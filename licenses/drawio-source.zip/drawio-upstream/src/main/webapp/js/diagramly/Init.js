/**
 * Copyright (c) 2006-2021, JGraph Holdings Ltd
 * Copyright (c) 2006-2021, draw.io AG
 */

// urlParams is null when used for embedding
window.urlParams = window.urlParams || {};

// mxIsElectron is false in embed mode (set by bootstrap.js for desktop)
if (window.mxIsElectron == null || urlParams['embed'] == '1')
{
	window.mxIsElectron = false;
}

// isLocalStorage controls access to local storage
window.isLocalStorage = window.isLocalStorage || false;

// Checks for SVG support
window.isSvgBrowser = true;

// Checks for Mermaid support
window.isMermaidEnabled = typeof structuredClone === 'function';

// CUSTOM_PARAMETERS - URLs for save and export
// Base URL defines cases where an absolute URL is needed (eg. embedding)
window.DRAWIO_BASE_URL = window.DRAWIO_BASE_URL || ((/.*\.draw\.io$/.test(window.location.hostname)) ||
	(/.*\.diagrams\.net$/.test(window.location.hostname)) ?
	window.location.protocol + '//' + window.location.hostname : 'https://app.diagrams.net');
window.DRAWIO_SERVER_URL = window.DRAWIO_SERVER_URL || window.location.origin +
	window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/')) + '/';
window.DRAWIO_LIGHTBOX_URL = window.DRAWIO_LIGHTBOX_URL || 'https://viewer.diagrams.net';
// Defaults only if unset so that a pre-configuration can set null to disable
// server-side export (see EditorUi.isRemoteExportEnabled)
window.EXPORT_URL = (typeof window.EXPORT_URL === 'undefined') ?
	'https://convert.diagrams.net/node/export' : window.EXPORT_URL;
window.DRAW_MATH_URL = window.DRAW_MATH_URL || 'math4/es5';
window.REALTIME_URL = window.REALTIME_URL || window.DRAWIO_SERVER_URL + 'cache';
window.DRAWIO_GITLAB_URL = window.DRAWIO_GITLAB_URL || 'https://gitlab.com';
window.DRAWIO_GITLAB_ID = window.DRAWIO_GITLAB_ID || '2b14debc5feeb18ba65358d863ec870e4cc9294b28c3c941cb3014eb4af9a9b4';
window.DRAWIO_GITHUB_URL = window.DRAWIO_GITHUB_URL || 'https://github.com';
window.DRAWIO_GITHUB_API_URL = window.DRAWIO_GITHUB_API_URL || 'https://api.github.com';
window.DRAWIO_GITHUB_ID = window.DRAWIO_GITHUB_ID || 'Iv1.98d62f0431e40543';
window.SAVE_URL = window.SAVE_URL || window.DRAWIO_SERVER_URL + 'save';
window.PROXY_URL = window.PROXY_URL || window.DRAWIO_SERVER_URL + 'proxy';
window.DRAWIO_VIEWER_URL = window.DRAWIO_VIEWER_URL || null;
window.NOTIFICATIONS_URL = window.NOTIFICATIONS_URL || ((/.*\.draw\.io$/.test(window.location.hostname)) ||
	(/.*\.diagrams\.net$/.test(window.location.hostname)) ?
	window.DRAWIO_SERVER_URL + 'notifications' : null);
window.RT_WEBSOCKET_URL = window.RT_WEBSOCKET_URL || ('wss://' + ((window.location.hostname == 'test.draw.io') ?
	'app.diagrams.net' : window.location.hostname) + '/rt');
// AI diagram generation (generate/v3 worker), on the own origin of the hosts
// that route it and on www.draw.io for all others
window.GENERATE_URL = window.GENERATE_URL || (((/^(www|ac|aj)\.draw\.io$/.test(window.location.hostname) ||
	window.location.hostname == 'app.diagrams.net') ? window.location.origin :
	'https://www.draw.io') + '/generate/v3');
// Maximum AI prompt length on the Atlassian deployments (applied to
// Editor.maxPublicPromptLength on ac.draw.io / aj.draw.io / Forge CDN hosts,
// 0 disables the limit); must not exceed the generate/v3 worker's
// MAX_PROMPT_LENGTH_ATLASSIAN, which enforces the server-side cap
window.DRAWIO_ATLASSIAN_PROMPT_LENGTH = (window.DRAWIO_ATLASSIAN_PROMPT_LENGTH != null) ?
	window.DRAWIO_ATLASSIAN_PROMPT_LENGTH : 100000;

// Paths and files
window.SHAPES_PATH = window.SHAPES_PATH || 'shapes';
// Path for images inside the diagram
window.GRAPH_IMAGE_PATH = window.GRAPH_IMAGE_PATH || 'img';
window.ICONSEARCH_PATH = window.ICONSEARCH_PATH || (urlParams['dev'] && window.location.protocol != 'file:' ?
	'iconSearch2' : window.DRAWIO_SERVER_URL + 'iconSearch2');
// Grouped icon search service (v3): returns icon sets alongside results
// and supports server-side data URI inlining. Takes precedence over
// ICONSEARCH_PATH in the sidebar search when defined.
window.ICON_SERVICE_PATH = window.ICON_SERVICE_PATH || (urlParams['dev'] && window.location.protocol != 'file:' ?
	'api/icons' : window.DRAWIO_SERVER_URL + 'api/icons');
window.TEMPLATE_PATH = window.TEMPLATE_PATH || 'templates';
window.NEW_DIAGRAM_CATS_PATH = window.NEW_DIAGRAM_CATS_PATH || 'newDiagramCats';
window.PLUGINS_BASE_PATH = window.PLUGINS_BASE_PATH || '';

// Allows third-party plugins to run
window.ALLOW_CUSTOM_PLUGINS = window.ALLOW_CUSTOM_PLUGINS || false;

// Directory for i18 files and basename for main i18n file
window.RESOURCES_PATH = window.RESOURCES_PATH || 'resources';
window.RESOURCE_BASE = window.RESOURCE_BASE || RESOURCES_PATH + '/dia';

// Specifies global configuration via variable
window.DRAWIO_CONFIG = window.DRAWIO_CONFIG || null;

// Sets the base path, the UI language via URL param and configures the
// supported languages to avoid 404s. The loading of all core language
// resources is disabled as all required resources are in grapheditor.
// properties. Note that in this example the loading of two resource
// files (the special bundle and the default bundle) is disabled to
// save a GET request. This requires that all resources be present in
// the special bundle.
window.mxLoadResources = window.mxLoadResources || false;
window.mxLanguage = window.mxLanguage || (function() 
{
	var lang = urlParams['lang'];
	
	// Known issue: No JSON object at this point in quirks in IE8
	if (lang == null && typeof(JSON) != 'undefined')
	{
		// Cannot use mxSettings here
		if (isLocalStorage) 
		{
			try
			{
				var value = localStorage.getItem('.drawio-config');
				
				if (value != null)
				{
					lang = JSON.parse(value).language || null;
				}
				
				if (!lang && window.mxIsElectron)
				{
					lang = urlParams['appLang'];
					
					if (lang != null)
			    	{
			    		var dash = lang.indexOf('-');
			    		
			    		if (dash >= 0)
			    		{
			    			lang = lang.substring(0, dash);
			    		}
			    		
			    		lang = lang.toLowerCase();
			    	}
				}
			}
			catch (e)
			{
				// cookies are disabled, attempts to use local storage will cause
				// a DOM error at a minimum on Chrome
				isLocalStorage = false;
			}
		}
	}
	
	return lang;
})();

// Add new languages here. First entry is translated to [Automatic]
// in the menu defintion in Diagramly.js.
window.mxLanguageMap = window.mxLanguageMap ||
{
	'i18n': '',
	'id' : 'Bahasa Indonesia',
	'ms' : 'Bahasa Melayu',
	'bs' : 'Bosanski',
	'bg' : 'Bulgarian',
	'ca' : 'Català',
	'cs' : 'Čeština',
	'da' : 'Dansk',
	'de' : 'Deutsch',
	'et' : 'Eesti',
	'en' : 'English',
	'es' : 'Español',
	'eu' : 'Euskara',
	'fil' : 'Filipino',
	'fr' : 'Français',
	'gl' : 'Galego',
	'it' : 'Italiano',
	'hu' : 'Magyar',
	'kl' : 'Kalaallisut',
	'lt' : 'Lietuvių',
	'lv' : 'Latviešu',
	'nl' : 'Nederlands',
	'no' : 'Norsk',
	'pl' : 'Polski',
	'pt-br' : 'Português (Brasil)',
	'pt' : 'Português (Portugal)',
	'ro' : 'Română',
	'fi' : 'Suomi',
	'sv' : 'Svenska',
	'vi' : 'Tiếng Việt',
	'tr' : 'Türkçe',
	'el' : 'Ελληνικά',
	'ru' : 'Русский',
	'sr' : 'Српски',
	'uk' : 'Українська',
	'he' : 'עברית',
	'ar' : 'العربية',
	'fa' : 'فارسی',
	'th' : 'ไทย',
	'ta' : 'தமிழ்',
	'ko' : '한국어',
	'ja' : '日本語',
	'zh' : '简体中文',
	'zh-tw' : '繁體中文'
};

if (typeof window.mxBasePath === 'undefined')
{
	window.mxBasePath = 'mxgraph';
	window.mxImageBasePath = 'mxgraph/images';
}

if (window.mxLanguages == null)
{
	window.mxLanguages = [];
	
	// Populates the list of supported special language bundles
	for (var lang in mxLanguageMap)
	{
		// Empty means default (ie. browser language), "en" means English (default for unsupported languages)
		// Since "en" uses no extension this must not be added to the array of supported language bundles.
		if (lang != 'en')
		{
			window.mxLanguages.push(lang);
		}
	}

	// Uses browser language if supported
	if (window.mxLanguage == null &&
		(window.location.hostname == 'test.draw.io' ||
		window.location.hostname == 'www.draw.io' ||
		window.location.hostname == 'viewer.diagrams.net' ||
		window.location.hostname == 'embed.diagrams.net' ||
		window.location.hostname == 'app.diagrams.net' ||
		window.location.hostname == 'jgraph.github.io'))
	{
		var lang = navigator.language;

		if (lang != null)
		{
			var dash = lang.indexOf('-');
				
			if (dash > 0)
			{
				lang = lang.substring(0, dash);
			}

			if (window.mxLanguages.indexOf(lang) >= 0)
			{
				window.mxLanguage = lang;
			}
		}
	}
}

//Disable Google Drive when running in a WebView (e.g, MS Teams App) Since auth doesn't work with disallowd_useragent
//[For MS Teams only] TODO Check if other apps are affected also (android and iOS)
if (urlParams['extAuth'] == '1' && /((iPhone|iPod|iPad).*AppleWebKit(?!.*Version)|; wv)/i.test(navigator.userAgent))
{
	urlParams['gapi'] = '0';
	urlParams['noDevice'] = '1';
	//Force viewer only
	//TODO This should always be for MS Teams only
	if (urlParams['lightbox'] != '1')
	{
		urlParams['lightbox'] = '1';
		urlParams['layers'] = '1';
		urlParams['viewerOnlyMsg'] = '1';
	}
}

// Uses lightbox mode on viewer domain
if (window.location.hostname == 'viewer.diagrams.net')
{
	urlParams['lightbox'] = '1';
}	

// Lightbox enables chromeless mode
if (urlParams['lightbox'] == '1')
{
	urlParams['chrome'] = '0';
}

// Embed inline is embed mode and sketch UI
if (urlParams['embedInline'] == '1')
{
	urlParams['embed'] = '1';
	urlParams['ui'] = 'sketch';
	urlParams['plugins'] = '0';
	urlParams['proto'] = 'json';
	urlParams['prefetchFonts'] = '1';

	// Forces page view off by default so the inline editor matches the
	// host page while the page setting stored in the file is preserved
	// (see savedGraphState in Editor.setGraphXml/getGraphXml)
	if (urlParams['pv'] == null)
	{
		urlParams['pv'] = '0';
	}
}

// The configuration message (configure=1) is only accepted in embed mode,
// where the host supplies and receives the diagram anyway. Otherwise any
// opener could configure the app that has the user's storage and sign-ins.
if (urlParams['configure'] == '1' && urlParams['embed'] != '1')
{
	delete urlParams['configure'];

	if (window.console != null)
	{
		console.log('Ignored configure=1 without embed=1');
	}
}

// Disables loading settings in configured mode
window.mxLoadSettings = window.mxLoadSettings || urlParams['configure'] != '1';

/**
 * Global function for loading local files via servlet
 */
function setCurrentXml(data, filename)
{
	if (window.parent != null && window.parent.openFile != null)
	{
		window.parent.openFile.setData(data, filename);
	}
};

/**
 * Returns the global UI setting before running static draw.io code
 */
window.uiTheme = window.uiTheme || (function() 
{
	var ui = urlParams['ui'];

	//Use Sketch theme for MS Teams (and any future extAuth) by default
	if (urlParams['extAuth'] == '1')
	{
		ui = 'sketch';
	}

	// Known issue: No JSON object at this point in quirks in IE8
	if (ui == null && isLocalStorage && typeof JSON !== 'undefined' && urlParams['lightbox'] != '1')
	{
		try
		{
			var value = localStorage.getItem('.drawio-config');
			
			if (value != null)
			{
				ui = JSON.parse(value).ui || null;
			}
		}
		catch (e)
		{
			// cookies are disabled, attempts to use local storage will cause
			// a DOM error at a minimum on Chrome
			isLocalStorage = false;
		}
	}
	
	// Redirects dark UI parameter
	if (urlParams['ui'] == 'dark' && urlParams['dark'] == null)
	{
		urlParams['dark'] = '1';
	}
	
	// Activates sketch mode in Confluence Cloud sketch theme
	if (ui == 'sketch' && urlParams['sketch'] == null &&
		window.location.hostname === 'ac.draw.io')
	{
		urlParams['sketch'] = '1';
	}
	
	return ui;
})();

/**
 * Overrides splash URL parameter via configuration
 */
(function()
{
	if (typeof JSON !== 'undefined')
	{
		// Cannot use mxSettings or Editor.config here
		var showSplash = (window.DRAWIO_CONFIG != null) ?
			window.DRAWIO_CONFIG.showSplashOnStart : null;

		if (isLocalStorage)
		{
			// Handles lockdown and splash screen configuration
			try
			{
				var value = localStorage.getItem('.configuration');

				if (value != null)
				{
					var config = JSON.parse(value);

					if (config != null)
					{
						if (config.lockdown != null)
						{
							urlParams['lockdown'] = config.lockdown;
						}

						if (config.showSplashOnStart != null)
						{
							showSplash = config.showSplashOnStart;
						}
					}
				}
			}
			catch (e)
			{
				// ignore
			}
		}

		if (showSplash != true && urlParams['splash'] == null)
		{
			urlParams['splash'] = '0';
		}
	}
	
	// The export service is not taken from the URL. The export request carries
	// the diagram, so a link that picked the service would send the diagram to
	// whoever wrote the link as soon as the user exported [GHSA-ff67-v9r9-6877].
	// A deployment sets window.EXPORT_URL in PreConfig.js, which loads first.

	// Customizes gitlab URL
	var glUrl = urlParams['gitlab'];

	if (glUrl != null)
	{
		glUrl = decodeURIComponent(glUrl);
		
		if (glUrl.substring(0, 7) != 'http://' &&  glUrl.substring(0, 8) != 'https://')
		{
			glUrl = 'http://' + glUrl;
		}
		
		DRAWIO_GITLAB_URL = glUrl;
	}
	
	var glId = urlParams['gitlab-id'];

	if (glId != null)
	{
		DRAWIO_GITLAB_ID = glId;
	}

	// URL for logging
	window.DRAWIO_LOG_URL = window.DRAWIO_LOG_URL || '';

	//Adds hard-coded logging domain for draw.io domains
	var host = window.location.host;
	
	if (host != 'test.draw.io')
	{
		var searchString = 'diagrams.net';
		var position = host.length - searchString.length;
		var lastIndex = host.lastIndexOf(searchString, position);
		
		if (lastIndex !== -1 && lastIndex === position)
		{
			window.DRAWIO_LOG_URL = 'https://log.diagrams.net';
		}
		else
		{
			// For atlas integrations
			var searchString = 'draw.io';
			var position = host.length - searchString.length;
			var lastIndex = host.lastIndexOf(searchString, position);
			
			if (lastIndex !== -1 && lastIndex === position)
			{
				window.DRAWIO_LOG_URL = 'https://log.draw.io';
			}
		}
	}
})();

// Enables stealth mode with Google Drive
if (urlParams['gapi-stealth'] == '1')
{
	urlParams['stealth'] = '1';
}

// Enables offline mode
if (urlParams['offline'] == '1' || urlParams['demo'] == '1' || 
	urlParams['stealth'] == '1' || urlParams['local'] == '1' ||
	urlParams['lockdown'] == '1')
{
	urlParams['picker'] = (urlParams['gapi-stealth'] == '1') ? '1' : '0';
	urlParams['gapi'] = (urlParams['gapi-stealth'] == '1') ? '1' : '0';
	urlParams['od'] = '0';
	urlParams['gh'] = '0';
	urlParams['gl'] = '0';
	urlParams['tr'] = '0';
	urlParams['ms365'] = '0';
}

// Disables Trello client by default
if (urlParams['mode'] == 'trello')
{
	urlParams['tr'] = '1';
}

// Uses embed mode on embed domain
if (window.location.hostname == 'embed.diagrams.net')
{
	urlParams['embed'] = '1';
}

// Fallback for cases where the hash property is not available
if ((window.location.hash == null || window.location.hash.length <= 1) &&
	urlParams['open'] != null)
{
	window.location.hash = urlParams['open'];
}

// TODO: One day we could remove this. It's just to stop mermaid throwing syntax error on startup for pre v98 browsers
// Maybe remove in 2027
if (typeof window.structuredClone !== 'function')
{
	window.structuredClone = function(value)
	{
		{
			return value;
		}
	}
}
