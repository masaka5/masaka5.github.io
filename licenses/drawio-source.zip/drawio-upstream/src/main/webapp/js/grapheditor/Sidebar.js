/**
 * Copyright (c) 2006-2012, JGraph Holdings Ltd
 */
/**
 * Construcs a new sidebar for the given editor.
 */
function Sidebar(editorUi, container)
{
	this.editorUi = editorUi;
	this.container = container;
	// Sidebar background tooltip ("Click or drag and drop shapes. …") —
	// the section titles now carry a more specific "Drag to reorder"
	// hint, so the broader instruction lives on the container itself
	// and surfaces when the user hovers over empty sidebar space.
	this.container.setAttribute('title', mxResources.get('sidebarTooltip'));
	this.palettes = new Object();
	// Null prototype as the taglist is looked up with user-typed search
	// terms, eg. __proto__ must not resolve to inherited members
	this.taglist = Object.create(null);
	this.lastCreated = 0;
	this.showTooltips = true;
	this.recentShapes = [];
	this.graph = editorUi.createTemporaryGraph(this.editorUi.editor.graph.getStylesheet());
    this.graph.cellRenderer.minSvgStrokeWidth = this.minThumbStrokeWidth;
	this.graph.cellRenderer.antiAlias = this.thumbAntiAlias;
	this.graph.container.style.visibility = 'hidden';
	this.graph.shapeBackgroundColor = 'transparent';
	this.graph.foldingEnabled = false;

	// Uses the initial default style for rendering the sidebars
	this.initialDefaultVertexStyle = mxUtils.clone(editorUi.editor.graph.defaultVertexStyle);
	this.initialDefaultEdgeStyle = mxUtils.clone(editorUi.editor.graph.defaultEdgeStyle);
	// Keys that do not identify a shape in the style to libraries map, eg. the
	// label perimeter that is added to shapes with labels outside on insert
	this.ignoredStyles = ['html', 'whiteSpace', 'aspect', 'points', 'verticalLabelPosition',
		'labelPosition', 'outlineConnect', 'labelPerimeter'].concat(Graph.cellStyles);
	
	// Wrapper for entries and footer
	this.wrapper = document.createElement('div');
	this.container.appendChild(this.wrapper);

	var title = this.createMoreShapes();
	this.container.appendChild(title);

	document.body.appendChild(this.graph.container);
	
	this.pointerUpHandler = mxUtils.bind(this, function()
	{
		if (this.tooltipCloseImage == null || this.tooltipCloseImage.style.display == 'none')
		{
			this.showTooltips = true;
			this.hideTooltip();
		}
	});

	this.pointerDownHandler = mxUtils.bind(this, function(evt)
	{
		if (this.tooltipCloseImage == null || this.tooltipCloseImage.style.display == 'none')
		{
			this.showTooltips = false;
			this.hideTooltip();
		}
		// Closes closable tooltips on pointer events outside of the tooltip
		else if (this.tooltip != null && this.tooltip.style.display != 'none' &&
			!mxUtils.isAncestorNode(this.tooltip, mxEvent.getSource(evt)))
		{
			this.hideTooltip();
		}
	});

	this.pointerMoveHandler = mxUtils.bind(this, function(evt)
	{
		if (Date.now() - this.lastCreated > 300 && (this.tooltipCloseImage == null ||
			this.tooltipCloseImage.style.display == 'none'))
		{
			var src = mxEvent.getSource(evt);
			
			while (src != null)
			{
				if (src == this.currentElt)
				{
					return;
				}
				
				src = src.parentNode;
			}
			
			this.hideTooltip();
		}
	});

	// Handles mouse leaving the window
	this.pointerOutHandler = mxUtils.bind(this, function(evt)
	{
		if (evt.toElement == null && evt.relatedTarget == null)
		{
			this.hideTooltip();
		}
	});
	
	// Adds listeners in capture phase to bypass blocking in other listeners
	if (window.addEventListener)
	{
		document.addEventListener((mxClient.IS_POINTER) ? 'pointerup' : 'mouseup', this.pointerUpHandler, true)
		document.addEventListener((mxClient.IS_POINTER) ? 'pointerdown' : 'mousedown', this.pointerDownHandler, true)
		document.addEventListener((mxClient.IS_POINTER) ? 'pointermove' : 'mousemove', this.pointerMoveHandler, true)
		document.addEventListener((mxClient.IS_POINTER) ? 'pointerout' : 'mouseout', this.pointerOutHandler, true)
	}
	else
	{
		mxEvent.addListener(document, (mxClient.IS_POINTER) ? 'pointerup' : 'mouseup', this.pointerUpHandler);
		mxEvent.addListener(document, (mxClient.IS_POINTER) ? 'pointerdown' : 'mousedown', this.pointerDownHandler);
		mxEvent.addListener(document, (mxClient.IS_POINTER) ? 'pointermove' : 'mousemove', this.pointerMoveHandler);
		mxEvent.addListener(document, (mxClient.IS_POINTER) ? 'pointerout' : 'mouseout', this.pointerOutHandler);
	}

	// Enables tooltips after scroll
	mxEvent.addListener(container, 'scroll', mxUtils.bind(this, function()
	{
		this.showTooltips = true;
		this.hideTooltip();
	}));

	// Stops dragging if escape is pressed
	this.escapeListener = mxUtils.bind(this, function(sender, evt)
	{
		if (this.activeDragSource != null && this.activeDragSource.isActive())
		{
			this.activeDragSource.reset();
		}
	});

	this.editorUi.editor.graph.addListener(mxEvent.ESCAPE, this.escapeListener);

	this.refreshListener = mxUtils.bind(this, function(sender, evt)
	{
		this.refresh();
	});

	this.editorUi.addListener('sidebarTitlesChanged', this.refreshListener);
	this.editorUi.addListener('languageChanged', this.refreshListener);
	this.init();
};

/**
 * Adds all palettes to the sidebar.
 */
Sidebar.prototype.init = function()
{
	var dir = STENCIL_PATH;
	
	this.addSearchPalette(true);
	this.addGeneralPalette(true);
	this.addMiscPalette(false);
	this.addAdvancedPalette(false);
	this.addBasicPalette(dir);
	
	this.setCurrentSearchEntryLibrary('arrows');
	this.addStencilPalette('arrows', mxResources.get('arrows'), dir + '/arrows.xml',
		';whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=2');
	this.setCurrentSearchEntryLibrary();
	
	this.addUmlPalette(false);
	this.addBpmnPalette(dir, false);
	
	this.setCurrentSearchEntryLibrary('flowchart');
	this.addStencilPalette('flowchart', 'Flowchart', dir + '/flowchart.xml',
		';whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=2');
	this.setCurrentSearchEntryLibrary();
	
	this.setCurrentSearchEntryLibrary('clipart');
	this.addImagePalette('clipart', mxResources.get('clipart'), dir + '/clipart/', '_128x128.png',
		['Earth_globe', 'Empty_Folder', 'Full_Folder', 'Gear', 'Lock', 'Software', 'Virus', 'Email',
		 'Database', 'Router_Icon', 'iPad', 'iMac', 'Laptop', 'MacBook', 'Monitor_Tower', 'Printer',
		 'Server_Tower', 'Workstation', 'Firewall_02', 'Wireless_Router_N', 'Credit_Card',
		 'Piggy_Bank', 'Graph', 'Safe', 'Shopping_Cart', 'Suit1', 'Suit2', 'Suit3', 'Pilot1',
		 'Worker1', 'Soldier1', 'Doctor1', 'Tech1', 'Security1', 'Telesales1'], null,
		 {'Wireless_Router_N': 'wireless router switch wap wifi access point wlan',
		  'Router_Icon': 'router switch'});
	this.setCurrentSearchEntryLibrary();
};

/**
 * Specifies if tooltips should be visible. Default is true.
 */
Sidebar.prototype.enableTooltips = true;

/**
 * Specifies the border for the tooltip. Default is 16 px.
 */
Sidebar.prototype.tooltipBorder = 16;

/**
 * Specifies the delay for the tooltip. Default is 300 ms.
 */
Sidebar.prototype.tooltipDelay = 300;

/**
 * Specifies the delay for the drop target icons. Default is 200 ms.
 */
Sidebar.prototype.dropTargetDelay = 200;

/**
 * Specifies the URL of the gear image.
 */
Sidebar.prototype.gearImage = STENCIL_PATH + '/clipart/Gear_128x128.png';

/**
 * Specifies the width of the thumbnails.
 */
Sidebar.prototype.thumbWidth = 38;

/**
 * Specifies the height of the thumbnails.
 */
Sidebar.prototype.thumbHeight = 38;

/**
 * Specifies the width of the thumbnails.
 */
Sidebar.prototype.minThumbStrokeWidth = 1;

/**
 * Specifies the width of the thumbnails.
 */
Sidebar.prototype.thumbAntiAlias = false;

/**
 * Specifies the delay for the tooltip. Default is 2 px.
 */
Sidebar.prototype.thumbBorder = 2;

/**
 * Whether live preview should be enabled. Default is true.
 */
Sidebar.prototype.livePreview = true;

/**
 * Whether closed libraries should be searched. Default is true.
 */
Sidebar.prototype.searchClosedLibraries = true;

/**
 * Opacity for search results from closed libraries. Default is null.
 */
Sidebar.prototype.closedLibraryOpacity = null;

/**
 * Optional map from library ID to a search ranking weight (default
 * weight is 0). The weight breaks ties between equally scored search
 * results, eg. to rank shapes from the latest library of a family
 * above the same shapes from its superseded predecessors. Default
 * is null (no weights).
 */
Sidebar.prototype.librarySearchWeights = null;

/**
 * Whether an image-only search (eg. via an external icon provider) is
 * available. Default is false; subclassers that wire up an image search
 * backend override this to surface the "Search Images" omnibox option.
 */
Sidebar.prototype.isImageSearchSupported = function()
{
	return false;
};

/*
 * Experimental smaller sidebar entries
 */
if (urlParams['sidebar-entries'] != 'large')
{
	Sidebar.prototype.thumbBorder = 1;
	Sidebar.prototype.thumbWidth = 32;
	Sidebar.prototype.thumbHeight = 30;
	Sidebar.prototype.minThumbStrokeWidth = 1.3;
	Sidebar.prototype.thumbAntiAlias = true;
}

/*
 * Defers createThumb until the entry scrolls near the viewport via an
 * IntersectionObserver. Off-screen palettes pay almost nothing even
 * when expanded. Toggled off by callers (e.g. search) that need the
 * thumb's inner DOM populated synchronously. Falls back to eager
 * rendering (the historical behavior) on browsers without
 * IntersectionObserver support (IE11, Safari <12.1).
 */
Sidebar.prototype.virtualThumbs = typeof IntersectionObserver != 'undefined';

/*
 * Defers a palette's content creation (onInit) until the expanded
 * palette scrolls near the viewport — virtualThumbs at the palette
 * level. Startup and Expand All then only pay for the palettes in
 * view, even with every library expanded; the rest initialize on
 * scroll. Falls back to eager init (the historical behavior) on
 * browsers without IntersectionObserver support (IE11, Safari <12.1).
 */
Sidebar.prototype.virtualPalettes = typeof IntersectionObserver != 'undefined';

/**
 * Placeholder height (in px) for expanded palettes whose content
 * creation is deferred. Callers that know their entry count refine
 * this via setDeferredPaletteSize so that off-screen palettes occupy
 * roughly their real height (a zero-height placeholder would sit at
 * the same scroll offset as its neighbors and trigger the observer
 * for all of them at once).
 */
Sidebar.prototype.deferredPaletteHeight = 60;

/**
 * Specifies the size of the sidebar titles.
 */
Sidebar.prototype.sidebarTitleSize = 8;

/**
 * Specifies if titles in the sidebar should be enabled.
 */
Sidebar.prototype.sidebarTitles = false;

/**
 * Specifies if titles in the tooltips should be enabled.
 */
Sidebar.prototype.tooltipTitles = true;

/**
 * Specifies if titles in the tooltips should be enabled.
 */
Sidebar.prototype.maxTooltipWidth = 400;

/**
 * Specifies if titles in the tooltips should be enabled.
 */
Sidebar.prototype.maxTooltipHeight = 400;

/**
 * Maximum zoom for scaled-down closable tooltips. Default is 2.
 */
Sidebar.prototype.maxTooltipZoom = 2;

/**
 * Specifies if stencil files should be loaded and added to the search index
 * when stencil palettes are added. If this is false then the stencil files
 * are lazy-loaded when the palette is shown.
 */
Sidebar.prototype.addStencilsToIndex = true;

/**
 * Specifies the width for clipart images. Default is 80.
 */
Sidebar.prototype.defaultImageWidth = 80;

/**
 * Specifies the height for clipart images. Default is 80.
 */
Sidebar.prototype.defaultImageHeight = 80;

/**
 * Specifies the height for clipart images. Default is 80.
 */
Sidebar.prototype.tooltipMouseDown = null;

/**
 * Specifies if libraries are expanded by default. Default is true.
 */
Sidebar.prototype.expandLibraries = true;

/**
 * Reloads the sidebar.
 */
Sidebar.prototype.refresh = function()
{
	var graph = this.editorUi.editor.graph;
	this.graph.stylesheet.styles = mxUtils.clone(
		graph.getStylesheet().styles);
	var scrollTop = this.wrapper.scrollTop;

	// Drops pending lazy-render callbacks so the observers do not keep
	// the DOM removed below alive; recreated lazily on next use
	this.disconnectObservers();
	this.wrapper.innerText = '';
	var temp = this.palettes;
	this.palettes = new Object();

	// Overrides addPalette to restore expanded state
	var addPalette = this.addPalette;

	this.addPalette = function(id, title, expanded, onInit)
	{
		expanded = this.wasPaletteExpanded(temp, id, expanded);

		return addPalette.apply(this, arguments);
	};

	this.init(temp);

	// Restores previous implementation
	this.addPalette = addPalette;

	// Restores scrollbar position
	window.setTimeout(mxUtils.bind(this, function()
	{	
		this.wrapper.scrollTop = scrollTop;
	}), 0);
};

/**
 * Overrides the sidebar init.
 */
Sidebar.prototype.wasPaletteExpanded = function(paletteStates, id, defaultExpanded)
{
	var elts = (paletteStates != null && id != null) ? paletteStates[id] : null;
	var result = defaultExpanded

	if (elts != null && elts.length == 2 &&
		elts[1].firstChild != null)
	{
		result = elts[1].firstChild.style.display != 'none';
	}

	return result;
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.getEntryContainer = function()
{
	return this.wrapper;
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.appendChild = function(child)
{
	this.wrapper.appendChild(child);
};

/**
 * Adds all palettes to the sidebar.
 */
Sidebar.prototype.getTooltipOffset = function(elt, bounds)
{
	if (mxUtils.isAncestorNode(this.container, elt))
	{
		var b = document.body;
		var d = document.documentElement;
		var bottom = Math.max(b.clientHeight || 0, d.clientHeight);
		var height = bounds.height + 2 * this.tooltipBorder;
		
		return new mxPoint(this.container.offsetWidth + 2 + this.editorUi.container.offsetLeft,
			Math.min(bottom - height - 20 /*status bar*/, Math.max(0, (this.editorUi.container.offsetTop +
				this.container.offsetTop + elt.offsetTop - this.wrapper.scrollTop - height / 2 + 16))));	
	}
	else
	{
		var rect = elt.getBoundingClientRect();

		return new mxPoint(rect.x + rect.width + this.tooltipBorder,
			rect.y + rect.height / 2 - bounds.height / 2 - 6);
	}
};

/**
 * Adds all palettes to the sidebar.
 */
Sidebar.prototype.createMoreShapes = function()
{
	var div =  this.editorUi.createDiv('geSidebarFooter');
	var title = document.createElement('button');
	title.className = 'geBtn gePrimaryBtn';

	this.editorUi.dependsOnLanguage(mxUtils.bind(this, function()
	{
		title.innerHTML = '<span>+</span>';
		mxUtils.write(title, mxResources.get('moreShapes'));
		title.setAttribute('title', mxResources.get('moreShapes'));
	}));
	
	mxEvent.addListener(title, 'click', mxUtils.bind(this, function(evt)
	{
		this.editorUi.actions.get('shapes').funct();
		mxEvent.consume(evt);
	}));

	mxEvent.preventDefault(title);
	div.appendChild(title);
	
	return div;
};

/**
 * Adds all palettes to the sidebar.
 */
Sidebar.prototype.createTooltip = function(elt, cells, w, h, title, showLabel, off, maxSize, mouseDown, closable, applyAllStyles)
{
	applyAllStyles = (applyAllStyles != null) ? applyAllStyles : true;
	this.tooltipMouseDown = mouseDown;
	var graph = this.editorUi.editor.graph;

	// Lazy creation of the DOM nodes and graph instance
	if (this.tooltip == null)
	{
		this.tooltip = document.createElement('div');
		this.tooltip.className = 'geSidebarTooltip';
		this.tooltip.style.userSelect = 'none';
		this.tooltip.style.zIndex = mxPopupMenu.prototype.zIndex - 1;
		document.body.appendChild(this.tooltip);

		mxEvent.addMouseWheelListener(mxUtils.bind(this, function(evt, up, pinch, cx, cy, ratio)
		{
			// Zooms tooltips that were scaled down to fit, hides others
			if (this.tooltipZoomControls.style.display != 'none')
			{
				var factor = this.graph2.zoomFactor;

				// Slower zoom for pinch gesture on trackpad
				if (evt.deltaY != null && Math.abs(evt.deltaY) < 40 &&
					Math.round(evt.deltaY) != evt.deltaY)
				{
					factor = 1 + (Math.abs(evt.deltaY) / 20) * (factor - 1);
				}
				// Pinch gesture on touch screens zooms by the change of the
				// distance between the fingers
				else if (ratio != null)
				{
					factor = (ratio > 1) ? ratio : 1 / ratio;
				}

				var rect = this.tooltipContent.getBoundingClientRect();
				this.setTooltipZoom(this.tooltipZoom * ((up) ? factor : 1 / factor),
					((cx != null) ? cx : mxEvent.getClientX(evt)) - rect.left,
					((cy != null) ? cy : mxEvent.getClientY(evt)) - rect.top);
				mxEvent.consume(evt);
			}
			else
			{
				this.hideTooltip();
			}
		}), this.tooltip);

		// Scrollable pane between the graph and the overlaid buttons and title
		this.tooltipContent = document.createElement('div');
		this.tooltipContent.style.width = '100%';
		this.tooltipContent.style.height = '100%';
		this.tooltip.appendChild(this.tooltipContent);

		this.graph2 = new Graph(this.tooltipContent, null, null, this.editorUi.editor.graph.getStylesheet());
		this.graph2.shapeBackgroundColor = this.graph.shapeBackgroundColor;
		this.graph2.resetViewOnRootChange = false;
		this.graph2.foldingEnabled = false;
		this.graph2.gridEnabled = false;
		this.graph2.autoScroll = false;
		this.graph2.setTooltips(false);
		this.graph2.setConnectable(false);
		this.graph2.setPanning(false);
		this.graph2.setEnabled(false);

		// Renders oveflow on SVG
		if (this.graph2.dialect == mxConstants.DIALECT_SVG)
		{
			var root = this.graph2.view.getDrawPane().ownerSVGElement;
			
			if (root != null)
			{
				root.style.overflow = 'visible';
			}
		}
		else
		{
			this.graph2.view.canvas.style.overflow = 'visible';
		}
		
		// Blocks all links
		this.graph2.openLink = mxUtils.bind(this, function()
		{
			this.hideTooltip();
		});
		
		mxEvent.addGestureListeners(this.tooltip, mxUtils.bind(this, function(evt)
		{
			if (mxUtils.isAncestorNode(this.tooltipZoomControls, mxEvent.getSource(evt)))
			{
				return;
			}

			if (this.tooltipMouseDown != null)
			{
				this.tooltipMouseDown(evt);
			}

			window.setTimeout(mxUtils.bind(this, function()
			{
				if (this.tooltipCloseImage == null || this.tooltipCloseImage.style.display == 'none')
				{
					this.hideTooltip();
				}
			}), 0);
		}), null, mxUtils.bind(this, function(evt)
		{
			// Keeps zoomed tooltips visible for scrolling and ignores
			// clicks on the zoom controls
			if (!this.isTooltipZoomed() && !mxUtils.isAncestorNode(
				this.tooltipZoomControls, mxEvent.getSource(evt)))
			{
				this.hideTooltip();
			}
		}));

		// Pans a zoomed tooltip on drag inside its viewport
		mxEvent.addGestureListeners(this.tooltipContent, mxUtils.bind(this, function(evt)
		{
			if (this.isTooltipZoomed() && evt.isPrimary != false &&
				(!mxEvent.isMouseEvent(evt) || mxEvent.isLeftMouseButton(evt)))
			{
				var content = this.tooltipContent;
				var rect = content.getBoundingClientRect();
				var px = mxEvent.getClientX(evt);
				var py = mxEvent.getClientY(evt);

				// Ignores events over the scrollbars for native scrolling
				if (px - rect.left < content.clientWidth &&
					py - rect.top < content.clientHeight)
				{
					var sl = content.scrollLeft;
					var st = content.scrollTop;
					content.style.cursor = 'grabbing';

					var move = function(evt2)
					{
						content.scrollLeft = sl - mxEvent.getClientX(evt2) + px;
						content.scrollTop = st - mxEvent.getClientY(evt2) + py;
						mxEvent.consume(evt2);
					};

					var end = mxUtils.bind(this, function(evt2)
					{
						mxEvent.removeGestureListeners(document, null, move, end);
						content.style.cursor = (this.isTooltipZoomed()) ? 'grab' : '';
					});

					mxEvent.addGestureListeners(document, null, move, end);
					mxEvent.consume(evt, true, false);
				}
			}
		}));

		var close = document.createElement('img');
		close.setAttribute('src', Editor.crossImage);
		close.setAttribute('title', mxResources.get('close'));
		close.className = 'geButton';
		this.tooltip.appendChild(close);
		this.tooltipCloseImage = close;

		mxEvent.addListener(close, 'click', mxUtils.bind(this, function(evt)
		{
			this.hideTooltip();
			mxEvent.consume(evt);
		}));

		// Zoom controls for tooltips that were scaled down to fit
		var controls = document.createElement('div');
		controls.style.position = 'absolute';
		controls.style.right = '26px';
		controls.style.top = '2px';
		controls.style.whiteSpace = 'nowrap';
		this.tooltip.appendChild(controls);
		this.tooltipZoomControls = controls;

		var addZoomButton = mxUtils.bind(this, function(src, title, fn)
		{
			var btn = document.createElement('img');
			btn.setAttribute('src', src);
			btn.setAttribute('title', title);
			btn.className = 'geButton';
			btn.style.position = 'static';
			controls.appendChild(btn);

			mxEvent.addListener(btn, 'click', mxUtils.bind(this, function(evt)
			{
				fn();
				mxEvent.consume(evt);
			}));
		});

		addZoomButton(Editor.zoomInImage, mxResources.get('zoomIn'),
			mxUtils.bind(this, function()
		{
			this.setTooltipZoom(this.tooltipZoom * this.graph2.zoomFactor);
		}));

		addZoomButton(Editor.zoomOutImage, mxResources.get('zoomOut'),
			mxUtils.bind(this, function()
		{
			this.setTooltipZoom(this.tooltipZoom / this.graph2.zoomFactor);
		}));

		addZoomButton(Editor.zoomFitImage, mxResources.get('fit'),
			mxUtils.bind(this, function()
		{
			this.setTooltipZoom(this.tooltipFitScale);
		}));
	}
	
	this.tooltipCloseImage.style.display = (closable) ? '' : 'none';
	this.graph2.model.clear();
	this.graph2.view.setTranslate(this.tooltipBorder, this.tooltipBorder);
	
	if (!maxSize && (w > this.maxTooltipWidth || h > this.maxTooltipHeight))
	{
		this.graph2.view.scale = Math.round(Math.min(this.maxTooltipWidth / w, this.maxTooltipHeight / h) * 100) / 100;
	}
	else
	{
		this.graph2.view.scale = 1;
	}
	
	this.tooltip.style.display = 'block';
	this.graph2.labelsVisible = (showLabel == null || showLabel);
	var fo = mxClient.NO_FO;
	mxClient.NO_FO = Editor.prototype.originalNoForeignObject;
	
	// Applies current style for preview
	if (cells != null)
	{
		var temp = this.graph2.cloneCells(cells);
		this.graph2.pasteCellStyles(graph.includeDescendants(temp),
			(!applyAllStyles) ? graph.defaultVertexStyle : graph.currentVertexStyle,
			(!applyAllStyles) ? graph.defaultEdgeStyle : graph.currentEdgeStyle,
			null, graph.pasteEdgeStyle, (applyAllStyles) ?
				graph.pasteStylesToText : false);
		this.graph2.addCells(temp);
	}

	mxClient.NO_FO = fo;
	var bounds = this.graph2.getGraphBounds();
	this.tooltipFitScale = null;

	// Maximum size applied with transform for faster repaint
	if (maxSize && w > 0 && h > 0 && (bounds.width > w || bounds.height > h))
	{
		var s = Math.round(Math.min(w / bounds.width, h / bounds.height) * 100) / 100;

		if (!mxClient.NO_FO)
		{
			// Remembers fitted scale and unscaled size for setTooltipZoom
			this.tooltipFitScale = s;
			this.tooltipDocWidth = bounds.width + 2 * this.tooltipBorder + 4;
			this.tooltipDocHeight = bounds.height + 2 * this.tooltipBorder;

			this.graph2.view.getDrawPane().ownerSVGElement.style.transform = 'scale(' + s + ')';
			this.graph2.view.getDrawPane().ownerSVGElement.style.transformOrigin = '0 0';
			bounds.width *= s;
			bounds.height *= s;
		}
		else
		{
			this.graph2.view.setScale(Math.round(Math.min(
				this.maxTooltipWidth / bounds.width,
				this.maxTooltipHeight / bounds.height) * 100) / 100);
			bounds = this.graph2.getGraphBounds();
		}
	}
	else if (!mxClient.NO_FO)
	{
		this.graph2.view.getDrawPane().ownerSVGElement.style.transform = '';
	}

	// Resets zoom and scrollbars from the previous tooltip
	this.tooltipZoom = this.tooltipFitScale;
	this.tooltipZoomControls.style.display = (closable &&
		this.tooltipFitScale != null) ? '' : 'none';
	this.tooltipContent.style.overflow = 'visible';
	this.tooltipContent.style.cursor = '';

	if (!mxClient.NO_FO)
	{
		var root = this.graph2.view.getDrawPane().ownerSVGElement;
		root.style.width = '100%';
		root.style.height = '100%';
	}

	var width = bounds.width + 2 * this.tooltipBorder + 4;
	var height = bounds.height + 2 * this.tooltipBorder;

	this.tooltip.style.overflow = 'visible';
	this.tooltip.style.width = width + 'px';
	this.tooltipContent.style.height = height + 'px';
	var w2 = width;
	
	// Adds title for entry
	if (this.tooltipTitles && title != null && title.length > 0)
	{
		if (this.tooltipTitle == null)
		{
			this.tooltipTitle = document.createElement('div');
			this.tooltipTitle.style.borderTopStyle = 'solid';
			this.tooltipTitle.style.borderTopWidth = '1px';
			this.tooltipTitle.style.textAlign = 'center';
			this.tooltipTitle.style.width = '100%';
			this.tooltipTitle.style.overflow = 'hidden';
			this.tooltipTitle.style.position = 'absolute';
			this.tooltipTitle.style.paddingTop = '6px';
			this.tooltipTitle.style.bottom = '6px';

			this.tooltip.appendChild(this.tooltipTitle);
		}
		else
		{
			this.tooltipTitle.innerText = '';
		}
		
		this.tooltipTitle.style.display = '';
		mxUtils.write(this.tooltipTitle, title);
		this.tooltipTitle.setAttribute('title', title);
		
		// Allows for wider labels
		w2 = Math.min(this.maxTooltipWidth, Math.max(width, this.tooltipTitle.scrollWidth + 4));
		var ddy = this.tooltipTitle.offsetHeight + 10;
		height += ddy;
		
		this.tooltipTitle.style.marginTop = (2 - ddy) + 'px';
	}
	else if (this.tooltipTitle != null && this.tooltipTitle.parentNode != null)
	{
		this.tooltipTitle.style.display = 'none';
	}

	// Updates width if label is wider
	if (w2 > width)
	{
		this.tooltip.style.width = w2 + 'px';
	}
	
	this.tooltip.style.height = height + 'px';
	var x0 = -Math.round(bounds.x - this.tooltipBorder) +
		((w2 > width) ? (w2 - width) / 2 : 0);

	if (w2 > width && this.tooltipFitScale != null)
	{
		// Keeps the centered content inside the zoomed scroll range
		this.tooltipDocWidth += (w2 - width) / 2;
	}

	var y0 = -Math.round(bounds.y - this.tooltipBorder);
	off = (off != null) ? off : this.getTooltipOffset(elt, bounds);
	var left = off.x;
	var top = off.y;
	
	// Remembers the content offset for setTooltipZoom
	this.tooltipDx = x0;
	this.tooltipDy = y0;

	if (x0 != 0 || y0 != 0)
	{
		this.graph2.view.canvas.setAttribute('transform', 'translate(' + x0 + ',' + y0 + ')');
	}
	else
	{
		this.graph2.view.canvas.removeAttribute('transform');
	}
	
	// Workaround for ignored position CSS style in IE9
	// (changes to relative without the following line)
	this.tooltip.style.position = 'absolute';
	this.tooltip.style.left = Math.max(0, left) + 'px';
	this.tooltip.style.top = Math.max(0, top) + 'px';
	
	mxUtils.fit(this.tooltip, this.tooltipBorder);
	this.lastCreated = Date.now();
};

/**
 * Returns true if the current tooltip is zoomed beyond its fitted scale.
 */
Sidebar.prototype.isTooltipZoomed = function()
{
	return this.tooltipFitScale != null && this.tooltipZoom > this.tooltipFitScale;
};

/**
 * Sets the zoom of a tooltip that was scaled down to fit, adding scrollbars
 * while the content is larger than the fitted tooltip size. The optional
 * cx and cy define the fixpoint of the zoom in the tooltip viewport,
 * defaulting to its center.
 */
Sidebar.prototype.setTooltipZoom = function(zoom, cx, cy)
{
	if (this.tooltipFitScale != null)
	{
		zoom = Math.max(this.tooltipFitScale, Math.min(this.maxTooltipZoom, zoom));
		var root = this.graph2.view.getDrawPane().ownerSVGElement;
		var content = this.tooltipContent;
		cx = (cx != null) ? cx : content.clientWidth / 2;
		cy = (cy != null) ? cy : content.clientHeight / 2;

		// Keeps the fixpoint stable while zooming
		var dx = (content.scrollLeft + cx) / this.tooltipZoom;
		var dy = (content.scrollTop + cy) / this.tooltipZoom;
		this.tooltipZoom = zoom;

		if (this.isTooltipZoomed())
		{
			// Zooms via the canvas transform with the SVG sized to the visible
			// diagram so that its layout size defines the exact scroll range
			// (a CSS scale transform does not shrink the scrollable size)
			this.graph2.view.canvas.setAttribute('transform', 'scale(' + zoom +
				') translate(' + this.tooltipDx + ',' + this.tooltipDy + ')');
			root.style.transform = '';
			root.style.width = Math.ceil(this.tooltipDocWidth * zoom) + 'px';
			root.style.height = Math.ceil(this.tooltipDocHeight * zoom) + 'px';
			content.style.overflow = 'auto';
			content.scrollLeft = Math.round(dx * zoom - cx);
			content.scrollTop = Math.round(dy * zoom - cy);
		}
		else
		{
			// Restores the fitted view
			if (this.tooltipDx != 0 || this.tooltipDy != 0)
			{
				this.graph2.view.canvas.setAttribute('transform',
					'translate(' + this.tooltipDx + ',' + this.tooltipDy + ')');
			}
			else
			{
				this.graph2.view.canvas.removeAttribute('transform');
			}

			root.style.transform = 'scale(' + this.tooltipFitScale + ')';
			root.style.transformOrigin = '0 0';
			root.style.width = '100%';
			root.style.height = '100%';
			content.style.overflow = 'visible';
		}

		content.style.cursor = (this.isTooltipZoomed()) ? 'grab' : '';
	}
};

/**
 * Adds all palettes to the sidebar.
 */
Sidebar.prototype.showTooltip = function(elt, cells, w, h, title, showLabel, off)
{
	if (this.enableTooltips && this.showTooltips)
	{
		if (this.currentElt != elt)
		{
			if (this.thread != null)
			{
				window.clearTimeout(this.thread);
				this.thread = null;
			}

			var show = mxUtils.bind(this, function()
			{
				this.createTooltip(elt, cells, w, h, title, showLabel, off);
			});

			if (this.tooltip != null && this.tooltip.style.display != 'none')
			{
				show();
			}
			else
			{
				this.thread = window.setTimeout(show, this.tooltipDelay);
			}

			this.currentElt = elt;
		}
	}
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.hideTooltip = function()
{
	if (this.thread != null)
	{
		window.clearTimeout(this.thread);
		this.thread = null;
	}
	
	if (this.tooltip != null)
	{
		this.tooltip.style.display = 'none';
		this.currentElt = null;
	}
	
	this.tooltipMouseDown = null;
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.addDataEntry = function(tags, width, height, title, data)
{
	if (tags == null)
	{
		tags = '';
	}

	if (title != null)
	{
		tags += ' ' + title;
	}

	return this.addEntry(tags, mxUtils.bind(this, function()
	{
	   	return this.createVertexTemplateFromData(data, width, height, title);
	}));
};

/**
 * Adds the give entries to the search index.
 */
Sidebar.prototype.addEntries = function(images, defaultTags)
{
	for (var i = 0; i < images.length; i++)
	{
		(mxUtils.bind(this, function(img)
		{
			var data = img.data;
			var tags = (img.title != null) ? img.title : '';
			
			if (img.tags != null)
			{
				tags += ' ' + img.tags;
			}

			if (defaultTags != null)
			{
				tags += ' ' + defaultTags;
			}

			if (data != null && tags.length > 0)
			{
				this.addEntry(tags, mxUtils.bind(this, function()
				{
					data = this.editorUi.convertDataUri(data);
					var s = 'shape=image;verticalLabelPosition=bottom;verticalAlign=top;imageAspect=0;';
					
					if (img.aspect == 'fixed')
					{
						s += 'aspect=fixed;'
					}
					
					return this.createVertexTemplate(s + 'image=' +
						data, img.w, img.h, '', img.title || '', false, false, true)
				}));
			}
			else if (img.xml != null && tags.length > 0)
			{
				this.addEntry(tags, mxUtils.bind(this, function()
				{
					var cells = this.editorUi.stringToCells((img.xml.charAt(0) == '<') ?
						img.xml : Graph.decompress(img.xml));

					return this.createVertexTemplateFromCells(
						cells, img.w, img.h, img.title || '', true, false, true);
				}));
			}
		}))(images[i]);
	}
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.setCurrentSearchEntryLibrary = function(id, lib)
{
	this.currentSearchEntryLibrary = (id != null) ? {id: id, lib: lib} : null;
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.getKeyStyle = function(style)
{
	var newStyle = [];
	
	if (typeof style === 'string')
	{
		var tokens = style.split(';');

		for (var i = 0; i < tokens.length; i++)
		{
			var tmp = tokens[i].split('=');

			if (tmp.length > 1 && mxUtils.indexOf(this.ignoredStyles, tmp[0]) < 0)
			{
				newStyle.push(tmp[0] + '=' + tmp[1]);
			}
		}
	}

	return newStyle.join(';');
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.addLibForStyle = function(style, lib)
{
	if (style != '')
	{
		if (this.styleToLibs == null)
		{
			this.styleToLibs = {};
		}

		if (this.styleToLibs[style] == null)
		{
			this.styleToLibs[style] = [];
		}

		this.styleToLibs[style].push(lib);
	}
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.getLibsForStyle = function(style)
{
	return (this.styleToLibs != null) ? this.styleToLibs[style] : null;
};

/**
 * Returns the name of the shape of the given style for finding it in the
 * palettes (see getShapeMatches): the value of shape or the named style at
 * the start, eg. ellipse, and for images the image, which is the shape, or
 * an empty string for the default shape.
 */
Sidebar.prototype.getShapeName = function(style)
{
	var tokens = (typeof style === 'string') ? style.split(';') : [];
	var name = (tokens[0] != null && tokens[0].indexOf('=') < 0) ? tokens[0] : '';
	var image = null;

	for (var i = 0; i < tokens.length; i++)
	{
		var index = tokens[i].indexOf('=');

		if (index > 0)
		{
			var key = tokens[i].substring(0, index);

			if (key == mxConstants.STYLE_SHAPE)
			{
				name = tokens[i].substring(index + 1);
			}
			else if (key == mxConstants.STYLE_IMAGE)
			{
				image = tokens[i].substring(index + 1);
			}
		}
	}

	return (name == mxConstants.SHAPE_IMAGE && image != null) ? name + '\n' + image : name;
};

/**
 * Adds the given library to the shapes with the given name and key (see
 * getShapeName and getKeyStyle) for finding shapes in their palettes (see
 * getShapeMatches). The default shape is only added with a key.
 */
Sidebar.prototype.addShapeForStyle = function(name, key, lib)
{
	if (name.length > 0 || key.length > 0)
	{
		if (this.shapeKeys == null)
		{
			this.shapeKeys = Object.create(null);
		}

		if (this.shapeKeys[name] == null)
		{
			this.shapeKeys[name] = Object.create(null);
		}

		if (this.shapeKeys[name][key] == null)
		{
			this.shapeKeys[name][key] = [];
		}

		this.shapeKeys[name][key].push(lib);
		this.shapeMatches = null;

		if (this.shapeIndexes != null)
		{
			delete this.shapeIndexes[name];
		}
	}
};

/**
 * Maximum number of styles whose matches are kept (see getShapeMatches).
 * Default is 10000.
 */
Sidebar.prototype.maxShapeMatches = 10000;

/**
 * Maximum number of keys of a shape that are visited for the values of a
 * style and of keys with the fewest values that are compared (see
 * getClosestKeys). The built-in palettes have at most a few hundred keys for
 * a shape, crafted libraries can have many more. Default is 1000.
 */
Sidebar.prototype.maxClosestKeys = 1000;

/**
 * Maximum number of values that are counted for a style when keys are
 * compared, the shorter of the values of each key and of the style (see
 * getClosestKeys). Keys whose comparison does not fit are skipped. Default is
 * 10000.
 */
Sidebar.prototype.maxClosestKeyValues = 10000;

/**
 * Returns the shapes of the palettes with the shape of the given style (see
 * getShapeName) whose keys (see getKeyStyle) are closest to the key of the
 * style (see getClosestKeys), the first shape of each library, as an array
 * of objects with the name, the key and the library of each shape, or null
 * if no palette has the shape. A shape is found in its palette if it was
 * changed after it was inserted, eg. rotated or with another perimeter,
 * except for the default shape, eg. rectangles, which are found with the
 * same key only. The result is kept for each style until shapes are added to
 * the libraries, in two generations of at most maxShapeMatches styles: a
 * full generation becomes the old one, whose styles move to the new one when
 * they are used again, so that the styles of a large selection stay kept and
 * the styles of later files are kept too.
 */
Sidebar.prototype.getShapeMatches = function(style)
{
	if (this.shapeMatches == null)
	{
		this.shapeMatches = Object.create(null);
		this.oldShapeMatches = null;
		this.shapeMatchCount = 0;
	}

	var result = (typeof style === 'string') ? this.shapeMatches[style] : null;

	if (result === undefined && this.oldShapeMatches != null)
	{
		result = this.oldShapeMatches[style];

		if (result !== undefined)
		{
			this.addShapeMatch(style, result);
		}
	}

	if (result === undefined)
	{
		var name = this.getShapeName(style);
		var keys = (this.shapeKeys != null) ? this.shapeKeys[name] : null;
		result = null;

		if (keys != null)
		{
			var key = this.getKeyStyle(style);
			var best = (keys[key] != null) ? [key] : [];

			// Closest keys if the shape was changed, except for the default
			// shape, which is found with the same key only
			if (best.length == 0 && name.length > 0)
			{
				best = this.getClosestKeys(name, key);
			}

			if (best.length > 0)
			{
				var seen = Object.create(null);
				result = [];

				for (var i = 0; i < best.length; i++)
				{
					for (var j = 0; j < keys[best[i]].length; j++)
					{
						var lib = keys[best[i]][j];

						if (seen[lib.id] == null)
						{
							seen[lib.id] = true;
							result.push({name: name, key: best[i], lib: lib});
						}
					}
				}
			}
		}

		this.addShapeMatch(style, result);
	}

	return result;
};

/**
 * Keeps the given matches of the given style (see getShapeMatches).
 */
Sidebar.prototype.addShapeMatch = function(style, result)
{
	if (this.shapeMatchCount >= this.maxShapeMatches)
	{
		this.oldShapeMatches = this.shapeMatches;
		this.shapeMatches = Object.create(null);
		this.shapeMatchCount = 0;
	}

	this.shapeMatches[style] = result;
	this.shapeMatchCount++;
};

/**
 * Returns the values of the given key of a style (see getKeyStyle) without
 * the shape, which is part of the name of the shape (see getShapeName).
 */
Sidebar.prototype.getKeyValues = function(key)
{
	var tokens = key.split(';');
	var result = [];

	for (var i = 0; i < tokens.length; i++)
	{
		if (tokens[i].length > 0 && tokens[i].substring(0, 6) != 'shape=')
		{
			result.push(tokens[i]);
		}
	}

	return result;
};

/**
 * Returns the keys of the shapes with the given name (see addShapeForStyle)
 * that have the fewest values that are not in both keys with the given key
 * (see getKeyValues), in the order in which they were added. Only the keys
 * that share values with the given key and the keys with the fewest values
 * are compared (see getShapeIndex), with the values they share counted from
 * their own values. maxClosestKeys and maxClosestKeyValues limit the keys
 * that are visited and the values that are counted, so that the time for a
 * style does not grow with the size of a library or the number of values.
 */
Sidebar.prototype.getClosestKeys = function(name, key)
{
	var index = this.getShapeIndex(name);
	var values = this.getKeyValues(key);
	var given = Object.create(null);
	var seen = Object.create(null);
	var keys = [];

	for (var i = 0; i < values.length; i++)
	{
		given[values[i]] = (given[values[i]] || 0) + 1;
	}

	// Keys that share values with the given key, rare values first, as they
	// tell the closest keys apart
	var rare = values.slice();

	rare.sort(function(a, b)
	{
		return ((index.keys[a] != null) ? index.keys[a].length : 0) -
			((index.keys[b] != null) ? index.keys[b].length : 0);
	});

	for (var i = 0, visits = 0; i < rare.length && visits < this.maxClosestKeys; i++)
	{
		var temp = index.keys[rare[i]];

		for (var j = 0; temp != null && j < temp.length && visits < this.maxClosestKeys; j++, visits++)
		{
			if (seen[temp[j]] == null)
			{
				seen[temp[j]] = true;
				keys.push(temp[j]);
			}
		}
	}

	for (var i = 0; i < index.smallest.length; i++)
	{
		if (seen[index.smallest[i]] == null)
		{
			seen[index.smallest[i]] = true;
			keys.push(index.smallest[i]);
		}
	}

	var result = [];
	var min = null;

	var distinct = Object.keys(given);

	for (var i = 0, counted = 0; i < keys.length && counted < this.maxClosestKeyValues; i++)
	{
		var temp = index.values[keys[i]];
		var cost = Math.min(temp.length, distinct.length);

		// Skips keys whose comparison does not fit into the remaining values
		if (counted + cost > this.maxClosestKeyValues)
		{
			continue;
		}

		// Counts the shared values from the shorter list
		var shared = 0;

		if (temp.length <= distinct.length)
		{
			for (var j = 0; j < temp.length; j++)
			{
				shared += given[temp[j]] || 0;
			}
		}
		else
		{
			var counts = this.getKeyValueCounts(index, keys[i]);

			for (var j = 0; j < distinct.length; j++)
			{
				shared += given[distinct[j]] * (counts[distinct[j]] || 0);
			}
		}

		counted += cost;
		var dist = values.length + temp.length - 2 * shared;

		if (min == null || dist < min)
		{
			min = dist;
			result = [keys[i]];
		}
		else if (dist == min)
		{
			result.push(keys[i]);
		}
	}

	result.sort(function(a, b)
	{
		return mxUtils.compareNumbers(index.order[a], index.order[b]);
	});

	return result;
};

/**
 * Returns the number of times each value occurs in the given key of the given
 * index (see getShapeIndex), created when it is first used and kept with the
 * index (see getClosestKeys).
 */
Sidebar.prototype.getKeyValueCounts = function(index, key)
{
	if (index.counts == null)
	{
		index.counts = Object.create(null);
	}

	var counts = index.counts[key];

	if (counts == null)
	{
		var values = index.values[key];
		counts = Object.create(null);

		for (var i = 0; i < values.length; i++)
		{
			counts[values[i]] = (counts[values[i]] || 0) + 1;
		}

		index.counts[key] = counts;
	}

	return counts;
};

/**
 * Returns the index of the keys of the shapes with the given name (see
 * addShapeForStyle) for finding the closest keys (see getClosestKeys): the
 * keys for each value, the values and the order of each key, and the first
 * maxClosestKeys keys with the fewest values. The index is created when a
 * shape with the name is first compared and kept until shapes with the name
 * are added.
 */
Sidebar.prototype.getShapeIndex = function(name)
{
	if (this.shapeIndexes == null)
	{
		this.shapeIndexes = Object.create(null);
	}

	var index = this.shapeIndexes[name];

	if (index == null)
	{
		index = {keys: Object.create(null), values: Object.create(null),
			order: Object.create(null), smallest: []};
		var min = null;
		var count = 0;

		for (var key in this.shapeKeys[name])
		{
			var values = this.getKeyValues(key);
			index.values[key] = values;
			index.order[key] = count++;

			for (var i = 0; i < values.length; i++)
			{
				if (index.keys[values[i]] == null)
				{
					index.keys[values[i]] = [];
				}

				index.keys[values[i]].push(key);
			}

			if (min == null || values.length < min)
			{
				min = values.length;
				index.smallest = [key];
			}
			else if (values.length == min && index.smallest.length < this.maxClosestKeys)
			{
				index.smallest.push(key);
			}
		}

		this.shapeIndexes[name] = index;
	}

	return index;
};

/**
 * Specifies the maximum time in ms for each slice of the deferred update
 * of the style to libraries map. Default is 8.
 */
Sidebar.prototype.styleToLibsSliceTime = 8;

/**
 * Returns true if all entries were added to the style to libraries map.
 */
Sidebar.prototype.isStyleToLibsLoaded = function()
{
	return this.pendingLibEntries == null;
};

/**
 * Queues the given entry function for the style to libraries map. The
 * styles are collected by running the function, which builds the cells
 * for all shapes in all libraries, so this is done in idle time after
 * startup (see updateStyleToLibs).
 */
Sidebar.prototype.addLibEntry = function(fn, lib)
{
	if (this.pendingLibEntries == null)
	{
		this.pendingLibEntries = [];
		this.pendingLibIndex = 0;
	}

	this.pendingLibEntries.push({fn: fn, lib: lib});
	this.scheduleStyleToLibsUpdate();

	// Entry functions of each palette (see getPaletteCells)
	var id = this.getPaletteIdForLibrary(lib);

	if (this.paletteEntries == null)
	{
		this.paletteEntries = Object.create(null);
	}

	if (this.paletteEntries[id] == null)
	{
		this.paletteEntries[id] = [];
	}

	this.paletteEntries[id].push(fn);

	if (this.paletteShapes != null)
	{
		delete this.paletteShapes[id];
	}

	// Palettes of each library (see getPickerShapes)
	if (this.libraryPalettes == null)
	{
		this.libraryPalettes = Object.create(null);
	}

	if (this.libraryPalettes[lib.id] == null)
	{
		this.libraryPalettes[lib.id] = Object.create(null);
	}

	this.libraryPalettes[lib.id][id] = true;
};

/**
 * Returns the ID of the palette of the given library of the style to
 * libraries map (see getLibsForStyle).
 */
Sidebar.prototype.getPaletteIdForLibrary = function(lib)
{
	return (lib.lib != null) ? lib.lib : lib.id;
};

/**
 * Returns the cells of the entries of the palette with the given ID (see
 * getPaletteIdForLibrary) as objects with the cells, the width, the height
 * and the title of each entry, without creating the templates (see
 * updateStyleToLibs). Edges are ignored.
 */
Sidebar.prototype.getPaletteCells = function(id)
{
	var fns = (this.paletteEntries != null) ? this.paletteEntries[id] : null;
	var result = [];

	if (fns != null)
	{
		var createVertexTemplateFromCells = this.createVertexTemplateFromCells;
		var createEdgeTemplateFromCells = this.createEdgeTemplateFromCells;

		this.createVertexTemplateFromCells = function(cells, width, height, title)
		{
			if (cells != null)
			{
				result.push({cells: cells, width: width, height: height, title: title});
			}
		};

		this.createEdgeTemplateFromCells = function()
		{
			// ignore
		};

		try
		{
			for (var i = 0; i < fns.length; i++)
			{
				try
				{
					fns[i]();
				}
				catch (e)
				{
					// ignore
				}
			}
		}
		finally
		{
			this.createVertexTemplateFromCells = createVertexTemplateFromCells;
			this.createEdgeTemplateFromCells = createEdgeTemplateFromCells;
		}
	}

	return result;
};

/**
 * Returns the entries of the palette with the given ID that are a single
 * vertex, which may have children, in the order of the palette (see
 * getPaletteCells). Each entry has the cell, the name of its shape and the
 * key of its style (see getShapeName and getKeyStyle) and the title, and is
 * listed once for each shape and title as refresh adds the palettes again.
 * The entries are kept until entries are added to the palette, so their
 * cells must not be changed.
 */
Sidebar.prototype.getPaletteShapes = function(id)
{
	if (this.paletteShapes == null)
	{
		this.paletteShapes = Object.create(null);
	}

	var result = this.paletteShapes[id];

	if (result == null)
	{
		var items = this.getPaletteCells(id);
		var seen = Object.create(null);
		result = [];

		for (var i = 0; i < items.length; i++)
		{
			var cell = (items[i].cells.length == 1) ? items[i].cells[0] : null;

			if (cell != null && this.graph.model.isVertex(cell) && typeof cell.style === 'string')
			{
				var name = this.getShapeName(cell.style);
				var key = this.getKeyStyle(cell.style);
				var title = items[i].title || '';

				if (seen[name + '\n' + key + '\n' + title] == null)
				{
					seen[name + '\n' + key + '\n' + title] = true;
					result.push({cell: cell, name: name, key: key, title: title});
				}
			}
		}

		this.paletteShapes[id] = result;
	}

	return result;
};

/**
 * Returns the entry of the palette shapes (see getPaletteShapes) of the
 * closest shape of the given style (see getShapeMatches) in a library that
 * the given function accepts, or null.
 */
Sidebar.prototype.getPaletteShape = function(style, accept)
{
	var matches = this.getShapeMatches(style);
	var result = null;

	for (var i = 0; matches != null && i < matches.length && result == null; i++)
	{
		if (accept == null || accept(matches[i].lib))
		{
			result = this.getShapeEntry(matches[i].lib, matches[i].name, matches[i].key);
		}
	}

	return result;
};

/**
 * Returns the entry of the palette shapes (see getPaletteShapes) of the given
 * library of the style to libraries map with the given name and key or null.
 */
Sidebar.prototype.getShapeEntry = function(lib, name, key)
{
	var shapes = this.getPaletteShapes(this.getPaletteIdForLibrary(lib));
	var result = null;

	for (var i = 0; i < shapes.length && result == null; i++)
	{
		if (shapes[i].name == name && shapes[i].key == key)
		{
			result = shapes[i];
		}
	}

	return result;
};

/**
 * Returns the entry of the palette shapes (see getPaletteShapes) with the
 * given name and key in the palettes of the library with the given ID or
 * null.
 */
Sidebar.prototype.getLibraryShape = function(id, name, key)
{
	var keys = (this.shapeKeys != null && typeof name === 'string') ? this.shapeKeys[name] : null;
	var libs = (keys != null && typeof key === 'string') ? keys[key] : null;
	var result = null;

	for (var i = 0; libs != null && i < libs.length && result == null; i++)
	{
		if (libs[i].id == id)
		{
			result = this.getShapeEntry(libs[i], name, key);
		}
	}

	return result;
};

/**
 * Returns true if the library with the given ID has the basic shapes of the
 * shape picker (see EditorUi.getCellsForShapePicker), ie. the General, Misc
 * and Advanced palettes.
 */
Sidebar.prototype.isBasicLibrary = function(id)
{
	return id == 'general';
};

/**
 * Maximum number of recent shapes of each library (see addRecentShapes).
 * Default is 15.
 */
Sidebar.prototype.maxRecentShapes = 15;

/**
 * Maximum number of libraries with recent shapes (see addRecentShapes).
 * Default is 10.
 */
Sidebar.prototype.maxRecentLibraries = 10;

/**
 * Maximum length of the name and key of a recent shape (see addRecentShapes),
 * eg. images with data URIs are not recent shapes. Default is 300.
 */
Sidebar.prototype.maxRecentShapeLength = 300;

/**
 * Adds the shapes of palettes of the given cells that were inserted from the
 * sidebar, the shape picker or the inline toolbar to the recent shapes of
 * their libraries other than the basic library (see getShapeMatches and
 * isBasicLibrary). The recent shapes are an array of objects with the ID of
 * a library and its shapes as arrays of the name and the key, the most recent
 * first. Fires recentShapesChanged on the UI if shapes were added, so that
 * they can be stored, and returns true if shapes were added.
 */
Sidebar.prototype.addRecentShapes = function(cells)
{
	var model = this.editorUi.editor.graph.model;
	var changed = false;

	for (var i = 0; i < cells.length; i++)
	{
		var matches = (model.isVertex(cells[i])) ? this.getShapeMatches(model.getStyle(cells[i])) : null;
		var seen = Object.create(null);

		for (var j = 0; matches != null && j < matches.length; j++)
		{
			var id = matches[j].lib.id;

			if (seen[id] == null && !this.isBasicLibrary(id) && matches[j].name.length +
				matches[j].key.length <= this.maxRecentShapeLength)
			{
				seen[id] = true;
				this.addRecentShape(id, matches[j].name, matches[j].key);
				changed = true;
			}
		}
	}

	if (changed)
	{
		this.editorUi.fireEvent(new mxEventObject('recentShapesChanged'));
	}

	return changed;
};

/**
 * Adds the shape with the given name and key to the recent shapes of the
 * library with the given ID (see addRecentShapes).
 */
Sidebar.prototype.addRecentShape = function(id, name, key)
{
	var lib = {id: id, shapes: []};

	for (var i = 0; i < this.recentShapes.length; i++)
	{
		if (this.recentShapes[i] != null && this.recentShapes[i].id == id)
		{
			lib = this.recentShapes.splice(i, 1)[0];
			break;
		}
	}

	var shapes = [[name, key]];

	for (var i = 0; Array.isArray(lib.shapes) && i < lib.shapes.length &&
		shapes.length < this.maxRecentShapes; i++)
	{
		if (Array.isArray(lib.shapes[i]) && (lib.shapes[i][0] != name || lib.shapes[i][1] != key))
		{
			shapes.push(lib.shapes[i]);
		}
	}

	lib.shapes = shapes;
	this.recentShapes.unshift(lib);

	if (this.recentShapes.length > this.maxRecentLibraries)
	{
		this.recentShapes.length = this.maxRecentLibraries;
	}
};

/**
 * Returns the entries of the recent shapes of the library with the given ID
 * (see addRecentShapes and getLibraryShape), the most recent first.
 */
Sidebar.prototype.getRecentShapes = function(id)
{
	var result = [];

	for (var i = 0; i < this.recentShapes.length; i++)
	{
		var lib = this.recentShapes[i];

		if (lib != null && lib.id == id && Array.isArray(lib.shapes))
		{
			for (var j = 0; j < lib.shapes.length; j++)
			{
				var entry = (Array.isArray(lib.shapes[j])) ? this.getLibraryShape(
					id, lib.shapes[j][0], lib.shapes[j][1]) : null;

				if (entry != null)
				{
					result.push(entry);
				}
			}
		}
	}

	return result;
};

/**
 * Sets the titles of the shapes of the library with the given ID (see
 * setCurrentSearchEntryLibrary) for the shape picker, in the order of the
 * shape picker (see getPickerShapes). A title that is given n times stands
 * for the first n shapes with that title in the palettes of the library.
 */
Sidebar.prototype.setPickerShapes = function(id, titles)
{
	if (this.pickerShapes == null)
	{
		this.pickerShapes = Object.create(null);
	}

	this.pickerShapes[id] = titles;
};

/**
 * Returns the entries of the shapes for the shape picker of the given library
 * of the style to libraries map (see getPaletteShapes): the shapes with the
 * titles of the library in the palettes of the library (see setPickerShapes)
 * or, if there are no titles, the shapes of the palette of the library after
 * the given entry, first the shapes of the same kind, eg. images or the
 * resource icons of AWS, and then the others (see getShapeName).
 */
Sidebar.prototype.getPickerShapes = function(lib, entry)
{
	var titles = (this.pickerShapes != null) ? this.pickerShapes[lib.id] : null;
	var result = [];

	if (titles != null)
	{
		var byTitle = Object.create(null);
		var count = Object.create(null);

		for (var id in this.libraryPalettes[lib.id])
		{
			var shapes = this.getPaletteShapes(id);

			for (var i = 0; i < shapes.length; i++)
			{
				if (byTitle[shapes[i].title] == null)
				{
					byTitle[shapes[i].title] = [];
				}

				byTitle[shapes[i].title].push(shapes[i]);
			}
		}

		for (var i = 0; i < titles.length; i++)
		{
			var list = byTitle[titles[i]];
			var n = count[titles[i]] || 0;
			count[titles[i]] = n + 1;

			if (list != null && n < list.length)
			{
				result.push(list[n]);
			}
		}
	}
	else
	{
		var shapes = this.getPaletteShapes(this.getPaletteIdForLibrary(lib));
		var start = mxUtils.indexOf(shapes, entry) + 1;
		var others = [];

		// Images are one kind of shape
		var getKind = function(name)
		{
			var index = name.indexOf('\n');

			return (index >= 0) ? name.substring(0, index) : name;
		};

		var kind = (entry != null) ? getKind(entry.name) : null;

		for (var i = 0; i < shapes.length; i++)
		{
			var shape = shapes[(start + i) % shapes.length];

			if (getKind(shape.name) == kind)
			{
				result.push(shape);
			}
			else
			{
				others.push(shape);
			}
		}

		result = result.concat(others);
	}

	return result;
};

/**
 * Returns the title of the palette with the given ID.
 */
Sidebar.prototype.getPaletteTitle = function(id)
{
	var elts = this.palettes[id];

	return (elts != null && elts[0] != null) ? mxUtils.trim(elts[0].textContent) : id;
};

/**
 * Schedules the next slice of the update of the style to libraries map.
 */
Sidebar.prototype.scheduleStyleToLibsUpdate = function()
{
	if (!this.styleToLibsScheduled)
	{
		this.styleToLibsScheduled = true;

		var update = mxUtils.bind(this, function(deadline)
		{
			this.styleToLibsScheduled = false;
			var t0 = Date.now();

			this.updateStyleToLibs(mxUtils.bind(this, function()
			{
				return Date.now() - t0 < this.styleToLibsSliceTime &&
					(deadline == null || deadline.timeRemaining() > 0);
			}));

			if (!this.isStyleToLibsLoaded())
			{
				this.scheduleStyleToLibsUpdate();
			}
		});

		if (typeof window.requestIdleCallback === 'function')
		{
			window.requestIdleCallback(update);
		}
		else
		{
			window.setTimeout(update, 0);
		}
	}
};

/**
 * Adds the cell styles of the queued entries to the style to libraries
 * map. If hasTime is given then entries are added until it returns false,
 * with at least one entry per call. Otherwise all entries are added.
 */
Sidebar.prototype.updateStyleToLibs = function(hasTime)
{
	var entries = this.pendingLibEntries;

	if (entries != null)
	{
		var self = this;
		var lib = null;
		var createVertexTemplateFromCells = this.createVertexTemplateFromCells;

		// Collects the styles of the cells instead of creating the template
		this.createVertexTemplateFromCells = function(cells, width, height, title, allowCellsInserted)
		{
			if (cells != null)
			{
				for (var i = 0; i < cells.length; i++)
				{
					var key = self.getKeyStyle(cells[i].style);
					self.addLibForStyle(key, lib);
					self.addShapeForStyle(self.getShapeName(cells[i].style), key, lib);
				}
			}
		};

		try
		{
			while (this.pendingLibIndex < entries.length)
			{
				var entry = entries[this.pendingLibIndex++];
				lib = entry.lib;

				try
				{
					entry.fn();
				}
				catch (e)
				{
					// ignore
				}

				if (hasTime != null && !hasTime())
				{
					break;
				}
			}
		}
		finally
		{
			this.createVertexTemplateFromCells = createVertexTemplateFromCells;
		}

		if (this.pendingLibIndex >= entries.length)
		{
			this.pendingLibEntries = null;
			this.pendingLibIndex = 0;
		}
	}
};

/**
 * Hides the current tooltip.
 */
Sidebar.prototype.addEntry = function(tags, fn)
{
	// Collects shape names for reverse lookup
	if (this.currentSearchEntryLibrary != null)
	{
		this.addLibEntry(fn, this.currentSearchEntryLibrary);
	}

	if (this.taglist != null && typeof tags === 'string' && tags.length > 0)
	{
		if (this.currentSearchEntryLibrary != null)
		{
			fn.parentLibraries = [this.currentSearchEntryLibrary];
		}

		// Replaces special characters
		var tmp = tags.toLowerCase().replace(/[\/\,\(\)]/g, ' ').split(' ');

		for (var i = 0; i < tmp.length; i++)
		{
			this.addEntryForTag(tmp[i], fn);

			// Adds additional entry with removed trailing numbers
			var normalized = this.getNormalizedTag(tmp[i]);

			if (normalized != tmp[i])
			{
				this.addEntryForTag(normalized, fn);
			}
		}
	}

	return fn;
};

/**
 * Returns the soundex of the given tag without trailing numbers. The
 * results are cached since most tags are used by many entries.
 */
Sidebar.prototype.getNormalizedTag = function(tag)
{
	if (this.normalizedTags == null)
	{
		// Null prototype as tags may come from custom libraries
		this.normalizedTags = Object.create(null);
	}

	var normalized = this.normalizedTags[tag];

	if (normalized == null)
	{
		normalized = Editor.soundex(tag.replace(/\.*\d*$/, ''));
		this.normalizedTags[tag] = normalized;
	}

	return normalized;
};

/**
 * Adds the given entry function for the given tag. Repeated tags of an
 * entry add the function only once as it is then the last entry.
 */
Sidebar.prototype.addEntryForTag = function(tag, fn)
{
	if (tag != null && tag.length > 1)
	{
		var entry = this.taglist[tag];

		if (typeof entry !== 'object')
		{
			entry = {entries: []};
			this.taglist[tag] = entry;
		}

		if (entry.entries[entry.entries.length - 1] !== fn)
		{
			entry.entries.push(fn);
		}
	}
};
/**
 * Returns true if the entry should be ignored in search results.
 */
Sidebar.prototype.isEntryIgnored = function(entry, searchClosedLibraries)
{
	var ignored = !searchClosedLibraries;

	if (entry.parentLibraries != null && ignored)
	{
		for (var j = 0; j < entry.parentLibraries.length; j++)
		{
			if (this.isEntryVisible(entry.parentLibraries[j].id))
			{
				ignored = false;

				break;
			}
		}
	}

	return ignored;
};

/**
 * Returns the search ranking weight for the given entry, ie. the
 * highest librarySearchWeights value of its parent libraries.
 * Returns 0 for entries without a weighted parent library.
 */
Sidebar.prototype.getEntrySearchWeight = function(entry)
{
	var weight = 0;

	if (this.librarySearchWeights != null && entry.parentLibraries != null)
	{
		for (var i = 0; i < entry.parentLibraries.length; i++)
		{
			var temp = this.librarySearchWeights[entry.parentLibraries[i].id];
			temp = (typeof temp === 'number') ? temp : 0;
			weight = (i == 0) ? temp : Math.max(weight, temp);
		}
	}

	return weight;
};

/**
 * Splits a token on camelCase and letter-digit boundaries.
 * e.g. "pid2misc" → ["pid", "misc"], "discInst" → ["disc", "inst"]
 */
Sidebar.prototype.splitCompoundToken = function(token)
{
	var parts = token.replace(/([a-z])([A-Z])/g, '$1 $2')
		.replace(/([a-zA-Z])(\d)/g, '$1 $2')
		.replace(/(\d)([a-zA-Z])/g, '$1 $2')
		.toLowerCase().split(/\s+/);

	return parts.filter(function(p) { return p.length >= 2; });
};

/**
 * Returns true if the character before index in key is a word boundary,
 * ie. the start of the key, a non-alphanumeric character (eg. "-") or
 * a letter-digit transition.
 */
Sidebar.prototype.isTagMatchBoundary = function(key, index)
{
	if (index == 0)
	{
		return true;
	}

	var prev = key.charCodeAt(index - 1);
	var curr = key.charCodeAt(index);
	var prevDigit = prev >= 48 && prev <= 57;
	var currDigit = curr >= 48 && curr <= 57;

	// Non-alphanumeric characters are boundaries
	if (!prevDigit && !(prev >= 97 && prev <= 122))
	{
		return true;
	}

	return prevDigit != currDigit;
};

/**
 * Collects entries for tags that contain the given term, eg. "7050"
 * matches the tag "dcs-7050qx-32" of a shape imported from a VSSX
 * library. Matches at word boundaries within a tag are added to
 * prefix, matches elsewhere to substring. Entries in seen are ignored
 * and matched entries are added to seen.
 */
Sidebar.prototype.matchPartialEntries = function(term, seen, prefix, substring)
{
	// Requires longer terms for matches inside words to avoid noise
	var minInnerLength = 4;

	if (term.length >= 2)
	{
		for (var key in this.taglist)
		{
			var c = key.charCodeAt(0);

			// Ignores Soundex keys (upper case first letter) and exact matches
			if ((c >= 65 && c <= 90) || key === term)
			{
				continue;
			}

			var idx = key.indexOf(term);

			if (idx >= 0)
			{
				var entry = this.taglist[key];

				if (typeof entry === 'object' && entry.entries != null)
				{
					// Checks if any occurrence starts at a word boundary
					var boundary = false;
					var j = idx;

					while (j >= 0 && !boundary)
					{
						boundary = this.isTagMatchBoundary(key, j);
						j = (boundary) ? j : key.indexOf(term, j + 1);
					}

					if (boundary || term.length >= minInnerLength)
					{
						var target = (boundary) ? prefix : substring;
						var arr = entry.entries;

						for (var k = 0; k < arr.length; k++)
						{
							if (seen.get(arr[k]) == null)
							{
								seen.put(arr[k], true);
								target.push(arr[k]);
							}
						}
					}
				}
			}
		}
	}
};

/**
 * Collects entries matching a single term (exact, partial and Soundex).
 * Returns { exact: [entries], prefix: [entries], substring: [entries],
 * phonetic: [entries] }.
 */
Sidebar.prototype.matchTermEntries = function(term, reverseMap)
{
	var exact = [];
	var prefix = [];
	var substring = [];
	var phonetic = [];
	var english = null;

	var found = this.taglist[term];

	if (found != null)
	{
		exact = found.entries.slice();
	}

	// Checks English translation for localized search terms
	if (reverseMap != null)
	{
		english = reverseMap[term];

		if (english != null && english !== term)
		{
			found = this.taglist[english];

			if (found != null)
			{
				for (var i = 0; i < found.entries.length; i++)
				{
					if (mxUtils.indexOf(exact, found.entries[i]) < 0)
					{
						exact.push(found.entries[i]);
					}
				}
			}
		}
		else
		{
			english = null;
		}
	}

	// Adds partial matches on tags, eg. for searching parts of shape
	// names in imported libraries where the whole name is one tag
	var seen = new mxDictionary();

	for (var i = 0; i < exact.length; i++)
	{
		seen.put(exact[i], true);
	}

	this.matchPartialEntries(term, seen, prefix, substring);

	// Tags may differ from the resource key in inflection, eg. the
	// mockups resource key resolves to the singular mockup tag, so
	// partial and Soundex matching must also run on the translation
	if (english != null)
	{
		this.matchPartialEntries(english, seen, prefix, substring);
	}

	var normalized = Editor.soundex(term.replace(/\.*\d*$/, ''));

	if (normalized.length > 0 && normalized !== term)
	{
		found = this.taglist[normalized];

		if (found != null)
		{
			phonetic = found.entries.slice();
		}
	}

	// Soundex of the raw term cannot match for non-Latin scripts, so
	// localized terms rely on the Soundex of the translation
	if (english != null)
	{
		var englishNormalized = Editor.soundex(english.replace(/\.*\d*$/, ''));

		if (englishNormalized.length > 0 && englishNormalized !== english &&
			englishNormalized !== normalized)
		{
			found = this.taglist[englishNormalized];

			if (found != null)
			{
				for (var i = 0; i < found.entries.length; i++)
				{
					if (mxUtils.indexOf(phonetic, found.entries[i]) < 0)
					{
						phonetic.push(found.entries[i]);
					}
				}
			}
		}
	}

	return { exact: exact, prefix: prefix, substring: substring, phonetic: phonetic };
};

/**
 * Returns a reverse lookup map from localized resource values to
 * their resource keys (which are the English terms). Rebuilds
 * the map when the language changes.
 */
Sidebar.prototype.getResourceReverseMap = function()
{
	var lang = mxClient.language || 'en';

	if (this.resourceReverseMap == null || this.resourceReverseLang !== lang)
	{
		// Null prototype as the map is looked up with user-typed search terms
		this.resourceReverseMap = Object.create(null);
		this.resourceReverseLang = lang;

		if (lang !== 'en' && mxResources.resources != null)
		{
			for (var key in mxResources.resources)
			{
				var value = mxResources.resources[key];

				if (value != null && typeof value === 'string' && value !== key)
				{
					// Strips Unicode directional formatting characters that
					// wrap the values in the RTL resource files as they never
					// appear in typed search terms
					var lower = value.replace(/[\u200e\u200f\u202a-\u202e]/g, '').toLowerCase();

					if (lower.length > 0 && lower !== key && this.resourceReverseMap[lower] == null)
					{
						this.resourceReverseMap[lower] = key;
					}
				}
			}
		}
	}

	return this.resourceReverseMap;
};

/**
 * Adds shape search UI.
 */
Sidebar.prototype.searchEntries = function(searchTerms, count, page, success, error, searchClosedLibraries, imagesOnly)
{
	if (this.taglist != null && searchTerms != null)
	{
		// Improves search for fully qualified names of the form mxgraph.foo.bar
		if (searchTerms.substring(0, 8) == 'mxgraph.' && searchTerms.indexOf(' ') < 0 &&
			searchTerms.lastIndexOf('.') > 8)
		{
			searchTerms = searchTerms.substring(8).replace(/\./g, ' ');
		}

		// Normalize: split compound tokens like "pid2misc" → ["pid", "misc"]
		var rawTerms = searchTerms.toLowerCase().split(' ');
		var tmp = [];
		var seenTerms = Object.create(null);

		for (var i = 0; i < rawTerms.length; i++)
		{
			var subTokens = this.splitCompoundToken(rawTerms[i]);

			if (subTokens.length == 0 && rawTerms[i].length >= 2)
			{
				subTokens = [rawTerms[i]];
			}

			for (var j = 0; j < subTokens.length; j++)
			{
				if (!seenTerms[subTokens[j]])
				{
					seenTerms[subTokens[j]] = true;
					tmp.push(subTokens[j]);
				}
			}
		}

		// Builds reverse map for localized search term translation
		var reverseMap = this.getResourceReverseMap();

		// Translates multi-word localized names as a whole, eg. "balon kata"
		// (id) resolves to the callout tag while its single tokens do not.
		// Soundex covers translations that only match a tag phonetically,
		// eg. "miundo ya majaribio" (sw) resolves to the mockups resource
		// key while the tag is the singular mockup
		if (tmp.length > 1)
		{
			var english = reverseMap[searchTerms.toLowerCase().replace(/\s+/g, ' ').trim()];

			if (english != null && !seenTerms[english] &&
				(this.taglist[english] != null ||
				this.taglist[Editor.soundex(english.replace(/\.*\d*$/, ''))] != null))
			{
				seenTerms[english] = true;
				tmp.push(english);
			}
		}

		var max = (page + 1) * count;

		// Collect per-term match entries
		var termMatches = [];

		for (var i = 0; i < tmp.length; i++)
		{
			termMatches.push(this.matchTermEntries(tmp[i], reverseMap));
		}

		// Try strict AND to find the candidate set
		var dict = new mxDictionary();
		var andResults = null;
		var index = 0;
		var andFailed = false;

		for (var i = 0; i < termMatches.length; i++)
		{
			var arr = termMatches[i].exact.concat(termMatches[i].prefix,
				termMatches[i].substring, termMatches[i].phonetic);
			var tmpDict = new mxDictionary();

			if (arr.length > 0)
			{
				andResults = [];

				for (var j = 0; j < arr.length; j++)
				{
					var entry = arr[j];

					if (((index == 0) == (dict.get(entry) == null)) &&
						tmpDict.get(entry) == null)
					{
						tmpDict.put(entry, entry);
						andResults.push(entry);
					}
				}
			}
			else
			{
				andResults = [];
			}

			dict = tmpDict;
			index++;

			if (andResults.length == 0 && i < termMatches.length - 1)
			{
				andFailed = true;
				break;
			}
		}

		// Score candidates: +1.0 per exact match, +0.8 per match at a word
		// boundary in a tag, +0.6 per match inside a tag, +0.5 per
		// Soundex-only match. Each shape scores at most once per term
		// (using its best tier)
		var tierScores = [1.0, 0.8, 0.6, 0.5];
		var scores = new mxDictionary();
		var allEntries = new mxDictionary();
		var candidateFilter = null;

		// If AND succeeded, only score the AND results
		if (!andFailed && andResults != null && andResults.length > 0)
		{
			candidateFilter = new mxDictionary();

			for (var i = 0; i < andResults.length; i++)
			{
				candidateFilter.put(andResults[i], true);
			}
		}

		for (var i = 0; i < termMatches.length; i++)
		{
			var matchedForTerm = new mxDictionary();
			var tiers = [termMatches[i].exact, termMatches[i].prefix,
				termMatches[i].substring, termMatches[i].phonetic];

			for (var t = 0; t < tiers.length; t++)
			{
				for (var j = 0; j < tiers[t].length; j++)
				{
					var entry = tiers[t][j];

					if ((candidateFilter == null || candidateFilter.get(entry) != null) &&
						matchedForTerm.get(entry) == null)
					{
						var prev = scores.get(entry);

						matchedForTerm.put(entry, true);
						scores.put(entry, (prev || 0) + tierScores[t]);
						allEntries.put(entry, entry);
					}
				}
			}
		}

		// Collect and sort by score descending, using the library search
		// weights to break ties so that entries from superseded libraries
		// appear after equally scored entries from their replacements
		var candidates = [];

		allEntries.visit(mxUtils.bind(this, function(key, entry)
		{
			candidates.push({ entry: entry, score: scores.get(entry) || 0,
				weight: this.getEntrySearchWeight(entry) });
		}));

		candidates.sort(function(a, b)
		{
			return (b.score - a.score) || (b.weight - a.weight);
		});

		var results = [];

		for (var i = 0; i < candidates.length; i++)
		{
			if (!this.isEntryIgnored(candidates[i].entry, searchClosedLibraries))
			{
				results.push(candidates[i].entry);
			}
		}

		var len = results.length;
		var more = (page + 1) * count < len;
		success(results.slice(page * count, (page + 1) * count), len, more, tmp);
	}
	else
	{
		success([], null, null, tmp);
	}
};

/**
 * Adds shape search UI.
 */
Sidebar.prototype.filterTags = function(tags)
{
	if (tags != null)
	{
		var arr = tags.split(' ');
		var result = [];
		var hash = {};
		
		// Ignores tags with leading numbers, strips trailing numbers
		for (var i = 0; i < arr.length; i++)
		{
			// Removes duplicates
			if (hash[arr[i]] == null)
			{
				hash[arr[i]] = '1';
				result.push(arr[i]);
			}
		}
		
		return result.join(' ');
	}
	
	return null;
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.cloneCell = function(cell, value)
{
	var clone = cell.clone();
	
	if (value != null)
	{
		clone.value = value;
	}
	
	return clone;
};

/**
 * Adds shape search UI.
 */
Sidebar.prototype.showPopupMenuForEntry = function(elt, libs, evt)
{
	// Hook for subclassers
};

/**
 * Adds shape search UI.
 */
Sidebar.prototype.addSearchPalette = function(expand)
{
	var editorUi = this.editorUi;
	var graph = editorUi.editor.graph;
	var elt = document.createElement('div');
	elt.style.visibility = 'hidden';
	this.appendChild(elt);
		
	var div = document.createElement('div');
	div.className = 'geSidebar geSearchSidebar';

	if (!expand)
	{
		div.style.display = 'none';
	}
	
	var inner = document.createElement('div');
	inner.style.whiteSpace = 'nowrap';
	inner.style.textOverflow = 'clip';
	inner.style.cursor = 'default';

	var input = document.createElement('input');
	input.setAttribute('id', 'geOmniSearch');
	// Reuse the placeholder text as the hover tooltip so the "Type /
	// to search" hint is also discoverable while the input is focused
	// (placeholders disappear once the user starts typing) and so the
	// sidebar container's broader tooltip doesn't surface here.
	var omniHint = mxResources.get('typeSlashToSearch');
	input.setAttribute('placeholder', omniHint);
	input.setAttribute('title', omniHint);
	input.setAttribute('type', 'text');
	inner.appendChild(input);

	var cross = document.createElement('img');
	cross.setAttribute('src', Editor.magnifyImage);
	cross.setAttribute('title', mxResources.get('search'));
	cross.className = 'geAdaptiveAsset';

	// A control for the keyboard only while it resets the search
	Editor.initKeyboardButton(cross);
	cross.setAttribute('tabindex', '-1');

	var find;

	inner.appendChild(cross);
	div.appendChild(inner);

	var consumeEvent = false;

	mxEvent.addGestureListeners(input, mxUtils.bind(this, function(evt)
	{
		consumeEvent = false;

		if (!mxClient.IS_TOUCH && mxEvent.getSource(evt) == input &&
			document.activeElement != input)
		{
			input.focus();

			if (mxClient.IS_GC || mxClient.IS_FF)
			{
				input.select();
			}
			else
			{
				document.execCommand('selectAll', false, null);
			}

			consumeEvent = true;
		}
	}), mxUtils.bind(this, function(evt)
	{
		if (mxEvent.getSource(evt) == input &&
			consumeEvent)
		{
			mxEvent.consume(evt);
		}
	}), mxUtils.bind(this, function(evt)
	{
		if (consumeEvent)
		{
			mxEvent.consume(evt);
			consumeEvent = false;
		}
	}));

	var lastActions = [];

	var executeAction = mxUtils.bind(this, function(action, args)
	{
		editorUi.hideCurrentMenu();
		mxUtils.remove(action, lastActions);
		lastActions.unshift(action);

		if (lastActions.length > 5)
		{
			lastActions.pop();
		}

		action.funct.apply(this, args);
		input.value = null;
	});

	// Focuses the diagram unless the action moved the focus, eg. into a dialog
	function focusGraph()
	{
		var ae = document.activeElement;

		if (ae == null || ae == input || ae == document.body)
		{
			graph.container.focus();
		}
	};

	var hiddenActions = ['about', 'deleteAll', 'showBoundingBox',
		'createSidebarEntry', 'downloadDesktop', 'toggleGoogleFonts'];
	
	var findAction = mxUtils.bind(this, function(value)
	{
		var bestMatch = null;
		
		for (var key in editorUi.actions.actions)
		{
			var action = (hiddenActions.indexOf(key) < 0 &&
				key.substring(0, 4) != 'test') ?
				editorUi.actions.get(key) : null;
			
			if (action != null && action.isEnabled() &&
				action.visible)
			{
				if (key.toLowerCase() == value)
				{
					return action;
				}
				else
				{
					var tokens = value.toLowerCase().split(' ');
					var matchTokens = 0;

					for (var i = 0; i < tokens.length; i++)
					{
						if (tokens[i].length == 0)
						{
							matchTokens++;
						}
						else if ((key.toLowerCase().indexOf(tokens[i]) >= 0 ||
							action.getTitle().toLowerCase().
								indexOf(tokens[i]) >= 0))
						{
							matchTokens++;
						}
					}

					if (matchTokens == tokens.length &&
						(lastActions.indexOf(bestMatch) < 0 ||
						bestMatch != null && !bestMatch.isEnabled()))
					{
						bestMatch = action;
					}
				}
			}
		}

		return bestMatch;
	});

	var enterAction = null;
	var ctrlEnterAction = null;
	var selectedItem = null;

	function setEnterAction(item, fn)
	{
		enterAction = fn;
		var td = item.firstChild.nextSibling.nextSibling;
		var span = document.createElement('span');
		span.className = 'geMenuShortcut';
		span.innerHTML = 'Enter';
		td.appendChild(span);
	};

	var ctrlEnterSpan = null;

	function setCtrlEnterAction(item, fn)
	{
		ctrlEnterAction = fn;

		if (ctrlEnterSpan != null && ctrlEnterSpan.parentNode != null)
		{
			ctrlEnterSpan.parentNode.removeChild(ctrlEnterSpan);
		}

		var td = item.firstChild.nextSibling.nextSibling;
		ctrlEnterSpan = document.createElement('span');
		ctrlEnterSpan.className = 'geMenuShortcut';
		ctrlEnterSpan.innerHTML = (mxClient.IS_MAC) ? 'Cmd+Enter' : 'Ctrl+Enter';
		td.appendChild(ctrlEnterSpan);
	};

	// Consumes Shift keyup after Shift+Enter to prevent
	// addMenuHandler's keyup handler from reopening the dropdown
	var consumeNextShiftUp = false;

	mxEvent.addListener(input, 'keyup', function(evt)
	{
		if (consumeNextShiftUp && evt.keyCode == 16 /* Shift */)
		{
			consumeNextShiftUp = false;
			mxEvent.consume(evt);
		}
	});

	editorUi.addMenuHandler(input, mxUtils.bind(this, function(menu, parent)
	{
		selectedItem = null;

		// Wraps addItem to store action function on each menu item
		var origAddItem = menu.addItem;

		menu.addItem = function(title, image, funct, parent, iconCls, enabled, active, noHover)
		{
			var tr = origAddItem.apply(menu, arguments);
			tr._action = funct;
			tr._enabled = (enabled != false);
			return tr;
		};

		var lc = input.value.toLowerCase();
		enterAction = null;
		ctrlEnterAction = null;

		var item = menu.addItem(mxResources.get('searchShapes'), null, mxUtils.bind(this, function()
		{
			find(null, false);
		}), parent);

		setEnterAction(item, function()
		{
			find(null, false);
		});

		var openLibItem = menu.addItem(mxResources.get('searchShapesInOpenLibraries'), null, mxUtils.bind(this, function()
		{
			find(false, false);
		}), parent);

		var td = openLibItem.firstChild.nextSibling.nextSibling;
		var span = document.createElement('span');
		span.className = 'geMenuShortcut';
		span.innerHTML = 'Shift+Enter';
		td.appendChild(span);

		// Separate image-only search (eg. via the icon provider); only
		// offered when an image search backend is configured.
		if (this.isImageSearchSupported())
		{
			menu.addItem(mxResources.get('searchImages'), null, mxUtils.bind(this, function()
			{
				find(null, true);
			}), parent);
		}

		if (editorUi.isTemplateSearchSupported())
		{
			menu.addItem(mxResources.get('searchTemplates'), null, mxUtils.bind(this, function()
			{
				editorUi.hideCurrentMenu();
				editorUi.searchTemplates(input.value);
				input.value = '';
			}), parent);
		}

		menu.addItem(mxResources.get('findInDiagram'), null, mxUtils.bind(this, function()
		{
			editorUi.hideCurrentMenu();
			editorUi.showSearchWindow(true, input.value);
			input.value = '';
		}), parent);
		
		if (Editor.enableAi &&
			!editorUi.isOffline() &&
			editorUi.isOwnGDriveDomain() &&
			editorUi.isExternalDataComms() &&
			editorUi.getServiceName() == 'draw.io' &&
			EditorUi.isMermaidSupported())
		{
			menu.addItem(mxResources.get('generate'), null, mxUtils.bind(this, function()
			{
				editorUi.openGenerateDialog(input.value);
				input.value = '';
			}), parent);
		}

		if (!editorUi.isOffline() &&
			editorUi.isOwnGDriveDomain() &&
			editorUi.isExternalDataComms())
		{
			menu.addItem(mxResources.get('help'), null, mxUtils.bind(this, function()
			{
				editorUi.searchHelp(input.value);
				input.value = '';
			}), parent);
		}

		menu.addSeparator();

		var bestMatch = (input.value.length > 0) ?
			findAction(lc) : null;

		function addAction(action)
		{
			if (action != null && action.visible)
			{
				var item = menu.addItem(action.getTitle(), null,
					function() {
						executeAction(action, arguments);
					}, parent, null, action.isEnabled());

				// Adds checkmark image
				if (action.toggleAction && action.isSelected())
				{
					menu.addCheckmark(item, Editor.checkmarkImage);
				}

				if (enterAction == null && action.isEnabled() &&
					(input.value.length == 0 || bestMatch == action))
				{
					setEnterAction(item, function()
					{
						executeAction(action, arguments);
						focusGraph();
					});
				}

				if (ctrlEnterAction == null && action.isEnabled() &&
					(bestMatch == action || input.value.length == 0))
				{
					setCtrlEnterAction(item, function()
					{
						executeAction(action, arguments);
						focusGraph();
					});
				}
			}
		};

		addAction(bestMatch);

		for (var i = 0; i < lastActions.length; i++)
		{
			if (lastActions[i] != bestMatch)
			{
				addAction(lastActions[i]);
			}
		}

		// Finds first matching page, preferring non-current page
		if (lc.length > 0 && editorUi.pages != null)
		{
			menu.addSeparator();
			var matchingPages = [];

			for (var i = 0; i < editorUi.pages.length; i++)
			{
				var page = editorUi.pages[i];

				if (page.getName() != null && ((lc.charAt(lc.length - 1) == ' ') ?
					page.getName().toLowerCase() == lc.substring(0, lc.length - 1) :
					page.getName().toLowerCase().indexOf(lc) >= 0))
				{
					matchingPages.push(page);
				}
			}

			// Sorts non-current pages first
			if (matchingPages.length > 1)
			{
				var currentPage = editorUi.currentPage;

				matchingPages.sort(function(a, b)
				{
					if (a == currentPage) return 1;
					if (b == currentPage) return -1;
					return 0;
				});
			}

			for (var i = 0; i < Math.min(4, matchingPages.length); i++)
			{
				(function(page, isFirst)
				{
					var fn = function()
					{
						editorUi.selectPage(page);
						graph.container.focus();
						input.value = '';
					};

					var item = menu.addItem(page.getName() +
						' (' + mxResources.get('page') + ')',
						null, fn, parent);

					if (isFirst)
					{
						if (enterAction == null)
						{
							setEnterAction(item, fn);
						}

						setCtrlEnterAction(item, fn);
					}
				})(matchingPages[i], i == 0);
			}
		}
		
		// Finds first matching library
		if (lc.length > 0 && editorUi.sidebar != null &&
			editorUi.sidebar.entries != null)
		{
			menu.addSeparator();

			for (var i = 0; i < editorUi.sidebar.entries.length; i++)
			{
				var entries = editorUi.sidebar.entries[i].entries;

				for (var j = 0; j < entries.length; j++)
				{
					(function(entry)
					{
						var config = editorUi.sidebar.getConfigurationById(entry.id);
						var tokens = entry.title.toLowerCase().split(' ');

						if (config != null && mxUtils.indexOf(tokens, lc) >= 0)
						{
							var fn = function()
							{
								var elts = editorUi.sidebar.showPalettes(config.prefix || '',
									config.libs || [config.id], true);
								input.value = '';
								
								if (elts != null && elts.length > 1)
								{
									if (elts[1].firstChild != null &&
										(elts[1].firstChild.firstChild == null ||
										elts[1].firstChild.style.display == 'none'))
									{
										elts[0].click();
									}

									elts[0].scrollIntoView({behavior: 'smooth'});
								}
							};

							var item = menu.addItem(entry.title + ' (' +
								mxResources.get('openLibrary') + ')',
								null, fn, parent);

							if (enterAction == null)
							{
								setEnterAction(item, fn);
							}

							if (ctrlEnterAction == null)
							{
								setCtrlEnterAction(item, fn);
							}
						}

						return true;
					})(entries[j]);
				}
			}
		}
		
	}), null, true);

	var center = document.createElement('div');
	center.style.display = 'none';
	center.style.paddingTop = '8px';
	center.style.alignItems = 'center';
	center.style.justifyContent = 'center';

	var button = mxUtils.button(mxResources.get('moreResults'), function()
	{
		find();
	});
	
	button.setAttribute('title', mxResources.get('moreResults'));
	button.className = 'geBtn gePrimaryBtn';
	button.style.borderRadius = '16px';
	button.style.padding = '8px 12px';
	
	center.appendChild(button);
	div.appendChild(center);
	
	var searchTerm = '';
	var active = false;
	var complete = false;
	var page = 0;
	var hash = new Object();

	// Count is dynamically updated below
	var count = 12;
	
	var clearDiv = mxUtils.bind(this, function()
	{
		active = false;
		this.currentSearch = null;
		var child = div.firstChild;
		
		while (child != null)
		{
			var next = child.nextSibling;
			
			if (child != inner && child != center)
			{
				child.parentNode.removeChild(child);
			}
			
			child = next;
		}
	});

	function resetSearch()
	{
		cross.setAttribute('src', Editor.magnifyImage);
		cross.setAttribute('title', mxResources.get('search'));
		cross.setAttribute('tabindex', '-1');
		center.style.display = 'none';
		input.value = '';
		searchTerm = '';
		clearDiv();
	};
		
	mxEvent.addListener(cross, 'click', function()
	{
		if (cross.getAttribute('src') != Editor.magnifyImage)
		{
			resetSearch();
		}

		input.focus();
	});

	var lastSearchClosedLibs = null;
	var lastImagesOnly = null;

	find = mxUtils.bind(this, function(searchClosedLibs, imagesOnly)
	{
		if (searchClosedLibs == null)
		{
			searchClosedLibs = this.searchClosedLibraries;
		}

		// Preserves the current mode for paging (eg. the More Results
		// button) so an image search is not silently turned into a
		// shape search; explicit callers (the omnibox items) pass a value.
		if (imagesOnly == null)
		{
			imagesOnly = (lastImagesOnly != null) ? lastImagesOnly : false;
		}

		editorUi.hideCurrentMenu();

		// Shows 4 rows (minimum 4 results)
		count = 4 * Math.max(1, Math.floor(this.container.clientWidth / (this.thumbWidth + 10)));
		this.hideTooltip();

		if (input.value != '')
		{
			if (center.parentNode != null)
			{
				if (searchTerm != input.value || lastSearchClosedLibs != searchClosedLibs ||
					lastImagesOnly != imagesOnly)
				{
					clearDiv();
					searchTerm = input.value;
					lastSearchClosedLibs = searchClosedLibs;
					lastImagesOnly = imagesOnly;
					hash = new Object();
					complete = false;
					page = 0;
				}

				if (!active && !complete)
				{
					button.setAttribute('disabled', 'true');
					center.style.display = 'flex';
					button.style.cursor = 'wait';
					button.innerHTML = '';
					mxUtils.write(button, mxResources.get('loading') + '...');
					active = true;

					// Ignores old results
					var current = new Object();
					this.currentSearch = current;

					try
					{
						this.searchEntries(searchTerm, count, page, mxUtils.bind(this, function(results, len, more, terms)
						{
							if (this.currentSearch == current)
							{
								results = (results != null) ? results : [];
								active = false;
								page++;
								this.insertSearchHint(div, searchTerm, count, page, results, len, more, terms);
								this.insertSearchResultsHeader(div, searchTerm, page);

								// Allows to repeat the search
								if (results.length == 0 && page == 1)
								{
									searchTerm = '';
								}

								if (center.parentNode != null)
								{
									center.parentNode.removeChild(center);
								}

								// Search results dedup and right-click menu key on
								// elt.innerHTML, which would be empty for every
								// virtual placeholder. Force synchronous thumbs
								// for the search render loop.
								var prevVirtualThumbs = this.virtualThumbs;
								this.virtualThumbs = false;

								for (var i = 0; i < results.length; i++)
								{
									(mxUtils.bind(this, function(result)
									{
										try
										{
											var elt = result();

											if (this.closedLibraryOpacity != null &&
												searchClosedLibs)
											{
												if (this.isEntryIgnored(result, false))
												{
													elt.style.opacity = this.closedLibraryOpacity;
												}
											}

											// Avoids duplicates in results
											if (hash[elt.innerHTML] == null)
											{
												hash[elt.innerHTML] = (result.parentLibraries != null) ?
													result.parentLibraries.slice() : [];
												div.appendChild(elt);
											}
											else if (result.parentLibraries != null)
											{
												hash[elt.innerHTML] = hash[elt.innerHTML].concat(result.parentLibraries);
											}

											mxEvent.addGestureListeners(elt, null, null, mxUtils.bind(this, function(evt)
											{
												var libs = hash[elt.innerHTML];

												if (mxEvent.isPopupTrigger(evt))
												{
													this.showPopupMenuForEntry(elt, libs, evt);
												}
											}));

											// Disables the built-in context menu
											mxEvent.disableContextMenu(elt);
										}
										catch (e)
										{
											if (urlParams['test'] == '1')
											{
												if (window.console != null && !EditorUi.isElectronApp)
												{
													console.error(e);
												}
												else
												{
													mxLog.show();
													mxLog.debug(e.stack);
												}
											}
										}
									}))(results[i]);
								}

								this.virtualThumbs = prevVirtualThumbs;

								if (more)
								{
									button.removeAttribute('disabled');
									button.innerHTML = '';
									mxUtils.write(button, mxResources.get('moreResults'));
								}
								else
								{
									button.innerHTML = mxResources.get('reset');
									center.style.display = 'none';
									complete = true;
								}

								button.style.cursor = '';
								div.appendChild(center);
							}
						}), mxUtils.bind(this, function()
						{
							button.style.cursor = '';
						}), searchClosedLibs, imagesOnly);
					}
					catch (e)
					{
						editorUi.handleError(e);
					}
				}
			}
		}
		else
		{
			clearDiv();
			input.value = '';
			searchTerm = '';
			hash = new Object();
			center.style.display = 'none';
			complete = false;
			input.focus();
		}
	});

	this.searchShapes = function(value)
	{
		input.value = value;
		find(null, false);
	};
	
	mxEvent.addListener(input, 'keydown', mxUtils.bind(this, function(evt)
	{
		if (evt.keyCode == 13 /* Enter */ && evt.shiftKey)
		{
			consumeNextShiftUp = true;
			find(false, false);
			mxEvent.consume(evt);
		}
		else if (evt.keyCode == 13 /* Enter */ && (evt.metaKey || evt.ctrlKey) &&
			ctrlEnterAction != null)
		{
			ctrlEnterAction(evt, evt);
			mxEvent.consume(evt);
		}
		else if (evt.keyCode == 13 /* Enter */ && enterAction != null)
		{
			enterAction(evt, evt);
			mxEvent.consume(evt);
		}
		else if (evt.keyCode == 38 /* ArrowUp */ || evt.keyCode == 40 /* ArrowDown */)
		{
			var menu = editorUi.currentMenu;
			var items = [];

			// Shift+Arrow Up and Down only move the focus (see EditorUi.isArrowKeyEvent)
			if (menu != null && menu.tbody != null && !mxEvent.isShiftDown(evt))
			{
				var children = menu.tbody.childNodes;

				for (var i = 0; i < children.length; i++)
				{
					if (children[i].nodeName == 'TR' &&
						children[i]._action != null &&
						children[i]._enabled)
					{
						items.push(children[i]);
					}
				}
			}

			if (items.length > 0)
			{
				var idx = items.indexOf(selectedItem);

				if (evt.keyCode == 40 /* ArrowDown */)
				{
					idx = (idx + 1) % items.length;
				}
				else
				{
					idx = (idx <= 0) ? items.length - 1 : idx - 1;
				}

				if (selectedItem != null)
				{
					selectedItem.className = 'mxPopupMenuItem';
				}

				selectedItem = items[idx];
				selectedItem.className = 'mxPopupMenuItemHover';
				selectedItem.scrollIntoView({block: 'nearest'});
				enterAction = selectedItem._action;
			}
			// Moves the focus to the first result or to the control above or
			// below without a menu
			else if (!mxEvent.isAltDown(evt) && !mxEvent.isControlDown(evt) &&
				!mxEvent.isMetaDown(evt) && (evt.keyCode != 40 || !this.focusFirstItem(div)))
			{
				editorUi.focusTabStopInDirection(input, evt.keyCode);
			}

			mxEvent.consume(evt);
		}
		else if (evt.keyCode == 27 /* Escape */)
		{
			// Returns to the diagram if there is no search to reset
			// and no menu to close (closed on keyup in addMenuHandler)
			if (input.value == '' && searchTerm == '' && editorUi.currentMenu == null)
			{
				graph.container.focus();
			}
			else
			{
				resetSearch();
			}

			mxEvent.consume(evt);
		}
	}));

	var searchChanged = mxUtils.bind(this, function()
	{
		window.setTimeout(mxUtils.bind(this, function()
		{
			if (input.value == '')
			{
				cross.setAttribute('src', Editor.magnifyImage);
				cross.setAttribute('title', mxResources.get('search'));
				cross.setAttribute('tabindex', '-1');
			}
			else
			{
				cross.setAttribute('src', Editor.crossImage);
				cross.setAttribute('title', mxResources.get('reset'));
				cross.setAttribute('tabindex', '0');
			}
			
			if (input.value == '')
			{
				complete = true;

				// Deleting the term clears the results like Escape does
				// (resetSearch also resets searchTerm so that repeating
				// the previous search runs again)
				resetSearch();
			}
			else if (input.value != searchTerm)
			{
				center.style.display = 'none';
				complete = false;
			}
			else if (!active)
			{
				if (complete)
				{
					center.style.display = 'none';
				}
				else
				{
					center.style.display = 'flex';
				}
			}
		}), 0);
	});
	
	mxEvent.addListener(input, 'keyup', searchChanged);
	mxEvent.addListener(input, 'paste', searchChanged);
	mxEvent.addListener(input, 'cut', searchChanged);

    // Workaround for blocked text selection in Editor
    mxEvent.addListener(input, 'mousedown', function(evt)
    {
    	if (evt.stopPropagation)
    	{
    		evt.stopPropagation();
    	}
    	
    	evt.cancelBubble = true;
    });
    
    // Workaround for blocked text selection in Editor
    mxEvent.addListener(input, 'selectstart', function(evt)
    {
    	if (evt.stopPropagation)
    	{
    		evt.stopPropagation();
    	}
    	
    	evt.cancelBubble = true;
    });

	var outer = document.createElement('div');
    outer.appendChild(div);
    this.appendChild(outer);
	
    // Keeps references to the DOM nodes
	this.palettes['search'] = [elt, outer];
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.insertSearchHint = function(div, searchTerm, count, page, results, len, more, terms)
{
	if (results.length == 0 && page == 1)
	{
		var err = document.createElement('div');
		err.className = 'geSidebarText';
		var temp = mxResources.get('noResultsFor', [searchTerm]);
		err.setAttribute('title', temp);
		mxUtils.write(err, temp);
		div.appendChild(err);
	}
};

/**
 * Hook for a header above the search results (called with the page already
 * incremented, so 1 is the first page). Does nothing here - the application
 * layer overrides this (grapheditor must not know about specific search
 * providers).
 */
Sidebar.prototype.insertSearchResultsHeader = function(div, searchTerm, page)
{
	// Overridden in the application
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.addGeneralPalette = function(expand)
{
	var lineTags = 'line lines connector connectors connection connections arrow arrows ';
	this.setCurrentSearchEntryLibrary('general', 'general');
	var graph = this.editorUi.editor.graph;
	var sb = this;

	var temp = parseInt(this.initialDefaultVertexStyle['fontSize']);
	var fontSize = !isNaN(temp) ? 'fontSize=' + Math.min(16, temp) + ';' : '';
	// Label cells of edges inherit the text styles of the edge
	var edgeLabelStyle = 'edgeLabel;resizable=0;html=1;' + Graph.createInheritedLabelStyle();
	
	// Reusable cells
	var field = new mxCell('List Item', new mxGeometry(0, 0, 80, 30),
		'text;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;' +
		'spacingLeft=4;spacingRight=4;overflow=hidden;points=[[0,0.5],[1,0.5]];' +
		'portConstraint=eastwest;rotatable=0;whiteSpace=wrap;html=1;' + fontSize);
	field.vertex = true;

	var fns = [
	 	this.createVertexTemplateEntry('rounded=0;whiteSpace=wrap;html=1;', 120, 60, '', 'Rectangle', null, null, 'rect rectangle box'),
	 	this.createVertexTemplateEntry('rounded=1;whiteSpace=wrap;html=1;roundedPerimeter=1;', 120, 60, '', 'Rounded Rectangle', null, null, 'rounded rect rectangle box'),
	 	this.createVertexTemplateEntry(graph.appendFontSize(Editor.defaultTextStyle, graph.vertexFontSize),
			60, 30, 'Text', 'Text', null, null, 'text textbox textarea label'),
	 	this.createVertexTemplateEntry('text;html=1;whiteSpace=wrap;overflow=hidden;rounded=0;', 180, 120,
			'<h1 style="margin-top: 0px;">Heading</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ' +
			'ut labore et dolore magna aliqua.</p>', 'Textbox', null, null, 'text textbox textarea'),
 		this.createVertexTemplateEntry('ellipse;whiteSpace=wrap;html=1;shapeInside=1;', 120, 80, '', 'Ellipse', null, null, 'oval ellipse state'),
		this.createVertexTemplateEntry('whiteSpace=wrap;html=1;aspect=fixed;', 80, 80, '', 'Square', null, null, 'square'),
		this.createVertexTemplateEntry('ellipse;whiteSpace=wrap;html=1;shapeInside=1;aspect=fixed;', 80, 80, '', 'Circle', null, null, 'circle'),
	 	this.createVertexTemplateEntry('shape=process;whiteSpace=wrap;html=1;backgroundOutline=1;', 120, 60, '', 'Process', null, null, 'process task'),
	 	this.createVertexTemplateEntry('rhombus;whiteSpace=wrap;html=1;shapeInside=1;', 80, 80, '', 'Diamond', null, null, 'diamond rhombus if condition decision conditional question test'),
	 	this.createVertexTemplateEntry('shape=parallelogram;perimeter=parallelogramPerimeter;whiteSpace=wrap;html=1;shapeInside=1;fixedSize=1;', 120, 60, '', 'Parallelogram'),
	 	this.createVertexTemplateEntry('shape=hexagon;perimeter=hexagonPerimeter2;whiteSpace=wrap;html=1;shapeInside=1;fixedSize=1;', 120, 80, '', 'Hexagon', null, null, 'hexagon preparation'),
	 	this.createVertexTemplateEntry('triangle;whiteSpace=wrap;html=1;shapeInside=1;', 60, 80, '', 'Triangle', null, null, 'triangle logic inverter buffer'),
	 	this.createVertexTemplateEntry('shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;', 60, 80, '', 'Cylinder', null, null, 'cylinder data database'),
	 	this.createVertexTemplateEntry('ellipse;shape=cloud;whiteSpace=wrap;html=1;perimeter=cloudPerimeter;', 120, 80, '', 'Cloud', null, null, 'cloud network'),
	 	this.createVertexTemplateEntry('shape=document;whiteSpace=wrap;html=1;boundedLbl=1;', 120, 80, '', 'Document'),
	 	this.createVertexTemplateEntry('shape=internalStorage;whiteSpace=wrap;html=1;backgroundOutline=1;', 80, 80, '', 'Internal Storage'),
	 	this.createVertexTemplateEntry('shape=cube;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;darkOpacity=0.05;darkOpacity2=0.1;', 120, 80, '', 'Cube'),
	 	this.createVertexTemplateEntry('shape=step;perimeter=stepPerimeter;whiteSpace=wrap;html=1;shapeInside=1;fixedSize=1;', 120, 80, '', 'Step'),
	 	this.createVertexTemplateEntry('shape=trapezoid;perimeter=trapezoidPerimeter;whiteSpace=wrap;html=1;shapeInside=1;fixedSize=1;', 120, 60, '', 'Trapezoid'),
	 	this.createVertexTemplateEntry('shape=tape;whiteSpace=wrap;html=1;', 120, 100, '', 'Tape'),
	 	this.createVertexTemplateEntry('shape=note;whiteSpace=wrap;html=1;backgroundOutline=1;darkOpacity=0.05;', 80, 100, '', 'Note'),
	    this.createVertexTemplateEntry('shape=card;whiteSpace=wrap;html=1;', 80, 100, '', 'Card'),
	    this.createVertexTemplateEntry('shape=callout;whiteSpace=wrap;html=1;perimeter=calloutPerimeter;', 120, 80, '', 'Callout', null, null, 'bubble chat thought speech message'),
	    this.createVertexTemplateEntry('shape=wedgeCallout;whiteSpace=wrap;html=1;', 120, 80, '', 'Wedge Callout', null, null, 'bubble chat thought speech message callout annotation pointer wedge'),
	 	this.createVertexTemplateEntry('shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;html=1;outlineConnect=0;', 30, 60, 'Actor', 'Actor', false, null, 'user person human stickman'),
	 	this.createVertexTemplateEntry('shape=xor;whiteSpace=wrap;html=1;shapeInside=1;', 60, 80, '', 'Or', null, null, 'logic or'),
	 	this.createVertexTemplateEntry('shape=or;whiteSpace=wrap;html=1;shapeInside=1;', 60, 80, '', 'And', null, null, 'logic and'),
	 	this.createVertexTemplateEntry('shape=dataStorage;whiteSpace=wrap;html=1;shapeInside=1;fixedSize=1;', 100, 80, '', 'Data Storage'),
		this.createVertexTemplateEntry('swimlane;startSize=0;', 200, 200, '', 'Container', null, null, 'container swimlane lane pool group'),
		this.createVertexTemplateEntry('swimlane;whiteSpace=wrap;html=1;', 200, 200, 'Vertical Container', 'Container', null, null, 'container swimlane lane pool group'),
		this.createVertexTemplateEntry('swimlane;horizontal=0;whiteSpace=wrap;html=1;', 200, 200, 'Horizontal Container', 'Horizontal Container', null, null, 'container swimlane lane pool group'),
		this.addEntry('list group erd table', function()
		{
			var cell = new mxCell('List', new mxGeometry(0, 0, 140, 120),
		    	'swimlane;fontStyle=0;childLayout=stackLayout;horizontal=1;startSize=30;horizontalStack=0;' +
		    	'resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=1;marginBottom=0;whiteSpace=wrap;html=1;');
			cell.vertex = true;
			cell.insert(sb.cloneCell(field, 'Item 1'));
			cell.insert(sb.cloneCell(field, 'Item 2'));
			cell.insert(sb.cloneCell(field, 'Item 3'));
			
			return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'List');
		}),
		this.addEntry('list item entry value group erd table', function()
		{
			return sb.createVertexTemplateFromCells([sb.cloneCell(field, 'List Item')], field.geometry.width, field.geometry.height, 'List Item');
		}),
		this.addEntry('curve', mxUtils.bind(this, function()
	 	{
			var cell = new mxCell('', new mxGeometry(0, 0, 50, 50), 'curved=1;curveGeometry=1;endArrow=classic;html=1;');
			cell.geometry.setTerminalPoint(new mxPoint(0, 50), true);
			cell.geometry.setTerminalPoint(new mxPoint(50, 0), false);
			cell.geometry.points = [new mxPoint(50, 50), new mxPoint(0, 0)];
			cell.geometry.relative = true;
			cell.edge = true;
			
		    return this.createEdgeTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Curve');
	 	})),
	 	this.createEdgeTemplateEntry('shape=flexArrow;endArrow=classic;startArrow=classic;html=1;', 100, 100, '', 'Bidirectional Arrow', null, lineTags + 'bidirectional'),
	 	this.createEdgeTemplateEntry('shape=flexArrow;endArrow=classic;html=1;', 50, 50, '', 'Arrow', null, lineTags + 'directional directed'),
	 	this.createEdgeTemplateEntry('endArrow=none;dashed=1;html=1;', 50, 50, '', 'Dashed Line', null, lineTags + 'dashed undirected no'),
	 	this.createEdgeTemplateEntry('endArrow=none;dashed=1;html=1;dashPattern=1 3;strokeWidth=2;', 50, 50, '', 'Dotted Line', null, lineTags + 'dotted undirected no'),
	 	this.createEdgeTemplateEntry('endArrow=none;html=1;', 50, 50, '', 'Line', null, lineTags + 'simple undirected plain blank no'),
	 	this.createEdgeTemplateEntry('endArrow=classic;startArrow=classic;html=1;', 50, 50, '', 'Bidirectional Connector', null, lineTags + 'bidirectional'),
	 	this.createEdgeTemplateEntry('endArrow=classic;html=1;', 50, 50, '', 'Directional Connector', null, lineTags + 'directional directed'),
	 	this.createEdgeTemplateEntry('shape=link;html=1;', 100, 0, '', 'Link', null, lineTags + 'link'),
	 	this.addEntry(lineTags + 'edge title', mxUtils.bind(this, function()
		{
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'endArrow=classic;html=1;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(100, 0), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
	    	var cell0 = new mxCell('Label', new mxGeometry(0, 0, 0, 0), edgeLabelStyle + ';align=center;verticalAlign=middle;');
	    	cell0.geometry.relative = true;
	    	cell0.setConnectable(false);
	    	cell0.vertex = true;
	    	edge.insert(cell0);
			
			return this.createEdgeTemplateFromCells([edge], 100, 0, 'Connector with Label');
		})),
		this.addEntry(lineTags + 'edge title multiplicity', mxUtils.bind(this, function()
		{
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'endArrow=classic;html=1;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(160, 0), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
	    	var cell0 = new mxCell('Label', new mxGeometry(0, 0, 0, 0), edgeLabelStyle + ';align=center;verticalAlign=middle;');
	    	cell0.geometry.relative = true;
	    	cell0.setConnectable(false);
	    	cell0.vertex = true;
	    	edge.insert(cell0);
	    	
	    	var cell1 = new mxCell('Source', new mxGeometry(-1, 0, 0, 0), edgeLabelStyle + ';align=left;verticalAlign=bottom;');
	    	cell1.geometry.relative = true;
	    	cell1.setConnectable(false);
	    	cell1.vertex = true;
	    	edge.insert(cell1);
			
	    	var cell2 = new mxCell('Target', new mxGeometry(1, 0, 0, 0), edgeLabelStyle + ';align=right;verticalAlign=bottom;');
	    	cell2.geometry.relative = true;
	    	cell2.setConnectable(false);
	    	cell2.vertex = true;
	    	edge.insert(cell2);
	    	
			return this.createEdgeTemplateFromCells([edge], 160, 0, 'Connector with Labels');
		})),
	 	this.addEntry(lineTags + 'edge shape symbol message mail email', mxUtils.bind(this, function()
		{
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'endArrow=classic;html=1;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(100, 0), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
	    	var cell = new mxCell('', new mxGeometry(0, 0, 20, 14), 'shape=message;html=1;outlineConnect=0;');
	    	cell.geometry.relative = true;
	    	cell.vertex = true;
	    	cell.geometry.offset = new mxPoint(-10, -7);
	    	edge.insert(cell);

			return this.createEdgeTemplateFromCells([edge], 100, 0, 'Connector with Symbol');
		}))
	];
	
	this.addPaletteFunctions('general', mxResources.get('general'), (expand != null) ? expand : true, fns);
	this.setCurrentSearchEntryLibrary();
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.addMiscPalette = function(expand)
{
	var sb = this;
	var lineTags = 'line lines connector connectors connection connections arrow arrows '
	this.setCurrentSearchEntryLibrary('general', 'misc');
	var graph = this.editorUi.editor.graph;
	var slantedTextStyle = 'text;html=1;strokeColor=none;fillColor=none;align=center;' +
		'verticalAlign=middle;whiteSpace=wrap;';
	var slantedTextTags = 'text slanted skewed isometric aws 3d face';

	var fns = [
		this.createVertexTemplateEntry(mxUtils.setStyle(mxUtils.setStyle(graph.appendFontSize(Editor.defaultTextStyle, graph.vertexFontSize), 'autosize', '1'), 'resizable', '0'),
			60, 30, 'Text', 'Autosize Text', null, null, 'autosize text'),
   	 	this.createVertexTemplateEntry('text;strokeColor=none;fillColor=none;html=1;fontSize=25;fontStyle=1;verticalAlign=middle;align=center;autosizeText=1;',
			160, 40, 'Autosize Title', 'Autosize Title', null, null, 'text heading title'),
		this.addEntry('link url hyperlink text label', mxUtils.bind(this, function()
	 	{
	 		var cell = new mxCell('Link', new mxGeometry(0, 0, 60, 40), 'text;html=1;strokeColor=none;fillColor=none;whiteSpace=wrap;align=center;verticalAlign=middle;fontColor=#0000EE;fontStyle=4;');
	 		cell.vertex = true;
	 		this.graph.setLinkForCell(cell, 'https://www.draw.io');

	 		return this.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Link');
	 	})),
		this.createVertexTemplateEntry('shape=curvedText;noLabel=1;align=center;verticalAlign=middle;strokeColor=none;fillColor=none;',
			70, 50, 'Curved Text', 'Curved Text', null, null, 'text curved arc path'),
		// Slanted text for the faces of isometric (30 degrees) diagrams via a CSS
		// transform on a block in the HTML label, which the label editor keeps
		// for the lines that are typed into it
		this.createVertexTemplateEntry(slantedTextStyle, 100, 60,
			'<div style="transform:skewY(30deg);">Text</div>', 'Slanted Text Left',
			null, null, slantedTextTags + ' left'),
		this.createVertexTemplateEntry(slantedTextStyle, 100, 60,
			'<div style="transform:skewY(-30deg);">Text</div>', 'Slanted Text Right',
			null, null, slantedTextTags + ' right'),
		this.createVertexTemplateEntry(slantedTextStyle, 100, 60,
			'<div style="transform:matrix(0.866,-0.5,0.866,0.5,0,0);">Text</div>',
			'Slanted Text Top', null, null, slantedTextTags + ' top'),
		this.addEntry('variable placeholder metadata hello world text label', mxUtils.bind(this, function()
	 	{
	 		var cell = new mxCell('%name% Text', new mxGeometry(0, 0, 80, 20), 'text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;overflow=hidden;');
	 		cell.vertex = true;
	 		this.graph.setAttributeForCell(cell, 'placeholders', '1');
	 		this.graph.setAttributeForCell(cell, 'name', 'Variable');

	 		return this.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Variable');
	 	})),
		this.addEntry('timestamp date time text label', mxUtils.bind(this, function()
	 	{
	 		var cell = new mxCell('%date{ddd mmm dd yyyy HH:MM:ss}%', new mxGeometry(0, 0, 160, 20), 'text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;overflow=hidden;');
	 		cell.vertex = true;
	 		this.graph.setAttributeForCell(cell, 'placeholders', '1');

	 		return this.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Timestamp');
	 	})),
		this.createVertexTemplateEntry('text;strokeColor=none;fillColor=none;html=1;whiteSpace=wrap;verticalAlign=middle;overflow=hidden;', 100, 80,
 			'<ul><li>Value 1</li><li>Value 2</li><li>Value 3</li></ul>', 'Unordered List'),
	 	this.createVertexTemplateEntry('text;strokeColor=none;fillColor=none;html=1;whiteSpace=wrap;verticalAlign=middle;overflow=hidden;', 100, 80,
 			'<ol><li>Value 1</li><li>Value 2</li><li>Value 3</li></ol>', 'Ordered List'),
		this.addDataEntry('vertical list', 60, 60, 'Vertical List',
			'7ZjBbptAEIafZq/Vsmvc9grEaaX04vQFpt4xrLrsomVs7Dx9xYJx4pjIaRsfLE4ww8wA/z+fkGAyLXf3Hqrih1NomLxjMvXOUXdW7lI0hgmuFZMZE4IzIZhYjFyNwlVegUdLlzSIrmELZoNdpkvUtDd9oi6gak8JfrWpJByXaBV6JrOVMwaqGhWTSU3g6VE/tdWcyWTlLIG2oS4KcajVYU5XUWijHmDvNnS4wyFK1s4ehkVt91obkzrj2mnWWQw39O43niT7N0JPuBtVJaR6Se7RlUh+zwRvtKKiq5h3wvECdV7QyxzUXZwPnUeJmVj0Kp9XXL5T8aVrmEwK5/VTK6fplTvVum50acDiNwR1kkqc2g9dzwXTtkCv6awzyrvqJ/gcqU+ckb9y2lKQIk5YnHAmUv4pZnHGRMriJDrGcRbKPaXO1uRBBx8QamqwPjV7fqmJ4q9MjOJ/N3H2ysTvhCUTPBo1swJPGswSVwQ2DyQVVJoejabQhI8VrNrSxkPV4WPb6qMpY/a5Lfq1aRclK7RSaN/wC/3dFjvbohPhBZMJGJ1bJjOD63ZyXcFK2/whRFl8qTPyvzvTDzvK9+5pYAi9BcLEbayqX9k9POdFGxBPGH8wxvuXNl6B6vkY1WKietj5m6b680T1daiW/GpUfxmjWk5UDzt/01R/nSD+EIhn1/s0R3yM4tlE8bDjt0QxE4vjb5Cu/Plfkj8='),
 		this.createVertexTemplateEntry('shape=note;whiteSpace=wrap;html=1;backgroundOutline=1;autosizeText=1;' +
			'fontColor=#000000;darkOpacity=0.05;fillColor=#FFF9B2;strokeColor=none;fillStyle=solid;fontSize=20;' +
			'direction=west;gradientDirection=north;gradientColor=#FFF2A1;shadow=1;size=20;pointerEvents=1;',
			150, 150, 'The size of the font in this note will change so that it fits within the note shape', mxResources.get('note')),
		this.addDataEntry('table', 180, 120, 'Table 1', '7ZlNktowEIVPo23KkjBDtjLDZJFsmFyggxqkipBccoNhTp+ybGB+M0AlLMArW+3XsvQ+q97CTBbLzUOE0vwIGh2T90wWMQRq75abAp1jIrOayTETImNCMDH54ClPT7MSIno6pkG0DWtwK2wrbaGiresKlYGyuSX41ZRUuk7Ra4xMjmfBOSgr1EyqiiDSo31q1BmTahY8gfVJx9M4aW2ap1UY6/R32IYV7d6wG6l58LvJ+JBJ1a0UI+Hmw92mUrfVBwxLpLhlIqutJtMpRq0jmUG7MLu2zqYMqraw2PcezGNi0vn3vpfyRC+noWZSmRDtU2OU6zx57WJV26UDj98Q9KuSCnq774rhNxbBhcZt6w1GS+96rmMof0JcIHWFuXVu1+iDbxiXwXpKVuSK5Spjosi+5CwfM1GwXPHDOB8neaQi+Ioi2EQCoaIaq7MxivMwDv4BxcHxFEuIZMFNcUbgF+lwGFq67muvjSV8LGHWSOsIZXsifKM+0PiIW1hjnLvmCxkbqzX6v4DCeL/Glhc/13H5qePDEw3vJju4c/Js4AijB0IVVl5Xbyju13kU2LwH+wzs5iWGK+I87Dm/5bwPuCsCfdfn7X/O2+1LjJeI39Ftnt67q4/frz3Ym4hfnvWgbyN/Oe8D+DIBPLpgAHNxm+eX86uPYC57tDcSwoOe9HWmMBOTw9+BVv7858Ef'),
 		this.addDataEntry('table', 180, 120, 'Table 2', '7ZnBctowEIafRteOJWEgV9slPaQX0ul9ixasqSx5ZBFDnr4j2YaExAOkLQc7J6T17sr8n3f+GZvwtNjdWyjz70agIvwr4ak1xjWrYpeiUoRFUhCeEcYiwhhhi56rNFyNSrCo3SUFrCl4ArXFJtIEKrdXbaDKofRLB798KAm/S9QCLeHZyigFZYWC8CR3hSI8o4QndS4dPpaw8pW1hZLwpHJg3aN89qGI8GRltAOpQxsa9qGVDMc0GblU4gH2Zuu6G+h2Pntb6AepsWqzralfbtdGd6fRaTjemt+YGmX8gQLXsFW+UasAWoe7XhVDqJXwHk2Bzu4Ji2opXN5mzBuloxzlJu/KWvkjqJrA5lB7hELYouXyPiN+JaOlqT0MY+WzV1i1epzKX9WyUKDxG4I4CSVG7A+QTqEIa8ofYDfoOqGlUp2s2mj/jJRGahf+cpyQOIkIS6MvMYkzwlISJ/S4j7OQbl1qdOUsyKA4QuVqrNxZjFLnaOXFGNnHME7+AcXJG4o/w5JFtBdnCdZJUEtcOdCbMH1nZmxltPbZR1zv0DFPaNfKPyVZLoVAfSIz+1uZ+VmZp1eq3DY7KnF1N1AOrQaHidlqUb1Bd7jPi2jGvTTZWGjuXms/ILjTXrh8ZHAP/jUgurNPO/3Pdrp/jfEW7jrvHdnJ4EZ2Nnh3veulGY+F5nDdlUa9dKcjoztEe6X0019v46/zG/orZb1DOxvc0FI6eIelvJfnfDQ8B+yx/W+b7saGdwAmS9ji+EmgSX/5xeAP'),
		this.addDataEntry('table title', 180, 150, 'Table with Title 1', '7ZnPctowEMafRteOJWFIr7ZDemgvJC+wRQvWVEgeecGQp+9YFn9aICGZDAfwCevTrmx/P3a+g5nMF+snD1X5yyk0TD4ymXvnqLtarHM0holEKyYLJkTChGBifGaXh92kAo+WLmkQXcMKzBI75QV+G+zUmjYmqnUJVXtJYVdm4XeCVqFnspg6Y6CqUTGZ1QSenvVrWy0TJrOpswTahkIe1qFYh4OKUFFqo37Cxi1pe4vtKqvJuz+YO+PafoUzWJpWnzm7vQsfMpnF90BPuD7rRZCiEU/oFkh+w0TSaEVlrHjo/EpK1PNy25ZGEepOmO9699YyMY7unnZaHjn9tskT1zCZlc7r19ZAE706tDesG70wYPEHgvpPypza7LoOXdS2RK/pJAvlXfUCfo4UhZk2ZttonW3hV05bClakGUuzhIk8+ZaytGAiZ2nG9+u0COWecmdr8qADCYSaGqw/jVGcxriJRkdY71EdfAHUweVQK/CkwUxwSmDnYYhKWpg4FE2pCZ8rmLaljYeqGxzbVu/hnMPoVuhnpv3DFKVWCu0b3NA/rrDDxz8LQL47R8MPGh4P27vz4dPAEHoLhJlbWlUfUdw950Vg0x7sAdj1vxhuiPOw53zMmYvbAz3q4/c68Tu6Yvw+3Of0jm4+fr/3YO8ifnnSg76P/OW8D+DrBDDnV0xgLu5zgDm/+Qzmskd7Jyk86EnfZgwzMd5/S+jKDz81/AU='),
		this.addDataEntry('table title', 180, 120, 'Table with Title 2', '7ZhNc9owEIZ/ja4dW4ppuNoO6YFeINP7Fi1YUyF55AVDfn3HsgxpDfnoMJ4O5GRptSvJ7+N9D2YiW+8eHZTFdytRM/HAROaspXa03mWoNeORkkzkjPOIcc745Mxq7FejEhwaek8Bbwu2oDfYRp7gp8Y2WtFeh2hVQNkMya+K1D9naCQ6JvKF1RrKCiUTaUXgaK6em2wRMZEurCFQxifGfu6Tld8o9xmF0nIKe7uh7ohuli7VDuXM1lWodraeKoNVKF1aQ/Nwzcif7uwvzKy2zXESl7DR1OW1l4pHTKThtdER7s5K50NBt0e0ayS3ZzyqlaQiZNy38kYFqlXRlQXNI6jawOpQeyTB+CTAOA1G9MC8zmRmaybSwjr13OitD3ocafh5rdYaDH5DkH+FUiv3HZAeIuls+QRuhdQJr7TuZDbWNN9EaZUh/8pJypI0YjyLviQsyRnPWJLGx3mS+3RHmTUVOVBecYSKaqyoh1GZAp36Z4z8NMZ9EDrAeouquADUux7U+CzVEhwp0DNcEJiVb7qC1jq0QV0ownkJiya1dlC2jWaa7CO1E5DsFt1SNx9LXigp0XTg0D1sseUXX5qAeLOR7j6oeNjsqM6HdwNN6AwQpnZjZNXDeLjnu8gmPbI//JBHgxMGrVaGiVzj0rdSCQtlVlM/y0dnPoEhcO/+hPOy4S6LPx6e/+jTroex69GAdv21B5X/D3Z9UbVHV2/N92etmd+eNY9uz5rHn9Y8jDWPB7TmOOpRFVfnzeOr9+Y4PmvO4vbMeXz15sz45Phvq01/+evrNw=='),
		this.addDataEntry('crossfunctional cross-functional cross functional flowchart swimlane table', 400, 400, 'Cross-Functional Flowchart',
			'7ZnfbtowFMafxpebYpvQ7nIJo7vYpIntBbzkjFgzPpF9KNCnn/IPqhK3EWrXKs0V8ck5Vvi+H9YnwmS62d84VRbfMQfD5BcmU4dIzdVmn4IxTEQ6Z3LBhIiYEEwsA3d5fTcqlQNLQwZEM3CrzBaaSurQ+w/Lrc1Io1VV89LgLiuUo6bZ08G0zb5QZXVJ6ndVSurPFdgcHJOLDI1RpYecySQrtMm/qQNuqevvVokn5einvqt2mkVVczOo600XVcVBtnVe38IKfNNYVWFfKpu3iz9ou034nMmk/WbgCPZBdepSK80N4AbIHZiIdjqnoumYRY2CUQF6XdCDovJNYX2cPYnNxLLVu197eab954zQMRHxx4Ve4Y7JpECn79CSMq0Afqc3Rln4Cip/UEowP3QlcvgXUjRYWaRtAU5XJuQOy1/KrYHu69k+Qb3WxnRjFm1ld4naUq1AnLA4iZhIo48xixdMpCxO+GkdL+p2RylaT07p2gBQnnbgX5kB0c/AobO6mXgKCS6eAYnZGRI/CuWhH4nW28HOPzQ0REKG1kLW/qRD1r+iX7Lfr33Qr6M1g/1qd19VMti1gUv2U4bAWUWQ4Nbm/gyD46MPIiMOkiEmMoaRwefjRGMeRENOaAxDQ1yPE42rYMQQU8R4MxGj72B6uYxxfcbE858S56dBiIknTon/a9PVe0wWnyYeLuNhrHmCRxMRlxEx1hjBeTBHyClHvJkc0Yffy+UILqZjIvi3In+PSYLLiYgLiRhtlphNSFyIxEjCBBPL0+uspv3+265/'),		
 		this.addDataEntry('table', 280, 160, 'Table', '7Zpdc6IwFIZ/DfcksSqX1X7sxe6NdvY+ylEyjYQJsWp//QZIrDXSIkUdcZ3pTDiSNHmfHF5yRo8MF+tnSZPojwiBe+TRI0MphCpai/UQOPewz0KPPHgY+/rPw08l36L8Wz+hEmJVpQMuOrxRvoQicp+moNIinKoNN+FpxHj4m27EMhtX0QkHezWQMF3KlL3BCFL2nnXwdTRVUrzCUHAh8yFI0J/M9AzJYMY434nf94ZBB2c9IhqKlQ5mN5mJgVSwLl1cHjIrewaxACU3+pYVC1VkFtgvBPAjYPPIduuaIE2LwHzb90Mr3TByHZaOOBrp+Sdg1RllKxlEQrJ3ESvKt6pQqcY7Kq3YgtMYfgEN90IDEW5MSInEtDjMlGlOhFJiYS6kWV3WDqVIXqicgw1MBec0SdmE2397GBmsExrbacz0tMdmcS5PFkcgmXJpzvJPVYC4HkBCfs6v42z9F6b0arGP3N0v4himOdcvBayo0XbHU87msY5NtSAg90RH5nqn41P+yfaVWvBjEoV8q3NAjpPZDDbKZInnuW5Hjka5XnNMld7oyzhMHXbbeVbCeVeKE98MzvVn8Xd5dBqlW2G0Zul2S+m6j+GW00X9nov3ypO35+D9b64nM9fNZ6Lfei3+udf2Hb5/8+apvfYj6iTvKmIKxgmdZuOt9At4jUTt1XPVLwStkZh7ozWbmEEpuNO66mXAHemf9TlWGK1ZjsgvBXlaA70oyMpWeUUZidAteyWq7pWP90/4gTTjld27il6Jfu6VyK3J2FTtnClVm8hM9H1t5mDyfKFgjVTcG63hVCSlpO5aQOpIN6wPrsJoDYNzaz8WXLc94Cq73zWlnFvmuSH3u9BJMehWdL8GqrLIrfTY1OydKTX3FT/Ji2uxkVtdkUVuVcei7N8CyvZWY1F5PSe4IbJtrMQit+JzQwZ7oeMlsnW2c5wvcXkpyFaJruPtN6jnoFf0tovdWs8W1bkK56dE1d4Tpn1qHiLnPlCvllwLjpj68uPnVsXtu7/G+gc='),		
 		this.addDataEntry('table', 180, 140, 'Table', '7ZhNc5swEIZ/DXc+HH9cTdv00F7sTu8yWoOmi8QIOUB+fSUjJXEwMbZzgcl4PKNdIVn7PlovkhfFef0oSZH9FhTQi757USyFUG0rr2NA9EKfUS/65oWhr79e+KOnNzj2+gWRwNWQAWE74IngAVpP6yhVg9aRZAzpL9KIg5lRkR2Cs9YSkoMs2RNsoGTPZoCvvWVGqKissWeIsUAhtc0FB9OvpPgHzumFUeybj+6xqwGpoO6N6Oiy4TyCyEHJRj9SMaoy+8SyjdrPgKWZGzazTlK2jvRl7KtAumE1Oq9XdFkvHX0BTqmN0WGdCcmeBVcEnUKKSLV9o1jFciQcfgKh71xrQRvrUqKwLYS9ss2dUErk1pA2XNOmUhR/iEzBORKBSIqS7dD97Hl8UBeEu2Xs9bK3NrgenIOghbdBmy3uZzbrMPt7bIZ+0N3sgnNIjug+1Oh0C1shzmhDkKVcm4kWArR/XWVMwbYgiZmp0nlvtofKzcYIhmoZXdRyfqWUdrKNCZ2nCNfPRlDHx4nS+/XAadnh87LOQcgeepGd+X8aMbL6VOAJEZz3EoymSDAIp4dw8VXa7iltzSmji5Vufn+lW/Ym3WycSbe4rdJ9IOUNSfZuts9NslUvsodJIbuy0o2IYOD3IpxPEeHgUjcmht2TwFetu77WraKBte4TTnVB9+rCpV33xWUUaRdcvtgY+ytl0L0/cdCW04I23ZNd0H+fspokwwmc7bT5eqfcPv72yvk/'),		
 		this.addDataEntry('table', 180, 140, 'Table', '7ZhLc5swEMc/DXcejh9X3CY9tBe707uM1qCpkBixDpBPX2GkvLBi7LgHmBw8s1okof3/tF4kL1rn9YMiRfZLUuBe9N2L1kpK7Ky8XgPnXugz6kXfvDD09c8L7x1Pg+NTvyAKBA4ZEHYDHgk/QOfpHCU23DiSjHH6kzTy0M6IZMfBtmIFyUGV7BE2ULKndoCvvWVGqKxMY884X0sulW4LKXSf2LwTFELtXPfRZRb9ADIHVI3uUjGKmemx7GLzM2BpZofNjJOUnSN9HvsigzaMEqdVic6romMswOqxaaONM6nYkxRIuNUBicLtK10qlnMi4AcQ+s4VS9oYF8rCWBz2aMydRJS5aSgTbmtTJYvfRKVgHYnknBQl23H72tOQoC6IsMvY62VvTXAOaCUq+Resk4kMFMOhMMPrYM4Wn2c567H8czRDP+hvdSkEJEekH2rn0uKEbISzVOhmorUA7Y+rjCFsC5K0k1U68dudg3m7Z4KhckZn5ZxfqKaZbNNGL1IOl89GuI5PENRb+SBo2UP0vM5B1O6c1E78QY2bWv1W4wlBnDshRhOFGITTo7j4qn3/o/Y1b9mdLYXzz5fCpTMfZ6PNx8V1pfADNa/Iv3ez3Tb/Vk5qd1OjdmEpHBHEwHdSnE+U4uBaOCaM/TPDVzG8XTFcRQOL4Q3OhUH/6sNmZP+LZywZGZy/NRn752jQv5yx3JaT4zbds2HgvpdZTRXjBE6HuvlyOd11f313/Q8='),
	 	this.createVertexTemplateEntry('text;html=1;whiteSpace=wrap;strokeColor=none;fillColor=none;overflow=fill;', 180, 180,
 			'<table border="1" width="100%" height="100%" cellpadding="4" style="width:100%;height:100%;border-collapse:collapse;">' +
 			'<tr><th align="center"><b>Title</b></th></tr>' +
 			'<tr><td align="center">Section 1.1\nSection 1.2\nSection 1.3</td></tr>' +
 			'<tr><td align="center">Section 2.1\nSection 2.2\nSection 2.3</td></tr></table>', 'HTML Table 4'),
		this.createVertexTemplateEntry('rounded=1;whiteSpace=wrap;html=1;strokeWidth=2;fillWeight=4;hachureGap=8;hachureAngle=45;fillColor=#1ba1e2;sketch=1;', 120, 60, '', 'Rectangle Sketch', true, null, 'rectangle rect box text sketch comic retro'),
		this.createVertexTemplateEntry('ellipse;whiteSpace=wrap;html=1;strokeWidth=2;fillWeight=2;hachureGap=8;fillColor=#990000;fillStyle=dots;sketch=1;', 120, 60, '', 'Ellipse Sketch', true, null, 'ellipse oval sketch comic retro'),
		this.createVertexTemplateEntry('rhombus;whiteSpace=wrap;html=1;strokeWidth=2;fillWeight=-1;hachureGap=8;fillStyle=cross-hatch;fillColor=#006600;sketch=1;', 120, 60, '', 'Diamond Sketch', true, null, 'diamond sketch comic retro'),
	 	this.createVertexTemplateEntry('html=1;whiteSpace=wrap;shape=isoCube2;backgroundOutline=1;isoAngle=15;', 90, 100, '', 'Isometric Cube', true, null, 'cube box iso isometric'),
	 	this.createVertexTemplateEntry('html=1;whiteSpace=wrap;aspect=fixed;shape=isoRectangle;', 150, 90, '', 'Isometric Square', true, null, 'rectangle rect box iso isometric'),
	 	this.createEdgeTemplateEntry('edgeStyle=isometricEdgeStyle;endArrow=none;html=1;', 50, 100, '', 'Isometric Edge 1'),
	 	this.createEdgeTemplateEntry('edgeStyle=isometricEdgeStyle;endArrow=none;html=1;elbow=vertical;', 50, 100, '', 'Isometric Edge 2'),
	 	this.createVertexTemplateEntry('shape=curlyBracket;whiteSpace=wrap;html=1;rounded=1;labelPosition=left;verticalLabelPosition=middle;align=right;verticalAlign=middle;', 20, 120, '', 'Left Curly Bracket'),
		this.createVertexTemplateEntry('shape=curlyBracket;whiteSpace=wrap;html=1;rounded=1;flipH=1;labelPosition=right;verticalLabelPosition=middle;align=left;verticalAlign=middle;', 20, 120, '', 'Right Curly Bracket'),
	 	this.createVertexTemplateEntry('line;strokeWidth=2;html=1;', 160, 10, '', 'Horizontal Line'),
	 	this.createVertexTemplateEntry('line;strokeWidth=2;direction=south;html=1;', 10, 160, '', 'Vertical Line'),
	 	this.createVertexTemplateEntry('line;strokeWidth=4;html=1;perimeter=backbonePerimeter;points=[];outlineConnect=0;', 160, 10, '', 'Horizontal Backbone', false, null, 'backbone bus network'),
	 	this.createVertexTemplateEntry('line;strokeWidth=4;direction=south;html=1;perimeter=backbonePerimeter;points=[];outlineConnect=0;', 10, 160, '', 'Vertical Backbone', false, null, 'backbone bus network'),
	 	this.createVertexTemplateEntry('shape=crossbar;whiteSpace=wrap;html=1;rounded=1;', 120, 20, '', 'Horizontal Crossbar', false, null, 'crossbar distance measure dimension unit'),
		this.createVertexTemplateEntry('shape=crossbar;whiteSpace=wrap;html=1;rounded=1;direction=south;', 20, 120, '', 'Vertical Crossbar', false, null, 'crossbar distance measure dimension unit'),
	 	this.createVertexTemplateEntry('shape=image;html=1;verticalLabelPosition=bottom;verticalAlign=top;imageAspect=1;aspect=fixed;image=' + this.gearImage, 52, 61, '', 'Image (Fixed Aspect)', false, null, 'fixed image icon symbol'),
	 	this.createVertexTemplateEntry('shape=image;html=1;verticalLabelPosition=bottom;verticalAlign=top;imageAspect=0;image=' + this.gearImage, 50, 60, '', 'Image (Variable Aspect)', false, null, 'strechted image icon symbol'),
	 	this.createVertexTemplateEntry('icon;html=1;image=' + this.gearImage, 60, 60, 'Icon', 'Icon', false, null, 'icon image symbol'),
	 	this.createVertexTemplateEntry('label;whiteSpace=wrap;html=1;image=' + this.gearImage, 140, 60, 'Label', 'Label 1', null, null, 'label image icon symbol'),
	 	this.createVertexTemplateEntry('label;whiteSpace=wrap;html=1;align=center;verticalAlign=bottom;spacingLeft=0;spacingBottom=4;imageAlign=center;imageVerticalAlign=top;image=' + this.gearImage, 120, 80, 'Label', 'Label 2', null, null, 'label image icon symbol'),
		this.addEntry('shape group container', function()
		{
		    var cell = new mxCell('Label', new mxGeometry(0, 0, 160, 70),
				'html=1;whiteSpace=wrap;container=1;recursiveResize=0;collapsible=0;');
		    cell.vertex = true;
		    
			var symbol = new mxCell('', new mxGeometry(20, 20, 20, 30), 'triangle;html=1;whiteSpace=wrap;');
			symbol.vertex = true;
			cell.insert(symbol);
	    	
    		return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Shape Group');
		}),
	 	this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;left=0;right=0;fillColor=none;', 120, 60, '', 'Partial Rectangle'),
		this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;bottom=0;top=0;fillColor=none;', 120, 60, '', 'Partial Rectangle'),
		this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;bottom=1;right=1;left=1;top=0;fillColor=none;routingCenterX=-0.5;', 120, 60, '', 'Partial Rectangle'),
		this.createVertexTemplateEntry('shape=waypoint;sketch=0;fillStyle=solid;size=6;pointerEvents=1;points=[];fillColor=none;resizable=0;rotatable=0;perimeter=centerPerimeter;snapToPoint=1;', 20, 20, '', 'Waypoint'),
		this.createEdgeTemplateEntry('edgeStyle=segmentEdgeStyle;endArrow=classic;html=1;curved=0;rounded=0;endSize=8;startSize=8;', 50, 50, '', 'Manual Line', null, lineTags + 'manual'),
	 	this.createEdgeTemplateEntry('shape=filledEdge;curved=0;rounded=0;fixDash=1;endArrow=none;strokeWidth=10;fillColor=#ffffff;edgeStyle=orthogonalEdgeStyle;html=1;', 60, 40, '', 'Filled Edge'),
	 	this.createEdgeTemplateEntry('shape=taperedArrow;startWidth=12;endWidth=2;endArrow=block;endFill=1;html=1;', 60, 40, '', 'Tapered Arrow', null, lineTags + 'tapered taper arrow wedge'),
	 	this.createEdgeTemplateEntry('edgeStyle=elbowEdgeStyle;elbow=horizontal;endArrow=classic;html=1;curved=0;rounded=0;endSize=8;startSize=8;', 50, 50, '', 'Horizontal Elbow', null, lineTags + 'elbow horizontal'),
	 	this.createEdgeTemplateEntry('edgeStyle=elbowEdgeStyle;elbow=vertical;endArrow=classic;html=1;curved=0;rounded=0;endSize=8;startSize=8;', 50, 50, '', 'Vertical Elbow', null, lineTags + 'elbow vertical'),
	 	this.createVertexTemplateEntry('shape=mxgraph.basic.arc;html=1;startAngle=0.3;endAngle=0.1;endArrow=classic;endFill=1;', 50, 50, '', 'Arc', null, null, 'arc curve'),
	 	this.createVertexTemplateEntry('shape=zigzag;html=1;fillColor=none;', 160, 20, '', 'Zigzag', null, null, 'zigzag wave sawtooth')
	];

	this.addPaletteFunctions('misc', mxResources.get('misc'), (expand != null) ? expand : true, fns);
	this.setCurrentSearchEntryLibrary();
};
/**
 * Adds the container palette to the sidebar.
 */
Sidebar.prototype.addAdvancedPalette = function(expand)
{
	this.setCurrentSearchEntryLibrary('general', 'advanced');
	this.addPaletteFunctions('advanced', mxResources.get('advanced'), (expand != null) ? expand : false, this.createAdvancedShapes());
	this.setCurrentSearchEntryLibrary();
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.addBasicPalette = function(dir)
{
	this.setCurrentSearchEntryLibrary('basic');
	this.addStencilPalette('basic', mxResources.get('basic'), dir + '/basic.xml',
		';whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=2',
		null, null, null, null, [
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;top=0;bottom=0;fillColor=none;', 120, 60, '', 'Partial Rectangle'),
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;right=0;top=0;bottom=0;fillColor=none;routingCenterX=-0.5;', 120, 60, '', 'Partial Rectangle'),
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;bottom=0;right=0;fillColor=none;', 120, 60, '', 'Partial Rectangle'),
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;top=0;left=0;fillColor=none;', 120, 60, '', 'Partial Rectangle')
	]);
	this.setCurrentSearchEntryLibrary();
};

/**
 * Adds the container palette to the sidebar.
 */
Sidebar.prototype.createAdvancedShapes = function()
{
	// Avoids having to bind all functions to "this"
	var sb = this;

	// Reusable cells
	var field = new mxCell('List Item', new mxGeometry(0, 0, 60, 26), 'text;strokeColor=none;fillColor=none;align=left;verticalAlign=top;spacingLeft=4;spacingRight=4;overflow=hidden;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;whiteSpace=wrap;html=1;');
	field.vertex = true;

	return [
		this.createVertexTemplateEntry('shape=ext;double=1;rounded=0;whiteSpace=wrap;html=1;', 120, 80, '', 'Double Rectangle', null, null, 'rect rectangle box double'),
	 	this.createVertexTemplateEntry('shape=ext;double=1;rounded=1;whiteSpace=wrap;html=1;', 120, 80, '', 'Double Rounded Rectangle', null, null, 'rounded rect rectangle box double'),
 		this.createVertexTemplateEntry('ellipse;shape=doubleEllipse;whiteSpace=wrap;html=1;', 100, 60, '', 'Double Ellipse', null, null, 'oval ellipse start end state double'),
		this.createVertexTemplateEntry('shape=ext;double=1;whiteSpace=wrap;html=1;aspect=fixed;', 80, 80, '', 'Double Square', null, null, 'double square'),
		this.createVertexTemplateEntry('ellipse;shape=doubleEllipse;whiteSpace=wrap;html=1;aspect=fixed;', 80, 80, '', 'Double Circle', null, null, 'double circle'),
	 	this.createVertexTemplateEntry('shape=tapeData;whiteSpace=wrap;html=1;perimeter=ellipsePerimeter;', 80, 80, '', 'Tape Data'),
	 	this.createVertexTemplateEntry('shape=manualInput;boundedLbl=1;whiteSpace=wrap;html=1;', 80, 80, '', 'Manual Input'),
	 	this.createVertexTemplateEntry('shape=loopLimit;whiteSpace=wrap;html=1;', 100, 80, '', 'Loop Limit'),
	 	this.createVertexTemplateEntry('shape=offPageConnector;whiteSpace=wrap;html=1;', 80, 80, '', 'Off Page Connector'),
	 	this.createVertexTemplateEntry('shape=delay;whiteSpace=wrap;html=1;', 80, 40, '', 'Delay'),
	 	this.createVertexTemplateEntry('shape=display;whiteSpace=wrap;html=1;', 80, 40, '', 'Display'),
	 	this.createVertexTemplateEntry('shape=singleArrow;direction=west;whiteSpace=wrap;html=1;', 100, 60, '', 'Arrow Left'),
	 	this.createVertexTemplateEntry('shape=singleArrow;whiteSpace=wrap;html=1;', 100, 60, '', 'Arrow Right'),
	 	this.createVertexTemplateEntry('shape=singleArrow;direction=north;whiteSpace=wrap;html=1;', 60, 100, '', 'Arrow Up'),
	 	this.createVertexTemplateEntry('shape=singleArrow;direction=south;whiteSpace=wrap;html=1;', 60, 100, '', 'Arrow Down'),
	 	this.createVertexTemplateEntry('shape=doubleArrow;whiteSpace=wrap;html=1;', 100, 60, '', 'Double Arrow'),
	 	this.createVertexTemplateEntry('shape=doubleArrow;direction=south;whiteSpace=wrap;html=1;', 60, 100, '', 'Double Arrow Vertical', null, null, 'double arrow'),
	 	this.createVertexTemplateEntry('shape=actor;whiteSpace=wrap;html=1;', 40, 60, '', 'User', null, null, 'user person human'),
	 	this.createVertexTemplateEntry('shape=cross;whiteSpace=wrap;html=1;', 80, 80, '', 'Cross'),
	 	this.createVertexTemplateEntry('shape=corner;whiteSpace=wrap;html=1;', 80, 80, '', 'Corner'),
	 	this.createVertexTemplateEntry('shape=tee;whiteSpace=wrap;html=1;', 80, 80, '', 'Tee'),
	 	this.createVertexTemplateEntry('shape=datastore;whiteSpace=wrap;html=1;', 60, 60, '', 'Data Store', null, null, 'data store cylinder database'),
	 	this.createVertexTemplateEntry('shape=orEllipse;perimeter=ellipsePerimeter;whiteSpace=wrap;html=1;backgroundOutline=1;', 80, 80, '', 'Or', null, null, 'or circle oval ellipse'),
	 	this.createVertexTemplateEntry('shape=sumEllipse;perimeter=ellipsePerimeter;whiteSpace=wrap;html=1;backgroundOutline=1;', 80, 80, '', 'Sum', null, null, 'sum circle oval ellipse'),
	 	this.createVertexTemplateEntry('shape=lineEllipse;perimeter=ellipsePerimeter;whiteSpace=wrap;html=1;backgroundOutline=1;', 80, 80, '', 'Ellipse with horizontal divider', null, null, 'circle oval ellipse'),
	 	this.createVertexTemplateEntry('shape=lineEllipse;line=vertical;perimeter=ellipsePerimeter;whiteSpace=wrap;html=1;backgroundOutline=1;', 80, 80, '', 'Ellipse with vertical divider', null, null, 'circle oval ellipse'),
	 	this.createVertexTemplateEntry('shape=sortShape;perimeter=rhombusPerimeter;whiteSpace=wrap;html=1;', 80, 80, '', 'Sort', null, null, 'sort'),
	 	this.createVertexTemplateEntry('shape=collate;whiteSpace=wrap;html=1;', 80, 80, '', 'Collate', null, null, 'collate'),
	 	this.createVertexTemplateEntry('shape=switch;whiteSpace=wrap;html=1;', 60, 60, '', 'Switch', null, null, 'switch router'),

		this.addEntry('process bar', function()
		{
			return sb.createVertexTemplateFromData('1ZVNboMwEIVP42UlfkqabCFtNokUiRO4MAWrBiPbKZDTd2xMSJMgVaraKgskzxs/e+YbS5AwqbqNpE25EzlwEj6TMJFC6GFVdQlwTgKP5SRckyDw8CPBy0zWt1mvoRJq/R1DMBg+KD/AoOylyEApFGMqh6zSPXdZ1bKK0xqjOCsZz7e0Fwdzk9I0ex+juBSSHUWtKTa09lF4Y5wngguJcS2sf9qTGq/bKEGxI+zHBi6lHe1Q9U7qlirthExwThvFXm2tRlFaine4uNYWGguZgxF9b5TShmasLlB78IPxfDocZqqgnBU1rjOswljjRrBaK4Mlikm0RqUtmQZzjvG0OFPTpa5GBg41SA3d7Lis5Ga1AVGBlj1uaVmuSzey1WKwlcCKcrR5w5w9qgahOHmn6ePCPYDbjyG8egyphgYV//odlLQBO3YwXTYgGV5nkRppP8U4+g7yFGflMPwOt+A2t9Hg6PSuUdfpGdUTwHOq0dPPoT7OQQ3uHepq+W9Qozmo4b1D9ZeLv6KK4fSjsbkv/6FP', 296, 100, 'Process Bar');
		}),
	 	this.createVertexTemplateEntry('swimlane;', 200, 200, 'Container', 'Container', null, null, 'container swimlane lane pool group'),
		this.addEntry('list group erd table', function()
		{
			var cell = new mxCell('List', new mxGeometry(0, 0, 140, 110),
		    	'swimlane;fontStyle=0;childLayout=stackLayout;horizontal=1;startSize=26;fillColor=none;horizontalStack=0;' +
		    	'resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=1;marginBottom=0;html=1;');
			cell.vertex = true;
			cell.insert(sb.cloneCell(field, 'Item 1'));
			cell.insert(sb.cloneCell(field, 'Item 2'));
			cell.insert(sb.cloneCell(field, 'Item 3'));
			
			return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'List');
		}),
		this.addEntry('list item entry value group erd table', function()
		{
			return sb.createVertexTemplateFromCells([sb.cloneCell(field, 'List Item')], field.geometry.width, field.geometry.height, 'List Item');
		})
	];
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.addBasicPalette = function(dir)
{
	this.setCurrentSearchEntryLibrary('basic');
	this.addStencilPalette('basic', mxResources.get('basic'), dir + '/basic.xml',
		';whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#000000;strokeWidth=2',
		null, null, null, null, [
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;top=0;bottom=0;fillColor=none;', 120, 60, '', 'Partial Rectangle'),
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;right=0;top=0;bottom=0;fillColor=none;routingCenterX=-0.5;', 120, 60, '', 'Partial Rectangle'),
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;bottom=0;right=0;fillColor=none;', 120, 60, '', 'Partial Rectangle'),
			this.createVertexTemplateEntry('shape=partialRectangle;whiteSpace=wrap;html=1;top=0;left=0;fillColor=none;', 120, 60, '', 'Partial Rectangle')
	]);
	this.setCurrentSearchEntryLibrary();
};

/**
 * Adds the general palette to the sidebar.
 */
Sidebar.prototype.addUmlPalette = function(expand)
{
	// Avoids having to bind all functions to "this"
	var sb = this;

	// Reusable cells
	var field = new mxCell('+ field: type', new mxGeometry(0, 0, 100, 26), 'text;strokeColor=none;fillColor=none;align=left;verticalAlign=top;spacingLeft=4;spacingRight=4;overflow=hidden;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;whiteSpace=wrap;html=1;');
	field.vertex = true;

	var divider = new mxCell('', new mxGeometry(0, 0, 40, 8), 'line;strokeWidth=1;fillColor=none;align=left;verticalAlign=middle;spacingTop=-1;spacingLeft=3;spacingRight=3;rotatable=0;labelPosition=right;points=[];portConstraint=eastwest;strokeColor=inherit;');
	divider.vertex = true;

	// Messages drawn from a lifeline or an activation bar are routed by
	// mxEdgeStyle.SequenceMessage, which keeps them horizontal at their own y
	// (libavoidRouting=0 keeps a current edge style with auto-routing, which
	// would otherwise be pasted onto new and inserted edges, from routing them)
	var sequenceEdgeStyle = 'edgeStyle=sequenceEdgeStyle;libavoidRouting=0;curved=0;rounded=0;';
	var sequenceNewEdgeStyle = 'newEdgeStyle={"edgeStyle":"sequenceEdgeStyle","libavoidRouting":0,"curved":0,"rounded":0};';
	var lifelineStyle = 'shape=umlLifeline;perimeter=lifelinePerimeter;whiteSpace=wrap;html=1;container=1;dropTarget=0;' +
		'collapsible=0;recursiveResize=0;outlineConnect=0;portConstraint=eastwest;' + sequenceNewEdgeStyle;
	var activationStyle = 'html=1;points=[[0,0,0,0,5],[0,1,0,0,-5],[1,0,0,0,5],[1,1,0,0,-5]];perimeter=orthogonalPerimeter;' +
		'outlineConnect=0;targetShapes=umlLifeline;portConstraint=eastwest;' + sequenceNewEdgeStyle;
	var hr = '<hr size="1" style="border-style:solid;"/>';
	
	// Default tags
	var dt = 'uml static class ';
	this.setCurrentSearchEntryLibrary('uml');
	this.setPickerShapes('uml', ['Class', 'Interface', 'Object', 'Package', 'Actor', 'Use Case',
		'Component', 'Lifeline', 'Frame', 'Boundary Object', 'Entity Object', 'Control Object',
		'Module', 'Block', 'End', 'Activation Bar']);
	
	var fns = [
   		this.createVertexTemplateEntry('html=1;whiteSpace=wrap;', 110, 50, 'Object', 'Object', null, null, dt + 'object instance'),
   		this.createVertexTemplateEntry('html=1;whiteSpace=wrap;', 110, 50, '&laquo;interface&raquo;<br><b>Name</b>', 'Interface', null, null, dt + 'interface object instance annotated annotation'),
	 	this.addEntry(dt + 'object instance', function()
		{
			var cell = new mxCell('Classname', new mxGeometry(0, 0, 160, 90),
		    	'swimlane;fontStyle=1;align=center;verticalAlign=top;childLayout=stackLayout;horizontal=1;startSize=26;horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=1;marginBottom=0;whiteSpace=wrap;html=1;');
			cell.vertex = true;
			cell.insert(field.clone());
			cell.insert(divider.clone());
			cell.insert(sb.cloneCell(field, '+ method(type): type'));
			
			return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Class'); 
		}),
		this.addEntry(dt + 'section subsection', function()
		{
			var cell = new mxCell('Classname', new mxGeometry(0, 0, 140, 110),
		    	'swimlane;fontStyle=0;childLayout=stackLayout;horizontal=1;startSize=26;fillColor=none;horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=1;marginBottom=0;whiteSpace=wrap;html=1;');
			cell.vertex = true;
			cell.insert(field.clone());
			cell.insert(field.clone());
			cell.insert(field.clone());
			
			return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Class 2');
		}),
		this.addEntry(dt + 'item member method function variable field attribute label', function()
		{
			return sb.createVertexTemplateFromCells([sb.cloneCell(field, '+ item: attribute')], field.geometry.width, field.geometry.height, 'Item 1');
		}),
   		this.addEntry(dt + 'item member method function variable field attribute label', function()
		{
   			var cell = new mxCell('item: attribute', new mxGeometry(0, 0, 120, field.geometry.height), 'label;fontStyle=0;strokeColor=none;fillColor=none;align=left;verticalAlign=top;overflow=hidden;' +
   				'spacingLeft=28;spacingRight=4;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;imageWidth=16;imageHeight=16;whiteSpace=wrap;html=1;image=' + sb.gearImage);
   			cell.vertex = true;
   			
			return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Item 2');
		}),
		this.addEntry(dt + 'divider hline line separator', function()
		{
			return sb.createVertexTemplateFromCells([divider.clone()], divider.geometry.width, divider.geometry.height, 'Divider');
		}),
		this.addEntry(dt + 'spacer space gap separator', function()
		{
			var cell = new mxCell('', new mxGeometry(0, 0, 20, 14), 'text;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingTop=-1;spacingLeft=4;spacingRight=4;rotatable=0;labelPosition=right;points=[];portConstraint=eastwest;');
			cell.vertex = true;
			
			return sb.createVertexTemplateFromCells([cell.clone()], cell.geometry.width, cell.geometry.height, 'Spacer');
		}),
		this.createVertexTemplateEntry('text;align=center;fontStyle=1;verticalAlign=middle;spacingLeft=3;spacingRight=3;strokeColor=none;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;html=1;',
			80, 26, 'Title', 'Title', null, null, dt + 'title label'),
		this.addEntry(dt + 'component', function()
		{
		    var cell = new mxCell('&laquo;Annotation&raquo;<br/><b>Component</b>', new mxGeometry(0, 0, 180, 90), 'html=1;dropTarget=0;whiteSpace=wrap;');
		    cell.vertex = true;
		    
			var symbol = new mxCell('', new mxGeometry(1, 0, 20, 20), 'shape=module;jettyWidth=8;jettyHeight=4;');
			symbol.vertex = true;
			symbol.geometry.relative = true;
			symbol.geometry.offset = new mxPoint(-27, 7);
			cell.insert(symbol);
	    	
	    	return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Component');
		}),
		this.addEntry(dt + 'component', function()
		{
		    var cell = new mxCell('<p style="margin:0px;margin-top:6px;text-align:center;"><b>Component</b></p>' +
				hr + '<p style="margin:0px;margin-left:8px;">+ Attribute1: Type<br/>+ Attribute2: Type</p>', new mxGeometry(0, 0, 180, 90),
				'align=left;overflow=fill;html=1;dropTarget=0;whiteSpace=wrap;');
		    cell.vertex = true;
		    
			var symbol = new mxCell('', new mxGeometry(1, 0, 20, 20), 'shape=component;jettyWidth=8;jettyHeight=4;');
			symbol.vertex = true;
			symbol.geometry.relative = true;
			symbol.geometry.offset = new mxPoint(-24, 4);
			cell.insert(symbol);
	    	
	    	return sb.createVertexTemplateFromCells([cell], cell.geometry.width, cell.geometry.height, 'Component with Attributes');
		}),
		this.createVertexTemplateEntry('verticalAlign=top;align=left;spacingTop=8;spacingLeft=2;spacingRight=12;shape=cube;size=10;direction=south;fontStyle=4;html=1;whiteSpace=wrap;',
			180, 120, 'Block', 'Block', null, null, dt + 'block'),
		this.createVertexTemplateEntry('shape=module;align=left;spacingLeft=20;align=center;verticalAlign=top;whiteSpace=wrap;html=1;', 100, 50, 'Module', 'Module', null, null, dt + 'module component'),
		this.createVertexTemplateEntry('shape=folder;fontStyle=1;spacingTop=10;tabWidth=40;tabHeight=14;tabPosition=left;html=1;whiteSpace=wrap;', 70, 50,
		   	'package', 'Package', null, null, dt + 'package'),
		this.createVertexTemplateEntry('verticalAlign=top;align=left;overflow=fill;html=1;whiteSpace=wrap;',
			160, 90, '<p style="margin:0px;margin-top:4px;text-align:center;text-decoration:underline;"><b>Object:Type</b></p>' + hr +
			'<p style="margin:0px;margin-left:8px;">field1 = value1<br/>field2 = value2<br>field3 = value3</p>', 'Object',
			null, null, dt + 'object instance'),
		this.createVertexTemplateEntry('verticalAlign=top;align=left;overflow=fill;html=1;whiteSpace=wrap;',180, 90,
			'<div style="box-sizing:border-box;width:100%;background:#e4e4e4;padding:2px;">Tablename</div>' +
			'<table style="width:100%;font-size:1em;" cellpadding="2" cellspacing="0">' +
			'<tr><td>PK</td><td>uniqueId</td></tr><tr><td>FK1</td><td>' +
			'foreignKey</td></tr><tr><td></td><td>fieldname</td></tr></table>', 'Entity', null, null, 'er entity table'),
		this.addEntry(dt + 'object instance', function()
		{
		    var cell = new mxCell('<p style="margin:0px;margin-top:4px;text-align:center;">' +
	    			'<b>Class</b></p>' +
					hr + '<div style="height:2px;"></div>', new mxGeometry(0, 0, 140, 60),
					'verticalAlign=top;align=left;overflow=fill;html=1;whiteSpace=wrap;');
		    cell.vertex = true;
			
			return sb.createVertexTemplateFromCells([cell.clone()], cell.geometry.width, cell.geometry.height, 'Class 3');
		}),
		this.addEntry(dt + 'object instance', function()
		{
		    var cell = new mxCell('<p style="margin:0px;margin-top:4px;text-align:center;">' +
	    			'<b>Class</b></p>' +
					hr + '<div style="height:2px;"></div>' + hr + '<div style="height:2px;"></div>', new mxGeometry(0, 0, 140, 60),
					'verticalAlign=top;align=left;overflow=fill;html=1;whiteSpace=wrap;');
		    cell.vertex = true;
			
			return sb.createVertexTemplateFromCells([cell.clone()], cell.geometry.width, cell.geometry.height, 'Class 4');
		}),
		this.addEntry(dt + 'object instance', function()
		{
		    var cell = new mxCell('<p style="margin:0px;margin-top:4px;text-align:center;">' +
	    			'<b>Class</b></p>' + hr + '<p style="margin:0px;margin-left:4px;">+ field: Type</p>' + hr +
					'<p style="margin:0px;margin-left:4px;">+ method(): Type</p>', new mxGeometry(0, 0, 160, 90),
					'verticalAlign=top;align=left;overflow=fill;html=1;whiteSpace=wrap;');
		    cell.vertex = true;
			
			return sb.createVertexTemplateFromCells([cell.clone()], cell.geometry.width, cell.geometry.height, 'Class 5');
		}),
		this.addEntry(dt + 'object instance', function()
		{
		    var cell = new mxCell('<p style="margin:0px;margin-top:4px;text-align:center;">' +
	    			'<i>&lt;&lt;Interface&gt;&gt;</i><br/><b>Interface</b></p>' +
					hr + '<p style="margin:0px;margin-left:4px;">+ field1: Type<br/>' +
					'+ field2: Type</p>' + hr + '<p style="margin:0px;margin-left:4px;">' +
					'+ method1(Type): Type<br/>' +
					'+ method2(Type, Type): Type</p>', new mxGeometry(0, 0, 190, 140),
					'verticalAlign=top;align=left;overflow=fill;html=1;whiteSpace=wrap;');
		    cell.vertex = true;
			
			return sb.createVertexTemplateFromCells([cell.clone()], cell.geometry.width, cell.geometry.height, 'Interface 2');
		}),
		this.createVertexTemplateEntry('shape=providedRequiredInterface;html=1;verticalLabelPosition=bottom;sketch=0;', 20, 20, '', 'Provided/Required Interface', null, null, 'uml provided required interface lollipop notation'),
		this.createVertexTemplateEntry('shape=requiredInterface;html=1;verticalLabelPosition=bottom;sketch=0;', 10, 20, '', 'Required Interface', null, null, 'uml required interface lollipop notation'),
		this.addDataEntry('uml lollipop notation provided required interface', 20, 20, 'Required Interface',
			'jVNBbuMwDHyN7o6N9L5x2l66QIEe9qy1GUutIhoUHTt9/VKWNo7bBu0hgDicYeQZSlX1cXok3Zvf2IJT1b2qakLkdDpONTinysK2qtqrsizkp8qHG93N3C16TeD5J4IyCU7aDZCQBAQ+uwwQDr6FyC9UtUNigx167Z4QewE3Ar4C8/nFvkeFHhgFMnx0uQu+/UWEo5RGu0NtqYmzI/5gncuDpcoT7qQKTPgGf2zLJk8Jb8CNyeQDes7sTSl1M9BpvmJkpi+AtoOVKaypg2xK9dmnmZVNegQ8AtNZKAROsz2tR+mQyu7Cu0if0crEspiyv9ukOKdyu9YHHKiBLFlSksPVHRZozu7rHKvvcxSB7UM0fjSW4aXXTeyMsnvrvLSznZdzI94ARSD00ESbDnaKLu8OEluNDqW59+jhEtgHkCDYd/13vkGMrQey8lFxaJ7+vCA7QtZ8xdbO4ThvTvivj07N3m13aruP6ziws17+1/t0xWUBTkAM0813cSPvMa9cZKSnUxiwneE19tUGrOJbspJyec8p2uvn/g8='),
		this.addEntry('uml lollipop notation provided required interface', function()
		{
			return sb.createVertexTemplateFromData('zZRNb9swDIZ/je6O3ey+OGsvG1Cgh55Vm7G0KqJB07HTXz/KUux4bbBdNvRgQHz5IYmPTFWUx/GBdGt+YA1OFd9UURIix9VxLME5lWe2VsVe5Xkmn8rvb3g3kzdrNYHnv0koYsJJux6iEoWOzy4JhL2vIcRnqtghscEGvXbfEVsRNyL+BObzk30LGbpnFMnw0SUv+PorEQ5iGu0OpaUq1A76vXUuFRYrVfgiVseEr/BsazapSvcKXJkUHA8JdQOre7OmBtK97963YopKfXgAPALTWUIInGZ7WpfSXTSbOW5OfUQrFfNsTBvFDmfnaG7X+R32VEFKWUDI4uoMizTh+RhV/n9RoWz0DtIKQroakJVbAD21urK+Sc6I4oZzYb35NDT/Nb67P+OTBNt24dcYjGUIPQueQabDGpN2tvGyrqQZQEHoWqhCXw52DPx3B2FWokNx7j16mH+p30SCzr7pl+kEAUV7ATZXf1yUHSFrvorWzuEwPZjukh86NfVuu1PbfXiFPTvrZV/v4xE3M/ETEMN4c3LdAHxJSKSGNCOClP5EA7YxvNY+egErmgs6MZcBHElfz+df',
				40, 10, 'Lollipop Notation');
		}),
		this.createVertexTemplateEntry('shape=umlBoundary;whiteSpace=wrap;html=1;', 100, 80, 'Boundary Object', 'Boundary Object', null, null, 'uml boundary object'),
		this.createVertexTemplateEntry('ellipse;shape=umlEntity;whiteSpace=wrap;html=1;', 80, 80, 'Entity Object', 'Entity Object', null, null, 'uml entity object'),
		this.createVertexTemplateEntry('ellipse;shape=umlControl;whiteSpace=wrap;html=1;', 70, 80, 'Control Object', 'Control Object', null, null, 'uml control object'),
		this.createVertexTemplateEntry('shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;html=1;', 30, 60, 'Actor', 'Actor', false, null, 'uml actor'),
		this.createVertexTemplateEntry('ellipse;whiteSpace=wrap;html=1;', 140, 70, 'Use Case', 'Use Case', null, null, 'uml use case usecase'),
		this.addEntry('uml activity state start', function()
		{
	    	var cell = new mxCell('', new mxGeometry(0, 0, 30, 30),
	    		'ellipse;html=1;shape=startState;fillColor=#000000;strokeColor=#ff0000;');
	    	cell.vertex = true;
	    	
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'edgeStyle=orthogonalEdgeStyle;html=1;verticalAlign=bottom;endArrow=open;endSize=8;strokeColor=#ff0000;');
			edge.geometry.setTerminalPoint(new mxPoint(15, 90), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
			cell.insertEdge(edge, true);
	    	
			return sb.createVertexTemplateFromCells([cell, edge], 30, 90, 'Start');
		}),
		this.addEntry('uml activity state', function()
		{
			var cell = new mxCell('Activity', new mxGeometry(0, 0, 120, 40),
				'rounded=1;whiteSpace=wrap;html=1;arcSize=40;fontColor=#000000;fillColor=#ffffc0;strokeColor=#ff0000;');
			cell.vertex = true;
			
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'edgeStyle=orthogonalEdgeStyle;html=1;verticalAlign=bottom;endArrow=open;endSize=8;strokeColor=#ff0000;');
			edge.geometry.setTerminalPoint(new mxPoint(60, 100), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
			cell.insertEdge(edge, true);
			
			return sb.createVertexTemplateFromCells([cell, edge], 120, 100, 'Activity');
		}),
		this.addEntry('uml activity composite state', function()
		{
			var cell = new mxCell('Composite State', new mxGeometry(0, 0, 160, 60),
					'swimlane;fontStyle=1;align=center;verticalAlign=middle;childLayout=stackLayout;horizontal=1;startSize=30;horizontalStack=0;resizeParent=0;resizeLast=1;container=0;fontColor=#000000;collapsible=0;rounded=1;arcSize=30;strokeColor=#ff0000;fillColor=#ffffc0;swimlaneFillColor=#ffffc0;dropTarget=0;');
			cell.vertex = true;
			
			var cell1 = new mxCell('Subtitle', new mxGeometry(0, 0, 200, 26), 'text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;spacingLeft=4;spacingRight=4;whiteSpace=wrap;overflow=hidden;rotatable=0;fontColor=#000000;');
			cell1.vertex = true;
			cell.insert(cell1);
			
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'edgeStyle=orthogonalEdgeStyle;html=1;verticalAlign=bottom;endArrow=open;endSize=8;strokeColor=#ff0000;');
			edge.geometry.setTerminalPoint(new mxPoint(80, 120), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
			cell.insertEdge(edge, true);
			
			return sb.createVertexTemplateFromCells([cell, edge], 160, 120, 'Composite State');
		}),
		this.addEntry('uml activity condition', function()
		{
	    	var cell = new mxCell('Condition', new mxGeometry(0, 0, 80, 40), 'rhombus;whiteSpace=wrap;html=1;fontColor=#000000;fillColor=#ffffc0;strokeColor=#ff0000;');
	    	cell.vertex = true;
	    	
			var edge1 = new mxCell('no', new mxGeometry(0, 0, 0, 0), 'edgeStyle=orthogonalEdgeStyle;html=1;align=left;verticalAlign=bottom;endArrow=open;endSize=8;strokeColor=#ff0000;');
			edge1.geometry.setTerminalPoint(new mxPoint(180, 20), false);
			edge1.geometry.relative = true;
			edge1.geometry.x = -1;
			edge1.edge = true;
			
			cell.insertEdge(edge1, true);
	    	
			var edge2 = new mxCell('yes', new mxGeometry(0, 0, 0, 0), 'edgeStyle=orthogonalEdgeStyle;html=1;align=left;verticalAlign=top;endArrow=open;endSize=8;strokeColor=#ff0000;');
			edge2.geometry.setTerminalPoint(new mxPoint(40, 100), false);
			edge2.geometry.relative = true;
			edge2.geometry.x = -1;
			edge2.edge = true;
			
			cell.insertEdge(edge2, true);
			
			return sb.createVertexTemplateFromCells([cell, edge1, edge2], 180, 100, 'Condition');
		}),
		this.addEntry('uml activity fork join', function()
		{
	    	var cell = new mxCell('', new mxGeometry(0, 0, 200, 10), 'shape=line;html=1;strokeWidth=6;strokeColor=#ff0000;');
	    	cell.vertex = true;
			
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'edgeStyle=orthogonalEdgeStyle;html=1;verticalAlign=bottom;endArrow=open;endSize=8;strokeColor=#ff0000;');
			edge.geometry.setTerminalPoint(new mxPoint(100, 80), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
			cell.insertEdge(edge, true);
		
			return sb.createVertexTemplateFromCells([cell, edge], 200, 80, 'Fork/Join');
		}),
		this.createVertexTemplateEntry('ellipse;html=1;shape=endState;fillColor=#000000;strokeColor=#ff0000;', 30, 30, '', 'End', null, null, 'uml activity state end'),
		this.createVertexTemplateEntry(lifelineStyle, 100, 300, ':Object', 'Lifeline', null, null, 'uml sequence participant lifeline'),
		this.createVertexTemplateEntry(lifelineStyle + 'participant=umlActor;', 20, 300, '', 'Actor Lifeline', null, null, 'uml sequence participant lifeline actor'),
		this.createVertexTemplateEntry(lifelineStyle + 'participant=umlBoundary;', 50, 300, '', 'Boundary Lifeline', null, null, 'uml sequence participant lifeline boundary'),
		this.createVertexTemplateEntry(lifelineStyle + 'participant=umlEntity;', 40, 300, '', 'Entity Lifeline', null, null, 'uml sequence participant lifeline entity'),
		this.createVertexTemplateEntry(lifelineStyle + 'participant=umlControl;', 40, 300, '', 'Control Lifeline', null, null, 'uml sequence participant lifeline control'),
		this.createVertexTemplateEntry('shape=umlFrame;whiteSpace=wrap;html=1;pointerEvents=0;', 300, 200, 'frame', 'Frame', null, null, 'uml sequence frame'),
		this.createVertexTemplateEntry('shape=umlDestroy;whiteSpace=wrap;html=1;strokeWidth=3;targetShapes=umlLifeline;',
			30, 30, '', 'Destruction', null, null, 'uml sequence destruction destroy'),
		this.addEntry('uml sequence invoke invocation call activation bar', function()
		{
	    	var cell = new mxCell('', new mxGeometry(0, 0, 10, 80), activationStyle);
	    	cell.vertex = true;
	    	
			var edge = new mxCell('dispatch', new mxGeometry(0, 0, 0, 0), 'html=1;verticalAlign=bottom;startArrow=oval;endArrow=block;' +
				'startSize=8;' + sequenceEdgeStyle + 'entryX=0;entryY=0;entryDx=0;entryDy=5;');
			edge.geometry.setTerminalPoint(new mxPoint(-70, 5), true);
			edge.geometry.relative = true;
			edge.edge = true;
			
			cell.insertEdge(edge, false);
	
			return sb.createVertexTemplateFromCells([cell, edge], 10, 80, 'Found Message');
		}),
		this.addEntry('uml sequence invoke call delegation synchronous invocation activation bar', function()
		{
	    	var cell = new mxCell('', new mxGeometry(0, 0, 10, 80), activationStyle);
	    	cell.vertex = true;
	    	
			var edge1 = new mxCell('dispatch', new mxGeometry(0, 0, 0, 0), 'html=1;verticalAlign=bottom;endArrow=block;' +
				sequenceEdgeStyle + 'entryX=0;entryY=0;entryDx=0;entryDy=5;');
			edge1.geometry.setTerminalPoint(new mxPoint(-70, 5), true);
			edge1.geometry.relative = true;
			edge1.edge = true;

			cell.insertEdge(edge1, false);
			
			var edge2 = new mxCell('return', new mxGeometry(0, 0, 0, 0), 'html=1;verticalAlign=bottom;endArrow=open;dashed=1;' +
				'endSize=8;' + sequenceEdgeStyle + 'exitX=0;exitY=1;exitDx=0;exitDy=-5;');
			edge2.geometry.setTerminalPoint(new mxPoint(-70, 75), false);
			edge2.geometry.relative = true;
			edge2.edge = true;
			
			cell.insertEdge(edge2, true);
			
			return sb.createVertexTemplateFromCells([cell, edge1, edge2], 10, 80, 'Synchronous Invocation');
		}),
		this.addEntry('uml sequence self call recursion delegation activation bar', function()
		{
	    	var cell = new mxCell('', new mxGeometry(-5, 20, 10, 40), activationStyle);
	    	cell.vertex = true;
	
			// A self-call leaves at the y of the first waypoint and returns at
			// the y of the second (see mxEdgeStyle.SequenceMessage)
			var edge = new mxCell('self call', new mxGeometry(0, 0, 0, 0), 'html=1;align=left;spacingLeft=2;endArrow=block;' +
				sequenceEdgeStyle);
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.points = [new mxPoint(30, 0), new mxPoint(30, 30)];
			edge.geometry.relative = true;
			edge.edge = true;
			
			cell.insertEdge(edge, false);
	
			return sb.createVertexTemplateFromCells([cell, edge], 10, 60, 'Self Call');
		}),
		this.addEntry('uml sequence invoke call delegation callback activation bar', function()
		{
			var cell = new mxCell('', new mxGeometry(0, 0, 10, 80), activationStyle);
			cell.vertex = true;

			var edge1 = new mxCell('callback', new mxGeometry(0, 0, 0, 0), 'html=1;verticalAlign=bottom;endArrow=block;' +
				sequenceEdgeStyle + 'entryX=1;entryY=0;entryDx=0;entryDy=5;');
			edge1.geometry.setTerminalPoint(new mxPoint(80, 5), true);
			edge1.geometry.relative = true;
			edge1.edge = true;

			cell.insertEdge(edge1, false);

			var edge2 = new mxCell('return', new mxGeometry(0, 0, 0, 0), 'html=1;verticalAlign=bottom;endArrow=open;dashed=1;' +
				'endSize=8;' + sequenceEdgeStyle + 'exitX=1;exitY=1;exitDx=0;exitDy=-5;');
			edge2.geometry.setTerminalPoint(new mxPoint(80, 75), false);
			edge2.geometry.relative = true;
			edge2.edge = true;

			cell.insertEdge(edge2, true);

			return sb.createVertexTemplateFromCells([cell, edge1, edge2], 10, 80, 'Callback');

		}),
		this.createVertexTemplateEntry(activationStyle, 10, 80, '', 'Activation Bar', null, null, 'uml sequence activation bar'),
	 	this.createEdgeTemplateEntry('html=1;verticalAlign=bottom;startArrow=oval;startFill=1;endArrow=block;startSize=8;' +
		 	sequenceEdgeStyle, 60, 0, 'dispatch', 'Found Message 1', null, 'uml sequence message call invoke dispatch'),
	 	this.createEdgeTemplateEntry('html=1;verticalAlign=bottom;startArrow=circle;startFill=1;endArrow=open;startSize=6;endSize=8;' +
			 sequenceEdgeStyle, 80, 0, 'dispatch', 'Found Message 2', null, 'uml sequence message call invoke dispatch'),
	 	this.createEdgeTemplateEntry('html=1;verticalAlign=bottom;endArrow=block;' + sequenceEdgeStyle,
			80, 0, 'dispatch', 'Message', null, 'uml sequence message call invoke dispatch'),
		this.addEntry('uml sequence return message', function()
		{
			var edge = new mxCell('return', new mxGeometry(0, 0, 0, 0), 'html=1;verticalAlign=bottom;' +
				'endArrow=open;dashed=1;endSize=8;' + sequenceEdgeStyle);
			edge.geometry.setTerminalPoint(new mxPoint(80, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
			return sb.createEdgeTemplateFromCells([edge], 80, 0, 'Return');
		}),
		this.addEntry('uml relation', function()
		{
			var edge = new mxCell('name', new mxGeometry(0, 0, 0, 0), 'endArrow=block;endFill=1;html=1;edgeStyle=orthogonalEdgeStyle;align=left;verticalAlign=top;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(160, 0), false);
			edge.geometry.relative = true;
			edge.geometry.x = -1;
			edge.edge = true;
			
	    	var cell = new mxCell('1', new mxGeometry(-1, 0, 0, 0), 'edgeLabel;resizable=0;html=1;align=left;verticalAlign=bottom;' +
				Graph.createInheritedLabelStyle());
	    	cell.geometry.relative = true;
	    	cell.setConnectable(false);
	    	cell.vertex = true;
	    	edge.insert(cell);
	    	
			return sb.createEdgeTemplateFromCells([edge], 160, 0, 'Relation 1');
		}),
		this.addEntry('uml association', function()
		{
			var edge = new mxCell('', new mxGeometry(0, 0, 0, 0), 'endArrow=none;html=1;edgeStyle=orthogonalEdgeStyle;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(160, 0), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
	    	var cell1 = new mxCell('parent', new mxGeometry(-1, 0, 0, 0), 'edgeLabel;resizable=0;html=1;align=left;verticalAlign=bottom;' +
				Graph.createInheritedLabelStyle());
	    	cell1.geometry.relative = true;
	    	cell1.setConnectable(false);
	    	cell1.vertex = true;
	    	edge.insert(cell1);
			
	    	var cell2 = new mxCell('child', new mxGeometry(1, 0, 0, 0), 'edgeLabel;resizable=0;html=1;align=right;verticalAlign=bottom;' +
				Graph.createInheritedLabelStyle());
	    	cell2.geometry.relative = true;
	    	cell2.setConnectable(false);
	    	cell2.vertex = true;
	    	edge.insert(cell2);
	    	
			return sb.createEdgeTemplateFromCells([edge], 160, 0, 'Association 1');
		}),
		this.addEntry('uml aggregation', function()
		{
			var edge = new mxCell('1', new mxGeometry(0, 0, 0, 0), 'endArrow=open;html=1;endSize=12;startArrow=diamondThin;startSize=14;startFill=0;edgeStyle=orthogonalEdgeStyle;align=left;verticalAlign=bottom;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(160, 0), false);
			edge.geometry.relative = true;
			edge.geometry.x = -1;
			edge.geometry.y = 3;
			edge.edge = true;
		
			return sb.createEdgeTemplateFromCells([edge], 160, 0, 'Aggregation 1');
		}),
		this.addEntry('uml composition', function()
		{
			var edge = new mxCell('1', new mxGeometry(0, 0, 0, 0), 'endArrow=open;html=1;endSize=12;startArrow=diamondThin;startSize=14;startFill=1;edgeStyle=orthogonalEdgeStyle;align=left;verticalAlign=bottom;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(160, 0), false);
			edge.geometry.relative = true;
			edge.geometry.x = -1;
			edge.geometry.y = 3;
			edge.edge = true;
			
			return sb.createEdgeTemplateFromCells([edge], 160, 0, 'Composition 1');
		}),
		this.addEntry('uml relation', function()
		{
			var edge = new mxCell('Relation', new mxGeometry(0, 0, 0, 0), 'endArrow=open;html=1;endSize=12;startArrow=diamondThin;startSize=14;startFill=0;edgeStyle=orthogonalEdgeStyle;');
			edge.geometry.setTerminalPoint(new mxPoint(0, 0), true);
			edge.geometry.setTerminalPoint(new mxPoint(160, 0), false);
			edge.geometry.relative = true;
			edge.edge = true;
			
	    	var cell1 = new mxCell('0..n', new mxGeometry(-1, 0, 0, 0), 'edgeLabel;resizable=0;html=1;align=left;verticalAlign=top;' +
				Graph.createInheritedLabelStyle());
	    	cell1.geometry.relative = true;
	    	cell1.setConnectable(false);
	    	cell1.vertex = true;
	    	edge.insert(cell1);
			
	    	var cell2 = new mxCell('1', new mxGeometry(1, 0, 0, 0), 'edgeLabel;resizable=0;html=1;align=right;verticalAlign=top;' +
				Graph.createInheritedLabelStyle());
	    	cell2.geometry.relative = true;
	    	cell2.setConnectable(false);
	    	cell2.vertex = true;
	    	edge.insert(cell2);
	    	
			return sb.createEdgeTemplateFromCells([edge], 160, 0, 'Relation 2');
		}),
		this.createEdgeTemplateEntry('endArrow=open;endSize=12;dashed=1;html=1;', 160, 0, 'Use', 'Dependency', null, 'uml dependency use'),
		this.createEdgeTemplateEntry('endArrow=block;endSize=16;endFill=0;html=1;', 160, 0, 'Extends', 'Generalization', null, 'uml generalization extend'),
	 	this.createEdgeTemplateEntry('endArrow=block;startArrow=block;endFill=1;startFill=1;html=1;', 160, 0, '', 'Association 2', null, 'uml association'),
	 	this.createEdgeTemplateEntry('endArrow=open;startArrow=circlePlus;endFill=0;startFill=0;endSize=8;html=1;', 160, 0, '', 'Inner Class', null, 'uml inner class'),
	 	this.createEdgeTemplateEntry('endArrow=open;startArrow=cross;endFill=0;startFill=0;endSize=8;startSize=10;html=1;', 160, 0, '', 'Terminate', null, 'uml terminate'),
	 	this.createEdgeTemplateEntry('endArrow=block;dashed=1;endFill=0;endSize=12;html=1;', 160, 0, '', 'Implementation', null, 'uml realization implementation'),
	 	this.createEdgeTemplateEntry('endArrow=diamondThin;endFill=0;endSize=24;html=1;', 160, 0, '', 'Aggregation 2', null, 'uml aggregation'),
	 	this.createEdgeTemplateEntry('endArrow=diamondThin;endFill=1;endSize=24;html=1;', 160, 0, '', 'Composition 2', null, 'uml composition'),
	 	this.createEdgeTemplateEntry('endArrow=open;endFill=1;endSize=12;html=1;', 160, 0, '', 'Association 3', null, 'uml association')
	];
	
	this.addPaletteFunctions('uml', mxResources.get('uml'), expand || false, fns);
	this.setCurrentSearchEntryLibrary();
};

/**
 * Creates and returns the given title element.
 */
Sidebar.prototype.createTitle = function(label)
{
	var elt = document.createElement('a');
	// Section titles can be dragged to reorder palettes — surface that
	// affordance via the tooltip. The broader sidebar-tooltip text now
	// lives on the container background.
	elt.setAttribute('title', mxResources.get('reorder'));
	elt.className = 'geTitle';

	// Invisible overlay over the left-edge arrow icon (the icon itself
	// is the title's background-image — see addFoldingHandler — so we
	// can't add a child with the icon directly). The overlay only
	// carries a tooltip; clicks bubble to the title and trigger the
	// fold handler as before.
	var iconHit = document.createElement('span');
	iconHit.setAttribute('title', mxResources.get('collapseExpand',
		null, 'Collapse/Expand'));
	iconHit.style.cssText = 'position:absolute;left:0;top:0;' +
		'width:24px;height:100%;cursor:pointer';
	elt.appendChild(iconHit);

	var span = document.createElement('span');
	span.className = 'geTitleLabel';
	mxUtils.write(span, label);
	elt.appendChild(span);

	return elt;
};

/**
 * Replaces the text of the given title. The label keeps its element, which is
 * the control for the keyboard (see addFoldingHandler), and the title its
 * other children.
 */
Sidebar.prototype.setTitleText = function(title, text)
{
	var label = title.querySelector('.geTitleLabel');

	if (label != null)
	{
		mxUtils.setTextContent(label, text);
	}
	else
	{
		mxUtils.setTextContent(title, text);
	}
};

/**
 * Creates a thumbnail for the given cells.
 */
Sidebar.prototype.createThumb = function(cells, width, height, parent, title, showLabel, showTitle, w, h, bg, border, scale)
{
	this.graph.labelsVisible = (showLabel == null || showLabel);
	var fo = mxClient.NO_FO;
	mxClient.NO_FO = Editor.prototype.originalNoForeignObject;
	this.graph.shapeForegroundColor = 'light-dark(#000000, #ffffff)';
	this.graph.shapeBackgroundColor = (bg != null) ? bg :
		'light-dark(var(--ge-panel-color), var(--ge-dark-panel-color))';
	this.graph.view.scaleAndTranslate((scale != null) ? scale : 1, 0, 0);
	this.graph.addCells(cells);
	var bounds = this.graph.getGraphBounds();

	if (scale == null)
	{
		var s = Math.floor(Math.min((width - 2 * this.thumbBorder) / bounds.width,
			(height - 2 * this.thumbBorder) / bounds.height) * 100) / 100;
		this.graph.view.scaleAndTranslate(s,
			(width - bounds.width * s) / 2 / s - bounds.x,
			(height - bounds.height * s) / 2 / s - bounds.y);
	}

	var node = null;
	
	// For supporting HTML labels in IE9 standards mode the container is cloned instead
	if (this.graph.dialect == mxConstants.DIALECT_SVG && !mxClient.NO_FO &&
		this.graph.view.getCanvas().ownerSVGElement != null)
	{
		node = this.graph.view.getCanvas().ownerSVGElement.cloneNode(true);
	}
	else
	{
		node = this.graph.container.cloneNode(false);
		node.innerHTML = this.graph.container.innerHTML;
	}

	this.graph.getModel().clear();
	this.graph.view.scaleAndTranslate(1, 0, 0);
	mxClient.NO_FO = fo;
	
	node.style.position = 'relative';
	node.style.overflow = (scale != null) ? 'visible' : 'hidden';
	node.style.left = ((border != null) ? border : this.thumbBorder - 1) + 'px';
	node.style.top = node.style.left;
	node.style.width = width + 'px';
	node.style.height = height + 'px';
	node.style.visibility = '';
	node.style.minWidth = '';
	node.style.minHeight = '';
	this.disablePointerEvents(node);

	parent.appendChild(node);
	
	// Adds title for sidebar entries
	if (this.sidebarTitles && title != null && showTitle != false)
	{
		var border = 0;
		parent.style.height = (this.thumbHeight + border + this.sidebarTitleSize + 8) + 'px';
		
		var div = document.createElement('div');
		div.style.color = Editor.isDarkMode() ? '#A0A0A0' : '#303030';
		div.style.fontSize = this.sidebarTitleSize + 'px';
		div.style.textAlign = 'center';
		div.style.whiteSpace = 'nowrap';
		div.style.overflow = 'hidden';
		div.style.textOverflow = 'ellipsis';
		
		div.style.paddingTop = '4px';
		mxUtils.write(div, title);
		parent.appendChild(div);
	}

	return bounds;
};

/**
 * Returns a function that creates a title.
 */
Sidebar.prototype.createSection = function(title)
{
	return mxUtils.bind(this, function()
	{
		var elt = document.createElement('div');
		elt.setAttribute('title', title);
		elt.style.textOverflow = 'ellipsis';
		elt.style.whiteSpace = 'nowrap';
		elt.style.textAlign = 'center';
		elt.style.overflow = 'hidden';
		elt.style.width = '100%';
		elt.style.padding = '14px 0';
		
		mxUtils.write(elt, title);
		
		return elt;
	});
};

/**
 * Creates and returns a new palette item for the given image.
 */
Sidebar.prototype.createItem = function(cells, title, showLabel, showTitle, width, height,
	allowCellsInserted, showTooltip, clickFn, thumbWidth, thumbHeight, icon, startEditing,
	sourceCell, useElt, connectEdge)
{
	showTooltip = (showTooltip != null) ? showTooltip : true;
	thumbWidth = (thumbWidth != null) ? thumbWidth : this.thumbWidth;
	thumbHeight = (thumbHeight != null) ? thumbHeight : this.thumbHeight;

	var elt = useElt;

	if (elt == null)
	{
		elt = document.createElement('a');
		var border = 2 * this.thumbBorder;
		elt.style.width = (thumbWidth + border) + 'px';
		elt.style.height = (thumbHeight + border) + 'px';
	}

	// Suppress the sidebar container's tooltip ("Click or drag and drop
	// shapes. …") from showing when hovering an individual thumb — the
	// thumb has its own custom showTooltip (cell preview) and the
	// container hint isn't relevant here. The broken-image branch below
	// overrides this with the actual cell title.
	elt.setAttribute('title', '');

	if (title != null)
	{
		elt.setAttribute('aria-label', title);
	}
	
	// Blocks default click action
	mxEvent.addListener(elt, 'click', function(evt)
	{
		mxEvent.consume(evt);
	});
	
	var bounds = new mxRectangle(0, 0, width, height);
	
	// Applies default styles
	if (cells != null && cells.length > 0)
	{
		var originalCells = cells;
		cells = this.graph.cloneCells(cells);
		this.graph.pasteCellStyles(this.graph.includeDescendants(originalCells),
			this.initialDefaultVertexStyle, this.initialDefaultEdgeStyle);

		if (icon != null)
		{
			elt.className = 'geButton';
			elt.style.backgroundImage = 'url(' + icon + ')';
			elt.style.backgroundRepeat = 'no-repeat';
			elt.style.backgroundPosition = 'center';
			elt.style.backgroundSize = '24px 24px';
		}
		else if (useElt == null)
		{
			elt.className = 'geItem';

			if (this.virtualThumbs)
			{
				// Pre-size the placeholder to match what createThumb
				// would set, so layout is stable and the observer can
				// actually decide which entries are off-screen. Without
				// this, every thumb collapses to default height and the
				// observer fires for all of them at once on insert.
				if (this.sidebarTitles && title != null && showTitle != false)
				{
					elt.style.height = (this.thumbHeight +
						this.sidebarTitleSize + 8) + 'px';
				}

				elt.renderThumbFn = mxUtils.bind(this, function()
				{
					this.createThumb(originalCells, thumbWidth, thumbHeight,
						elt, title, showLabel, showTitle, width, height);
				});
				this.getThumbObserver().observe(elt);
			}
			else
			{
				this.createThumb(originalCells, thumbWidth, thumbHeight,
					elt, title, showLabel, showTitle, width, height);
			}
		}
		
		if (cells.length > 1 || cells[0].vertex)
		{
			var ds = this.createDragSource(elt, this.createDropHandler(cells, true, allowCellsInserted,
				bounds, startEditing, sourceCell, connectEdge), this.createDragPreview(width, height),
				cells, bounds, startEditing, sourceCell);
			this.addClickHandler(elt, ds, cells, clickFn, startEditing);
		
			// Uses guides for vertices only if enabled in graph
			ds.isGuidesEnabled = mxUtils.bind(this, function()
			{
				return this.editorUi.editor.graph.graphHandler.guidesEnabled;
			});
		}
		else if (cells[0] != null && cells[0].edge)
		{
			var ds = this.createDragSource(elt, this.createDropHandler(cells, false, allowCellsInserted,
				bounds, startEditing, sourceCell, connectEdge), this.createDragPreview(width, height),
				cells, bounds, startEditing);
			this.addClickHandler(elt, ds, cells, clickFn);
		}
	
		// Shows a tooltip with the rendered cell
		if (!mxClient.IS_IOS && showTooltip)
		{
			mxEvent.addGestureListeners(elt, null, mxUtils.bind(this, function(evt)
			{
				if (mxEvent.isMouseEvent(evt))
				{
					// In embedInline mode the tooltip is anchored to the document
					// body, but the editor is a small floating container, so the
					// default element-relative offset collapses to the page origin.
					// Anchor the preview near the cursor instead.
					var off = (urlParams['embedInline'] == '1') ?
						new mxPoint(evt.clientX + 16, evt.clientY + 16) : null;
					this.showTooltip(elt, cells, bounds.width, bounds.height, title, showLabel, off);
				}
			}));
		}
	}
	else if (useElt == null)
	{
		elt.style.backgroundImage = 'url(' + Editor.svgBrokenImage.src + ')';
		elt.setAttribute('title', title);
	}
	
	return elt;
};

/**
 * Disables legacy anchor points on flipped shapes that have no edges connected,
 * everything else is skipped to match the preview.
 */
Sidebar.prototype.prepareCellsForInsert = function(cells)
{
	if (cells != null && cells.length > 0)
	{
		var model = this.graph.getModel();

		for (var i = 0; i < cells.length; i++)
		{
			this.prepareCellsForInsert(model.getChildren(cells[i]));

			if (model.isVertex(cells[i]))
			{
				var edges = model.getEdges(cells[i]);
				var style = this.graph.getCellStyle(cells[i]);

				// Disables legacy anchor points for flipped shapes without edges
				if ((edges == null || edges.length == 0) && style != null &&
					(mxUtils.getValue(style, mxConstants.STYLE_FLIPV, 0) == 1 ||
					mxUtils.getValue(style, mxConstants.STYLE_FLIPH, 0) == 1 ||
					mxUtils.getValue(style, 'stencilFlipH', 0) == 1 ||
					mxUtils.getValue(style, 'stencilFlipV', 0) == 1))
				{
					this.graph.setCellStyles('legacyAnchorPoints', '0', [cells[i]]);
				}
			}
		}
	}
};

/**
 * Returns true if the given cells are a single plain text shape that should
 * be added as a label of the given edge instead of splitting the edge.
 */
Sidebar.prototype.isEdgeLabelDrop = function(edge, cells)
{
	var graph = this.editorUi.editor.graph;
	var geo = (cells != null && cells.length == 1) ?
		graph.getCellGeometry(cells[0]) : null;

	return graph.model.isEdge(edge) && geo != null && !geo.relative &&
		graph.model.isVertex(cells[0]) &&
		graph.model.getChildCount(cells[0]) == 0 &&
		typeof cells[0].style === 'string' &&
		cells[0].style.substring(0, 5) == 'text;';
};

/**
 * Adds the given cell as a label of the given edge with the center at the
 * given location in screen coordinates.
 */
Sidebar.prototype.addEdgeLabel = function(edge, cell, x, y)
{
	var graph = this.editorUi.editor.graph;
	var state = graph.view.getState(edge);
	var geo = graph.getCellGeometry(cell).clone();
	geo.relative = true;
	geo.x = 0;
	geo.y = 0;
	geo.offset = new mxPoint(0, 0);

	if (state != null)
	{
		var pt = graph.view.getRelativePoint(state, x, y);
		geo.x = Math.round(pt.x * 10000) / 10000;
		geo.y = Math.round(pt.y);

		// Puts the center of the cell at the given location
		pt = graph.view.getPoint(state, geo);
		var s = graph.view.scale;
		geo.offset = new mxPoint(Math.round((x - pt.x) / s - geo.width / 2),
			Math.round((y - pt.y) / s - geo.height / 2));
	}

	graph.model.setGeometry(cell, geo);
	cell.setConnectable(false);
	graph.addCells([cell], edge);
};

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createDropHandler = function(cells, allowSplit, allowCellsInserted, bounds, startEditing, sourceCell, connectEdge)
{
	allowCellsInserted = (allowCellsInserted != null) ? allowCellsInserted : true;
	this.prepareCellsForInsert.call(this, cells);
	
	return mxUtils.bind(this, function(graph, evt, target, x, y, force)
	{
		var elt = (force) ? null : ((mxEvent.isTouchEvent(evt) || mxEvent.isPenEvent(evt)) ?
			document.elementFromPoint(mxEvent.getClientX(evt), mxEvent.getClientY(evt)) :
			mxEvent.getSource(evt));
		
		while (elt != null && elt != this.container)
		{
			elt = elt.parentNode;
		}

		if (elt == null && graph.isEnabled())
		{
			// Tab continues in the diagram, not from the dragged shape (see getTabStart)
			this.editorUi.tabStart = null;
			cells = graph.getImportableCells(cells);
			
			if (cells.length > 0)
			{
				graph.stopEditing();
				
				// Holding alt while mouse is released ignores drop target
				var validDropTarget = (target != null && !mxEvent.isAltDown(evt)) ?
					graph.isValidDropTarget(target, cells, evt) : false;
					
				var select = null;

				if (target != null && !validDropTarget)
				{
					target = null;
				}

				// When reconnecting an unconnected edge terminal to the dropped shape,
				// ignores the drop target so the shape is inserted at the drop location
				// and the terminal is connected (never splitting or nesting into it)
				if (connectEdge != null)
				{
					target = null;
				}

				if (!graph.isCellLocked(target || graph.getDefaultParent()))
				{
					graph.model.beginUpdate();
					try
					{
						x = Math.round(x);
						y = Math.round(y);
						
						// Splits the target edge or inserts into target group
						if (allowSplit && graph.isSplitTarget(target, cells, evt))
						{
							var s = graph.view.scale;
							var tr = graph.view.translate;
							var tx = (x + tr.x) * s;
							var ty = (y + tr.y) * s;
							
							var clones = graph.cloneCells(cells);

							// Adds plain text shapes as labels of the edge
							if (this.isEdgeLabelDrop(target, clones))
							{
								this.addEdgeLabel(target, clones[0], tx, ty);
							}
							else
							{
								graph.splitEdge(target, clones, null,
									x - bounds.width / 2, y - bounds.height / 2,
									tx, ty);
							}

							select = clones;
						}
						else if (cells.length > 0)
						{
							select = graph.importCells(cells, x, y, target);

							if (graph.model.isVertex(sourceCell) && select.length == 1 &&
								graph.model.isVertex(select[0]))
							{
								var edge = graph.insertEdge(graph.model.getParent(sourceCell),
									null, '', sourceCell, select[0], graph.createCurrentEdgeStyle());
								graph.applyNewEdgeStyle(sourceCell, [edge]);
								select.push(edge);

								if (graph.connectionHandler.insertBeforeSource)
								{
									graph.insertEdgeBeforeCell(edge, sourceCell);
								}
							}
							// Reconnects an existing unconnected edge terminal to the dropped shape
							else if (connectEdge != null && select.length == 1 &&
								graph.model.isVertex(select[0]) &&
								graph.model.contains(connectEdge.cell))
							{
								graph.model.setTerminal(connectEdge.cell, select[0], connectEdge.source);
								var ceGeo = graph.getCellGeometry(connectEdge.cell);

								if (ceGeo != null && ceGeo.getTerminalPoint(connectEdge.source) != null)
								{
									ceGeo = ceGeo.clone();
									ceGeo.setTerminalPoint(null, connectEdge.source);
									graph.model.setGeometry(connectEdge.cell, ceGeo);
								}
							}
						}
						
						// Executes parent layout hooks for position/order
						if (graph.layoutManager != null)
						{
							var layout = graph.layoutManager.getLayout(target);
							
							if (layout != null)
							{
								var s = graph.view.scale;
								var tr = graph.view.translate;
								var tx = (x + tr.x) * s;
								var ty = (y + tr.y) * s;
								
								for (var i = 0; i < select.length; i++)
								{
									layout.moveCell(select[i], tx, ty);
								}
							}
						}

						if (allowCellsInserted && (evt == null || !mxEvent.isShiftDown(evt)))
						{
							graph.fireEvent(new mxEventObject('cellsInserted', 'cells', select));
						}

						for (var i = 0; i < select.length; i++)
						{
							if (graph.model.isVertex(select[i]) &&
								graph.isAutoSizeCell(select[i]))
							{
								graph.updateCellSize(select[i]);
							}
						}
					}
					catch (e)
					{
						this.editorUi.handleError(e);
					}
					finally
					{
						graph.model.endUpdate();
					}
	
					if (select != null && select.length > 0)
					{
						// Keeps the scroll position if any part of the
						// dropped cell is visible, eg. for cells larger
						// than the viewport or at high zoom levels
						if (!graph.isCellVisibleInViewport(select[0]))
						{
							graph.scrollCellToVisible(select[0]);
						}

						graph.setSelectionCells(select);
						this.addRecentShapes(select);
					}

					if (startEditing || (graph.editAfterInsert && evt != null &&
						mxEvent.isMouseEvent(evt) && select != null &&
						select.length == 1))
					{
						window.setTimeout(function()
						{
							graph.startEditing(select[0]);
						}, 0);
					}
				}
			}
			
			mxEvent.consume(evt);
		}
	});
};

/**
 * Creates and returns a preview element for the given width and height.
 */
Sidebar.prototype.createDragPreview = function(width, height)
{
	var elt = document.createElement('div');
	elt.className = 'geDragPreview';
	elt.style.width = width + 'px';
	elt.style.height = height + 'px';

	return elt;
};

/**
 * Creates a live preview of the edge that connects the given source cell
 * to the dropped cell (see createDropHandler) while dragging from the
 * hover-icon shape picker. Reuses the connection handler's live preview
 * (createEdgeState, updateEdgeState and createShape invoked on a minimal
 * handler stand-in) so the previewed edge matches the edge inserted on
 * drop, including the current edge style, the source's newEdgeStyle and
 * preview routing overrides.
 */
Sidebar.prototype.createEdgePreview = function(graph, sourceCell, cell)
{
	var preview =
	{
		handler: null,
		targetState: null,
		shape: null
	};

	// Renders the preview edge from the source cell to the given preview
	// rectangle (in view coordinates), creating the preview on demand
	preview.update = function(x, y, w, h)
	{
		var sourceState = graph.view.getState(sourceCell);

		if (sourceState == null)
		{
			preview.hide();
			return;
		}

		if (preview.handler == null)
		{
			// Stand-in for the connection handler state read by
			// createEdgeState, updateEdgeState and convertWaypoint
			preview.handler = {graph: graph, previous: sourceState,
				currentState: null, edgeState: null, sourceConstraint: null,
				constraintHandler: null, waypoints: null,
				convertWaypoint: mxConnectionHandler.prototype.convertWaypoint};
			preview.handler.edgeState = mxConnectionHandler.prototype.
				createEdgeState.call(preview.handler, null);

			var targetCell = graph.cloneCell(cell);
			preview.targetState = new mxCellState(graph.view, targetCell,
				graph.getCellStyle(targetCell));
			preview.handler.currentState = preview.targetState;
		}

		preview.handler.previous = sourceState;
		var target = preview.targetState;
		target.x = x;
		target.y = y;
		target.width = w;
		target.height = h;

		// Keeps the target geometry in model coordinates in sync for
		// routers that inspect the cell rather than the state
		var geo = target.cell.geometry;

		if (geo != null)
		{
			var s = graph.view.scale;
			var tr = graph.view.translate;
			geo.x = x / s - tr.x;
			geo.y = y / s - tr.y;
			geo.width = w / s;
			geo.height = h / s;
		}

		if (preview.shape == null)
		{
			preview.shape = mxConnectionHandler.prototype.createShape.call(
				{graph: graph, livePreview: true,
				edgeState: preview.handler.edgeState});
			preview.shape.apply(preview.handler.edgeState);
		}

		mxConnectionHandler.prototype.updateEdgeState.call(preview.handler,
			new mxPoint(x + w / 2, y + h / 2), null);

		var edgeState = preview.handler.edgeState;
		preview.shape.points = edgeState.absolutePoints;
		preview.shape.scale = graph.view.scale;
		edgeState.shape = preview.shape;
		graph.cellRenderer.postConfigureShape(edgeState);
		edgeState.shape = null;
		preview.shape.node.style.display = '';
		preview.shape.redraw();
	};

	preview.hide = function()
	{
		if (preview.shape != null)
		{
			preview.shape.node.style.display = 'none';
		}
	};

	// Removes the preview and frees per-drag resources, the next call
	// to update recreates the preview
	preview.destroy = function()
	{
		if (preview.shape != null)
		{
			preview.shape.destroy();
			preview.shape = null;
		}

		if (typeof LibavoidRouting !== 'undefined' &&
			LibavoidRouting.endPreview != null)
		{
			// Drops the per-drag state of the libavoid connect preview
			LibavoidRouting.endPreview(preview.handler);
		}

		preview.handler = null;
		preview.targetState = null;
	};

	return preview;
};

/**
 * Creates a drag source for the given element.
 */
Sidebar.prototype.dropAndConnect = function(source, targets, direction, dropCellIndex, evt, firstVertex, freeSourceEdge)
{
	var graph = this.editorUi.editor.graph;
	var index = (graph.model.isEdge(source) || firstVertex != null) ? firstVertex : freeSourceEdge;
	var geo = this.getDropAndConnectGeometry(source, targets[index], direction, targets);

	// Moves the drop geometry including the end of dangling edges
	function translateGeometry(tx, ty)
	{
		geo.x += tx;
		geo.y += ty;

		var pt = geo.getTerminalPoint(false);

		if (pt != null)
		{
			geo.setTerminalPoint(new mxPoint(pt.x + tx, pt.y + ty), false);
		}
	};

	// Targets without the new edge for selection
	var tmp = [];
	
	if (geo != null)
	{
		var editingCell = null;

		graph.model.beginUpdate();
		try
		{
			var sourceGeo = graph.getCellGeometry(source);
			var geo2 = graph.getCellGeometry(targets[dropCellIndex]);

			// Handles special case where target should be ignored for stack layouts
			var targetParent = graph.model.getParent(source);
			var validLayout = true;
			
			// Ignores parent if it has a stack layout or if it is a table or row
			if (graph.layoutManager != null)
			{
				var layout = graph.layoutManager.getLayout(targetParent);
			
				// LATER: Use parent of parent if valid layout
				if (layout != null && layout.constructor == mxStackLayout)
				{
					validLayout = false;
				}
			}
			
			// Checks if another container is at the drop location
			var tmp = (graph.model.isEdge(source)) ? null : graph.view.getState(targetParent);
			var dx = 0;
			var dy = 0;
			
			// Offsets by parent position (geometry is absolute for relative sources)
			if (tmp != null && (sourceGeo == null || !sourceGeo.relative))
			{
				var offset = tmp.origin;
				dx = offset.x;
				dy = offset.y;
			}
			
			var useParent = !graph.isTableRow(source) && !graph.isTableCell(source) &&
				(graph.model.isEdge(source) || (sourceGeo != null &&
				!sourceGeo.relative && validLayout));
			
			var tempTarget = graph.getCellAt((geo.x + dx + graph.view.translate.x) * graph.view.scale,
				(geo.y + dy + graph.view.translate.y) * graph.view.scale, null, null, null, function(state, x, y)
				{
					return !graph.isContainer(state.cell);
				});
			
			// Uses the parent of relative sources (eg. ports) if it is the container at the drop location
			if (tempTarget != null && (tempTarget != targetParent || (!useParent && validLayout &&
				!graph.isTableRow(source) && !graph.isTableCell(source))))
			{
				tmp = graph.view.getState(tempTarget);
			
				// Offsets by new parent position
				if (tmp != null)
				{
					var offset = tmp.origin;
					targetParent = tempTarget;
					useParent = true;
					
					if (!graph.model.isEdge(source))
					{
						translateGeometry(dx - offset.x, dy - offset.y);
					}
				}
			}
			else if (!validLayout || graph.isTableRow(source) || graph.isTableCell(source))
			{
				translateGeometry(dx, dy);
			}

			dx = geo2.x;
			dy = geo2.y;
			
			// Ignores geometry of edges
			if (graph.model.isEdge(targets[dropCellIndex]))
			{
				dx = 0;
				dy = 0;
			}
			
			targets = graph.importCells(targets, (geo.x - (useParent ? dx : 0)),
				(geo.y - (useParent ? dy : 0)), (useParent) ? targetParent : null);
			tmp = targets;

			if (graph.model.isEdge(source))
			{
				// Adds new terminal to edge
				// LATER: Push new terminal out radially from edge start point
				graph.model.setTerminal(source, targets[dropCellIndex],
					direction == mxConstants.DIRECTION_NORTH);
				
				// Replaces the source edge style with the dangling edge and
				// removes the dangling edge from the graph
				if (freeSourceEdge != null && firstVertex != null)
				{
					graph.model.remove(targets[freeSourceEdge]);
					graph.updateShapes(targets[freeSourceEdge], [source]);
				}
			}
			else if (graph.model.isEdge(targets[dropCellIndex]) && firstVertex == null)
			{
				// Adds new outgoing connection to vertex and clears points
				graph.model.setTerminal(targets[dropCellIndex], source, true);
				var geo3 = graph.getCellGeometry(targets[dropCellIndex]);
				var tp = (geo3 != null) ? geo3.getTerminalPoint(true) : null;
				geo3.points = null;

				// Connects edge terminal points at the same location to the source
				if (tp != null)
				{
					for (var i = 0; i < targets.length; i++)
					{
						if (graph.model.isEdge(targets[i]) && i != dropCellIndex)
						{
							var geo4 = graph.getCellGeometry(targets[i]);
							var pt = (geo4 != null) ? geo4.getTerminalPoint(true) : null;
							
							if (pt != null)
							{
								if (pt.x == tp.x && pt.y == tp.y)
								{
									graph.model.setTerminal(targets[i], source, true);
								}
							}
						}
					}
				}

				if (geo3.getTerminalPoint(false) != null)
				{
					geo3.setTerminalPoint(geo.getTerminalPoint(false), false);
				}
				else if (useParent && graph.model.isVertex(targetParent))
				{
					// Adds parent offset to other nodes
					var tmpState = graph.view.getState(targetParent);
					var offset = (tmpState.cell != graph.view.currentRoot) ?
						tmpState.origin : new mxPoint(0, 0);

					graph.cellsMoved(targets, offset.x, offset.y, null, null, true);
				}
			}
			else if (firstVertex != null)
			{
				geo2 = graph.getCellGeometry(targets[firstVertex]);
				dx = geo.x - Math.round(geo2.x);
				dy = geo.y - Math.round(geo2.y);
				geo.x = Math.round(geo2.x);
				geo.y = Math.round(geo2.y);
				graph.model.setGeometry(targets[dropCellIndex], geo);
				graph.cellsMoved(targets, dx, dy, null, null, true);
				tmp = targets.slice();
				editingCell = (tmp.length == 1) ? tmp[0] : null;

				if (freeSourceEdge != null)
				{
					graph.model.setTerminal(targets[freeSourceEdge], source, true);
				}
				else
				{
					targets.push(graph.insertEdge(null, null, '', source, targets[dropCellIndex],
						graph.createCurrentEdgeStyle()));
				}
			}
			
			if (evt == null || !mxEvent.isShiftDown(evt))
			{
				graph.fireEvent(new mxEventObject('cellsInserted', 'cells', targets));
			}
		}
		catch (e)
		{
			this.editorUi.handleError(e);
		}
		finally
		{
			graph.model.endUpdate();
		}

		this.addRecentShapes(targets);

		if (graph.editAfterInsert && evt != null && mxEvent.isMouseEvent(evt) &&
			editingCell != null)
		{
			window.setTimeout(function()
			{
				graph.startEditing(editingCell);
			}, 0);
		}
	}

	// Removes connected edge from selection
	// cells to avoid disconnecting on move
	if (freeSourceEdge != null && tmp.length > 1)
	{
		tmp.splice(freeSourceEdge, 1);
	}
	
	return tmp;
};

/**
 * Creates a drag source for the given element.
 */
Sidebar.prototype.getDropAndConnectGeometry = function(source, target, direction, targets)
{
	var graph = this.editorUi.editor.graph;
	var view = graph.view;
	var keepSize = targets.length > 1;
	var state = graph.view.getState(source);
	var geo = graph.getCellGeometry(source);
	var geo2 = graph.getCellGeometry(target);

	if (state != null && geo != null && geo2 != null)
	{
		geo2 = geo2.clone();

		if (graph.model.isEdge(source))
		{
			var pts = state.absolutePoints;
			var p0 = pts[0];
			var pe = pts[pts.length - 1];
			
			if (direction == mxConstants.DIRECTION_NORTH)
			{
				geo2.x = p0.x / view.scale - view.translate.x - geo2.width / 2;
				geo2.y = p0.y / view.scale - view.translate.y - geo2.height / 2;
			}
			else
			{
				geo2.x = pe.x / view.scale - view.translate.x - geo2.width / 2;
				geo2.y = pe.y / view.scale - view.translate.y - geo2.height / 2;
			}
		}
		else
		{
			if (geo.relative)
			{
				geo = geo.clone();
				geo.x = state.x / view.scale - view.translate.x;
				geo.y = state.y / view.scale - view.translate.y;
			}
			
			var length = graph.defaultEdgeLength;
			
			// Maintains edge length
			if (graph.model.isEdge(target) && geo2.getTerminalPoint(true) != null &&
				geo2.getTerminalPoint(false) != null)
			{
				var p0 = geo2.getTerminalPoint(true);
				var pe = geo2.getTerminalPoint(false);
				var dx = pe.x - p0.x;
				var dy = pe.y - p0.y;
				
				length = Math.sqrt(dx * dx + dy * dy);
				
				geo2.x = geo.getCenterX();
				geo2.y = geo.getCenterY();
				geo2.width = 1;
				geo2.height = 1;
				
				if (direction == mxConstants.DIRECTION_NORTH)
				{
					geo2.height = length
					geo2.y = geo.y - length;
					geo2.setTerminalPoint(new mxPoint(geo2.x, geo2.y), false);
				}
				else if (direction == mxConstants.DIRECTION_EAST)
				{
					geo2.width = length
					geo2.x = geo.x + geo.width;
					geo2.setTerminalPoint(new mxPoint(geo2.x + geo2.width, geo2.y), false);
				}
				else if (direction == mxConstants.DIRECTION_SOUTH)
				{
					geo2.height = length
					geo2.y = geo.y + geo.height;
					geo2.setTerminalPoint(new mxPoint(geo2.x, geo2.y + geo2.height), false);
				}
				else if (direction == mxConstants.DIRECTION_WEST)
				{
					geo2.width = length
					geo2.x = geo.x - length;
					geo2.setTerminalPoint(new mxPoint(geo2.x, geo2.y), false);
				}
			}
			else
			{
				// Try match size or ignore if width or height < 45 which
				// is considered special enough to be ignored here
				if (!keepSize && geo2.width > 45 && geo2.height > 45 &&
					geo.width > 45 && geo.height > 45)
				{
					geo2.width = geo2.width * (geo.height / geo2.height);
					geo2.height = geo.height;
				}
	
				geo2.x = geo.x + geo.width / 2 - geo2.width / 2;
				geo2.y = geo.y + geo.height / 2 - geo2.height / 2;

				if (direction == mxConstants.DIRECTION_NORTH)
				{
					geo2.y = geo2.y - geo.height / 2 - geo2.height / 2 - length;
				}
				else if (direction == mxConstants.DIRECTION_EAST)
				{
					geo2.x = geo2.x + geo.width / 2 + geo2.width / 2 + length;
				}
				else if (direction == mxConstants.DIRECTION_SOUTH)
				{
					geo2.y = geo2.y + geo.height / 2 + geo2.height / 2 + length;
				}
				else if (direction == mxConstants.DIRECTION_WEST)
				{
					geo2.x = geo2.x - geo.width / 2 - geo2.width / 2 - length;
				}
				
				// Adds offset to match cells without connecting edge
				if (graph.model.isEdge(target) && geo2.getTerminalPoint(true) != null &&
					target.getTerminal(false) != null)
				{
					var targetGeo = graph.getCellGeometry(target.getTerminal(false));
					
					if (targetGeo != null)
					{
						if (direction == mxConstants.DIRECTION_NORTH)
						{
							geo2.x -= targetGeo.getCenterX();
							geo2.y -= targetGeo.getCenterY() + targetGeo.height / 2;
						}
						else if (direction == mxConstants.DIRECTION_EAST)
						{
							geo2.x -= targetGeo.getCenterX() - targetGeo.width / 2;
							geo2.y -= targetGeo.getCenterY();
						}
						else if (direction == mxConstants.DIRECTION_SOUTH)
						{
							geo2.x -= targetGeo.getCenterX();
							geo2.y -= targetGeo.getCenterY() - targetGeo.height / 2;
						}
						else if (direction == mxConstants.DIRECTION_WEST)
						{
							geo2.x -= targetGeo.getCenterX() + targetGeo.width / 2;
							geo2.y -= targetGeo.getCenterY();
						}
					}
				}
			}
		}
	}
	
	return geo2;
};

/**
 * Limits drop style to non-transparent source shapes and groups.
 */
Sidebar.prototype.isDropStyleEnabled = function(cells, firstVertex)
{
	var result = true;
	
	if (firstVertex != null && cells.length == 1 &&
		this.graph.model.getChildCount(cells[firstVertex]) == 0)
	{
		var vstyle = this.graph.getCellStyle(cells[firstVertex]);
		
		if (vstyle != null)
		{
			result = mxUtils.getValue(vstyle, mxConstants.STYLE_STROKECOLOR, mxConstants.NONE) != mxConstants.NONE ||
				mxUtils.getValue(vstyle, mxConstants.STYLE_FILLCOLOR, mxConstants.NONE) != mxConstants.NONE;
		}
	}
	
	return result;
};

/**
 * Ignores swimlanes as drop style targets.
 */
Sidebar.prototype.isDropStyleTargetIgnored = function(state)
{
	return this.graph.isSwimlane(state.cell) || this.graph.isTableCell(state.cell) ||
		this.graph.isTableRow(state.cell) || this.graph.isTable(state.cell);
};

/**
 * Returns the state of the edge label at the given position for the given
 * edge state, checking the labels of the child cells and the label of the
 * edge itself, in which case the given state is returned.
 */
Sidebar.prototype.getEdgeLabelStateAt = function(state, x, y)
{
	var graph = state.view.graph;
	var result = null;

	var childCount = graph.model.getChildCount(state.cell);

	for (var i = childCount - 1; i >= 0 && result == null; i--)
	{
		var child = graph.model.getChildAt(state.cell, i);

		if (graph.model.isVertex(child))
		{
			var childState = graph.view.getState(child);

			if (childState != null && (mxUtils.contains(childState, x, y) ||
				(childState.text != null && childState.text.boundingBox != null &&
				mxUtils.contains(childState.text.boundingBox, x, y))))
			{
				result = childState;
			}
		}
	}

	if (result == null && state.text != null && state.text.boundingBox != null &&
		mxUtils.contains(state.text.boundingBox, x, y))
	{
		result = state;
	}

	return result;
};

/**
 * Lazily creates a shared IntersectionObserver used to defer thumb
 * rendering until the entry scrolls near the viewport. Used by the
 * virtual thumbs path in createItem.
 */
Sidebar.prototype.getThumbObserver = function()
{
	if (this.thumbObserver == null)
	{
		this.thumbObserver = new IntersectionObserver(mxUtils.bind(this, function(entries)
		{
			for (var i = 0; i < entries.length; i++)
			{
				var entry = entries[i];

				if (entry.isIntersecting)
				{
					var fn = entry.target.renderThumbFn;

					if (fn != null)
					{
						entry.target.renderThumbFn = null;
						this.thumbObserver.unobserve(entry.target);
						fn();
					}
				}
			}
		}), {rootMargin: '200px 0px'});
	}

	return this.thumbObserver;
};

/**
 * Lazily creates a shared IntersectionObserver used to defer palette
 * content creation until the expanded palette scrolls near the
 * viewport. Used by the virtual palettes path in deferPaletteInit.
 */
Sidebar.prototype.getPaletteObserver = function()
{
	if (this.paletteObserver == null)
	{
		this.paletteObserver = new IntersectionObserver(mxUtils.bind(this, function(entries)
		{
			for (var i = 0; i < entries.length; i++)
			{
				var entry = entries[i];

				if (entry.isIntersecting)
				{
					var fn = entry.target.initPaletteFn;

					if (fn != null)
					{
						this.paletteObserver.unobserve(entry.target);
						fn();
					}
				}
			}
		// Viewport root like getThumbObserver — the sidebar wrapper has
		// a zero-size rect in some themes (e.g. simple), which makes an
		// element root never intersect
		}), {rootMargin: '200px 0px'});
	}

	return this.paletteObserver;
};

/**
 * Defers the given palette content creation until the content div
 * first scrolls near the viewport. The pending initializer is kept on
 * the content div so expand/collapse only toggles visibility — a
 * collapsed (or hidden) palette never intersects and stays
 * uninitialized until it is both expanded and scrolled into view.
 */
Sidebar.prototype.deferPaletteInit = function(content, title, onInit)
{
	if (content.style.minHeight == '')
	{
		content.style.minHeight = this.deferredPaletteHeight + 'px';
	}

	content.initPaletteFn = mxUtils.bind(this, function()
	{
		content.initPaletteFn = null;
		content.style.minHeight = '';

		var fo = mxClient.NO_FO;
		mxClient.NO_FO = Editor.prototype.originalNoForeignObject;
		onInit(content, title);
		mxClient.NO_FO = fo;
	});

	this.getPaletteObserver().observe(content);
};

/**
 * Refines the placeholder height of a deferred palette from its entry
 * count so off-screen palettes occupy roughly their real height.
 */
Sidebar.prototype.setDeferredPaletteSize = function(content, count)
{
	if (content != null && content.initPaletteFn != null && count > 0)
	{
		// Nominal 200px content width; exact numbers don't matter, the
		// estimate only spreads the palettes out so the observer can
		// tell which ones are actually near the viewport
		var perRow = Math.max(1, Math.floor(200 /
			(this.thumbWidth + 2 * this.thumbBorder + 4)));
		content.style.minHeight = (Math.ceil(count / perRow) *
			(this.thumbHeight + 2 * this.thumbBorder + 6)) + 'px';
	}
};

/**
 * Stops observing the given DOM subtree (deferred palette content and
 * thumb placeholders) before it is removed from the DOM, so the shared
 * observers do not keep the detached nodes alive.
 */
Sidebar.prototype.unobserveElements = function(elt)
{
	if (elt.nodeType == mxConstants.NODETYPE_ELEMENT &&
		(this.thumbObserver != null || this.paletteObserver != null))
	{
		var nodes = [elt].concat(Array.prototype.slice.call(
			elt.querySelectorAll('.geItem, .geSidebar')));

		for (var i = 0; i < nodes.length; i++)
		{
			if (this.thumbObserver != null && nodes[i].renderThumbFn != null)
			{
				nodes[i].renderThumbFn = null;
				this.thumbObserver.unobserve(nodes[i]);
			}

			if (this.paletteObserver != null && nodes[i].initPaletteFn != null)
			{
				nodes[i].initPaletteFn = null;
				this.paletteObserver.unobserve(nodes[i]);
			}
		}
	}
};

/**
 * Disconnects the shared thumb and palette observers, dropping all
 * pending lazy-render callbacks. Used when the sidebar is rebuilt;
 * the observers are recreated lazily on next use.
 */
Sidebar.prototype.disconnectObservers = function()
{
	if (this.thumbObserver != null)
	{
		this.thumbObserver.disconnect();
		this.thumbObserver = null;
	}

	if (this.paletteObserver != null)
	{
		this.paletteObserver.disconnect();
		this.paletteObserver = null;
	}
};

/**
 * Creates a drag source for the given element.
 */
Sidebar.prototype.disablePointerEvents = function(node)
{
	mxUtils.visitNodes(node, mxUtils.bind(this, function(node)
	{
		if (node.nodeType == mxConstants.NODETYPE_ELEMENT &&
			node.style != null)
		{
			node.style.pointerEvents = 'none';
			node.removeAttribute('pointer-events');
		}
	}));
};

/**
 * Creates a drag source for the given element.
 */
Sidebar.prototype.createDragSource = function(elt, dropHandler, preview, cells, bounds, startEditing, sourceCell)
{
	// Checks if the cells contain any vertices
	var ui = this.editorUi;
	var graph = ui.editor.graph;
	var freeSourceEdge = null;
	var firstVertex = null;
	var sidebar = this;
	var count = 0;
	var livePreview = this.livePreview;

	// Previews the edge that createDropHandler inserts between the source
	// cell and the dropped cell (hover-icon shape picker drags)
	var edgePreview = (sourceCell != null && graph.model.isVertex(sourceCell) &&
		cells.length == 1 && graph.model.isVertex(cells[0])) ?
		this.createEdgePreview(graph, sourceCell, cells[0]) : null;

	for (var i = 0; i < cells.length && livePreview; i++)
	{
		count += graph.model.getDescendants(cells[i]).length;
		livePreview = count < graph.graphHandler.maxLivePreview;
	}

	for (var i = 0; i < cells.length; i++)
	{
		if (firstVertex == null && graph.model.isVertex(cells[i]))
		{
			firstVertex = i;
		}
		else if (freeSourceEdge == null && graph.model.isEdge(cells[i]) &&
				graph.model.getTerminal(cells[i], true) == null)
		{
			freeSourceEdge = i;
		}
		
		if (firstVertex != null && freeSourceEdge != null)
		{
			break;
		}
	}
	
	// Checks if the replace source is a group
	var groupSource = firstVertex != null &&
		graph.model.getChildCount(cells[firstVertex]) > 0;

	var dropStyleEnabled = this.isDropStyleEnabled(cells, firstVertex);
	
	var dragSource = mxUtils.makeDraggable(elt, graph, mxUtils.bind(this, function(graph, evt, target, x, y)
	{
		if (this.updateThread != null)
		{
			window.clearTimeout(this.updateThread);
		}
		
		if (cells != null && currentStyleTarget != null && activeArrow == styleTarget)
		{
			// Replaces the shape of the edge label under the mouse
			if (styleTargetLabel)
			{
				graph.setSelectionCell(graph.updateEdgeLabelShape(
					cells[firstVertex], currentStyleTarget.cell));
			}
			else
			{
				var tmp = graph.isCellSelected(currentStyleTarget.cell) ? graph.getSelectionCells() : [currentStyleTarget.cell];
				graph.updateShapes((graph.model.isEdge(currentStyleTarget.cell)) ? cells[0] : cells[firstVertex], tmp, true);
				graph.setSelectionCells(tmp);
			}
		}
		else if (cells != null && activeArrow != null && currentTargetState != null && activeArrow != styleTarget)
		{
			var index = (graph.model.isEdge(currentTargetState.cell) || freeSourceEdge == null) ? firstVertex : freeSourceEdge;
			graph.setSelectionCells(this.dropAndConnect(currentTargetState.cell, cells, direction, index, evt, firstVertex, freeSourceEdge));
		}
		else
		{
			dropHandler.apply(this, arguments);
		}
		
		if (this.editorUi.hoverIcons != null)
		{
			this.editorUi.hoverIcons.update(graph.view.getState(graph.getSelectionCell()));
		}
	}), preview, 0, 0, graph.autoscroll, true, true);

	if (livePreview)
	{
		dragSource.createDragElement = mxUtils.bind(this, function()
		{
			return dragSource.createPreviewElement(this.graph);
		});
		
		dragSource.createPreviewElement = mxUtils.bind(this, function(targetGraph)
		{
			var elt = document.createElement('a');
			elt.className = 'geItem';
			elt.style.overflow = 'visible';
			var s = targetGraph.view.scale;
			elt.style.width = (s * Math.max(1, bounds.width)) + 'px';
			elt.style.height = (s * Math.max(1, bounds.height)) + 'px';
			
			// Transparency for guides and target highlights
			mxUtils.setOpacity(elt, 50);

			var clones = graph.cloneCells(cells);
			this.graph.pasteCellStyles(graph.includeDescendants(clones),
				graph.currentVertexStyle, graph.currentEdgeStyle,
				null, graph.pasteEdgeStyle, graph.pasteStylesToText);
			
			sidebar.createThumb(clones, s * Math.max(1, bounds.width),
				s * Math.max(1, bounds.height), elt, null, null, null,
				null, null, graph.shapeBackgroundColor, 0, s);
			
			return elt;
		});
	}
	
	// Overrides mouseDown to ignore popup triggers
	var mouseDown = dragSource.mouseDown;
	
	dragSource.mouseDown = function(evt)
	{
		if (!mxEvent.isPopupTrigger(evt) && !mxEvent.isMultiTouchEvent(evt) &&
			!graph.isCellLocked(graph.getDefaultParent()))
		{
			graph.stopEditing();
			mouseDown.apply(this, arguments);
		}
	};

	// Workaround for event redirection via image tag in quirks and IE8
	function createArrow(img, tooltip)
	{
		var arrow = null;
		arrow = mxUtils.createImage(img.src);
		arrow.style.width = img.width + 'px';
		arrow.style.height = img.height + 'px';
		
		if (tooltip != null)
		{
			arrow.setAttribute('title', tooltip);
		}
		
		mxUtils.setOpacity(arrow, (img == this.refreshTarget) ? 30 : 20);
		arrow.style.position = 'absolute';
		arrow.style.cursor = 'crosshair';
		
		return arrow;
	};

	var currentTargetState = null;
	var currentStateHandle = null;
	var currentStyleTarget = null;
	var styleTargetBounds = null;
	var styleTargetLabel = false;
	var activeTarget = false;
	
	var arrowUp = createArrow(this.triangleUp, mxResources.get('connect'));
	var arrowRight = createArrow(this.triangleRight, mxResources.get('connect'));
	var arrowDown = createArrow(this.triangleDown, mxResources.get('connect'));
	var arrowLeft = createArrow(this.triangleLeft, mxResources.get('connect'));
	var styleTarget = createArrow(this.refreshTarget, mxResources.get('replace'));

	// Workaround for actual parentNode not being updated in old IE
	var styleTargetParent = null;
	var roundSource = createArrow(this.roundDrop);
	var roundTarget = createArrow(this.roundDrop);
	var direction = mxConstants.DIRECTION_NORTH;
	var activeArrow = null;
	
	function checkArrow(x, y, bounds, arrow)
	{
		if (arrow.parentNode != null)
		{
			if (mxUtils.contains(bounds, x, y))
			{
				mxUtils.setOpacity(arrow, 100);
				activeArrow = arrow;
			}
			else
			{
				mxUtils.setOpacity(arrow, (arrow == styleTarget) ? 30 : 20);
			}
		}
		
		return bounds;
	};
	
	// Returns the bounds of the round drop target at the given end of an edge
	function getRoundDropBounds(pt)
	{
		return new mxRectangle(pt.x - sidebar.roundDrop.width / 2,
			pt.y - sidebar.roundDrop.height / 2,
			sidebar.roundDrop.width, sidebar.roundDrop.height);
	};

	// Hides guides and preview if target is active
	var dsCreatePreviewElement = dragSource.createPreviewElement;
	
	// Stores initial size of preview element
	dragSource.createPreviewElement = function(graph)
	{
		var elt = dsCreatePreviewElement.apply(this, arguments);
		
		this.previewElementWidth = elt.style.width;
		this.previewElementHeight = elt.style.height;

		// Pass-through events required to tooltip on replace shape
		elt.style.pointerEvents = 'none';
				
		return elt;
	};
	
	// Shows/hides hover icons
	var dragEnter = dragSource.dragEnter;
	dragSource.dragEnter = function(graph, evt)
	{
		if (ui.hoverIcons != null)
		{
			ui.hoverIcons.setDisplay('none');
		}
		
		dragEnter.apply(this, arguments);

		// Uses the descendants of the drop target or the default parent as
		// guides, like moving cells (see mxGraphHandler.getGuideContainer)
		if (this.currentGuide != null)
		{
			this.currentGuide.isStateIgnored = mxUtils.bind(this, function(state)
			{
				return graph.isGuideStateOutside(state, this.currentDropTarget);
			});
		}
	};
	
	var dragExit = dragSource.dragExit;
	dragSource.dragExit = function(graph, evt)
	{
		if (ui.hoverIcons != null)
		{
			ui.hoverIcons.setDisplay('');
		}

		if (edgePreview != null)
		{
			edgePreview.destroy();
		}

		dragExit.apply(this, arguments);
	};
	
	dragSource.dragOver = function(graph, evt)
	{
		mxDragSource.prototype.dragOver.apply(this, arguments);

		if (this.currentGuide != null && activeArrow != null)
		{
			this.currentGuide.hide();
		}

		if (this.previewElement != null)
		{
			ui.hideShapePicker();
			var view = graph.view;
			
			if (currentStyleTarget != null && activeArrow == styleTarget)
			{
				this.previewElement.style.display = 'none';
			}
			else if (currentTargetState != null && activeArrow != null)
			{
				if (dragSource.currentHighlight != null && dragSource.currentHighlight.state != null)
				{
					dragSource.currentHighlight.hide();
				}
				
				var index = (graph.model.isEdge(currentTargetState.cell) || firstVertex != null) ? firstVertex : freeSourceEdge;
				var geo = sidebar.getDropAndConnectGeometry(currentTargetState.cell, cells[index], direction, cells);
				var geo2 = (!graph.model.isEdge(currentTargetState.cell)) ? graph.getCellGeometry(currentTargetState.cell) : null;
				var geo3 = graph.getCellGeometry(cells[index]);
				var parent = graph.model.getParent(currentTargetState.cell);
				var dx = view.translate.x * view.scale;
				var dy = view.translate.y * view.scale;
				
				if (geo2 != null && !geo2.relative && graph.model.isVertex(parent) && parent != view.currentRoot)
				{
					// Uses the parent origin as the base of the child coordinate
					// space since state.x/y of transparentBounds parents also
					// contains the child-derived bounds offset
					var pState = view.getState(parent);

					dx = view.scale * (view.translate.x + pState.origin.x);
					dy = view.scale * (view.translate.y + pState.origin.y);
				}
				
				var dx2 = geo3.x;
				var dy2 = geo3.y;

				// Ignores geometry of edges
				if (graph.model.isEdge(cells[index]))
				{
					dx2 = 0;
					dy2 = 0;
				}
				
				// Shows preview at drop location
				this.previewElement.style.left = ((geo.x - dx2) * view.scale + dx) + 'px';
				this.previewElement.style.top = ((geo.y - dy2) * view.scale + dy) + 'px';
				
				if (cells.length == 1)
				{
					this.previewElement.style.width = (geo.width * view.scale) + 'px';
					this.previewElement.style.height = (geo.height * view.scale) + 'px';

					if (this.previewElement.firstChild != null)
					{
						this.previewElement.firstChild.style.display = 'none';
						this.previewElement.className = 'geDragPreview';
						mxUtils.setOpacity(this.previewElement, 100);
					}
				}
				
				this.previewElement.style.display = '';
			}
			else if (dragSource.currentHighlight != null &&
				dragSource.currentHighlight.state != null &&
				graph.model.isEdge(dragSource.currentHighlight.state.cell))
			{
				// Centers drop cells when splitting edges
				this.previewElement.style.left = Math.round(parseInt(this.previewElement.style.left) -
					bounds.width * view.scale / 2) + 'px';
				this.previewElement.style.top = Math.round(parseInt(this.previewElement.style.top) -
					bounds.height * view.scale / 2) + 'px';
			}
			else
			{
				this.previewElement.style.width = this.previewElementWidth;
				this.previewElement.style.height = this.previewElementHeight;
				this.previewElement.style.display = '';

				if (this.previewElement.firstChild != null)
				{
					this.previewElement.firstChild.style.display = '';
					mxUtils.setOpacity(this.previewElement, 50);
					this.previewElement.className = '';
				}
			}

			// Shows the connecting edge for drops that insert it: hidden
			// while an arrow or replace target is active (dropAndConnect
			// or style replace) and while splitting a highlighted edge
			if (edgePreview != null)
			{
				if (activeArrow == null && currentStyleTarget == null &&
					this.previewElement.style.display != 'none' &&
					this.previewElement.style.visibility != 'hidden' &&
					(dragSource.currentHighlight == null ||
					dragSource.currentHighlight.state == null ||
					!graph.model.isEdge(dragSource.currentHighlight.state.cell)))
				{
					edgePreview.update(parseFloat(this.previewElement.style.left),
						parseFloat(this.previewElement.style.top),
						parseFloat(this.previewElement.style.width),
						parseFloat(this.previewElement.style.height));
				}
				else
				{
					edgePreview.hide();
				}
			}
		}
	};
	
	var startTime = new Date().getTime();
	var timeOnTarget = 0;
	var prev = null;
	var lastMove = null;
	
	// Gets source cell style to compare shape below
	var sourceCellStyle = this.editorUi.editor.graph.getCellStyle(cells[0]);
	
	// Allows drop into cell only if target is a valid root
	dragSource.getDropTarget = mxUtils.bind(this, function(graph, x, y, evt)
	{
		// Alt means no targets at all
		// LATER: Show preview where result will go
		var cell = (!mxEvent.isAltDown(evt) && cells != null) ?
			graph.getCellAt(x, y, null, null, null, function(state, x, y)
			{
				return graph.isContainer(state.cell) && mxUtils.getValue(
					state.style, 'dropTarget', '1') != '0';
			}) : null;
		
		// Uses connectable parent vertex if one exists
		if (cell != null && !this.graph.isCellConnectable(cell) &&
			!this.graph.model.isEdge(cell))
		{
			var parent = this.graph.getModel().getParent(cell);
			
			if (this.graph.getModel().isVertex(parent) &&
				this.graph.isCellConnectable(parent))
			{
				cell = parent;
			}
		}
		
		// Ignores locked cells
		if (graph.isCellLocked(cell))
		{
			cell = null;
		}
		
		var state = graph.view.getState(cell);
		activeArrow = null;
		var bbox = null;
		lastMove = {x: x, y: y, evt: evt};

		// Time on target
		if (prev != state)
		{
			startTime = new Date().getTime();
			timeOnTarget = 0;
			prev = state;

			if (this.updateThread != null)
			{
				window.clearTimeout(this.updateThread);
			}
			
			if (state != null)
			{
				this.updateThread = window.setTimeout(function()
				{
					if (activeArrow == null)
					{
						prev = state;

						// Uses the last mouse location since the mouse may have moved
						// over the same cell, eg. from the end of an edge to its middle
						dragSource.getDropTarget(graph, lastMove.x, lastMove.y, lastMove.evt);
					}
				}, this.dropTargetDelay + 10);
			}
		}
		else
		{
			timeOnTarget = new Date().getTime() - startTime;
		}

		// Uses the label of the edge or one of its children as the replace target
		var labelState = (state != null && graph.model.isEdge(state.cell) &&
			firstVertex != null && !groupSource && !graph.model.isEdge(cells[0])) ?
			this.getEdgeLabelStateAt(state, x, y) : null;

		// Shift means disabled, delayed on cells with children, shows after this.dropTargetDelay, hides after 3500ms
		if (dropStyleEnabled && (timeOnTarget < 3500) && state != null && !mxEvent.isShiftDown(evt) &&
			// If shape is equal or target has no stroke, fill and gradient then use longer delay except for images and groups
			((((mxUtils.getValue(state.style, mxConstants.STYLE_SHAPE) != mxUtils.getValue(sourceCellStyle, mxConstants.STYLE_SHAPE) || groupSource) &&
			(mxUtils.getValue(state.style, mxConstants.STYLE_STROKECOLOR, mxConstants.NONE) != mxConstants.NONE ||
			mxUtils.getValue(state.style, mxConstants.STYLE_FILLCOLOR, mxConstants.NONE) != mxConstants.NONE ||
			mxUtils.getValue(state.style, mxConstants.STYLE_GRADIENTCOLOR, mxConstants.NONE) != mxConstants.NONE)) ||
			mxUtils.getValue(sourceCellStyle, mxConstants.STYLE_SHAPE) == 'image') ||
			timeOnTarget > 1500 || graph.model.isEdge(state.cell)) && (timeOnTarget > this.dropTargetDelay) &&
			!this.isDropStyleTargetIgnored(state) && (labelState != null ||
			(graph.model.isVertex(state.cell) && firstVertex != null) ||
			(graph.model.isEdge(state.cell) && graph.model.isEdge(cells[0]))))
		{
			if (graph.isCellEditable((labelState != null) ? labelState.cell : state.cell))
			{
				currentStyleTarget = (labelState != null) ? labelState : state;
				styleTargetLabel = labelState != null;
				var tmp = null;

				// Places the icon at the center of the label
				if (labelState != null && labelState.text != null &&
					labelState.text.boundingBox != null)
				{
					tmp = new mxPoint(labelState.text.boundingBox.getCenterX(),
						labelState.text.boundingBox.getCenterY());
				}
				else
				{
					tmp = (graph.model.isEdge(currentStyleTarget.cell)) ?
						graph.view.getPoint(currentStyleTarget) :
						new mxPoint(currentStyleTarget.getCenterX(),
							currentStyleTarget.getCenterY());
				}

				tmp = new mxRectangle(tmp.x - this.refreshTarget.width / 2, tmp.y - this.refreshTarget.height / 2,
					this.refreshTarget.width, this.refreshTarget.height);

				styleTarget.style.left = Math.floor(tmp.x) + 'px';
				styleTarget.style.top = Math.floor(tmp.y) + 'px';

				if (styleTargetParent == null)
				{
					graph.container.appendChild(styleTarget);
					styleTargetParent = styleTarget.parentNode;
				}

				styleTargetBounds = tmp;
				checkArrow(x, y, tmp, styleTarget);
			}
		}
		// Does not reset on ignored edges or inside the icon bounds
		else if (currentStyleTarget == null || !(mxUtils.contains(currentStyleTarget, x, y) ||
			(styleTargetBounds != null && mxUtils.contains(styleTargetBounds, x, y))) ||
			(timeOnTarget > 1500 && !mxEvent.isShiftDown(evt)))
		{
			currentStyleTarget = null;
			styleTargetBounds = null;
			styleTargetLabel = false;

			if (styleTargetParent != null)
			{
				styleTarget.parentNode.removeChild(styleTarget);
				styleTargetParent = null;
			}
		}
		else if (currentStyleTarget != null && styleTargetParent != null &&
			styleTargetBounds != null)
		{
			// Sets active Arrow as side effect
			checkArrow(x, y, styleTargetBounds, styleTarget);
		}
		
		// Checks if inside bounds
		if (activeTarget && currentTargetState != null && !mxEvent.isAltDown(evt) && activeArrow == null)
		{
			// LATER: Use hit-detection for edges
			bbox = mxRectangle.fromRectangle(currentTargetState);
			
			if (graph.model.isEdge(currentTargetState.cell))
			{
				var pts = currentTargetState.absolutePoints;
				
				if (roundSource.parentNode != null)
				{
					bbox.add(checkArrow(x, y, getRoundDropBounds(pts[0]), roundSource));
				}
				
				if (roundTarget.parentNode != null)
				{
					bbox.add(checkArrow(x, y, getRoundDropBounds(pts[pts.length - 1]), roundTarget));
				}
			}
			else
			{
				var bds = mxRectangle.fromRectangle(currentTargetState);
				
				// Uses outer bounding box to take rotation into account
				if (currentTargetState.shape != null && currentTargetState.shape.boundingBox != null)
				{
					bds = mxRectangle.fromRectangle(currentTargetState.shape.boundingBox);
				}

				bds.grow(this.graph.tolerance);
				bds.grow(HoverIcons.prototype.arrowSpacing);
				
				var handler = this.graph.selectionCellsHandler.getHandler(currentTargetState.cell);
				
				if (handler != null)
				{
					bds.x -= handler.horizontalOffset / 2;
					bds.y -= handler.verticalOffset / 2;
					bds.width += handler.horizontalOffset;
					bds.height += handler.verticalOffset;
					
					// Adds bounding box of rotation handle to avoid overlap
					if (handler.rotationShape != null && handler.rotationShape.node != null &&
						handler.rotationShape.node.style.visibility != 'hidden' &&
						handler.rotationShape.node.style.display != 'none' &&
						handler.rotationShape.boundingBox != null)
					{
						bds.add(handler.rotationShape.boundingBox);
					}
				}
				
				bbox.add(checkArrow(x, y, new mxRectangle(currentTargetState.getCenterX() - this.triangleUp.width / 2,
					bds.y - this.triangleUp.height, this.triangleUp.width, this.triangleUp.height), arrowUp));
				bbox.add(checkArrow(x, y, new mxRectangle(bds.x + bds.width,
					currentTargetState.getCenterY() - this.triangleRight.height / 2,
					this.triangleRight.width, this.triangleRight.height), arrowRight));
				bbox.add(checkArrow(x, y, new mxRectangle(currentTargetState.getCenterX() - this.triangleDown.width / 2,
						bds.y + bds.height, this.triangleDown.width, this.triangleDown.height), arrowDown));
				bbox.add(checkArrow(x, y, new mxRectangle(bds.x - this.triangleLeft.width,
						currentTargetState.getCenterY() - this.triangleLeft.height / 2,
						this.triangleLeft.width, this.triangleLeft.height), arrowLeft));
			}
			
			// Adds tolerance
			if (bbox != null)
			{
				bbox.grow(10);
			}
		}
		
		if (currentStyleTarget != null && activeArrow == styleTarget)
		{
			state = currentStyleTarget;
		}

		var validTarget = (firstVertex == null || graph.isCellConnectable(cells[firstVertex])) &&
			((graph.model.isEdge(cell) && firstVertex != null) ||
			(graph.model.isVertex(cell) && graph.isCellConnectable(cell)));
		
		// Drop arrows shown after this.dropTargetDelay, hidden after 5 secs, switches arrows after 500ms
		if ((currentTargetState != null && timeOnTarget >= 5000) ||
			(currentTargetState != state &&
			(bbox == null || !mxUtils.contains(bbox, x, y) ||
			(timeOnTarget > 500 && activeArrow == null && validTarget))))
		{
			activeTarget = false;
			currentTargetState = ((timeOnTarget < 5000 && timeOnTarget > this.dropTargetDelay) ||
				graph.model.isEdge(cell)) ? state : null;

			if (currentTargetState != null && validTarget)
			{
				var elts = [roundSource, roundTarget, arrowUp, arrowRight, arrowDown, arrowLeft];
				
				for (var i = 0; i < elts.length; i++)
				{
					if (elts[i].parentNode != null)
					{
						elts[i].parentNode.removeChild(elts[i]);
					}
				}
				
				if (graph.model.isEdge(cell))
				{
					var pts = state.absolutePoints;
					
					if (pts != null)
					{
						var p0 = pts[0];
						var pe = pts[pts.length - 1];
						
						roundSource.style.left = Math.floor(p0.x - this.roundDrop.width / 2) + 'px';
						roundSource.style.top = Math.floor(p0.y - this.roundDrop.height / 2) + 'px';
						
						roundTarget.style.left = Math.floor(pe.x - this.roundDrop.width / 2) + 'px';
						roundTarget.style.top = Math.floor(pe.y - this.roundDrop.height / 2) + 'px';
						
						if (graph.model.getTerminal(cell, true) == null)
						{
							graph.container.appendChild(roundSource);
						}
						
						if (graph.model.getTerminal(cell, false) == null)
						{
							graph.container.appendChild(roundTarget);
						}

						// Activates the end under the mouse at once since a drop
						// before the next move would otherwise split the edge
						if (activeArrow == null)
						{
							checkArrow(x, y, getRoundDropBounds(p0), roundSource);
							checkArrow(x, y, getRoundDropBounds(pe), roundTarget);
						}
					}
				}
				else
				{
					var bds = mxRectangle.fromRectangle(state);
					
					// Uses outer bounding box to take rotation into account
					if (state.shape != null && state.shape.boundingBox != null)
					{
						bds = mxRectangle.fromRectangle(state.shape.boundingBox);
					}

					bds.grow(this.graph.tolerance);
					bds.grow(HoverIcons.prototype.arrowSpacing);
					
					var handler = this.graph.selectionCellsHandler.getHandler(state.cell);
					
					if (handler != null)
					{
						bds.x -= handler.horizontalOffset / 2;
						bds.y -= handler.verticalOffset / 2;
						bds.width += handler.horizontalOffset;
						bds.height += handler.verticalOffset;
						
						// Adds bounding box of rotation handle to avoid overlap
						if (handler.rotationShape != null && handler.rotationShape.node != null &&
							handler.rotationShape.node.style.visibility != 'hidden' &&
							handler.rotationShape.node.style.display != 'none' &&
							handler.rotationShape.boundingBox != null)
						{
							bds.add(handler.rotationShape.boundingBox);
						}
					}
					
					arrowUp.style.left = Math.floor(state.getCenterX() - this.triangleUp.width / 2) + 'px';
					arrowUp.style.top = Math.floor(bds.y - this.triangleUp.height) + 'px';
					
					arrowRight.style.left = Math.floor(bds.x + bds.width) + 'px';
					arrowRight.style.top = Math.floor(state.getCenterY() - this.triangleRight.height / 2) + 'px';
					
					arrowDown.style.left = arrowUp.style.left
					arrowDown.style.top = Math.floor(bds.y + bds.height) + 'px';
					
					arrowLeft.style.left = Math.floor(bds.x - this.triangleLeft.width) + 'px';
					arrowLeft.style.top = arrowRight.style.top;
					
					if (state.style['portConstraint'] != 'eastwest')
					{
						graph.container.appendChild(arrowUp);
						graph.container.appendChild(arrowDown);
					}

					graph.container.appendChild(arrowRight);
					graph.container.appendChild(arrowLeft);
				}
				
				// Hides handle for cell under mouse
				if (state != null)
				{
					currentStateHandle = graph.selectionCellsHandler.getHandler(state.cell);
					
					if (currentStateHandle != null && currentStateHandle.setHandlesVisible != null)
					{
						currentStateHandle.setHandlesVisible(false);
					}
				}
				
				activeTarget = true;
			}
			else
			{
				var elts = [roundSource, roundTarget, arrowUp, arrowRight, arrowDown, arrowLeft];
				
				for (var i = 0; i < elts.length; i++)
				{
					if (elts[i].parentNode != null)
					{
						elts[i].parentNode.removeChild(elts[i]);
					}
				}
			}
		}

		direction = mxConstants.DIRECTION_NORTH;

		if (activeArrow == arrowRight)
		{
			direction = mxConstants.DIRECTION_EAST;
		}
		else if (activeArrow == arrowDown || activeArrow == roundTarget)
		{
			direction = mxConstants.DIRECTION_SOUTH;
		}
		else if (activeArrow == arrowLeft)
		{
			direction = mxConstants.DIRECTION_WEST;
		}

		if (!activeTarget && currentStateHandle != null)
		{
			currentStateHandle.setHandlesVisible(true);
		}
		
		// Handles drop target and looks through vertices that are no drop
		// targets to find drop targets below (eg. containers under shapes)
		var target = ((!mxEvent.isAltDown(evt) || mxEvent.isShiftDown(evt)) &&
			!(currentStyleTarget != null && activeArrow == styleTarget)) ?
			graph.getCellAt(x, y, null, null, null, function(state)
			{
				return graph.model.isVertex(state.cell) &&
					!graph.isValidDropTarget(state.cell, cells, evt);
			}) : null;

		if (target != null && (activeArrow != null ||
			!graph.isSplitTarget(target, cells, evt)))
		{
			target = graph.getDropTarget(cells, evt, target, true);
		}
		
		return target;
	});
	
	// Sets active drag source
	var startDrag = dragSource.startDrag;

	dragSource.startDrag = function(evt)
	{
		sidebar.activeDragSource = this;
		startDrag.apply(this, arguments);
	};

	// Clears active drag source
	var stopDrag = dragSource.stopDrag;

	dragSource.stopDrag = function()
	{
		stopDrag.apply(this, arguments);
		var elts = [roundSource, roundTarget, styleTarget, arrowUp, arrowRight, arrowDown, arrowLeft];
		
		for (var i = 0; i < elts.length; i++)
		{
			if (elts[i].parentNode != null)
			{
				elts[i].parentNode.removeChild(elts[i]);
			}
		}
		
		if (currentTargetState != null && currentStateHandle != null)
		{
			currentStateHandle.reset();
		}
		
		sidebar.activeDragSource = null;
		currentStateHandle = null;
		currentTargetState = null;
		currentStyleTarget = null;
		styleTargetBounds = null;
		styleTargetLabel = false;
		styleTargetParent = null;
		activeArrow = null;
	};
	
	return dragSource;
};

/**
 * Returns true if the given cells are a single unconnected edge and the
 * selection consists of two connectable vertices.
 */
Sidebar.prototype.isConnectSelectedVertices = function(cells)
{
	var graph = this.editorUi.editor.graph;
	var model = graph.model;

	if (cells != null && cells.length == 1 && model.isEdge(cells[0]) &&
		model.getTerminal(cells[0], true) == null &&
		model.getTerminal(cells[0], false) == null &&
		graph.getSelectionCount() == 2)
	{
		var sel = graph.getSelectionCells();

		return sel[0] != sel[1] && model.isVertex(sel[0]) &&
			model.isVertex(sel[1]) && graph.isCellConnectable(sel[0]) &&
			graph.isCellConnectable(sel[1]);
	}

	return false;
};

/**
 * Adds a handler for inserting the cell with a single click.
 */
Sidebar.prototype.itemClicked = function(cells, ds, evt, elt)
{
	var graph = this.editorUi.editor.graph;
	graph.container.focus();

	// Tab continues in the diagram, not from the clicked shape (see getTabStart)
	this.editorUi.tabStart = null;
	
	// Alt+Click inserts and connects
	if (mxEvent.isAltDown(evt) && graph.getSelectionCount() == 1)
	{
		var freeSourceEdge = null;
		var firstVertex = null;

		for (var i = 0; i < cells.length; i++)
		{
			if (firstVertex == null && graph.model.isVertex(cells[i]))
			{
				firstVertex = i;
			}
			else if (freeSourceEdge == null && graph.model.isEdge(cells[i]) &&
					graph.model.getTerminal(cells[i], true) == null)
			{
				freeSourceEdge = i;
			}
			
			if (firstVertex != null && freeSourceEdge != null)
			{
				break;
			}
		}
		
		var index = (freeSourceEdge == null) ? firstVertex : freeSourceEdge;
		graph.setSelectionCells(this.dropAndConnect(graph.getSelectionCell(), cells,
			(mxEvent.isMetaDown(evt) || mxEvent.isControlDown(evt)) ?
			(mxEvent.isShiftDown(evt) ? mxConstants.DIRECTION_WEST : mxConstants.DIRECTION_NORTH) : 
			(mxEvent.isShiftDown(evt) ? mxConstants.DIRECTION_EAST : mxConstants.DIRECTION_SOUTH),
			index, evt, firstVertex, freeSourceEdge));
		graph.scrollCellToVisible(graph.getSelectionCell());
	}
	// Click on edge connects two selected vertices (in selection order)
	else if (!mxEvent.isAltDown(evt) && !mxEvent.isShiftDown(evt) &&
		this.isConnectSelectedVertices(cells))
	{
		var sel = graph.getSelectionCells();
		var edge = graph.cloneCell(cells[0]);
		var geo = edge.geometry;

		if (geo != null)
		{
			geo.setTerminalPoint(null, true);
			geo.setTerminalPoint(null, false);
			geo.points = null;
		}

		graph.model.beginUpdate();
		try
		{
			edge = graph.addEdge(edge, null, sel[0], sel[1]);
			graph.fireEvent(new mxEventObject('cellsInserted', 'cells', [edge]));
		}
		finally
		{
			graph.model.endUpdate();
		}

		graph.setSelectionCell(edge);
	}
	// Shift+Click updates shape
	else if (mxEvent.isShiftDown(evt) && !graph.isSelectionEmpty())
	{
		var temp = graph.getEditableCells(graph.getSelectionCells());
		graph.updateShapes(cells[0], temp, true);
		graph.scrollCellToVisible(temp);
	}
	else
	{
		var pt = (mxEvent.isAltDown(evt)) ? graph.getFreeInsertPoint() :
			graph.getCenterInsertPoint(graph.getBoundingBoxFromGeometry(cells, true));
		ds.drop(graph, evt, null, pt.x, pt.y, true);

		var sel = graph.getSelectionCells();

		if (Editor.insertAnimations && sel.length == 1 &&
			graph.model.isVertex(sel[0]))
		{
			graph.clearSelection();
			var anims = graph.createPopAnimations(sel, true);

			graph.executeAnimations(anims, function()
			{
				graph.setSelectionCells(sel);
			}, 20, 10);
		}
	}
};

/**
 * Adds a handler for inserting the cell with a single click.
 */
Sidebar.prototype.addClickHandler = function(elt, ds, cells, clickFn)
{
	var graph = this.editorUi.editor.graph;

	// Shapes are reached with the arrow keys instead of Tab, which would have to
	// pass all of them, and insert their cells with Enter and Space like a click
	elt.setAttribute('role', 'button');
	elt.setAttribute('tabindex', '-1');
	elt.setAttribute('data-sidebar-item', '1');

	mxEvent.addListener(elt, 'keydown', mxUtils.bind(this, function(evt)
	{
		if (!mxEvent.isControlDown(evt) && !mxEvent.isMetaDown(evt))
		{
			if (evt.keyCode == 13 /* Enter */ || evt.keyCode == 32 /* Space */)
			{
				if (clickFn != null)
				{
					clickFn(evt);
				}

				if (!mxEvent.isConsumed(evt))
				{
					this.itemClicked(cells, ds, evt, elt);
				}

				mxEvent.consume(evt);
			}
			// Arrow keys without Shift scroll the shapes (see EditorUi.isInScrollArea)
			else if (evt.keyCode >= 37 && evt.keyCode <= 40 && !mxEvent.isAltDown(evt) &&
				(mxEvent.isShiftDown(evt) || !this.editorUi.isInScrollArea(elt)))
			{
				this.focusItemInDirection(elt, evt.keyCode);
				mxEvent.consume(evt);
			}
		}
	}));

	var oldGetGraphForEvent = ds.getGraphForEvent;
	var oldMouseDown = ds.mouseDown;
	var oldMouseMove = ds.mouseMove;
	var oldMouseUp = ds.mouseUp;
	var tol = graph.tolerance;
	var active = false;
	var first = null;
	var sb = this;
	var op = null;

	ds.getGraphForEvent = function(evt)
	{
		if (active)
		{
			return oldGetGraphForEvent.apply(this, arguments);
		}
		else
		{
			return null;
		}
	};

	ds.mouseDown =function(evt)
	{
		oldMouseDown.apply(this, arguments);
		first = new mxPoint(mxEvent.getClientX(evt), mxEvent.getClientY(evt));
		op = elt.style.opacity;
		active = false;

		if (op == '')
		{
			op = '1';
		}
		
		if (this.dragElement != null)
		{
			this.dragElement.style.display = 'none';
		}
	};
	
	ds.mouseMove = function(evt)
	{
		active = first != null && (Math.abs(first.x - mxEvent.getClientX(evt)) > tol ||
			Math.abs(first.y - mxEvent.getClientY(evt)) > tol);

		if (active && this.dragElement != null &&
			this.dragElement.style.display == 'none')
		{
			this.dragElement.style.display = '';
		}
		
		oldMouseMove.apply(this, arguments);
	};
	
	ds.mouseUp = function(evt)
	{
		try
		{
			if (!mxEvent.isPopupTrigger(evt) && this.currentGraph == null &&
				this.dragElement != null && this.dragElement.style.display == 'none')
			{
				if (clickFn != null)
				{
					clickFn(evt);
				}

				if (!mxEvent.isConsumed(evt))
				{
					sb.itemClicked(cells, ds, evt, elt);
				}
			}
	
			oldMouseUp.apply(ds, arguments);
			first = null;
			
			// Blocks tooltips on this element after single click
			sb.currentElt = elt;
		}
		catch (e)
		{
			ds.reset();
			sb.editorUi.handleError(e);
		}
	};
};

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createVertexTemplateEntry = function(style, width, height, value, title, showLabel, showTitle, tags)
{
	if (tags != null && title != null)
	{
		tags += ' ' + title;
	}

	tags = (tags != null && tags.length > 0) ? tags : ((title != null) ? title.toLowerCase() : '');
	
	return this.addEntry(tags, mxUtils.bind(this, function()
 	{
 		return this.createVertexTemplate(style, width, height, value, title, showLabel, showTitle);
 	}));
}

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createVertexTemplate = function(style, width, height, value, title, showLabel, showTitle,
	allowCellsInserted, showTooltip, clickFn, thumbWidth, thumbHeight, icon, startEditing)
{
	var cells = [new mxCell((value != null) ? value : '', new mxGeometry(0, 0, width, height), style)];
	cells[0].vertex = true;

	return this.createVertexTemplateFromCells(cells, width, height, title, showLabel, showTitle,
		allowCellsInserted, showTooltip, clickFn, thumbWidth, thumbHeight, icon, startEditing);
};

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createVertexTemplateFromData = function(data, width, height, title, showLabel,
	showTitle, allowCellsInserted, showTooltip)
{
	var cells = null;

	try
	{
		var doc = mxUtils.parseXml(Graph.decompress(data));
		var codec = new mxCodec(doc);

		var model = new mxGraphModel();
		codec.decode(doc.documentElement, model);
		
		cells = this.graph.cloneCells(model.root.getChildAt(0).children);
	}
	catch (e)
	{
		title = mxResources.get('error') + ': ' + e.message;
	}
	
	return this.createVertexTemplateFromCells(cells, width, height, title, showLabel, showTitle,
		allowCellsInserted, showTooltip);
};

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createVertexTemplateFromCells = function(cells, width, height, title, showLabel,
	showTitle, allowCellsInserted, showTooltip, clickFn, thumbWidth, thumbHeight, icon, startEditing,
	sourceCell, connectEdge)
{
	// Use this line to convert calls to this function with lots of boilerplate code for creating cells
	//console.trace('xml', Graph.compress(mxUtils.getXml(this.graph.encodeCells(cells))), cells);

	// Edges end at the labels of new shapes with a label outside the shape
	this.graph.addLabelPerimeters(cells);

	return this.createItem(cells, title, showLabel, showTitle, width, height, allowCellsInserted,
		showTooltip, clickFn, thumbWidth, thumbHeight, icon, startEditing, sourceCell, undefined, connectEdge);
};

/**
 * 
 */
Sidebar.prototype.createEdgeTemplateEntry = function(style, width, height, value, title, showLabel,
	tags, allowCellsInserted, showTooltip)
{
	tags = (tags != null && tags.length > 0) ? tags : title.toLowerCase();
	
 	return this.addEntry(tags, mxUtils.bind(this, function()
 	{
 		return this.createEdgeTemplate(style, width, height, value, title, showLabel, allowCellsInserted, showTooltip);
 	}));
};

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createEdgeTemplate = function(style, width, height, value, title, showLabel,
	allowCellsInserted, showTooltip)
{
	var cell = new mxCell((value != null) ? value : '', new mxGeometry(0, 0, width, height), style);
	cell.geometry.setTerminalPoint(new mxPoint(0, height), true);
	cell.geometry.setTerminalPoint(new mxPoint(width, 0), false);
	cell.geometry.relative = true;
	cell.edge = true;
	
	return this.createEdgeTemplateFromCells([cell], width, height, title, showLabel, allowCellsInserted, showTooltip);
};

/**
 * Creates a drop handler for inserting the given cells.
 */
Sidebar.prototype.createEdgeTemplateFromCells = function(cells, width, height, title, showLabel,
	allowCellsInserted, showTooltip, showTitle, clickFn, thumbWidth, thumbHeight, icon)
{
	return this.createItem(cells, title, showLabel, (showTitle != null) ? showTitle : true, width, height,
		allowCellsInserted, showTooltip, clickFn, thumbWidth, thumbHeight, icon);
};

/**
 * Adds the given palette.
 */
Sidebar.prototype.addPaletteFunctions = function(id, title, expanded, fns)
{
	var div = this.addPalette(id, title, expanded, mxUtils.bind(this, function(content)
	{
		for (var i = 0; i < fns.length; i++)
		{
			var elt = fns[i](content);

			if (elt != null)
			{
				content.appendChild(elt);
			}
		}
	}));

	this.setDeferredPaletteSize(div, fns.length);

	return div;
};

/**
 * Adds the given palette. The optional eager flag forces the content
 * to be created synchronously when expanded, bypassing the deferred
 * virtualPalettes path — used for interactive palettes (user
 * libraries, scratchpad) whose content is accessed programmatically.
 */
Sidebar.prototype.addPalette = function(id, title, expanded, onInit, eager)
{
	var elt = this.createTitle(title);
	this.appendChild(elt);

	var div = document.createElement('div');
	div.className = 'geSidebar';

	// Disables built-in pan and zoom on touch devices
	if (mxClient.IS_POINTER)
	{
		div.style.touchAction = 'none';
	}

	if (expanded && this.expandLibraries)
	{
		if (this.virtualPalettes && !eager)
		{
			this.deferPaletteInit(div, elt, onInit);
		}
		else
		{
			onInit(div, elt);
		}

		onInit = null;
	}
	else
	{
		div.style.display = 'none';
	}

    this.addFoldingHandler(elt, div, onInit);
	
	var outer = document.createElement('div');
    outer.appendChild(div);
    this.appendChild(outer);
    
    // Keeps references to the DOM nodes
    if (id != null)
    {
    	this.palettes[id] = [elt, outer];
    }
    
    return div;
};

/**
 * Create the given title element.
 */
Sidebar.prototype.addFoldingHandler = function(title, content, funct)
{
	var initialized = false;

	// The label is the control for the keyboard as the title of a library
	// also contains its buttons (see Editor.addFocusRing)
	var control = title.querySelector('.geTitleLabel') || title;

	title.style.backgroundImage = (content.style.display == 'none') ?
		'url(\'' + Editor.arrowRightImage + '\')' :
		'url(\'' + Editor.arrowDownImage + '\')';

	mxEvent.addListener(title, 'click', mxUtils.bind(this, function(evt)
	{
		if (this._paletteDragging)
		{
			return;
		}

		if (title.contains(mxEvent.getSource(evt)))
		{
			if (content.style.display == 'none')
			{
				if (!initialized)
				{
					initialized = true;

					if (funct != null && this.virtualPalettes)
					{
						// Shows the palette immediately and lets the
						// observer create the content when it scrolls
						// into view (right away if the palette is in
						// view, but Expand All stays cheap for the
						// off-screen palettes)
						this.deferPaletteInit(content, title, funct);
						this.setContentVisible(content, true);
					}
					else if (funct != null)
					{
						// Wait cursor does not show up on Mac
						title.style.cursor = 'wait';

						// Captures child nodes
						var children = [];

						for (var i = 0; i < title.children.length; i++)
						{
							children.push(title.children[i]);
						}

						title.innerHTML = mxResources.get('loading') + '...';

						window.setTimeout(mxUtils.bind(this, function()
						{
							this.setContentVisible(content, true);
							title.style.cursor = '';
							title.innerHTML = '';

							// Restores child nodes
							for (var i = 0; i < children.length; i++)
							{
								title.appendChild(children[i]);
							}

							var fo = mxClient.NO_FO;
							mxClient.NO_FO = Editor.prototype.originalNoForeignObject;
							funct(content, title);
							mxClient.NO_FO = fo;
						}), (mxClient.IS_FF) ? 20 : 0);
					}
					else
					{
						this.setContentVisible(content, true);
					}
				}
				else
				{
					this.setContentVisible(content, true);
				}
				
				title.style.backgroundImage = 'url(\'' + Editor.arrowDownImage + '\')';
				control.setAttribute('aria-expanded', 'true');
			}
			else
			{
				title.style.backgroundImage = 'url(\'' + Editor.arrowRightImage + '\')';
				control.setAttribute('aria-expanded', 'false');
				this.setContentVisible(content, false);
			}

			mxEvent.consume(evt);
		}
	}));

	// Enter and Space collapse and expand the palette, Shift+Arrow Down moves
	// into its shapes if it is expanded (see addClickHandler), and Arrow Down
	// if the shapes do not scroll (see EditorUi.isInScrollArea). A click on
	// the title keeps the focus where it is.
	this.editorUi.initKeyboardButton(control);
	control.setAttribute('aria-expanded', (content.style.display == 'none') ? 'false' : 'true');

	if (control != title)
	{
		Editor.addFocusRing(control, title);
		mxEvent.preventDefault(title);
	}

	mxEvent.addListener(title, 'keydown', mxUtils.bind(this, function(evt)
	{
		if (evt.keyCode == 40 /* Down */ && !mxEvent.isAltDown(evt) && !mxEvent.isControlDown(evt) &&
			!mxEvent.isMetaDown(evt) && content.style.display != 'none' &&
			(mxEvent.isShiftDown(evt) || !this.editorUi.isInScrollArea(title)) &&
			this.focusFirstItem(content))
		{
			mxEvent.consume(evt);
		}
	}));
};

/**
 * Returns the shapes in the given palette that the keyboard reaches (see
 * addClickHandler).
 */
Sidebar.prototype.getKeyboardItems = function(content)
{
	var elts = content.querySelectorAll('[data-sidebar-item]');
	var items = [];

	for (var i = 0; i < elts.length; i++)
	{
		if (elts[i].getClientRects().length > 0)
		{
			items.push(elts[i]);
		}
	}

	return items;
};

/**
 * Moves the focus to the first shape in the given palette and returns true if
 * the focus was moved.
 */
Sidebar.prototype.focusFirstItem = function(content)
{
	var items = this.getKeyboardItems(content);

	if (items.length > 0)
	{
		items[0].focus();
	}

	return items.length > 0;
};

/**
 * Moves the focus from the given shape to the nearest shape of its palette in
 * the direction of the given arrow key or, if there is none, to the nearest
 * control, eg. the title of the palette (see EditorUi.focusTabStopInDirection).
 */
Sidebar.prototype.focusItemInDirection = function(elt, keyCode)
{
	var ui = this.editorUi;
	var picker = ui.shapePicker;
	var items = this.getKeyboardItems((picker != null && mxUtils.isAncestorNode(picker, elt)) ?
		picker : elt.parentNode);
	var bounds = elt.getBoundingClientRect();
	var dx = (keyCode == 37) ? -1 : ((keyCode == 39) ? 1 : 0);
	var dy = (keyCode == 38) ? -1 : ((keyCode == 40) ? 1 : 0);
	var next = null;
	var min = null;

	for (var i = 0; i < items.length; i++)
	{
		if (items[i] != elt)
		{
			var dist = ui.getDirectionalDistance(bounds,
				items[i].getBoundingClientRect(), dx, dy);

			if (dist != null && (min == null || dist < min))
			{
				next = items[i];
				min = dist;
			}
		}
	}

	if (next != null)
	{
		next.focus();
	}
	else
	{
		ui.focusTabStopInDirection(elt, keyCode);
	}
};

/**
 * Removes the palette for the given ID.
 */
Sidebar.prototype.setContentVisible = function(content, visible)
{
	var delay = Editor.transitionDelay;
	mxUtils.setPrefixedStyle(content.style, 'transition', 'all ' + delay + 's linear');

	if (visible)
	{
		mxUtils.setPrefixedStyle(content.style, 'transform', 'scaleY(0)');
		content.style.display = 'block';

		window.setTimeout(mxUtils.bind(this, function()
		{
			mxUtils.setPrefixedStyle(content.style, 'transform', 'scaleY(1)');

			window.setTimeout(mxUtils.bind(this, function()
			{
				mxUtils.setPrefixedStyle(content.style, 'transform', null);
				mxUtils.setPrefixedStyle(content.style, 'transition', null);
			}), delay * 1000);
		}), 0);
	}
	else
	{
		mxUtils.setPrefixedStyle(content.style, 'transform', 'scaleY(0)');

		window.setTimeout(mxUtils.bind(this, function()
		{
			mxUtils.setPrefixedStyle(content.style, 'transform', null);
			mxUtils.setPrefixedStyle(content.style, 'transition', null);
			content.style.display = 'none';
		}), delay * 1000);
	}
};

/**
 * Removes the palette for the given ID.
 */
Sidebar.prototype.removePalette = function(id)
{
	var elts = this.palettes[id];

	if (elts != null)
	{
		this.palettes[id] = null;

		for (var i = 0; i < elts.length; i++)
		{
			this.unobserveElements(elts[i]);
			this.container.removeChild(elts[i]);
		}

		return true;
	}

	return false;
};

/**
 * Adds the given image palette.
 */
Sidebar.prototype.addImagePalette = function(id, title, prefix, postfix, items, titles, tags)
{
	var fns = [];
	
	for (var i = 0; i < items.length; i++)
	{
		(mxUtils.bind(this, function(item, title, tmpTags)
		{
			if (tmpTags == null && (prefix == null || prefix.substring(0, 17) != 'img/lib/clip_art/'))
			{
				var slash = item.lastIndexOf('/');
				var dot = item.lastIndexOf('.');
				tmpTags = item.substring((slash >= 0) ? slash + 1 : 0, (dot >= 0) ? dot : item.length).replace(/[-_]/g, ' ');
			}
			
			fns.push(this.createVertexTemplateEntry('image;html=1;image=' + prefix + item + postfix,
				this.defaultImageWidth, this.defaultImageHeight, '', title, title != null, null, this.filterTags(tmpTags)));
		}))(items[i], (titles != null) ? titles[i] : null, (tags != null) ? tags[items[i]] : null);
	}

	this.addPaletteFunctions(id, title, false, fns);
};

/**
 * Creates the array of tags for the given stencil. Duplicates are allowed and will be filtered out later.
 */
Sidebar.prototype.getTagsForStencil = function(packageName, stencilName, moreTags)
{
	var tags = packageName.split('.');
	
	for (var i = 1; i < tags.length; i++)
	{
		tags[i] = tags[i].replace(/_/g, ' ')
	}
	
	tags.push(stencilName.replace(/_/g, ' '));
	
	if (moreTags != null)
	{
		tags.push(moreTags);
	}
	
	return tags.slice(1, tags.length);
};

/**
 * Adds the given stencil palette.
 */
Sidebar.prototype.addStencilPalette = function(id, title, stencilFile, style, ignore, onInit, scale, tags, customFns, groupId)
{
	scale = (scale != null) ? scale : 1;

	if (this.addStencilsToIndex)
	{
		// LATER: Handle asynchronous loading dependency
		var fns = [];
		
		if (customFns != null)
		{
			for (var i = 0; i < customFns.length; i++)
			{
				fns.push(customFns[i]);
			}
		}

		mxStencilRegistry.loadStencilSet(stencilFile, mxUtils.bind(this, function(packageName, stencilName, displayName, w, h)
		{
			if (ignore == null || mxUtils.indexOf(ignore, stencilName) < 0)
			{
				var tmp = this.getTagsForStencil(packageName, stencilName);
				var tmpTags = (tags != null) ? tags[stencilName] : null;

				if (tmpTags != null)
				{
					tmp.push(tmpTags);
				}
				
				fns.push(this.createVertexTemplateEntry('shape=' + packageName + stencilName.toLowerCase() + style,
					Math.round(w * scale), Math.round(h * scale), '', stencilName.replace(/_/g, ' '), null, null,
					this.filterTags(tmp.join(' '))));
			}
		}), true, true);
	
		this.addPaletteFunctions(id, title, false, fns);
	}
	else
	{
		this.addPalette(id, title, false, mxUtils.bind(this, function(content)
	    {
			if (style == null)
			{
				style = '';
			}
			
			if (onInit != null)
			{
				onInit.call(this, content);
			}
			
			if (customFns != null)
			{
				for (var i = 0; i < customFns.length; i++)
				{
					customFns[i](content);
				}
			}

			mxStencilRegistry.loadStencilSet(stencilFile, mxUtils.bind(this, function(packageName, stencilName, displayName, w, h)
			{
				if (ignore == null || mxUtils.indexOf(ignore, stencilName) < 0)
				{
					content.appendChild(this.createVertexTemplate('shape=' + packageName + stencilName.toLowerCase() + style,
						Math.round(w * scale), Math.round(h * scale), '', stencilName.replace(/_/g, ' '), true));
				}
			}), true);
	    }));
	}
};

/**
 * Adds the given stencil palette.
 */
Sidebar.prototype.destroy = function()
{
	if (this.graph != null)
	{
		if (this.graph.container != null && this.graph.container.parentNode != null)
		{
			this.graph.container.parentNode.removeChild(this.graph.container);
		}
		
		this.graph.destroy();
		this.graph = null;
	}

	if (this.escapeListener != null)
	{
		this.editorUi.editor.graph.removeListener(this.escapeListener);
		this.escapeListener = null;
	}
	
	if (this.refreshListener != null)
	{
		this.editorUi.removeListener(this.refreshListener);
		this.refreshListener = null;
	}
	
	if (this.pointerUpHandler != null)
	{
		mxEvent.removeListener(document, (mxClient.IS_POINTER) ? 'pointerup' : 'mouseup', this.pointerUpHandler);
		this.pointerUpHandler = null;
	}

	if (this.pointerDownHandler != null)
	{
		mxEvent.removeListener(document, (mxClient.IS_POINTER) ? 'pointerdown' : 'mousedown', this.pointerDownHandler);
		this.pointerDownHandler = null;
	}
	
	if (this.pointerMoveHandler != null)
	{
		mxEvent.removeListener(document, (mxClient.IS_POINTER) ? 'pointermove' : 'mousemove', this.pointerMoveHandler);
		this.pointerMoveHandler = null;
	}
	
	if (this.pointerOutHandler != null)
	{
		mxEvent.removeListener(document, (mxClient.IS_POINTER) ? 'pointerout' : 'mouseout', this.pointerOutHandler);
		this.pointerOutHandler = null;
	}
};
