"""Markdown editor real Chromium workflows. Run from workspace root."""
import asyncio, json, os, sys
from pathlib import Path
from playwright.async_api import async_playwright
BASE = os.getenv('TOOLBOX_TEST_BASE', 'http://127.0.0.1:8765').rstrip('/')
sys.stdout.reconfigure(encoding='utf8')
async def set_text(page, text):
    await page.get_by_role('textbox', name='Markdown 编辑区', exact=True).fill(text)
    await page.wait_for_timeout(250)
async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={'width':1440,'height':900}, accept_downloads=True)
        errors, external, failed = [], [], []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: external.append(r.url) if r.url.startswith('http') and not r.url.startswith(BASE) else None)
        page.on('response', lambda r: failed.append(r.url) if r.status >= 400 else None)
        response = await page.goto(BASE+'/tools/markdown/')
        assert response.status == 200, 'Markdown editor entry must exist'
        await page.get_by_role('textbox',name='Markdown 编辑区',exact=True).wait_for()
        text = '# 中文笔记\n\n| 项目 | 状态 |\n| --- | --- |\n| Markdown | 完成 |\n\n- [x] 任务\n\n~~删除~~\n\n```javascript\nconst value = 42;\n```'
        await set_text(page,text)
        preview = page.locator('#preview')
        assert await preview.locator('h1').inner_text() == '中文笔记'
        assert await preview.locator('table td').count() == 2
        assert await preview.locator('input[type=checkbox]:checked').count() == 1
        assert await preview.locator('del').inner_text() == '删除'
        assert await preview.locator('code .hljs-keyword').count() > 0
        await set_text(page,'快捷键')
        await page.get_by_role('textbox',name='Markdown 编辑区',exact=True).press('ControlOrMeta+a')
        await page.keyboard.press('ControlOrMeta+b')
        assert await preview.locator('strong').inner_text() == '快捷键'
        await page.get_by_role('button',name='斜体',exact=True).click()
        await page.wait_for_timeout(250)
        assert await preview.locator('em').count() == 1
        await page.locator('#file-input').set_input_files({'name':'中文笔记.md','mimeType':'text/markdown','buffer':text.encode()})
        await page.wait_for_timeout(300)
        async with page.expect_download() as info:
            await page.get_by_role('button',name='导出 MD',exact=True).click()
        assert Path(await (await info.value).path()).read_text(encoding='utf8') == text
        async with page.expect_download() as info:
            await page.get_by_role('button',name='导出 HTML',exact=True).click()
        html = Path(await (await info.value).path()).read_text(encoding='utf8')
        assert '<table>' in html and '<style>' in html and '<script' not in html
        await page.wait_for_timeout(1000)
        await page.reload()
        await page.get_by_role('textbox',name='Markdown 编辑区',exact=True).wait_for()
        async with page.expect_download() as info:
            await page.get_by_role('button',name='导出 MD',exact=True).click()
        restored=Path(await (await info.value).path()).read_text(encoding='utf8')
        assert restored == text, repr(restored)
        hostile = '<script>window.pwned=1</script><iframe src="https://tracker.invalid/frame"></iframe><img src="https://tracker.invalid/pixel" onerror="window.pwned=1"><img src="/missing-pixel" srcset="https://tracker.invalid/a 2x"><a href="javascript:alert(1)">坏链接</a><a href="data:text/html,<script>alert(1)</script>">数据链接</a>\n\n[外链](https://example.com)\n\n![图片](https://tracker.invalid/md)\n\n<style>body{background:url(https://tracker.invalid/css)}</style>'
        await set_text(page,hostile)
        assert await page.evaluate('window.pwned') is None
        assert await preview.locator('script,iframe,style,img,[onerror],[srcset]').count() == 0
        assert await preview.locator('a[href^="javascript:"],a[href^="data:"]').count() == 0
        assert await preview.locator('a[href="https://example.com"]').get_attribute('rel') == 'noopener noreferrer'
        async with page.expect_download() as info:
            await page.get_by_role('button',name='导出 HTML',exact=True).click()
        html = Path(await (await info.value).path()).read_text(encoding='utf8')
        assert '<iframe' not in html and '<script' not in html and '<img' not in html and 'onerror' not in html
        await set_text(page,'# 保留草稿')
        await page.wait_for_timeout(900)
        for width,height in [(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
            await page.set_viewport_size({'width':width,'height':height})
            await page.get_by_role('button',name='预览',exact=True).click()
            assert await preview.locator('h1').is_visible()
            assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'), (width,height)
            await page.get_by_role('button',name='编辑',exact=True).click()
            assert await page.get_by_role('textbox',name='Markdown 编辑区',exact=True).is_visible()
        await page.set_viewport_size({'width':1440,'height':900})
        await page.get_by_role('button',name='分栏',exact=True).click()
        await page.screenshot(path='_scratch/ops-tests/markdown-desktop.png')
        await page.set_viewport_size({'width':390,'height':844})
        await page.screenshot(path='_scratch/ops-tests/markdown-mobile.png')
        await page.evaluate('''async () => { const db=await new Promise((ok,no)=>{const r=indexedDB.open('toolbox-markdown',1);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});await new Promise((ok,no)=>{const t=db.transaction('drafts','readwrite');t.objectStore('drafts').put({version:99,text:123,original:'preserve me'},'current');t.oncomplete=ok;t.onerror=no});db.close()}''')
        await page.reload()
        await page.get_by_text('本地草稿无法读取，已暂停自动保存。原始数据仍保留。',exact=True).wait_for()
        await set_text(page,'不能覆盖损坏记录')
        await page.wait_for_timeout(1000)
        record = await page.evaluate('''async () => {const db=await new Promise(ok=>{const r=indexedDB.open('toolbox-markdown',1);r.onsuccess=()=>ok(r.result)});return await new Promise(ok=>{const r=db.transaction('drafts').objectStore('drafts').get('current');r.onsuccess=()=>ok(r.result)})}''')
        assert record['original'] == 'preserve me'
        async with page.expect_download() as info:
            await page.get_by_role('button',name='下载原始草稿',exact=True).click()
        assert 'preserve me' in Path(await (await info.value).path()).read_text(encoding='utf8')
        assert not errors, errors
        assert not external, external
        assert not failed, failed
        result = {'input_preview_gfm_highlight':True,'toolbar_shortcut':True,'import_md_export_md_html':True,'draft_refresh_corruption_protection':True,'xss_and_default_image_requests_blocked':True,'viewports':5,'external_requests':external,'page_errors':errors,'failed_requests':failed}
        Path('_scratch/ops-tests/markdown-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps(result,ensure_ascii=False))
        await browser.close()
asyncio.run(main())
