"""Markdown safety, recovery, offline export and print checks."""
import asyncio, json, os, sys
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
sys.stdout.reconfigure(encoding='utf8')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch();page=await browser.new_page(viewport={'width':1280,'height':800},accept_downloads=True);errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/markdown/');editor=page.get_by_role('textbox',name='Markdown 编辑区',exact=True);await editor.wait_for()
  # Large fenced blocks must remain readable without expensive syntax work.
  large_code='const value = 42;\n'*4000
  await page.locator('#file-input').set_input_files({'name':'large-code.md','mimeType':'text/markdown','buffer':('```javascript\n'+large_code+'```').encode()});await page.wait_for_timeout(350)
  assert await page.locator('#preview code').inner_text()==large_code.rstrip('\n')
  assert await page.locator('#preview code .hljs-keyword').count()==0, 'large blocks skip syntax highlighting'
  await page.locator('#file-input').set_input_files({'name':'empty.md','mimeType':'text/markdown','buffer':b''});await page.wait_for_timeout(250)
  assert await page.locator('#preview').inner_text()==''
  async with page.expect_download() as info:await page.get_by_role('button',name='导出 MD',exact=True).click()
  assert Path(await (await info.value).path()).read_bytes()==b''
  await page.locator('#file-input').set_input_files({'name':'note.txt','mimeType':'text/plain','buffer':'# 导入中文 TXT\n\n一段正文。\n'.encode()});await page.wait_for_timeout(250)
  assert await page.locator('#preview h1').inner_text()=='导入中文 TXT'
  await page.locator('#file-input').set_input_files({'name':'bad.md','mimeType':'text/markdown','buffer':b'\xff\xfe\x00'});await page.get_by_text('无法导入，请使用 UTF-8 编码的 Markdown 或纯文本文件',exact=True).wait_for()
  assert await page.locator('#preview h1').inner_text()=='导入中文 TXT'
  await page.locator('#file-input').set_input_files({'name':'large.md','mimeType':'text/markdown','buffer':b'a'*(2*1024*1024+1)});await page.get_by_text('请选择不超过 2 MB 的 .md / .txt 文件',exact=True).wait_for()
  assert await page.locator('#preview h1').inner_text()=='导入中文 TXT'
  # User explicitly opts in, fixture stays on the same local origin.
  await page.route(BASE+'/markdown-fixture.png',lambda route:route.fulfill(status=200,content_type='image/png',body=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082')))
  await editor.fill(f'# 打印测试\n\n![本地测试图]({BASE}/markdown-fixture.png)\n\n| 列 | 内容 |\n| --- | --- |\n| 一 | 二 |\n\n```python\nprint("你好")\n```');await page.wait_for_timeout(250)
  assert await page.locator('#preview img').count()==0
  await page.get_by_label('加载外部图片',exact=True).check();await page.locator('#preview img').wait_for();await page.wait_for_function("document.querySelector('#preview img').complete")
  assert await page.locator('#preview img').get_attribute('referrerpolicy')=='no-referrer'
  async with page.expect_download() as info:await page.get_by_role('button',name='导出 HTML',exact=True).click()
  exported=Path(await (await info.value).path()).read_text(encoding='utf8');assert '<img' not in exported
  offline=await browser.new_page();requests=[];offline.on('request',lambda r:requests.append(r.url));await offline.set_content(exported)
  assert await offline.locator('h1').inner_text()=='打印测试';assert await offline.locator('table').count()==1;assert requests==[],requests
  await page.get_by_label('加载外部图片',exact=True).uncheck()
  await page.evaluate('window.print=()=>{window.printCalled=true}')
  await page.get_by_role('button',name='打印 / PDF',exact=True).click();assert await page.evaluate('window.printCalled')
  await page.emulate_media(media='print');assert not await page.locator('header').is_visible();assert not await page.locator('#editor').is_visible();assert await page.locator('#preview h1').is_visible()
  await page.pdf(path='_scratch/ops-tests/markdown-print.pdf',format='A4');assert Path('_scratch/ops-tests/markdown-print.pdf').read_bytes().startswith(b'%PDF-')
  await page.emulate_media(media='screen');await page.wait_for_timeout(800)
  # Check damaged raw draft survives an explicit "new draft" as a separate key.
  await page.evaluate('''async()=>{const db=await new Promise(ok=>{const r=indexedDB.open('toolbox-markdown',1);r.onsuccess=()=>ok(r.result)});await new Promise(ok=>{const t=db.transaction('drafts','readwrite');t.objectStore('drafts').put({broken:'recoverable'},'current');t.oncomplete=ok});db.close()}''')
  await page.reload();await page.get_by_role('button',name='另存新草稿',exact=True).wait_for();await editor.fill('# 新草稿');await page.get_by_role('button',name='另存新草稿',exact=True).click();await page.get_by_text('已另存新草稿，原始记录已保留为恢复副本',exact=True).wait_for()
  records=await page.evaluate('''async()=>{const db=await new Promise(ok=>{const r=indexedDB.open('toolbox-markdown',1);r.onsuccess=()=>ok(r.result)});return await new Promise(ok=>{const r=db.transaction('drafts').objectStore('drafts').getAll();r.onsuccess=()=>ok(r.result)})}''')
  assert any(r.get('broken')=='recoverable' for r in records);assert any(r.get('text')=='# 新草稿' for r in records)
  unavailable=await browser.new_page();await unavailable.add_init_script("Object.defineProperty(window,'indexedDB',{get(){throw new Error('disabled')}})");await unavailable.goto(BASE+'/tools/markdown/');await unavailable.get_by_role('textbox',name='Markdown 编辑区',exact=True).wait_for();await unavailable.get_by_text('本地草稿无法读取，已暂停自动保存。原始数据仍保留。',exact=True).wait_for();assert await unavailable.locator('#raw-draft').is_disabled();assert await unavailable.locator('#new-draft').is_disabled()
  assert errors==[],errors
  results={'txt_import':True,'invalid_large_import_preserves_document':True,'images_explicit_opt_in':True,'export_html_offline_no_requests':True,'print_button_and_pdf':True,'damaged_draft_backup_and_restart':True,'storage_unavailable_fallback':True,'page_errors':errors}
  Path('_scratch/ops-tests/markdown-edge-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(results,ensure_ascii=False));await browser.close()
asyncio.run(main())
