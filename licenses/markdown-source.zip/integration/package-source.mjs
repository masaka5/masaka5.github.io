import {readFile,writeFile,readdir,stat,mkdir,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {zipSync} from 'fflate';
const root=path.dirname(fileURLToPath(import.meta.url));
const site=path.resolve(root,'../../toolbox-site');
const licenses=path.join(site,'licenses');
const lock=JSON.parse(await readFile(path.join(root,'package-lock.json'),'utf8'));
const archive={};
const deps=[];
const notice=['Markdown 编辑器 — 完整第三方许可\n\n本文件包括锁定依赖的版权声明与完整许可正文。生产依赖公开分发源码同时收录在 markdown-source.zip 的 upstream/。构建依赖按 lockfile 可由 npm ci 获取。\n'];
async function collect(folder,prefix,excludeNodeModules=false) {
  for (const entry of await readdir(folder,{withFileTypes:true})) {
    if (entry.name==='.git' || (excludeNodeModules && entry.name==='node_modules')) continue;
    const file=path.join(folder,entry.name);
    if (entry.isDirectory()) await collect(file,prefix+'/'+entry.name,excludeNodeModules);
    else if(entry.isFile()) archive[prefix+'/'+entry.name]=new Uint8Array(await readFile(file));
  }
}
await collect(root,'integration',true);
for (const [key,entry] of Object.entries(lock.packages)) {
  if (!key || !key.includes('node_modules/')) continue;
  const folder=path.join(root,key);
  let pkg;
  try {pkg=JSON.parse(await readFile(path.join(folder,'package.json'),'utf8'));} catch {continue;} // other-platform optional build binaries
  const name=pkg.name || key.split('node_modules/').pop();
  const licenseFiles=(await readdir(folder)).filter(file=>/^(licen[sc]e|copying|notice)([.-]|$)/i.test(file));
  const files=[];
  for(const file of licenseFiles) if((await stat(path.join(folder,file))).isFile()) files.push(file);
  // esbuild's platform binary package uses the parent esbuild project's MIT
  // license; npm distributes that full text in the parent package.
  const inheritedLicense=name.startsWith('@esbuild/') ? path.join(root,'node_modules/esbuild/LICENSE.md') : null;
  if(!files.length && inheritedLicense) files.push('LICENSE.md (esbuild project)');
  if(!files.length) throw new Error(`No full license found for ${name}`);
  deps.push({name,version:pkg.version,license:pkg.license || entry.license,developmentOnly:!!entry.dev,source:entry.resolved,integrity:entry.integrity,repository:typeof pkg.repository==='string'?pkg.repository:pkg.repository?.url,licenseFiles:files});
  notice.push(`\n${'='.repeat(72)}\n${name} ${pkg.version} — ${pkg.license || entry.license}\n${entry.dev?'Build dependency':'Runtime dependency'}\nSource: ${entry.resolved}\n`);
  for(const file of files) notice.push(`\n--- ${file} ---\n${await readFile(file.endsWith('(esbuild project)')?inheritedLicense:path.join(folder,file),'utf8')}\n`);
  if(!entry.dev) await collect(folder,'upstream/'+name,true);
}
const tests=path.resolve(root,'../ops-tests');
for(const file of ['markdown-browser.py','markdown-edge.py']) archive['tests/'+file]=new Uint8Array(await readFile(path.join(tests,file)));
archive['THIRD-PARTY-NOTICES.txt']=new TextEncoder().encode(notice.join(''));
await mkdir(licenses,{recursive:true});
await writeFile(path.join(licenses,'markdown-third-party.txt'),notice.join(''));
await copyFile(path.join(root,'LICENSE'),path.join(licenses,'markdown-MIT.txt'));
await writeFile(path.join(licenses,'markdown-source.zip'),zipSync(archive,{level:6}));
const files=[];
async function manifestFiles(folder) {
 for(const entry of await readdir(folder,{withFileTypes:true})) {
  const file=path.join(folder,entry.name);
  if(entry.isDirectory()) await manifestFiles(file);
  else {const bytes=await readFile(file);files.push({path:path.relative(site,file).split(path.sep).join('/'),bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
 }
}
await manifestFiles(path.join(site,'tools/markdown'));
for(const file of ['markdown-third-party.txt','markdown-MIT.txt','markdown-source.zip','markdown.html']) {
 const bytes=await readFile(path.join(licenses,file));files.push({path:'licenses/'+file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
}
await writeFile(path.join(licenses,'markdown-manifest.json'),JSON.stringify({name:'toolbox-markdown',version:'1.0.0',entry:'tools/markdown/',license:'MIT; third-party notices included',build:'npm ci && npm run build && npm run package-source',supports:['CodeMirror 6 editing','GFM preview','syntax highlight','toolbar and keyboard shortcuts','UTF-8 md/txt import','Markdown and self-contained HTML export','browser print/PDF','IndexedDB local draft with corruption protection','desktop split and mobile tabs'],security:{rawHTML:false,remoteImages:'off by default; explicit session-only HTTP(S) opt-in',htmlExport:'sanitized with embedded styles, no scripts or remote images'},dependencies:deps,files},null,2)+'\n');
console.log(`Packaged ${deps.length} dependency notices and ${Object.keys(archive).length} source files; SHA-256 manifest written.`);
