# Markdown 编辑器集成

独立静态入口：`toolbox-site/tools/markdown/`。界面为中文，延续工具站白、灰、蓝配色；桌面默认左右分栏，宽度不超过 800px 时用编辑 / 预览切换。内容在浏览器处理，无账号、广告、遥测或服务端接口。

## 构建

需要 Node.js 22 或更新版本及 npm。在本目录运行：

```sh
npm ci
npm run build
npm audit --omit=dev
npm run package-source
```

`build.mjs` 以相对路径输出到 `../../toolbox-site/tools/markdown/`，可在 GitHub Pages 子路径使用。依赖版本和完整依赖树锁定在 `package-lock.json`。构建工具为 esbuild，源码归档工具为 fflate；运行时所有代码均自托管，无 CDN。`package-source` 会重新生成 `licenses/markdown-source.zip`、第三方完整许可和带 SHA-256 的 manifest，运行它前先完成 build。

运行时核心：CodeMirror 6、marked、DOMPurify、highlight.js。highlight.js 收录 JavaScript、TypeScript、Python、JSON、Bash、CSS、XML/HTML、Markdown、SQL、Java、C++、Go、Rust、YAML；其他代码块保留纯文本。单个代码块超过 20,000 字符时跳过语法高亮，保留全文以避免大块代码执行语法正则的开销。GFM 表格、任务清单、删除线和围栏代码块由 marked 解析，未实现数学公式、Mermaid、脚注或 Markdown 扩展插件。

## 文档与安全边界

- 纯文本 Markdown 编辑；工具栏和 Ctrl / ⌘ B、I、K 常用格式，Ctrl / ⌘ S 导出 MD；CodeMirror 提供撤销 / 重做与原生编辑快捷键。
- UTF-8 `.md` / `.markdown` / `.txt` 导入，最大 2 MiB；编辑文档最大 2,097,152 个 UTF-16 字符。导出 Markdown 为当前原文，HTML 为经过净化的独立文档；HTML 内嵌样式与高亮，无脚本，无图片网络资源。打印使用浏览器原生打印 / 保存 PDF。
- 原生 HTML 标签禁用；渲染结果再交给 DOMPurify 白名单净化。预览不允许 iframe、脚本、SVG、表单、style 或事件属性；危险链接协议不进入预览。外部 HTTP(S) 链接使用 `noopener noreferrer`。
- Markdown 图片默认只显示说明，无论是否同源均不请求。用户勾选“加载外部图片”后仅允许 Markdown 语法的 HTTP(S) 图片，使用 `no-referrer`；选择只在当前页生效，不写入草稿。此时图片地址的服务器会收到普通图片请求。导出 HTML 始终排除网络图片，保证离线可读。
- 草稿存储在 IndexedDB 数据库 `toolbox-markdown`、store `drafts`、key `current`。文本改变后 650ms 延迟保存，隐藏页面时尽力提交；未保存时关闭页签会由浏览器提示。浏览器清除站点数据会清除草稿，建议导出文件保留长期副本。
- 启动时读取和验证草稿，验证失败 / 存储失败时暂停自动保存，不覆盖原记录。支持下载原始 JSON；“另存新草稿”会在同一事务中把原记录复制到 `recovery-时间戳`，再写入当前草稿。数据库不可用时可继续编辑并导出。

## 验证

从工作区根目录启动静态 HTTP 服务，根目录指向 `toolbox-site`，然后运行（要求 Python Playwright / Chromium）：

```sh
python -m http.server 8765 --directory toolbox-site
python _scratch/ops-tests/markdown-browser.py
python _scratch/ops-tests/markdown-edge.py
```

可用 `TOOLBOX_TEST_BASE` 指定不同服务地址。主测试验证输入 → 预览、GFM、高亮、格式快捷键、导入 / 下载、刷新草稿、安全渲染、损坏草稿保护、五种 viewport 无外层滚动，以及无外部请求、页面错误或失败资源。边界测试验证 TXT / 无效 / 超限导入、图片明确选择、离线 HTML、打印按钮 / PDF、损坏数据备份和数据库不可用回退。测试结果 JSON、桌面 / 手机截图和打印 PDF 在 `_scratch/ops-tests/markdown-*`。

项目新增集成代码为 MIT。依赖独立版权与许可见 `toolbox-site/licenses/markdown-third-party.txt`；源码包收录集成源码、锁文件、测试和已安装生产依赖的公开分发源码。
