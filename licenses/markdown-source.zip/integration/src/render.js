import { Marked } from 'marked';
import DOMPurify from 'dompurify';
import hljs from 'highlight.js/lib/core';
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import python from 'highlight.js/lib/languages/python';
import json from 'highlight.js/lib/languages/json';
import bash from 'highlight.js/lib/languages/bash';
import css from 'highlight.js/lib/languages/css';
import xml from 'highlight.js/lib/languages/xml';
import markdown from 'highlight.js/lib/languages/markdown';
import sql from 'highlight.js/lib/languages/sql';
import java from 'highlight.js/lib/languages/java';
import cpp from 'highlight.js/lib/languages/cpp';
import go from 'highlight.js/lib/languages/go';
import rust from 'highlight.js/lib/languages/rust';
import yaml from 'highlight.js/lib/languages/yaml';
import proseCSS from './markdown.css' with { type: 'text' };

for (const [name, language] of Object.entries({javascript,typescript,python,json,bash,css,xml,markdown,sql,java,cpp,go,rust,yaml})) hljs.registerLanguage(name, language);
const escape = text => String(text).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));

// Raw HTML is deliberately disabled. Images are rendered only from Markdown
// tokens after an explicit session-only choice; never parse untrusted HTML in
// the live document before sanitization.
export function renderMarkdown(text, allowImages = false) {
  const parser = new Marked({gfm:true,breaks:false,renderer:{
    html() { return ''; },
    image({href,title,text}) {
      if (!allowImages || !/^https?:\/\//i.test(href)) return `<span class="blocked-image">图片：${escape(text || '未命名')}（未加载）</span>`;
      return `<img src="${escape(href)}" alt="${escape(text)}"${title ? ` title="${escape(title)}"` : ''} loading="lazy" referrerpolicy="no-referrer">`;
    },
    code({text,lang}) {
      const language = (lang || '').split(/\s/)[0].toLowerCase();
      // Keep large pasted/imported blocks responsive. They stay fully visible,
      // but do not feed an unbounded string into language regex grammars.
      const result = text.length <= 20_000 && hljs.getLanguage(language) ? hljs.highlight(text,{language,ignoreIllegals:true}).value : escape(text);
      return `<pre><code class="hljs${hljs.getLanguage(language) ? ` language-${escape(language)}` : ''}">${result}</code></pre>\n`;
    }
  }});
  const html = DOMPurify.sanitize(parser.parse(text), {
    ALLOWED_TAGS:['p','br','hr','h1','h2','h3','h4','h5','h6','blockquote','ul','ol','li','strong','em','del','pre','code','a','table','thead','tbody','tr','th','td','input','span',...(allowImages ? ['img'] : [])],
    ALLOWED_ATTR:['href','title','class','type','checked','disabled','start','align','src','alt','loading','referrerpolicy'],
    ALLOW_DATA_ATTR:false,
    FORBID_ATTR:['style','srcset'],
    ALLOWED_URI_REGEXP:/^(?:(?:https?|mailto):|[^a-z]|[a-z+.-]+(?:[^a-z+.-:]|$))/i
  });
  // Detached template cannot initiate requests. Only sanitized content reaches
  // the live preview. External links always leave without an opener/referrer.
  const template = document.createElement('template');
  template.innerHTML = html;
  for (const link of template.content.querySelectorAll('a')) {
    const href = link.getAttribute('href') || '';
    if (/^https?:/i.test(href)) {
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
    }
  }
  for (const input of template.content.querySelectorAll('input')) {
    input.type = 'checkbox';
    input.disabled = true;
    input.setAttribute('aria-label',input.checked ? '已完成任务' : '未完成任务');
  }
  return template.innerHTML;
}

export function exportHTML(text) {
  // Export is self-contained and always excludes all network images even if
  // the live-preview opt-in is active.
  const content = renderMarkdown(text, false);
  return `<!doctype html>\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src 'none'; base-uri 'none'; form-action 'none'"><title>Markdown 文档</title><style>${proseCSS}\nbody{margin:0;padding:40px 24px;background:white}.markdown-body{max-width:900px;margin:auto}@media print{body{padding:0}.markdown-body pre{white-space:pre-wrap}}</style></head><body><article class="markdown-body">${content}</article></body></html>`;
}
