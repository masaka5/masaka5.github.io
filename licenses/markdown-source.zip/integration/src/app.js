import { EditorState } from '@codemirror/state';
import { EditorView, keymap, lineNumbers, drawSelection, highlightActiveLine } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab, undo, redo } from '@codemirror/commands';
import { syntaxHighlighting, defaultHighlightStyle } from '@codemirror/language';
import { markdown } from '@codemirror/lang-markdown';
import { renderMarkdown, exportHTML } from './render.js';
import { MAX_LENGTH, validDraft, openDrafts, readDraft, saveDraft } from './draft.js';
import './style.css';

const $ = selector => document.querySelector(selector);
const status = message => { $('#status').textContent = message; };
const initial = '# 开始写作\n\n在左侧输入 Markdown，右侧实时预览。文档仅保存在此浏览器。\n\n## 一份简单的清单\n\n- [x] 支持表格、任务和删除线\n- [ ] 写下你的下一步\n\n| 快捷键 | 操作 |\n| --- | --- |\n| Ctrl / ⌘ B | 加粗 |\n| Ctrl / ⌘ I | 斜体 |\n| Ctrl / ⌘ K | 链接 |\n| Ctrl / ⌘ S | 导出 Markdown |\n\n```javascript\nconst greeting = "你好，世界";\nconsole.log(greeting);\n```\n\n> 导入 .md / .txt 文件，或直接开始编辑。\n';
let db, view, saveTimer, renderTimer, rawDraft, blocked=false, dirty=false, name='未命名', importedToken=0;
const snapshot = () => ({version:1,text:view.state.doc.toString(),name,updated:Date.now()});
function showRecovery() {
  blocked=true;
  $('#recovery').hidden=false;
  $('#raw-draft').disabled=rawDraft===undefined;
  $('#new-draft').disabled=!db;
}
async function persist() {
  clearTimeout(saveTimer);
  if (!dirty || blocked || !db) return;
  const record=snapshot();
  try {
    await saveDraft(db,record);
    if (record.text===view.state.doc.toString()) {
      dirty=false;
      status('草稿已保存在此浏览器');
    }
  } catch {
    showRecovery();
    status('本地保存失败，请导出 MD 保留文档');
  }
}
function render() {
  clearTimeout(renderTimer);
  const text=view.state.doc.toString();
  $('#preview').innerHTML=renderMarkdown(text,$('#allow-images').checked);
  $('#count').textContent=`${text.length.toLocaleString('zh-CN')} 字符 · ${view.state.doc.lines.toLocaleString('zh-CN')} 行`;
}
function changed() {
  dirty=true;
  clearTimeout(saveTimer);
  clearTimeout(renderTimer);
  renderTimer=setTimeout(render,100);
  if (!blocked) {
    status('正在保存…');
    saveTimer=setTimeout(persist,650);
  }
}
function download(data,type,extension,fileName=name) {
  const blob=new Blob([data],{type});
  const url=URL.createObjectURL(blob);
  const link=document.createElement('a');
  link.href=url;
  link.download=fileName.replace(/[<>:"/\\|?*\u0000-\u001f]/g,'_').slice(0,120)+extension;
  link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function exportMD() { download(view.state.doc.toString(),'text/markdown;charset=utf-8','.md'); return true; }
function format(kind) {
  const {from,to}=view.state.selection.main;
  const selected=view.state.sliceDoc(from,to);
  let before='',after='',placeholder='文本';
  if (kind==='bold') before=after='**';
  if (kind==='italic') before=after='*';
  if (kind==='strike') before=after='~~';
  if (kind==='link') {before='[';after='](https://example.com)';placeholder='链接文字';}
  if (kind==='code') {before='\n```\n';after='\n```\n';placeholder='代码';}
  if (kind==='table') {before='\n';after='\n';placeholder='| 标题 | 标题 |\n| --- | --- |\n| 内容 | 内容 |';}
  let insert,anchor,head;
  if (['heading','quote','list','task'].includes(kind)) {
    const prefix={heading:'## ',quote:'> ',list:'- ',task:'- [ ] '}[kind];
    const start=view.state.doc.lineAt(from).from;
    const end=view.state.doc.lineAt(to).to;
    insert=view.state.sliceDoc(start,end).split('\n').map(line=>prefix+line).join('\n');
    view.dispatch({changes:{from:start,to:end,insert},selection:{anchor:start,head:start+insert.length},scrollIntoView:true});
  } else {
    insert=before+(selected||placeholder)+after;
    anchor=from+before.length;head=anchor+(selected||placeholder).length;
    view.dispatch({changes:{from,to,insert},selection:{anchor,head},scrollIntoView:true});
  }
  view.focus();
  return true;
}
const media=matchMedia('(max-width:800px)');
function setMode(mode) {
  const workspace=$('#workspace');
  workspace.dataset.mode=mode;
  workspace.dataset.mobileMode=mode==='preview' ? 'preview' : 'edit';
  for (const button of document.querySelectorAll('button[data-mode]')) button.setAttribute('aria-pressed',String(button.dataset.mode===(media.matches && mode==='split'?'edit':mode)));
  requestAnimationFrame(()=>view?.requestMeasure());
}
async function start() {
  let text=initial;
  try {
    db=await openDrafts();
    rawDraft=await readDraft(db);
    if (rawDraft!==undefined) {
      if (!validDraft(rawDraft)) throw new Error('invalid draft');
      text=rawDraft.text;name=rawDraft.name;
      status('已恢复本地草稿');
    } else status('开始编辑后自动保存草稿');
  } catch {
    showRecovery();
    status('自动保存已暂停，请先导出文档');
  }
  view=new EditorView({parent:$('#editor'),state:EditorState.create({doc:text,extensions:[
    lineNumbers(),history(),drawSelection(),highlightActiveLine(),markdown(),syntaxHighlighting(defaultHighlightStyle),EditorView.lineWrapping,
    EditorView.contentAttributes.of({'aria-label':'Markdown 编辑区',spellcheck:'false'}),
    EditorState.transactionFilter.of(transaction=>transaction.newDoc.length>MAX_LENGTH ? [] : transaction),
    keymap.of([{key:'Mod-b',run:()=>format('bold')},{key:'Mod-i',run:()=>format('italic')},{key:'Mod-k',run:()=>format('link')},{key:'Mod-s',run:exportMD},...defaultKeymap,...historyKeymap,indentWithTab]),
    EditorView.updateListener.of(update=>{if(update.docChanged) changed();})
  ]})});
  render();setMode('split');
}
for (const button of document.querySelectorAll('[data-format]')) button.addEventListener('click',()=>format(button.dataset.format));
for (const button of document.querySelectorAll('button[data-mode]')) button.addEventListener('click',()=>setMode(button.dataset.mode));
media.addEventListener('change',()=>setMode($('#workspace').dataset.mode));
$('#allow-images').addEventListener('change',render);
$('#import').onclick=()=>$('#file-input').click();
$('#file-input').onchange=async event=>{
  const file=event.target.files[0];event.target.value='';
  if (!file) return;
  if (!/\.(md|markdown|txt)$/i.test(file.name) || file.size>MAX_LENGTH) {status('请选择不超过 2 MB 的 .md / .txt 文件');return;}
  const token=++importedToken;
  try {
    const bytes=await file.arrayBuffer();
    const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
    if (text.includes('\0')) throw new Error('binary file');
    if (token!==importedToken) return;
    name=file.name.replace(/\.(md|markdown|txt)$/i,'').slice(0,200);
    view.dispatch({changes:{from:0,to:view.state.doc.length,insert:text}});
    render();
    status(blocked?'已导入，自动保存仍暂停':'已导入，正在保存…');
  } catch {status('无法导入，请使用 UTF-8 编码的 Markdown 或纯文本文件');}
};
$('#export-md').onclick=exportMD;
$('#export-html').onclick=()=>download(exportHTML(view.state.doc.toString()),'text/html;charset=utf-8','.html');
$('#print').onclick=()=>{render();window.print();};
$('#raw-draft').onclick=()=>download(JSON.stringify(rawDraft,null,2),'application/json;charset=utf-8','.json','Markdown-原始草稿');
$('#new-draft').onclick=async()=>{
  try {
    await saveDraft(db,snapshot(),rawDraft);
    blocked=false;dirty=false;$('#recovery').hidden=true;
    status('已另存新草稿，原始记录已保留为恢复副本');
  } catch {status('无法另存，请导出 MD 保留文档');}
};
document.addEventListener('visibilitychange',()=>{if(document.hidden) persist();});
window.addEventListener('pagehide',persist);
window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
start();
