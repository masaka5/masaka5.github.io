export const MAX_LENGTH = 2 * 1024 * 1024;
export function validDraft(record) {
  return record && record.version === 1 && typeof record.text === 'string' && record.text.length <= MAX_LENGTH && typeof record.name === 'string' && record.name.length <= 200;
}
export async function openDrafts() {
  return new Promise((resolve,reject) => {
    const request = indexedDB.open('toolbox-markdown',1);
    request.onupgradeneeded = () => request.result.createObjectStore('drafts');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error('草稿数据库暂时被占用'));
  });
}
export async function readDraft(db) {
  return new Promise((resolve,reject) => {
    const request = db.transaction('drafts').objectStore('drafts').get('current');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
export async function saveDraft(db,record,backup) {
  return new Promise((resolve,reject) => {
    const transaction = db.transaction('drafts','readwrite');
    const store = transaction.objectStore('drafts');
    if (backup !== undefined) store.put(backup,`recovery-${Date.now()}`);
    store.put(record,'current');
    transaction.oncomplete = resolve;
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error);
  });
}
