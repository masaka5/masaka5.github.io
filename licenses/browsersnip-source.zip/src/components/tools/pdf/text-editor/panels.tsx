import { Button } from 'antd';
/**
 * Presentational controls for the in-place text editor.
 *
 * Every control here is dumb: it takes values and callbacks, holds no state, and
 * knows nothing about pdf.js or `pdf-lib`. The decisions live in `model.ts`, the
 * bytes in `draw.ts`, and the wiring in `TextEditor.tsx`. Styling reuses the
 * app's existing vocabulary (`doodle-*`, `cream`, `ink`, category accents).
 */
import {
  MIN_BLOCK_SIZE,
  SWATCH_COLORS,
  blockStillHasSource,
  ZOOM_PRESETS,
  rulerTicks,
  type AlignMode,
  type BulletMarker,
  type DistributeAxis,
  type EditObject,
  type EditScope,
  type EditorStyle,
  type FitMode,
  type ListKind,
  type NumberMarker,
  type TextDirection,
} from './model';
import type { TopLeftBox } from '@/lib/pdf/core/tables';
import type { FontFamilyOption } from './faces';
import { TextStylingControls } from '../shared/TextStylingControls';
import { MODE_AFTER_CREATE, keyForMode } from './keys';

// ── primitives ──────────────────────────────────────────────────────────────

interface ButtonProps {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  title?: string;
  kind?: 'primary' | 'secondary' | 'danger' | 'ghost';
  active?: boolean;
  className?: string;
}

export function ToolButton({ label, onClick, disabled, title, kind = 'secondary', active, className = '' }: ButtonProps) {
  const base =
    kind === 'primary'
      ? 'doodle-btn !w-auto !px-3 !py-1.5 !text-[11px]'
      : kind === 'danger'
        ? 'doodle-btn-danger !px-2.5 !py-1 !text-[11px]'
        : active
          ? 'doodle-chip doodle-chip-active !px-2.5 !py-1 !text-[11px] !flex-none'
          : 'doodle-chip doodle-chip-inactive !px-2.5 !py-1 !text-[11px] !flex-none';
  return (
    <Button
      htmlType="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      aria-pressed={active}
      className={`${base} ${className}`}
    >
      {label}
    </Button>
  );
}

export function PanelHeading({ children }: { children: React.ReactNode }) {
  return (
    <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{children}</p>
  );
}

export function Labeled({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <label className="block space-y-1">
      <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{label}</span>
      {children}
      {hint && <span className="block text-[10px] leading-relaxed text-ink-muted">{hint}</span>}
    </label>
  );
}

export function NumberField({
  value,
  onChange,
  min,
  max,
  step = 1,
  suffix,
}: {
  value: number;
  onChange: (next: number) => void;
  min: number;
  max: number;
  step?: number;
  suffix?: string;
}) {
  return (
    <div className="flex items-center gap-1">
      <input
        type="number"
        value={Number.isFinite(value) ? Math.round(value * 100) / 100 : 0}
        min={min}
        max={max}
        step={step}
        onChange={(event) => onChange(event.target.valueAsNumber)}
        className="doodle-input !px-2 !py-1 !text-[11px]"
      />
      {suffix && <span className="font-mono text-[9px] text-ink-muted">{suffix}</span>}
    </div>
  );
}

export function SliderField({
  label,
  value,
  min,
  max,
  step = 1,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  suffix?: string;
  onChange: (next: number) => void;
}) {
  return (
    <div className="space-y-1">
      <span className="flex items-baseline justify-between gap-2 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">
        <span>{label}</span>
        <span className="font-display text-[11px] normal-case tracking-normal text-ink-soft tabular-nums">
          {Math.round(value * 100) / 100}
          {suffix ?? ''}
        </span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(event.target.valueAsNumber)}
        className="w-full accent-[#2563EB]"
      />
    </div>
  );
}

export function SelectField<T extends string>({
  label,
  value,
  options,
  onChange,
  hint,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (next: T) => void;
  hint?: string;
}) {
  return (
    <Labeled label={label} hint={hint}>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value as T)}
        className="doodle-input !px-2 !py-1 !text-[11px]"
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </Labeled>
  );
}

export function SegmentedField<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label?: string;
  value: T;
  options: { value: T; label: string; title?: string }[];
  onChange: (next: T) => void;
}) {
  return (
    <div className="space-y-1">
      {label && <PanelHeading>{label}</PanelHeading>}
      <div className="flex flex-wrap gap-1">
        {options.map((option) => (
          <ToolButton
            key={option.value}
            label={option.label}
            title={option.title ?? option.label}
            active={value === option.value}
            onClick={() => onChange(option.value)}
          />
        ))}
      </div>
    </div>
  );
}

export function ToggleField({
  label,
  checked,
  onChange,
  title,
}: {
  label: string;
  checked: boolean;
  onChange: (next: boolean) => void;
  title?: string;
}) {
  return (
    <label
      title={title}
      className="flex cursor-pointer items-center justify-between gap-2 py-0.5 text-[11px] text-ink-soft"
    >
      <span>{label}</span>
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="h-3 w-3 accent-[#2563EB]"
      />
    </label>
  );
}

/** Swatch row plus the browser's own picker, for any colour in the model. */
export function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (next: string) => void;
}) {
  const safe = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(value) ? value : '#000000';
  return (
    <div className="space-y-1">
      <div className="flex items-center gap-1">
        <PanelHeading>{label}</PanelHeading>
        <input
          type="color"
          value={safe}
          onChange={(event) => onChange(event.target.value)}
          className="ml-auto h-6 w-8 cursor-pointer rounded border border-cream-border bg-white"
          aria-label={`${label} picker`}
        />
      </div>
      <div className="flex flex-wrap gap-1">
        {SWATCH_COLORS.map((color) => (
          <Button
            key={color}
            htmlType="button"
            title={color}
            aria-label={`${label} ${color}`}
            onClick={() => onChange(color)}
            className={`h-4 w-4 rounded border ${value.toLowerCase() === color.toLowerCase() ? 'border-accent ring-1 ring-accent/40' : 'border-cream-border'}`}
            style={{ background: color }}
          />
        ))}
      </div>
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="doodle-input !px-2 !py-1 font-mono !text-[10px]"
        aria-label={`${label} hex value`}
      />
    </div>
  );
}

// ── toolbar ─────────────────────────────────────────────────────────────────

export interface ToolbarProps {
  hasDocument: boolean;
  dirty: number;
  page: number;
  numPages: number;
  zoom: number;
  showRulers: boolean;
  barsHidden: boolean;
  canUndo: boolean;
  canRedo: boolean;
  /** False until something has actually been edited — with the reason. */
  canExport: boolean;
  exportNote: string;
  undoNote: string;
  redoNote: string;
  onBack: () => void;
  onOpenAnother: () => void;
  onExport: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onPrevPage: () => void;
  onNextPage: () => void;
  onJumpPage: (page: number) => void;
  onZoom: (scale: number) => void;
  onFit: (mode: FitMode) => void;
  onToggleRulers: () => void;
  onToggleBars: () => void;
  onCopyPageText: () => void;
  onReloadPreview: () => void;
}

export function TopToolbar(props: ToolbarProps) {
  const percent = Math.round(props.zoom * 100);
  return (
    <div className="flex flex-wrap items-center gap-1.5 border-b border-cream-border bg-cream-light px-2 py-1.5" role="toolbar" aria-label={"文本编辑器"}>
      <ToolButton label={"← 返回上传"} onClick={props.onBack} title={"关闭此PDF并返回到文件放置处"} />
      <ToolButton label={"打开另一个PDF"} onClick={props.onOpenAnother} />
      <ToolButton
        label={"出口"}
        kind="primary"
        onClick={props.onExport}
        disabled={!props.canExport}
        title={props.exportNote}
      />
      <span className="mx-1 h-4 w-px bg-cream-border" />
      <ToolButton label={"撤消"} onClick={props.onUndo} disabled={!props.canUndo} title={props.undoNote} />
      <ToolButton label={"重做"} onClick={props.onRedo} disabled={!props.canRedo} title={props.redoNote} />
      <span className="mx-1 h-4 w-px bg-cream-border" />
      <ToolButton label="◂" onClick={props.onPrevPage} disabled={props.page <= 1} title={"上一页"} />
      <span className="min-w-[4.5rem] text-center font-mono text-[10px] tabular-nums text-ink-muted">
        {"页"}<input
          type="number"
          value={props.page}
          min={1}
          max={Math.max(1, props.numPages)}
          onChange={(event) => props.onJumpPage(event.target.valueAsNumber)}
          className="mx-1 w-12 rounded border border-cream-border bg-white px-1 py-0.5 text-center text-[11px] text-ink"
          aria-label={"跳转至页面"}
        />
        {"的"}{props.numPages || '—'}
      </span>
      <ToolButton label="▸" onClick={props.onNextPage} disabled={props.page >= props.numPages} title={"下一页"} />
      <span className="mx-1 h-4 w-px bg-cream-border" />
      <select
        value={String(percent)}
        onChange={(event) => props.onZoom(Number(event.target.value) / 100)}
        className="doodle-input !w-auto !px-2 !py-1 !text-[11px]"
        aria-label={"缩放"}
      >
        {ZOOM_PRESETS.map((preset) => (
          <option key={preset} value={String(Math.round(preset * 100))}>
            {Math.round(preset * 100)}%
          </option>
        ))}
      </select>
      <ToolButton label={"适合页面"} onClick={() => props.onFit('page')} />
      <ToolButton label={"适合宽度"} onClick={() => props.onFit('width')} />
      <span className="mx-1 h-4 w-px bg-cream-border" />
      <ToolButton label={props.showRulers ? "隐藏标尺" : "统治者"} active={props.showRulers} onClick={props.onToggleRulers} />
      <ToolButton label={props.barsHidden ? "显示条" : "隐藏栏"} onClick={props.onToggleBars} />
      <ToolButton label={"复制页面文本"} onClick={props.onCopyPageText} disabled={!props.hasDocument} title={"按阅读顺序复制此页的文本"} />
      <ToolButton label={"重新加载预览"} onClick={props.onReloadPreview} disabled={!props.hasDocument} title={"从编辑的字节重新渲染页面"} />
      <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted" data-export-state={props.canExport ? 'ready' : 'waiting'}>
        {props.canExport ? `${props.dirty} block(s) waiting for export` : props.exportNote}
      </span>
    </div>
  );
}

// ── mode + scope ────────────────────────────────────────────────────────────

export interface ModePanelProps {
  mode: 'edit' | 'add-text' | 'add-image';
  scope: EditScope;
  /** Pinned placement tools stay armed after each drop (brief's pin ruling). */
  pinned: boolean;
  onMode: (mode: 'edit' | 'add-text' | 'add-image') => void;
  onScope: (scope: EditScope) => void;
  onPin: (pinned: boolean) => void;
  onPickImage: () => void;
}

export function ModePanel({ mode, scope, pinned, onMode, onScope, onPin, onPickImage }: ModePanelProps) {
  // The tooltip carries the bound key, so the panel, the keyboard handler and the
  // shortcut list all read the same table (`keyForMode` is the reverse of it).
  const keyOf = (value: ModePanelProps['mode']): string => {
    const key = keyForMode(value);
    return key ? ` (${key})` : '';
  };
  // One source for "does this mode keep placing?": the declared table in `keys`,
  // not a comparison against the mode name in three components.
  const placement = MODE_AFTER_CREATE[mode] === 'default';
  const pinNote = !placement
    ? 'Edit is the resting tool. Pin before placing a run of boxes or images.'
    : pinned
      ? 'Pinned: keeps placing until you press Esc.'
      : 'One-shot: steps back to Edit as soon as this is placed.';
  return (
    <div className="space-y-2">
      <SegmentedField
        label={"工具"}
        value={mode}
        onChange={onMode}
        options={[
          { value: 'edit', label: "编辑", title: `Click a paragraph and retype it${keyOf('edit')}` },
          {
            value: 'add-text',
            label: "添加文本框",
            title: `Drag on the page to place new text${keyOf('add-text')}`,
          },
          {
            value: 'add-image',
            label: "添加图像",
            title: `Choose an image, then click where it goes${keyOf('add-image')}`,
          },
        ]}
      />
      <div className="flex items-start gap-2" data-tool-pin={pinned ? 'pinned' : 'one-shot'}>
        <ToolButton
          label={pinned ? "🔒 已固定" : "🔓 一击"}
          active={pinned}
          onClick={() => onPin(!pinned)}
          title={
            pinned
              ? "放置工具在每次跌落后保持待命状态。 Esc 将其取消固定。"
              : "该工具在每次放置之后返回到编辑。将其固定以放置多个。"
          }
        />
        <p className="min-w-0 flex-1 text-[10px] leading-relaxed text-ink-muted">{pinNote}</p>
      </div>
      {mode === 'edit' && (
        <SelectField
          label={"编辑范围"}
          value={scope}
          onChange={onScope}
          options={[
            { value: 'text', label: "文本" },
            { value: 'image', label: "图像" },
            { value: 'shape', label: "形状" },
            { value: 'all', label: "全部" },
          ]}
          hint={"点击可以抓取哪些对象。您尚未编辑的单词始终是文本。"}
        />
      )}
      {mode === 'add-image' && <ToolButton label={"选择图像..."} onClick={onPickImage} className="w-full" />}
    </div>
  );
}

// ── format inspector ────────────────────────────────────────────────────────

export interface FormatPanelProps {
  style: EditorStyle;
  hasSelection: boolean;
  families: FontFamilyOption[];
  /**
   * The words the selection holds. The posture buttons are judged against them:
   * a Latin-only family loses italic exactly when the run passes what it can
   * encode, because that run is written in the bundled face instead.
   */
  text?: string;
  localFontsSupported: boolean;
  localFontsLoaded: boolean;
  onScanLocalFonts: () => void;
  onStyle: (patch: Partial<EditorStyle>) => void;
  onInline: (patch: Partial<EditorStyle>) => void;
  onList: (kind: ListKind) => void;
  notes: string[];
}

export function FormatPanel({
  style,
  hasSelection,
  families,
  text = '',
  localFontsSupported,
  localFontsLoaded,
  onScanLocalFonts,
  onStyle,
  onInline,
  onList,
  notes,
}: FormatPanelProps) {
  const disabled = !hasSelection;
  return (
    <div className={`space-y-3 ${disabled ? 'opacity-50' : ''}`} data-format-panel={disabled ? 'empty' : 'ready'}>
      <PanelHeading>{"格式"}</PanelHeading>
      {disabled && (
        <p className="text-[10px] leading-relaxed text-ink-muted">
          {"没有选择任何内容——这些控件需要文本块。单击页面上的段落，或在已选择的段落上按 Enter。"}</p>
      )}
      {/*
         Family, weight, slant, size, colour, alignment and line height are the one
         control set every surface mounts, so this editor cannot offer a posture the
         file would drop while the annotation editor refuses it. The patch splits on
         the way out: the face fields belong to the runs, alignment and leading to the
         block, which is how the editor's own undo history is shaped.
      */}
      <TextStylingControls
        surface="text-editor"
        style={style}
        text={text}
        families={families}
        disabled={disabled}
        onChange={(patch) => {
          const { align, lineSpacing, ...inline } = patch;
          if (Object.keys(inline).length > 0) onInline(inline);
          if (align !== undefined || lineSpacing !== undefined) onStyle({ align, lineSpacing });
        }}
        onScanLocalFonts={onScanLocalFonts}
        localFontsSupported={localFontsSupported}
        localFontsLoaded={localFontsLoaded}
      />
      <Labeled label={"方向"}>
        <SelectField
          label=""
          value={style.direction}
          onChange={(direction: TextDirection) => onStyle({ direction })}
          options={[
            { value: 'auto', label: "自动" },
            { value: 'ltr', label: 'LTR' },
            { value: 'rtl', label: 'RTL' },
          ]}
        />
      </Labeled>
      <div className="space-y-1">
        <PanelHeading>{"风格"}</PanelHeading>
        <div className="flex flex-wrap gap-1">
          {(
            [
              ['underline', 'U̲', 'Underline'],
              ['strike', 'S̶', 'Strikethrough'],
              ['superscript', 'x²', 'Superscript'],
              ['subscript', 'x₂', 'Subscript'],
            ] as const
          ).map(([key, label, title]) => (
            <ToolButton
              key={key}
              label={label}
              title={title}
              active={Boolean(style[key])}
              disabled={disabled}
              onClick={() => onInline({ [key]: !style[key] } as Partial<EditorStyle>)}
            />
          ))}
        </div>
      </div>
      <div className="space-y-1.5">
        <PanelHeading>{"列表"}</PanelHeading>
        <div className="flex flex-wrap gap-1">
          <ToolButton label={"·项目符号"} active={style.list === 'bullet'} disabled={disabled} onClick={() => onList('bullet')} />
          <ToolButton label={"1.数量"} active={style.list === 'number'} disabled={disabled} onClick={() => onList('number')} />
          <ToolButton label={"无"} active={style.list === 'none'} disabled={disabled} onClick={() => onList('none')} />
        </div>
        {style.list === 'bullet' && (
          <SelectField
            label={"标记"}
            value={style.bulletMarker}
            onChange={(bulletMarker: BulletMarker) => onStyle({ bulletMarker })}
            options={[
              { value: 'dot', label: "·点" },
              { value: 'circle', label: "◦圆" },
              { value: 'square', label: "▪ 方形" },
              { value: 'dash', label: "– 破折号" },
              { value: 'arrow', label: "▸ 箭头" },
            ]}
          />
        )}
        {style.list === 'number' && (
          <SelectField
            label={"标记"}
            value={style.numberMarker}
            onChange={(numberMarker: NumberMarker) => onStyle({ numberMarker })}
            options={[
              { value: 'decimal', label: '1, 2, 3' },
              { value: 'lower-alpha', label: 'a, b, c' },
              { value: 'upper-alpha', label: 'A, B, C' },
              { value: 'lower-roman', label: "一、二、三" },
              { value: 'upper-roman', label: "一、二、三" },
            ]}
          />
        )}
      </div>
      {/* Line spacing moved into `TextStylingControls`, where the surface's support
          table decides whether the mark has lines to space at all. */}
      <div className="grid grid-cols-2 gap-2">
        <Labeled label={"之前的空格"}>
          <NumberField value={style.spaceBefore} min={0} max={200} step={0.5} suffix="pt" onChange={(spaceBefore) => onStyle({ spaceBefore })} />
        </Labeled>
        <Labeled label={"之后的空间"}>
          <NumberField value={style.spaceAfter} min={0} max={200} step={0.5} suffix="pt" onChange={(spaceAfter) => onStyle({ spaceAfter })} />
        </Labeled>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Labeled label={"缩进"}>
          <NumberField value={style.indent} min={-100} max={400} step={0.5} suffix="pt" onChange={(indent) => onStyle({ indent })} />
        </Labeled>
        <Labeled label={"第一行"}>
          <NumberField value={style.firstLineIndent} min={-100} max={400} step={0.5} suffix="pt" onChange={(firstLineIndent) => onStyle({ firstLineIndent })} />
        </Labeled>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <SliderField label={"字符间距"} value={style.charSpacing} min={-2} max={20} step={0.05} suffix="pt" onChange={(charSpacing) => onStyle({ charSpacing })} />
        <SliderField label={"字间距"} value={style.wordSpacing} min={-2} max={40} step={0.05} suffix="pt" onChange={(wordSpacing) => onStyle({ wordSpacing })} />
      </div>
      <SliderField label={"水平刻度"} value={style.horizontalScale} min={20} max={300} step={1} suffix="%" onChange={(horizontalScale) => onStyle({ horizontalScale })} />
      <div className="space-y-1.5 rounded-doodle-md border border-cream-border bg-cream-soft p-2">
        <PanelHeading>{"文本大纲"}</PanelHeading>
        <div className="grid grid-cols-2 gap-2">
          <ColorField label={"颜色"} value={style.outlineColor} onChange={(outlineColor) => onStyle({ outlineColor })} />
          <Labeled label={"宽度"}>
            <NumberField value={style.outlineWidth} min={0} max={20} step={0.1} suffix="pt" onChange={(outlineWidth) => onStyle({ outlineWidth })} />
          </Labeled>
        </div>
      </div>
      <SliderField label={"不透明度"} value={style.opacity} min={0} max={1} step={0.05} onChange={(opacity) => onStyle({ opacity })} />
      {notes.map((note) => (
        <p key={note} className="rounded-doodle-md border border-warn/25 bg-warn/5 p-2 text-[10px] leading-relaxed text-warn">
          {note}
        </p>
      ))}
    </div>
  );
}

// ── object inspector ────────────────────────────────────────────────────────

export interface ObjectPanelProps {
  selection: EditObject[];
  onSetBox: (box: TopLeftBox) => void;
  onTransform: (patch: { rotation?: number; flipH?: boolean; flipV?: boolean }) => void;
  onRotate: (delta: number) => void;
  onZOrder: (order: 'front' | 'back' | 'forward' | 'backward') => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onAlign: (mode: AlignMode) => void;
  onDistribute: (axis: DistributeAxis) => void;
  onAlt: (value: string) => void;
  onReplaceImage: () => void;
  onMove: (dx: number, dy: number) => void;
}

export function ObjectPanel(props: ObjectPanelProps) {
  const selected = props.selection;
  const first = selected[0];
  if (!first) {
    return (
      <div className="space-y-2">
        <PanelHeading>{"对象"}</PanelHeading>
        <p className="text-[10px] leading-relaxed text-ink-muted">
          {"点击段落以编辑其文字，或点击放置的对象以移动、旋转、重新堆叠或描述它。按住 Shift 键并单击可选择多个并将它们对齐。"}</p>
      </div>
    );
  }
  const image = first.kind === 'image' ? first : null;
  return (
    <div className="space-y-2.5">
      <PanelHeading>{"对象·"}{first.kind === 'text' ? "文本块" : "图像"} {"页"}{first.page}</PanelHeading>
      <div className="flex flex-wrap gap-1">
        <ToolButton label="⟲ −90°" onClick={() => props.onRotate(-90)} title={"逆时针旋转"} />
        <ToolButton label="⟳ +90°" onClick={() => props.onRotate(90)} title={"顺时针旋转"} />
        <ToolButton label={"翻转H"} active={first.flipH} onClick={() => props.onTransform({ flipH: !first.flipH })} />
        <ToolButton label={"翻转V"} active={first.flipV} onClick={() => props.onTransform({ flipV: !first.flipV })} />
      </div>
      <div className="grid grid-cols-2 gap-1">
        {(['left', 'center', 'right', 'top', 'middle', 'bottom'] as AlignMode[]).map((mode) => (
          <ToolButton key={mode} label={mode} disabled={selected.length < 2} onClick={() => props.onAlign(mode)} title={`Align ${mode}`} />
        ))}
      </div>
      <div className="flex flex-wrap gap-1">
        <ToolButton label={"分配 ↔"} disabled={selected.length < 3} onClick={() => props.onDistribute('horizontal')} />
        <ToolButton label={"分配↕"} disabled={selected.length < 3} onClick={() => props.onDistribute('vertical')} />
      </div>
      <div className="flex flex-wrap gap-1">
        <ToolButton label={"带到前面"} onClick={() => props.onZOrder('front')} />
        <ToolButton label={"发送到后面"} onClick={() => props.onZOrder('back')} />
        <ToolButton label={"转发"} onClick={() => props.onZOrder('forward')} />
        <ToolButton label={"向后"} onClick={() => props.onZOrder('backward')} />
      </div>
      <div className="flex flex-wrap gap-1">
        <ToolButton label={"重复"} onClick={props.onDuplicate} />
        <ToolButton label={"删除"} kind="danger" onClick={props.onDelete} />
        {image && <ToolButton label={"替换图像"} onClick={props.onReplaceImage} title={"交换像素，保持位置"} />}
      </div>
      <div className="flex flex-wrap gap-1">
        <ToolButton label="←" onClick={() => props.onMove(-1, 0)} title={"向左轻推"} />
        <ToolButton label="→" onClick={() => props.onMove(1, 0)} title={"向右微移"} />
        <ToolButton label="↑" onClick={() => props.onMove(0, -1)} title={"轻推"} />
        <ToolButton label="↓" onClick={() => props.onMove(0, 1)} title={"向下轻推"} />
      </div>
      <Labeled label={"替代文本"} hint={"写为标签，以便屏幕阅读器和PDF/UA工具可以描述该对象。"}>
        <input
          value={first.alt}
          onChange={(event) => props.onAlt(event.target.value)}
          placeholder={"描述该对象"}
          className="doodle-input !px-2 !py-1 !text-[11px]"
        />
      </Labeled>
      {/* Keyboard route to the same geometry the handles drag (WCAG 2.5.7). */}
      <div className="grid grid-cols-2 gap-2" data-object-box>
        <Labeled label="X">
          <NumberField value={first.box.x} min={-2000} max={4000} step={0.5} suffix="pt" onChange={(x) => props.onSetBox({ ...first.box, x })} />
        </Labeled>
        <Labeled label="Y">
          <NumberField value={first.box.y} min={-2000} max={4000} step={0.5} suffix="pt" onChange={(y) => props.onSetBox({ ...first.box, y })} />
        </Labeled>
        <Labeled label={"宽度"}>
          <NumberField
            value={first.box.width}
            min={MIN_BLOCK_SIZE}
            max={4000}
            step={0.5}
            suffix="pt"
            onChange={(width) => props.onSetBox({ ...first.box, width: Math.max(MIN_BLOCK_SIZE, width || 0) })}
          />
        </Labeled>
        <Labeled label={"高度"}>
          <NumberField
            value={first.box.height}
            min={MIN_BLOCK_SIZE}
            max={4000}
            step={0.5}
            suffix="pt"
            onChange={(height) => props.onSetBox({ ...first.box, height: Math.max(MIN_BLOCK_SIZE, height || 0) })}
          />
        </Labeled>
      </div>
    </div>
  );
}

// ── find & replace ──────────────────────────────────────────────────────────

export interface FindPanelProps {
  open: boolean;
  query: string;
  replacement: string;
  caseSensitive: boolean;
  wholeWord: boolean;
  ignoreAccents: boolean;
  status: string;
  /** False when there is nothing to act on — with the reason next to it. */
  canReplace: boolean;
  replaceNote: string;
  searching: boolean;
  onQuery: (value: string) => void;
  onReplacement: (value: string) => void;
  onToggle: (key: 'caseSensitive' | 'wholeWord' | 'ignoreAccents', value: boolean) => void;
  onNext: () => void;
  onPrev: () => void;
  onReplace: () => void;
  onReplaceAll: () => void;
  onClose: () => void;
}

export function FindReplacePanel(props: FindPanelProps) {
  if (!props.open) return null;
  return (
    <div className="space-y-2 rounded-doodle-md border border-cream-border bg-white p-3 shadow-doodle-card">
      <div className="flex items-center gap-2">
        <PanelHeading>{"查找和替换——每页"}</PanelHeading>
        <Button htmlType="button" onClick={props.onClose} className="ml-auto text-[11px] text-ink-muted hover:text-ink" aria-label={"关闭查找和替换"}>
          ✕
        </Button>
      </div>
      <input
        value={props.query}
        onChange={(event) => props.onQuery(event.target.value)}
        onKeyDown={(event) => {
          if (event.key === 'Enter') props.onNext();
        }}
        placeholder={"找到……"}
        className="doodle-input !px-2 !py-1 !text-[11px]"
        aria-label={"要查找的文本"}
      />
      <input
        value={props.replacement}
        onChange={(event) => props.onReplacement(event.target.value)}
        placeholder={"替换为……"}
        className="doodle-input !px-2 !py-1 !text-[11px]"
        aria-label={"替换文本"}
      />
      <div className="flex flex-wrap gap-2">
        {(
          [
            ['caseSensitive', 'Match case'],
            ['wholeWord', 'Whole word'],
            ['ignoreAccents', 'Ignore accents'],
          ] as const
        ).map(([key, label]) => (
          <label key={key} className="flex cursor-pointer items-center gap-1 text-[10px] text-ink-soft">
            <input
              type="checkbox"
              checked={props[key]}
              onChange={(event) => props.onToggle(key, event.target.checked)}
              className="h-3 w-3 accent-[#2563EB]"
            />
            {label}
          </label>
        ))}
      </div>
      <div className="flex flex-wrap gap-1">
        <ToolButton label={"上一页"} onClick={props.onPrev} title={"跳至上一场比赛"} />
        <ToolButton label={"下一个"} onClick={props.onNext} title={"跳转到下一场比赛"} />
        <ToolButton label={"替换"} onClick={props.onReplace} disabled={!props.canReplace} title={props.replaceNote} />
        <ToolButton label={"全部替换"} kind="primary" onClick={props.onReplaceAll} disabled={!props.canReplace} title={props.replaceNote} />
      </div>
      <p className="font-mono text-[10px] text-ink-muted" role="status" aria-live="polite" data-find-status>
        {props.searching ? "搜索每一页……" : props.status}
      </p>
      {!props.canReplace && <p className="text-[10px] leading-relaxed text-ink-muted">{props.replaceNote}</p>}
    </div>
  );
}

// ── object list ─────────────────────────────────────────────────────────────

const STATE_LABEL: Record<EditObject['state'], string> = {
  draft: 'edited',
  queued: 'queued',
  written: 'written',
  'needs-engine': 'needs PyMuPDF',
  failed: 'skipped',
};

export function ObjectList({
  objects,
  selectedIds,
  onSelect,
  onEdit,
}: {
  objects: EditObject[];
  selectedIds: string[];
  onSelect: (id: string) => void;
  /** Enter / double-click: go one level deeper, i.e. start retyping. */
  onEdit: (id: string) => void;
}) {
  if (objects.length === 0) {
    return (
      <p className="text-[10px] leading-relaxed text-ink-muted">
        {"尚未编辑。单击页面中的某个段落即可重写它。"}</p>
    );
  }
  return (
    <ul className="max-h-40 space-y-1 overflow-y-auto pr-1" data-edit-list>
      {objects.map((object) => (
        <li key={object.id}>
          <Button
            htmlType="button"
            onClick={() => onSelect(object.id)}
            onDoubleClick={() => onEdit(object.id)}
            onKeyDown={(event) => {
              if (event.key !== 'Enter') return;
              event.preventDefault();
              onEdit(object.id);
            }}
            aria-current={selectedIds.includes(object.id) ? 'true' : undefined}
            aria-label={`${object.kind === 'text' ? 'Text block' : 'Image'}, page ${object.page}, ${STATE_LABEL[object.state]}. Press Enter to edit.`}
            title={"点击选择，双击或回车编辑"}
            className={`flex w-full items-center gap-2 rounded border px-2 py-1 text-left text-[10px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent ${
              selectedIds.includes(object.id)
                ? 'border-accent bg-accent/10 text-ink'
                : 'border-cream-border bg-white text-ink-soft hover:border-ink-muted'
            }`}
          >
            <span className="font-mono uppercase tracking-[0.08em] text-ink-muted">
              {object.kind === 'text' ? 'T' : 'I'}{object.page}
            </span>
            <span className="truncate">{object.alt || objectLabel(object)}</span>
            <span
              className={`ml-auto shrink-0 rounded px-1 font-mono text-[9px] uppercase ${
                blockStillHasSource(object.state)
                  ? 'bg-warn/15 text-warn'
                  : object.state === 'written'
                    ? 'bg-success/15 text-success'
                    : 'bg-cream-soft text-ink-muted'
              }`}
            >
              {STATE_LABEL[object.state]}
            </span>
          </Button>
        </li>
      ))}
    </ul>
  );
}

function objectLabel(object: EditObject): string {
  if (object.kind === 'text') {
    const text = object.paragraphs.map((p) => p.runs.map((r) => r.text).join('')).join(' ').trim();
    return text.length > 0 ? text.slice(0, 40) : '(empty block)';
  }
  return 'Placed image';
}

// ── export warnings + live size ─────────────────────────────────────────────

/**
 * What an export could not do, kept on screen until the next one.
 *
 * A toast disappears in eight seconds; a degraded block has to stay readable
 * while the user decides whether to accept the file. This is this surface's
 * equivalent of a registry tool's `result.warnings`.
 */
export function WarningList({
  headline,
  lines,
  onDismiss,
}: {
  headline: string;
  lines: string[];
  onDismiss: () => void;
}) {
  if (lines.length === 0) return null;
  return (
    <div
      data-export-warnings
      role="status"
      className="space-y-1.5 rounded-doodle-md border border-warn/30 bg-warn/10 p-2"
    >
      <div className="flex items-start gap-2">
        <PanelHeading>{"导出结果"}</PanelHeading>
        <Button
          htmlType="button"
          onClick={onDismiss}
          className="ml-auto text-[10px] text-ink-muted hover:text-ink"
          aria-label={"驳回导出结果"}
        >
          ✕
        </Button>
      </div>
      <p className="text-[10px] leading-relaxed text-ink">{headline}</p>
      <ul className="space-y-1">
        {lines.map((line, index) => (
          <li key={`${index}:${line.slice(0, 24)}`} className="text-[10px] leading-relaxed text-warn">
            {line}
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Dimensions that follow the box while it is drawn or resized. */
export function SizeBadge({ box, scale }: { box: TopLeftBox; scale: number }) {
  return (
    <div
      data-size-badge
      className="pointer-events-none absolute rounded bg-accent px-1.5 py-0.5 font-mono text-[9px] leading-none text-white"
      style={{ left: box.x * scale, top: (box.y + box.height) * scale + 2 }}
    >
      {Math.round(box.width)} × {Math.round(box.height)} {"点"}</div>
  );
}

// ── toasts ──────────────────────────────────────────────────────────────────

export interface Toast {
  id: number;
  kind: 'info' | 'success' | 'warn' | 'error';
  text: string;
}

const TOAST_STYLE: Record<Toast['kind'], string> = {
  info: 'border-cream-border bg-white text-ink',
  success: 'border-success/30 bg-success/10 text-success',
  warn: 'border-warn/30 bg-warn/10 text-warn',
  error: 'border-danger/30 bg-danger/10 text-danger',
};

export function ToastStack({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  if (toasts.length === 0) return null;
  return (
    <div className="pointer-events-none absolute bottom-4 left-1/2 z-50 flex w-[min(28rem,90%)] -translate-x-1/2 flex-col gap-2">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          role="status"
          className={`pointer-events-auto flex items-start gap-2 rounded-doodle-md border px-3 py-2 text-[11px] leading-relaxed shadow-doodle-hover ${TOAST_STYLE[toast.kind]}`}
        >
          <span className="flex-1">{toast.text}</span>
          <Button htmlType="button" onClick={() => onDismiss(toast.id)} className="text-[10px] opacity-60 hover:opacity-100" aria-label={"驳回"}>
            ✕
          </Button>
        </div>
      ))}
    </div>
  );
}

// ── rulers ──────────────────────────────────────────────────────────────────

export function Ruler({
  orientation,
  lengthPoints,
  scale,
}: {
  orientation: 'horizontal' | 'vertical';
  lengthPoints: number;
  scale: number;
}) {
  const px = lengthPoints * scale;
  const ticks = rulerTicks(lengthPoints, scale, 40);
  const long = orientation === 'horizontal';
  return (
    <div
      className={long ? 'relative h-4 bg-cream-soft' : 'relative w-4 bg-cream-soft'}
      style={long ? { width: px } : { height: px }}
      aria-hidden
    >
      {ticks.map((tick) => (
        <span
          key={tick.label}
          className="absolute font-mono text-[7px] leading-none text-ink-muted"
          style={
            long
              ? { left: tick.position, top: 0, height: 8, borderLeft: '1px solid #BFBFB6', paddingLeft: 2 }
              : { top: tick.position, left: 0, width: 8, borderTop: '1px solid #BFBFB6', paddingTop: 1 }
          }
        >
          {Number(tick.label) % 100 === 0 ? tick.label : ''}
        </span>
      ))}
    </div>
  );
}
