import {afterEach, expect, it, vi} from 'vitest';
import {cleanup, fireEvent, render, screen} from '@testing-library/react';
import {FieldControl} from '@/components/tools/pdf/shared/FieldControls';
import {FileIntake, intakeCopy} from '@/components/tools/pdf/shared/FileIntake';
afterEach(cleanup);
it('uses Ant intake action without changing picker behavior',()=>{
 const open=vi.fn();render(<FileIntake title="合并 PDF" promise="" copy={intakeCopy()} controls={{open,dragging:false,inputProps:{} as any}}/>);
 const button=screen.getByRole('button',{name:'选择PDF文件'});expect(button).toHaveClass('ant-btn');fireEvent.click(button);expect(open).toHaveBeenCalledOnce();
});
it('retains numeric raw value for downstream clamping',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'dpi',label:'分辨率',type:'number',min:72,max:300,default:150}} values={{dpi:150}} onChange={change}/>);
 fireEvent.change(screen.getByLabelText('分辨率'),{target:{value:'400'}});expect(change).toHaveBeenCalledWith('dpi',400);
});
it('Ant select preserves numeric options rather than stringifying tool values',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'rotation',label:'旋转',type:'select',options:[{value:90,label:'90°'},{value:180,label:'180°'}]}} values={{rotation:90}} onChange={change}/>);
 const box=screen.getByRole('combobox');expect(box.closest('.ant-select')).toBeTruthy();fireEvent.mouseDown(box);fireEvent.click(screen.getAllByText('180°').at(-1)!);expect(change).toHaveBeenCalledWith('rotation',180);
});
it('attachment upload reads real bytes and keeps multiple selection order',async()=>{
 const change=vi.fn();const {container}=render(<FieldControl field={{key:'attachments',label:'附件',type:'file',multiple:true}} values={{attachments:[]}} onChange={change}/>);
 expect(container.querySelector('.ant-upload')).toBeTruthy();
 const a=new File(['alpha'],'a.txt',{type:'text/plain'});Object.defineProperty(a,'arrayBuffer',{value:async()=>new TextEncoder().encode('alpha').buffer});
 const b=new File(['beta'],'b.txt',{type:'text/plain'});Object.defineProperty(b,'arrayBuffer',{value:async()=>new TextEncoder().encode('beta').buffer});
 fireEvent.change(container.querySelector('input[type=file]')!,{target:{files:[a,b]}});
 await vi.waitFor(()=>expect(change).toHaveBeenCalledOnce());
 const outputs=change.mock.calls[0][1];expect(outputs.map((x:any)=>x.name)).toEqual(['a.txt','b.txt']);expect(new TextDecoder().decode(outputs[1].bytes)).toBe('beta');
});
it('slider keyboard forwards bounded numeric values',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'quality',label:'质量',type:'slider',min:0,max:100,step:5}} values={{quality:50}} onChange={change}/>);
 fireEvent.keyDown(screen.getByRole('slider'),{key:'ArrowRight',code:'ArrowRight',keyCode:39});expect(change).toHaveBeenCalledWith('quality',55);
});
