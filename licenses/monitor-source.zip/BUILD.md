# 多屏显示器检测

纯静态网页，直接以 HTTP/HTTPS 提供 toolbox-site；没有 npm 或本地服务依赖。浏览器测试使用 Python3 + Playwright，运行 _scratch/ops-tests/monitor-multi.py 和 monitor-platform.py。TOOLBOX_TEST_BASE 指定站点。

多屏检测面板：识别显示器需支持 Window Management API 的 Chrome/Edge、HTTPS 和用户授权；全部检测需允许站点弹窗。开窗时尝试按屏幕可用区域定位并进入对应屏幕全屏；浏览器拒绝无用户手势全屏时，请在每个检测窗口点击全屏。不支持自动识别时新增窗口，拖到目标屏幕后全屏，图案/暂停/速度/结束仍会同步。最多16窗口。

自动测试验证真实多网页BroadcastChannel同步与模拟ScreenDetailed接口；不能代替物理多屏定位的实机验证。动态画面使用共同时间基准，不保证不同屏幕刷新率下逐帧一致。刷新/关闭控制页结束所属窗口，不保存检测会话。
