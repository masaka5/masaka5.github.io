from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site';folder=SITE/'tools/monitor'
files=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(folder.iterdir())if p.is_file()and p.name!='manifest.json']
(folder/'manifest.json').write_text(json.dumps({'version':'2.0.0','files':files},indent=2)+'\n',encoding='utf8')
sources=SITE/'licenses/sources.json';records=json.loads(sources.read_text('utf8'));records=[r for r in records if r.get('project')!='monitor-multi-toolbox']
records.append({'project':'monitor-multi-toolbox','version':'2.0.0','sourceArchive':'licenses/monitor-source.zip','changes':'First-party Canvas patterns with Window Management placement and BroadcastChannel session synchronization. No additional third-party runtime.'})
sources.write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(SITE/'licenses/monitor-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(folder.iterdir()):
  if p.is_file():z.write(p,'toolbox-site/tools/monitor/'+p.name)
 for name in ['package-monitor-source.py','stage-monitor-release.py']:
  z.write(ROOT/'_scratch'/name,'_scratch/'+name)
 for p in (ROOT/'_scratch/ops-tests').glob('monitor-*.py'):z.write(p,'_scratch/ops-tests/'+p.name)
 z.writestr('BUILD.md','''# 多屏显示器检测

纯静态网页，直接以 HTTP/HTTPS 提供 toolbox-site；没有 npm 或本地服务依赖。浏览器测试使用 Python3 + Playwright，运行 _scratch/ops-tests/monitor-multi.py 和 monitor-platform.py。TOOLBOX_TEST_BASE 指定站点。

多屏检测面板：识别显示器需支持 Window Management API 的 Chrome/Edge、HTTPS 和用户授权；全部检测需允许站点弹窗。开窗时尝试按屏幕可用区域定位并进入对应屏幕全屏；浏览器拒绝无用户手势全屏时，请在每个检测窗口点击全屏。不支持自动识别时新增窗口，拖到目标屏幕后全屏，图案/暂停/速度/结束仍会同步。最多16窗口。

自动测试验证真实多网页BroadcastChannel同步与模拟ScreenDetailed接口；不能代替物理多屏定位的实机验证。动态画面使用共同时间基准，不保证不同屏幕刷新率下逐帧一致。刷新/关闭控制页结束所属窗口，不保存检测会话。
''')
print(json.dumps({'monitor_runtime_files':len(files),'source_kb':round((SITE/'licenses/monitor-source.zip').stat().st_size/1024,1)}))
