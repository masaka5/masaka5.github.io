import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();context=await b.new_context(viewport={'width':1280,'height':800});page=await context.new_page();errors=[]
  context.on('page',lambda p:p.on('pageerror',lambda e:errors.append(str(e))))
  await page.goto(BASE+'/tools/monitor/')
  assert await page.locator('#multiTest').count()==1,'multi-monitor entry is missing'
  await page.locator('#multiTest').click();await page.locator('#multiPanel').wait_for(state='visible')
  async with page.expect_popup()as pending:await page.locator('#manualScreen').click()
  first=await pending.value;await first.wait_for_function("document.querySelector('#testStage').classList.contains('is-testing')")
  async with page.expect_popup()as pending:await page.locator('#manualScreen').click()
  second=await pending.value;await second.wait_for_function("document.querySelector('#testStage').classList.contains('is-testing')")
  await first.locator('#nextPattern').click(force=True)
  await second.wait_for_function("document.querySelector('#testStage').dataset.pattern==='solid-green'")
  await page.wait_for_function("document.querySelector('#testStage').dataset.pattern==='solid-green'")
  await page.locator('#closeMultiPanel').click();await page.locator('[data-group=motion]').click()
  await second.wait_for_function("document.querySelector('#testStage').dataset.pattern==='breathing'")
  await first.locator('#overlayPause').click(force=True)
  await page.wait_for_function("document.querySelector('#pauseMotion').textContent==='继续'")
  await second.wait_for_function("document.querySelector('#overlayPause').textContent==='继续'")
  await page.locator('[data-pattern=motion]').click();await page.locator('#motionSpeed').fill('1000');await page.locator('#motionSpeed').dispatch_event('input')
  await second.wait_for_function("document.querySelector('#motionSpeed').value==='1000'")
  await first.locator('#endTest').click(force=True)
  await page.wait_for_function("document.querySelector('#multiStatus').textContent.includes('已结束')")
  await page.wait_for_timeout(100);assert first.is_closed()and second.is_closed()
  assert not errors,errors
  print(json.dumps({'base':BASE,'real_windows':2,'pattern_sync':True,'pause_sync':True,'speed_sync':True,'cleanup':True,'errors':errors}));await b.close()
asyncio.run(main())
