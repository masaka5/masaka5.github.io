import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
FAKE="""(()=>{
 const screens=[{label:'主屏',width:1920,height:1080,availWidth:1920,availHeight:1040,availLeft:0,availTop:0,isPrimary:true},{label:'副屏',width:2560,height:1440,availWidth:2560,availHeight:1400,availLeft:-2560,availTop:0,isPrimary:false}];
 window.screenDetails={screens};window.getScreenDetails=async()=>window.screenDetails;window.openedFeatures=[];
 const open=window.open;window.open=function(url,name,features){window.openedFeatures.push(features);return open.call(this,url,name,features)};
 Element.prototype.requestFullscreen=async function(options){window.requestedScreen=options?.screen?.label;throw new DOMException('gesture','NotAllowedError')};
})()"""
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();ctx=await b.new_context();await ctx.add_init_script(FAKE);page=await ctx.new_page();errors=[]
  ctx.on('page',lambda t:t.on('pageerror',lambda e:errors.append(str(e))))
  await page.goto(BASE+'/tools/monitor/');await page.locator('#multiTest').click();await page.locator('#identifyScreens').click()
  assert await page.locator('.screen-row').count()==2
  await page.locator('#allScreens').click();await page.wait_for_timeout(500)
  children=[t for t in ctx.pages if t!=page];assert len(children)==2
  for t in children:await t.wait_for_function("document.querySelector('#testStage').classList.contains('is-testing')")
  assert await page.evaluate("openedFeatures.some(v=>v.includes('left=-2560'))")
  assert [await t.evaluate('requestedScreen')for t in children]==['主屏','副屏']
  for t in children:assert await t.locator('#retryFullscreen').is_visible()
  await page.screenshot(path='_scratch/monitor-multi-desktop.png')
  await page.evaluate('()=>{screenDetails.screens=screenDetails.screens.slice(1);screenDetails.onscreenschange()}')
  assert await page.locator('.screen-row').count()==1
  await page.locator('.screen-row button').click()
  assert children[0].is_closed(),'removed screen window must close'
  assert not children[1].is_closed(),'remaining screen must keep its own window'
  assert await page.evaluate('openedFeatures.length')==2,'existing screen must not open duplicate'
  await page.locator('#endScreens').click();assert all(t.is_closed()for t in children)
  await page.evaluate("()=>{window.getScreenDetails=async()=>{throw new DOMException('denied','NotAllowedError')}}")
  await page.locator('#identifyScreens').click();assert '未获得' in await page.locator('#multiStatus').inner_text()
  await page.evaluate('window.open=()=>null');await page.locator('#manualScreen').click();assert '拦截' in await page.locator('#multiStatus').inner_text()
  assert await page.locator('#endScreens').is_disabled()
  await page.locator('#closeMultiPanel').click()
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h})
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight')
   for s in ['#multiTest','#startTest']:
    r=await page.locator(s).bounding_box();assert r and r['x']>=0 and r['x']+r['width']<=w,(w,h,s,r)
   await page.locator('#multiTest').click()
   if (w,h)==(390,400):await page.screenshot(path='_scratch/monitor-multi-mobile.png')
   await page.locator('#closeMultiPanel').click()
  await ctx.close()
  # Unsupported platform retains manual synchronized windows; closing controller closes its children.
  ctx=await b.new_context();await ctx.add_init_script('window.getScreenDetails=undefined');page=await ctx.new_page();await page.goto(BASE+'/tools/monitor/')
  await page.locator('#multiTest').click();await page.locator('#identifyScreens').click();assert '不支持' in await page.locator('#multiStatus').inner_text()
  async with page.expect_popup()as pending:await page.locator('#manualScreen').click()
  child=await pending.value;await child.wait_for_function("document.querySelector('#testStage').classList.contains('is-testing')")
  await page.reload()
  if not child.is_closed():await child.wait_for_event('close')
  # Single-display flow remains usable.
  await page.locator('#startTest').click();await page.wait_for_function("document.querySelector('#testStage').classList.contains('is-testing')")
  await page.locator('#patternCanvas').click();assert await page.locator('#testStage').get_attribute('data-pattern')=='solid-green'
  await page.locator('#endTest').click(force=True);assert not await page.locator('#testStage').evaluate('(e)=>e.classList.contains("is-testing")')
  assert not errors,errors
  print(json.dumps({'base':BASE,'simulated_screens':2,'negative_position':True,'fullscreen_fallback':True,'permission_denied':True,'popup_blocked':True,'unsupported_fallback':True,'controller_reload_cleanup':True,'single_screen':True,'layouts':5,'errors':errors}));await b.close()
asyncio.run(main())
