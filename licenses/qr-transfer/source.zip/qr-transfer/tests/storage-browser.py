"""Orphan cleanup must preserve a different active sender's leased file."""
from pathlib import Path
import os,json
from playwright.sync_api import sync_playwright,expect
URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
with sync_playwright()as p:
 b=p.chromium.launch();ctx=b.new_context();a=ctx.new_page();a.goto(URL)
 def prepare(page):
  page.locator('input[type=file]').first.set_input_files({'name':'lease.bin','mimeType':'application/octet-stream','buffer':os.urandom(9000)});page.get_by_role('button',name='生成二维码',exact=True).click();expect(page.locator('.qr-display canvas')).to_be_visible(timeout=20000);page.get_by_role('button',name='暂停播放').click()
 def sends():return a.evaluate("async()=>{const r=await navigator.storage.getDirectory(),n=[];for await(const [name]of r.entries())if(name.startsWith('pqr-send-'))n.push(name);return n.sort();}")
 prepare(a);first=sends();assert len(first)==1,first
 other=ctx.new_page();other.goto(URL);prepare(other);assert len(sends())==2 and first[0]in sends()
 other.close();prepare(a);assert len(sends())==1,sends()
 a.reload();prepare(a);assert len(sends())==1,sends()
 b.close();print(json.dumps({'activeSenderPreserved':True,'closedSenderReclaimed':True,'refreshOrphanReclaimed':True}))
