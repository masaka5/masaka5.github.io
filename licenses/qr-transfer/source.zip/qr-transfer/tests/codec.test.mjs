import test from 'node:test';import assert from 'node:assert/strict';import {createRequire} from 'node:module';
import {seal,open} from '../src/package.mjs';
const zstd=createRequire(import.meta.url)('@bokuweb/zstd-wasm');let safe;try{safe=await import('../src/zstd-size.mjs');}catch{}
test('real Zstandard WASM compresses and restores, bounded by declared frame content size',async()=>{
 assert.ok(safe,'bounded WASM decode is missing');await zstd.init();const codec={compress:b=>zstd.compress(b,3),decompress:(b,size)=>{safe.checkZstd(b,size);return zstd.decompress(b);}};
 const data=new TextEncoder().encode('中文数据\n'.repeat(20000)),sealed=await seal([{name:'压缩.txt',data}],'secret',codec);
 assert.equal(sealed.compressed,true);assert.ok(sealed.bytes.length<data.length/10);
 assert.deepEqual((await open(sealed.bytes,'secret',codec)).files[0].data,data);
 assert.throws(()=>safe.checkZstd(new Uint8Array([0x28,0xb5,0x2f,0xfd,0xe0,255,255,255,255,255,255,255,127]),100),/长度|限制/);
 assert.throws(()=>safe.checkZstd(new Uint8Array([0x28,0xb5,0x2f,0xfd,0,255]),100));
});
