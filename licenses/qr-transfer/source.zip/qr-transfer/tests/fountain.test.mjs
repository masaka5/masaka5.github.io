import test from 'node:test';import assert from 'node:assert/strict';
let f;try{f=await import('../src/fountain.mjs');}catch{}
test('maximum density fills QR byte capacity and supports five GiB without uint32 overflow',()=>{
 assert.ok(f,'fountain implementation missing');assert.equal(f.MAX_FILE,5*1024**3);assert.equal(f.MAX_SHARD+f.HEADER,2953);
 const meta={id:'1234567890abcdef',length:5*1024**3,size:f.MAX_SHARD};const gen=Math.floor((meta.length-1)/(128*meta.size)),k=f.count(meta,gen);
 const packet=f.encodePacket(meta,gen,0,new Uint8Array(meta.size));assert.equal(packet.length,2953);const decoded=f.decodePacket(packet);assert.equal(decoded.length,meta.length);assert.equal(decoded.generation,gen);assert.equal(decoded.k,k);
 assert.throws(()=>f.validateFiles([{name:'too-big',size:f.MAX_FILE+1}]));assert.equal(f.validateFiles([{name:'exact',size:f.MAX_FILE}]),f.MAX_FILE);
});
test('fountain recovers with missing original shards, shuffled repair symbols and duplicates',()=>{
 assert.ok(f);const raw=crypto.getRandomValues(new Uint8Array(12000)),meta={id:'1234567890abcdef',length:raw.length,size:600},k=f.count(meta,0),decoder=new f.Generation(k,600),packets=[];
 for(let seed=0;seed<k*5;seed++)if(seed%3!==0)packets.push(f.decodePacket(f.symbol(meta,raw,0,seed)));
 for(const packet of packets.toReversed()){decoder.accept(packet.seed,packet.generation,packet.data);if(decoder.complete)break;}
 assert.ok(decoder.complete);assert.deepEqual(decoder.bytes().slice(0,raw.length),raw);assert.equal(decoder.accept(packets[0].seed,0,packets[0].data),false);
 const resumed=f.Generation.restore(decoder.snapshot());assert.deepEqual(resumed.bytes(),decoder.bytes());
});
test('partial generation snapshots resume, dependent symbols do not inflate rank and corruption fails CRC',()=>{
 assert.ok(f);const meta={id:'1234567890abcdef',length:10000,size:600},source=new Uint8Array(10000).map((_,i)=>i%251),decoder=new f.Generation(f.count(meta,0),600);
 const first=f.decodePacket(f.symbol(meta,source,0,0));decoder.accept(first.seed,0,first.data);decoder.accept(first.seed,0,first.data);assert.equal(decoder.rank,1);
 const resumed=f.Generation.restore(decoder.snapshot());for(let s=20;!resumed.complete&&s<200;s++){const p=f.decodePacket(f.symbol(meta,source,0,s));resumed.accept(p.seed,0,p.data);}assert.deepEqual(resumed.bytes().slice(0,source.length),source);
 const corrupt=f.symbol(meta,source,0,2);corrupt[corrupt.length-1]^=1;assert.throws(()=>f.decodePacket(corrupt),/校验/);
});
test('128-dimensional generations recover from repair-only symbols; default rounds generate new seeds',()=>{
 const size=f.MAX_SHARD,raw=Uint8Array.from({length:size*270+17},(_,i)=>(i*71+(i>>>8))%256),meta={id:'9876543210abcdef',length:raw.length,size};
 for(let generation=0;generation<f.generations(meta);generation++){
  const source=raw.subarray(generation*128*size,(generation+1)*128*size),k=f.count(meta,generation),decoder=new f.Generation(k,size);
  const seeds=Array.from({length:k+32},(_,i)=>1000+i).reverse();
  for(const seed of seeds){if(seed%7===0)continue;const p=f.decodePacket(f.symbol(meta,source,generation,seed));decoder.accept(seed,generation,p.data);if(decoder.complete)break;}
  assert.ok(decoder.complete,`generation ${generation}`);assert.deepEqual(decoder.bytes().slice(0,source.length),source);
 }
 assert.equal(f.position(meta,0).seed,0);assert.equal(f.position(meta,256).generation,1);
 assert.equal(f.position(meta,0,2).seed,256);assert.equal(f.position(meta,0,3).seed,512);
});
