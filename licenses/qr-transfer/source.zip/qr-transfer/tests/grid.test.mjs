import test from 'node:test';import assert from 'node:assert/strict';import {build} from 'esbuild';import {fileURLToPath} from 'node:url';import {decodePacket,MAX_SHARD} from '../src/fountain.mjs';
let grid;try{const r=await build({entryPoints:[fileURLToPath(new URL('../src/grid.mjs',import.meta.url))],bundle:true,format:'esm',write:false,platform:'node',logLevel:'silent'});grid=await import('data:text/javascript;base64,'+Buffer.from(r.outputFiles[0].contents).toString('base64'));}catch{}
test('automatic grid fits module pitch and manual grid obeys display aspect',()=>{
 assert.ok(grid,'grid integration missing');assert.equal(grid.chooseGrid(380,380,185,'auto').count,1);assert.equal(grid.chooseGrid(1920,1080,185,'auto').count,2);
 const g=grid.chooseGrid(1600,1000,185,6);assert.equal(g.cols*g.rows,6);assert.ok(g.cols>=g.rows);
});
test('multi-code planning covers sources, new fountain seeds, repairs and >4 GiB offsets',()=>{
 assert.ok(grid);const meta={id:'1234567890abcdef',length:MAX_SHARD*260,size:MAX_SHARD},seen=[];
 for(let i=0;i<130;i++)seen.push(...grid.framePlan(meta,i,1,null,4));assert.equal(new Set(seen.map(p=>p.generation+':'+p.seed)).size,520);
 const repair=grid.framePlan(meta,0,3,[2],4);assert.ok(repair.every(p=>p.generation===2&&p.seed>=4));
 const big={...meta,length:5*1024**3};const last=grid.framePlan(big,Math.ceil(Math.ceil(big.length/big.size)*2/9)-1,2,null,9);assert.ok(last.length>0);assert.ok(last[0].generation*128*MAX_SHARD>2**32);
});
test('Decimen rasterizer renders independent QR matrices with quiet zones',()=>{
 assert.ok(grid);const packets=[new Uint8Array(2953),new Uint8Array(2953)],r=grid.renderGrid(packets,{cols:2,rows:1});assert.equal(r.width,370);assert.equal(r.height,185);assert.equal(r.pixels.length,370*185);assert.equal(r.pixels[0],0xffffffff);assert.equal(r.pixels[4*370+4],0xff000000);assert.equal(r.version,40);
});
