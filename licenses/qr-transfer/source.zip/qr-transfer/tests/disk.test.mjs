import test from 'node:test';import assert from 'node:assert/strict';import {Disk} from '../src/disk.mjs';
test('disk-backed exports reject silently truncated browser storage instead of returning partial files',async()=>{
 const removed=[];Object.defineProperty(globalThis,'navigator',{value:{storage:{getDirectory:async()=>({removeEntry:async name=>removed.push(name)})}},configurable:true});
 const make=(physical,fileSize)=>{const d=new Disk();d.name='pqr-test.bin';d.position=5*1024**3;d.handle={getSize:()=>physical,flush(){},close(){}};d.file={getFile:async()=>({size:fileSize})};return d;};
 await assert.rejects(make(2000*1024**2,2000*1024**2).finish(),/未能完整暂存/);
 await assert.rejects(make(5*1024**3,2000*1024**2).finish(),/未能完整暂存/);
 assert.equal((await make(5*1024**3,5*1024**3).finish()).size,5*1024**3);assert.equal(removed.length,2);
});
