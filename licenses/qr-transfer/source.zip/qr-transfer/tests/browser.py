from pathlib import Path
import json,hashlib,os
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-transfer-tests';OUT.mkdir(exist_ok=True)
BASE=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765');URL=BASE+'/tools/qr-transfer/'
raw=bytes((i*31+i//7)%256 for i in range(8192));(OUT/'source.bin').write_bytes(raw)
with sync_playwright()as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':900},locale='zh-CN',accept_downloads=True)
 sender=ctx.new_page();errors=[];sender.on('pageerror',lambda e:errors.append(str(e)));sender.goto(URL)
 expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=20000)
 sender.locator('input[type=file]').first.set_input_files({'name':'中文.bin','mimeType':'application/octet-stream','buffer':raw})
 sender.get_by_role('button',name='生成二维码',exact=True).click()
 expect(sender.get_by_role('button',name='暂停播放',exact=True)).to_be_visible(timeout=20000)
 sender.get_by_role('button',name='暂停播放',exact=True).click()
 # Decode what is actually rendered, not any internal transfer API.
 def decode(page):
  return page.evaluate('''async()=>{const c=document.querySelector('.qr-display canvas');ZXingWASM.prepareZXingModule({overrides:{locateFile:p=>new URL('../../vendor/zxing/'+p,location.href).href}});const result=await ZXingWASM.readBarcodes(c.getContext('2d').getImageData(0,0,c.width,c.height),{formats:['QRCode'],tryHarder:true});return result.filter(r=>!r.error).map(r=>r.text);}''')
 first=decode(sender);assert len(first)==1,first
 count=int(first[0].split('|')[3]);assert count>=2,count
 frames=[];images=[]
 for i in range(count):
  text=decode(sender);assert len(text)==1,(i,text);frames.append(text[0])
  images.append(sender.locator('.qr-display canvas').screenshot())
  sender.get_by_role('button',name='下一帧',exact=True).click()
 receiver=ctx.new_page();receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive')
 expect(receiver.get_by_role('button',name='开始接收',exact=True)).to_be_visible()
 upload=receiver.locator('input[type=file]').last
 # Omit the second frame, feed the rest in reverse and duplicate the first.
 for i in [0,0]+list(reversed(range(2,count))):
  upload.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':images[i]})
  expect(receiver.locator('.camera-controls button').first).not_to_have_class('ant-btn-loading')
  receiver.wait_for_timeout(180)
 expect(receiver.locator('.receive-progress')).to_contain_text(f'{count-1} / {count} 帧',timeout=10000)
 expect(receiver.locator('.receive-progress')).to_contain_text('重复 1')
 receiver.reload();expect(receiver.locator('.receive-progress')).to_contain_text(f'{count-1} / {count} 帧')
 # Receiver produces a real, decodable missing-frame QR.
 receiver.get_by_role('button').filter(has_text='显示补帧码').click()
 repair=receiver.evaluate('''async()=>{const c=document.querySelector('.repair-code canvas');ZXingWASM.prepareZXingModule({overrides:{locateFile:p=>new URL('../../vendor/zxing/'+p,location.href).href}});return (await ZXingWASM.readBarcodes(c.getContext('2d').getImageData(0,0,c.width,c.height),{formats:['QRCode'],tryHarder:true}))[0].text;}''')
 assert repair.startswith('PQR1|')and repair.split('|')[3]=='1',repair
 receiver.locator('.ant-drawer-close').click();expect(receiver.get_by_role('dialog')).not_to_be_visible()
 upload=receiver.locator('input[type=file]').last
 upload.set_input_files({'name':'missing.png','mimeType':'image/png','buffer':images[1]})
 expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000)
 receiver.get_by_role('button').filter(has_text='查看 1 个文件').click()
 with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 中文.bin',exact=True).click()
 event.value.save_as(OUT/'received.bin');assert(OUT/'received.bin').read_bytes()==raw
 receiver.locator('.ant-drawer-close').click();expect(receiver.get_by_role('dialog')).not_to_be_visible()
 for page,role in [(sender,'send'),(receiver,'receive')]:
  for width,height in [(1440,900),(1920,1080),(1280,720),(390,844),(375,667),(320,568),(844,390)]:
   page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(160)
   metrics=page.evaluate('''()=>({w:innerWidth,h:innerHeight,sw:document.documentElement.scrollWidth,sh:document.documentElement.scrollHeight,canvas:[...document.querySelectorAll('.tool-pane:not([hidden]) canvas')].map(c=>c.getBoundingClientRect().toJSON())})''')
   assert metrics['sw']<=width and metrics['sh']<=height,(role,width,height,metrics)
   assert all(c['bottom']<=height+1 and c['right']<=width+1 for c in metrics['canvas']),(role,width,height,'canvas clipped',metrics)
   if width in [1440,390,320]:page.screenshot(path=str(OUT/f'{role}-{width}.png'))
 # Offline reload must still load app, compression and decoder WASM.
 ctx.set_offline(True);sender.reload();expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=15000)
 sender.locator('.input-heading .ant-select').click();sender.locator('.ant-select-item-option').filter(has_text='文本').click()
 sender.get_by_label('发送文本',exact=True).fill('离线传输内容\n你好 🌍')
 sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.get_by_role('button',name='暂停播放',exact=True)).to_be_visible(timeout=15000)
 sender.get_by_role('button',name='暂停播放',exact=True).click();assert decode(sender)[0].startswith('PQT1|')
 assert not errors,errors
 b.close();print(json.dumps({'frames':count,'actualQRWasmDecode':True,'unorderedDuplicateRecovery':True,'reloadResume':True,'missingFrameQR':True,'downloadSHA256':hashlib.sha256(raw).hexdigest(),'layouts':14,'offlineCompressionAndDecoding':True,'pageErrors':errors}))
