import test from 'node:test';import assert from 'node:assert/strict';import {createRequire} from 'node:module';
let p;try{p=await import('../src/stream-package.mjs');}catch{}
const zstd=createRequire(import.meta.url)('@bokuweb/zstd-wasm');await zstd.init();const codec={compress:b=>zstd.compress(b,3),decompress:b=>zstd.decompress(b)};
class Writer{constructor(){this.parts=[];this.position=0;}async append(b){this.parts.push(b.slice());this.position+=b.length;}async finish(){return new Blob(this.parts);}async abort(){this.parts=[];}}
const output=()=>new Writer();
test('stream packaging reads bounded slices, encrypts/compresses records and restores exact files',async()=>{
 assert.ok(p,'stream packaging missing');const raw=new Uint8Array(3*1024**2+19).map((_,i)=>i%251),file=new File([raw],'中文.bin'),empty=new File([],'空文件');let largest=0;const original=file.slice.bind(file);file.slice=(a,b)=>{largest=Math.max(largest,b-a);return original(a,b);};
 const writer=new Writer(),result=await p.sealStream([file,empty],'password',codec,writer);assert.ok(largest<=1048576);assert.ok(result.compressed);assert.ok(result.length<raw.length/10);
 await assert.rejects(()=>p.openStream(result.file,'wrong',codec,output),/密码/);
 const restored=await p.openStream(result.file,'password',codec,output);assert.deepEqual(new Uint8Array(await restored.files[0].blob.arrayBuffer()),raw);assert.equal(restored.files[1].blob.size,0);assert.match(restored.files[0].sha256,/^[a-f0-9]{64}$/);
 const corrupt=new Uint8Array(await result.file.arrayBuffer());corrupt[corrupt.length-1]^=1;await assert.rejects(()=>p.openStream(new Blob([corrupt]),'password',codec,output),/密码|校验|损坏/);
});
test('64-bit package metadata accepts 5 GiB and rejects oversized or malformed declarations',()=>{
 assert.ok(p);const h=p.streamHeader(5*1024**3,1,'');assert.equal(p.inspectStream(h).total,5*1024**3);assert.throws(()=>p.streamHeader(5*1024**3+1,1,''));
 const bad=h.slice();bad[21]=255;assert.throws(()=>p.inspectStream(bad));
});
