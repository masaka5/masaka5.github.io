"""Real RGB channel decoding and independent packet recovery in the shipped worker."""
from pathlib import Path
import os,json,base64,hashlib
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-fountain-tests';OUT.mkdir(exist_ok=True)
URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/';raw=os.urandom(90000)
with sync_playwright()as p:
 engine=os.environ.get('QR_BROWSER','chromium');browser=(p.firefox.launch()if engine=='firefox'else p.chromium.launch(**({'channel':'msedge'}if engine=='edge'else{})))
 ctx=browser.new_context(viewport={'width':1920,'height':1080},accept_downloads=True);page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(URL)
 page.locator('input[type=file]').first.set_input_files({'name':'彩色传输.bin','mimeType':'application/octet-stream','buffer':raw});page.get_by_role('button',name='传输设置').click();page.get_by_role('slider',name='刷新速度',exact=True).press('Home');expect(page.get_by_label('编码模式',exact=True).first).to_contain_text('彩色');assert page.get_by_role('link',name='源码',exact=True).count()==0;page.locator('.ant-drawer-close').click();page.get_by_role('button',name='生成二维码',exact=True).click();expect(page.locator('.qr-display canvas')).to_be_visible(timeout=20000);page.get_by_role('button',name='暂停播放').click()
 page.evaluate("""async()=>{const manifest=await(await fetch('./manifest.json')).json();window.decoderURL='./assets/decode-worker.js?v='+manifest.revision;window.gridDecoder=new Worker(decoderURL,{type:'module'});window.gridSeq=0;window.decodeColor=(variant='original')=>new Promise((resolve,reject)=>{const c=document.querySelector('.qr-display canvas'),s=document.createElement('canvas');s.width=c.width;s.height=c.height;const ctx=s.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,s.width,s.height);if(variant==='rotate'){ctx.translate(s.width,0);ctx.rotate(Math.PI/2);}ctx.drawImage(c,0,0);const data=ctx.getImageData(0,0,s.width,s.height);if(variant==='tint')for(let i=0;i<data.data.length;i+=4){const r=data.data[i],g=data.data[i+1],b=data.data[i+2];data.data[i]=20+r*.75+g*.06;data.data[i+1]=8+g*.8+b*.05;data.data[i+2]=15+b*.68+r*.04;}if(variant==='missing-blue')for(let i=0;i<data.data.length;i+=4)data.data[i+2]=255;const id=++gridSeq,t=setTimeout(()=>reject(Error('decode timeout')),15000);gridDecoder.onmessage=({data:r})=>{clearTimeout(t);resolve({count:r.symbols.length,color:r.color,tracked:r.tracked,error:r.error,channels:r.symbols.map(s=>s.channel),flags:r.symbols.map(s=>s.bytes[32]),bytes:r.symbols.map(s=>Array.from(s.bytes))});};gridDecoder.onerror=e=>reject(Error(e.message));gridDecoder.postMessage({id,width:s.width,height:s.height,buffer:data.data.buffer,started:performance.now()},[data.data.buffer]);});}""")
 rows=[]
 for count in [1,2,4,6,9]:
  page.get_by_role('button',name='传输设置').click();page.get_by_label('并行码数',exact=True).first.click();page.locator(f'.ant-select-item-option[title="{count} 码"]').click();page.locator('.ant-drawer-close').click();expect(page.locator('.qr-display canvas')).to_have_attribute('data-codes',str(count));page.wait_for_timeout(150)
  result=page.evaluate('decodeColor()');assert not result.get('error'),result;assert result['color']and result['count']==count*3,(count,result['count']);assert result['flags']==[1]*(count*3)
  tracked=page.evaluate('decodeColor()');assert tracked['tracked']==count*3,(count,tracked['tracked']);rows.append({'visibleCodes':count,'independentPackets':result['count']})
 # Probe tint and a lost channel with one position, without discarding its siblings.
 page.get_by_role('button',name='传输设置').click();page.get_by_label('并行码数',exact=True).first.click();page.locator('.ant-select-item-option[title="1 码"]').click();page.locator('.ant-drawer-close').click();expect(page.locator('.qr-display canvas')).to_have_attribute('data-codes','1');page.wait_for_timeout(200)
 for variant,expected in [('tint',3),('rotate',3),('missing-blue',2)]:
  result=page.evaluate('variant=>decodeColor(variant)',variant);assert result['count']==expected,(variant,result['count'])
 expect(page.get_by_role('dialog')).not_to_be_visible();page.screenshot(path=str(OUT/'color-desktop.png'))
 total=int(page.locator('.frame-number').inner_text().split(' / ')[1]);images=[]
 for _ in range(total):
  page.wait_for_timeout(80);images.append(base64.b64decode(page.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]")));page.get_by_role('button',name='下一帧').click()
 receiver=ctx.new_page();receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive')
 for i,image in enumerate(images):
  receiver.locator('input[type=file]').last.set_input_files({'name':'color.png','mimeType':'image/png','buffer':image});receiver.wait_for_timeout(150)
  if i==0:expect(receiver.locator('.receive-progress')).to_contain_text('3 / ');receiver.reload();expect(receiver.locator('.receive-progress')).to_contain_text('3 / ')
  if receiver.get_by_text('接收完成',exact=True).is_visible():break
 expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000);receiver.get_by_role('button').filter(has_text='查看 1 个文件').click()
 with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 彩色传输.bin').click()
 event.value.save_as(OUT/'color-received.bin');assert(OUT/'color-received.bin').read_bytes()==raw
 expect(page.get_by_text('离线可用',exact=True)).to_be_visible(timeout=20000);ctx.set_offline(True);page.evaluate("gridDecoder.terminate();gridDecoder=new Worker(decoderURL,{type:'module'})");assert page.evaluate('decodeColor()')['count']==3
 assert not errors,errors;browser.close();print(json.dumps({'browser':engine,'grid':rows,'threePlanes':True,'tint':True,'rotation':True,'lostBlueKeptOthers':True,'refresh':True,'downloadSha256':hashlib.sha256(raw).hexdigest(),'offlineWorker':True,'pageErrors':errors}))
