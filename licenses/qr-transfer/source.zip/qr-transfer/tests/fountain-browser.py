from pathlib import Path
import os,json,base64,hashlib
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-fountain-tests';OUT.mkdir(exist_ok=True);URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
raw=os.urandom(9000)
with sync_playwright()as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':900},locale='zh-CN',accept_downloads=True);sender=ctx.new_page();errors=[];sender.on('pageerror',lambda e:errors.append(str(e)));sender.goto(URL)
 sender.get_by_role('button',name='传输设置').click();sender.get_by_label('编码模式',exact=True).first.click();sender.locator('.ant-select-item-option[title="黑白 · 稳定兼容"]').click();sender.get_by_role('slider',name='刷新速度',exact=True).press('Home');sender.locator('.ant-drawer-close').click()
 expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=30000);sender.locator('input[type=file]').first.set_input_files({'name':'喷泉.bin','mimeType':'application/octet-stream','buffer':raw});sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.locator('.qr-display canvas')).to_be_visible(timeout=30000);sender.get_by_role('button',name='暂停播放').click()
 def decode(page):return page.evaluate("""async()=>{ZXingWASM.prepareZXingModule({overrides:{locateFile:p=>new URL('../../vendor/zxing/'+p,location.href).href}});const c=document.querySelector('.qr-display canvas');const r=(await ZXingWASM.readBarcodes(c.getContext('2d').getImageData(0,0,c.width,c.height),{formats:['QRCode'],tryHarder:true}))[0];return r?{bytes:[...r.bytes],error:r.error,text:r.text}:null;}""")
 data=decode(sender);assert data and not data['error'],data;packet=bytes(data['bytes']);assert packet[:4]==b'PQF2' and len(packet)==2953
 expect(sender.locator('.qr-display canvas')).to_have_attribute('data-version','40');k=int.from_bytes(packet[30:32],'big');total=2*k;images=[];packets=[]
 for i in range(total):
  expect(sender.locator('.frame-number')).to_have_text(f'{i+1} / {total}');sender.wait_for_timeout(60);current=decode(sender);packets.append(bytes(current['bytes']));images.append(base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]")));sender.get_by_role('button',name='下一帧').click()
 receiver=ctx.new_page();receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive');expect(receiver.get_by_role('button',name='开始接收')).to_be_enabled()
 def feed(image):receiver.locator('input[type=file]').last.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':image});receiver.wait_for_timeout(100)
 # Omit all original symbols. Only new random repair combinations are scanned.
 feed(images[k]);feed(images[k]);expect(receiver.locator('.receive-progress')).to_contain_text('冗余 1');receiver.reload();expect(receiver.locator('.receive-progress')).to_contain_text('1 / ')
 receiver.get_by_role('button').filter(has_text='显示补发码').click();repair=base64.b64decode(receiver.locator('.repair-code canvas').evaluate("c=>c.toDataURL().split(',')[1]"));receiver.locator('.ant-drawer-close').click()
 sender.get_by_role('button',name='扫描补帧码').click();sender.locator('.ant-drawer input[type=file]').set_input_files({'name':'repair.png','mimeType':'image/png','buffer':repair});expect(sender.get_by_text('补发编码',exact=True)).to_be_visible();expect(sender.get_by_role('dialog')).not_to_be_visible();sender.get_by_role('button',name='暂停播放').click()
 # This repair selection starts new random seeds, not the missing original QR.
 for _ in range(k+14):
  image=base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]"));feed(image)
  if receiver.get_by_text('接收完成',exact=True).is_visible():break
  sender.get_by_role('button',name='下一帧').click();sender.wait_for_timeout(90)
 expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000);receiver.get_by_role('button').filter(has_text='查看 1 个文件').click()
 with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 喷泉.bin').click()
 event.value.save_as(OUT/'received.bin');assert(OUT/'received.bin').read_bytes()==raw;receiver.locator('.ant-drawer-close').click()
 for page,role in[(sender,'send'),(receiver,'receive')]:
  for width,height in[(1440,900),(1920,1080),(1280,720),(390,844),(375,667),(320,568),(844,390)]:
   page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(150);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(role,width,height)
   if width in[1440,390]:page.screenshot(path=str(OUT/f'{role}-{width}.png'))
 # Offline reload, local worker/OPFS/Zstd/hash WASM and binary QR decode.
 ctx.set_offline(True);sender.reload();expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=15000);sender.locator('.input-heading .ant-select').click();sender.locator('.ant-select-item-option').filter(has_text='文本').click();sender.get_by_label('发送文本',exact=True).fill('离线喷泉码验证');sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.locator('.qr-display canvas')).to_be_visible(timeout=15000);assert bytes(decode(sender)['bytes'])[:4]==b'PQF2'
 assert not errors,errors;b.close();print(json.dumps({'v40L':True,'rawQRBytes':len(packet),'payloadBytes':2916,'recoveredWithoutOriginalSymbols':True,'duplicateRankNotInflated':True,'refreshResume':True,'reverseRepairQR':True,'sha256':hashlib.sha256(raw).hexdigest(),'layouts':14,'offline':True,'pageErrors':errors}))
