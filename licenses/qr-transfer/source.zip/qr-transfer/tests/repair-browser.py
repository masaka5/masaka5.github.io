from pathlib import Path
import json,os,base64
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
with sync_playwright()as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1200,'height':900},locale='zh-CN');sender=ctx.new_page();sender.goto(URL)
 sender.locator('input[type=file]').first.set_input_files({'name':'test.bin','mimeType':'application/octet-stream','buffer':os.urandom(1800)})
 sender.get_by_role('button',name='生成二维码').click();expect(sender.get_by_role('button',name='暂停播放')).to_be_visible(timeout=15000);sender.get_by_role('button',name='暂停播放').click()
 image=sender.locator('.qr-display canvas').screenshot()
 receiver=ctx.new_page();receiver.goto(URL+'?view=receive');expect(receiver.get_by_role('button',name='开始接收')).to_be_enabled()
 receiver.locator('input[type=file]').last.set_input_files({'name':'first.png','mimeType':'image/png','buffer':image})
 expect(receiver.get_by_role('button').filter(has_text='显示补帧码')).to_be_visible(timeout=10000);receiver.get_by_role('button').filter(has_text='显示补帧码').click()
 repair=base64.b64decode(receiver.locator('.repair-code canvas').evaluate("c=>c.toDataURL('image/png').split(',')[1]"))
 sender.get_by_role('button',name='扫描补帧码').click();sender.locator('.ant-drawer input[type=file]').set_input_files({'name':'repair.png','mimeType':'image/png','buffer':repair})
 expect(sender.get_by_text('补帧发送',exact=True)).to_be_visible(timeout=10000)
 expect(sender.get_by_role('dialog')).not_to_be_visible();sender.get_by_role('button',name='暂停播放').click();assert int(sender.locator('.frame-number').inner_text().split(' / ')[0])>1
 # Tab switches pause the animation and camera.
 sender.locator('.ant-segmented-item').filter(has_text='接收').click();sender.wait_for_timeout(500)
 sender.locator('.ant-segmented-item').filter(has_text='发送').click();expect(sender.get_by_text('补帧发送',exact=True)).to_be_visible()
 b.close();print(json.dumps({'reverseMissingFrameQR':True,'senderOnlyMissingFrames':True,'tabSwitch':True}))
