import test from 'node:test';import assert from 'node:assert/strict';import {decodePacket,encodePacket,MAX_SHARD} from '../src/fountain.mjs';import {framePlan,renderColorGrid} from '../src/grid.mjs';
test('colour packets carry an explicit mode and a colour grid carries three independent QR planes',()=>{
 const meta={id:'1234567890abcdef',length:MAX_SHARD,size:MAX_SHARD},packet=encodePacket(meta,0,0,new Uint8Array(MAX_SHARD),'color');assert.equal(decodePacket(packet).mode,'color');
 const packets=Array.from({length:3},(_,channel)=>{const bytes=new Uint8Array(2953);bytes[4]=channel+1;return bytes;});const raster=renderColorGrid(packets,{cols:1,rows:1});assert.equal(raster.color,true);assert.equal(raster.pixels.length,raster.width*raster.height);const colors=new Set(raster.pixels);assert.ok(colors.size>2,'colour raster must contain more than black and white');
});
test('colour frame planning gives three independent packets per visible slot',()=>{const meta={id:'1234567890abcdef',length:MAX_SHARD*30,size:MAX_SHARD};assert.equal(framePlan(meta,0,1,null,3).length,3);assert.equal(framePlan(meta,0,1,null,27).length,27);});
