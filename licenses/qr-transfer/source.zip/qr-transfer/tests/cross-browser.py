from pathlib import Path
import json,os
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-transfer-tests';URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
with sync_playwright()as p:
 chromium=p.chromium.launch();sender=chromium.new_page(viewport={'width':1200,'height':900},locale='zh-CN');sender.goto(URL)
 sender.locator('input[type=file]').first.set_input_files({'name':'互通.txt','mimeType':'text/plain','buffer':b'cross engine '+bytes(range(256))*20})
 sender.get_by_role('button',name='生成二维码').click();expect(sender.get_by_role('button',name='暂停播放')).to_be_visible(timeout=15000);sender.get_by_role('button',name='暂停播放').click()
 images=[]
 for _ in range(2):images.append(sender.locator('.qr-display canvas').screenshot());sender.get_by_role('button',name='下一帧').click()
 results=[]
 for name,engine,options in [('firefox',p.firefox,{}),('edge',p.chromium,{'channel':'msedge'})]:
  b=engine.launch(**options);ctx=b.new_context(viewport={'width':390,'height':844},locale='zh-CN');page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(URL+'?view=receive')
  expect(page.get_by_role('button',name='开始接收')).to_be_enabled(timeout=10000)
  for image in images:
   page.locator('input[type=file]').last.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':image});page.wait_for_timeout(250)
  expect(page.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000)
  assert page.evaluate('document.documentElement.scrollHeight<=innerHeight&&document.documentElement.scrollWidth<=innerWidth')
  assert not errors,errors
  results.append({'engine':name,'decodedChromiumQR':True,'restoredWithWasm':True,'mobileNoOverflow':True,'errors':errors});b.close()
 # Camera denial must recover with image input still available.
 denied=chromium.new_context(permissions=[]);denied.add_init_script("navigator.mediaDevices.getUserMedia=()=>Promise.reject(new DOMException('denied','NotAllowedError'))");page=denied.new_page();page.goto(URL+'?view=receive')
 page.get_by_role('button',name='开始接收').click();expect(page.get_by_text('请允许摄像头访问',exact=True)).to_be_visible(timeout=10000)
 expect(page.get_by_role('button',name='从图片识别')).to_be_enabled()
 chromium.close();print(json.dumps({'crossBrowser':results,'cameraDeniedHandled':True}))
