"""Actual 5 GiB streaming test; QR samples + worker packets, not 5 GiB optical scanning."""
from pathlib import Path
import hashlib,json,os,time,tempfile
from playwright.sync_api import sync_playwright,expect

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'_scratch/qr-fountain-tests';OUT.mkdir(exist_ok=True)
FIXTURE=OUT/'five-gib-zero.bin';LIMIT=5*1024**3
URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
INJECT="""(()=>{
 const Native=globalThis.Worker;let serial=1000000000;
 globalThis.Worker=class extends Native{constructor(...args){super(...args);globalThis.testWorker=this;
 this.addEventListener('message',({data})=>{if(data.result?.originalBytes!==undefined)globalThis.testPrepared=data.result;});}};
 globalThis.testRPC=(type,payload={})=>new Promise((resolve,reject)=>{
 const id=++serial,w=globalThis.testWorker;
 const listener=({data})=>{if(data.id!==id)return;if(data.progress){globalThis.testProgress=data.progress;return;}
 w.removeEventListener('message',listener);data.error?reject(Error(data.error)):resolve(data.result);};
 w.addEventListener('message',listener);w.postMessage({id,type,...payload});});
})();"""
started=time.time()
try:
 with FIXTURE.open('wb')as f:f.truncate(LIMIT+1)
 with sync_playwright()as p,tempfile.TemporaryDirectory(prefix='pqr-large-send-')as sender_profile,tempfile.TemporaryDirectory(prefix='pqr-large-receive-')as receiver_profile:
  ctx=p.chromium.launch_persistent_context(sender_profile,viewport={'width':1440,'height':900});ctx.add_init_script(INJECT)
  sender=ctx.new_page();errors=[];sender.on('pageerror',lambda e:errors.append(str(e)));sender.goto(URL)
  expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=30000)
  sender.locator('input[type=file]').first.set_input_files(str(FIXTURE))
  expect(sender.get_by_role('alert')).to_contain_text('不能超过 5 GB')
  with FIXTURE.open('r+b')as f:f.truncate(LIMIT)
  sender.locator('input[type=file]').first.set_input_files(str(FIXTURE))
  sender.get_by_role('button',name='生成二维码',exact=True).click()
  sender.wait_for_function('()=>!!globalThis.testPrepared',timeout=600000)
  expect(sender.get_by_role('button',name='暂停播放')).to_be_visible(timeout=20000);sender.get_by_role('button',name='暂停播放').click()
  prepared=sender.evaluate('globalThis.testPrepared');meta=prepared['meta'];assert prepared['originalBytes']==LIMIT
  expect(sender.locator('.qr-display canvas')).to_have_attribute('data-version','40')
  qr=sender.evaluate("""async()=>{ZXingWASM.prepareZXingModule({overrides:{locateFile:p=>new URL('../../vendor/zxing/'+p,location.href).href}});const c=document.querySelector('.qr-display canvas');return [...(await ZXingWASM.readBarcodes(c.getContext('2d').getImageData(0,0,c.width,c.height),{formats:['QRCode'],tryHarder:true}))[0].bytes];}""")
  assert bytes(qr)[:4]==b'PQF2' and len(qr)==2953
  print(json.dumps({'stage':'prepared','originalBytes':LIMIT,'wireBytes':meta['length'],'elapsed':round(time.time()-started)}),flush=True)
  other=p.chromium.launch_persistent_context(receiver_profile);other.add_init_script(INJECT);receiver=other.new_page();receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive');receiver.wait_for_function('()=>!!globalThis.testWorker')
  generations=(meta['length']+128*meta['size']-1)//(128*meta['size'])
  for generation in range(generations):
   k=min(128,(meta['length']-generation*128*meta['size']+meta['size']-1)//meta['size']);complete=False
   for round_number in range(1,5):
    packets=sender.evaluate("""async({meta,generation,k,round_number})=>{const packets=[];for(let index=0;index<k+16;index++){const frame=await testRPC('frame',{transfer:meta.id,generation,index,round:round_number});packets.push([...frame.packet]);}return packets;}""",{'meta':meta,'generation':generation,'k':k,'round_number':round_number})
    status=receiver.evaluate("""async packets=>{let result;for(const bytes of packets)result=await testRPC('accept',{packet:new Uint8Array(bytes)});return result;}""",packets)
    if status['done']>=generation+1:complete=True;break
   assert complete,(generation,status)
  assert status['complete']
  print(json.dumps({'stage':'received','generations':generations,'onlyRepairSymbols':True}),flush=True)
  restored=receiver.evaluate("""async()=>{const r=await testRPC('restore');const f=r.files[0];return{size:f.blob.size,sha256:f.sha256,head:[...new Uint8Array(await f.blob.slice(0,64).arrayBuffer())],tail:[...new Uint8Array(await f.blob.slice(f.blob.size-64).arrayBuffer())]};}""")
  h=hashlib.sha256();block=bytes(1048576)
  for _ in range(LIMIT//len(block)):h.update(block)
  assert restored['size']==LIMIT and restored['sha256']==h.hexdigest(),restored
  assert restored['head']==[0]*64 and restored['tail']==[0]*64
  assert not errors,errors
  receiver.evaluate("()=>testRPC('clear')");sender.evaluate("()=>testRPC('cancel')");ctx.close();other.close()
 result={'actualFileBytes':LIMIT,'rejectOverLimit':True,'streamedPrepareAndRestore':True,'onlyRepairSymbols':True,'v40QRDecoded':True,'sha256':h.hexdigest(),'elapsedSeconds':round(time.time()-started),'pageErrors':errors}
 (OUT/'large-results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
finally:
 FIXTURE.unlink(missing_ok=True)
