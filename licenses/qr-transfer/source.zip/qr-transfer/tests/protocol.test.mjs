import test from 'node:test';import assert from 'node:assert/strict';
let p;try{p=await import('../src/protocol.mjs');}catch{}
test('out-of-order frames, duplicates, missing frames and snapshots recover exact bytes',()=>{
 assert.ok(p,'protocol is missing');const bytes=crypto.getRandomValues(new Uint8Array(2500)),sender=p.createTransfer(bytes,300),r=new p.Receiver();
 for(const i of [4,0,2,2,1,8,7,6])r.accept(sender.frame(i));
 assert.equal(r.received,7);assert.equal(r.duplicates,1);assert.deepEqual(r.missing(),[3,5]);
 const resumed=p.Receiver.restore(r.snapshot());for(const i of resumed.missing())resumed.accept(sender.frame(i));
 assert.deepEqual(resumed.bytes(),bytes);assert.equal(resumed.complete,true);
});
test('corruption and foreign sessions cannot poison an in-progress transfer',()=>{
 assert.ok(p);const a=p.createTransfer(new Uint8Array(901),300),b=p.createTransfer(new Uint8Array(901).fill(2),300),r=new p.Receiver();
 r.accept(a.frame(0));assert.throws(()=>r.accept(b.frame(1)),/其他传输/);
 const bad=a.frame(1).slice(0,-1)+'X';assert.throws(()=>r.accept(bad));assert.equal(r.received,1);
 assert.throws(()=>r.accept('https://example.com'));assert.throws(()=>p.createTransfer(new Uint8Array(17*1024*1024),300));
});
test('missing-frame request binds the exact transfer and rejects unbounded ranges',()=>{
 assert.ok(p);const a=p.createTransfer(new Uint8Array(1000),300),r=new p.Receiver();r.accept(a.frame(1));
 const request=p.createRequest(r);assert.deepEqual(p.parseRequest(request,a),[0,2,3]);
 assert.throws(()=>p.parseRequest(request,p.createTransfer(new Uint8Array(1001),300)));
});
