from pathlib import Path
from io import BytesIO
import json,os,hashlib,base64
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-fountain-tests';OUT.mkdir(exist_ok=True);URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
raw=os.urandom(3500)
with sync_playwright()as p:
 b=p.chromium.launch();sender=b.new_page(viewport={'width':1100,'height':900});sender.goto(URL);sender.locator('input[type=file]').first.set_input_files([{'name':'加密.bin','mimeType':'application/octet-stream','buffer':raw},{'name':'空文件.txt','mimeType':'text/plain','buffer':b''}]);sender.get_by_role('button',name='传输设置').click();sender.get_by_role('switch',name='密码加密').click();sender.get_by_label('加密密码',exact=True).fill('测试口令-123');sender.locator('.ant-drawer-close').click();sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.locator('.qr-display canvas')).to_be_visible(timeout=15000);sender.get_by_role('button',name='暂停播放').click();total=int(sender.locator('.frame-number').inner_text().split(' / ')[1].replace(',',''));images=[]
 for i in range(total):
  sender.wait_for_timeout(80);images.append(base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]")));sender.get_by_role('button',name='下一帧').click()
 video=OUT/'fountain-camera.y4m'
 with video.open('wb')as f:
  f.write(b'YUV4MPEG2 W800 H800 F10:1 Ip A1:1 C420jpeg\n')
  for data in images:
   image=Image.open(BytesIO(data)).convert('RGB').resize((740,740),Image.Resampling.NEAREST);surface=Image.new('RGB',(800,800),'white');surface.paste(image,(30,30));yuv=np.asarray(surface.convert('YCbCr'));y=yuv[:,:,0].tobytes();u=yuv[:,:,1].reshape(400,2,400,2).mean(axis=(1,3)).astype('uint8').tobytes();v=yuv[:,:,2].reshape(400,2,400,2).mean(axis=(1,3)).astype('uint8').tobytes()
   for _ in range(7):f.write(b'FRAME\n'+y+u+v)
 camera=p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--use-file-for-fake-video-capture='+str(video)]);ctx=camera.new_context(viewport={'width':390,'height':844},permissions=['camera'],accept_downloads=True);receiver=ctx.new_page();errors=[];receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive');receiver.get_by_role('button',name='开始接收').click();expect(receiver.get_by_text('等待解密',exact=True)).to_be_visible(timeout=45000);assert receiver.locator('video').evaluate('v=>v.srcObject===null')
 receiver.get_by_label('解密密码',exact=True).fill('错误密码');receiver.get_by_role('button').filter(has_text='解密').click();expect(receiver.get_by_text('密码错误或加密数据损坏',exact=True)).to_be_visible();receiver.get_by_label('解密密码',exact=True).fill('测试口令-123');receiver.get_by_role('button').filter(has_text='解密').click();expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000);receiver.get_by_role('button').filter(has_text='查看 2 个文件').click()
 for name,expected in[('加密.bin',raw),('空文件.txt',b'')]:
  with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 '+name).click()
  event.value.save_as(OUT/name);assert(OUT/name).read_bytes()==expected
 receiver.locator('.ant-drawer-close').click();receiver.get_by_role('button',name='清除接收进度').click();receiver.get_by_role('button',name='清 除',exact=True).click();expect(receiver.locator('.receive-progress')).to_contain_text('0 / 0 片');receiver.reload();expect(receiver.locator('.receive-progress')).to_contain_text('0 / 0 片');assert not errors,errors;camera.close();b.close();print(json.dumps({'v40CameraVideo':True,'actualGetUserMedia':True,'encryptedMultiFile':True,'wrongPasswordRetry':True,'emptyFile':True,'clearPersisted':True,'pageErrors':errors}))
