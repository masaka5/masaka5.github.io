"""Exercise the shipped Decimen worker, not a mock or the fallback decoder."""
from pathlib import Path
import os,json,base64
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-fountain-tests';OUT.mkdir(exist_ok=True)
URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
with sync_playwright()as p:
 browser=p.chromium.launch();page=browser.new_page(viewport={'width':1920,'height':1080});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(URL)
 page.locator('input[type=file]').first.set_input_files({'name':'grid.bin','mimeType':'application/octet-stream','buffer':os.urandom(60000)})
 page.get_by_role('button',name='传输设置').click();page.get_by_label('编码模式',exact=True).first.click();page.locator('.ant-select-item-option[title="黑白 · 稳定兼容"]').click();page.get_by_role('slider',name='刷新速度',exact=True).focus();page.get_by_label('刷新速度',exact=True).press('Home');page.locator('.ant-drawer-close').click()
 page.get_by_role('button',name='生成二维码',exact=True).click();expect(page.locator('.qr-display canvas')).to_be_visible(timeout=20000);page.get_by_role('button',name='暂停播放').click()
 page.evaluate("""async()=>{const manifest=await(await fetch('./manifest.json')).json();window.gridDecoder=new Worker('./assets/decode-worker.js?v='+manifest.revision,{type:'module'});window.gridSeq=0;window.decodeGrid=()=>new Promise((resolve,reject)=>{const c=document.querySelector('.qr-display canvas'),data=c.getContext('2d').getImageData(0,0,c.width,c.height),id=++gridSeq;const t=setTimeout(()=>reject(Error('decode timeout')),15000);gridDecoder.onmessage=({data:r})=>{clearTimeout(t);resolve({count:r.symbols.length,tracked:r.tracked,error:r.error,bytes:r.symbols.map(s=>s.bytes.length),headers:r.symbols.map(s=>Array.from(s.bytes.slice(0,4)))});};gridDecoder.onerror=e=>reject(Error(e.message));gridDecoder.postMessage({id,width:c.width,height:c.height,buffer:data.data.buffer,started:performance.now()},[data.data.buffer]);});}""")
 rows=[]
 for count in [1,2,4,6,9]:
  page.get_by_role('button',name='传输设置').click();page.get_by_label('并行码数',exact=True).first.click();page.locator(f'.ant-select-item-option[title="{count} 码"]').click();page.locator('.ant-drawer-close').click();expect(page.locator('.qr-display canvas')).to_have_attribute('data-codes',str(count));page.wait_for_timeout(60)
  first=page.evaluate('decodeGrid()');second=page.evaluate('decodeGrid()');assert not first.get('error'),first;assert first['count']==count,(count,first);assert second['tracked']==count,(count,second)
  assert all(n==2953 for n in first['bytes']);assert all(h==[80,81,70,50]for h in first['headers']);rows.append({'codes':count,'decoded':first['count'],'tracked':second['tracked'],'payloadPerFrame':count*2916})
  if count==4:
   expect(page.get_by_role('dialog')).not_to_be_visible();page.wait_for_timeout(250);page.screenshot(path=str(OUT/'decimen-grid4-desktop.png'))
 # Medium ECC must fit 2331 total QR bytes, including the protocol header.
 page.get_by_role('button',name='传输设置').click();page.get_by_label('每帧数据',exact=True).first.click();page.locator('.ant-select-item-option[title="2294 B · V40-M 强纠错"]').click();page.locator('.ant-drawer-close').click();page.get_by_role('button',name='生成二维码',exact=True).click();expect(page.locator('.qr-display canvas')).to_have_attribute('data-bytes','2331');page.get_by_role('button',name='暂停播放').click();medium=page.evaluate('decodeGrid()');assert medium['count']==9 and medium['bytes']==[2331]*9,medium
 # Offline worker restart also exercises locally cached compressed WASM.
 expect(page.get_by_text('离线可用',exact=True)).to_be_visible(timeout=20000);page.evaluate("window.gridWorkerURL=gridDecoder instanceof Worker?performance.getEntriesByType('resource').find(r=>r.name.includes('decode-worker.js')).name:null")
 page.context.set_offline(True)
 page.evaluate("gridDecoder.terminate();gridDecoder=new Worker(gridWorkerURL,{type:'module'})")
 offline=page.evaluate('decodeGrid()');assert offline['count']==9,offline
 assert not errors,errors
 browser.close();print(json.dumps({'grid':rows,'mediumEcc':True,'pageErrors':errors}))
