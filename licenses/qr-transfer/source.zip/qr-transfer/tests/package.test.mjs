import test from 'node:test';import assert from 'node:assert/strict';
let p;try{p=await import('../src/package.mjs');}catch{}
const identity={compress:b=>b,decompress:(b,size)=>{assert.equal(b.length,size);return b;}};
test('unicode, binary, empty files and text preserve metadata and bytes',async()=>{
 assert.ok(p,'file packaging is missing');const files=[{name:'中文.bin',type:'application/octet-stream',lastModified:123,data:new Uint8Array([0,255,1])},{name:'empty',type:'',data:new Uint8Array()}];
 const sealed=await p.seal(files,'',identity),opened=await p.open(sealed.bytes,'',identity);
 assert.equal(opened.files[0].name,files[0].name);assert.deepEqual(opened.files[0].data,files[0].data);assert.equal(opened.files[1].data.length,0);
 const text=await p.seal([{name:'文本.txt',type:'text/plain',data:new TextEncoder().encode('你好\n🌍')}],'',identity,'text');
 assert.equal((await p.open(text.bytes,'',identity)).kind,'text');
});
test('password, envelope digest, file digest and declared lengths are enforced',async()=>{
 assert.ok(p);const file={name:'secret.txt',data:new TextEncoder().encode('private')};const encrypted=await p.seal([file],'password',identity);
 assert.equal(encrypted.encrypted,true);await assert.rejects(()=>p.open(encrypted.bytes,'wrong',identity),/密码/);
 assert.deepEqual((await p.open(encrypted.bytes,'password',identity)).files[0].data,file.data);
 const corrupt=encrypted.bytes.slice();corrupt[corrupt.length-1]^=1;await assert.rejects(()=>p.open(corrupt,'password',identity),/校验/);
 await assert.rejects(()=>p.seal([{name:'large',data:new Uint8Array(17*1024*1024)}],'',identity),/16 MB/);
});
