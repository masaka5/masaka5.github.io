import test from 'node:test';import assert from 'node:assert/strict';import {decodePool} from '../src/decode-pool.mjs';
test('decode pool waits for durable delivery and releases every worker on initialization/error',async()=>{
 const workers=[];let stopped=0,calls=0,errors=0,release;
 globalThis.__QR_REVISION__='test';Object.defineProperty(globalThis,'navigator',{configurable:true,value:{hardwareConcurrency:8}});
 globalThis.Worker=class{constructor(){if(++calls===2)throw Error('worker limit');workers.push(this);}terminate(){stopped++;}addEventListener(){} };
 assert.throws(()=>decodePool(()=>{},()=>{}),/worker limit/);assert.equal(stopped,1);
 workers.length=0;globalThis.Worker=class{constructor(){workers.push(this);this.listeners={};}addEventListener(type,fn){this.listeners[type]=fn;}postMessage(){}terminate(){stopped++;} };
 const pool=decodePool(()=>new Promise(resolve=>release=resolve),()=>errors++);
 assert.ok(pool.submit({}));const event={data:{id:1,symbols:[{bytes:new Uint8Array([1])}]}};workers[0].listeners.message(event);workers[0].onmessage(event);await Promise.resolve();assert.equal(pool.available,false);
 release();await new Promise(resolve=>setImmediate(resolve));assert.equal(pool.available,true);
 workers[0].listeners.message({data:{id:2,error:'decode failed'}});assert.equal(pool.available,false);assert.equal(errors,1);assert.equal(stopped,3);pool.stop();
});
