import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {readFile} from 'node:fs/promises';
const script=await readFile(new URL('../sw.js',import.meta.url),'utf8');
function service(){
 const handlers={},base='https://example.test/tools/qr-transfer/',entries=new Map([[base,new Response('cached page')],[base+'assets/app.js',new Response('legacy script')],[base+'assets/app.js?v=current',new Response('current script')]]);let online=true;
 const cache={match:async(req,options)=>{const url=typeof req==='string'?req:req.url;if(options?.ignoreSearch)return [...entries].find(([key])=>key.split('?')[0]===url.split('?')[0])?.[1].clone();return entries.get(url)?.clone();}};
 vm.runInNewContext(script,{self:{location:{href:base+'sw.js'},addEventListener:(name,fn)=>handlers[name]=fn},URL,Request,Response,AbortController,setTimeout,clearTimeout,caches:{open:async()=>cache},fetch:async()=>{if(!online)throw Error('offline');return new Response('fresh network');}});
 return{fetch:async(path,mode='cors')=>{let response;handlers.fetch({request:{method:'GET',url:new URL(path,base).href,mode},respondWith:p=>response=p});return response?await(await response).text():null;},offline:()=>online=false};
}
test('refresh serves the network page instead of a stale protocol, falling back to the offline page',async()=>{
 const sw=service();assert.equal(await sw.fetch('./?view=receive','navigate'),'fresh network');sw.offline();assert.equal(await sw.fetch('./?view=receive','navigate'),'cached page');
});
test('asset revisions never match a cached asset from a different build',async()=>{
 const sw=service();assert.equal(await sw.fetch('assets/app.js?v=current'),'current script');assert.equal(await sw.fetch('assets/app.js?v=new'),'fresh network');
});
