"""Reproduce a real v1 cached receiver scanning a v2 QR; verify safe cache migration."""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import subprocess,threading,json,base64,os
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright,expect

ROOT=Path(__file__).resolve().parents[3];SITE=ROOT/'toolbox-site';REPO=ROOT/'_scratch/masaka5-toolbox-upstream'
FILES=['index.html','sw.js','assets/app.js','assets/app.css','assets/worker.js']
old={'/tools/qr-transfer/'+name:subprocess.check_output(['git','show','f9b2887b:tools/qr-transfer/'+name],cwd=REPO)for name in FILES}
legacy=True
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(SITE),**kwargs)
 def log_message(self,*args):pass
 def do_GET(self):
  path=urlsplit(self.path).path
  if path=='/tools/qr-transfer/':path+='index.html'
  if legacy and path in old:
   data=old[path];self.send_response(200);self.send_header('Content-Type',self.guess_type(path));self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-cache');self.end_headers();self.wfile.write(data)
  else:super().do_GET()
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();url=f'http://127.0.0.1:{server.server_port}/tools/qr-transfer/'
try:
 with sync_playwright()as p:
  browser=p.chromium.launch();oldctx=browser.new_context();receiver=oldctx.new_page();receiver.goto(url+'?view=receive');expect(receiver.get_by_text('离线可用',exact=True)).to_be_visible(timeout=20000)
  receiver.evaluate("localStorage.setItem('upgrade-preserve','keep')")
  legacy=False
  senderctx=browser.new_context();sender=senderctx.new_page();sender.goto(url);expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=20000)
  raw=os.urandom(9000)
  sender.get_by_role('button',name='传输设置').click();sender.get_by_role('slider',name='刷新速度',exact=True).press('Home');sender.locator('.ant-drawer-close').click()
  sender.locator('input[type=file]').first.set_input_files({'name':'upgrade.txt','mimeType':'text/plain','buffer':raw});sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.locator('.qr-display canvas')).to_be_visible(timeout=15000);sender.get_by_role('button',name='暂停播放').click()
  image=base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]"))
  sources=int(sender.locator('.frame-number').inner_text().split(' / ')[1])//2;images=[image]
  for _ in range(sources-1):sender.get_by_role('button',name='下一帧').click();sender.wait_for_timeout(120);images.append(base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]")))
  receiver.locator('input[type=file]').last.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':image});expect(receiver.get_by_text('数据帧过长',exact=True)).to_be_visible(timeout=10000)
  receiver.goto(url+'update.html?view=receive');expect(receiver.get_by_role('button',name='开始接收')).to_be_enabled(timeout=30000);expect(receiver.get_by_text('总大小 ≤ 5 GB · 自动合并编码',exact=True)).to_be_visible(timeout=15000)
  assert receiver.evaluate("localStorage.getItem('upgrade-preserve')")=='keep'
  receiver.locator('input[type=file]').last.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':image})
  expect(receiver.locator('.receive-progress')).to_contain_text(f'1 / {sources} 片')
  receiver.evaluate("""async()=>{const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('pocket-qr-transfer-v1',1);r.onsuccess=()=>resolve(r.result);r.onerror=reject;});await new Promise((resolve,reject)=>{const tx=db.transaction('frames','readwrite');tx.objectStore('frames').put(new Uint8Array([7,8,9]),123);tx.oncomplete=resolve;tx.onerror=reject;});db.close();}""")
  receiver.goto(url+'update.html?view=receive');expect(receiver.locator('.receive-progress')).to_contain_text(f'1 / {sources} 片',timeout=20000)
  assert receiver.evaluate("""async()=>{const db=await new Promise(resolve=>{const r=indexedDB.open('pocket-qr-transfer-v1',1);r.onsuccess=()=>resolve(r.result);});const bytes=await new Promise(resolve=>{const r=db.transaction('frames').objectStore('frames').get(123);r.onsuccess=()=>resolve(r.result);});db.close();return [...bytes];}""")==[7,8,9]
  for image in images[1:]:receiver.locator('input[type=file]').last.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':image});receiver.wait_for_timeout(150)
  expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000)
  oldctx.set_offline(True);receiver.reload();expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=20000)
  browser.close();print(json.dumps({'reproducedLegacyFrameTooLong':True,'upgradedWithoutClearingUserStorage':True,'v1DataPreserved':True,'v2ProgressPreserved':True,'v40Accepted':True,'offlineReload':True}))
finally:server.shutdown();server.server_close()
