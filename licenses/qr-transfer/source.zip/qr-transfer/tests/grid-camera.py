"""Continuous 4-code video through getUserMedia, with missed and duplicate frames."""
from pathlib import Path
from io import BytesIO
import os,json,base64,time,hashlib
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-fountain-tests';OUT.mkdir(exist_ok=True)
URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/';raw=os.urandom(80000)
with sync_playwright()as p:
 browser=p.chromium.launch();sender=browser.new_page(viewport={'width':1920,'height':1080});sender.goto(URL);sender.locator('input[type=file]').first.set_input_files({'name':'多码视频.bin','mimeType':'application/octet-stream','buffer':raw})
 sender.get_by_role('button',name='传输设置').click();sender.get_by_label('编码模式',exact=True).first.click();sender.locator('.ant-select-item-option[title="黑白 · 稳定兼容"]').click();sender.get_by_label('并行码数',exact=True).first.click();sender.locator('.ant-select-item-option[title="4 码"]').click();sender.get_by_role('slider',name='刷新速度',exact=True).press('Home');sender.locator('.ant-drawer-close').click();sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.locator('.qr-display canvas')).to_be_visible(timeout=20000);sender.get_by_role('button',name='暂停播放').click();total=int(sender.locator('.frame-number').inner_text().split(' / ')[1]);images=[]
 for i in range(total):
  sender.wait_for_timeout(60);images.append(base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]")));sender.get_by_role('button',name='下一帧').click()
 video=OUT/'grid-camera.y4m'
 with video.open('wb')as f:
  f.write(b'YUV4MPEG2 W1080 H1080 F30:1 Ip A1:1 C420jpeg\n')
  # Omit first systematic frame entirely; hold other frames for 100 ms, then
  # repeat repair frames so missing originals recover from independent equations.
  order=list(range(1,total))+list(range(total//2,total))*3
  for i in order:
   image=Image.open(BytesIO(images[i])).convert('RGB').resize((1040,1040),Image.Resampling.NEAREST);surface=Image.new('RGB',(1080,1080),'white');surface.paste(image,(20,20));yuv=np.asarray(surface.convert('YCbCr'));y=yuv[:,:,0].tobytes();u=yuv[:,:,1].reshape(540,2,540,2).mean(axis=(1,3)).astype('uint8').tobytes();v=yuv[:,:,2].reshape(540,2,540,2).mean(axis=(1,3)).astype('uint8').tobytes()
   for _ in range(3):f.write(b'FRAME\n'+y+u+v)
 camera=p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--use-file-for-fake-video-capture='+str(video)]);ctx=camera.new_context(permissions=['camera'],accept_downloads=True);receiver=ctx.new_page();errors=[];receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive');start=time.monotonic();receiver.get_by_role('button',name='开始接收').click();expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=60000);elapsed=time.monotonic()-start
 # Confirm the optimized worker actually ran; a working fallback cannot mask
 # a broken Decimen module in this test.
 assert receiver.evaluate("performance.getEntriesByType('resource').some(r=>r.name.includes('decode-worker.js'))")
 receiver.get_by_role('button').filter(has_text='查看 1 个文件').click()
 with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 多码视频.bin').click()
 event.value.save_as(OUT/'grid-received.bin');assert(OUT/'grid-received.bin').read_bytes()==raw
 assert not errors,errors;camera.close();browser.close();print(json.dumps({'codesPerFrame':4,'videoFps':10,'omittedSystematicFrame':True,'duplicates':True,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'elapsedSeconds':round(elapsed,2),'measuredKiBps':round(len(raw)/elapsed/1024,2),'pageErrors':errors}))
