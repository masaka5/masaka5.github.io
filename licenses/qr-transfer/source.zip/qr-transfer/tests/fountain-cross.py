from pathlib import Path
import json,os,base64
from playwright.sync_api import sync_playwright,expect
URL=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765')+'/tools/qr-transfer/'
with sync_playwright()as p:
 b=p.chromium.launch();sender=b.new_page();sender.goto(URL);sender.locator('input[type=file]').first.set_input_files({'name':'互通.txt','mimeType':'text/plain','buffer':b'cross engine '+bytes(range(256))*40});sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.locator('.qr-display canvas')).to_be_visible(timeout=20000);sender.get_by_role('button',name='暂停播放').click();total=int(sender.locator('.frame-number').inner_text().split(' / ')[1].replace(',',''));images=[]
 for _ in range(total//2):
  sender.wait_for_timeout(80);images.append(base64.b64decode(sender.locator('.qr-display canvas').evaluate("c=>c.toDataURL().split(',')[1]")));sender.get_by_role('button',name='下一帧').click()
 results=[]
 for name,engine,options in[('firefox',p.firefox,{}),('edge',p.chromium,{'channel':'msedge'})]:
  browser=engine.launch(**options);page=browser.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(URL+'?view=receive');expect(page.get_by_role('button',name='开始接收')).to_be_enabled()
  for image in images:page.locator('input[type=file]').last.set_input_files({'name':'qr.png','mimeType':'image/png','buffer':image});page.wait_for_timeout(300)
  expect(page.get_by_text('接收完成',exact=True)).to_be_visible(timeout=20000);assert not errors,errors;assert page.evaluate('document.documentElement.scrollHeight<=innerHeight&&document.documentElement.scrollWidth<=innerWidth');results.append({'engine':name,'binaryQR':True,'OPFSAndWasmRestore':True});browser.close()
 b.close();print(json.dumps({'crossBrowser':results}))
