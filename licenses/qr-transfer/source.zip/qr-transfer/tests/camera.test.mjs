import test from 'node:test';import assert from 'node:assert/strict';import {camera} from '../src/camera.mjs';
test('cancel during decoder loading skips permission; failed video playback releases tracks',async()=>{
 let release,requests=0,stopped=0;globalThis.document={createElement:()=>({getContext:()=>({})})};globalThis.isSecureContext=true;
 globalThis.ZXingWASM={prepareZXingModule:()=>new Promise(resolve=>{release=resolve;})};
 Object.defineProperty(globalThis,'navigator',{configurable:true,value:{mediaDevices:{getUserMedia:async()=>{requests++;return{getTracks:()=>[{stop(){stopped++;}}]};}}}});
 const video={srcObject:null,play:async()=>{throw Error('play blocked');}};const controller=camera(video,()=>{},()=>{});
 const pending=controller.start();controller.stop();release();await pending;assert.equal(requests,0);
 await assert.rejects(controller.start(),/play blocked/);assert.equal(requests,1);assert.equal(stopped,1);assert.equal(video.srcObject,null);
});
