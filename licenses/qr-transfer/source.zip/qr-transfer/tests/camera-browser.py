from pathlib import Path
from io import BytesIO
import json,os,hashlib
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/qr-transfer-tests';OUT.mkdir(exist_ok=True)
BASE=os.environ.get('QR_TEST_ORIGIN','http://127.0.0.1:8765');URL=BASE+'/tools/qr-transfer/'
raw=os.urandom(3500)
with sync_playwright()as p:
 b=p.chromium.launch();sender=b.new_page(viewport={'width':1100,'height':900},locale='zh-CN');sender.goto(URL)
 expect(sender.get_by_text('离线可用',exact=True)).to_be_visible(timeout=20000)
 sender.locator('input[type=file]').first.set_input_files([{'name':'加密.bin','mimeType':'application/octet-stream','buffer':raw},{'name':'空文件.txt','mimeType':'text/plain','buffer':b''}])
 sender.get_by_role('button',name='传输设置',exact=True).click();sender.get_by_role('switch',name='密码加密',exact=True).click();sender.get_by_label('加密密码',exact=True).fill('测试口令-123')
 sender.locator('.ant-drawer-close').click();expect(sender.get_by_role('dialog')).not_to_be_visible()
 sender.get_by_role('button',name='生成二维码',exact=True).click();expect(sender.get_by_role('button',name='暂停播放',exact=True)).to_be_visible(timeout=15000)
 sender.get_by_role('button',name='暂停播放',exact=True).click()
 first=sender.evaluate('''async()=>{const c=document.querySelector('.qr-display canvas');ZXingWASM.prepareZXingModule({overrides:{locateFile:p=>new URL('../../vendor/zxing/'+p,location.href).href}});return(await ZXingWASM.readBarcodes(c.getContext('2d').getImageData(0,0,c.width,c.height),{formats:['QRCode'],tryHarder:true}))[0].text;}''')
 count=int(first.split('|')[3]);assert count>5
 image_bytes=[]
 for i in range(count):image_bytes.append(sender.locator('.qr-display canvas').screenshot());sender.get_by_role('button',name='下一帧',exact=True).click()
 # Feed generated QR images through Chromium's actual getUserMedia video path.
 video=OUT/'dynamic-camera.y4m'
 with video.open('wb')as f:
  f.write(b'YUV4MPEG2 W640 H640 F10:1 Ip A1:1 C420jpeg\n')
  for data in image_bytes:
   image=Image.open(BytesIO(data)).convert('RGB').resize((512,512),Image.Resampling.NEAREST);surface=Image.new('RGB',(640,640),'white');surface.paste(image,(64,64));yuv=np.asarray(surface.convert('YCbCr'))
   y=yuv[:,:,0].tobytes();u=yuv[:,:,1].reshape(320,2,320,2).mean(axis=(1,3)).astype('uint8').tobytes();v=yuv[:,:,2].reshape(320,2,320,2).mean(axis=(1,3)).astype('uint8').tobytes()
   for _ in range(5):f.write(b'FRAME\n'+y+u+v)
 camera=p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--use-file-for-fake-video-capture='+str(video)])
 ctx=camera.new_context(viewport={'width':390,'height':844},permissions=['camera'],locale='zh-CN',accept_downloads=True)
 receiver=ctx.new_page();errors=[];receiver.on('pageerror',lambda e:errors.append(str(e)));receiver.goto(URL+'?view=receive')
 expect(receiver.get_by_role('button',name='开始接收',exact=True)).to_be_enabled(timeout=10000)
 receiver.get_by_role('button',name='开始接收',exact=True).click()
 expect(receiver.get_by_role('button',name='停止扫描',exact=True)).to_be_visible(timeout=10000)
 expect(receiver.get_by_text('等待解密',exact=True)).to_be_visible(timeout=45000)
 assert receiver.locator('video').evaluate('v=>v.srcObject===null'),'camera tracks were not released on completion'
 receiver.get_by_label('解密密码',exact=True).fill('错误密码');receiver.get_by_role('button').filter(has_text='解密').click()
 expect(receiver.get_by_text('密码错误或加密数据损坏',exact=True)).to_be_visible()
 receiver.get_by_label('解密密码',exact=True).fill('测试口令-123');receiver.get_by_role('button').filter(has_text='解密').click()
 expect(receiver.get_by_text('接收完成',exact=True)).to_be_visible(timeout=15000)
 receiver.get_by_role('button').filter(has_text='查看 2 个文件').click()
 with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 加密.bin',exact=True).click()
 event.value.save_as(OUT/'encrypted-received.bin');assert(OUT/'encrypted-received.bin').read_bytes()==raw
 with receiver.expect_download()as event:receiver.get_by_role('button',name='下载 空文件.txt',exact=True).click()
 event.value.save_as(OUT/'empty-received.txt');assert(OUT/'empty-received.txt').stat().st_size==0
 receiver.locator('.ant-drawer-close').click();expect(receiver.get_by_role('dialog')).not_to_be_visible()
 receiver.get_by_role('button',name='清除接收进度',exact=True).click();receiver.get_by_role('button',name='清 除',exact=True).click()
 expect(receiver.locator('.receive-progress')).to_contain_text('0 / 0 帧')
 receiver.reload();expect(receiver.locator('.receive-progress')).to_contain_text('0 / 0 帧')
 assert not errors,errors
 camera.close();b.close()
 print(json.dumps({'cameraFrames':count,'actualGetUserMediaVideo':True,'encryptedMultiFile':True,'wrongPasswordRetry':True,'emptyFile':True,'cameraTracksStopped':True,'clearPersisted':True,'sha256':hashlib.sha256(raw).hexdigest(),'pageErrors':errors}))
