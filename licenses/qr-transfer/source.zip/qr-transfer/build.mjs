import {build} from 'esbuild';import path from 'node:path';import {fileURLToPath} from 'node:url';import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url)),output=path.resolve(process.env.QR_OUTPUT||path.join(root,'dist')),modules=path.join(root,'node_modules');
await mkdir(path.join(output,'assets'),{recursive:true});
const settings={bundle:true,minify:true,legalComments:'eof',target:['es2022'],format:'esm',define:{'process.env.NODE_ENV':'"production"'},metafile:true};
const main=await build({...settings,entryPoints:[path.join(root,'src/main.jsx')],outfile:path.join(output,'assets/app.js')});
const worker=await build({...settings,entryPoints:[path.join(root,'src/fountain-worker.mjs')],outfile:path.join(output,'assets/worker.js')});
await copyFile(path.join(modules,'@bokuweb/zstd-wasm/dist/esm/zstd.wasm'),path.join(output,'assets/zstd.wasm'));
await copyFile(path.join(root,'index.html'),path.join(output,'index.html'));
const version=createHash('sha256');for(const name of ['app.js','app.css','worker.js','zstd.wasm'])version.update(await readFile(path.join(output,'assets',name)));
await writeFile(path.join(output,'sw.js'),(await readFile(path.join(root,'sw.js'),'utf8')).replace('__BUILD__',version.digest('hex').slice(0,16)));
const files=[];for(const file of ['index.html','sw.js','assets/app.js','assets/app.css','assets/worker.js','assets/zstd.wasm']){const data=await readFile(path.join(output,file));files.push({file,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});}
await writeFile(path.join(output,'manifest.json'),JSON.stringify({name:'动态二维码传输',version:'2.0.0',protocol:'PQF2 / PFR2 / PQS2',encoding:'systematic GF(2) fountain, 128 shards/generation',defaultPayloadBytes:2916,files},null,2)+'\n');
const noticeDir=path.join(root,'notices');await mkdir(noticeDir,{recursive:true});const packages=new Map();
for(const input of [...Object.keys(main.metafile.inputs),...Object.keys(worker.metafile.inputs)]){
 const match=input.replaceAll('\\','/').match(/node_modules\/((?:@[^/]+\/)?[^/]+)/);if(!match||packages.has(match[1]))continue;
 const name=match[1],dir=path.join(modules,name),pkg=JSON.parse(await readFile(path.join(dir,'package.json'),'utf8'));let text='';
 for(const file of(await readdir(dir)).filter(n=>/^(licen[sc]e|copying|notice)([.\-_]|$)/i.test(n)))try{text+='\n'+await readFile(path.join(dir,file),'utf8');}catch{}
 if(!text){try{text=await readFile(path.join(noticeDir,name.replaceAll('/','_')+'.txt'),'utf8');}catch{text=await readFile(path.resolve(root,'../home-react-integration/notices',name.replaceAll('/','_')+'.txt'),'utf8');await writeFile(path.join(noticeDir,name.replaceAll('/','_')+'.txt'),text);}}
 if(!text.trim())throw Error('Missing license: '+name);packages.set(name,{name,version:pkg.version,license:pkg.license,text});
}
const licenseDir=process.env.QR_OUTPUT?path.resolve(output,'../../licenses/qr-transfer'):path.join(output,'licenses');await mkdir(licenseDir,{recursive:true});
await writeFile(path.join(licenseDir,'THIRD-PARTY-NOTICES.txt'),[...packages.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(p=>`===== ${p.name}@${p.version} (${p.license}) =====\n${p.text}`).join('\n\n')+'\n\n'+await readFile(path.join(noticeDir,'zstd-BSD.txt'),'utf8'));
await writeFile(path.join(licenseDir,'dependencies.json'),JSON.stringify([...packages.values()].map(({text,...p})=>p),null,2)+'\n');
console.log(JSON.stringify({output,totalBytes:files.reduce((n,f)=>n+f.bytes,0),files}));
