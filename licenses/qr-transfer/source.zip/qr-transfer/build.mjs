import {build} from 'esbuild';import path from 'node:path';import {fileURLToPath} from 'node:url';import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';import {createHash} from 'node:crypto';import {gzipSync} from 'node:zlib';
const root=path.dirname(fileURLToPath(import.meta.url)),output=path.resolve(process.env.QR_OUTPUT||path.join(root,'dist')),modules=path.join(root,'node_modules');
await mkdir(path.join(output,'assets'),{recursive:true});
const sourceHash=createHash('sha256');for(const file of ['build.mjs','index.html','update.html','sw.js','package-lock.json',...(await readdir(path.join(root,'src'))).sort().map(name=>'src/'+name)])sourceHash.update(await readFile(path.join(root,file)));
for(const file of(await readdir(path.join(root,'vendor/decimen'),{recursive:true})).sort())try{sourceHash.update(await readFile(path.join(root,'vendor/decimen',file)));}catch(error){if(error.code!=='EISDIR'&&error.code!=='EPERM')throw error;}
const revision=sourceHash.digest('hex').slice(0,16);
const settings={bundle:true,minify:true,legalComments:'eof',target:['es2022'],format:'esm',define:{'process.env.NODE_ENV':'"production"','__QR_REVISION__':JSON.stringify(revision)},metafile:true};
const main=await build({...settings,entryPoints:[path.join(root,'src/main.jsx')],outfile:path.join(output,'assets/app.js')});
const worker=await build({...settings,entryPoints:[path.join(root,'src/fountain-worker.mjs')],outfile:path.join(output,'assets/worker.js')});
const scanner=await build({...settings,entryPoints:[path.join(root,'src/decode-worker.mjs')],outfile:path.join(output,'assets/decode-worker.js'),external:['node:*']});
await writeFile(path.join(output,'assets/decimen.wasm.gz'),gzipSync(await readFile(path.join(root,'vendor/decimen/codec/decimen_codec.wasm')),{level:9}));
await copyFile(path.join(modules,'@bokuweb/zstd-wasm/dist/esm/zstd.wasm'),path.join(output,'assets/zstd.wasm'));
await build({...settings,entryPoints:[path.join(root,'src/update.mjs')],outfile:path.join(output,'assets/update.js')});
for(const name of ['index.html','update.html'])await writeFile(path.join(output,name),(await readFile(path.join(root,name),'utf8')).replaceAll('__REVISION__',revision));
const version=createHash('sha256');for(const name of ['app.js','app.css','worker.js','zstd.wasm','decode-worker.js','decimen.wasm.gz'])version.update(await readFile(path.join(output,'assets',name)));
await writeFile(path.join(output,'sw.js'),(await readFile(path.join(root,'sw.js'),'utf8')).replace('__BUILD__',version.digest('hex').slice(0,16)).replaceAll('__REVISION__',revision));
const files=[];for(const file of ['index.html','update.html','sw.js','assets/update.js','assets/app.js','assets/app.css','assets/worker.js','assets/zstd.wasm','assets/decode-worker.js','assets/decimen.wasm.gz']){const data=await readFile(path.join(output,file));files.push({file,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});}
await writeFile(path.join(output,'manifest.json'),JSON.stringify({name:'动态二维码传输',version:'2.2.0',revision,protocol:'PQF2 (RGB flag) / PFR2 / PQS2',encoding:'RGB three-plane multi-QR + Decimen tracked WASM + systematic GF(2) fountain',defaultPayloadBytes:2916,defaultMode:'color',files},null,2)+'\n');
const noticeDir=path.join(root,'notices');await mkdir(noticeDir,{recursive:true});const packages=new Map();
for(const input of [...Object.keys(main.metafile.inputs),...Object.keys(worker.metafile.inputs),...Object.keys(scanner.metafile.inputs)]){
 const match=input.replaceAll('\\','/').match(/node_modules\/((?:@[^/]+\/)?[^/]+)/);if(!match||packages.has(match[1]))continue;
 const name=match[1],dir=path.join(modules,name),pkg=JSON.parse(await readFile(path.join(dir,'package.json'),'utf8'));let text='';
 for(const file of(await readdir(dir)).filter(n=>/^(licen[sc]e|copying|notice)([.\-_]|$)/i.test(n)))try{text+='\n'+await readFile(path.join(dir,file),'utf8');}catch{}
 if(!text){try{text=await readFile(path.join(noticeDir,name.replaceAll('/','_')+'.txt'),'utf8');}catch{text=await readFile(path.resolve(root,'../home-react-integration/notices',name.replaceAll('/','_')+'.txt'),'utf8');await writeFile(path.join(noticeDir,name.replaceAll('/','_')+'.txt'),text);}}
 if(!text.trim())throw Error('Missing license: '+name);packages.set(name,{name,version:pkg.version,license:pkg.license,text});
}
const licenseDir=process.env.QR_OUTPUT?path.resolve(output,'../../licenses/qr-transfer'):path.join(output,'licenses');await mkdir(licenseDir,{recursive:true});
await copyFile(path.join(root,'vendor/decimen/LICENSE'),path.join(licenseDir,'DECIMEN-LICENSE.txt'));
await writeFile(path.join(licenseDir,'DECIMEN-NOTICE.txt'),await readFile(path.join(root,'vendor/decimen/NOTICE'),'utf8')+'\n'+await readFile(path.join(root,'vendor/decimen/codec/NOTICE.md'),'utf8'));
await writeFile(path.join(licenseDir,'THIRD-PARTY-NOTICES.txt'),[...packages.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(p=>`===== ${p.name}@${p.version} (${p.license}) =====\n${p.text}`).join('\n\n')+'\n\n'+await readFile(path.join(noticeDir,'zstd-BSD.txt'),'utf8'));
await writeFile(path.join(licenseDir,'dependencies.json'),JSON.stringify([...packages.values()].map(({text,...p})=>p),null,2)+'\n');
console.log(JSON.stringify({output,totalBytes:files.reduce((n,f)=>n+f.bytes,0),files}));
