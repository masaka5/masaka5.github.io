# 动态二维码传输

2.1 使用 Decimen Optical 的多码栅格与跟踪 WASM 解码，默认按屏幕面积选择
1/2/4/6/9 码，20 帧/秒，可设置 1–60 帧。QR 编码在 worker 批量完成，固定
掩码 4、最多预取两画面；接收最多两个 worker、每个仅一帧在途，过载丢旧帧，
每 12 帧或跟踪失败重新定位。解码组件异常时回退到原 ZXing，不关闭摄像头。
每码独立校验和喷泉恢复，批量入库严格等待落盘；速率只计算独立编码的增量。
V40-M 模式有效载荷 2294 B，包含 37 B 头后总计 2331 B。
本工具与原版 Decimen DT 协议不互通；未使用 PrismFlow。
源码及授权见 vendor/decimen/SOURCE.md，应用按 AGPL-3.0-or-later 提供。
`tests/grid-browser.py` 直接测试生产 Decimen worker 的 1/2/4/6/9 码及跟踪路径、
M 纠错、离线重启；`grid-camera.py` 通过 getUserMedia 输入有漏帧的连续四码视频。

`npm ci && npm test && npm run build`。生产可设置 `QR_OUTPUT`。
静态站点运行，不需要信令、文件服务器、API 或互联网数据通道。
首次打开后，确认“离线可用”，两台设备即可断网重新打开该页面传输。
摄像头使用浏览器 getUserMedia，因此需要 HTTPS 或 localhost。

默认使用分代系统随机线性喷泉码（GF(2)），无需切换。每代最多 128 个源片，
第一轮发送原始片及随机 XOR 方程，后续轮次持续生成新方程。接收端按独立
方程的秩计进度，重复和相关编码不虚增进度，不必等待某个指定丢失帧。
补发二维码请求未完成的代，发送端为其产生新的冗余编码。

默认最高密度 QR Version 40-L，Byte 模式 2953 B，其中 PQF2 头 37 B、
有效载荷 2916 B；保留 4 模块静区。可降低为 1200/600 B 便于手机扫描。
编码使用 Nayuki/rc-component，ZXing-C++ WASM 读取原始字节而非 UTF-8 文本。
协议 PQF2（喷泉编码）、PFR2（补发请求）、PQS2（流式封装）。旧 v1 实现
及单测仅保留在源码，运行时不兼容旧协议；两端需刷新加载同一版本。

单次最多 20 个文件，总原始大小 5 GiB（界面写 5 GB），恰好上限可接受。
按 1 MiB 读取，Zstandard WASM 压缩，hash-wasm SHA256 增量校验，
WebCrypto AES-256-GCM 按记录加密（PBKDF2-SHA256 250000 次、随机盐/IV）。
元信息、记录头及索引均纳入 GCM AAD；每码 CRC32、每块及完整文件 SHA256。
未启用密码时完整性校验不提供身份认证。

发送包、已解码数据和恢复文件在 OPFS 暂存，独立编码在 IndexedDB 保存，
仅两代解码矩阵驻留内存。支持超过 4 GiB 的偏移，先检查可用存储配额。
刷新后可续收，密码不保存；恢复后的文件仍在浏览器暂存，清除接收进度时
删除该次接收编码及恢复文件。请在可信设备操作，下载后清除暂存。
浏览器需支持 OPFS 同步访问并有足够可用配额；大文件使用普通模式，部分
浏览器无痕模式存在单文件限制。导出前检查实际暂存大小，截短文件拒绝导出。
摄像头权限需 HTTPS。
最高密度要求清晰对焦，大文件光学传输可能耗时数天，通常更适合文件直传。
发送轮次不表示接收成功，接收端完成 SHA256 校验后才能导出。

验证脚本：`tests/fountain-browser.py`（实际二进制 QR、漏原始片、补发、刷新、
14 尺寸布局、离线）；`fountain-camera.py`（getUserMedia 视频扫描、密码、
多文件）；`fountain-cross.py`（Firefox/Edge）；`fountain-large.py`（实际
5 GiB 高压缩率文件的流式准备与恢复，抽验 QR，其余通过 worker 传码，
不是 5 GiB 全量光学扫码测试）。旧 browser/camera-browser/repair-browser/
cross-browser 脚本对应 v1，不适用于当前页面。

2.0.1 修复：v1 缓存的接收器用旧版 1400 字符限制处理新版二进制码，
会报“数据帧过长”。页面导航改为联网优先、离线回退；应用/CSS/worker
使用内容版本参数，缓存严格按完整 URL 匹配，防止不同版本混用。
`update.html?view=receive` 可从旧缓存直接更新接收器，只更新组件缓存，
不清除 IndexedDB、OPFS 或用户设置，不强制刷新其他正在传输的页面。
`tests/cache-upgrade.py` 从 Git 历史 f9b2887b 的实际 v1 产物复现报错，验证
升级、旧库保存、新版部分接收进度保留及离线续收；需原仓库历史。
