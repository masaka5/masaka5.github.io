# 动态二维码传输

`npm ci && npm test && npm run build`。生产可设置 `QR_OUTPUT`。
静态站点运行，不需要信令、文件服务器、API 或互联网数据通道。
首次打开后，确认“离线可用”，两台设备即可断网重新打开该页面传输。
摄像头使用浏览器 getUserMedia，因此需要 HTTPS 或 localhost。

WASM：Zstandard 压缩（@bokuweb/zstd-wasm 0.0.27）运行在 worker；
ZXing-C++ WASM 使用工具箱已有 /vendor/zxing 文件。二维码编码使用
Ant Design 的 QRCode（Nayuki/rc-component）。加密使用 WebCrypto
AES-256-GCM，PBKDF2-SHA256 250000 次，随机 16 字节 salt / 12 字节 IV。

循环分片和手动补帧参考 qrloop（https://github.com/gre/qrloop）与
txqr（https://github.com/divan/txqr）的设计，未复制其代码，不与其协议互通。
协议为本项目 PQT1（帧）、PQR1（补帧请求）、PQE1（压缩加密包）、PQP1
（多文件封装）。每帧 CRC32、整个包 SHA256、每个原始文件 SHA256。
未启用密码时校验不提供身份认证；有密码时 AES-GCM 校验元数据与文件内容。

单次最多 20 个文件、总原始大小 16 MiB。发送动画仅表示本轮播放，不表示
接收端已收到，接收端显示实际唯一帧进度。扫码很慢，大文件适合文件直传。
接收帧保存在此浏览器 IndexedDB，可刷新补收。未加密帧可能含原始内容；
用后点击“清除接收进度”。密码和解密结果仅在内存中，离开页面不保存。
客户端“保存文件”从浏览器下载，不执行接收到的 HTML/脚本，不直接打开文档。
Zstd 帧长度和窗口在 WASM 分配前检查，解包限长且不使用文件系统路径。
