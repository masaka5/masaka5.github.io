"""Package editable sources and update only the relevant integration records."""
from pathlib import Path
import zipfile,hashlib,json,os,io,tarfile,lzma
ROOT=Path(__file__).resolve().parents[2];PROJECT=Path(__file__).resolve().parent;SITE=ROOT/'toolbox-site'
sha=lambda data:hashlib.sha256(data).hexdigest()
license_dir=SITE/'licenses/qr-transfer';license_dir.mkdir(exist_ok=True)
archive=license_dir/'source.zip';rows=[]
# Preserve the complete decoder build inputs without vendoring unrelated tests,
# images or Git metadata. All reader sources and pinned build scripts are included.
engine=ROOT/'_scratch/decimen-codec-reference';buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as tar:
 inputs=[p for folder in ['wrapper','third_party/zxing-cpp/core','third_party/zxing-cpp/cmake']for p in(engine/folder).rglob('*')if p.is_file()]
 inputs +=[engine/name for name in ['CMakeLists.txt','build.sh','package.json','LICENSE','.gitmodules','third_party/zxing-cpp/CMakeLists.txt','third_party/zxing-cpp/LICENSE','third_party/zxing-cpp/NOTICE']if(engine/name).is_file()]
 for path in sorted(set(inputs)):tar.add(path,arcname='decimen-codec/'+path.relative_to(engine).as_posix(),recursive=False)
(license_dir/'decimen-build-source.tar.xz').write_bytes(lzma.compress(buffer.getvalue(),preset=9))
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for path in sorted(PROJECT.rglob('*')):
  rel=path.relative_to(PROJECT)
  if not path.is_file()or path.suffix=='.wasm'or any(part in {'dist','node_modules','__pycache__','.local'}for part in rel.parts):continue
  name='qr-transfer/'+rel.as_posix();data=path.read_bytes();z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
 for name in ['THIRD-PARTY-NOTICES.txt','dependencies.json','DECIMEN-LICENSE.txt','DECIMEN-NOTICE.txt']:
  data=(license_dir/name).read_bytes();rel='qr-transfer/notices/'+name;z.writestr(rel,data);rows.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
(license_dir/'source-manifest.json').write_text(json.dumps({'sourceArchive':'source.zip','license':'AGPL-3.0-or-later','compression':'@bokuweb/zstd-wasm@0.0.27','hash':'hash-wasm@4.12.0','scanner':'decimen-codec 0.2.0 / dc2b8c5; shared ZXing fallback','upstream':'https://github.com/bearea/decimen-optical/tree/5301fc2020716b5a97d4edf6e1793c3dedbf6e17','decoderBuildSource':{'path':'decimen-build-source.tar.xz','sha256':sha((license_dir/'decimen-build-source.tar.xz').read_bytes())},'protocol':'PQF2/PFR2/PQS2','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'files':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
changed=['_scratch/build-toolbox-icons.cjs','_scratch/tool-icon-rules.cjs','_scratch/toolbox-taxonomy.cjs','_scratch/build-toolbox-seo.cjs','toolbox-site/assets/catalog.js','toolbox-site/assets/catalog-base.js','toolbox-site/assets/tool-icon-paths.js','toolbox-site/index.html','toolbox-site/sitemap.xml','toolbox-cloud/src/tool-ids.json']
target=SITE/'licenses/integration-source.zip';temp=target.with_suffix('.qr-transfer.zip')
with zipfile.ZipFile(target)as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_LZMA)as z:
 for info in old.infolist():
  if info.filename not in changed:z.writestr(info,old.read(info.filename),compress_type=zipfile.ZIP_LZMA)
 for name in changed:z.write(ROOT/name,name)
os.replace(temp,target)
print(json.dumps({'qrSourceFiles':len(rows),'qrSourceBytes':archive.stat().st_size,'catalogSourceUpdated':len(changed)}))
