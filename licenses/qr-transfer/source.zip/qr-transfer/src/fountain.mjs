export const MAX_FILE=5*1024**3,MAX_WIRE=MAX_FILE+16*1024**2,HEADER=37,MAX_SHARD=2916,GENERATION=128;
const magic=[80,81,70,50],table=new Uint32Array(256).map((_,n)=>{let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc(bytes){let c=0xffffffff;for(let i=0;i<bytes.length;i++)if(i<33||i>=37)c=table[(c^bytes[i])&255]^(c>>>8);return(c^0xffffffff)>>>0;}
const integer=(n,min,max)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
export function validateFiles(files){if(!Array.isArray(files)||!files.length||files.length>20)throw Error('最多添加 20 个文件');let total=0;for(const f of files){if(!integer(f.size,0,MAX_FILE))throw Error('文件总大小不能超过 5 GB');total+=f.size;}if(total>MAX_FILE)throw Error('文件总大小不能超过 5 GB');return total;}
export function validate(meta){if(!meta||!/^[0-9a-f]{16}$/.test(meta.id)||!integer(meta.length,1,MAX_WIRE)||!integer(meta.size,300,MAX_SHARD))throw Error('传输参数无效');return meta;}
export const generations=meta=>Math.ceil(meta.length/(meta.size*GENERATION));
export function count(meta,generation){validate(meta);if(!integer(generation,0,generations(meta)-1))throw Error('数据代编号无效');return Math.min(GENERATION,Math.ceil((meta.length-generation*meta.size*GENERATION)/meta.size));}
export function encodePacket(meta,generation,seed,data,mode=meta.mode){
 const k=count(meta,generation);if(!integer(seed,0,0xffffffff)||!(data instanceof Uint8Array)||data.length!==meta.size)throw Error('编码片长度无效');
 const bytes=new Uint8Array(HEADER+data.length),view=new DataView(bytes.buffer);bytes.set(magic);for(let i=0;i<8;i++)bytes[4+i]=parseInt(meta.id.slice(i*2,i*2+2),16);
 view.setUint32(12,generation);view.setUint32(16,seed);view.setBigUint64(20,BigInt(meta.length));view.setUint16(28,meta.size);view.setUint16(30,k);bytes[32]=mode==='color'?1:0;bytes.set(data,HEADER);view.setUint32(33,crc(bytes));return bytes;
}
export function isPacket(bytes){return bytes instanceof Uint8Array&&magic.every((n,i)=>bytes[i]===n);}
export function decodePacket(bytes){
 if(!isPacket(bytes)||bytes.length<HEADER+300||bytes.length>2953)throw Error('不是本工具的喷泉码');const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),length=Number(view.getBigUint64(20)),size=view.getUint16(28),generation=view.getUint32(12),seed=view.getUint32(16),id=Array.from(bytes.subarray(4,12),n=>n.toString(16).padStart(2,'0')).join('');
 const meta={id,length,size};if(bytes[32]>1||bytes.length!==HEADER+size||view.getUint16(30)!==count(meta,generation))throw Error('喷泉码参数无效');if(crc(bytes)!==view.getUint32(33))throw Error('帧校验失败');return{...meta,mode:bytes[32]?'color':'mono',generation,seed,k:count(meta,generation),data:bytes.slice(HEADER)};
}
function random(seed,generation){let x=(seed^Math.imul(generation+1,0x9e3779b9))>>>0;return()=>{x=(x+0x6d2b79f5)>>>0;let t=x;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return(t^(t>>>14))>>>0;};}
export function coefficients(k,seed,generation){const bits=new Uint32Array(4);if(seed<k){bits[seed>>>5]=(1<<(seed&31))>>>0;return bits;}const next=random(seed,generation);for(let i=0;i<4;i++)bits[i]=next();for(let i=k;i<128;i++)bits[i>>>5]&=~(1<<(i&31));if(bits.every(n=>!n)){const index=next()%k;bits[index>>>5]|=1<<(index&31);}return bits;}
function has(bits,index){return!!(bits[index>>>5]&(1<<(index&31)));}
function xor(target,source){for(let i=0;i<target.length;i++)target[i]^=source[i];}
export function symbol(meta,source,generation,seed){const k=count(meta,generation),mask=coefficients(k,seed,generation),data=new Uint8Array(meta.size);for(let i=0;i<k;i++)if(has(mask,i)){const part=source.subarray(i*meta.size,(i+1)*meta.size);for(let j=0;j<part.length;j++)data[j]^=part[j];}return encodePacket(meta,generation,seed,data);}
export class Generation{
 constructor(k,size){if(!integer(k,1,128)||!integer(size,300,MAX_SHARD))throw Error('编码代参数无效');this.k=k;this.size=size;this.rows=new Map();}
 get rank(){return this.rows.size;}get complete(){return this.rank===this.k;}
 accept(seed,generation,payload){
  if(!(payload instanceof Uint8Array)||payload.length!==this.size)throw Error('编码片长度无效');const bits=coefficients(this.k,seed,generation),data=payload.slice();
  for(let i=0;i<this.k;i++)if(has(bits,i)&&this.rows.has(i)){const row=this.rows.get(i);xor(bits,row.bits);xor(data,row.data);}
  for(let i=0;i<this.k;i++)if(has(bits,i)){for(const row of this.rows.values())if(has(row.bits,i)){xor(row.bits,bits);xor(row.data,data);}this.rows.set(i,{bits,data});return true;}
  if(data.some(n=>n!==0))throw Error('编码数据冲突，请重新接收');return false;
 }
 bytes(){if(!this.complete)throw Error('本代编码片不足');const out=new Uint8Array(this.k*this.size);for(let i=0;i<this.k;i++)out.set(this.rows.get(i).data,i*this.size);return out;}
 snapshot(){return{k:this.k,size:this.size,rows:[...this.rows].map(([i,r])=>[i,r.bits.slice(),r.data.slice()])};}
 static restore(s){const g=new Generation(s.k,s.size);if(!Array.isArray(s.rows)||s.rows.length>s.k)throw Error('接收缓存无效');for(const[i,bits,data]of s.rows){if(!integer(i,0,s.k-1)||g.rows.has(i)||!(bits instanceof Uint32Array)||bits.length!==4||!(data instanceof Uint8Array)||data.length!==s.size||!has(bits,i))throw Error('接收缓存无效');g.rows.set(i,{bits:bits.slice(),data:data.slice()});}return g;}
}
export function position(meta,index,round=1){const sources=Math.ceil(meta.length/meta.size),total=sources*2;if(!integer(index,0,total-1)||!integer(round,1,0xffffffff))throw Error('发送位置无效');const generation=Math.min(generations(meta)-1,Math.floor(index/(GENERATION*2))),local=index-generation*GENERATION*2,k=count(meta,generation);const seed=round===1?local:(2*k+(round-2)*2*k+local)>>>0;return{generation,seed,total,k};}
export function request(meta,missing){const body=`PFR2|${meta.id}|${generations(meta)}|${missing.slice(0,96).join(',')}`;let c=0xffffffff;for(const ch of body)c=table[(c^ch.charCodeAt(0))&255]^(c>>>8);return body+'|'+((c^0xffffffff)>>>0).toString(16).padStart(8,'0');}
export function parseRepair(text,meta){if(typeof text!=='string'||text.length>1100)throw Error('补发码无效');const p=text.split('|');if(p.length!==5||p[0]!=='PFR2'||p[1]!==meta.id||p[2]!==String(generations(meta)))throw Error('补发码不属于当前传输');const missing=p[3].split(',').map(Number);if(!missing.length||missing.length>96||new Set(missing).size!==missing.length||missing.some(n=>!integer(n,0,generations(meta)-1))||request(meta,missing)!==text)throw Error('补发码校验失败');return missing;}
