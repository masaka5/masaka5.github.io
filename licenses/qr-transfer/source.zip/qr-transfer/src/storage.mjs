let opened;
function database(){
 if(!opened)opened=new Promise((resolve,reject)=>{
  const r=indexedDB.open('pocket-qr-transfer-v1',1);
  r.onupgradeneeded=()=>{r.result.createObjectStore('meta');r.result.createObjectStore('frames');};
  r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(Error('无法保存接收进度'));r.onblocked=()=>reject(Error('请关闭其他接收页面后重试'));
 });return opened;
}
export async function saveFrame(meta,index,bytes){
 const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction(['meta','frames'],'readwrite');tx.objectStore('meta').put(meta,'current');tx.objectStore('frames').put(bytes,index);tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(Error('接收进度保存失败，暂时不要刷新'));});
}
export async function loadFrames(){
 const db=await database();return new Promise((resolve,reject)=>{
  const tx=db.transaction(['meta','frames'],'readonly'),meta=tx.objectStore('meta').get('current'),keys=tx.objectStore('frames').getAllKeys(),values=tx.objectStore('frames').getAll();
  tx.oncomplete=()=>resolve({schema:1,meta:meta.result||null,parts:keys.result.map((k,i)=>[k,values.result[i]]),duplicates:0});tx.onerror=()=>reject(Error('无法读取接收进度'));
 });
}
export async function clearFrames(){const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction(['meta','frames'],'readwrite');tx.objectStore('meta').clear();tx.objectStore('frames').clear();tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(Error('清除进度失败'));});}
