/*! Decimen integration: (c) 2026 Evan Crawley, AGPL-3.0-or-later; source and notices: ../../licenses/qr-transfer/source.zip */
import DecimenCodec from '../vendor/decimen/codec/decimen_codec.js';
import {isColorImage,channelImage} from './color.mjs';import {isPacket,decodePacket} from './fountain.mjs';
let engine,ptr=0,allocated=0,canvas,previous=[[],[],[]],turn=0,plane;
async function ready(){return engine??=fetch(new URL('./decimen.wasm.gz',import.meta.url)).then(async r=>{if(!r.ok)throw Error('扫码组件加载失败');const wasm=await new Response(r.body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer(),compiled=await WebAssembly.compile(wasm);return DecimenCodec({instantiateWasm:(imports,done)=>{const instance=new WebAssembly.Instance(compiled,imports);done(instance,compiled);return instance.exports;}});});}
function quadArgs(q){return[q.topLeft.x,q.topLeft.y,q.topRight.x,q.topRight.y,q.bottomRight.x,q.bottomRight.y,q.bottomLeft.x,q.bottomLeft.y];}
self.onmessage=async({data:msg})=>{
 let bitmap=msg.bitmap;
 try{
  const zx=await ready();let width=msg.width,height=msg.height,pixels;
  if(bitmap){width=bitmap.width;height=bitmap.height;if(width<1||height<1||width*height>4096*2160)throw Error('画面尺寸无效');canvas??=new OffscreenCanvas(width,height);if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(bitmap,0,0);bitmap.close();bitmap=null;pixels=ctx.getImageData(0,0,width,height).data;}else pixels=new Uint8Array(msg.buffer);
  if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width*height>4096*2160||pixels.byteLength!==width*height*4)throw Error('画面尺寸无效');
  const needed=width*height*4;if(needed>allocated){if(ptr)zx._free(ptr);ptr=zx._malloc(needed);allocated=needed;}const color=isColorImage(pixels),symbols=[];let tracked=0;turn++;
  if(color&&plane?.length!==needed)plane=new Uint8ClampedArray(needed);
  for(let channel=0;channel<(color?3:1);channel++){
   zx.HEAPU8.set(color?channelImage(pixels,channel,plane):pixels,ptr);const found=[],old=previous[channel];
   const add=(r,trackedResult)=>{if(!r.valid||!r.bytes.length)return;const bytes=r.bytes.slice();if(isPacket(bytes)){try{decodePacket(bytes);}catch{return;}}else if(color&&!new TextDecoder().decode(bytes).startsWith('PFR2|'))return;if(found.some(s=>Math.abs(s.quad.topLeft.x-r.position.topLeft.x)<4&&Math.abs(s.quad.topLeft.y-r.position.topLeft.y)<4))return;found.push({bytes,quad:r.position,modules:r.modules,tracked:trackedResult,channel});if(trackedResult)tracked++;};
   if(old.length&&turn%12!==0&&old.every(p=>p.width===width&&p.height===height))for(const position of old)add(zx.readTracked(ptr,width,height,position.modules,...quadArgs(position.quad)),true);
   if(!old.length||found.length<old.length||turn%12===0){const vector=zx.readFull(ptr,width,height,true,12,false);try{for(let i=0;i<vector.size();i++)add(vector.get(i),false);}finally{vector.delete();}}
   previous[channel]=found.slice(0,9).map(s=>({...s,width,height}));symbols.push(...found.slice(0,9));
  }
  if(!color){previous[1]=[];previous[2]=[];}self.postMessage({id:msg.id,symbols,color,tracked,decodeMs:performance.now()-msg.started},symbols.map(s=>s.bytes.buffer));
 }catch(error){self.postMessage({id:msg.id,symbols:[],error:error.message});}finally{bitmap?.close();}
};
