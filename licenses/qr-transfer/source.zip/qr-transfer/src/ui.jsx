import React,{useEffect,useState} from 'react';import {QRCode} from 'antd';
export const bytes=n=>n>=1048576?(n/1048576).toFixed(2)+' MB':n>=1024?(n/1024).toFixed(1)+' KB':n+' B';
export function useSquare(ref){const [size,setSize]=useState(240);useEffect(()=>{if(!ref.current)return;const r=new ResizeObserver(([entry])=>setSize(Math.max(80,Math.floor(Math.min(entry.contentRect.width-32,entry.contentRect.height-32,720)))));r.observe(ref.current);return()=>r.disconnect();},[]);return size;}
export function Code({value,size}){return <QRCode value={value} size={size} errorLevel="M" bordered={false} bgColor="#fff" color="#000" type="canvas" style={{padding:12,flexShrink:0}}/>;}
export function cleanDownload(file){
 const url=URL.createObjectURL(new Blob([file.data],{type:'application/octet-stream'})),a=document.createElement('a');a.href=url;a.download=file.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
