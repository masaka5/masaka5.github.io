import {DecodeWorkerPool} from '../vendor/decimen/worker-pool.mjs';
export function decodePool(onResults,onError){
 let closed=false,batch=[],delivering=false;const timers=new Map();
 function fail(error){if(closed)return;stop();onError(error);}
 const pool=new DecodeWorkerPool(()=>{const worker=new Worker(new URL('./decode-worker.js?v='+__QR_REVISION__,import.meta.url),{type:'module'});
  worker.onerror=()=>fail(Error('高速扫码组件不可用'));
  worker.addEventListener('message',({data})=>{clearTimeout(timers.get(worker));timers.delete(worker);if(data.error)fail(Error(data.error));});return worker;
 },bytes=>{if(closed)return;batch.push(bytes);if(!delivering){delivering=true;queueMicrotask(async()=>{try{while(batch.length&&!closed)await onResults(batch.splice(0,9));}catch(e){fail(e);}finally{delivering=false;}});}});
 try{pool.resize(Math.max(1,Math.min(2,Math.floor((navigator.hardwareConcurrency||2)/4))));}catch(error){stop();throw error;}
 function stop(){closed=true;batch=[];for(const timer of timers.values())clearTimeout(timer);timers.clear();pool.resize(0);}
 return{get available(){return!closed&&!delivering&&pool.busyCount<pool.size;},submit(message,transfer){if(closed)return false;const worker=pool.workers[pool.busy.indexOf(false)];if(!worker)return false;const ok=pool.submit(message,transfer);if(ok)timers.set(worker,setTimeout(()=>fail(Error('扫码组件响应超时')),8000));return ok;},stop};
}
