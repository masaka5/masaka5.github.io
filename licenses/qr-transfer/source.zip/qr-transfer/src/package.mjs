import {MAX_RAW,MAX_WIRE} from './protocol.mjs';
const enc=new TextEncoder(),dec=new TextDecoder('utf-8',{fatal:true}),MAX_PACK=MAX_RAW+65536+8,HEADER=73;
const hex=bytes=>Array.from(bytes,n=>n.toString(16).padStart(2,'0')).join('');
export const digest=async bytes=>new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
const equal=(a,b)=>a.length===b.length&&a.every((n,i)=>n===b[i]);
const join=(...parts)=>{const b=new Uint8Array(parts.reduce((sum,p)=>sum+p.length,0));let offset=0;for(const p of parts){b.set(p,offset);offset+=p.length;}return b;};
function fileName(name){if(typeof name!=='string'||!name||enc.encode(name).length>1024||/[\x00-\x1f\x7f]/.test(name))throw Error('文件名无效');return name.replaceAll('\\','/').split('/').pop()||'文件';}
export async function packFiles(files,kind='files'){
 if(!Array.isArray(files)||!files.length||files.length>20||!['files','text'].includes(kind)||(kind==='text'&&files.length!==1))throw Error('最多添加 20 个文件');
 let size=0;const entries=[];
 for(const file of files){
  if(!(file.data instanceof Uint8Array))throw Error('文件数据无效');size+=file.data.length;if(size>MAX_RAW)throw Error('文件总大小不能超过 16 MB');
  const name=fileName(file.name),type=typeof file.type==='string'&&file.type.length<=200?file.type:'';
  entries.push({name,type,lastModified:Number.isSafeInteger(file.lastModified)&&file.lastModified>=0?file.lastModified:0,size:file.data.length,sha256:hex(await digest(file.data))});
 }
 const meta=enc.encode(JSON.stringify({version:1,kind,files:entries}));if(meta.length>65536)throw Error('文件信息过长');
 const head=new Uint8Array(8);head.set(enc.encode('PQP1'));new DataView(head.buffer).setUint32(4,meta.length);
 return join(head,meta,...files.map(f=>f.data));
}
export async function unpackFiles(bytes){
 if(!(bytes instanceof Uint8Array)||bytes.length<8||bytes.length>MAX_PACK||dec.decode(bytes.subarray(0,4))!=='PQP1')throw Error('文件包格式无效');
 const len=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(4);if(!len||len>65536||len+8>bytes.length)throw Error('文件信息长度无效');
 let meta;try{meta=JSON.parse(dec.decode(bytes.subarray(8,8+len)));}catch{throw Error('文件信息无效');}
 if(meta.version!==1||!['files','text'].includes(meta.kind)||!Array.isArray(meta.files)||!meta.files.length||meta.files.length>20||(meta.kind==='text'&&meta.files.length!==1))throw Error('文件列表无效');
 let offset=8+len,total=0;const files=[];
 for(const file of meta.files){
  const name=fileName(file.name);
  if(!Number.isSafeInteger(file.size)||file.size<0||file.size>MAX_RAW||offset+file.size>bytes.length||!/^[0-9a-f]{64}$/.test(file.sha256)||typeof file.type!=='string'||file.type.length>200)throw Error('文件数据长度无效');
  const data=bytes.slice(offset,offset+file.size);offset+=file.size;total+=file.size;if(total>MAX_RAW)throw Error('文件总大小不能超过 16 MB');
  if(hex(await digest(data))!==file.sha256)throw Error('文件完整性校验失败');
  files.push({name,type:file.type,lastModified:Number.isSafeInteger(file.lastModified)&&file.lastModified>=0?file.lastModified:0,data,sha256:file.sha256});
 }
 if(offset!==bytes.length)throw Error('文件包存在多余数据');return{kind:meta.kind,files};
}
async function keyFor(password,salt){
 if(typeof password!=='string'||!password||enc.encode(password).length>1024)throw Error('请输入有效密码');
 const material=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveKey']);
 return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:250000,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
export async function seal(files,password,codec,kind='files'){
 const packed=await packFiles(files,kind),compressed=await codec.compress(packed),useCompression=compressed.length<packed.length;
 let payload=useCompression?compressed:packed;
 const head=new Uint8Array(HEADER);head.set(enc.encode('PQE1'));head[4]=(useCompression?1:0)|(password?2:0);
 const view=new DataView(head.buffer);view.setUint32(5,packed.length);view.setUint32(9,payload.length+(password?16:0));
 if(password){head.set(crypto.getRandomValues(new Uint8Array(16)),13);head.set(crypto.getRandomValues(new Uint8Array(12)),29);const key=await keyFor(password,head.subarray(13,29));payload=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:head.subarray(29,41),additionalData:head.subarray(0,41)},key,payload));}
 head.set(await digest(join(head.subarray(0,41),payload)),41);
 return{bytes:join(head,payload),originalBytes:files.reduce((n,f)=>n+f.data.length,0),packedBytes:packed.length,compressed:useCompression,encrypted:!!password};
}
export function inspect(bytes){
 if(!(bytes instanceof Uint8Array)||bytes.length<HEADER||bytes.length>MAX_WIRE||dec.decode(bytes.subarray(0,4))!=='PQE1'||bytes[4]>3)throw Error('传输包格式无效');
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),rawSize=view.getUint32(5),payloadSize=view.getUint32(9);
 if(rawSize<8||rawSize>MAX_PACK||payloadSize!==bytes.length-HEADER||!payloadSize)throw Error('传输包长度无效');
 return{compressed:!!(bytes[4]&1),encrypted:!!(bytes[4]&2),rawSize};
}
export async function open(bytes,password,codec){
 const info=inspect(bytes),head=bytes.subarray(0,HEADER);let payload=bytes.subarray(HEADER);
 if(!equal(await digest(join(head.subarray(0,41),payload)),head.subarray(41,73)))throw Error('传输内容校验失败，请重新接收');
 if(info.encrypted){
  if(!password)throw Error('请输入解密密码');
  try{const key=await keyFor(password,head.subarray(13,29));payload=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:head.subarray(29,41),additionalData:head.subarray(0,41)},key,payload));}
  catch{throw Error('密码错误或加密数据损坏');}
 }
 const packed=info.compressed?await codec.decompress(payload,info.rawSize):payload;
 if(packed.length!==info.rawSize)throw Error('解压长度校验失败');
 return {...await unpackFiles(packed),...info};
}
