import React,{useEffect,useState} from 'react';import {createRoot} from 'react-dom/client';
import {App,Button,ConfigProvider,Segmented,Tag,Tooltip} from 'antd';import zhCN from 'antd/locale/zh_CN';import {ArrowLeftOutlined,QrcodeOutlined,CloudDownloadOutlined,SendOutlined,ScanOutlined} from '@ant-design/icons';
import Send from './Send.jsx';import Receive from './Receive.jsx';import {dispose} from './client.mjs';import './style.css';
function Workspace(){
 const [tab,setTab]=useState(()=>new URLSearchParams(location.search).get('view')==='receive'?'receive':'send'),[offline,setOffline]=useState('checking');
 useEffect(()=>{let live=true;
  if(!navigator.serviceWorker){setOffline('unsupported');return;}
  navigator.serviceWorker.register('./sw.js',{scope:'./'}).then(async registration=>{await navigator.serviceWorker.ready;const worker=registration.active||registration.waiting||registration.installing;if(worker?.state==='activated')worker.postMessage({type:'OFFLINE_STATUS'});else worker?.addEventListener('statechange',()=>{if(worker.state==='activated')worker.postMessage({type:'OFFLINE_STATUS'});});}).catch(()=>{if(live)setOffline('error');});
  const listener=({data})=>{if(live&&data.type==='OFFLINE_READY')setOffline('ready');if(live&&data.type==='OFFLINE_ERROR')setOffline('error');};navigator.serviceWorker.addEventListener('message',listener);
  return()=>{live=false;navigator.serviceWorker.removeEventListener('message',listener);dispose();};
 },[]);
 const change=value=>{setTab(value);const url=new URL(location.href);url.searchParams.set('view',value);history.replaceState(null,'',url);};
 return <div className="qr-shell"><header className="tool-header"><div className="header-title"><Button type="text" href="../../" aria-label="返回工具箱" icon={<ArrowLeftOutlined/>}/><QrcodeOutlined/><h1>动态二维码传输</h1></div><Tooltip title={offline==='ready'?'组件已缓存，可断网重新打开此页面':offline==='checking'?'正在缓存离线组件':offline==='unsupported'?'当前浏览器不支持离线缓存':'离线缓存失败，请联网刷新重试'}><Tag icon={<CloudDownloadOutlined/>} color={offline==='ready'?'success':'default'} className="offline-status">{offline==='ready'?'离线可用':offline==='checking'?'准备离线':'未离线'}</Tag></Tooltip></header><main className="qr-main"><div className="workspace-nav"><Segmented aria-label="传输方向" value={tab} onChange={change} options={[{value:'send',label:'发送',icon:<SendOutlined/>},{value:'receive',label:'接收',icon:<ScanOutlined/>}]}/><span>屏幕传输 · 文件不上传</span></div><div className="tool-pane" hidden={tab!=='send'}><Send active={tab==='send'}/></div><div className="tool-pane" hidden={tab!=='receive'}><Receive active={tab==='receive'}/></div></main></div>;
}
createRoot(document.getElementById('root')).render(<ConfigProvider locale={zhCN} theme={{token:{colorPrimary:'#315fc9',colorText:'#242d3a',colorTextSecondary:'#687588',colorBorder:'#e3e7ed',borderRadius:8,fontSize:14,controlHeight:36,fontFamily:'-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif'}}}><App><Workspace/></App></ConfigProvider>);
