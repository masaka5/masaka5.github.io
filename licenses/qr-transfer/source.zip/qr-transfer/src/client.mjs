let worker=null,sequence=0;const pending=new Map();
function ensure(){
 if(worker)return worker;worker=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});
 worker.onmessage=({data})=>{const task=pending.get(data.id);if(!task)return;clearTimeout(task.timer);pending.delete(data.id);data.error?task.reject(Error(data.error)):task.resolve(data.result);};
 worker.onerror=()=>dispose('处理组件加载失败，请刷新后重试');return worker;
}
export function dispose(message='操作已取消'){
 worker?.terminate();worker=null;for(const task of pending.values()){clearTimeout(task.timer);task.reject(Error(message));}pending.clear();
}
export function run(type,payload){return new Promise((resolve,reject)=>{
 try{const w=ensure(),id=++sequence,timer=setTimeout(()=>dispose('处理超时，请减少文件大小后重试'),60000);pending.set(id,{resolve,reject,timer});w.postMessage({id,type,...payload});}
 catch(error){reject(error);}
});}
