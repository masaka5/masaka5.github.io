let worker=null,sequence=0;const pending=new Map();
function ensure(){
 if(worker)return worker;worker=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});
 worker.onmessage=({data})=>{const task=pending.get(data.id);if(!task)return;clearTimeout(task.timer);if(data.progress){task.progress?.(data.progress);task.timer=setTimeout(()=>dispose('处理超时，请重试'),120000);return;}pending.delete(data.id);data.error?task.reject(Error(data.error)):task.resolve(data.result);};
 worker.onerror=()=>dispose('处理组件加载失败，请刷新后重试');return worker;
}
export function dispose(message='操作已取消'){
 worker?.terminate();worker=null;for(const task of pending.values()){clearTimeout(task.timer);task.reject(Error(message));}pending.clear();
}
export function run(type,payload={},progress){return new Promise((resolve,reject)=>{
 try{const w=ensure(),id=++sequence,timer=setTimeout(()=>dispose('处理超时，请重试'),120000);pending.set(id,{resolve,reject,timer,progress});w.postMessage({id,type,...payload});}
 catch(error){reject(error);}
});}
