import {seal,open} from './package.mjs';import {codec} from './codec.mjs';
self.onmessage=async({data})=>{
 try{
  const c=await codec();
  if(data.type==='prepare'){
   const result=await seal(data.files,data.password,c,data.kind);self.postMessage({id:data.id,result},[result.bytes.buffer]);
  }else if(data.type==='restore'){
   const result=await open(data.bytes,data.password,c);self.postMessage({id:data.id,result},result.files.map(f=>f.data.buffer));
  }else throw Error('操作无效');
 }catch(error){self.postMessage({id:data.id,error:error.message||'数据处理失败'});}
};
