/*! Adapted from Decimen Optical Transfer (c) 2026 Evan Crawley. AGPL-3.0-or-later; see vendor/decimen/LICENSE. */
import {QrCode,QrSegment,Ecc} from '@rc-component/qrcode/es/libs/qrcodegen.js';
import {rasterizeQrGrid} from '../vendor/decimen/qr-raster.ts';import {position,count} from './fountain.mjs';
export function chooseGrid(width,height,modules=185,choice='auto'){
 const options=[1,2,4,6,9],fit=n=>{let cols=Math.floor(Math.sqrt(n)),rows=Math.ceil(n/cols);if(width>height)[cols,rows]=[rows,cols];return{count:n,cols,rows,pitch:Math.min(width/cols,height/rows)/modules};};
 if(choice!=='auto'&&options.includes(Number(choice)))return fit(Number(choice));
 let best=fit(1);for(const n of options){const g=fit(n);if(g.pitch>=3&&g.count>best.count)best=g;}return best;
}
export function framePlan(meta,index,round,subset,batch){
 if(!Number.isSafeInteger(index)||index<0||!Number.isSafeInteger(batch)||batch<1||batch>9)throw Error('发送位置无效');
 const total=subset?subset.reduce((n,g)=>n+count(meta,g)*2,0):Math.ceil(meta.length/meta.size)*2,plans=[];
 if(index>=Math.ceil(total/batch))throw Error('发送位置无效');
 for(let slot=0;slot<batch&&index*batch+slot<total;slot++){let local=index*batch+slot;if(subset){for(const g of subset){const k=count(meta,g);if(local<k*2){plans.push({generation:g,k,seed:(2*k+round*k*2+local)>>>0});break;}local-=k*2;}}else plans.push(position(meta,local,round));}
 return plans;
}
export function renderGrid(packets,shape,ecc='L'){
 if(!packets.length||packets.length>9||shape.cols*shape.rows>9)throw Error('码阵参数无效');
 let version;const matrices=packets.map(packet=>{const qr=QrCode.encodeSegments([QrSegment.makeBytes(Array.from(packet))],ecc==='M'?Ecc.MEDIUM:Ecc.LOW,version||1,version||40,4,false);version=qr.version;const data=new Uint8Array(qr.size*qr.size);for(let y=0;y<qr.size;y++)for(let x=0;x<qr.size;x++)data[y*qr.size+x]=qr.getModule(x,y)?1:0;return data;});
 while(matrices.length<shape.cols*shape.rows)matrices.push(new Uint8Array((17+4*version)**2));
 // Upstream emits portrait grids; transpose slot positions when landscape is requested.
 const base=rasterizeQrGrid(17+4*version,matrices,4),baseCols=Math.floor(Math.sqrt(matrices.length));
 if(baseCols===shape.cols)return{...base,version,count:packets.length};
 const cell=25+4*version,width=shape.cols*cell,height=shape.rows*cell,pixels=new Uint32Array(width*height);
 matrices.forEach((_,i)=>{const sx=(i%baseCols)*cell,sy=Math.floor(i/baseCols)*cell,dx=(i%shape.cols)*cell,dy=Math.floor(i/shape.cols)*cell;for(let y=0;y<cell;y++)pixels.set(base.pixels.subarray((sy+y)*base.width+sx,(sy+y)*base.width+sx+cell),(dy+y)*width+dx);});
 return{width,height,pixels,version,count:packets.length};
}
