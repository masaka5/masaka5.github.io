import React,{useEffect,useRef,useState} from 'react';
import {Button,Select,Space} from 'antd';import {CameraOutlined,StopOutlined,PictureOutlined} from '@ant-design/icons';
import {camera,cameraError,scanImage} from './camera.mjs';
export default function CameraView({onCode,active=true,label='扫描',onStatus}){
 const video=useRef(null),controller=useRef(null),handler=useRef(onCode),input=useRef(null),[running,setRunning]=useState(false),[loading,setLoading]=useState(false),[devices,setDevices]=useState([]),[selected,setSelected]=useState('');
 handler.current=onCode;const generation=useRef(0);
 useEffect(()=>{controller.current=camera(video.current,text=>handler.current(text),error=>{setRunning(false);onStatus?.(cameraError(error));});return()=>{generation.current++;controller.current.stop();};},[]);
 const stop=()=>{generation.current++;controller.current?.stop();setRunning(false);setLoading(false);};
 useEffect(()=>{if(!active)stop();},[active]);
 useEffect(()=>{const onHidden=()=>{if(document.hidden)stop();};document.addEventListener('visibilitychange',onHidden);return()=>document.removeEventListener('visibilitychange',onHidden);},[]);
 async function start(device=selected){
  if(!active)return;
  const token=++generation.current;setLoading(true);onStatus?.('');
  try{await controller.current.start(device);if(token!==generation.current)return;setRunning(true);const list=await navigator.mediaDevices.enumerateDevices();if(token===generation.current)setDevices(list.filter(d=>d.kind==='videoinput').map((d,i)=>({value:d.deviceId,label:d.label||'摄像头 '+(i+1)})));}
  catch(error){if(token===generation.current){setRunning(false);onStatus?.(cameraError(error));}}
  finally{if(token===generation.current)setLoading(false);}
 }
 async function image(event){const files=[...event.target.files];event.target.value='';stop();const token=generation.current;setLoading(true);try{let found=0;for(const file of files){const results=await scanImage(file);if(token!==generation.current)return;for(const result of results){if(result.text&&!result.error){handler.current(result.text);found++;}}}if(!found)onStatus?.('未识别到二维码，请选择清晰图片');}catch(error){if(token===generation.current)onStatus?.(error.message);}finally{if(token===generation.current)setLoading(false);}}
 return <div className="camera-box"><div className="video-wrap"><video ref={video} muted playsInline autoPlay aria-label="摄像头预览"/>{!running&&<div className="camera-placeholder"><CameraOutlined/><span>对准另一设备的二维码</span></div>}</div><div className="camera-controls"><Space><Button type="primary" aria-label={running?'停止扫描':label} icon={running?<StopOutlined/>:<CameraOutlined/>} loading={loading} disabled={!active} onClick={()=>running?stop():start()}>{running?'停止扫描':label}</Button><Button aria-label="从图片识别" icon={<PictureOutlined/>} onClick={()=>input.current?.click()} disabled={loading||!active}/></Space>{devices.length>1&&<Select aria-label="选择摄像头" value={selected||undefined} placeholder="选择摄像头" options={devices} onChange={value=>{setSelected(value);if(running)start(value);}}/>}<input hidden ref={input} type="file" accept="image/*" multiple onChange={image}/></div></div>;
}
