import {createSHA256} from 'hash-wasm';import {digest,keyFor} from './package.mjs';import {MAX_FILE,MAX_WIRE,validateFiles} from './fountain.mjs';
export const BLOCK=1048576;const HEADER=34,RECORD=55,enc=new TextEncoder(),dec=new TextDecoder('utf-8',{fatal:true});
const join=(...parts)=>{const out=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let offset=0;for(const p of parts){out.set(p,offset);offset+=p.length;}return out;};
const equal=(a,b)=>a.length===b.length&&a.every((n,i)=>n===b[i]);
const json=data=>enc.encode(JSON.stringify(data));
function name(value){if(typeof value!=='string'||!value||enc.encode(value).length>1024||/[\x00-\x1f\x7f]/.test(value))throw Error('文件名无效');return value.replaceAll('\\','/').split('/').pop()||'文件';}
export function streamHeader(total,count,password){if(!Number.isSafeInteger(total)||total<0||total>MAX_FILE||!Number.isInteger(count)||count<1||count>20)throw Error('文件总大小不能超过 5 GB');const h=new Uint8Array(HEADER),v=new DataView(h.buffer);h.set(enc.encode('PQS2'));h[4]=password?1:0;if(password)h.set(crypto.getRandomValues(new Uint8Array(16)),5);v.setUint32(21,BLOCK);h[25]=count;v.setBigUint64(26,BigInt(total));return h;}
export function inspectStream(h){if(h.length!==HEADER||dec.decode(h.subarray(0,4))!=='PQS2'||h[4]>1)throw Error('文件包格式无效');const v=new DataView(h.buffer,h.byteOffset,h.byteLength),total=Number(v.getBigUint64(26)),count=h[25];if(v.getUint32(21)!==BLOCK||!Number.isSafeInteger(total)||total<0||total>MAX_FILE||count<1||count>20)throw Error('文件包超出 5 GB 限制');return{encrypted:!!h[4],total,count};}
function aad(header,index,record){const number=new Uint8Array(4);new DataView(number.buffer).setUint32(0,index);return join(header,number,record);}
export async function sealStream(files,password,codec,writer,{progress=()=>{},cancelled=()=>false,kind='files'}={}){
 const total=validateFiles(files),header=streamHeader(total,files.length,password),key=password?await keyFor(password,header.subarray(5,21)):null;let index=0,done=0,compressed=false;
 const meta=files.map(f=>({name:name(f.name),size:f.size,type:typeof f.type==='string'&&f.type.length<=200?f.type:'',lastModified:Number.isSafeInteger(f.lastModified)?f.lastModified:0}));
 async function write(type,fileIndex,raw){if(cancelled())throw Error('操作已取消');const z=await codec.compress(raw),use=z.length<raw.length;let payload=use?z:raw;compressed||=use;const r=new Uint8Array(RECORD),v=new DataView(r.buffer);r[0]=type;r[1]=fileIndex;r[2]=use?1:0;v.setUint32(3,raw.length);v.setUint32(7,payload.length+(key?16:0));r.set(await digest(raw),23);if(key){r.set(crypto.getRandomValues(new Uint8Array(12)),11);payload=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:r.subarray(11,23),additionalData:aad(header,index,r)},key,payload));}await writer.append(r);await writer.append(payload);index++;if(writer.position>MAX_WIRE)throw Error('传输包超出限制');}
 try{
  await writer.append(header);await write(1,255,json({version:2,kind,files:meta}));const hashes=[];
  for(let i=0;i<files.length;i++){const hash=await createSHA256();hash.init();for(let offset=0;offset<files[i].size;offset+=BLOCK){if(cancelled())throw Error('操作已取消');const data=new Uint8Array(await files[i].slice(offset,Math.min(files[i].size,offset+BLOCK)).arrayBuffer());if(!data.length)throw Error('文件读取失败');hash.update(data);await write(2,i,data);done+=data.length;progress({stage:'准备',done,total});}hashes.push(hash.digest('hex'));}
  await write(3,255,json({sha256:hashes}));const file=await writer.finish();return{file,length:file.size,originalBytes:total,compressed,encrypted:!!password};
 }catch(error){await writer.abort();throw error;}
}
export async function openStream(file,password,codec,createOutput,{progress=()=>{},cancelled=()=>false}={}){
 const read=async(offset,length)=>{const b=new Uint8Array(await file.slice(offset,offset+length).arrayBuffer());if(b.length!==length)throw Error('文件包不完整');return b;};
 const header=await read(0,HEADER),info=inspectStream(header);if(info.encrypted&&!password)throw Error('请输入解密密码');const key=info.encrypted?await keyFor(password,header.subarray(5,21)):null;
 let offset=HEADER,index=0,manifest=null,finished=false,totalDone=0;const outputs=[],hashes=[],sizes=[];let verified=[];
 try{
  while(offset<file.size){if(cancelled())throw Error('操作已取消');if(finished||index>Math.ceil(MAX_FILE/BLOCK)+22)throw Error('文件包包含多余数据');const r=await read(offset,RECORD),v=new DataView(r.buffer),type=r[0],fileIndex=r[1],rawSize=v.getUint32(3),payloadSize=v.getUint32(7);offset+=RECORD;
   if(![1,2,3].includes(type)||r[2]>1||!rawSize||rawSize>(type===2?BLOCK:65536)||payloadSize<1||payloadSize>BLOCK+16||offset+payloadSize>file.size)throw Error('文件块长度无效');let payload=await read(offset,payloadSize);offset+=payloadSize;
   if(key){try{payload=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:r.subarray(11,23),additionalData:aad(header,index,r)},key,payload));}catch{throw Error('密码错误或加密数据损坏');}}
   const raw=r[2]?await codec.decompress(payload,rawSize):payload;if(raw.length!==rawSize||!equal(await digest(raw),r.subarray(23)))throw Error('文件块完整性校验失败');index++;
   if(type===1){if(manifest||index!==1||fileIndex!==255)throw Error('文件列表无效');try{manifest=JSON.parse(dec.decode(raw));}catch{throw Error('文件列表无效');}if(manifest.version!==2||!['files','text'].includes(manifest.kind)||!Array.isArray(manifest.files)||manifest.files.length!==info.count||(manifest.kind==='text'&&info.count!==1)||validateFiles(manifest.files)!==info.total)throw Error('文件列表无效');for(let i=0;i<manifest.files.length;i++){const f=manifest.files[i];f.name=name(f.name);if(typeof f.type!=='string'||f.type.length>200)throw Error('文件类型无效');outputs.push(await createOutput(i,f));const h=await createSHA256();h.init();hashes.push(h);sizes.push(0);}}
   else if(type===2){if(!manifest||fileIndex>=outputs.length||sizes[fileIndex]+raw.length>manifest.files[fileIndex].size)throw Error('文件块顺序或长度无效');await outputs[fileIndex].append(raw);hashes[fileIndex].update(raw);sizes[fileIndex]+=raw.length;totalDone+=raw.length;progress({stage:'恢复',done:totalDone,total:info.total});}
   else{if(!manifest||fileIndex!==255)throw Error('校验记录无效');let footer;try{footer=JSON.parse(dec.decode(raw));}catch{throw Error('校验记录无效');}if(!Array.isArray(footer.sha256)||footer.sha256.length!==outputs.length)throw Error('文件校验记录无效');verified=hashes.map((h,i)=>{const hash=h.digest('hex');if(sizes[i]!==manifest.files[i].size||hash!==footer.sha256[i])throw Error('文件完整性校验失败');return hash;});finished=true;}
  }
  if(!finished||totalDone!==info.total)throw Error('文件包不完整');const files=[];for(let i=0;i<outputs.length;i++)files.push({...manifest.files[i],blob:await outputs[i].finish(),sha256:verified[i]});return{kind:manifest.kind,files,...info};
 }catch(error){await Promise.allSettled(outputs.map(o=>o.abort()));throw error;}
}
