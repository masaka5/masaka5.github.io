import {codec} from './codec.mjs';import {validateFiles,validate,MAX_WIRE,MAX_SHARD,Generation,generations,count,position,symbol,decodePacket,request} from './fountain.mjs';import {sealStream,openStream,inspectStream} from './stream-package.mjs';import {Disk,root,capacity,removeDisk,fileFromDisk,state,getGeneration,loadRanks,saveGeneration,resetState,lease,cleanSendOrphans,cleanOutputs} from './disk.mjs';
import {framePlan,renderGrid} from './grid.mjs';
let sender=null,receiver=null,preparing=0,restoring=0,receiveQueue=Promise.resolve(),sendLease=null;
const id=()=>Array.from(crypto.getRandomValues(new Uint8Array(8)),n=>n.toString(16).padStart(2,'0')).join('');
const names=new Set();
async function packetAt(pos){if(sender.cache?.generation!==pos.generation){const offset=pos.generation*sender.size*128;sender.cache={generation:pos.generation,bytes:new Uint8Array(await sender.file.slice(offset,Math.min(sender.length,offset+128*sender.size)).arrayBuffer())};}return symbol(sender,sender.cache.bytes,pos.generation,pos.seed);}
async function releaseSender(){if(sender){const name=sender.name;sender=null;await removeDisk(name);}if(sendLease){await sendLease();sendLease=null;}}
async function loadReceiver(){if(receiver)return receiver;const saved=await state();if(!saved)return null;validate(saved);const ranks=await loadRanks(saved),file=await Disk.create(saved.disk,false);receiver={meta:saved,ranks,file,cache:new Map()};return receiver;}
function summary(r=receiver){if(!r)return null;let rank=0,done=0;const missing=[],sources=Math.ceil(r.meta.length/r.meta.size);for(let g=0;g<r.ranks.length;g++){rank+=r.ranks[g];if(r.ranks[g]===Math.min(128,sources-g*128))done++;else if(missing.length<96)missing.push(g);}return{meta:r.meta,rank,sources,done,total:r.ranks.length,complete:done===r.ranks.length,redundant:r.meta.redundant||0,missing,request:missing.length?request(r.meta,missing):null};}
async function accept(packet,report=true){const p=decodePacket(packet);let r=await loadReceiver();if(!r){await capacity(p.length*2+4*1024**2);const meta={id:p.id,length:p.length,size:p.size,disk:'pqr-receive-'+p.id+'.bin',redundant:0};r=receiver={meta,file:await Disk.create(meta.disk),ranks:new Uint16Array(generations(meta)),cache:new Map()};}
 if(['id','length','size'].some(k=>r.meta[k]!==p[k]))throw Error('这是其他传输，请先清除当前进度');
 if(r.ranks[p.generation]===p.k){r.meta.redundant++;return report?summary(r):null;}
 let g=r.cache.get(p.generation);if(!g){g=new Generation(p.k,p.size);for(const row of await getGeneration(p.id,p.generation))g.accept(row.seed,p.generation,row.data);r.cache.set(p.generation,g);if(r.cache.size>2)r.cache.delete(r.cache.keys().next().value);}
 if(!g.accept(p.seed,p.generation,p.data)){r.meta.redundant++;return report?summary(r):null;}
 const complete=g.complete;if(complete){const bytes=g.bytes(),offset=p.generation*p.size*128;r.file.write(bytes.subarray(0,Math.min(bytes.length,p.length-offset)),offset);r.file.flush();}
 try{await saveGeneration(r.meta,p.generation,g.rank,p,complete);}catch(error){r.cache.delete(p.generation);throw error;}
 r.ranks[p.generation]=g.rank;if(complete)r.cache.delete(p.generation);return report?summary(r):null;
}
async function clearReceiver(){restoring++;const r=receiver||await loadReceiver();receiver=null;r?.file.close();await resetState();if(r){await removeDisk(r.meta.disk);await cleanOutputs(r.meta.id);}for(const name of [...names]){await removeDisk(name);names.delete(name);}return null;}
function storageError(error){if(['QuotaExceededError'].includes(error.name))return'浏览器可用存储不足，请清理空间后重试';if(['NoModificationAllowedError','InvalidStateError'].includes(error.name))return'暂存文件正在被其他页面使用，请关闭其他接收页面后重试';return /[\u3400-\u9fff]/.test(error.message||'')?error.message:'文件处理失败，请检查浏览器存储和文件访问权限';}
self.onmessage=async({data})=>{
 const progress=value=>self.postMessage({id:data.id,progress:value});
 try{let result;
  if(data.type==='prepare'){
   const token=++preparing,total=validateFiles(data.files);await root();await releaseSender();await cleanSendOrphans();await capacity(total+16*1024**2);const name='pqr-send-'+id()+'.bin';sendLease=await lease(name);const writer=await Disk.create(name);
   const prepared=await sealStream(data.files,data.password,await codec(),writer,{kind:data.kind,progress,cancelled:()=>token!==preparing});if(token!==preparing){await removeDisk(name);throw Error('操作已取消');}
   const meta={id:id(),length:prepared.length,size:data.size||MAX_SHARD};validate(meta);sender={...meta,file:prepared.file,name,cache:null};result={meta,originalBytes:prepared.originalBytes,compressed:prepared.compressed,encrypted:prepared.encrypted};
  }else if(data.type==='grid-frame'){
   if(!sender||data.transfer!==sender.id)throw Error('请重新生成二维码');const shape=data.shape;if(!shape||![1,2,4,6,9].includes(shape.count)||!Number.isInteger(shape.cols)||!Number.isInteger(shape.rows)||shape.cols<1||shape.rows<1||shape.cols*shape.rows!==shape.count)throw Error('码阵参数无效');const plans=framePlan(sender,data.index,data.round,data.subset,shape.count),packets=[];for(const pos of plans)packets.push(await packetAt(pos));result={raster:renderGrid(packets,shape,sender.size===2294?'M':'L'),generation:plans[0].generation};
  }else if(data.type==='frame'){
   if(!sender||data.transfer!==sender.id)throw Error('请重新生成二维码');let pos;if(data.generation!==undefined){const k=count(sender,data.generation),slot=data.index%(k*2);pos={generation:data.generation,k,seed:(2*k+(data.round||1)*k*2+slot)>>>0};}else pos=position(sender,data.index,data.round);
   result={packet:await packetAt(pos),...pos};
  }else if(data.type==='cancel'){preparing++;await releaseSender();result=null;}
  else if(data.type==='status'){result=summary(await loadReceiver());}
  else if(data.type==='accept'){const task=receiveQueue.catch(()=>{}).then(()=>accept(data.packet));receiveQueue=task;result=await task;}
  else if(data.type==='accept-batch'){if(!Array.isArray(data.packets)||!data.packets.length||data.packets.length>9)throw Error('接收批次无效');const task=receiveQueue.catch(()=>{}).then(async()=>{for(const packet of data.packets)await accept(packet,false);return summary();});receiveQueue=task;result=await task;}
  else if(data.type==='clear'){restoring++;const task=receiveQueue.catch(()=>{}).then(()=>clearReceiver());receiveQueue=task;result=await task;}
  else if(data.type==='restore'){
   await receiveQueue.catch(()=>{});const r=await loadReceiver();if(!r||!summary(r).complete)throw Error('编码片不足');r.file.flush();const file=await r.file.file.getFile(),header=new Uint8Array(await file.slice(0,34).arrayBuffer()),info=inspectStream(header);
   if(info.encrypted&&!data.password){result={locked:true};}else{
    const token=++restoring;await cleanOutputs(r.meta.id);names.clear();await capacity(info.total+8*1024**2);
    result=await openStream(file,data.password,await codec(),async i=>{const name='pqr-output-'+r.meta.id+'-'+i+'.bin';names.add(name);return Disk.create(name);},{progress,cancelled:()=>token!==restoring});
   }
  }else throw Error('操作无效');
  const transfer=result?.raster?[result.raster.pixels.buffer]:result?.packet?[result.packet.buffer]:[];self.postMessage({id:data.id,result},transfer);
 }catch(error){self.postMessage({id:data.id,error:storageError(error)});}
};
