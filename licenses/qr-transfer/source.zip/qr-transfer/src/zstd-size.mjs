import {MAX_RAW} from './protocol.mjs';
// Read the standard frame header before the third-party wrapper calls malloc.
// Unknown content lengths, oversized windows and concatenated/skippable frame
// magic are rejected; decompression capacity is bounded to the file package.
export function checkZstd(bytes,expected){
 if(!Number.isSafeInteger(expected)||expected<8||expected>MAX_RAW+65544||bytes.length<6||bytes[0]!==0x28||bytes[1]!==0xb5||bytes[2]!==0x2f||bytes[3]!==0xfd)throw Error('压缩内容或长度无效');
 const descriptor=bytes[4];if(descriptor&0x18)throw Error('压缩帧格式无效');
 const single=!!(descriptor&32),flag=descriptor>>>6,dictSize=[0,1,2,4][descriptor&3];let offset=5;
 if(!single){const wd=bytes[offset++],base=2**(10+(wd>>>3)),window=base+(base/8)*(wd&7);if(window>32*1024*1024)throw Error('压缩窗口超出限制');}
 offset+=dictSize;const size=[single?1:0,2,4,8][flag];if(!size||offset+size>bytes.length)throw Error('压缩长度缺失');
 let content=0n;for(let i=0;i<size;i++)content|=BigInt(bytes[offset+i])<<BigInt(i*8);if(size===2)content+=256n;
 if(content!==BigInt(expected))throw Error('压缩长度不一致或超出限制');return expected;
}
