export const MAX_RAW=16*1024*1024,MAX_WIRE=MAX_RAW+65536+4096,MAX_FRAMES=60000;
const table=new Uint32Array(256).map((_,n)=>{let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
export function crc32(text){let c=0xffffffff;for(let i=0;i<text.length;i++)c=table[(c^text.charCodeAt(i))&255]^(c>>>8);return((c^0xffffffff)>>>0).toString(16).padStart(8,'0');}
export function base64(bytes){let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(text).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');}
export function unbase64(text){if(!/^[A-Za-z0-9_-]+$/.test(text))throw Error('数据帧格式无效');const decoded=atob(text.replaceAll('-','+').replaceAll('_','/'));const result=Uint8Array.from(decoded,c=>c.charCodeAt(0));if(base64(result)!==text)throw Error('数据帧编码无效');return result;}
function integer(text,min,max){if(!/^(0|[1-9][0-9]*)$/.test(String(text)))throw Error('数据帧参数无效');const n=Number(text);if(!Number.isSafeInteger(n)||n<min||n>max)throw Error('数据帧超出限制');return n;}
function metadata({id,total,size,length}){
 if(!/^[0-9a-f]{16}$/.test(id))throw Error('传输编号无效');
 integer(size,300,900);integer(length,1,MAX_WIRE);integer(total,1,MAX_FRAMES);
 if(total!==Math.ceil(length/size))throw Error('数据帧数量无效');
}
export function encodeFrame(meta,index,bytes){
 metadata(meta);integer(index,0,meta.total-1);const expected=Math.min(meta.size,meta.length-index*meta.size);
 if(!(bytes instanceof Uint8Array)||bytes.length!==expected)throw Error('数据帧长度无效');
 const prefix=`PQT1|${meta.id}|${index}|${meta.total}|${meta.size}|${meta.length}|`,data=base64(bytes);
 return prefix+crc32(prefix+data)+'|'+data;
}
export function decodeFrame(text){
 if(typeof text!=='string'||text.length>1400)throw Error('数据帧过长');
 const parts=text.split('|');if(parts.length!==8||parts[0]!=='PQT1')throw Error('不是本工具的数据帧');
 const [version,id,idx,total,size,length,checksum,data]=parts,meta={id,total:integer(total,1,MAX_FRAMES),size:integer(size,300,900),length:integer(length,1,MAX_WIRE)};
 metadata(meta);const index=integer(idx,0,meta.total-1);
 if(!/^[0-9a-f]{8}$/.test(checksum)||crc32(parts.slice(0,6).join('|')+'|'+data)!==checksum)throw Error('帧校验失败');
 const bytes=unbase64(data);if(bytes.length!==Math.min(meta.size,meta.length-index*meta.size))throw Error('数据帧长度无效');
 return {...meta,index,bytes};
}
export function createTransfer(bytes,size=600){
 if(!(bytes instanceof Uint8Array)||!bytes.length||bytes.length>MAX_WIRE)throw Error('传输数据超出 16 MB 限制');
 const meta={id:Array.from(crypto.getRandomValues(new Uint8Array(8)),n=>n.toString(16).padStart(2,'0')).join(''),size,length:bytes.length,total:Math.ceil(bytes.length/size)};metadata(meta);
 return {...meta,frame:index=>encodeFrame(meta,index,bytes.subarray(index*size,Math.min((index+1)*size,bytes.length)))};
}
export class Receiver{
 constructor(){this.meta=null;this.parts=new Map();this.duplicates=0;}
 get received(){return this.parts.size;}
 get complete(){return !!this.meta&&this.received===this.meta.total;}
 accept(text){
  const f=decodeFrame(text);
  if(this.meta&&['id','total','size','length'].some(k=>this.meta[k]!==f[k]))throw Error('这是其他传输，请先清空当前接收');
  const old=this.parts.get(f.index);
  if(old){if(old.some((n,i)=>n!==f.bytes[i]))throw Error('同序号数据冲突');this.duplicates++;return {duplicate:true,index:f.index};}
  if(!this.meta)this.meta={id:f.id,total:f.total,size:f.size,length:f.length};
  this.parts.set(f.index,f.bytes);return{duplicate:false,index:f.index,bytes:f.bytes};
 }
 missing(){if(!this.meta)return[];const list=[];for(let i=0;i<this.meta.total;i++)if(!this.parts.has(i))list.push(i);return list;}
 bytes(){if(!this.complete)throw Error('还有未收到的数据帧');const result=new Uint8Array(this.meta.length);for(const [index,data]of this.parts)result.set(data,index*this.meta.size);return result;}
 snapshot(){return {schema:1,meta:this.meta,parts:[...this.parts].map(([i,b])=>[i,b.slice()]),duplicates:this.duplicates};}
 static restore(snapshot){
  const r=new Receiver();if(!snapshot||snapshot.schema!==1||!Array.isArray(snapshot.parts)||snapshot.parts.length>MAX_FRAMES)throw Error('接收缓存无效');
  if(!snapshot.meta){if(snapshot.parts.length)throw Error('接收缓存无效');return r;}
  metadata(snapshot.meta);
  for(const row of snapshot.parts){if(!Array.isArray(row)||row.length!==2||r.parts.has(row[0]))throw Error('接收缓存无效');r.accept(encodeFrame(snapshot.meta,row[0],new Uint8Array(row[1])));}
  r.duplicates=Number.isSafeInteger(snapshot.duplicates)&&snapshot.duplicates>=0?snapshot.duplicates:0;return r;
 }
}
export function createRequest(receiver){
 if(!receiver.meta||receiver.complete)throw Error('没有需要补发的数据');
 // One request is kept small enough to scan; repeat for remaining gaps.
 const body=`PQR1|${receiver.meta.id}|${receiver.meta.total}|${receiver.missing().slice(0,128).join(',')}`;return body+'|'+crc32(body);
}
export function parseRequest(text,transfer){
 if(typeof text!=='string'||text.length>1100)throw Error('补帧码过长');
 const parts=text.split('|');if(parts.length!==5||parts[0]!=='PQR1'||crc32(parts.slice(0,4).join('|'))!==parts[4]||parts[1]!==transfer.id||integer(parts[2],1,MAX_FRAMES)!==transfer.total)throw Error('补帧码不属于当前传输');
 const list=parts[3].split(',');if(!list.length||list.length>128)throw Error('补帧数量无效');
 const values=list.map(n=>integer(n,0,transfer.total-1));if(new Set(values).size!==values.length)throw Error('补帧序号重复');return values;
}
