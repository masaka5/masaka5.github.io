import {decodePool} from './decode-pool.mjs';
let ready;
export function scanData(result){const bytes=result?.bytes instanceof Uint8Array?result.bytes:result?.bytes?new Uint8Array(result.bytes):null;return bytes?.[0]===80&&bytes?.[1]===81&&bytes?.[2]===70&&bytes?.[3]===50?bytes:result?.text;}
export async function decoder(){
 if(!globalThis.ZXingWASM)throw Error('扫码组件未加载，请刷新');
 if(!ready)ready=Promise.resolve(globalThis.ZXingWASM.prepareZXingModule({overrides:{locateFile:path=>new URL('../../vendor/zxing/'+path,location.href).href},fireImmediately:true}));
 await ready;return globalThis.ZXingWASM;
}
export async function scanImage(file){if(file.size>30*1024*1024)throw Error('图片不能超过 30 MB');const d=await decoder();return d.readBarcodes(file,{formats:['QRCode'],tryHarder:true,tryRotate:true,maxNumberOfSymbols:16});}
export function camera(video,onResult,onError){
 let stream=null,active=false,epoch=0,timer=null,pool=null,videoCallback=null,fallback=false;const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
 function stop(){active=false;epoch++;clearTimeout(timer);if(videoCallback!==null)video.cancelVideoFrameCallback?.(videoCallback);videoCallback=null;pool?.stop();pool=null;stream?.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;}
 async function start(deviceId=''){
  stop();const token=epoch;if(!isSecureContext)throw Error('摄像头需要 HTTPS 或 localhost');if(!navigator.mediaDevices?.getUserMedia)throw Error('此浏览器不支持摄像头');
  await decoder();if(epoch!==token)return;const next=await navigator.mediaDevices.getUserMedia({audio:false,video:{...(deviceId?{deviceId:{exact:deviceId}}:{facingMode:{ideal:'environment'}}),width:{ideal:1920},height:{ideal:1080},frameRate:{ideal:30,max:60}}});
  if(epoch!==token){next.getTracks().forEach(t=>t.stop());return;}
  stream=next;active=true;video.srcObject=stream;try{await video.play();}catch(error){if(epoch===token)stop();throw error;}
  const track=stream.getVideoTracks?.()[0];try{if(track?.getCapabilities?.().focusMode?.includes('continuous'))await track.applyConstraints({advanced:[{focusMode:'continuous'}]});}catch{}
  if(!active||epoch!==token)return;
  fallback=false;try{pool=decodePool(async packets=>{if(active&&token===epoch){const values=packets.map(bytes=>scanData({bytes,text:new TextDecoder().decode(bytes)})).filter(Boolean);if(values.length)await onResult(values);}},()=>{if(active&&token===epoch){fallback=true;pool=null;}});}catch{fallback=true;}
  function schedule(){if(!active||token!==epoch)return;if(video.requestVideoFrameCallback)videoCallback=video.requestVideoFrameCallback(loop);else timer=setTimeout(loop,25);}
  const loop=async()=>{
   if(!active||token!==epoch)return;
   try{if(video.readyState>=2&&video.videoWidth&&(fallback||pool?.available)){const scale=Math.min(1,1920/Math.max(video.videoWidth,video.videoHeight),1080/Math.min(video.videoWidth,video.videoHeight)),width=Math.round(video.videoWidth*scale),height=Math.round(video.videoHeight*scale);let bitmap;
    if(!fallback&&globalThis.createImageBitmap&&globalThis.OffscreenCanvas){try{bitmap=await createImageBitmap(video,{resizeWidth:width,resizeHeight:height});}catch{}}
    if(!active||token!==epoch){bitmap?.close();return;}
    if(bitmap){if(!pool?.submit({bitmap,started:performance.now()},[bitmap]))bitmap.close();}else{if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}ctx.drawImage(video,0,0,width,height);const image=ctx.getImageData(0,0,width,height);if(fallback){const results=await(await decoder()).readBarcodes(image,{formats:['QRCode'],tryHarder:true,tryRotate:true,maxNumberOfSymbols:9});if(active&&token===epoch){const values=results.map(scanData).filter(Boolean);if(values.length)await onResult(values);}}else pool?.submit({buffer:image.data.buffer,width,height,started:performance.now()},[image.data.buffer]);}
   }}
   catch(error){stop();onError(error);return;}
   schedule();
  };schedule();
 }
 return{start,stop};
}
export const cameraError=error=>({NotAllowedError:'请允许摄像头访问',NotFoundError:'未找到摄像头',NotSupportedError:'当前摄像头不可用，请选择其他设备',NotReadableError:'摄像头被占用，请关闭其他应用',OverconstrainedError:'当前摄像头不可用，请选择其他设备'}[error?.name]||(error?.message==='Not supported'?'当前摄像头不可用，请选择其他设备':error?.message)||'无法启动摄像头');
