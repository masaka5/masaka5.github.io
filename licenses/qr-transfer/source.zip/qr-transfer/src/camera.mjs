let ready;
export function scanData(result){const bytes=result?.bytes instanceof Uint8Array?result.bytes:result?.bytes?new Uint8Array(result.bytes):null;return bytes?.[0]===80&&bytes?.[1]===81&&bytes?.[2]===70&&bytes?.[3]===50?bytes:result?.text;}
export async function decoder(){
 if(!globalThis.ZXingWASM)throw Error('扫码组件未加载，请刷新');
 if(!ready)ready=Promise.resolve(globalThis.ZXingWASM.prepareZXingModule({overrides:{locateFile:path=>new URL('../../vendor/zxing/'+path,location.href).href},fireImmediately:true}));
 await ready;return globalThis.ZXingWASM;
}
export async function scanImage(file){if(file.size>30*1024*1024)throw Error('图片不能超过 30 MB');const d=await decoder();return d.readBarcodes(file,{formats:['QRCode'],tryHarder:true,tryRotate:true,maxNumberOfSymbols:16});}
export function camera(video,onResult,onError){
 let stream=null,active=false,epoch=0,timer=null;const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});
 function stop(){active=false;epoch++;clearTimeout(timer);stream?.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;}
 async function start(deviceId=''){
  stop();const token=epoch;if(!isSecureContext)throw Error('摄像头需要 HTTPS 或 localhost');if(!navigator.mediaDevices?.getUserMedia)throw Error('此浏览器不支持摄像头');
  await decoder();if(epoch!==token)return;const next=await navigator.mediaDevices.getUserMedia({audio:false,video:deviceId?{deviceId:{exact:deviceId},width:{ideal:1280},height:{ideal:720}}:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}}});
  if(epoch!==token){next.getTracks().forEach(t=>t.stop());return;}
  stream=next;active=true;video.srcObject=stream;try{await video.play();}catch(error){if(epoch===token)stop();throw error;}
  const loop=async()=>{
   if(!active||token!==epoch)return;const started=performance.now();
   try{if(video.readyState>=2&&video.videoWidth){const scale=Math.min(1,1280/video.videoWidth);canvas.width=Math.round(video.videoWidth*scale);canvas.height=Math.round(video.videoHeight*scale);ctx.drawImage(video,0,0,canvas.width,canvas.height);const result=await globalThis.ZXingWASM.readBarcodes(ctx.getImageData(0,0,canvas.width,canvas.height),{formats:['QRCode'],tryHarder:true,maxNumberOfSymbols:1});if(active&&token===epoch)for(const r of result)if(!r.error&&scanData(r))onResult(scanData(r));}}
   catch(error){stop();onError(error);return;}
   if(active&&token===epoch)timer=setTimeout(loop,Math.max(15,85-(performance.now()-started)));
  };loop();
 }
 return{start,stop};
}
export const cameraError=error=>({NotAllowedError:'请允许摄像头访问',NotFoundError:'未找到摄像头',NotSupportedError:'当前摄像头不可用，请选择其他设备',NotReadableError:'摄像头被占用，请关闭其他应用',OverconstrainedError:'当前摄像头不可用，请选择其他设备'}[error?.name]||(error?.message==='Not supported'?'当前摄像头不可用，请选择其他设备':error?.message)||'无法启动摄像头');
