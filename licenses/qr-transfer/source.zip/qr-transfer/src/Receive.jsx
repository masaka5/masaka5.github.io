import React,{useEffect,useRef,useState} from 'react';
import {App,Button,Card,Drawer,Empty,Input,Progress,Space,Tag} from 'antd';import {DownloadOutlined,CopyOutlined,DeleteOutlined,QrcodeOutlined,FolderOpenOutlined,UnlockOutlined} from '@ant-design/icons';
import {Receiver,createRequest} from './protocol.mjs';import {inspect} from './package.mjs';import {run} from './client.mjs';import {saveFrame,loadFrames,clearFrames} from './storage.mjs';import {bytes,cleanDownload,Code} from './ui.jsx';import CameraView from './CameraView.jsx';
export default function Receive({active}){
 const {message,modal}=App.useApp(),receiver=useRef(new Receiver()),[version,setVersion]=useState(0),[ready,setReady]=useState(false),[error,setError]=useState(''),[saved,setSaved]=useState(''),[result,setResult]=useState(null),[busy,setBusy]=useState(false),[password,setPassword]=useState(''),[locked,setLocked]=useState(false),[details,setDetails]=useState(false),[repair,setRepair]=useState(false),[invalid,setInvalid]=useState(0);
 const saveQueue=useRef(Promise.resolve()),generation=useRef(0),attempt=useRef(0),busyRef=useRef(false),autoTried=useRef(false),seenError=useRef('');
 useEffect(()=>{let live=true;loadFrames().then(snapshot=>{if(!live)return;receiver.current=Receiver.restore(snapshot);if(receiver.current.received)setSaved('已恢复上次接收进度');setVersion(v=>v+1);}).catch(e=>{if(live)setError(e.message);}).finally(()=>{if(live)setReady(true);});return()=>{live=false;generation.current++;attempt.current++;};},[]);
 async function restore(code=''){
  if(busyRef.current||!receiver.current.complete)return;busyRef.current=true;setBusy(true);setError('');const token=++attempt.current,gen=generation.current;
  try{const data=receiver.current.bytes(),info=inspect(data);if(info.encrypted&&!code){setLocked(true);return;}
   const restored=await run('restore',{bytes:data,password:code});if(token!==attempt.current||gen!==generation.current)return;setResult(restored);setLocked(false);setPassword('');setSaved('完整性校验通过');
  }catch(e){if(token===attempt.current&&gen===generation.current)setError(e.message);}
  finally{if(token===attempt.current){setBusy(false);busyRef.current=false;}}
 }
 useEffect(()=>{if(ready&&receiver.current.complete&&!autoTried.current&&!result){autoTried.current=true;restore();}},[version,ready]);
 function accept(text){
  if(!ready||result)return;
  try{
   const r=receiver.current,accepted=r.accept(text);if(!accepted.duplicate){setError('');seenError.current='';const token=generation.current;
    saveQueue.current=saveQueue.current.catch(()=>{}).then(()=>saveFrame(r.meta,accepted.index,accepted.bytes)).then(()=>{if(token===generation.current)setSaved('接收进度已暂存');}).catch(e=>{if(token===generation.current)setError(e.message);});
   }
   setVersion(v=>v+1);
  }catch(e){if(seenError.current!==text){setInvalid(n=>n+1);seenError.current=text;}setError(e.message);}
 }
 async function clear(){
  modal.confirm({title:'清除接收进度？',content:'已收集的数据帧和此浏览器的暂存将被移除。',okText:'清除',cancelText:'取消',okButtonProps:{danger:true},onOk:async()=>{
   try{setReady(false);generation.current++;attempt.current++;busyRef.current=false;await saveQueue.current.catch(()=>{});await clearFrames();receiver.current=new Receiver();autoTried.current=false;setResult(null);setPassword('');setLocked(false);setBusy(false);setError('');setSaved('');setInvalid(0);setVersion(v=>v+1);}
   catch(e){setError(e.message);}finally{setReady(true);}
  }});
 }
 const r=receiver.current,progress=r.meta?Math.round(r.received/r.meta.total*100):0,missing=r.missing();
 async function copy(){try{await navigator.clipboard.writeText(new TextDecoder().decode(result.files[0].data));message.success('已复制');}catch{message.error('复制失败，请下载文本文件');}}
 return <div className="receive-layout"><Card className="camera-card"><CameraView active={active&&ready&&!result&&!r.complete} onCode={accept} onStatus={setError} label="开始接收"/></Card><Card className="receive-card"><div className="receive-heading"><h2>{result?'接收完成':locked?'等待解密':'接收进度'}</h2><Button type="text" aria-label="清除接收进度" icon={<DeleteOutlined/>} onClick={clear} disabled={!ready||(!r.received&&!error)}/></div><div className="receive-progress"><Progress type="circle" percent={progress} size={112} status={result?'success':undefined}/><div><strong>{r.received} / {r.meta?.total||0} 帧</strong><span>重复 {r.duplicates} · 无效 {invalid}</span>{r.meta&&<span>{bytes(r.meta.length)} · {r.meta.id.slice(0,8)}</span>}</div></div><p className="save-status" role="status">{busy?'正在校验与恢复…':saved||'接收后自动保存进度，可刷新继续'}</p>
 {locked&&<div className="unlock-area"><Input.Password aria-label="解密密码" placeholder="输入发送端密码" autoComplete="off" value={password} onChange={e=>setPassword(e.target.value)} onPressEnter={()=>restore(password)} maxLength={256}/><Button type="primary" icon={<UnlockOutlined/>} loading={busy} onClick={()=>restore(password)}>解密</Button></div>}
 {error&&<p className="tool-error" role="alert">{error}</p>}
 {result?<div className="restore-result"><Tag color="success">SHA-256 校验通过</Tag><Button type="primary" icon={<FolderOpenOutlined/>} onClick={()=>setDetails(true)}>查看 {result.files.length} 个文件</Button>{result.kind==='text'&&<Button icon={<CopyOutlined/>} onClick={copy}>复制文本</Button>}</div>:r.meta&&!r.complete?<div className="receive-actions"><Button icon={<QrcodeOutlined/>} onClick={()=>setRepair(true)}>显示补帧码</Button><Button type="text" onClick={()=>setDetails(true)}>缺少 {missing.length} 帧</Button></div>:r.complete&&!locked?<Button loading={busy} onClick={()=>restore(password)}>重新校验</Button>:<div className="receive-empty">支持文件与文本 · 自动去重补收</div>}
 </Card><Drawer title={result?'恢复的文件':'缺失数据帧'} open={details} onClose={()=>setDetails(false)} width={480} destroyOnHidden>{result?<><div className="file-list">{result.files.map((f,i)=><div className="file-row" key={i}><div><strong>{f.name}</strong><span>{bytes(f.data.length)}</span><code>{f.sha256}</code></div><Button aria-label={'下载 '+f.name} icon={<DownloadOutlined/>} onClick={()=>cleanDownload(f)}/></div>)}</div>{result.kind==='text'&&<Input.TextArea aria-label="收到的文本" readOnly value={new TextDecoder().decode(result.files[0].data)} rows={10}/>}</>:<p className="missing-list">{missing.map(n=>n+1).join('、')}</p>}</Drawer>
 <Drawer title="补帧码" open={repair} onClose={()=>setRepair(false)} width={440} destroyOnHidden>{!!missing.length&&<div className="repair-code"><Code value={createRequest(r)} size={Math.min(350,innerWidth-84)}/><p className="muted-note">发送端点“扫描补帧码”后扫描此码</p><span className="muted-note">本次补发 {Math.min(128,missing.length)} 帧</span></div>}</Drawer></div>;
}
