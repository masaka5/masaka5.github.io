import {init,compress,decompress} from '../node_modules/@bokuweb/zstd-wasm/dist/esm/index.web.js';
import {checkZstd} from './zstd-size.mjs';
let ready;
export async function codec(){
 ready??=init(new URL('./zstd.wasm',import.meta.url).href);await ready;
 return {compress:bytes=>compress(bytes,3),decompress:(bytes,size)=>{checkZstd(bytes,size);const output=decompress(bytes,{defaultHeapSize:size});if(output.length!==size)throw Error('解压长度校验失败');return output;}};
}
