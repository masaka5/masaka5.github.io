import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-recurring-event-dates-v1',
  name: "重复事件日期生成器",
  slug: 'recurring-event-dates',
  description: "生成简单重复的接下来的N个日期（每日、每周、每月、每年，有间隔）。",
  category: 'time',
  tags: ['recurrence', 'schedule', 'dates', 'rrule', 'generator'],
  keywords: ['recurring dates', 'every N days', 'weekly schedule', 'monthly recurrence', 'rrule', 'occurrences'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
