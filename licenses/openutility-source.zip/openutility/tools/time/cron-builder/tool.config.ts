import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-cron-builder-v1',
  name: "Cron 表达式生成器",
  slug: 'cron-builder',
  description:
    "从具有人类可读预览的分钟、小时、天、月和工作日的下拉列表中构建标准cron表达式。",
  category: 'time',
  tags: ['cron', 'schedule', 'builder'],
  keywords: ['cron', 'crontab', 'schedule', 'builder', 'expression'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
