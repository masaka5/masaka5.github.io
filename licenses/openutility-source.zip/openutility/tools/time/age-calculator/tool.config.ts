import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-age-calculator-v1',
  name: "年龄计算器",
  slug: 'age-calculator',
  description:
    "根据出生日期以年、月、日计算精确年龄，加上总天数、小时数和下一个生日倒计时。",
  category: 'time',
  tags: ['age', 'date', 'birthday'],
  keywords: ['age', 'birthday', 'years old', 'calculate', 'date of birth'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
