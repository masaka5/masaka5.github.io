import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-date-add-subtract-v1',
  name: "添加或减去天数",
  slug: 'date-add-subtract',
  description:
    "从日期中添加或减去天、周、月或年并获得多种格式的结果日期。",
  category: 'time',
  tags: ['date', 'math', 'offset'],
  keywords: ['date math', 'add days', 'subtract', 'calculator', 'offset'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
