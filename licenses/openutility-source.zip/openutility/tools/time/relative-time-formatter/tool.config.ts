import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-relative-time-formatter-v1',
  name: "相对时间格式化程序",
  slug: 'relative-time-formatter',
  description:
    "将时间戳或日期转换为人类友好的相对短语，例如跨区域的“3小时前”或“2天内”。",
  category: 'time',
  tags: ['relative time', 'ago', 'intl'],
  keywords: ['relative time', 'ago', 'time since', 'intl', 'human readable'],
  icon: 'Clock',
  relatedTools: [],
};

export default meta;
