import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-moon-phase-calculator-v1',
  name: "月相计算器",
  slug: 'moon-phase-calculator',
  description: "通过算法估计任何日期的月相、照明百分比和月龄。",
  category: 'time',
  tags: ['moon phase', 'lunar', 'illumination', 'astronomy', 'calendar'],
  keywords: ['moon phase', 'lunar age', 'illumination', 'new moon', 'full moon', 'synodic month'],
  icon: 'Moon',
  relatedTools: [],
};

export default meta;
