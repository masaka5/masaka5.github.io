import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-cron-field-expander-v1',
  name: "Cron字段扩展器",
  slug: 'cron-field-expander',
  description: "将cron表达式的每个字段扩展为显式匹配值集合。",
  category: 'time',
  tags: ['cron', 'schedule', 'crontab', 'fields', 'expand'],
  keywords: ['cron expression', 'crontab', 'expand cron', 'cron values', 'cron fields', 'fire times'],
  icon: 'ListChecks',
  relatedTools: [],
};

export default meta;
