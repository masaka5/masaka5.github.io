import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-strftime-playground-v1',
  name: "strftime格式游乐场",
  slug: 'strftime-playground',
  description:
    "将C/Python strftime格式字符串应用于选定的日期时间并实时查看渲染的输出。",
  category: 'time',
  tags: ['strftime', 'date format', 'python', 'playground', 'format'],
  keywords: [
    'strftime',
    'date format',
    'python datetime',
    'format directives',
    'percent y',
    'time format',
  ],
  icon: 'Code',
  relatedTools: [],
};

export default meta;
