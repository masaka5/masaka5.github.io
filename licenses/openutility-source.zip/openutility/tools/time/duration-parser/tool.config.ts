import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-duration-parser-v1',
  name: "持续时间字符串解析器",
  slug: 'duration-parser',
  description: "将诸如“1h30m”、“2天4小时”或“90s”之类的人类持续时间文本解析为总秒和毫秒。",
  category: 'time',
  tags: ['duration', 'parser', 'time', 'seconds', 'milliseconds'],
  keywords: ['parse duration', 'human duration', '1h30m', 'time string', 'to seconds', 'to ms'],
  icon: 'Timer',
  relatedTools: [],
};

export default meta;
