import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-fixed-offset-timezone-math-v1',
  name: "固定UTC偏移转换器",
  slug: 'fixed-offset-timezone-math',
  description: "跨固定UTC偏移量（例如+05:30到-08:00）转换日期时间，无需猜测DST。",
  category: 'time',
  tags: ['utc offset', 'timezone', 'datetime', 'conversion', 'fixed offset'],
  keywords: ['utc offset converter', 'time zone math', 'fixed offset', 'no dst', 'half hour offset', 'gmt'],
  icon: 'Globe',
  relatedTools: [],
};

export default meta;
