import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-countdown-timer-builder-v1',
  name: "倒计时快照生成器",
  slug: 'countdown-timer-builder',
  description:
    "计算从现在到目标日期时间的准确剩余时间，分成单位。",
  category: 'time',
  tags: ['countdown', 'timer', 'remaining', 'duration', 'deadline'],
  keywords: [
    'countdown',
    'time remaining',
    'time until',
    'days until',
    'deadline',
    'duration breakdown',
    'event timer',
  ],
  icon: 'Hourglass',
  relatedTools: [],
};

export default meta;
