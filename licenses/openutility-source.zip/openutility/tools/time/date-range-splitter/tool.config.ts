import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-date-range-splitter-v1',
  name: "日期范围分割器",
  slug: 'date-range-splitter',
  description: "将日期范围分割成相等的块或固定长度的间隔（例如，每周的桶）。",
  category: 'time',
  tags: ['date', 'range', 'split', 'buckets', 'intervals'],
  keywords: ['date range split', 'date buckets', 'weekly buckets', 'chunk dates', 'reporting periods', 'date intervals'],
  icon: 'SplitSquareHorizontal',
  relatedTools: [],
};

export default meta;
