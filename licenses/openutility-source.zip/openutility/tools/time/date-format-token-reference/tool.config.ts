import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-date-format-token-reference-v1',
  name: "日期格式令牌参考",
  slug: 'date-format-token-reference',
  description: "跨时刻、日期-fns、strftime、Java和Unicode LDML的日期格式标记的可搜索备忘单。",
  category: 'time',
  tags: ['date format', 'tokens', 'cheatsheet', 'strftime', 'reference'],
  keywords: ['moment', 'date-fns', 'strftime', 'Java DateTimeFormatter', 'LDML', 'CLDR', 'format tokens', 'yyyy', '%Y'],
  icon: 'BookOpen',
  relatedTools: [],
};

export default meta;
