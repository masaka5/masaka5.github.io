import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-quarter-of-date-v1',
  name: "季度和财政期间查找器",
  slug: 'quarter-of-date',
  description:
    "确定任意日期的日历或财政季度、半期和期间日期。",
  category: 'time',
  tags: ['quarter', 'fiscal year', 'calendar', 'finance', 'period'],
  keywords: [
    'quarter',
    'fiscal year',
    'q1 q2 q3 q4',
    'half year',
    'fiscal quarter',
    'period dates',
  ],
  icon: 'ChartPie',
  relatedTools: [],
};

export default meta;
