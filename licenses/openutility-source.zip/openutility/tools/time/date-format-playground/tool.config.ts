import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-date-format-playground-v1',
  name: "Unicode 日期模式游乐场",
  slug: 'date-format-playground',
  description: "使用 Intl.DateTimeFormat 样式或 LDML 模式渲染日期时间并预览结果。",
  category: 'time',
  tags: ['date', 'format', 'intl', 'ldml', 'locale'],
  keywords: ['date format', 'intl datetimeformat', 'ldml pattern', 'locale date', 'date pattern preview', 'format tokens'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
