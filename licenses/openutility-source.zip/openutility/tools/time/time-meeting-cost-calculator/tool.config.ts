import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-time-meeting-cost-calculator-v1',
  name: "会议费用计算器",
  slug: 'time-meeting-cost-calculator',
  description: "根据与会者人数、每小时费率和持续时间来估计会议的美元成本。",
  category: 'time',
  tags: ['meeting', 'cost', 'salary', 'productivity', 'calculator'],
  keywords: [
    'meeting cost',
    'meeting price',
    'salary per hour',
    'cost of meeting',
    'attendee cost',
    'time is money',
  ],
  icon: 'HandCoins',
  relatedTools: [],
};

export default meta;
