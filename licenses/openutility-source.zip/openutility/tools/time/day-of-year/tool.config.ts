import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-day-of-year-v1',
  name: "一年中的某一天计算器",
  slug: 'day-of-year',
  description:
    "查找任意日期的一年中的序数日、一年中剩余的天数，并将序数日转换回日期。",
  category: 'time',
  tags: ['day of year', 'ordinal date', 'calendar'],
  keywords: ['day of year', 'ordinal date', 'julian day', 'remaining', 'calendar'],
  icon: 'Calendar',
  relatedTools: [],
};

export default meta;
