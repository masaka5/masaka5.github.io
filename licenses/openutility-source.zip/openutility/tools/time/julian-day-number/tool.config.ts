import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-julian-day-number-v1',
  name: "儒略日数转换器",
  slug: 'julian-day-number',
  description: "将公历日期转换为天文儒略日数/儒略日期并返回。",
  category: 'time',
  tags: ['julian day', 'astronomy', 'date', 'jdn', 'modified julian date'],
  keywords: ['julian day number', 'julian date', 'jdn', 'mjd', 'astronomical date', 'gregorian to julian'],
  icon: 'Star',
  relatedTools: [],
};

export default meta;
