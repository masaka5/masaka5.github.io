import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-epoch-precision-converter-v1',
  name: "Epoch精密转换器",
  slug: 'epoch-precision-converter',
  description: "通过自动检测在秒、毫秒、微秒和纳秒之间转换Unix时间戳。",
  category: 'time',
  tags: ['epoch', 'timestamp', 'unix', 'nanoseconds', 'precision'],
  keywords: ['epoch converter', 'unix timestamp', 'milliseconds', 'microseconds', 'nanoseconds', 'auto detect'],
  icon: 'Clock',
  relatedTools: [],
};

export default meta;
