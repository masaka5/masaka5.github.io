import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-iso-duration-parser-v1',
  name: "ISO 8601持续时间解析器",
  slug: 'iso-duration-parser',
  description:
    "将诸如P1Y2M10DT2H30M之类的ISO 8601持续时间字符串解析为总秒数和人类可读的细分。",
  category: 'time',
  tags: ['iso 8601', 'duration', 'period', 'parse'],
  keywords: ['iso 8601', 'duration', 'P1Y', 'period', 'parse'],
  icon: 'Timer',
  relatedTools: [],
};

export default meta;
