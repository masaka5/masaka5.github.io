import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-leap-year-checker-v1',
  name: "闰年检查器",
  slug: 'leap-year-checker',
  description: "检查是否有任何年份是闰年并列出邻近的闰年并解释规则。",
  category: 'time',
  tags: ['leap year', 'calendar', 'gregorian', 'february', 'date'],
  keywords: ['leap year checker', 'is leap year', '366 days', 'february 29', 'gregorian rule'],
  icon: 'Calendar',
  relatedTools: [],
};

export default meta;
