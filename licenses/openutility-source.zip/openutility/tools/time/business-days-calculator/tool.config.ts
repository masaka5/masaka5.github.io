import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-business-days-calculator-v1',
  name: "工作日计算器",
  slug: 'business-days-calculator',
  description:
    "计算两个日期之间的工作日（不包括周末），或者将多个工作日添加到开始日期。",
  category: 'time',
  tags: ['business days', 'working days', 'weekdays'],
  keywords: ['business days', 'working days', 'weekdays', 'exclude weekends', 'calculate'],
  icon: 'Calendar',
  relatedTools: [],
};

export default meta;
