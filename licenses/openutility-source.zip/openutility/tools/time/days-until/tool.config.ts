import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-days-until-v1',
  name: "截止日期的天数",
  slug: 'days-until',
  description:
    "计算今天与目标未来或过去日期之间的确切天数、周数、小时数和分钟数。",
  category: 'time',
  tags: ['countdown', 'date', 'deadline'],
  keywords: ['countdown', 'days until', 'deadline', 'remaining', 'date diff'],
  icon: 'Calendar',
  relatedTools: [],
};

export default meta;
