import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-cron-next-runs-preview-v1',
  name: "Cron Next 运行预览",
  slug: 'cron-next-runs-preview',
  description: "列出从选定的开始时间开始的 5 字段 cron 表达式的接下来的 N 个执行日期时间。",
  category: 'time',
  tags: ['cron', 'schedule', 'preview', 'crontab', 'next-runs'],
  keywords: ['cron next run', 'cron schedule preview', 'crontab', 'fire times', 'next execution', 'cron simulator'],
  icon: 'Repeat',
  relatedTools: [],
};

export default meta;
