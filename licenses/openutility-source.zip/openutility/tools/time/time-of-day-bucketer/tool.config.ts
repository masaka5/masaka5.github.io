import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-time-of-day-bucketer-v1',
  name: "一天中的时间分类器",
  slug: 'time-of-day-bucketer',
  description: "将时间分为一天中的部分（早上、下午、傍晚、夜晚）和太阳/时钟部分。",
  category: 'time',
  tags: ['time of day', 'morning', 'evening', 'greeting', 'classify'],
  keywords: [
    'part of day',
    'morning afternoon evening night',
    'good morning',
    'time bucket',
    'time segment',
    'clock period',
  ],
  icon: 'Sun',
  relatedTools: [],
};

export default meta;
