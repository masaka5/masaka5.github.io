import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-day-percentage-elapsed-v1',
  name: "已过去的天数百分比",
  slug: 'day-percentage-elapsed',
  description: "显示给定时刻已经过去了一天、一周、一个月、一年、一小时或一分钟的时间。",
  category: 'time',
  tags: ['date', 'progress', 'percentage', 'elapsed', 'year'],
  keywords: ['percent of year', 'day elapsed', 'year progress', 'time elapsed', 'week progress', 'percentage of day'],
  icon: 'Percent',
  relatedTools: [],
};

export default meta;
