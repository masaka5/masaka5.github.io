import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-ordinal-date-converter-v1',
  name: "序数日期转换器",
  slug: 'ordinal-date-converter',
  description:
    "在日历日期和序数日期（年+年中的日期，YYYY-DDD）之间转换。",
  category: 'time',
  tags: ['ordinal date', 'day of year', 'iso 8601', 'calendar', 'convert'],
  keywords: [
    'ordinal date',
    'yyyy-ddd',
    'day of year',
    'julian day',
    'iso ordinal',
    'date to ordinal',
  ],
  icon: 'ListOrdered',
  relatedTools: [],
};

export default meta;
