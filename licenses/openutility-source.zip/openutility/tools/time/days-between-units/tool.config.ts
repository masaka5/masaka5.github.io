import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-days-between-units-v1',
  name: "许多单位之间的天数",
  slug: 'days-between-units',
  description: "同时测量两个日期时间之间的跨度（以年、月、周、日、小时、分钟和秒为单位）。",
  category: 'time',
  tags: ['date', 'difference', 'duration', 'units', 'between'],
  keywords: ['days between', 'time between dates', 'date difference units', 'weeks between', 'hours between', 'business days'],
  icon: 'ArrowLeftRight',
  relatedTools: [],
};

export default meta;
