import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-iso-8601-parser-v1',
  name: "ISO 8601解析器",
  slug: 'iso-8601-parser',
  description:
    "将ISO 8601日期时间字符串分解为其组成部分（年、月、日、小时、偏移量、周）并验证它。",
  category: 'time',
  tags: ['iso 8601', 'parse', 'datetime', 'validate'],
  keywords: ['iso 8601', 'parse', 'datetime', 'offset', 'validate'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
