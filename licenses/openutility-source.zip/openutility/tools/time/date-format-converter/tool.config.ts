import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-date-format-converter-v1',
  name: "日期格式转换器",
  slug: 'date-format-converter',
  description:
    "一次性解析任何日期字符串并将其重新格式化为通用模式（ISO 8601、RFC 2822、美国、欧盟、区域设置字符串）。",
  category: 'time',
  tags: ['date format', 'iso 8601', 'rfc 2822', 'convert'],
  keywords: ['date format', 'iso 8601', 'rfc 2822', 'reformat', 'convert'],
  icon: 'Calendar',
  relatedTools: [],
};

export default meta;
