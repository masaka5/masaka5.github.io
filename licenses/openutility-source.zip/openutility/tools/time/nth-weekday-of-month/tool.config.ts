import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-nth-weekday-of-month-v1',
  name: "该月的第 N 个工作日",
  slug: 'nth-weekday-of-month',
  description:
    "查找诸如“十一月的第三个星期四”或“五月的最后一个星期一”之类的日期。",
  category: 'time',
  tags: ['weekday', 'recurring', 'calendar', 'holidays', 'schedule'],
  keywords: [
    'nth weekday',
    'last monday',
    'third thursday',
    'recurring meeting',
    'thanksgiving',
    'holiday rule',
  ],
  icon: 'Calendar',
  relatedTools: [],
};

export default meta;
