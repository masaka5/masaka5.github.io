import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-duration-humanizer-v1',
  name: "持续时间人性化器",
  slug: 'duration-humanizer',
  description: "将原始的秒数或毫秒数转换成人类短语，例如“2天，3小时，5分钟”。",
  category: 'time',
  tags: ['duration', 'humanize', 'seconds', 'format', 'time'],
  keywords: ['humanize duration', 'seconds to human', 'milliseconds to time', 'format duration', 'pretty time', 'time ago'],
  icon: 'Hourglass',
  relatedTools: [],
};

export default meta;
