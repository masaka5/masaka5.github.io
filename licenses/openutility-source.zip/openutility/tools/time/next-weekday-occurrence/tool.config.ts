import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-next-weekday-occurrence-v1',
  name: "下一个工作日发生的情况",
  slug: 'next-weekday-occurrence',
  description: "查找从开始日期算起的选定工作日的下一个（或第N个）日期。",
  category: 'time',
  tags: ['weekday', 'date', 'calendar', 'next', 'occurrence'],
  keywords: ['next monday', 'nth weekday', 'next weekday', 'upcoming day', 'find weekday date'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
