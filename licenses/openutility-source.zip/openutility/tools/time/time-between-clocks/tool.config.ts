import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-time-between-clocks-v1',
  name: "时钟时间差",
  slug: 'time-between-clocks',
  description:
    "计算一天中两个时间之间的持续时间，可选地结束午夜之后。",
  category: 'time',
  tags: ['duration', 'clock', 'shift', 'difference', 'overnight'],
  keywords: [
    'time difference',
    'shift length',
    'hours worked',
    'overnight duration',
    'clock math',
    'elapsed time',
  ],
  icon: 'Clock3',
  relatedTools: [],
};

export default meta;
