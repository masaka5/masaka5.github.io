import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-time-12-24-converter-v1',
  name: "12 / 24 小时时间转换器",
  slug: 'time-12-24-converter',
  description:
    "在12小时AM/PM和24小时格式之间转换时钟时间，单个或批量。",
  category: 'time',
  tags: ['12 hour', '24 hour', 'am pm', 'clock', 'convert'],
  keywords: [
    '12 hour to 24 hour',
    'am pm',
    'military time',
    'clock format',
    'time converter',
    'bulk time',
  ],
  icon: 'Clock3',
  relatedTools: [],
};

export default meta;
