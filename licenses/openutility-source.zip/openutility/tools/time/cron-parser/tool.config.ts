import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-cron-parser-v1',
  name: "Cron表达式解释器",
  slug: 'cron-parser',
  description: "用简单的英语解释cron表达式并预览下一个运行时间。",
  category: 'time',
  tags: ['cron', 'crontab', 'schedule', 'parser', 'explain'],
  keywords: ['cron', 'crontab', 'schedule', 'cron expression', 'next run', 'explain cron'],
  icon: 'CalendarClock',
  relatedTools: ['timestamp-converter', 'date-difference', 'gitignore-generator'],
};

export default meta;
