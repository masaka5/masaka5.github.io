import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-date-difference-v1',
  name: "日期差异",
  slug: 'date-difference',
  description: "计算两个日期之间的持续时间（以年、日、小时等为单位）。",
  category: 'time',
  tags: ['date', 'difference', 'duration', 'age', 'between'],
  keywords: ['date difference', 'duration', 'days between', 'age calculator', 'time between'],
  icon: 'Calendar',
  relatedTools: ['timestamp-converter', 'cron-parser', 'percentage-calculator'],
};

export default meta;
