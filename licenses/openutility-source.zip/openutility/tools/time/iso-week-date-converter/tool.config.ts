import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-iso-week-date-converter-v1',
  name: "ISO周日期转换器",
  slug: 'iso-week-date-converter',
  description: "在日历日期与其ISO-8601周日期形式(YYYY-Www-D)之间进行转换。",
  category: 'time',
  tags: ['iso 8601', 'week date', 'calendar', 'week number', 'conversion'],
  keywords: ['iso week date', 'yyyy-www-d', 'week year', '53 week year', 'week number converter'],
  icon: 'CalendarDays',
  relatedTools: [],
};

export default meta;
