import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'time-add-business-days-v1',
  name: "添加工作日",
  slug: 'add-business-days',
  description:
    "在日期中添加或减去多个工作日，跳过周末和自定义假期。",
  category: 'time',
  tags: ['business', 'days', 'workdays', 'date', 'holidays'],
  keywords: [
    'add business days',
    'working days',
    'skip weekends',
    'holidays',
    'date offset',
    'deadline calculator',
    'workday',
  ],
  icon: 'CalendarDays',
  relatedTools: [],
};

export default meta;
