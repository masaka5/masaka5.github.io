import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-box-shadow-generator-v1',
  name: "CSS盒子阴影生成器",
  slug: 'web-box-shadow-generator',
  description:
    "利用实时预览和可复制代码，以视觉方式制作具有偏移、模糊、扩散、颜色、不透明度和插入控件的CSS框阴影。",
  category: 'web',
  tags: ['css', 'box-shadow', 'design'],
  keywords: ['css', 'box-shadow', 'shadow', 'generator', 'preview', 'design'],
  icon: 'Layers',
  relatedTools: [],
};

export default meta;
