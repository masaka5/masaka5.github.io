import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-spf-flattening-analyzer-v1",
  name: "SPF平展分析仪",
  slug: "spf-flattening-analyzer",
  description: "在扁平化之前对SPF机制进行计数并估计DNS查找压力。",
  category: "web",
  tags: ["spf","dns","email","analysis"],
  keywords: ["spf","dns","email","analysis"],
  icon: "FileSearch",
  relatedTools: [],
};

export default meta;
