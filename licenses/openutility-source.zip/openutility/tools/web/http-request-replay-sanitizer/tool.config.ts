import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-http-request-replay-sanitizer-v1",
  name: "HTTP请求重放消毒剂",
  slug: "http-request-replay-sanitizer",
  description: "从捕获的HTTP请求中编辑秘密并发出更安全的重放片段。",
  category: "web",
  tags: ["http","request","redact","debug"],
  keywords: ["http","request","redact","debug"],
  icon: "Eraser",
  relatedTools: [],
};

export default meta;
