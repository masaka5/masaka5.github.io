import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cookie-string-builder-v1',
  name: "设置-Cookie字符串生成器",
  slug: 'web-cookie-string-builder',
  description:
    "通过验证从名称、值和属性构建Set-Cookie标头。",
  category: 'web',
  tags: ['http', 'cookies', 'headers', 'security', 'samesite'],
  keywords: [
    'set-cookie',
    'samesite',
    'httponly',
    'secure',
    'max-age',
    'partitioned',
    '__host-',
    'cookie header',
  ],
  icon: 'Cookie',
  relatedTools: [],
};

export default meta;
