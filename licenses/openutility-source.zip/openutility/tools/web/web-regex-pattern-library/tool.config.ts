import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-regex-pattern-library-v1',
  name: "通用正则表达式模式库",
  slug: 'web-regex-pattern-library',
  description:
    "用于电子邮件、URL、IP、日期和其他常见验证的准备复制的正则表达式模式的可搜索参考。",
  category: 'web',
  tags: ['regex', 'patterns', 'reference', 'validation', 'cheatsheet'],
  keywords: [
    'regular expression',
    'regex library',
    'email regex',
    'url regex',
    'ipv4',
    'uuid',
    'validation pattern',
    'common regex',
  ],
  icon: 'BookOpen',
  relatedTools: [],
};

export default meta;
