import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cron-explainer-v1',
  name: "Cron 表达式解释器（高级）",
  slug: 'web-cron-explainer',
  description:
    "将 cron 表达式翻译成简单的英语并列出接下来的几个运行时间，支持所有五个字段的范围、步骤和列表。",
  category: 'web',
  tags: ['cron', 'schedule', 'crontab'],
  keywords: ['cron', 'schedule', 'crontab', 'explain', 'next-run', 'expression'],
  icon: 'CalendarClock',
  relatedTools: [],
};

export default meta;
