import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-data-uri-builder-text-v1',
  name: "文本数据URI生成器",
  slug: 'web-data-uri-builder-text',
  description:
    "使用MIME类型、字符集和base64选项从粘贴的文本构建数据：URI。",
  category: 'web',
  tags: ['data-uri', 'base64', 'encode', 'svg', 'inline'],
  keywords: [
    'data uri',
    'data url',
    'base64',
    'percent encode',
    'inline svg',
    'mime type',
    'embed',
  ],
  icon: 'Braces',
  relatedTools: [],
};

export default meta;
