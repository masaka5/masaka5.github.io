import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-flatten-v1',
  name: "JSON 展平/取消展平（Web）",
  slug: 'web-json-flatten',
  description:
    "将深度嵌套的JSON对象展平为单级点符号键，或者从展平的键重建嵌套结构。",
  category: 'web',
  tags: ['json', 'flatten', 'transform'],
  keywords: ['json', 'flatten', 'nested', 'unflatten', 'dot-notation', 'transform'],
  icon: 'AlignJustify',
  relatedTools: [],
};

export default meta;
