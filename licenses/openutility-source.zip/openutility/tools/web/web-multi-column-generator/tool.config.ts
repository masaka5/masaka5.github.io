import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-multi-column-generator-v1',
  name: "CSS多列布局生成器",
  slug: 'web-multi-column-generator',
  description:
    "使用实时文本预览生成CSS列属性（计数、宽度、间隙、规则）。",
  category: 'web',
  tags: ['css', 'columns', 'layout', 'multicol'],
  keywords: [
    'css columns',
    'multi-column',
    'column-count',
    'column-gap',
    'column-rule',
    'column-fill',
    'layout',
  ],
  icon: 'AlignJustify',
  relatedTools: [],
};

export default meta;
