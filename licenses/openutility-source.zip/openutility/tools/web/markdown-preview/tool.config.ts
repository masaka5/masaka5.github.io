import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-markdown-preview-v1',
  name: "Markdown 到 HTML",
  slug: 'markdown-to-html',
  description: "通过实时预览和可复制输出将 Markdown 渲染为 HTML。",
  category: 'web',
  tags: ['markdown', 'md', 'html', 'preview', 'render'],
  keywords: ['markdown', 'md to html', 'preview', 'render markdown', 'gfm'],
  icon: 'FileCode',
  relatedTools: ['html-to-text', 'html-entities', 'json-formatter'],
};

export default meta;
