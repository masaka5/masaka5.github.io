import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-url-builder-v1',
  name: "URL生成器",
  slug: 'web-url-builder',
  description:
    "从单独的方案、主机、端口、路径、查询和片段字段组装有效的URL。",
  category: 'web',
  tags: ['url', 'query', 'builder', 'encode', 'whatwg'],
  keywords: [
    'url builder',
    'query string',
    'percent encoding',
    'scheme',
    'host',
    'fragment',
    'whatwg url',
    'encodeuricomponent',
  ],
  icon: 'Link',
  relatedTools: [],
};

export default meta;
