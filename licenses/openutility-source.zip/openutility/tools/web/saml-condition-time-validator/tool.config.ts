import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-condition-time-validator-v1",
  name: "SAML条件时间验证器",
  slug: "saml-condition-time-validator",
  description: "使用可配置的时钟偏差来验证NotBefore和NotOnOrAfter时间戳。",
  category: "web",
  tags: ["saml","time","condition","sso"],
  keywords: ["saml","time","condition","sso"],
  icon: "Clock",
  relatedTools: [],
};

export default meta;
