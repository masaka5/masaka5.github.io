import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-button-generator-v1',
  name: "CSS按钮生成器",
  slug: 'web-css-button-generator',
  description:
    "设计按钮(颜色、填充、半径、阴影、悬停)并复制CSS。",
  category: 'web',
  tags: ['css', 'button', 'ui', 'design', 'generator'],
  keywords: [
    'css button',
    'hover',
    'border-radius',
    'box-shadow',
    'button styles',
    'transition',
  ],
  icon: 'Pointer',
  relatedTools: [],
};

export default meta;
