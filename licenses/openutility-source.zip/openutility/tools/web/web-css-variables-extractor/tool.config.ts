import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-variables-extractor-v1',
  name: "CSS自定义属性提取器",
  slug: 'web-css-variables-extractor',
  description:
    "扫描 CSS 并列出所有 --custom-properties 和 var() 用法及其值。",
  category: 'web',
  tags: ['css', 'variables', 'var', 'audit', 'custom-properties'],
  keywords: [
    'css variables',
    'var()',
    'custom properties',
    'usage audit',
    'undeclared',
    'unused',
    'design tokens',
  ],
  icon: 'Variable',
  relatedTools: [],
};

export default meta;
