import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dns-zone-file-validator-v1",
  name: "DNS 区域文件验证器",
  slug: "dns-zone-file-validator",
  description: "检查区域文件记录中常见的 SOA、NS、MX、CNAME、TTL 和语法问题。",
  category: "web",
  tags: ["dns","zone","records","validation"],
  keywords: ["dns","zone","records","validation"],
  icon: "FileSearch",
  relatedTools: [],
};

export default meta;
