import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cache-control-builder-v1',
  name: "高速缓存控制生成器",
  slug: 'web-cache-control-builder',
  description:
    "根据缓存指令复选框和持续时间组成并解释缓存控制报头。",
  category: 'web',
  tags: ['http', 'cache', 'headers', 'cdn', 'performance'],
  keywords: [
    'cache-control',
    'max-age',
    's-maxage',
    'no-store',
    'immutable',
    'stale-while-revalidate',
    'http header',
  ],
  icon: 'Clock3',
  relatedTools: [],
};

export default meta;
