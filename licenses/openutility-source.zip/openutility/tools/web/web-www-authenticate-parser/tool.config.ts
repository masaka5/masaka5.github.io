import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-www-authenticate-parser-v1',
  name: "WWW-验证解析器",
  slug: 'web-www-authenticate-parser',
  description: "将 WWW-Authenticate / Authorization 质询标头解析为方案和参数。",
  category: 'web',
  tags: ['http', 'auth', 'header', 'bearer', 'parser'],
  keywords: ['www-authenticate', 'proxy-authenticate', 'digest', 'basic', 'oauth', 'challenge', 'realm'],
  icon: 'LockKeyhole',
  relatedTools: [],
};

export default meta;
