import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-triangle-generator-v1',
  name: "CSS三角形生成器",
  slug: 'web-css-triangle-generator',
  description:
    "使用任意方向和尺寸的边框技巧创建纯CSS三角形。",
  category: 'web',
  tags: ['css', 'triangle', 'border-trick', 'shapes', 'design'],
  keywords: [
    'css triangle',
    'border trick',
    'arrow',
    'caret',
    'tooltip arrow',
    'pure css shape',
  ],
  icon: 'Triangle',
  relatedTools: [],
};

export default meta;
