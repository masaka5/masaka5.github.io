import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-regex-escape-v1',
  name: "正则表达式转义/Unescape",
  slug: 'web-regex-escape',
  description: "将任意文本转义为文字正则表达式模式或将转义模式转义回纯文本。",
  category: 'web',
  tags: ['regex', 'escape', 'pattern', 'literal', 'text'],
  keywords: ['regex escape', 'regexp escape', 'literal pattern', 'escape special characters', 'unescape regex', 'metacharacters'],
  icon: 'Regex',
  relatedTools: [],
};

export default meta;
