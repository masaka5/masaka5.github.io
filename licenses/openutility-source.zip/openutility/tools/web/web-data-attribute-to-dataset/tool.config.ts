import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-data-attribute-to-dataset-v1',
  name: "HTML数据-*到JS数据集转换器",
  slug: 'web-data-attribute-to-dataset',
  description:
    "将data-*属性转换为element.dataset访问表达式并返回。",
  category: 'web',
  tags: ['html', 'dataset', 'data-attribute', 'javascript', 'convert'],
  keywords: [
    'data attribute',
    'dataset',
    'camelcase',
    'kebab-case',
    'data-*',
    'html',
    'javascript',
  ],
  icon: 'Braces',
  relatedTools: [],
};

export default meta;
