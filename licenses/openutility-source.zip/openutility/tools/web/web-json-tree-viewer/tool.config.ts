import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-tree-viewer-v1',
  name: "JSON 到漂亮/树",
  slug: 'web-json-tree-viewer',
  description:
    "将 JSON 可视化为具有类型注释和节点计数的可折叠缩进树，使得大型嵌套有效负载易于导航。",
  category: 'web',
  tags: ['json', 'tree', 'viewer'],
  keywords: ['json', 'tree', 'viewer', 'visualize', 'collapse', 'explore'],
  icon: 'List',
  relatedTools: [],
};

export default meta;
