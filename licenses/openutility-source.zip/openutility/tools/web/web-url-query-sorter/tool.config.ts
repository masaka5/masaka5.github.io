import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-url-query-sorter-v1',
  name: "URL查询参数排序器",
  slug: 'web-url-query-sorter',
  description: "通过对查询参数进行排序和可选地去重复来规范化URL。",
  category: 'web',
  tags: ['url', 'query', 'sort', 'canonical', 'params'],
  keywords: ['querystring', 'normalize', 'dedupe', 'search params', 'canonicalize url', 'order'],
  icon: 'ArrowDownUp',
  relatedTools: [],
};

export default meta;
