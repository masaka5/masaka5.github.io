import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-jwt-expiry-inspector-v1',
  name: "JWT 过期检查器",
  slug: 'web-jwt-expiry-inspector',
  description: "解码JWT并报告人类可读的发布/到期时间和剩余有效性。",
  category: 'web',
  tags: ['jwt', 'token', 'expiry', 'auth', 'decode'],
  keywords: ['jwt', 'json web token', 'exp', 'iat', 'nbf', 'expiry', 'validity', 'bearer', 'auth token'],
  icon: 'Clock3',
  relatedTools: [],
};

export default meta;
