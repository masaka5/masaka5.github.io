import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-html-attributes-stripper-v1',
  name: "HTML 属性剥离器/标签清理器",
  slug: 'web-html-attributes-stripper',
  description: "从HTML中移除选定的属性(样式、类、on*、data-*)或整个标签。",
  category: 'web',
  tags: ['html', 'sanitize', 'clean', 'strip', 'attributes'],
  keywords: ['remove style', 'strip class', 'clean html', 'sanitize paste', 'remove tags', 'data attributes'],
  icon: 'Eraser',
  relatedTools: [],
};

export default meta;
