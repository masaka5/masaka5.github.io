import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-transition-generator-v1',
  name: "CSS 过渡生成器",
  slug: 'web-transition-generator',
  description:
    "根据属性、持续时间、定时函数和延迟构建转换速记。",
  category: 'web',
  tags: ['css', 'transition', 'animation', 'easing', 'generator'],
  keywords: [
    'css transition',
    'transition shorthand',
    'timing function',
    'cubic-bezier',
    'duration',
    'delay',
    'ease',
    'longhand',
  ],
  icon: 'ArrowLeftRight',
  relatedTools: [],
};

export default meta;
