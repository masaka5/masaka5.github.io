import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-soap-request-debugger-v1",
  name: "SOAP请求调试器",
  slug: "soap-request-debugger",
  description: "检查SOAP HTTP标头、信封版本、操作和主体有效负载。",
  category: "web",
  tags: ["soap","http","xml","debug"],
  keywords: ["soap","http","xml","debug"],
  icon: "Bug",
  relatedTools: [],
};

export default meta;
