import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-relative-url-resolver-v1',
  name: "相对URL解析器",
  slug: 'web-relative-url-resolver',
  description:
    "解析针对基本URL的相对引用以产生绝对目标。",
  category: 'web',
  tags: ['url', 'relative', 'resolve', 'base', 'absolute'],
  keywords: ['rfc 3986', 'reference resolution', 'href', 'dot segments', 'scheme relative'],
  icon: 'Navigation',
  relatedTools: [],
};

export default meta;
