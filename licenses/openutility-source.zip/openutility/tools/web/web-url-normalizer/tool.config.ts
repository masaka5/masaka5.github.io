import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-url-normalizer-v1',
  name: "URL规范器",
  slug: 'web-url-normalizer',
  description:
    "通过小写主机、解析点段、排序参数和剥离默认值来规范化URL。",
  category: 'web',
  tags: ['url', 'normalize', 'canonical', 'query', 'rfc 3986'],
  keywords: ['canonicalize', 'sort params', 'dedupe', 'trailing slash', 'default port', 'cleanup'],
  icon: 'Route',
  relatedTools: [],
};

export default meta;
