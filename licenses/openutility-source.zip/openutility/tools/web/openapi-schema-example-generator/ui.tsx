'use client';

import { DeveloperToolPage } from '@/tools/_shared/developer-workbench';

export default function GeneratedDeveloperTool() {
  return <DeveloperToolPage slug="openapi-schema-example-generator" />;
}
