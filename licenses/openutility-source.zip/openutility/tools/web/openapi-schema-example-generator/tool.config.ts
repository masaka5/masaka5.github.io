import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-openapi-schema-example-generator-v1",
  name: "OpenAPI模式示例生成器",
  slug: "openapi-schema-example-generator",
  description: "从OpenAPI组件模式生成JSON示例。",
  category: "web",
  tags: ["openapi","schema","example","json"],
  keywords: ["openapi","schema","example","json"],
  icon: "Braces",
  relatedTools: [],
};

export default meta;
