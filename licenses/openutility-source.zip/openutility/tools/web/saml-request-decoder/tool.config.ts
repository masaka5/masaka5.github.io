import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-request-decoder-v1",
  name: "SAML请求解码器",
  slug: "saml-request-decoder",
  description: "从URL、查询字符串或表单输入解码SAMLRequest并检查XML。",
  category: "web",
  tags: ["saml","sso","decode","xml"],
  keywords: ["samlrequest","redirect binding","base64","deflate"],
  icon: "ShieldCheck",
  relatedTools: [],
};

export default meta;
