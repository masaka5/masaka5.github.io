import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-ip-address-converter-v1',
  name: "IP地址转换器",
  slug: 'web-ip-address-converter',
  description: "在点分、整数、十六进制、二进制和扩展形式之间转换IPv4/IPv6地址。",
  category: 'web',
  tags: ['ip', 'ipv4', 'ipv6', 'convert', 'network'],
  keywords: ['ip to integer', 'ip to hex', 'ip to binary', 'ipv6 expand', 'rfc 5952', 'ipv4-mapped', 'dotted decimal'],
  icon: 'ArrowLeftRight',
  relatedTools: [],
};

export default meta;
