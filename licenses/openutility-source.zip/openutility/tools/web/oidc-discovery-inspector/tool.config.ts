import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-oidc-discovery-inspector-v1",
  name: "OIDC发现检查员",
  slug: "oidc-discovery-inspector",
  description: "解析OpenID Connect发现元数据并总结端点、算法和授权。",
  category: "web",
  tags: ["oidc","openid","oauth","json"],
  keywords: ["oidc","openid","oauth","json"],
  icon: "Compass",
  relatedTools: [],
};

export default meta;
