import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dmarc-report-xml-parser-v1",
  name: "DMARC报告XML解析器",
  slug: "dmarc-report-xml-parser",
  description: "将聚合 DMARC XML 报告解析为源 IP、计数、处置和验证结果。",
  category: "web",
  tags: ["dmarc","xml","email","reports"],
  keywords: ["dmarc","xml","email","reports"],
  icon: "FileSearch",
  relatedTools: [],
};

export default meta;
