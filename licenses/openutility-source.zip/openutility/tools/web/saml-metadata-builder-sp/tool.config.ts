import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-metadata-builder-sp-v1",
  name: "SAML SP元数据生成器",
  slug: "saml-metadata-builder-sp",
  description: "构建用于SAML集成的服务提供商元数据。",
  category: "web",
  tags: ["saml","metadata","sp","xml"],
  keywords: ["saml","metadata","sp","xml"],
  icon: "FilePlus",
  relatedTools: [],
};

export default meta;
