import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-scim-filter-tester-v1",
  name: "SCIM 过滤器测试仪",
  slug: "scim-filter-tester",
  description: "针对粘贴的示例用户测试基本 SCIM 过滤器表达式。",
  category: "web",
  tags: ["scim","filter","identity","json"],
  keywords: ["scim","filter","identity","json"],
  icon: "Filter",
  relatedTools: [],
};

export default meta;
