import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-redirect-binding-builder-v1",
  name: "SAML重定向绑定生成器",
  slug: "saml-redirect-binding-builder",
  description: "构建SAML HTTP重定向绑定使用的URL参数。",
  category: "web",
  tags: ["saml","redirect","binding","sso"],
  keywords: ["saml redirect","relaystate","samlrequest"],
  icon: "Route",
  relatedTools: [],
};

export default meta;
