import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-to-java-v1',
  name: "JSON到Java类",
  slug: 'web-json-to-java',
  description:
    "将JSON有效负载转换成具有类型化字段和getter/setter的POJO Java类定义，推断嵌套类和集合泛型。",
  category: 'web',
  tags: ['json', 'java', 'codegen'],
  keywords: ['json', 'java', 'pojo', 'class', 'codegen', 'model'],
  icon: 'FileCode',
  relatedTools: [],
};

export default meta;
