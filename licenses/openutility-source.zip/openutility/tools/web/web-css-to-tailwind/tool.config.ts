import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-to-tailwind-v1',
  name: "CSS 到 Tailwind",
  slug: 'web-css-to-tailwind',
  description:
    "将常见的CSS声明转换为等效的Tailwind实用程序类，映射间距、颜色、flex、字体和边框属性。",
  category: 'web',
  tags: ['css', 'tailwind', 'convert'],
  keywords: ['css', 'tailwind', 'convert', 'utility', 'classes', 'frontend'],
  icon: 'Wand2',
  relatedTools: [],
};

export default meta;
