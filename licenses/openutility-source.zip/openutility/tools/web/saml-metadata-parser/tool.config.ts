import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-metadata-parser-v1",
  name: "SAML元数据解析器",
  slug: "saml-metadata-parser",
  description: "解析SAML实体元数据并列出端点、证书、绑定和实体ID。",
  category: "web",
  tags: ["saml","metadata","xml","sso"],
  keywords: ["saml","metadata","xml","sso"],
  icon: "FileSearch",
  relatedTools: [],
};

export default meta;
