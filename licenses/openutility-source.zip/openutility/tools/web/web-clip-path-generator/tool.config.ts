import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-clip-path-generator-v1',
  name: "CSS剪辑路径形状生成器",
  slug: 'web-clip-path-generator',
  description:
    "通过实时预览生成多边形、圆形、椭圆形和插入剪辑路径值。",
  category: 'web',
  tags: ['css', 'clip-path', 'shapes', 'polygon', 'design'],
  keywords: [
    'clip-path',
    'polygon',
    'circle',
    'ellipse',
    'inset',
    'css shape',
    'mask',
  ],
  icon: 'Shapes',
  relatedTools: [],
};

export default meta;
