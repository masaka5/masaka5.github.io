import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dnssec-chain-visualizer-v1",
  name: "DNSSEC 链可视化工具",
  slug: "dnssec-chain-visualizer",
  description: "检查粘贴的DS、DNSKEY、RRSIG和NSEC记录并概述信任链。",
  category: "web",
  tags: ["dnssec","dns","security","records"],
  keywords: ["dnssec","dns","security","records"],
  icon: "ShieldCheck",
  relatedTools: [],
};

export default meta;
