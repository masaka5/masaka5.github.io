import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-unit-converter-v1',
  name: "CSS单位转换器(px/rem/em/pt/%)",
  slug: 'web-css-unit-converter',
  description: "使用根和底数在px、rem、em、pt、pc、vw/vh和百分比之间进行转换。",
  category: 'web',
  tags: ['css', 'units', 'px', 'rem', 'convert'],
  keywords: ['px to rem', 'em', 'pt', 'pc', 'vw', 'vh', 'percent', 'font-size', 'absolute', 'relative'],
  icon: 'Ruler',
  relatedTools: [],
};

export default meta;
