import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-assertion-inspector-v1",
  name: "SAML 断言检查器",
  slug: "saml-assertion-inspector",
  description: "从SAML断言中提取主题、发行者、受众、会话和属性。",
  category: "web",
  tags: ["saml","assertion","attributes","sso"],
  keywords: ["saml","assertion","attributes","sso"],
  icon: "FileSearch",
  relatedTools: [],
};

export default meta;
