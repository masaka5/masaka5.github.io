import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-soap-action-header-builder-v1",
  name: "SOAPAction 标头生成器",
  slug: "soap-action-header-builder",
  description: "为 SOAP 1.1 或 1.2 请求构建 SOAPAction 和 Content-Type 标头。",
  category: "web",
  tags: ["soap","headers","http","api"],
  keywords: ["soap","headers","http","api"],
  icon: "FileCog",
  relatedTools: [],
};

export default meta;
