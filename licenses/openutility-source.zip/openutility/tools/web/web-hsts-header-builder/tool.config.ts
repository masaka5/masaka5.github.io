import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-hsts-header-builder-v1',
  name: "HSTS报头生成器",
  slug: 'web-hsts-header-builder',
  description:
    "利用预加载资格检查构建并解码严格传输安全报头。",
  category: 'web',
  tags: ['hsts', 'http', 'security', 'headers', 'preload', 'https'],
  keywords: [
    'strict-transport-security',
    'hsts',
    'max-age',
    'includeSubDomains',
    'preload',
    'hstspreload',
    'https',
    'security header',
  ],
  icon: 'Lock',
  relatedTools: [],
};

export default meta;
