import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-content-disposition-builder-v1',
  name: "内容配置生成器",
  slug: 'web-content-disposition-builder',
  description:
    "使用RFC 5987文件名编码构建并解析内容处置标头。",
  category: 'web',
  tags: ['http', 'header', 'download', 'content-disposition', 'rfc5987'],
  keywords: [
    'content-disposition',
    'attachment',
    'inline',
    'filename',
    'rfc 5987',
    'download header',
    'http header',
  ],
  icon: 'FileOutput',
  relatedTools: [],
};

export default meta;
