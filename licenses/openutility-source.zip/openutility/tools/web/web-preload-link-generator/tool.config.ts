import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-preload-link-generator-v1',
  name: "资源提示链接生成器",
  slug: 'web-preload-link-generator',
  description:
    "生成预加载、预取、预连接和dns-预取链接标签。",
  category: 'web',
  tags: ['performance', 'preload', 'resource-hints', 'html'],
  keywords: [
    'preload',
    'prefetch',
    'preconnect',
    'dns-prefetch',
    'modulepreload',
    'resource hints',
    'link rel',
    'performance',
  ],
  icon: 'Rocket',
  relatedTools: [],
};

export default meta;
