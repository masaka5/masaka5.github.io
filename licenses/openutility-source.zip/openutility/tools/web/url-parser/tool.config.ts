import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-url-parser-v1',
  name: "URL解析器",
  slug: 'url-parser',
  description: "将URL分解为协议、主机、路径、查询参数和散列。",
  category: 'web',
  tags: ['url', 'parse', 'query', 'components', 'uri'],
  keywords: ['url parser', 'query string', 'parse url', 'components', 'parameters'],
  icon: 'Link',
  relatedTools: ['url-encode', 'query-params', 'jwt-decoder'],
};

export default meta;
