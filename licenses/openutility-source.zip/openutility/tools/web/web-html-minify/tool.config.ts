import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-html-minify-v1',
  name: "HTML 缩小器/美化器",
  slug: 'web-html-minify',
  description: "通过去除注释和空白来缩小 HTML，或者对其进行漂亮的打印。",
  category: 'web',
  tags: ['html', 'minify', 'beautify', 'format', 'whitespace'],
  keywords: ['html minify', 'compress html', 'pretty print', 'indent html', 'strip comments', 'collapse whitespace'],
  icon: 'FileCode',
  relatedTools: [],
};

export default meta;
