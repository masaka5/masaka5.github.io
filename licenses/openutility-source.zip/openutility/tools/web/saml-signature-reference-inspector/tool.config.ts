import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-signature-reference-inspector-v1",
  name: "SAML签名参考检查器",
  slug: "saml-signature-reference-inspector",
  description: "检查XML签名方法、引用、转换、摘要和嵌入证书。",
  category: "web",
  tags: ["saml","signature","xml","security"],
  keywords: ["saml","signature","xml","security"],
  icon: "Fingerprint",
  relatedTools: [],
};

export default meta;
