import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-mta-sts-policy-checker-v1",
  name: "MTA-STS策略检查器",
  slug: "mta-sts-policy-checker",
  description: "验证MTA-STS TXT和策略文件内容以用于安全入站邮件递送。",
  category: "web",
  tags: ["mta-sts","email","tls","dns"],
  keywords: ["mta-sts","email","tls","dns"],
  icon: "ShieldCheck",
  relatedTools: [],
};

export default meta;
