import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-soap-fault-parser-v1",
  name: "SOAP错误解析器",
  slug: "soap-fault-parser",
  description: "将SOAP 1.1/1.2故障解析为代码、原因、参与者/节点、角色和细节。",
  category: "web",
  tags: ["soap","fault","xml","debug"],
  keywords: ["soap","fault","xml","debug"],
  icon: "FileX",
  relatedTools: [],
};

export default meta;
