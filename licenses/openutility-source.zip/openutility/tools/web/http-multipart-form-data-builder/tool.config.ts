import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-http-multipart-form-data-builder-v1",
  name: "多部分表格数据生成器",
  slug: "http-multipart-form-data-builder",
  description: "从字段定义构建多部分/表单数据主体和cURL片段。",
  category: "web",
  tags: ["http","multipart","form-data","api"],
  keywords: ["http","multipart","form-data","api"],
  icon: "Rows3",
  relatedTools: [],
};

export default meta;
