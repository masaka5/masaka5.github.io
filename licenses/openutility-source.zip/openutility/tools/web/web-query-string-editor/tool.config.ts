import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-query-string-editor-v1',
  name: "查询字符串编辑器",
  slug: 'web-query-string-editor',
  description: "在交互式键/值表中编辑、添加、重新排序、重复数据删除和排序URL查询参数。",
  category: 'web',
  tags: ['url', 'query', 'editor', 'params', 'table'],
  keywords: ['query string editor', 'url params', 'searchparams', 'edit query', 'sort params', 'dedupe params', 'querystring builder'],
  icon: 'TableProperties',
  relatedTools: [],
};

export default meta;
