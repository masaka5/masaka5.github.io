import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-oidc-id-token-validator-v1",
  name: "OIDC ID令牌验证器",
  slug: "oidc-id-token-validator",
  description: "解码ID令牌并检查发行者、受众、随机数、到期日和时钟声明。",
  category: "web",
  tags: ["oidc","jwt","token","auth"],
  keywords: ["oidc","jwt","token","auth"],
  icon: "ShieldCheck",
  relatedTools: [],
};

export default meta;
