import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-srcset-density-calculator-v1',
  name: "响应式图像宽度规划器",
  slug: 'web-srcset-density-calculator',
  description: "根据布局和断点计算srcset宽度描述符和尺寸。",
  category: 'web',
  tags: ['srcset', 'responsive', 'images', 'dpr', 'sizes'],
  keywords: ['width descriptor', 'breakpoint', 'retina', '2x 3x', 'sizes attribute', 'picture', 'image widths'],
  icon: 'Images',
  relatedTools: [],
};

export default meta;
