import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-html-class-attr-extractor-v1',
  name: "HTML 类和 ID 提取器",
  slug: 'web-html-class-attr-extractor',
  description:
    "提取 HTML 片段中使用的每个唯一的类名称和 ID，并将它们输出为排序列表或 CSS 存根。",
  category: 'web',
  tags: ['html', 'css', 'class', 'id', 'extract'],
  keywords: ['class names', 'id selectors', 'css stub', 'selector list', 'unique classes', 'dom parser'],
  icon: 'Tags',
  relatedTools: [],
};

export default meta;
