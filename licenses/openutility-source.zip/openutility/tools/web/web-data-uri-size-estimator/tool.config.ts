import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-data-uri-size-estimator-v1',
  name: "数据URI大小估计器",
  slug: 'web-data-uri-size-estimator',
  description: "在嵌入之前估计给定原始文件大小的 Base64 数据 URI 的字节大小和开销。",
  category: 'web',
  tags: ['data-uri', 'base64', 'size', 'overhead', 'estimate'],
  keywords: ['data url', 'inline image', 'embed', 'encoding overhead', 'base64 size', 'bytes', 'kb'],
  icon: 'Gauge',
  relatedTools: [],
};

export default meta;
