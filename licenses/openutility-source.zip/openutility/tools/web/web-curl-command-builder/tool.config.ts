import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-curl-command-builder-v1',
  name: "cURL 命令生成器",
  slug: 'web-curl-command-builder',
  description:
    "从方法、URL、标头、正文和身份验证字段构建完整的curl命令。",
  category: 'web',
  tags: ['curl', 'http', 'request', 'api', 'builder', 'command'],
  keywords: [
    'curl',
    'command builder',
    'http request',
    'rest',
    'headers',
    'basic auth',
    'form data',
    'shell',
  ],
  icon: 'Terminal',
  relatedTools: [],
};

export default meta;
