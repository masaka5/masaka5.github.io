import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-attribute-mapper-v1",
  name: "SAML属性映射器",
  slug: "saml-attribute-mapper",
  description: "使用简单的映射表将SAML属性映射到应用程序声明。",
  category: "web",
  tags: ["saml","attributes","mapping","sso"],
  keywords: ["saml","attributes","mapping","sso"],
  icon: "Shuffle",
  relatedTools: [],
};

export default meta;
