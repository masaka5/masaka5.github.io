import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-permissions-policy-builder-v1',
  name: "权限-策略生成器",
  slug: 'web-permissions-policy-builder',
  description:
    "从每个功能允许列表构建权限-策略（功能-策略）标头。",
  category: 'web',
  tags: ['security', 'headers', 'permissions-policy', 'feature-policy'],
  keywords: [
    'permissions-policy',
    'feature-policy',
    'header',
    'allowlist',
    'camera',
    'microphone',
    'geolocation',
    'security',
  ],
  icon: 'SlidersHorizontal',
  relatedTools: [],
};

export default meta;
