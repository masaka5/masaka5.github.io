import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-mime-types-v1',
  name: "MIME类型查找",
  slug: 'mime-types',
  description: "查找文件扩展名的MIME/内容类型，反之亦然。",
  category: 'web',
  tags: ['mime', 'content type', 'extension', 'reference'],
  keywords: ['mime type', 'content type', 'file extension', 'media type', 'lookup'],
  icon: 'FileType',
  relatedTools: ['http-status-codes', 'image-to-base64', 'url-parser'],
};

export default meta;
