import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-ip-subnet-v1',
  name: "IPv4 子网计算器",
  slug: 'ip-subnet-calculator',
  description: "根据 CIDR 计算网络、广播、掩码、主机范围和计数。",
  category: 'web',
  tags: ['ip', 'subnet', 'cidr', 'network', 'netmask'],
  keywords: ['subnet calculator', 'cidr', 'ipv4', 'netmask', 'network address', 'broadcast', 'host range'],
  icon: 'Network',
  relatedTools: ['number-base-converter', 'url-parser', 'mime-types'],
};

export default meta;
