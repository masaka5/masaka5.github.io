import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-media-query-builder-v1',
  name: "CSS媒体查询生成器",
  slug: 'web-media-query-builder',
  description:
    "利用最小/最大宽度断点、方向和视觉特征条件构建响应式@media查询。",
  category: 'web',
  tags: ['css', 'media-query', 'responsive', 'breakpoints', 'frontend'],
  keywords: [
    'css',
    'media query',
    '@media',
    'responsive',
    'breakpoints',
    'min-width',
    'max-width',
    'orientation',
    'prefers-color-scheme',
  ],
  icon: 'Smartphone',
  relatedTools: [],
};

export default meta;
