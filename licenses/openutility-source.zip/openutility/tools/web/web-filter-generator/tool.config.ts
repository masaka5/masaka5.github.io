import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-filter-generator-v1',
  name: "CSS过滤器生成器",
  slug: 'web-filter-generator',
  description:
    "将模糊、亮度、对比度和其他过滤器与实时图像预览相结合。",
  category: 'web',
  tags: ['css', 'filter', 'image', 'generator', 'preview', 'effects'],
  keywords: [
    'css filter',
    'blur',
    'brightness',
    'contrast',
    'grayscale',
    'hue-rotate',
    'sepia',
    'drop-shadow',
    'webkit-filter',
  ],
  icon: 'SlidersHorizontal',
  relatedTools: [],
};

export default meta;
