import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-spf-record-builder-v1",
  name: "SPF记录生成器",
  slug: "spf-record-builder",
  description: "从机制构建SPF TXT记录，包括IPv4、IPv6和全策略。",
  category: "web",
  tags: ["spf","dns","email","txt"],
  keywords: ["spf","dns","email","txt"],
  icon: "Mail",
  relatedTools: [],
};

export default meta;
