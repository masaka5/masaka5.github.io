import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cubic-bezier-v1',
  name: "CSS 三次贝塞尔曲线生成器",
  slug: 'web-cubic-bezier',
  description:
    "设计具有可拖动控制点和实时动画预览的CSS三次贝塞尔曲线缓动曲线，输出过渡定时函数值。",
  category: 'web',
  tags: ['css', 'cubic-bezier', 'animation'],
  keywords: ['css', 'cubic-bezier', 'easing', 'animation', 'transition', 'curve'],
  icon: 'Spline',
  relatedTools: [],
};

export default meta;
