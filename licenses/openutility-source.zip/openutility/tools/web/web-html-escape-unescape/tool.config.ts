import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-html-escape-unescape-v1',
  name: "HTML 转义/代码的 Unescape",
  slug: 'web-html-escape-unescape',
  description: "将文本转义为HTML安全实体或将实体转义回字符。",
  category: 'web',
  tags: ['html', 'escape', 'entities', 'encode', 'decode'],
  keywords: ['html escape', 'unescape', 'entities', 'amp lt gt', 'numeric entity', 'attribute safe'],
  icon: 'Code',
  relatedTools: [],
};

export default meta;
