import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-grid-template-generator-v1',
  name: "CSS网格模板生成器",
  slug: 'web-grid-template-generator',
  description:
    "定义网格列、行、间隙和命名区域，然后复制网格模板CSS。",
  category: 'web',
  tags: ['css', 'grid', 'layout', 'generator', 'template', 'areas'],
  keywords: [
    'css grid',
    'grid-template-columns',
    'grid-template-rows',
    'grid-template-areas',
    'fr unit',
    'gap',
    'layout',
    'minmax',
  ],
  icon: 'Grid3x3',
  relatedTools: [],
};

export default meta;
