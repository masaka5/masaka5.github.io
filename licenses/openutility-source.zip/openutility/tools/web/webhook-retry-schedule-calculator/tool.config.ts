import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-webhook-retry-schedule-calculator-v1",
  name: "Webhook 重试计划计算器",
  slug: "webhook-retry-schedule-calculator",
  description: "使用延迟、乘数、抖动和最大延迟对webhook重试尝试进行建模。",
  category: "web",
  tags: ["webhook","retry","backoff","schedule"],
  keywords: ["webhook","retry","backoff","schedule"],
  icon: "Timer",
  relatedTools: [],
};

export default meta;
