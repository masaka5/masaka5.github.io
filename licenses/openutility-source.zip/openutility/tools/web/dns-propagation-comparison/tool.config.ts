import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dns-propagation-comparison-v1",
  name: "DNS传播比较",
  slug: "dns-propagation-comparison",
  description: "比较来自多个解析器的粘贴的DNS答案并标记不匹配。",
  category: "web",
  tags: ["dns","propagation","resolver","compare"],
  keywords: ["dns","propagation","resolver","compare"],
  icon: "GitCompare",
  relatedTools: [],
};

export default meta;
