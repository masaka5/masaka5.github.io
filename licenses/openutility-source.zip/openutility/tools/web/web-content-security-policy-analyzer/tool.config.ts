import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-content-security-policy-analyzer-v1',
  name: "CSP标头分析器",
  slug: 'web-content-security-policy-analyzer',
  description:
    "解析内容安全策略标头并标记弱或不安全指令。",
  category: 'web',
  tags: ['csp', 'security', 'header', 'http', 'analyzer'],
  keywords: [
    'content-security-policy',
    'csp',
    'unsafe-inline',
    'unsafe-eval',
    'security header',
    'xss',
    'directives',
  ],
  icon: 'Shield',
  relatedTools: [],
};

export default meta;
