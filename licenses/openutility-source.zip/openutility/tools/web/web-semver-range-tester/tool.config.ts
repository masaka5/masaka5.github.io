import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-semver-range-tester-v1',
  name: "Semver 范围测试仪",
  slug: 'web-semver-range-tester',
  description: "测试语义版本是否满足npm样式的版本范围（脱字号、波形符、比较器、连字符范围）。",
  category: 'web',
  tags: ['semver', 'range', 'npm', 'caret', 'tilde'],
  keywords: ['version satisfies', 'range satisfaction', 'comparator', 'wildcard', 'hyphen range', 'x-range', '^', '~'],
  icon: 'GitCompare',
  relatedTools: [],
};

export default meta;
