import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-clamp-fluid-type-v1',
  name: "CSSclamp()流体类型计算器",
  slug: 'web-clamp-fluid-type',
  description: "根据最小/最大尺寸和视口范围计算响应式clamp()字体尺寸。",
  category: 'web',
  tags: ['css', 'clamp', 'fluid', 'typography', 'responsive'],
  keywords: ['fluid type', 'viewport', 'vw', 'rem', 'font-size', 'scale', 'preferred value'],
  icon: 'Scaling',
  relatedTools: [],
};

export default meta;
