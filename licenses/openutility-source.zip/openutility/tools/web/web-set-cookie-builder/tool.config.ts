import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-set-cookie-builder-v1',
  name: "Set-Cookie 标头生成器",
  slug: 'web-set-cookie-builder',
  description:
    "根据名称、值和属性切换构建语法正确的 Set-Cookie 标头。",
  category: 'web',
  tags: ['http', 'cookie', 'headers', 'security'],
  keywords: [
    'set-cookie',
    'cookie',
    'samesite',
    'httponly',
    'secure',
    '__host-',
    'max-age',
    'rfc 6265',
    'header',
  ],
  icon: 'Cookie',
  relatedTools: [],
};

export default meta;
