import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-html-entity-picker-v1',
  name: "HTML 实体选择器",
  slug: 'web-html-entity-picker',
  description:
    "命名HTML实体的可搜索参考及其可供复制的字符、数字和十六进制代码。",
  category: 'web',
  tags: ['html', 'entity', 'reference', 'unicode', 'symbols'],
  keywords: [
    'html entity',
    'named entity',
    'character reference',
    'nbsp',
    'mdash',
    'copyright',
    'numeric reference',
    'hex code point',
  ],
  icon: 'Ampersand',
  relatedTools: [],
};

export default meta;
