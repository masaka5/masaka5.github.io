import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-response-decoder-v1",
  name: "SAML响应解码器",
  slug: "saml-response-decoder",
  description: "解码SAMLResponse有效负载并提取断言、发布者、受众和主题细节。",
  category: "web",
  tags: ["saml","sso","response","assertion"],
  keywords: ["samlresponse","assertion","base64","xml"],
  icon: "ShieldCheck",
  relatedTools: [],
};

export default meta;
