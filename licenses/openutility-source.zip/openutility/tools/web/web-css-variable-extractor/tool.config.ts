import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-variable-extractor-v1',
  name: "CSS自定义属性提取器",
  slug: 'web-css-variable-extractor',
  description:
    "将所有CSS自定义属性（--var声明）从样式表提取到去重复的、可排序的列表中。",
  category: 'web',
  tags: ['css', 'variables', 'custom-properties', 'extract', 'tokens'],
  keywords: [
    'css variables',
    'custom properties',
    '--var',
    ':root',
    'design tokens',
    'extract',
    'json',
  ],
  icon: 'Variable',
  relatedTools: [],
};

export default meta;
