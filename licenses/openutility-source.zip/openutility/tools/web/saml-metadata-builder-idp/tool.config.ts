import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-metadata-builder-idp-v1",
  name: "SAML IdP 元数据生成器",
  slug: "saml-metadata-builder-idp",
  description: "使用SSO端点和签名证书构建身份提供者元数据。",
  category: "web",
  tags: ["saml","metadata","idp","xml"],
  keywords: ["saml","metadata","idp","xml"],
  icon: "FilePlus",
  relatedTools: [],
};

export default meta;
