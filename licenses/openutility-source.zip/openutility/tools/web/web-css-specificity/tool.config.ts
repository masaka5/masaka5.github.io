import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-specificity-v1',
  name: "CSS特异性计算器",
  slug: 'web-css-specificity',
  description:
    "将任何CSS选择器的特异性计算为(a，b，c)三元组并对多个选择器进行排名以预测哪个规则获胜。",
  category: 'web',
  tags: ['css', 'specificity', 'selector'],
  keywords: ['css', 'specificity', 'selector', 'cascade', 'calculate', 'frontend'],
  icon: 'Calculator',
  relatedTools: [],
};

export default meta;
