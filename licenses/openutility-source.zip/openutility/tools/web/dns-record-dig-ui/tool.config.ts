import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dns-record-dig-ui-v1",
  name: "DNS 记录挖掘 UI",
  slug: "dns-record-dig-ui",
  description: "构建可复制的 dig 命令并总结粘贴的 DNS 记录。",
  category: "web",
  tags: ["dns","dig","records","network"],
  keywords: ["dns","dig","records","network"],
  icon: "Globe",
  relatedTools: [],
};

export default meta;
