import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-html-to-text-v1',
  name: "HTML到文本",
  slug: 'html-to-text',
  description: "剥离HTML标签并解码实体以获得干净的纯文本。",
  category: 'web',
  tags: ['html', 'strip tags', 'plain text', 'extract'],
  keywords: ['html to text', 'strip tags', 'remove html', 'plain text', 'extract text'],
  icon: 'FileCode',
  relatedTools: ['html-entities', 'markdown-to-html', 'whitespace-cleaner'],
};

export default meta;
