import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-gradient-text-v1',
  name: "CSS渐变文本生成器",
  slug: 'web-css-gradient-text',
  description:
    "产生用于渐变颜色文本的背景剪辑文本技巧CSS。",
  category: 'web',
  tags: ['css', 'gradient', 'text', 'design', 'background-clip'],
  keywords: [
    'gradient text',
    'background-clip',
    'text-fill-color',
    'linear-gradient',
    'radial-gradient',
    'css',
  ],
  icon: 'Type',
  relatedTools: [],
};

export default meta;
