import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-protobuf-json-converter-v1",
  name: "Protobuf JSON 转换器",
  slug: "protobuf-json-converter",
  description: "规范化 protobuf JSON 字段名称和标量包装器以进行调试。",
  category: "web",
  tags: ["protobuf","json","api","convert"],
  keywords: ["protobuf","json","api","convert"],
  icon: "Braces",
  relatedTools: [],
};

export default meta;
