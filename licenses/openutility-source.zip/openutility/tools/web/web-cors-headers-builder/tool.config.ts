import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cors-headers-builder-v1',
  name: "CORS 标头生成器",
  slug: 'web-cors-headers-builder',
  description:
    "生成用于期望的跨源策略的Access-Control-*响应标头。",
  category: 'web',
  tags: ['http', 'cors', 'headers', 'security', 'api'],
  keywords: [
    'cors',
    'access-control-allow-origin',
    'preflight',
    'allow-credentials',
    'allow-methods',
    'cross-origin',
  ],
  icon: 'Globe2',
  relatedTools: [],
};

export default meta;
