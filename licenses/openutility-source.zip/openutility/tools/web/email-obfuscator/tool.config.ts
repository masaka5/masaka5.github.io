import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-email-obfuscator-v1',
  name: "电子邮件混淆器",
  slug: 'email-obfuscator',
  description: "混淆电子邮件地址（实体/JS）以阻止抓取者。",
  category: 'web',
  tags: ['email', 'obfuscate', 'anti-spam', 'entities'],
  keywords: ['email obfuscator', 'hide email', 'anti spam', 'html entities email', 'protect email'],
  icon: 'AtSign',
  relatedTools: ['html-entities', 'url-encode', 'web-html-escape-unescape'],
};

export default meta;
