'use client';

import { useMemo, useState } from 'react';

import { Input } from '@/components/ui/input';
import { Panel, PanelHeader } from '@/components/tools/panel';
import { CopyButton } from '@/components/tools/copy-button';

function entityEncode(s: string): string {
  return Array.from(s)
    .map((c) => (Math.random() > 0.5 ? `&#${c.charCodeAt(0)};` : `&#x${c.charCodeAt(0).toString(16)};`))
    .join('');
}

export default function EmailObfuscatorTool() {
  const [email, setEmail] = useState('hello@example.com');

  const outputs = useMemo(() => {
    if (!email) return [];
    const entities = entityEncode(email);
    const reversed = email.split('').reverse().join('');
    return [
      { label: "HTML实体", value: `<a href="mailto:${entities}">${entities}</a>` },
      {
        label: "CSS反向",
        value: `<span style="unicode-bidi:bidi-override;direction:rtl">${reversed}</span>`,
      },
      {
        label: "JS写",
        value: `<script>document.write(['${email.split('@')[0]}','${email.split('@')[1]}'].join('@'))</script>`,
      },
      { label: "AT/点", value: email.replace('@', ' [at] ').replace(/\./g, ' [dot] ') },
    ];
  }, [email]);

  return (
    <div className="flex flex-col gap-3">
      <div className="space-y-1">
        <label className="text-2xs font-medium uppercase tracking-wide text-muted-foreground">{"电子邮件地址"}</label>
        <Input value={email} onChange={(e) => setEmail(e.target.value)} className="max-w-md font-mono" />
      </div>
      {outputs.length > 0 && (
        <Panel>
          <div className="divide-y">
            {outputs.map((o) => (
              <div key={o.label} className="flex items-start gap-3 px-3 py-2">
                <span className="w-28 shrink-0 text-2xs font-medium uppercase tracking-wide text-muted-foreground">{o.label}</span>
                <code className="min-w-0 flex-1 break-all font-mono text-xs">{o.value}</code>
                <CopyButton value={o.value} size="icon-sm" />
              </div>
            ))}
          </div>
        </Panel>
      )}
      <p className="px-1 text-2xs text-muted-foreground">{"混淆可以阻止幼稚的抓取者；这不是真正的安全。"}</p>
    </div>
  );
}
