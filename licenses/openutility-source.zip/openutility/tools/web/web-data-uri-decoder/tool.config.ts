import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-data-uri-decoder-v1',
  name: "数据 URI 到文本",
  slug: 'web-data-uri-decoder',
  description:
    "将数据：URI解码回其底层文本，从而揭示MIME类型、编码以及来自base64或百分比编码的原始内容。",
  category: 'web',
  tags: ['data-uri', 'decode', 'base64'],
  keywords: ['data-uri', 'decode', 'base64', 'mime', 'inline', 'uri'],
  icon: 'FileOutput',
  relatedTools: [],
};

export default meta;
