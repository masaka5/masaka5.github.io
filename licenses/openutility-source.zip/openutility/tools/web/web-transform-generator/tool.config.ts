import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-transform-generator-v1',
  name: "CSS变换生成器",
  slug: 'web-transform-generator',
  description:
    "将平移、旋转、缩放、倾斜和透视合成为一个变换值。",
  category: 'web',
  tags: ['css', 'transform', 'animation', '3d', 'generator'],
  keywords: [
    'css transform',
    'translate',
    'rotate',
    'scale',
    'skew',
    'perspective',
    'transform-origin',
    'rotateX',
    'preview',
  ],
  icon: 'Globe',
  relatedTools: [],
};

export default meta;
