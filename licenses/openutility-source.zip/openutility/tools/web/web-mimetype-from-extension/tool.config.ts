import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-mimetype-from-extension-v1',
  name: "来自扩展的 MIME 类型",
  slug: 'web-mimetype-from-extension',
  description: "将一个或多个文件扩展名或文件名映射到它们的规范MIME类型并映射回来。",
  category: 'web',
  tags: ['mime', 'content-type', 'extension', 'filename', 'lookup'],
  keywords: ['mime type', 'content type', 'file extension', 'filename', 'media type', 'octet-stream', 'iana', 'reverse mime'],
  icon: 'FileSearch',
  relatedTools: [],
};

export default meta;
