import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-graphql-introspection-viewer-v1",
  name: "GraphQL 自省查看器",
  slug: "graphql-introspection-viewer",
  description: "总结GraphQL自省JSON类型、查询、突变、接口和标量。",
  category: "web",
  tags: ["graphql","schema","introspection","json"],
  keywords: ["graphql","schema","introspection","json"],
  icon: "Component",
  relatedTools: [],
};

export default meta;
