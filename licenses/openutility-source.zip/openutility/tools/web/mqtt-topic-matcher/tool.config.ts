import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-mqtt-topic-matcher-v1",
  name: "MQTT主题匹配器",
  slug: "mqtt-topic-matcher",
  description: "针对示例主题使用+和#通配符测试MQTT主题过滤器。",
  category: "web",
  tags: ["mqtt","topic","wildcard","events"],
  keywords: ["mqtt","topic","wildcard","events"],
  icon: "Radio",
  relatedTools: [],
};

export default meta;
