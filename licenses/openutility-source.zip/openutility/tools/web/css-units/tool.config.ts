import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-css-units-v1',
  name: "PX↔REM转换器",
  slug: 'px-rem-converter',
  description: "给定可配置的根字体大小，在px、rem和em之间进行转换。",
  category: 'web',
  tags: ['css', 'px', 'rem', 'em', 'units'],
  keywords: ['px to rem', 'rem to px', 'em', 'css units', 'font size'],
  icon: 'Ruler',
  relatedTools: ['css-minify', 'color-converter', 'unit-converter'],
};

export default meta;
