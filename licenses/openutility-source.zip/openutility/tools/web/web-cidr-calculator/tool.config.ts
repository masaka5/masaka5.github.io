import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cidr-calculator-v1',
  name: "CIDR/IP 范围计算器",
  slug: 'web-cidr-calculator',
  description: "将IPv4/IPv6 CIDR块扩展为网络、广播、掩码和主机范围。",
  category: 'web',
  tags: ['cidr', 'ip', 'subnet', 'network', 'ipv6'],
  keywords: ['netmask', 'broadcast', 'wildcard', 'host range', 'prefix', 'subnetting', 'ipv4'],
  icon: 'Network',
  relatedTools: [],
};

export default meta;
