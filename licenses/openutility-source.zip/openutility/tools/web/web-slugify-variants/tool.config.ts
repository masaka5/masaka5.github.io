import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-slugify-variants-v1',
  name: "Slugify 变体比较器",
  slug: 'web-slugify-variants',
  description:
    "一次从一个输入生成多个slug样式（kebab、snake、dot、path、GitHub-anchor）以进行比较。",
  category: 'web',
  tags: ['slug', 'slugify', 'kebab', 'snake', 'anchor'],
  keywords: ['url slug', 'dot case', 'path case', 'github heading', 'filename safe', 'diacritics'],
  icon: 'Link',
  relatedTools: [],
};

export default meta;
