import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-query-params-v1',
  name: "查询字符串 ↔ JSON",
  slug: 'query-params',
  description: "将 URL 查询字符串转换为 JSON 并返回，处理重复的键。",
  category: 'web',
  tags: ['query', 'querystring', 'json', 'params', 'url'],
  keywords: ['query string', 'querystring', 'params to json', 'url params', 'searchparams'],
  icon: 'Link2',
  relatedTools: ['url-parser', 'url-encode', 'json-formatter'],
};

export default meta;
