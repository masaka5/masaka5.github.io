import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-kafka-message-header-viewer-v1",
  name: "Kafka消息头查看器",
  slug: "kafka-message-header-viewer",
  description: "解析Kafka标头键/值对和有效负载元数据以用于调试消费者。",
  category: "web",
  tags: ["kafka","headers","events","debug"],
  keywords: ["kafka","headers","events","debug"],
  icon: "Database",
  relatedTools: [],
};

export default meta;
