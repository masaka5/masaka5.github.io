import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-favicon-link-generator-v1',
  name: "网站图标链接标签生成器",
  slug: 'web-favicon-link-generator',
  description:
    "为所有平台生成全套图标和应用程序图标链接标签。",
  category: 'web',
  tags: ['favicon', 'html', 'icons', 'manifest', 'apple-touch', 'meta'],
  keywords: [
    'favicon',
    'link tags',
    'apple touch icon',
    'web manifest',
    'theme-color',
    'msapplication',
    'maskable',
    'pwa icons',
  ],
  icon: 'Link',
  relatedTools: [],
};

export default meta;
