import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-media-query-generator-v1',
  name: "CSS媒体查询生成器",
  slug: 'web-media-query-generator',
  description:
    "根据断点和功能条件构建响应式 @media 查询。",
  category: 'web',
  tags: ['css', 'media-query', 'responsive', 'breakpoints'],
  keywords: [
    'media query',
    'responsive',
    'breakpoint',
    'min-width',
    'max-width',
    'prefers-color-scheme',
    'orientation',
    'css',
  ],
  icon: 'Smartphone',
  relatedTools: [],
};

export default meta;
