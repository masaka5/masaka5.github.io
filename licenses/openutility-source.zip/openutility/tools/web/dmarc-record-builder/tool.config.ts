import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dmarc-record-builder-v1",
  name: "DMARC 记录生成器",
  slug: "dmarc-record-builder",
  description: "使用报告 URI、对齐、百分比和子域策略构建 DMARC TXT 策略。",
  category: "web",
  tags: ["dmarc","dns","email","txt"],
  keywords: ["dmarc","dns","email","txt"],
  icon: "Mail",
  relatedTools: [],
};

export default meta;
