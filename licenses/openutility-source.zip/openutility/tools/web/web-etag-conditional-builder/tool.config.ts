import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-etag-conditional-builder-v1',
  name: "ETag 和条件请求生成器",
  slug: 'web-etag-conditional-builder',
  description:
    "生成ETag值和匹配的If-None-Match/If-Modified-Since请求标头。",
  category: 'web',
  tags: ['etag', 'http', 'cache', 'conditional', 'headers', 'hash'],
  keywords: [
    'etag',
    'if-none-match',
    'if-modified-since',
    'last-modified',
    '304 not modified',
    'conditional request',
    'weak etag',
    'caching',
  ],
  icon: 'Fingerprint',
  relatedTools: [],
};

export default meta;
