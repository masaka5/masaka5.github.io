'use client';

import { useEffect, useState } from 'react';
import { Panel, PanelHeader, OptionsBar, Field, StatBar } from '@/components/tools/panel';
import { CopyButton } from '@/components/tools/copy-button';
import { ErrorBanner } from '@/components/tools/error-banner';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const wc = (globalThis as unknown as { crypto: Crypto }).crypto;
const enc = new TextEncoder();

type Source = 'content' | 'value';

const SAMPLE = 'Hello, conditional caching world!\n';

function toHex(bytes: Uint8Array): string {
  let out = '';
  for (let i = 0; i < bytes.length; i++) {
    out += (bytes[i] ?? 0).toString(16).padStart(2, '0');
  }
  return out;
}

/** Format a Date as an RFC 7231 HTTP-date (IMF-fixdate, always GMT). */
function httpDate(d: Date): string {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const dow = days[d.getUTCDay()] ?? 'Sun';
  const mon = months[d.getUTCMonth()] ?? 'Jan';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${dow}, ${pad(d.getUTCDate())} ${mon} ${d.getUTCFullYear()} ${pad(
    d.getUTCHours(),
  )}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} GMT`;
}

function defaultLastModified(): string {
  // datetime-local format: YYYY-MM-DDTHH:mm
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`;
}

export default function EtagConditionalBuilderTool() {
  const [source, setSource] = useState<Source>('content');
  const [content, setContent] = useState(SAMPLE);
  const [rawValue, setRawValue] = useState('33a64df551425fcc55e4d42a148795d9f25f89d4');
  const [weak, setWeak] = useState(false);
  const [lastModified, setLastModified] = useState(defaultLastModified());

  const [hash, setHash] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = enc.encode(content);
        const buf = await wc.subtle.digest('SHA-1', data as unknown as ArrayBuffer);
        if (!cancelled) {
          setHash(toHex(new Uint8Array(buf)));
          setError(null);
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "未能对内容进行哈希处理。");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [content]);

  // Determine the core (unquoted) ETag string.
  const core =
    source === 'content' ? hash : rawValue.trim().replace(/^W\//, '').replace(/^"|"$/g, '');

  const etag = core ? `${weak ? 'W/' : ''}"${core}"` : '';

  // Parse Last-Modified into a Date (datetime-local is local time).
  const lmDate = lastModified ? new Date(lastModified) : null;
  const lmValid = lmDate !== null && !Number.isNaN(lmDate.getTime());
  const lastModifiedHeader = lmValid && lmDate ? httpDate(lmDate) : '';

  const responseHeaders = [
    etag ? `ETag: ${etag}` : '',
    lastModifiedHeader ? `Last-Modified: ${lastModifiedHeader}` : '',
  ]
    .filter(Boolean)
    .join('\n');

  const requestHeaders = [
    etag ? `If-None-Match: ${etag}` : '',
    lastModifiedHeader ? `If-Modified-Since: ${lastModifiedHeader}` : '',
  ]
    .filter(Boolean)
    .join('\n');

  return (
    <div className="flex flex-col gap-4">
      <Panel>
        <PanelHeader title={"输入"} />
        <div className="flex flex-col gap-4 p-3">
          <OptionsBar>
            <Field label={"ETag 来自"}>
              <Select value={source} onValueChange={(v) => setSource(v as Source)}>
                <SelectTrigger className="w-44">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="content">{"哈希内容(SHA-1)"}</SelectItem>
                  <SelectItem value="value">{"使用原始值"}</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <div className="flex items-center gap-2 self-end pb-1">
              <Switch id="weak" checked={weak} onCheckedChange={setWeak} />
              <Label htmlFor="weak" className="text-sm">
                {"弱验证器(W/)"}</Label>
            </div>
            <Field label={"最后修改"}>
              <Input
                type="datetime-local"
                value={lastModified}
                onChange={(e) => setLastModified(e.target.value)}
                className="w-56"
              />
            </Field>
          </OptionsBar>

          {source === 'content' ? (
            <Field label={"要散列的内容"}>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                spellCheck={false}
                placeholder={"粘贴响应正文以导出强大的 ETag..."}
                className="min-h-28 font-mono text-sm"
              />
            </Field>
          ) : (
            <Field label={"原始 ETag 值（不带引号）"}>
              <Input
                value={rawValue}
                onChange={(e) => setRawValue(e.target.value)}
                spellCheck={false}
                placeholder="abc123"
                className="font-mono"
              />
            </Field>
          )}
        </div>
      </Panel>

      {error && <ErrorBanner error={error} />}

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <PanelHeader title={"响应标头（服务器发送）"}>
            <CopyButton value={() => responseHeaders} disabled={!responseHeaders} />
          </PanelHeader>
          <pre className="overflow-x-auto whitespace-pre-wrap break-all p-3 font-mono text-xs">
            {responseHeaders || '—'}
          </pre>
          <StatBar items={[weak ? 'weak ETag' : 'strong ETag', 'first response: 200 OK']} />
        </Panel>

        <Panel>
          <PanelHeader title={"条件请求（客户端发送下一个）"}>
            <CopyButton value={() => requestHeaders} disabled={!requestHeaders} />
          </PanelHeader>
          <pre className="overflow-x-auto whitespace-pre-wrap break-all p-3 font-mono text-xs">
            {requestHeaders || '—'}
          </pre>
          <StatBar items={['matched: 304 Not Modified', 'changed: 200 OK + new body']} />
        </Panel>
      </div>

      <Panel>
        <PanelHeader title={"304如何工作"} />
        <div className="space-y-2 p-3 text-sm text-muted-foreground">
          <p>
            {"服务器返回"}<code className="font-mono">ETag</code> {"(并且可选地"}{' '}
            <code className="font-mono">{"最后修改"}</code>{")第一个200个响应。缓存存储主体和这些验证器。"}</p>
          <p>
            {"在下一个请求中，客户端回显 ETag"}{' '}
            <code className="font-mono">{"如果-无-匹配"}</code> {"和日期"}{' '}
            <code className="font-mono">{"如果-修改-自"}</code>{".如果资源没有变化，服务器回复"}<code className="font-mono">{"304未修改"}</code> {"没有主体，并且客户端重用其缓存的副本。如果改变，服务器会回复"}{' '}
            <code className="font-mono">{"200好"}</code> {"具有新的主体和新鲜的ETag。"}</p>
          <p>
            {"弱验证器（"}<code className="font-mono">W/</code>{")表示该实体在语义上是等效的，但逐字节可能不同；它不能用于字节范围（部分）请求，而强验证器可以。"}</p>
        </div>
      </Panel>
    </div>
  );
}
