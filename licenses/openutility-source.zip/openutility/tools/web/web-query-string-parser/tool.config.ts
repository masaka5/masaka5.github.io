import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-query-string-parser-v1',
  name: "查询字符串解析器",
  slug: 'web-query-string-parser',
  description:
    "将原始查询字符串解析为可读的键/值表或漂亮的JSON，将重复的键和括号符号扩展为数组。",
  category: 'web',
  tags: ['query', 'querystring', 'url', 'parse'],
  keywords: ['query', 'querystring', 'params', 'parse', 'json', 'url'],
  icon: 'Link2',
  relatedTools: [],
};

export default meta;
