import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-relative-unit-calculator-v1',
  name: "CSS REM / EM / VW / PX 计算器",
  slug: 'web-css-relative-unit-calculator',
  description: "利用可配置的根字体大小和视口在两个方向上在px、rem、em、vw和vh之间进行转换。",
  category: 'web',
  tags: ['css', 'units', 'rem', 'vw', 'convert'],
  keywords: ['px to rem', 'em', 'vh', 'viewport', 'root font size', 'relative units'],
  icon: 'Ruler',
  relatedTools: [],
};

export default meta;
