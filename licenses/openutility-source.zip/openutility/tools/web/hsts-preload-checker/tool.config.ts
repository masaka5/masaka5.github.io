import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-hsts-preload-checker-v1",
  name: "HSTS预载检查器",
  slug: "hsts-preload-checker",
  description: "对照常见预加载要求检查严格传输安全标头。",
  category: "web",
  tags: ["hsts","headers","security","tls"],
  keywords: ["hsts","headers","security","tls"],
  icon: "ShieldCheck",
  relatedTools: [],
};

export default meta;
