import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-tls-rpt-record-builder-v1",
  name: "TLS-RPT记录生成器",
  slug: "tls-rpt-record-builder",
  description: "构建用于邮件传递诊断的SMTP TLS报告DNS记录。",
  category: "web",
  tags: ["tls-rpt","email","dns","txt"],
  keywords: ["tls-rpt","email","dns","txt"],
  icon: "Mail",
  relatedTools: [],
};

export default meta;
