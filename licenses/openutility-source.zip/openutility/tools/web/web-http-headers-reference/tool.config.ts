import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-http-headers-reference-v1',
  name: "HTTP标头参考",
  slug: 'web-http-headers-reference',
  description:
    "查找任何HTTP请求或响应标头以查看其目的、方向、示例值以及它是标准的还是已弃用的。",
  category: 'web',
  tags: ['http', 'headers', 'reference'],
  keywords: ['http', 'headers', 'reference', 'request', 'response', 'lookup'],
  icon: 'Network',
  relatedTools: [],
};

export default meta;
