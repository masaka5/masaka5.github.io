import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-flexbox-playground-v1',
  name: "CSS Flexbox生成器",
  slug: 'web-flexbox-playground',
  description:
    "从下拉列表中设置flex容器和项目属性并复制生成的CSS。",
  category: 'web',
  tags: ['css', 'flexbox', 'layout', 'generator', 'flex', 'preview'],
  keywords: [
    'flexbox',
    'flex',
    'justify-content',
    'align-items',
    'flex-direction',
    'flex-wrap',
    'gap',
    'css layout',
  ],
  icon: 'Columns3',
  relatedTools: [],
};

export default meta;
