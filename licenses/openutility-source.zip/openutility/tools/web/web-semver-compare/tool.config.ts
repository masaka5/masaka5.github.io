import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-semver-compare-v1',
  name: "语义版本比较器",
  slug: 'web-semver-compare',
  description:
    "比较两个语义版本以查看哪个版本更大，将版本解析为主要/次要/补丁/预发行，并针对范围对其进行测试。",
  category: 'web',
  tags: ['semver', 'version', 'compare'],
  keywords: ['semver', 'version', 'compare', 'semantic', 'range', 'npm'],
  icon: 'GitCompare',
  relatedTools: [],
};

export default meta;
