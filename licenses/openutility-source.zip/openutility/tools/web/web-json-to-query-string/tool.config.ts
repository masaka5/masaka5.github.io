import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-to-query-string-v1',
  name: "用于查询参数的 JSON",
  slug: 'web-json-to-query-string',
  description:
    "将平面或嵌套的JSON对象转换为正确编码的URL查询字符串，并使用嵌套键和数组的括号表示法。",
  category: 'web',
  tags: ['json', 'query', 'url', 'encode'],
  keywords: ['json', 'query', 'url', 'params', 'encode', 'nested'],
  icon: 'Braces',
  relatedTools: [],
};

export default meta;
