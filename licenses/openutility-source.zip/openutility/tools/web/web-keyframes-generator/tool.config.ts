import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-keyframes-generator-v1',
  name: "CSS 关键帧和动画生成器",
  slug: 'web-keyframes-generator',
  description:
    "创建带有停止点和动画简写的 @keyframes，并复制 CSS。",
  category: 'web',
  tags: ['css', 'animation', 'keyframes', 'transition', 'frontend'],
  keywords: [
    'css',
    'keyframes',
    'animation',
    'transform',
    'timing-function',
    'easing',
    'shorthand',
    'preview',
  ],
  icon: 'Sparkles',
  relatedTools: [],
};

export default meta;
