import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-wsdl-to-sample-soap-v1",
  name: "WSDL 到示例 SOAP",
  slug: "wsdl-to-sample-soap",
  description: "为选定的操作名称生成起始SOAP信封。",
  category: "web",
  tags: ["wsdl","soap","xml","sample"],
  keywords: ["wsdl","soap","xml","sample"],
  icon: "FilePlus",
  relatedTools: [],
};

export default meta;
