import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-ip-cidr-membership-v1',
  name: "CIDR 中的 IP 检查器",
  slug: 'web-ip-cidr-membership',
  description: "检查IP地址是否落入一个或多个CIDR范围内。",
  category: 'web',
  tags: ['ip', 'cidr', 'subnet', 'network', 'match'],
  keywords: ['ip in range', 'cidr contains', 'subnet membership', 'ipv4', 'ipv6', 'prefix mask', 'overlap'],
  icon: 'Target',
  relatedTools: [],
};

export default meta;
