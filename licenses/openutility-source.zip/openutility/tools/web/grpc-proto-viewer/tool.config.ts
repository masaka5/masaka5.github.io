import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-grpc-proto-viewer-v1",
  name: "gRPC 原型查看器",
  slug: "grpc-proto-viewer",
  description: "解析.proto文本并列出包、服务、RPC、消息、字段和枚举。",
  category: "web",
  tags: ["grpc","protobuf","proto","api"],
  keywords: ["grpc","protobuf","proto","api"],
  icon: "Network",
  relatedTools: [],
};

export default meta;
