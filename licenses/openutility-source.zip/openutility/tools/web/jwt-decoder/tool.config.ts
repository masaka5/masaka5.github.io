import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-jwt-decoder-v1',
  name: "JWT解码器",
  slug: 'jwt-decoder',
  description: "解码并检查 JSON Web Token 标头和有效负载（无验证）。",
  category: 'web',
  tags: ['jwt', 'token', 'json web token', 'decode', 'auth'],
  keywords: ['jwt', 'jws', 'bearer', 'claims', 'token', 'auth', 'oauth'],
  icon: 'KeyRound',
  relatedTools: ['base64-text', 'json-formatter', 'hash-text'],
};

export default meta;
