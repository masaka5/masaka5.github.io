import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-json-schema-compatibility-diff-v1",
  name: "JSON 模式兼容性差异",
  slug: "json-schema-compatibility-diff",
  description: "比较 JSON 模式的必填字段、属性更改和枚举缩小。",
  category: "web",
  tags: ["json schema","schema","compatibility","diff"],
  keywords: ["json schema","schema","compatibility","diff"],
  icon: "GitCompare",
  relatedTools: [],
};

export default meta;
