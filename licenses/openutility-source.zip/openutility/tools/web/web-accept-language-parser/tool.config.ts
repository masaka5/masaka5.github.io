import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-accept-language-parser-v1',
  name: "接受语言/接受解析器",
  slug: 'web-accept-language-parser',
  description: "按质量值（q因子）对接受语言或接受报头进行解析和排序。",
  category: 'web',
  tags: ['accept-language', 'http header', 'q-factor', 'content negotiation', 'parser'],
  keywords: ['Accept header', 'Accept-Language', 'quality value', 'q-factor', 'language preference', 'content negotiation'],
  icon: 'Languages',
  relatedTools: [],
};

export default meta;
