import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-postman-collection-viewer-v1",
  name: "邮差收藏查看器",
  slug: "postman-collection-viewer",
  description: "汇总 Postman 集合而不将其导入 Postman。",
  category: "web",
  tags: ["postman","api","collection","json"],
  keywords: ["postman","api","collection","json"],
  icon: "List",
  relatedTools: [],
};

export default meta;
