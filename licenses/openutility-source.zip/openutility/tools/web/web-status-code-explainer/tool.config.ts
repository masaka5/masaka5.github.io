import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-status-code-explainer-v1',
  name: "HTTP 状态代码解释器",
  slug: 'web-status-code-explainer',
  description:
    "查找状态代码或符号以获得其类别、含义和典型用途。",
  category: 'web',
  tags: ['http', 'status', 'reference', 'rest', 'codes'],
  keywords: [
    'http status code',
    '404',
    '500',
    'reason phrase',
    'status class',
    'too many requests',
    'express res.status',
    'status line',
  ],
  icon: 'Activity',
  relatedTools: [],
};

export default meta;
