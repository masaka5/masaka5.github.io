import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-graphql-variables-validator-v1",
  name: "GraphQL变量验证器",
  slug: "graphql-variables-validator",
  description: "将 GraphQL 变量定义与变量 JSON 负载进行比较。",
  category: "web",
  tags: ["graphql","variables","json","validation"],
  keywords: ["graphql","variables","json","validation"],
  icon: "Variable",
  relatedTools: [],
};

export default meta;
