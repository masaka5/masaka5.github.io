import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-shell-arg-escaper-v1',
  name: "壳牌争论逃脱者",
  slug: 'web-shell-arg-escaper',
  description:
    "安全地引用和转义 bash、sh、PowerShell 或 cmd.exe 的字符串。",
  category: 'web',
  tags: ['shell', 'escape', 'quote', 'bash', 'powershell'],
  keywords: ['cmd', 'sh', 'argument', 'command line', 'injection', 'quoting'],
  icon: 'Terminal',
  relatedTools: [],
};

export default meta;
