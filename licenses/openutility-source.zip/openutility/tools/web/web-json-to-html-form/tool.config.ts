import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-to-html-form-v1',
  name: "JSON 到 HTML 表单生成器",
  slug: 'web-json-to-html-form',
  description:
    "将JSON对象转换为匹配的HTML表单，其中带标签的输入从每个字段的值类型推断出来。",
  category: 'web',
  tags: ['json', 'html', 'form', 'generator', 'scaffold'],
  keywords: ['json to form', 'html form', 'form generator', 'input fields', 'scaffold form', 'labeled inputs'],
  icon: 'ClipboardList',
  relatedTools: [],
};

export default meta;
