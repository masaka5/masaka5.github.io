'use client';

import { useState } from 'react';
import { TextToolLayout } from '@/components/tools/text-tool';
import { Field } from '@/components/tools/panel';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type Strategy = 'manual' | 'date' | 'content';

const SAMPLE = `/assets/app.js
/assets/styles.css
https://cdn.example.com/img/logo.png?w=200
/vendor/lib.js?v=old#section`;

/** Stable 32-bit FNV-1a hash rendered as base36 — deterministic per content string. */
function hashContent(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  // Force to unsigned and shorten.
  return (h >>> 0).toString(36);
}

function dateToken(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}${m}${day}`;
}

/**
 * Rewrite one URL, preserving existing query params and fragment.
 * Works for both absolute and relative URLs by parsing against a dummy base.
 */
function rewriteUrl(
  raw: string,
  param: string,
  token: string,
  overwrite: boolean,
): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';

  // Separate fragment first (URL/URLSearchParams keep it, but we want full control).
  const hashIdx = trimmed.indexOf('#');
  const fragment = hashIdx === -1 ? '' : trimmed.slice(hashIdx);
  const noFragment = hashIdx === -1 ? trimmed : trimmed.slice(0, hashIdx);

  const qIdx = noFragment.indexOf('?');
  const base = qIdx === -1 ? noFragment : noFragment.slice(0, qIdx);
  const queryStr = qIdx === -1 ? '' : noFragment.slice(qIdx + 1);

  const params = new URLSearchParams(queryStr);
  const has = params.has(param);
  if (has && !overwrite) {
    // Leave the existing param untouched.
    return trimmed;
  }
  params.set(param, token);

  const newQuery = params.toString();
  return `${base}${newQuery ? `?${newQuery}` : ''}${fragment}`;
}

export default function CacheBustingUrlBuilder() {
  const [strategy, setStrategy] = useState<Strategy>('content');
  const [param, setParam] = useState('v');
  const [manualToken, setManualToken] = useState('1.0.0');
  const [content, setContent] = useState('');
  const [overwrite, setOverwrite] = useState(true);

  return (
    <TextToolLayout
      deps={[strategy, param, manualToken, content, overwrite]}
      transform={(input) => {
        const lines = input.split('\n');
        const cleanParam = param.trim() || 'v';

        let token: string;
        if (strategy === 'manual') {
          token = manualToken.trim();
          if (!token) throw new Error("输入手动版本令牌。");
        } else if (strategy === 'date') {
          token = dateToken();
        } else {
          if (!content.trim()) {
            throw new Error(
              "在选项中输入内容字符串以导出散列（例如，粘贴捆绑包源或清单）。",
            );
          }
          token = hashContent(content);
        }

        const out: string[] = [];
        for (const line of lines) {
          if (!line.trim()) {
            out.push('');
            continue;
          }
          out.push(rewriteUrl(line, cleanParam, token, overwrite));
        }
        return out.join('\n');
      }}
      inputLabel={"资产 URL（每行一个）"}
      outputLabel={"重写的URL"}
      inputPlaceholder={SAMPLE}
      sample={SAMPLE}
      downloadName="cache-busted-urls.txt"
      options={
        <>
          <Field label={"策略"}>
            <Select value={strategy} onValueChange={(v) => setStrategy(v as Strategy)}>
              <SelectTrigger className="w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="manual">{"手动令牌"}</SelectItem>
                <SelectItem value="date">{"当前日期"}</SelectItem>
                <SelectItem value="content">{"内容散列"}</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label={"参数名称"}>
            <Input
              value={param}
              onChange={(e) => setParam(e.target.value)}
              className="w-24"
              spellCheck={false}
            />
          </Field>
          {strategy === 'manual' && (
            <Field label={"版本令牌"}>
              <Input
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                className="w-40"
                spellCheck={false}
              />
            </Field>
          )}
          {strategy === 'content' && (
            <Field label={"要散列的内容"} className="min-w-[240px] flex-1">
              <Input
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder={"粘贴内容/清单字符串..."}
                spellCheck={false}
              />
            </Field>
          )}
          <div className="flex items-center gap-2 self-end pb-1">
            <Switch id="overwrite" checked={overwrite} onCheckedChange={setOverwrite} />
            <Label htmlFor="overwrite" className="text-sm">
              {"覆盖现有参数"}</Label>
          </div>
        </>
      }
    />
  );
}
