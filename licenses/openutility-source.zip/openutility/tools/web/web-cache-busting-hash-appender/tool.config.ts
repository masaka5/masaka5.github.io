import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-cache-busting-hash-appender-v1',
  name: "资产缓存无效URL生成器",
  slug: 'web-cache-busting-hash-appender',
  description:
    "将确定性版本/散列查询参数附加到资产URL列表。",
  category: 'web',
  tags: ['cache', 'cache-busting', 'url', 'version', 'assets'],
  keywords: [
    'cache busting',
    'asset version',
    'query param',
    'fingerprint',
    'hash',
    'static assets',
    'cdn',
  ],
  icon: 'Link2',
  relatedTools: [],
};

export default meta;
