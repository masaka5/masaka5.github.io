import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-http-method-reference-v1',
  name: "HTTP方法参考",
  slug: 'web-http-method-reference',
  description:
    "具有安全/幂等/可缓存/主体语义的HTTP方法备忘单。",
  category: 'web',
  tags: ['http', 'methods', 'reference', 'rest', 'rfc'],
  keywords: [
    'http method',
    'verb',
    'get post put delete',
    'idempotent',
    'safe method',
    'cacheable',
    'webdav',
    'rfc 9110',
  ],
  icon: 'Send',
  relatedTools: [],
};

export default meta;
