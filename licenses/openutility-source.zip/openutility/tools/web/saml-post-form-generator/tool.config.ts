import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-saml-post-form-generator-v1",
  name: "SAML POST 表单生成器",
  slug: "saml-post-form-generator",
  description: "生成用于SAML HTTP-POST绑定的本地HTML表单。",
  category: "web",
  tags: ["saml","post","html","sso"],
  keywords: ["saml post binding","autosubmit form"],
  icon: "FileCode",
  relatedTools: [],
};

export default meta;
