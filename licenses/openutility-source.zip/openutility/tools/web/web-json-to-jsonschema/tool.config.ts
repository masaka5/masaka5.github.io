import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-to-jsonschema-v1',
  name: "JSON到JSON模式",
  slug: 'web-json-to-jsonschema',
  description:
    "从示例JSON文档生成草稿JSON模式，推断类型、所需键、数组项形状和嵌套对象定义。",
  category: 'web',
  tags: ['json', 'schema', 'validation'],
  keywords: ['json', 'schema', 'jsonschema', 'validation', 'infer', 'draft'],
  icon: 'FileJson',
  relatedTools: [],
};

export default meta;
