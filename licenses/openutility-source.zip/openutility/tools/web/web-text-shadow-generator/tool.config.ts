import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-text-shadow-generator-v1',
  name: "CSS文本阴影生成器",
  slug: 'web-text-shadow-generator',
  description:
    "利用实时印刷预览构建单个或堆叠的文本阴影值。",
  category: 'web',
  tags: ['css', 'text-shadow', 'typography', 'generator', 'preview'],
  keywords: [
    'text shadow',
    'css',
    'neon glow',
    'long shadow',
    'outline text',
    'retro 3d',
    'layers',
    'typography',
  ],
  icon: 'Type',
  relatedTools: [],
};

export default meta;
