import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-openapi-security-scheme-inspector-v1",
  name: "OpenAPI安全方案检查器",
  slug: "openapi-security-scheme-inspector",
  description: "总结 API 密钥、HTTP 身份验证、OAuth 流程、OpenID Connect URL 和操作安全性。",
  category: "web",
  tags: ["openapi","security","oauth","api"],
  keywords: ["openapi","security","oauth","api"],
  icon: "Lock",
  relatedTools: [],
};

export default meta;
