import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-http-message-parser-v1',
  name: "原始HTTP消息解析器",
  slug: 'web-http-message-parser',
  description: "将原始HTTP请求或响应解析为方法、路径、状态、标头和主体。",
  category: 'web',
  tags: ['http', 'parse', 'headers', 'request', 'response'],
  keywords: ['raw http', 'http request', 'http response', 'parse headers', 'status line', 'http message'],
  icon: 'FileCode',
  relatedTools: [],
};

export default meta;
