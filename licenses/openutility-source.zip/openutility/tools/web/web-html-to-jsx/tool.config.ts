import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-html-to-jsx-v1',
  name: "HTML 到 JSX",
  slug: 'web-html-to-jsx',
  description:
    "将原始HTML转换为React JSX，将类重命名为className，修复自闭合标签，camelCasing属性，并将内联样式转换为对象。",
  category: 'web',
  tags: ['html', 'jsx', 'react'],
  keywords: ['html', 'jsx', 'react', 'convert', 'className', 'component'],
  icon: 'FileCode',
  relatedTools: [],
};

export default meta;
