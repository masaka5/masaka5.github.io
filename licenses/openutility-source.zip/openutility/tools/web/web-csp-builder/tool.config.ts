import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-csp-builder-v1',
  name: "内容安全策略生成器",
  slug: 'web-csp-builder',
  description:
    "使用关键字和随机数/散列帮助器从每个指令源列表构建CSP标头。",
  category: 'web',
  tags: ['http', 'csp', 'security', 'headers', 'policy'],
  keywords: [
    'content-security-policy',
    'csp',
    'script-src',
    'nonce',
    'strict-dynamic',
    'unsafe-inline',
    'header',
  ],
  icon: 'ShieldCheck',
  relatedTools: [],
};

export default meta;
