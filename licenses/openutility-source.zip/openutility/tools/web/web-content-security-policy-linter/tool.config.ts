import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-content-security-policy-linter-v1',
  name: "内容-安全-策略 Linter",
  slug: 'web-content-security-policy-linter',
  description:
    "解析CSP标头字符串并标记不安全或冗余指令。",
  category: 'web',
  tags: ['csp', 'lint', 'security', 'header', 'http'],
  keywords: [
    'content-security-policy',
    'csp linter',
    'duplicate sources',
    'unknown directive',
    'unsafe-inline',
    'redundant',
    'normalize',
  ],
  icon: 'Shield',
  relatedTools: [],
};

export default meta;
