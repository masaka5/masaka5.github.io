import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-srcset-sizes-builder-v1',
  name: "响应式图像 srcset 生成器",
  slug: 'web-srcset-sizes-builder',
  description:
    "从基本文件名和宽度列表构建 <img> srcset 和尺寸属性。",
  category: 'web',
  tags: ['srcset', 'sizes', 'responsive', 'breakpoints', 'html'],
  keywords: [
    'srcset',
    'sizes attribute',
    'breakpoints',
    'responsive images',
    'media query',
    'width descriptor',
    'img tag',
    'lazy loading',
  ],
  icon: 'Image',
  relatedTools: [],
};

export default meta;
