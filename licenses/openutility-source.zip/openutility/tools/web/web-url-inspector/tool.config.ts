import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-url-inspector-v1',
  name: "URL检查器",
  slug: 'web-url-inspector',
  description:
    "将 URL 分解为协议、主机、端口、路径段、查询参数和哈希，显示为清晰标记的组件细分。",
  category: 'web',
  tags: ['url', 'parse', 'inspect'],
  keywords: ['url', 'parse', 'components', 'host', 'path', 'inspect'],
  icon: 'Globe',
  relatedTools: [],
};

export default meta;
