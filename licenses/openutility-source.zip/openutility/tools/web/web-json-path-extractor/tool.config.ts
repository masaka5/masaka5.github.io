import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-path-extractor-v1',
  name: "JSON 路径提取器（高级）",
  slug: 'web-json-path-extractor',
  description:
    "使用点/括号路径表达式（例如 data.items",
  category: 'web',
  tags: ['json', 'query', 'path'],
  keywords: ['json', 'jsonpath', 'query', 'extract', 'filter', 'path'],
  icon: 'FileSearch',
  relatedTools: [],
};

export default meta;
