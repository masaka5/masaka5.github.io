import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-semver-bump-v1',
  name: "Semver 版本保险杠",
  slug: 'web-semver-bump',
  description: "通过根据 semver 规则碰撞主要、次要、补丁或预发布来计算下一个语义版本。",
  category: 'web',
  tags: ['semver', 'version', 'bump', 'npm', 'release'],
  keywords: ['increment version', 'major minor patch', 'prerelease', 'premajor', 'preminor', 'prepatch', 'alpha', 'beta'],
  icon: 'TrendingUp',
  relatedTools: [],
};

export default meta;
