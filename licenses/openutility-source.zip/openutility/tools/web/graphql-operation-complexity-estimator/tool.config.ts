import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-graphql-operation-complexity-estimator-v1",
  name: "GraphQL操作复杂度估计器",
  slug: "graphql-operation-complexity-estimator",
  description: "估计GraphQL查询深度、字段计数、别名、片段和重复选择。",
  category: "web",
  tags: ["graphql","query","complexity","api"],
  keywords: ["graphql","query","complexity","api"],
  icon: "ChartBar",
  relatedTools: [],
};

export default meta;
