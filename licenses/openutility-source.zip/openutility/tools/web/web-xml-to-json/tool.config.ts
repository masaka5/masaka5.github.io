import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-xml-to-json-v1',
  name: "XML 到 JSON (DOM)",
  slug: 'web-xml-to-json',
  description:
    "将XML文档转换为结构化JSON对象，以可预测的约定映射元素、属性和文本内容。",
  category: 'web',
  tags: ['xml', 'json', 'convert'],
  keywords: ['xml', 'json', 'convert', 'parse', 'dom', 'attributes'],
  icon: 'FileJson',
  relatedTools: [],
};

export default meta;
