import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-http-cache-header-explainer-v1',
  name: "高速缓存控制标头解释器",
  slug: 'web-http-cache-header-explainer',
  description: "分解高速缓存控制标头并解释每个指令及其效果。",
  category: 'web',
  tags: ['http', 'cache', 'headers', 'cache-control', 'explain'],
  keywords: ['cache-control', 'max-age', 'no-store', 'immutable', 'http caching', 's-maxage'],
  icon: 'FileCog',
  relatedTools: [],
};

export default meta;
