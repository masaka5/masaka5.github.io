import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-color-format-converter-v1',
  name: "CSS颜色格式转换器",
  slug: 'web-css-color-format-converter',
  description: "在十六进制、rgb()、hsl()、hwb()、oklch()之间转换颜色并为代码命名。",
  category: 'web',
  tags: ['css', 'color', 'oklch', 'hsl', 'convert'],
  keywords: ['hex', 'rgba', 'hwb', 'named color', 'srgb', 'oklab', 'color function'],
  icon: 'Palette',
  relatedTools: [],
};

export default meta;
