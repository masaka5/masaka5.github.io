import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-link-header-builder-v1',
  name: "链接头生成器和解析器",
  slug: 'web-link-header-builder',
  description: "构建并解析RFC 8288链接标头（rel=next/prev、预加载、规范）。",
  category: 'web',
  tags: ['http', 'link', 'header', 'rfc8288', 'rel'],
  keywords: ['link header', 'rfc 8288', 'rel next prev', 'preload', 'preconnect', 'canonical', 'pagination', 'web linking'],
  icon: 'Link2',
  relatedTools: [],
};

export default meta;
