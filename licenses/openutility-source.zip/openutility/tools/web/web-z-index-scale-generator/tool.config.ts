import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-z-index-scale-generator-v1',
  name: "Z-索引标尺生成器",
  slug: 'web-z-index-scale-generator',
  description:
    "生成记录的z索引比例，其中命名层作为CSS变量或Sass/JS映射以避免堆叠混乱。",
  category: 'web',
  tags: ['css', 'z-index', 'design-system', 'tokens', 'layering'],
  keywords: [
    'stacking context',
    'z-index map',
    'css custom properties',
    'sass map',
    'design tokens',
    'layers',
    'modal tooltip',
  ],
  icon: 'Layers',
  relatedTools: [],
};

export default meta;
