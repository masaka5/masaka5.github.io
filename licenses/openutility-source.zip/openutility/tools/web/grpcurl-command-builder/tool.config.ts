import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-grpcurl-command-builder-v1",
  name: "grpcurl 命令生成器",
  slug: "grpcurl-command-builder",
  description: "使用主机、服务方法、标头、TLS和JSON主体构建grpcurl命令。",
  category: "web",
  tags: ["grpc","grpcurl","command","api"],
  keywords: ["grpc","grpcurl","command","api"],
  icon: "Terminal",
  relatedTools: [],
};

export default meta;
