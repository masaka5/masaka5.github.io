import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-content-type-charset-reference-v1',
  name: "内容类型和字符集参考",
  slug: 'web-content-type-charset-reference',
  description: "常见内容类型媒体类型、字符集和参数的可搜索参考。",
  category: 'web',
  tags: ['content-type', 'mime', 'charset', 'reference', 'http'],
  keywords: ['media type', 'mime type', 'utf-8', 'boundary', 'multipart', 'application/json', 'extensions'],
  icon: 'FileType',
  relatedTools: [],
};

export default meta;
