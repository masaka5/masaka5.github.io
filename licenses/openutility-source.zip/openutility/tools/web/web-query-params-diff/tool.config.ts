import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-query-params-diff-v1',
  name: "URL查询参数差异",
  slug: 'web-query-params-diff',
  description: "比较两个URL的查询字符串并显示哪些参数被添加、移除、改变或未更改。",
  category: 'web',
  tags: ['url', 'query', 'diff', 'compare', 'params'],
  keywords: ['query string diff', 'compare urls', 'url params', 'added removed changed', 'querystring', 'searchparams'],
  icon: 'Diff',
  relatedTools: [],
};

export default meta;
