import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-css-specificity-sorter-v1',
  name: "CSS选择器特异性排序器",
  slug: 'web-css-specificity-sorter',
  description: "根据发现覆盖顺序的特异性对多个CSS选择器进行评分和排名。",
  category: 'web',
  tags: ['css', 'specificity', 'selector', 'sort', 'cascade'],
  keywords: ['specificity score', 'a-b-c', 'override', 'rank selectors', 'cascade order'],
  icon: 'SortAsc',
  relatedTools: [],
};

export default meta;
