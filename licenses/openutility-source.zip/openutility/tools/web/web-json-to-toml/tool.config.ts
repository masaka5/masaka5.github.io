import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-json-to-toml-v1',
  name: "JSON 到 TOML（Web）",
  slug: 'web-json-to-toml',
  description:
    "将 JSON 配置转换为 TOML 格式并返回，处理表、表数组、嵌套键、字符串和数字/布尔标量。",
  category: 'web',
  tags: ['json', 'toml', 'convert'],
  keywords: ['json', 'toml', 'config', 'convert', 'cargo', 'settings'],
  icon: 'ArrowLeftRight',
  relatedTools: [],
};

export default meta;
