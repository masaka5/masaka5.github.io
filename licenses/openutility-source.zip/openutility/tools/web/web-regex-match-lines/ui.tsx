'use client';

import { useMemo, useState } from 'react';

import { Field } from '@/components/tools/panel';
import { TextToolLayout } from '@/components/tools/text-tool';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

type OutMode = 'matching' | 'non-matching' | 'annotated';

const SAMPLE = [
  'error: disk full on /dev/sda1',
  'info: backup completed at 02:00',
  'error: timeout connecting to db',
  'warning: low memory',
  'info: 42 users online',
].join('\n');

const FLAG_DEFS: { key: string; label: string }[] = [
  { key: 'i', label: "i (忽略大小写)" },
  { key: 'm', label: "m（多行 ^$）" },
  { key: 's', label: "s(点)" },
  { key: 'u', label: "u（统一码）" },
];

export default function RegexMatchLinesTool() {
  const [pattern, setPattern] = useState('error: (.+)');
  const [flags, setFlags] = useState<Record<string, boolean>>({
    i: false,
    m: false,
    s: false,
    u: false,
  });
  const [mode, setMode] = useState<OutMode>('annotated');

  const flagString = useMemo(
    () =>
      FLAG_DEFS.filter((f) => flags[f.key] === true)
        .map((f) => f.key)
        .join(''),
    [flags],
  );

  const transform = useMemo(
    () => (input: string) => {
      if (!input) return '';
      if (!pattern) throw new Error("输入正则表达式模式。");

      let re: RegExp;
      try {
        re = new RegExp(pattern, flagString);
      } catch (e) {
        throw new Error(e instanceof Error ? e.message : "正则表达式无效。");
      }

      const lines = input.split('\n');
      const out: string[] = [];
      const groupRows: string[] = [];
      let groupCount = 0;
      let matched = 0;

      lines.forEach((line, idx) => {
        re.lastIndex = 0;
        const m = re.exec(line);
        const hit = m !== null;
        if (hit) {
          matched += 1;
          if (m.length - 1 > groupCount) groupCount = m.length - 1;
          if (m.length > 1) {
            const groups = m
              .slice(1)
              .map((g, gi) => `$${gi + 1}=${g === undefined ? '(none)' : g}`)
              .join('  ');
            groupRows.push(`line ${idx + 1}: ${groups}`);
          }
        }

        if (mode === 'matching') {
          if (hit) out.push(line);
        } else if (mode === 'non-matching') {
          if (!hit) out.push(line);
        } else {
          const mark = hit ? '✓' : '✗';
          out.push(`${mark} ${idx + 1}\t${line}`);
        }
      });

      let result = out.join('\n');

      if (groupCount > 0 && groupRows.length > 0) {
        result += `\n\n--- Captured groups (${matched} matching line${matched === 1 ? '' : 's'}) ---\n`;
        result += groupRows.join('\n');
      }

      if (result === '') {
        const noun =
          mode === 'matching'
            ? 'matching'
            : mode === 'non-matching'
              ? 'non-matching'
              : '';
        return `(no ${noun} lines)`;
      }
      return result;
    },
    [pattern, flagString, mode],
  );

  const options = (
    <div className="flex flex-wrap items-end gap-4">
      <Field label={"图案"} className="min-w-[260px] flex-1">
        <Input
          value={pattern}
          onChange={(e) => setPattern(e.target.value)}
          placeholder={"例如错误：(.+)"}
          className="font-mono"
          spellCheck={false}
        />
      </Field>
      <Field label={"标志"}>
        <div className="flex flex-wrap gap-3">
          {FLAG_DEFS.map((f) => (
            <label key={f.key} className="flex items-center gap-1.5 text-xs">
              <Checkbox
                checked={flags[f.key] === true}
                onCheckedChange={(c) =>
                  setFlags((prev) => ({ ...prev, [f.key]: c === true }))
                }
              />
              <span className="font-mono">{f.label}</span>
            </label>
          ))}
        </div>
      </Field>
      <Field label={"输出"}>
        <RadioGroup
          value={mode}
          onValueChange={(v) => setMode(v as OutMode)}
          className="flex flex-wrap gap-3"
        >
          <div className="flex items-center gap-1.5">
            <RadioGroupItem value="matching" id="rml-m" />
            <Label htmlFor="rml-m" className="text-xs">{"仅匹配"}</Label>
          </div>
          <div className="flex items-center gap-1.5">
            <RadioGroupItem value="non-matching" id="rml-n" />
            <Label htmlFor="rml-n" className="text-xs">{"仅不匹配"}</Label>
          </div>
          <div className="flex items-center gap-1.5">
            <RadioGroupItem value="annotated" id="rml-a" />
            <Label htmlFor="rml-a" className="text-xs">{"带注释的"}</Label>
          </div>
        </RadioGroup>
      </Field>
    </div>
  );

  return (
    <TextToolLayout
      transform={transform}
      deps={[pattern, flagString, mode]}
      inputLabel={"文本"}
      outputLabel={"线"}
      inputPlaceholder={"粘贴文本，每行一条记录..."}
      sample={SAMPLE}
      downloadName="matches.txt"
      options={options}
    />
  );
}
