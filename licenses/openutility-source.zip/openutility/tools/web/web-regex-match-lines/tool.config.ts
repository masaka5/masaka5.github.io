import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-regex-match-lines-v1',
  name: "正则表达式与行匹配",
  slug: 'web-regex-match-lines',
  description:
    "针对粘贴文本的每一行运行正则表达式并列出哪些行匹配、哪些行不匹配以及捕获的组。",
  category: 'web',
  tags: ['regex', 'lines', 'filter', 'grep', 'match'],
  keywords: ['regular expression', 'grep', 'capture groups', 'test', 'pattern', 'per line'],
  icon: 'ListFilter',
  relatedTools: [],
};

export default meta;
