import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-oauth-authorization-url-builder-v1",
  name: "OAuth授权URL生成器",
  slug: "oauth-authorization-url-builder",
  description: "构建具有范围、PKCE、状态和随机数的OAuth 2.0或OIDC授权URL。",
  category: "web",
  tags: ["oauth","oidc","url","auth"],
  keywords: ["oauth","oidc","url","auth"],
  icon: "Link",
  relatedTools: [],
};

export default meta;
