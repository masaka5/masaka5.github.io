import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-wsdl-operation-explorer-v1",
  name: "WSDL操作资源管理器",
  slug: "wsdl-operation-explorer",
  description: "解析WSDL XML并列出服务、端口、绑定、操作和消息。",
  category: "web",
  tags: ["wsdl","soap","xml","api"],
  keywords: ["wsdl","soap","xml","api"],
  icon: "ListTree",
  relatedTools: [],
};

export default meta;
