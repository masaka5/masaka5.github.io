import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-srcset-generator-v1',
  name: "响应式图像srcset生成器",
  slug: 'web-srcset-generator',
  description:
    "从宽度列表生成<img>srcset/sizes（或<picture>）标记。",
  category: 'web',
  tags: ['srcset', 'responsive', 'images', 'html', 'picture'],
  keywords: [
    'responsive images',
    'srcset',
    'sizes',
    'picture',
    'webp',
    'avif',
    'density',
    'retina',
    'img tag',
  ],
  icon: 'Images',
  relatedTools: [],
};

export default meta;
