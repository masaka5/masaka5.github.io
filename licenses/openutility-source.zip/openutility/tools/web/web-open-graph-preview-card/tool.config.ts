import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-open-graph-preview-card-v1',
  name: "开放图谱/Twitter 卡预览",
  slug: 'web-open-graph-preview-card',
  description: "从粘贴的HTML解析OG和Twitter元标记并显示解析的共享卡字段。",
  category: 'web',
  tags: ['open graph', 'twitter card', 'meta', 'seo', 'preview'],
  keywords: ['open graph', 'og:title', 'twitter card', 'meta tags', 'social preview', 'share card', 'seo', 'og:image'],
  icon: 'Eye',
  relatedTools: [],
};

export default meta;
