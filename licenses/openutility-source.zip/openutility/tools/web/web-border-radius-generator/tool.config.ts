import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-border-radius-generator-v1',
  name: "CSS 边框半径生成器",
  slug: 'web-border-radius-generator',
  description:
    "可视化地构建边界半径值（包括椭圆和每个角）并复制CSS。",
  category: 'web',
  tags: ['css', 'border-radius', 'generator', 'design', 'shapes'],
  keywords: [
    'border radius',
    'rounded corners',
    'elliptical radius',
    'blob generator',
    'css shape',
    'per corner radius',
  ],
  icon: 'Square',
  relatedTools: [],
};

export default meta;
