import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-aspect-ratio-css-v1',
  name: "CSS纵横比生成器",
  slug: 'web-aspect-ratio-css',
  description: "将宽度：高度比转变为纵横比CSS加上填充顶部后备。",
  category: 'web',
  tags: ['css', 'aspect-ratio', 'responsive', 'layout', 'video'],
  keywords: ['16:9', 'padding-top hack', 'intrinsic ratio', 'gcd', 'reduce ratio', 'fallback'],
  icon: 'Crop',
  relatedTools: [],
};

export default meta;
