import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-bearer-auth-header-builder-v1',
  name: "授权标头生成器",
  slug: 'web-bearer-auth-header-builder',
  description:
    "构造承载、基本、API 密钥和自定义方案的授权标头值。",
  category: 'web',
  tags: ['http', 'auth', 'header', 'bearer', 'basic'],
  keywords: [
    'authorization header',
    'bearer token',
    'basic auth',
    'api key',
    'curl header',
    'fetch headers',
    'http auth',
  ],
  icon: 'KeyRound',
  relatedTools: [],
};

export default meta;
