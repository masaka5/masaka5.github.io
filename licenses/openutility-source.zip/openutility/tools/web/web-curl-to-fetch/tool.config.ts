import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-curl-to-fetch-v1',
  name: "cURL 到代码",
  slug: 'web-curl-to-fetch',
  description:
    "将curl命令转换为浏览器fetch()调用，将方法、URL、标头和主体解析为准备粘贴的JavaScript。",
  category: 'web',
  tags: ['curl', 'fetch', 'javascript', 'http'],
  keywords: ['curl', 'fetch', 'javascript', 'http', 'request', 'convert'],
  icon: 'Terminal',
  relatedTools: [],
};

export default meta;
