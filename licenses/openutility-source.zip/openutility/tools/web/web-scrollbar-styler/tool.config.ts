import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-scrollbar-styler-v1',
  name: "CSS自定义滚动条样式器",
  slug: 'web-scrollbar-styler',
  description:
    "生成跨浏览器自定义滚动条CSS（WebKit伪元素+Firefox）。",
  category: 'web',
  tags: ['css', 'scrollbar', 'design', 'webkit', 'firefox'],
  keywords: [
    'scrollbar',
    'css',
    'webkit-scrollbar',
    'scrollbar-color',
    'scrollbar-width',
    'custom scrollbar',
    'thumb',
    'track',
  ],
  icon: 'PanelLeft',
  relatedTools: [],
};

export default meta;
