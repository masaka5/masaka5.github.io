import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-xml-formatter-v1',
  name: "XML 格式化程序",
  slug: 'web-xml-formatter',
  description:
    "漂亮打印和缩进缩小的XML，或者通过剥离标签之间的空白以及自闭合标签处理来缩小详细的XML。",
  category: 'web',
  tags: ['xml', 'format', 'beautify'],
  keywords: ['xml', 'format', 'beautify', 'minify', 'pretty', 'indent'],
  icon: 'Code2',
  relatedTools: [],
};

export default meta;
