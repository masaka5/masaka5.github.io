import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-regex-cheatsheet-v1',
  name: "正则表达式备忘单和生成器",
  slug: 'web-regex-cheatsheet',
  description:
    "浏览可搜索的正则表达式语法参考和片段库，以获取常见模式，例如电子邮件、URL、IP和日期，以及可复制的表达式。",
  category: 'web',
  tags: ['regex', 'cheatsheet', 'reference'],
  keywords: ['regex', 'cheatsheet', 'reference', 'pattern', 'snippet', 'syntax'],
  icon: 'Regex',
  relatedTools: [],
};

export default meta;
