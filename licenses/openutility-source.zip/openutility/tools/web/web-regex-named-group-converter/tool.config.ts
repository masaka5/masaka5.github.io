import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-regex-named-group-converter-v1',
  name: "正则表达式命名组参考转换器",
  slug: 'web-regex-named-group-converter',
  description:
    "在正则表达式模式中的编号捕获组和命名捕获组及其反向引用/替换之间进行转换。",
  category: 'web',
  tags: ['regex', 'capture groups', 'named groups', 'convert', 'backreference'],
  keywords: ['regular expression', 'numbered groups', 'k<name>', 'replacement', '$1', 'rewrite'],
  icon: 'Parentheses',
  relatedTools: [],
};

export default meta;
