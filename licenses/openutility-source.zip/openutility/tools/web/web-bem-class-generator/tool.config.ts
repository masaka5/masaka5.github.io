import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-bem-class-generator-v1',
  name: "BEM类名生成器",
  slug: 'web-bem-class-generator',
  description:
    "通过 HTML/CSS 预览从块、元素和修饰符输入生成 Block__Element--修饰符 CSS 类名称。",
  category: 'web',
  tags: ['css', 'bem', 'naming', 'generator', 'frontend'],
  keywords: [
    'bem',
    'block element modifier',
    'css class names',
    'naming convention',
    'css methodology',
    'kebab-case',
  ],
  icon: 'Component',
  relatedTools: [],
};

export default meta;
