'use client';

import { useMemo, useState } from 'react';
import {
  Panel,
  PanelHeader,
  OptionsBar,
  Field,
  StatBar,
} from '@/components/tools/panel';
import { CopyButton } from '@/components/tools/copy-button';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type Browser = 'chrome' | 'firefox' | 'safari' | 'edge';
type OS = 'windows' | 'macos' | 'linux' | 'android' | 'ios';
type Device = 'desktop' | 'mobile' | 'tablet';
type Preset = 'custom' | 'googlebot' | 'bingbot' | 'curl' | 'wget';

interface Token {
  label: string;
  value: string;
}

interface PresetInfo {
  ua: string;
  tokens: Token[];
}

const PRESETS: Record<Exclude<Preset, 'custom'>, PresetInfo> = {
  googlebot: {
    ua: 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    tokens: [
      { label: "产品", value: 'Mozilla/5.0' },
      { label: "兼容性", value: 'compatible; Googlebot/2.1' },
      { label: "信息网址", value: '+http://www.google.com/bot.html' },
    ],
  },
  bingbot: {
    ua: 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
    tokens: [
      { label: "产品", value: 'Mozilla/5.0' },
      { label: "兼容性", value: 'compatible; bingbot/2.0' },
      { label: "信息网址", value: '+http://www.bing.com/bingbot.htm' },
    ],
  },
  curl: {
    ua: 'curl/8.7.1',
    tokens: [{ label: "产品/版本", value: 'curl/8.7.1' }],
  },
  wget: {
    ua: 'Wget/1.24.5',
    tokens: [{ label: "产品/版本", value: 'Wget/1.24.5' }],
  },
};

// Default per-OS platform tokens used inside the (...) comment block.
function platformToken(os: OS, device: Device, osVer: string): string {
  switch (os) {
    case 'windows':
      return `Windows NT ${osVer || '10.0'}; Win64; x64`;
    case 'macos':
      return `Macintosh; Intel Mac OS X ${(osVer || '10.15.7').replace(/\./g, '_')}`;
    case 'linux':
      return 'X11; Linux x86_64';
    case 'android':
      return `Linux; Android ${osVer || '14'}; ${device === 'tablet' ? 'SM-X710' : 'Pixel 8'}`;
    case 'ios':
      return device === 'tablet'
        ? `iPad; CPU OS ${(osVer || '17_5').replace(/\./g, '_')} like Mac OS X`
        : `iPhone; CPU iPhone OS ${(osVer || '17_5').replace(/\./g, '_')} like Mac OS X`;
    default:
      return 'X11; Linux x86_64';
  }
}

function defaultOsVersion(os: OS): string {
  switch (os) {
    case 'windows':
      return '10.0';
    case 'macos':
      return '10.15.7';
    case 'linux':
      return '';
    case 'android':
      return '14';
    case 'ios':
      return '17.5';
    default:
      return '';
  }
}

function buildTokens(
  browser: Browser,
  os: OS,
  device: Device,
  browserVer: string,
  osVer: string,
): { ua: string; tokens: Token[] } {
  const platform = platformToken(os, device, osVer);
  const mobileTag =
    os === 'android'
      ? ' Mobile'
      : os === 'ios' && device !== 'tablet'
        ? ' Mobile/15E148'
        : '';
  const bv = browserVer.trim();
  const tokens: Token[] = [{ label: "产品", value: 'Mozilla/5.0' }];
  tokens.push({ label: "平台", value: `(${platform})` });

  let ua: string;
  switch (browser) {
    case 'chrome': {
      const v = bv || '125.0.0.0';
      ua = `Mozilla/5.0 (${platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v}${mobileTag} Safari/537.36`;
      tokens.push(
        { label: "发动机", value: 'AppleWebKit/537.36 (KHTML, like Gecko)' },
        { label: "浏览器", value: `Chrome/${v}` },
        ...(mobileTag ? [{ label: "形状因数", value: mobileTag.trim() }] : []),
        { label: "兼容性", value: 'Safari/537.36' },
      );
      return { ua, tokens };
    }
    case 'edge': {
      const v = bv || '125.0.0.0';
      ua = `Mozilla/5.0 (${platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v}${mobileTag} Safari/537.36 Edg/${v}`;
      tokens.push(
        { label: "发动机", value: 'AppleWebKit/537.36 (KHTML, like Gecko)' },
        { label: "铬基", value: `Chrome/${v}` },
        ...(mobileTag ? [{ label: "形状因数", value: mobileTag.trim() }] : []),
        { label: "兼容性", value: 'Safari/537.36' },
        { label: "边缘品牌", value: `Edg/${v}` },
      );
      return { ua, tokens };
    }
    case 'firefox': {
      const v = bv || '126.0';
      const rv = v.split('.')[0] ?? '126';
      ua = `Mozilla/5.0 (${platform}; rv:${rv}.0) Gecko/20100101 Firefox/${v}`;
      tokens.push(
        { label: "壁虎版", value: `rv:${rv}.0` },
        { label: "发动机", value: 'Gecko/20100101' },
        { label: "浏览器", value: `Firefox/${v}` },
      );
      return { ua, tokens };
    }
    case 'safari': {
      const v = bv || '17.5';
      ua = `Mozilla/5.0 (${platform}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${v}${mobileTag} Safari/605.1.15`;
      tokens.push(
        { label: "发动机", value: 'AppleWebKit/605.1.15 (KHTML, like Gecko)' },
        { label: "Safari版本", value: `Version/${v}` },
        ...(mobileTag ? [{ label: "形状因数", value: mobileTag.trim() }] : []),
        { label: "兼容性", value: 'Safari/605.1.15' },
      );
      return { ua, tokens };
    }
    default:
      return { ua: 'Mozilla/5.0', tokens };
  }
}

const BROWSER_LABEL: Record<Browser, string> = {
  chrome: 'Chrome',
  firefox: 'Firefox',
  safari: 'Safari',
  edge: 'Edge',
};
const OS_LABEL: Record<OS, string> = {
  windows: 'Windows',
  macos: 'macOS',
  linux: 'Linux',
  android: 'Android',
  ios: 'iOS',
};

export default function UserAgentBuilderTool() {
  const [preset, setPreset] = useState<Preset>('custom');
  const [browser, setBrowser] = useState<Browser>('chrome');
  const [os, setOS] = useState<OS>('windows');
  const [device, setDevice] = useState<Device>('desktop');
  const [browserVer, setBrowserVer] = useState('125.0.0.0');
  const [osVer, setOSVer] = useState('10.0');

  const result = useMemo<{ ua: string; tokens: Token[] }>(() => {
    if (preset !== 'custom') {
      return PRESETS[preset];
    }
    return buildTokens(browser, os, device, browserVer, osVer);
  }, [preset, browser, os, device, browserVer, osVer]);

  const onOSChange = (next: OS) => {
    setOS(next);
    setOSVer(defaultOsVersion(next));
  };

  const isBot = preset !== 'custom';

  return (
    <div className="space-y-4">
      <Panel>
        <OptionsBar>
          <Field label={"预设"}>
            <Select value={preset} onValueChange={(v) => setPreset(v as Preset)}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="custom">{"定制构建"}</SelectItem>
                <SelectItem value="googlebot">{"谷歌机器人"}</SelectItem>
                <SelectItem value="bingbot">{"冰机器人"}</SelectItem>
                <SelectItem value="curl">{"卷曲"}</SelectItem>
                <SelectItem value="wget">Wget</SelectItem>
              </SelectContent>
            </Select>
          </Field>

          {!isBot && (
            <>
              <Field label={"浏览器"}>
                <Select value={browser} onValueChange={(v) => setBrowser(v as Browser)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="chrome">{"铬"}</SelectItem>
                    <SelectItem value="firefox">{"火狐浏览器"}</SelectItem>
                    <SelectItem value="safari">{"野生动物园"}</SelectItem>
                    <SelectItem value="edge">{"边缘"}</SelectItem>
                  </SelectContent>
                </Select>
              </Field>

              <Field label={"操作系统"}>
                <Select value={os} onValueChange={(v) => onOSChange(v as OS)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="windows">Windows</SelectItem>
                    <SelectItem value="macos">macOS</SelectItem>
                    <SelectItem value="linux">Linux</SelectItem>
                    <SelectItem value="android">{"安卓系统"}</SelectItem>
                    <SelectItem value="ios">iOS</SelectItem>
                  </SelectContent>
                </Select>
              </Field>

              <Field label={"设备类别"}>
                <Select value={device} onValueChange={(v) => setDevice(v as Device)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="desktop">{"桌面"}</SelectItem>
                    <SelectItem value="mobile">{"手机"}</SelectItem>
                    <SelectItem value="tablet">{"平板电脑"}</SelectItem>
                  </SelectContent>
                </Select>
              </Field>

              <Field label={"浏览器版本"}>
                <Input
                  value={browserVer}
                  onChange={(e) => setBrowserVer(e.target.value)}
                  className="w-32 font-mono"
                  placeholder="125.0.0.0"
                />
              </Field>

              <Field label={"操作系统版本"}>
                <Input
                  value={osVer}
                  onChange={(e) => setOSVer(e.target.value)}
                  className="w-28 font-mono"
                  placeholder="10.0"
                />
              </Field>
            </>
          )}
        </OptionsBar>
      </Panel>

      <Panel>
        <PanelHeader title={"用户代理字符串"}>
          <CopyButton value={() => result.ua} label={"复制"} />
        </PanelHeader>
        <div className="flex items-start gap-2 p-3">
          <code className="block min-w-0 flex-1 break-all rounded bg-muted px-3 py-2 font-mono text-sm">
            {result.ua}
          </code>
          <CopyButton value={result.ua} size="icon-sm" />
        </div>
        <StatBar
          items={[
            `${result.ua.length} chars`,
            isBot ? 'preset bot/tool' : `${BROWSER_LABEL[browser]} on ${OS_LABEL[os]}`,
            isBot ? null : device,
          ]}
        />
      </Panel>

      <Panel>
        <PanelHeader title={"代币细分"} />
        <div className="max-h-[360px] divide-y overflow-auto">
          {result.tokens.map((t, i) => (
            <div key={`${t.label}-${i}`} className="flex items-center gap-3 px-3 py-2">
              <span className="w-32 shrink-0 text-2xs font-medium uppercase tracking-wide text-muted-foreground">
                {t.label}
              </span>
              <code className="min-w-0 flex-1 break-all font-mono text-xs">
                {t.value}
              </code>
              <CopyButton value={t.value} size="icon-sm" />
            </div>
          ))}
        </div>
        <StatBar items={[`${result.tokens.length} tokens`]} />
      </Panel>

      {!isBot && (
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setBrowser('chrome');
              setOS('windows');
              setDevice('desktop');
              setBrowserVer('125.0.0.0');
              setOSVer('10.0');
            }}
          >
            {"桌面Chrome示例"}</Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setBrowser('safari');
              setOS('ios');
              setDevice('mobile');
              setBrowserVer('17.5');
              setOSVer('17.5');
            }}
          >
            {"iPhone Safari示例"}</Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setBrowser('chrome');
              setOS('android');
              setDevice('mobile');
              setBrowserVer('125.0.0.0');
              setOSVer('14');
            }}
          >
            {"Android Chrome 示例"}</Button>
        </div>
      )}
    </div>
  );
}
