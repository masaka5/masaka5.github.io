import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-user-agent-builder-v1',
  name: "用户代理字符串生成器",
  slug: 'web-user-agent-builder',
  description:
    "根据平台、引擎和版本选择器组成浏览器用户代理字符串。",
  category: 'web',
  tags: ['user-agent', 'http', 'browser', 'headers', 'testing'],
  keywords: [
    'ua string',
    'user agent generator',
    'navigator.userAgent',
    'browser identification',
    'googlebot',
    'curl',
    'spoof',
  ],
  icon: 'Smartphone',
  relatedTools: [],
};

export default meta;
