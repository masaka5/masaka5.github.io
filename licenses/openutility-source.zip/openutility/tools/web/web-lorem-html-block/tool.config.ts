import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-lorem-html-block-v1',
  name: "Lorem Ipsum HTML 块生成器",
  slug: 'web-lorem-html-block',
  description:
    "将占位符内容生成为准备粘贴的语义HTML块（段落、标题、列表、块引用）。",
  category: 'web',
  tags: ['lorem-ipsum', 'placeholder', 'html', 'mockup', 'content'],
  keywords: [
    'lorem ipsum',
    'placeholder text',
    'html',
    'dummy content',
    'mockup',
    'paragraphs',
    'headings',
    'lists',
    'seeded',
  ],
  icon: 'FileCode',
  relatedTools: [],
};

export default meta;
