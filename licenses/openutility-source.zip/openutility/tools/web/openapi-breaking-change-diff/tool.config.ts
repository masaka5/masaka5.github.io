import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-openapi-breaking-change-diff-v1",
  name: "OpenAPI重大变化差异",
  slug: "openapi-breaking-change-diff",
  description: "比较两个OpenAPI规范并识别移除的路径、方法、参数和响应代码。",
  category: "web",
  tags: ["openapi","diff","breaking","api"],
  keywords: ["openapi","diff","breaking","api"],
  icon: "GitCompare",
  relatedTools: [],
};

export default meta;
