import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-openapi-validator-linter-v1",
  name: "OpenAPI 验证器和 Linter",
  slug: "openapi-validator-linter",
  description: "验证常见的OpenAPI结构并标记缺失的信息、路径、响应和模式。",
  category: "web",
  tags: ["openapi","swagger","api","lint"],
  keywords: ["openapi","swagger","api","lint"],
  icon: "FileSearch",
  relatedTools: [],
};

export default meta;
