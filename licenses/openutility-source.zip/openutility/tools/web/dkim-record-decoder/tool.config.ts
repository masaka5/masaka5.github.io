import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-dkim-record-decoder-v1",
  name: "DKIM记录解码器",
  slug: "dkim-record-decoder",
  description: "解码 DKIM TXT 记录并提取版本、密钥类型、标志、哈希列表、服务和公钥提示。",
  category: "web",
  tags: ["dkim","dns","email","txt"],
  keywords: ["dkim","dns","email","txt"],
  icon: "KeyRound",
  relatedTools: [],
};

export default meta;
