import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-referrer-policy-reference-v1',
  name: "推荐人-策略参考和测试器",
  slug: 'web-referrer-policy-reference',
  description:
    "解释Referrer-Policy值并模拟在两个URL之间发送什么Referer。",
  category: 'web',
  tags: ['referrer', 'policy', 'http', 'privacy', 'security'],
  keywords: [
    'referrer-policy',
    'referer header',
    'no-referrer',
    'strict-origin',
    'cross-origin',
    'downgrade',
    'privacy',
  ],
  icon: 'Eye',
  relatedTools: [],
};

export default meta;
