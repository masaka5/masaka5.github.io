import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-ipv6-expander-v1',
  name: "IPv6扩展和压缩",
  slug: 'web-ipv6-expander',
  description: ".name 或 items[*].name",
  category: 'web',
  tags: ['ipv6', 'network', 'expand', 'compress', 'rfc5952'],
  keywords: ['ipv6 expand', 'ipv6 compress', 'canonical ipv6', 'rfc 5952', 'shorten ipv6', 'normalize ipv6'],
  icon: 'Minimize2',
  relatedTools: [],
};

export default meta;
