import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-user-agent-v1',
  name: "用户代理解析器",
  slug: 'user-agent-parser',
  description: "将用户代理字符串解析为浏览器、引擎、操作系统和设备。",
  category: 'web',
  tags: ['user agent', 'ua', 'browser', 'parse'],
  keywords: ['user agent', 'ua parser', 'browser detect', 'os detect', 'device'],
  icon: 'ScanLine',
  relatedTools: ['url-parser', 'http-status-codes', 'mime-types'],
};

export default meta;
