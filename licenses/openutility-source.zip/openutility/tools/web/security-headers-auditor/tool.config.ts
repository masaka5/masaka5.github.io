import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-security-headers-auditor-v1",
  name: "安全标头审核器",
  slug: "security-headers-auditor",
  description: "审核粘贴的 CSP、HSTS、框架、MIME、引荐来源网址和权限策略的 HTTP 响应标头。",
  category: "web",
  tags: ["security headers","http","csp","audit"],
  keywords: ["security headers","http","csp","audit"],
  icon: "Shield",
  relatedTools: [],
};

export default meta;
