import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-oauth-token-response-inspector-v1",
  name: "OAuth令牌响应检查器",
  slug: "oauth-token-response-inspector",
  description: "检查OAuth令牌响应、令牌类型、范围和到期日。",
  category: "web",
  tags: ["oauth","token","json","auth"],
  keywords: ["oauth","token","json","auth"],
  icon: "Key",
  relatedTools: [],
};

export default meta;
