import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-jwt-to-fetch-v1',
  name: "经过验证的 fetch() 构建器",
  slug: 'web-jwt-to-fetch',
  description:
    "生成具有方法、标头、不记名令牌和JSON主体的fetch()片段。",
  category: 'web',
  tags: ['fetch', 'http', 'javascript', 'api', 'bearer'],
  keywords: [
    'fetch',
    'http request',
    'bearer token',
    'authorization',
    'api',
    'javascript',
    'snippet',
    'json body',
  ],
  icon: 'Code2',
  relatedTools: [],
};

export default meta;
