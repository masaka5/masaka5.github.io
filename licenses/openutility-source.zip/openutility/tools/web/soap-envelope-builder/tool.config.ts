import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-soap-envelope-builder-v1",
  name: "SOAP 信封生成器",
  slug: "soap-envelope-builder",
  description: "从名称空间、操作和正文 XML 构建 SOAP 1.1 或 1.2 信封。",
  category: "web",
  tags: ["soap","xml","request","api"],
  keywords: ["soap","xml","request","api"],
  icon: "FileCode",
  relatedTools: [],
};

export default meta;
