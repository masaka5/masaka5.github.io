import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-dotenv-to-json-v1',
  name: ".env 到 JSON",
  slug: 'web-dotenv-to-json',
  description:
    "将.env/dotenv文件解析为JSON对象并将JSON转换回.env格式，处理引号、注释和导出前缀。",
  category: 'web',
  tags: ['env', 'dotenv', 'json', 'config'],
  keywords: ['env', 'dotenv', 'json', 'config', 'parse', 'environment'],
  icon: 'FileCog',
  relatedTools: [],
};

export default meta;
