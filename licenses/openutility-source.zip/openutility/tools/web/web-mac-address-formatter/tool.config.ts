import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-mac-address-formatter-v1',
  name: "MAC地址格式化器",
  slug: 'web-mac-address-formatter',
  description: "在冒号、连字符、点(Cisco)和裸符号之间重新格式化MAC地址。",
  category: 'web',
  tags: ['mac', 'network', 'formatter', 'oui', 'ethernet'],
  keywords: ['mac address', 'hardware address', 'oui', 'cisco dotted', 'colon', 'hyphen', 'unicast', 'multicast', 'locally administered', 'eui-48'],
  icon: 'Wifi',
  relatedTools: [],
};

export default meta;
