import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-robots-txt-tester-v1',
  name: "robots.txt测试器",
  slug: 'web-robots-txt-tester',
  description:
    "根据粘贴的robots.txt规则测试用户代理是否允许URL路径。",
  category: 'web',
  tags: ['robots', 'seo', 'crawler', 'allow', 'disallow'],
  keywords: ['robots.txt', 'user-agent', 'googlebot', 'rfc 9309', 'crawl-delay', 'sitemap'],
  icon: 'Bug',
  relatedTools: [],
};

export default meta;
