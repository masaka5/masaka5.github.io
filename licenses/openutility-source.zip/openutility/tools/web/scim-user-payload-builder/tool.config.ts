import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-scim-user-payload-builder-v1",
  name: "SCIM 用户有效负载构建器",
  slug: "scim-user-payload-builder",
  description: "构建用于配置测试的 SCIM 2.0 用户 JSON 有效负载。",
  category: "web",
  tags: ["scim","identity","json","provisioning"],
  keywords: ["scim","identity","json","provisioning"],
  icon: "User",
  relatedTools: [],
};

export default meta;
