import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-web-jsonld-schema-generator-v1',
  name: "JSON-LD结构化数据生成器",
  slug: 'web-jsonld-schema-generator',
  description:
    "为文章、产品、常见问题解答、面包屑等生成 schema.org JSON-LD。",
  category: 'web',
  tags: ['json-ld', 'schema.org', 'seo', 'structured-data', 'rich-results'],
  keywords: [
    'json-ld',
    'jsonld',
    'schema.org',
    'structured data',
    'seo',
    'rich snippets',
    'product',
    'faq',
    'breadcrumb',
    'article',
  ],
  icon: 'FileJson',
  relatedTools: [],
};

export default meta;
