import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-server-sent-events-event-parser-v1",
  name: "服务器发送的事件解析器",
  slug: "server-sent-events-event-parser",
  description: "将SSE流解析为事件、ID、重试提示、注释和数据有效负载。",
  category: "web",
  tags: ["sse","events","http","parser"],
  keywords: ["sse","events","http","parser"],
  icon: "Rss",
  relatedTools: [],
};

export default meta;
