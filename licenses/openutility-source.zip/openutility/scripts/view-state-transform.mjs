import ts from 'typescript';import fs from 'node:fs';import path from 'node:path';
const root=process.cwd();const inventory=[];const safe=[];
const sensitive=/crypto\/|password|passwd|passphrase|secret|token|credential|cookie|private.key|api.key|auth|jwt|encrypt|decrypt|rsa|keypair|totp|otp|ssh|pem|certificate|mnemonic|seed|hmac|pbkdf|curl|http-header|cipher|generate-pin|nanoid|random-string|uuid|env-example/i;
const hazard=/\b(?:fetch|WebSocket|Worker|FileReader|AudioContext|setInterval)\s*\(|navigator\.|URL\.createObjectURL|new (?:File|Blob)|useState[^;]*\b(?:File|Blob|ArrayBuffer|Uint8Array|ImageData)\b/;
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const sources=walk(path.join(root,'tools')).filter(p=>p.endsWith('.tsx'));
for(const file of sources){if(file.endsWith('ui.tsx')){const rel=path.relative(root,file).replaceAll('\\','/'),slug=path.basename(path.dirname(file)),code=fs.readFileSync(file,'utf8');if(!sensitive.test(rel)&&!hazard.test(code))safe.push(slug);}}
fs.writeFileSync('lib/view-state-tools.ts','// Generated conservative tool allowlist. See reports/view-state-inventory.json.\nexport const restorableTools=new Set('+JSON.stringify(safe)+');\n');
function inspect(code,id){const rel=path.relative(root,id).replaceAll('\\','/');const sf=ts.createSourceFile(rel,code,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);const names=new Set();for(const s of sf.statements)if(ts.isImportDeclaration(s)&&s.moduleSpecifier.text==='react')for(const e of s.importClause?.namedBindings?.elements??[])if((e.propertyName?.text??e.name.text)==='useState')names.add(e.name.text);
const edits=[];function visit(n){if(ts.isCallExpression(n)&&(ts.isIdentifier(n.expression)&&names.has(n.expression.text)||ts.isPropertyAccessExpression(n.expression)&&n.expression.expression.getText(sf)==='React'&&n.expression.name.text==='useState')){
 const binding=ts.isVariableDeclaration(n.parent)?n.parent.name.getText(sf):'<unbound>';const name=binding.match(/^\[\s*(\w+)/)?.[1]??binding;
 const initial=n.arguments[0];let reason='nonliteral/resource/derived initializer';let yes=false;
 const tool=rel.startsWith('tools/')&&!rel.includes('/_shared/');const sharedText=rel==='components/tools/text-tool.tsx'&&name==='input';const sharedDev=rel==='tools/_shared/developer-workbench.tsx'&&name==='values';
 const literal=initial&&(ts.isStringLiteral(initial)||ts.isNumericLiteral(initial)||[ts.SyntaxKind.TrueKeyword,ts.SyntaxKind.FalseKeyword].includes(initial.kind));
 if(!(tool||sharedText||sharedDev))reason='shared component internal, no unique instance key';
 else if(sensitive.test(rel)||sensitive.test(name))reason='sensitive/security tool';
 else if(tool&&hazard.test(code))reason='file/capability/network module excluded';
 else if(/nonce|paused|username|^out$|busy|loading|running|processing|error|elapsed|output|result|progress|copied|open|drag|hover|ready|status|worker|job|active|timer|remaining|start|end|timestamp|download|preview|url|id$/i.test(name))reason='transient/derived/resource binding';
 else if(literal||sharedText||sharedDev){yes=true;reason='bounded JSON view draft, allowlisted tool only';}
 if(yes){const start=n.expression.getStart(sf),argStart=n.arguments.pos;edits.push([start,n.expression.end,'useViewState'],[argStart,argStart,JSON.stringify(rel+':'+name)+',']);}
 inventory.push({source:rel,line:sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1,binding:name,restore:yes,reason});
 }ts.forEachChild(n,visit);}visit(sf);if(!edits.length)return null;for(const [s,e,t] of edits.sort((a,b)=>b[0]-a[0]))code=code.slice(0,s)+t+code.slice(e);return `import {useViewState} from '@/lib/use-view-state';\n`+code;}
export function viewStatePlugin(){return {name:'openutility-view-state',enforce:'pre',transform(code,id){id=id.split('?')[0];if(!id.endsWith('.tsx')||id.includes('node_modules')||!(/[/\\](tools|components)[/\\]/.test(id)))return null;return inspect(code,id);}};}
// Inventory includes ALL source callsites, including skipped shared components.
for(const file of [...sources,...walk(path.join(root,'components')).filter(p=>p.endsWith('.tsx'))])inspect(fs.readFileSync(file,'utf8'),file);
fs.mkdirSync('reports',{recursive:true});fs.writeFileSync('reports/view-state-inventory.json',JSON.stringify({safeToolCount:safe.length,restored:inventory.filter(x=>x.restore).length,skipped:inventory.filter(x=>!x.restore).length,bindings:inventory},null,2));


