import ts from 'typescript';import fs from 'node:fs';import path from 'node:path';
const root=process.cwd();const inventory=[];const safe=[];
const sensitive=/crypto\/|password|passwd|passphrase|secret|token|credential|cookie|private.key|api.key|auth|jwt|encrypt|decrypt|rsa|keypair|totp|otp|ssh|pem|certificate|mnemonic|seed|hmac|pbkdf|curl|http-header|cipher|generate-pin|nanoid|random-string|uuid|env|saml|license.key|http.request|header|postman|security.scheme/i;
const hazard=/\b(?:fetch|WebSocket|Worker|FileReader|AudioContext|setInterval)\s*\(|navigator\.|URL\.createObjectURL|new (?:File|Blob)|useState[^;]*\b(?:File|Blob|ArrayBuffer|Uint8Array|ImageData)\b/;
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const sources=walk(path.join(root,'tools')).filter(p=>p.endsWith('.tsx'));
// Thin shared-workbench wrappers do not expose input semantics. Inspect their
// actual definitions too; ambiguous credential/request/header fields are denied.
const semanticDenied=new Set();
const definitionSource=fs.readFileSync('lib/developer-tools/core.ts','utf8');
const definitionAst=ts.createSourceFile('core.ts',definitionSource,ts.ScriptTarget.Latest,true);
function inspectDefinition(node){if(ts.isObjectLiteralExpression(node)){const slug=node.properties.find(p=>ts.isPropertyAssignment(p)&&p.name.getText(definitionAst)==='slug'&&ts.isStringLiteral(p.initializer));if(slug&&/authorization|bearer|cookie|password|passphrase|secret|token|credential|api.?key|private.?key|saml|dotenv|license.?key|headers|raw.http|request|environment|env-/i.test(node.getText(definitionAst)))semanticDenied.add(slug.initializer.text);}ts.forEachChild(node,inspectDefinition);}inspectDefinition(definitionAst);
for(const file of sources){if(file.endsWith('ui.tsx')){const rel=path.relative(root,file).replaceAll('\\','/'),slug=path.basename(path.dirname(file)),code=fs.readFileSync(file,'utf8');if(!sensitive.test(rel)&&!hazard.test(code)&&!semanticDenied.has(slug))safe.push(slug);}}
fs.writeFileSync('lib/view-state-tools.ts','// Generated conservative tool allowlist. See reports/view-state-inventory.json.\nexport const restorableTools=new Set('+JSON.stringify(safe)+');\n');
function inspect(code,id){const rel=path.relative(root,id).replaceAll('\\','/');const sf=ts.createSourceFile(rel,code,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);const names=new Set();for(const s of sf.statements)if(ts.isImportDeclaration(s)&&s.moduleSpecifier.text==='react')for(const e of s.importClause?.namedBindings?.elements??[])if((e.propertyName?.text??e.name.text)==='useState')names.add(e.name.text);
const aliases=new Map(sf.statements.filter(ts.isTypeAliasDeclaration).map(n=>[n.name.text,n.type]));
function choices(type,seen=new Set()){if(!type)return null;if(ts.isTypeReferenceNode(type)){const name=type.typeName.getText(sf);if(seen.has(name))return null;return choices(aliases.get(name),new Set([...seen,name]));}if(ts.isUnionTypeNode(type)){const parts=type.types.map(t=>choices(t,seen));return parts.every(Boolean)?parts.flat():null;}if(ts.isLiteralTypeNode(type)&&(ts.isStringLiteral(type.literal)||ts.isNumericLiteral(type.literal)))return [ts.isNumericLiteral(type.literal)?Number(type.literal.text):type.literal.text];return null;}
const edits=[];function visit(n){if(ts.isCallExpression(n)&&(ts.isIdentifier(n.expression)&&names.has(n.expression.text)||ts.isPropertyAccessExpression(n.expression)&&n.expression.expression.getText(sf)==='React'&&n.expression.name.text==='useState')){
 const binding=ts.isVariableDeclaration(n.parent)?n.parent.name.getText(sf):'<unbound>';const name=binding.match(/^\[\s*(\w+)/)?.[1]??binding;
 const allowed=choices(n.typeArguments?.[0]);const initial=n.arguments[0];let reason='nonliteral/resource/derived initializer';let yes=false;
 const tool=rel.startsWith('tools/')&&!rel.includes('/_shared/');const sharedText=rel==='components/tools/text-tool.tsx'&&name==='input';const sharedDev=rel==='tools/_shared/developer-workbench.tsx'&&name==='values';
 const literal=initial&&(ts.isStringLiteral(initial)||ts.isNumericLiteral(initial)||[ts.SyntaxKind.TrueKeyword,ts.SyntaxKind.FalseKeyword].includes(initial.kind));
 if(!(tool||sharedText||sharedDev))reason='shared component internal, no unique instance key';
 else if(sensitive.test(rel)||sensitive.test(name)||semanticDenied.has(path.basename(path.dirname(id))))reason='sensitive/security tool';
 else if(tool&&hazard.test(code))reason='file/capability/network module excluded';
 else if(/nonce|paused|username|^out$|busy|loading|running|processing|error|elapsed|output|result|progress|copied|open|drag|hover|ready|status|worker|job|active|timer|remaining|start|end|timestamp|download|preview|url|id$/i.test(name))reason='transient/derived/resource binding';
 else if(literal||sharedText||sharedDev){yes=true;reason='bounded JSON view draft, allowlisted tool only';}
 if(yes){const start=n.expression.getStart(sf),argStart=n.arguments.pos;edits.push([start,n.expression.end,'useViewState'],[argStart,argStart,JSON.stringify(rel+':'+name)+',']);if(allowed)edits.push([n.arguments.end,n.arguments.end,','+JSON.stringify(allowed)]);}
 inventory.push({source:rel,line:sf.getLineAndCharacterOfPosition(n.getStart(sf)).line+1,binding:name,restore:yes,reason,...(yes&&allowed?{allowed}:{} )});
 }ts.forEachChild(n,visit);}visit(sf);if(!edits.length)return null;for(const [s,e,t] of edits.sort((a,b)=>b[0]-a[0]))code=code.slice(0,s)+t+code.slice(e);return `import {useViewState} from '@/lib/use-view-state';\n`+code;}
export function viewStatePlugin(){return {name:'openutility-view-state',enforce:'pre',transform(code,id){id=id.split('?')[0];if(!id.endsWith('.tsx')||id.includes('node_modules')||!(/[/\\](tools|components)[/\\]/.test(id)))return null;return inspect(code,id);}};}
// Inventory includes ALL source callsites, including skipped shared components.
for(const file of [...sources,...walk(path.join(root,'components')).filter(p=>p.endsWith('.tsx'))])inspect(fs.readFileSync(file,'utf8'),file);
fs.mkdirSync('reports',{recursive:true});fs.writeFileSync('reports/view-state-inventory.json',JSON.stringify({safeToolCount:safe.length,semanticDeniedTools:[...semanticDenied].sort(),restored:inventory.filter(x=>x.restore).length,skipped:inventory.filter(x=>!x.restore).length,bindings:inventory},null,2));


