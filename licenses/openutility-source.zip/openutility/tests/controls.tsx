import React,{useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {ConfigProvider} from 'antd';
import {toolboxTheme} from '../theme';
import {Input} from '../components/ui/input';
import {Textarea} from '../components/ui/textarea';
import {Button} from '../components/ui/button';
import {Checkbox} from '../components/ui/checkbox';
import {Slider} from '../components/ui/slider';
import {Select,SelectTrigger,SelectValue,SelectContent,SelectItem,SelectGroup,SelectLabel} from '../components/ui/select';
import {Tabs,TabsList,TabsTrigger,TabsContent} from '../components/ui/tabs';
function App(){const input=useRef<HTMLInputElement>(null),area=useRef<HTMLTextAreaElement>(null);const [range,setRange]=useState([0.1,0.3]);const [tab,setTab]=useState('a');const [checked,setChecked]=useState<boolean|'indeterminate'>('indeterminate');return <ConfigProvider theme={toolboxTheme}>
<Input aria-label="numeric" type="number" min="1" max="3" step="0.5" defaultValue="1.5" ref={input}/><Textarea aria-label="text ref" ref={area}/><Button onClick={()=>{input.current!.focus();area.current!.setSelectionRange(1,3);document.getElementById('ref-result')!.textContent=input.current!.tagName+' '+area.current!.tagName+' '+area.current!.selectionStart;}}>refs</Button><output id="ref-result"/>
<Checkbox checked={checked} onCheckedChange={setChecked}>tri</Checkbox><Checkbox defaultChecked disabled>disabled</Checkbox>
<Slider aria-label="decimal range" value={range} min={0} max={1} step={0.1} onValueChange={setRange}/><output>{JSON.stringify(range)}</output>
<Select name="choice" defaultValue="one"><SelectTrigger aria-label="choice"><SelectValue/></SelectTrigger><SelectContent><SelectGroup><SelectLabel>Group</SelectLabel><SelectItem value="one">One</SelectItem><SelectItem value="two" disabled>Two</SelectItem><SelectItem value="three">Three</SelectItem></SelectGroup></SelectContent></Select>
<div id="controlled-tabs"><Tabs value={tab} onValueChange={setTab}><div><TabsList><TabsTrigger value="a">A</TabsTrigger><TabsTrigger value="b" disabled>B</TabsTrigger><TabsTrigger value="c">C</TabsTrigger></TabsList><section><TabsContent value="a">Panel A</TabsContent><TabsContent value="c">Panel C</TabsContent></section></div></Tabs></div>
<div id="default-tabs"><Tabs defaultValue="second"><TabsList><TabsTrigger value="first">First</TabsTrigger><TabsTrigger value="second">Second</TabsTrigger></TabsList><section className="nested-layout"><TabsContent value="first" forceMount><Input aria-label="preserved" defaultValue="initial"/></TabsContent><TabsContent value="second"><Input aria-label="ordinary" defaultValue="reset"/></TabsContent></section></Tabs></div>
<Button asChild variant="link" onClick={()=>document.getElementById('ref-result')!.textContent+=' parent'}><a href="#destination" onClick={()=>document.getElementById('ref-result')!.textContent+=' child'}>anchor</a></Button></ConfigProvider>;}createRoot(document.getElementById('root')!).render(<App/>);
