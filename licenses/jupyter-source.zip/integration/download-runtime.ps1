$ErrorActionPreference = 'Stop'
$TaskRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$VendorRoot = Join-Path $TaskRoot 'toolbox-site/vendor/pyodide'
New-Item -ItemType Directory -Force $VendorRoot | Out-Null
$RuntimeBase = 'https://cdn.jsdelivr.net/pyodide/v314.0.6/full'
foreach ($Asset in @('pyodide.mjs','pyodide.asm.mjs','pyodide.asm.wasm','python_stdlib.zip','pyodide-lock.json')) {
    Invoke-WebRequest "$RuntimeBase/$Asset" -OutFile (Join-Path $VendorRoot $Asset)
}
$RuntimeLock = Get-Content -Raw (Join-Path $VendorRoot 'pyodide-lock.json') | ConvertFrom-Json
$WantedPackages = [System.Collections.Generic.HashSet[string]]::new()
function Add-RuntimePackage([string]$PackageName) {
    $PackageName = $PackageName.Replace('_','-')
    if ($WantedPackages.Add($PackageName)) {
        foreach ($Dependency in $RuntimeLock.packages.$PackageName.depends) { Add-RuntimePackage $Dependency }
    }
}
foreach ($PackageName in @('micropip','ipython','jedi','parso')) { Add-RuntimePackage $PackageName }
foreach ($PackageName in $WantedPackages) {
    $Asset = $RuntimeLock.packages.$PackageName.file_name
    Invoke-WebRequest "$RuntimeBase/$Asset" -OutFile (Join-Path $VendorRoot $Asset)
}
python -m pip download --no-deps -d $VendorRoot comm==0.2.3
Invoke-WebRequest 'https://raw.githubusercontent.com/pyodide/pyodide/314.0.6/LICENSE' -OutFile (Join-Path $VendorRoot 'LICENSE')
