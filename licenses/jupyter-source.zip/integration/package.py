"""Produce scoped source package, notices, and exact deployed asset manifest."""
from pathlib import Path
import email,hashlib,importlib.metadata,json,subprocess,tarfile,zipfile
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1];SITE=ROOT/'toolbox-site';LICENSES=SITE/'licenses'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def file_info(path):return {'path':path.relative_to(SITE).as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)}
lock=subprocess.check_output(['python','-m','pip','freeze','--path',str(HERE/'build-env')],text=True)
(HERE/'build-requirements.lock.txt').write_text(lock,encoding='utf8')
notices=['Online Jupyter and shared Pyodide runtime: third-party copyright and licenses\n']
for name in ['jupyterlite_core-0.8.7.dist-info','jupyterlite_pyodide_kernel-0.8.7.dist-info','jupyterlab_language_pack_zh_cn-4.5.post3.dist-info']:
 for path in (HERE/'build-env'/name).rglob('*'):
  if path.is_file()and 'license' in path.name.lower():notices.extend(['\n=== '+name+' / '+path.name+' ===\n',path.read_text(encoding='utf8')])
for path in [SITE/'tools/jupyter/build/third-party-licenses.json',SITE/'tools/jupyter/extensions/@jupyterlite/pyodide-kernel-extension/static/third-party-licenses.json']:
 for package in json.loads(path.read_text(encoding='utf8'))['packages']:
  notices.extend(['\n=== '+package['name']+' '+package.get('versionInfo','')+' / '+package.get('licenseId','')+' ===\n',package.get('extractedText','')])
for path in [SITE/'vendor/pyodide/LICENSE',*sorted((HERE/'upstream').glob('*LICENSE*'))]:notices.extend(['\n=== '+path.name+' ===\n',path.read_text(encoding='utf8')])
for wheel in sorted((SITE/'vendor/pyodide').glob('*.whl')):
 with zipfile.ZipFile(wheel)as z:
  metadata=email.message_from_bytes(z.read(next(n for n in z.namelist()if n.endswith('.dist-info/METADATA'))))
  notices.append('\n=== '+metadata['Name']+' '+metadata['Version']+' ===\n')
  files=[n for n in z.namelist()if any(term in n.lower().split('/')[-1]for term in ['license','copying','notice'])and not n.endswith('/')]
  for name in files:notices.extend(['\n'+name+'\n',z.read(name).decode('utf8',errors='replace')])
  if not files:notices.append(metadata.get('License','See upstream source metadata')+'\n')
(LICENSES/'jupyter-third-party.txt').write_text('\n'.join(notices),encoding='utf8')
(LICENSES/'jupyter-MIT.txt').write_bytes((HERE/'MIT.txt').read_bytes())
sources=[]
for path in sorted((HERE/'upstream').glob('*')):sources.append({'file':'upstream/'+path.name,'bytes':path.stat().st_size,'sha256':digest(path)})
archive=LICENSES/'jupyter-source.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name in ['README.md','MIT.txt','requirements.txt','build-requirements.lock.txt','jupyter_lite_config.json','jupyter-lite.json','build.ps1','download-runtime.ps1','finalize.py','package.py','toolbox.css','toolbox.js','browser-test.py','test-results.json']:
  path=HERE/name
  if path.exists():z.write(path,'integration/'+name)
 for path in sorted((HERE/'content').rglob('*')):
  if path.is_file():z.write(path,'integration/content/'+path.relative_to(HERE/'content').as_posix())
 for path in sorted((HERE/'upstream').glob('*')):
  if path.name.startswith('jupyterlab-')and path.name.endswith('.tar.gz'):
   # Keep all production source/build inputs; omit docs, fixtures and screenshots.
   with tarfile.open(path,'r:gz')as upstream:
    for member in upstream.getmembers():
     parts=member.name.split('/')
     if member.isfile()and(len(parts)==2 or parts[1]in ['packages','buildutils','dev_mode','scripts','jupyterlab']):
      z.writestr('upstream/'+member.name,upstream.extractfile(member).read())
  else:z.write(path,'upstream/'+path.name)
 z.writestr('upstream/SHA256.json',json.dumps(sources,indent=2))
 z.write(LICENSES/'jupyter-third-party.txt','THIRD-PARTY-NOTICES.txt')
assets=sorted([p for root in [SITE/'tools/jupyter',SITE/'vendor/pyodide']for p in root.rglob('*')if p.is_file()])
manifest={'tool':'jupyter','upstream':{'jupyterlite':{'version':'0.8.7','source':'https://github.com/jupyterlite/jupyterlite/tree/v0.8.7','license':'BSD-3-Clause'},'jupyterlab':{'version':'4.6.5','source':'https://github.com/jupyterlab/jupyterlab/tree/v4.6.5','license':'BSD-3-Clause'},'pyodide-kernel':{'version':'0.8.7','source':'https://github.com/jupyterlite/pyodide-kernel/tree/v0.8.7','license':'BSD-3-Clause'},'pyodide':{'version':'314.0.6','python':'3.14.2','source':'https://github.com/pyodide/pyodide/tree/314.0.6','runtime':'https://cdn.jsdelivr.net/pyodide/v314.0.6/full/','license':'MPL-2.0'},'chinese-language-pack':{'version':'4.5.post3','source':'https://github.com/jupyterlab/language-packs','license':'BSD-3-Clause'}},'runtime_assets':[file_info(p)for p in assets],'runtime_bytes':sum(p.stat().st_size for p in assets),'source_archive':file_info(archive),'upstream_sources':sources,'integration_license':'MIT','runtime_network':'same-origin only; PyPI fallback disabled','shared_with':['python-ide'],'verification':json.loads((HERE/'test-results.json').read_text(encoding='utf8'))}
(LICENSES/'jupyter-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'runtime_bytes':manifest['runtime_bytes'],'runtime_files':len(assets),'source_zip_bytes':archive.stat().st_size,'notices_bytes':(LICENSES/'jupyter-third-party.txt').stat().st_size}))
