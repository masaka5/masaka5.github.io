$ErrorActionPreference = 'Stop'
$TaskRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Push-Location $TaskRoot
try {
    python -m pip install --target "$PSScriptRoot/build-env" -r "$PSScriptRoot/requirements.txt"
    $env:PYTHONPATH = "$PSScriptRoot/build-env"
    $env:JUPYTER_PATH = "$PSScriptRoot/build-env/share/jupyter"
    & "$PSScriptRoot/download-runtime.ps1"
    python -m jupyterlite_core build --lite-dir $PSScriptRoot --output-dir "$TaskRoot/toolbox-site/tools/jupyter" --no-sourcemaps --no-unused-shared-packages
    python "$PSScriptRoot/finalize.py"
} finally { Pop-Location }
