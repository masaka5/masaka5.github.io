"""Real JupyterLite notebook workflows, no injected substitute runtime."""
import asyncio,json,sys,os
from pathlib import Path
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8')
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch();page=await browser.new_page(viewport={'width':1440,'height':900},accept_downloads=True);errors=[];failed=[];external=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('console',lambda m:errors.append(m.text)if m.type=='error' else None)
  page.on('response',lambda r:failed.append([r.status,r.url])if r.status>=400 else None)
  page.on('request',lambda r:external.append(r.url)if r.url.startswith('http')and not r.url.startswith(BASE)else None)
  await page.goto(BASE+'/tools/jupyter/')
  await page.get_by_text('开始使用.ipynb',exact=True).dblclick()
  await page.locator('.jp-CodeCell .cm-content').first.wait_for()
  await page.get_by_text('Python (Pyodide) | 空闲',exact=True).wait_for(timeout=60000)
  await page.locator('.jp-CodeCell .cm-content').first.click();await page.keyboard.press('Shift+Enter')
  await page.locator('.jp-OutputArea-output').get_by_text('4',exact=True).wait_for(timeout=60000)
  await page.locator('.jp-CodeCell .cm-content').nth(1).click();await page.keyboard.press('Shift+Enter')
  await page.locator('.jp-OutputArea-output').get_by_text('你好，Jupyter！',exact=True).wait_for()
  cell=page.locator('.jp-CodeCell .cm-content').last
  await cell.fill("raise ValueError('测试错误')");await page.keyboard.press('Shift+Enter')
  await page.locator('.jp-OutputArea-output').get_by_text('ValueError',exact=False).first.wait_for()
  await page.get_by_role('button',name='保存并创建检查点 (Ctrl+S)',exact=True).click();await page.wait_for_timeout(700)
  await page.reload();await page.locator('.jp-CodeCell .cm-content').first.wait_for()
  await page.get_by_text('Python (Pyodide) | 空闲',exact=True).wait_for(timeout=60000)
  # Document DOM may be restored before Lab's current-widget tracker. Focus the
  # notebook as a user does before invoking a current-document file command.
  await page.locator('.jp-NotebookPanel:visible .jp-CodeCell .cm-content').first.click()
  assert "raise ValueError('测试错误')"in await page.locator('body').inner_text()
  assert '你好，Jupyter！'in '\n'.join(await page.locator('.jp-OutputArea').all_inner_texts())
  await page.get_by_text('文件',exact=True).first.click()
  download_item=page.get_by_role('menuitem',name='下载文件',exact=True)
  await download_item.wait_for()
  assert await download_item.get_attribute('aria-disabled')!='true'
  assert 'lm-mod-disabled'not in(await download_item.get_attribute('class')or '')
  try:
   async with page.expect_download()as event:await download_item.click()
  except Exception:
   await page.screenshot(path='_scratch/jupyter-integration/download-failure.png')
   print(json.dumps({'download_failure_body':await page.locator('body').inner_text(),'console_errors':errors,'failed_requests':failed},ensure_ascii=False))
   raise
  notebook=json.loads(Path(await(await event.value).path()).read_text(encoding='utf8'))
  assert notebook['nbformat']==4 and any(cell.get('outputs')for cell in notebook['cells'])
  fixture={'cells':[{'cell_type':'markdown','metadata':{},'source':['# 导入验证\n','**Markdown 渲染**']},{'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':['print("导入成功")\n','6 * 7']}],'metadata':{'kernelspec':{'name':'python','display_name':'Python (Pyodide)','language':'python'}},'nbformat':4,'nbformat_minor':5}
  async with page.expect_file_chooser()as event:await page.get_by_role('button',name='上传文件',exact=True).click()
  await(await event.value).set_files({'name':'导入验证.ipynb','mimeType':'application/json','buffer':json.dumps(fixture,ensure_ascii=False).encode()})
  await page.locator('.jp-DirListing-itemText').get_by_text('导入验证.ipynb',exact=True).dblclick()
  await page.get_by_role('heading',name='导入验证',exact=True).wait_for()
  await page.locator('.jp-NotebookPanel:visible .jp-CodeCell .cm-content').last.click();await page.keyboard.press('Shift+Enter')
  await page.locator('.jp-OutputArea-output').get_by_text('42',exact=True).wait_for(timeout=60000)
  await page.get_by_role('button',name='保存并创建检查点 (Ctrl+S)',exact=True).click();await page.wait_for_timeout(500)
  await page.screenshot(path='_scratch/jupyter-integration/desktop.png')
  for width,height in [(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
   await page.set_viewport_size({'width':width,'height':height});await page.wait_for_timeout(300)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(width,height)
   header=await page.locator('#toolbox-header').bounding_box();assert header['height']==44
   if width<=600:
    await page.screenshot(path='_scratch/jupyter-integration/portrait.png')
    assert (await page.locator('.jp-NotebookPanel:visible').bounding_box())['width']>=width-80,(width,await page.locator('.jp-NotebookPanel:visible').bounding_box(),await page.locator('.jp-SideBar [data-id="filebrowser"]').get_attribute('aria-selected'))
  await page.screenshot(path='_scratch/jupyter-integration/mobile.png')
  assert not errors,errors;assert not failed,failed;assert not external,external
  result={'real_pyodide_arithmetic':True,'stdout':True,'python_errors':True,'markdown':True,'ipynb_import_export':True,'refresh_persistence':True,'viewports':5,'console_errors':errors,'failed_requests':failed,'external_requests':external}
  Path('_scratch/jupyter-integration/test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result,ensure_ascii=False))
  await browser.close()
asyncio.run(main())
