"""Build the static adaptation and local wheel index after jupyter lite build."""
from pathlib import Path
import hashlib,json,zipfile,email
ROOT=Path(__file__).resolve().parents[2]
SITE=ROOT/'toolbox-site'
HERE=Path(__file__).resolve().parent
runtime=SITE/'tools/jupyter'
vendor=SITE/'vendor/pyodide'
index={}
for wheel in vendor.glob('*.whl'):
 with zipfile.ZipFile(wheel) as z:
  metadata=email.message_from_bytes(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
 name=metadata['Name'].lower().replace('_','-');version=metadata['Version']
 index[name]={'releases':{version:[{'filename':wheel.name,'url':'./'+wheel.name,'packagetype':'bdist_wheel','python_version':'py3','digests':{'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest()}}]}}
(vendor/'all.json').write_text(json.dumps(index,indent=2),encoding='utf8')
config=json.loads((runtime/'jupyter-lite.json').read_text(encoding='utf8'))
kernel=config['jupyter-config-data']['litePluginSettings']['@jupyterlite/pyodide-kernel-extension:kernel']
kernel.update({'pyodideUrl':'../../../vendor/pyodide/pyodide.mjs','disablePyPIFallback':True})
kernel['pipliteUrls']=[url for url in kernel['pipliteUrls'] if 'vendor/pyodide/' not in url]+['../../../vendor/pyodide/all.json']
(runtime/'jupyter-lite.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf8')
for name in ['toolbox.css','toolbox.js']:
 (runtime/name).write_bytes((HERE/name).read_bytes())
lab=runtime/'lab/index.html';html=lab.read_text(encoding='utf8')
if '../toolbox.css' not in html:
 html=html.replace('<html>','<html lang="zh-CN">').replace('<title>JupyterLite</title>','<title>在线 Jupyter · 口袋工具箱</title>').replace('</head>','<link rel="stylesheet" href="../toolbox.css">\n<script src="../toolbox.js" defer></script>\n</head>')
 html=html.replace('Loading JupyterLite...','正在打开 Jupyter…').replace('JupyterLite requires JavaScript to be enabled in your browser.','请启用 JavaScript 以使用 Jupyter。')
 lab.write_text(html,encoding='utf8')
# The upstream JupyterLite extension uses its own translation domain.
translation=runtime/'api/translations/zh_CN.json'
data=json.loads(translation.read_text(encoding='utf8'))
strings={'Download':'下载文件','Download the file to your computer':'将文件下载到电脑'}
for domain in ['jupyterlab','@jupyterlite','@jupyterlab/docmanager-extension:plugin','jupyterlite']:
 data['data'].setdefault(domain,{'':{'domain':domain,'language':'zh-CN','plural_forms':'nplurals=1; plural=0;'}}).update({key:[value]for key,value in strings.items()})
translation.write_text(json.dumps(data,ensure_ascii=False),encoding='utf8')
print('JupyterLite static adaptation finalized')
