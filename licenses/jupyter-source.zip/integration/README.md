# 在线 Jupyter

Actual upstream JupyterLite 0.8.7 / JupyterLab 4.6.5, Pyodide kernel 0.8.7,
Pyodide 314.0.6 (CPython 3.14.2). Native Simplified Chinese translation pack
4.5.post3. Toolbox adaptation adds navigation, blue tokens, responsive sizing,
and a starter notebook. This is the upstream application, not a notebook imitation.

## Rebuild

Place this integration directory at `_scratch/jupyter-integration` inside a checkout
with `toolbox-site/`, then run `pwsh -File _scratch/jupyter-integration/build.ps1`.
Build requires Python 3.13+ and network access. Build-only Jupyter Server dependencies
index notebook metadata; no server code ships or executes in the deployed tool.
The static output lives at `toolbox-site/tools/jupyter/`, with shared Pyodide at
`toolbox-site/vendor/pyodide/`. `requirements.txt` pins direct build tools;
`build-requirements.lock.txt` records the exact resolved build environment.
Upstream source tag archives and their SHA-256 hashes are included. JupyterLab
production packages, build tooling and root lock/config/license files are included
from its tag archive; documentation images, example data and test screenshots are
omitted. The manifest records the original full tag archive hash.

## Static deployment

Serve the complete `toolbox-site/` over HTTPS (or localhost while testing).
GitHub Pages supports the relative paths and scoped JupyterLite service worker;
no cross-origin isolation headers or application server are required. Keep .nojekyll
at the site root so generated underscored resources are preserved.
The browser loads only same-origin assets. PyPI fallback is disabled. No third-party
CDN, sign-in, advertising, update feed, or telemetry is needed for notebook execution.
Python IDE uses the same vendor Pyodide runtime to avoid duplicate binaries.

## Behavior and limits

Run code with Shift+Enter. JupyterLite stores notebooks and settings in IndexedDB.
Save via the native notebook toolbar and export with File → Download file.
Use the native Upload button or drop an `.ipynb` to import. Site data is local to
the current origin and browser profile; clearing site data removes local files.
Export important work. This is browser Python: no server terminal, subprocesses,
raw sockets or arbitrary native CPython wheels. The bundled standard library and
IPython execute locally; scientific wheels are not bundled. Package-install attempts
may fail clearly when the package is absent rather than silently going to PyPI.
Execution of user notebook code has the usual same-origin browser capabilities.
Do not execute untrusted notebooks; Jupyter's native trust model is retained.

## Verification

Serve `toolbox-site/` at http://127.0.0.1:8765, install Python Playwright and Chromium,
then run `python _scratch/jupyter-integration/browser-test.py`.
It verifies actual 2+2 output, Chinese stdout, Python errors, Markdown, notebook
import/export, saved output after refresh, root overflow at 5 viewport sizes,
and no failed, external, or console-error requests.

## License

New integration code: MIT, see `MIT.txt`. Upstream JupyterLite/JupyterLab and
the Pyodide kernel retain BSD-3-Clause and dependency terms. Pyodide retains MPL-2.0
and its vendored runtime licenses. Bundled wheels retain their own notices; complete
extracted notices are shipped at `licenses/jupyter-third-party.txt`. Runtime sources
remain unmodified. Generated files and hashes are listed in `jupyter-manifest.json`.
