/*
 * Copyright (c) Jupyter Development Team.
 * Distributed under the terms of the Modified BSD License.
 */

import { defineConfig, globalIgnores } from 'eslint/config';
import js from '@eslint/js';
import globals from 'globals';
import jestPlugin from 'eslint-plugin-jest';
import reactPlugin from 'eslint-plugin-react';
import tsdocPlugin from 'eslint-plugin-tsdoc';
import regexpPlugin from 'eslint-plugin-regexp';
import prettierPluginRecommended from 'eslint-plugin-prettier/recommended';
import tseslint from 'typescript-eslint';
import * as jsoncParser from 'jsonc-eslint-parser';
import jupyterPlugin from '@jupyter/eslint-plugin';

// Application-lifetime sender types for the signal lifetime rules. The
// `longLivedTypes` option replaces the plugin's built-in list, so the twelve
// defaults are restated here, followed by the kernel session types: a session
// (and its context) outlives the widgets built on it, e.g. when one of
// several views of a document is closed.
const LONG_LIVED_TYPES = [
  // Plugin defaults:
  'CommandRegistry',
  'IDebugger',
  'IDocumentManager',
  'ILSPConnection',
  'ILabShell',
  'ILanguageServerManager',
  'IRenderMimeRegistry',
  'ISettingRegistry',
  'IShell',
  'IStateDB',
  'IThemeManager',
  'ServiceManager',
  // Kernel session types:
  'ISessionContext',
  'SessionContext',
  'ISessionConnection',
  'IKernelConnection',
  'KernelConnection'
];

// Filter globals to remove any with leading/trailing whitespace
const cleanGlobals = globalsObj => {
  const cleaned = {};
  for (const [key, value] of Object.entries(globalsObj)) {
    if (key === key.trim()) {
      cleaned[key] = value;
    }
  }
  return cleaned;
};

export default defineConfig([
  globalIgnores([
    '**/node_modules',
    '**/build',
    '**/lib',
    '**/mock_packages',
    '**/static',
    '**/typings',
    '**/schemas',
    '**/themes',
    '**/coverage',
    '**/*.map.js',
    '**/*.bundle.js',
    'dev_mode/index.js',
    '!dev_mode/static/index.out.js',
    'dev_mode/workspaces',
    'docs/_build',
    'docs/api',
    'docs/build',
    'docs/source/api',
    'examples/example.spec.ts',
    'examples/federated/core_package/index.template.js',
    'examples/federated/core_package/index.js',
    'examples/federated/labextensions',
    'galata/playwright-report',
    'jupyterlab/chrome-test.js',
    'jupyterlab/geckodriver',
    'jupyterlab/staging/index.js',
    'jupyterlab/staging/webpack.config.js',
    'packages/codemirror/test/foo*.js',
    'packages/extensionmanager-extension/examples/listings',
    'packages/nbconvert-css/raw.js',
    'packages/nbconvert-css/style/index.js',
    'packages/services/dist',
    'packages/ui-components/src/icon/iconimports.ts',
    '**/.idea/',
    '**/.history/',
    '**/.vscode/',
    'packages/lsp/src/_*',
    'packages/lsp/schema.js',
    '**/.pixi'
  ]),
  {
    files: ['**/*.js', '**/*.jsx'],
    extends: [js.configs.recommended],
    languageOptions: {
      globals: {
        ...cleanGlobals(globals.browser),
        ...cleanGlobals(globals.commonjs),
        ...cleanGlobals(globals.node),
        ...cleanGlobals(globals.jest),
        BigInt: 'readonly',
        HTMLCollectionOf: 'readonly',
        JSX: 'readonly',
        NodeJS: 'readonly',
        RequestInit: 'readonly',
        RequestInfo: 'readonly',
        ScrollLogicalPosition: 'readonly'
      },

      ecmaVersion: 2022,
      sourceType: 'module'
    },

    rules: {
      camelcase: [
        'error',
        {
          allow: [
            '__webpack_public_path__',
            '__webpack_share_scopes__',
            '__webpack_init_sharing__',
            '_jupyter_types_experimental',
            'allow_stdin',
            'allowed_extensions',
            'allowed_extensions_uris',
            'blocked_extensions',
            'blocked_extensions_uris',
            'bundles_extension',
            'cell_type',
            'check_update',
            'clear_output',
            'codemirror_mode',
            'comm_close',
            'comm_id',
            'comm_msg',
            'comm_open',
            'copy_from',
            'creation_date',
            'cursor_end',
            'cursor_pos',
            'cursor_start',
            'date_created',
            'detail_level',
            'display_data',
            'display_id',
            'display_name',
            'embed_options',
            'en_US',
            'execute_input',
            'execute_result',
            'execution_count',
            'execution_state',
            'extension_data',
            'extension_name',
            'file_extension',
            'file_size',
            'hash_algorithm',
            'help_links',
            'hist_access_type',
            'ids_only',
            'implementation_version',
            'installed_version',
            'is_allowed',
            'is_selected',
            'jlab_core',
            'jupyterlab_extensions',
            'jupyterlab_mime_extensions',
            'kernel_spec',
            'language_info',
            'last_modified',
            'last_update_date',
            'latest_version',
            'lineWrap_type',
            'msg_type',
            'msg_id',
            'msgid_plural',
            'nbconverter_exporter',
            'nbformat_minor',
            'needs_restart',
            'orig_nbformat',
            'output_mimetype',
            'output_type',
            'outputs_hidden',
            'parent_header',
            'per_page',
            'plugin_name',
            'plural_forms',
            'pf_re',
            'pkg_type',
            'protocol_version',
            'pygments_lexer',
            'request_seq',
            'slide_type',
            'source_hidden',
            'shutdown_reply',
            'stop_on_error',
            'store_history',
            'subshell_id',
            'target_name',
            'target_module',
            'UNSAFE_componentWillUpdate',
            'UNSAFE_componentWillReceiveProps',
            'user_expressions',
            'zh_CN'
          ]
        }
      ],

      'id-match': ['error', '^[a-zA-Z_]+[a-zA-Z0-9_]*$'],
      'no-inner-declarations': 'off',
      'no-prototype-builtins': 'off',
      'no-control-regex': 'warn',
      'no-undef': 'warn',
      'no-case-declarations': 'warn',
      'no-useless-escape': 'off',
      'prefer-const': 'off'
    }
  },
  {
    files: ['**/*.ts', '**/*.tsx'],
    extends: [
      js.configs.recommended,
      tseslint.configs.recommended,
      regexpPlugin.configs.recommended
    ],

    plugins: {
      '@typescript-eslint': tseslint.plugin,
      jest: jestPlugin,
      react: reactPlugin,
      jupyter: jupyterPlugin,
      tsdoc: tsdocPlugin
    },

    languageOptions: {
      globals: {
        ...cleanGlobals(globals.browser),
        ...cleanGlobals(globals.commonjs),
        ...cleanGlobals(globals.node),
        ...cleanGlobals(globals.jest),
        BigInt: 'readonly',
        HTMLCollectionOf: 'readonly',
        JSX: 'readonly',
        NodeJS: 'readonly',
        RequestInit: 'readonly',
        RequestInfo: 'readonly',
        ScrollLogicalPosition: 'readonly'
      },

      parser: tseslint.parser,
      ecmaVersion: 2018,

      parserOptions: {
        project: ['./tsconfig.eslint.json']
      }
    },

    rules: {
      'jupyter/command-described-by': 'error',
      'jupyter/plugin-activation-args': 'error',
      'jupyter/plugin-description': 'error',
      'jupyter/token-format': 'error',
      'jupyter/no-translation-concatenation': 'error',
      'jupyter/no-dynamic-translation': 'error',
      'jupyter/incorrect-translator-usage': 'error',
      'jupyter/no-untranslated-string': 'error',
      'jupyter/no-pageconfig-base-url': 'error',
      'jupyter/require-signal-cleanup': [
        'error',
        { longLivedTypes: LONG_LIVED_TYPES }
      ],
      'jupyter/require-signal-this-arg': 'error',
      'jupyter/prefer-signal-this-arg': [
        'error',
        { longLivedTypes: LONG_LIVED_TYPES }
      ],
      'jupyter/require-disposable-ownership': 'error',
      'jupyter/require-disposable-transfer': 'error',
      'tsdoc/syntax': 'warn',
      'jupyter/require-soft-assertions-before-snapshots': 'error',
      '@typescript-eslint/naming-convention': [
        'error',
        {
          selector: 'interface',
          format: ['PascalCase'],

          custom: {
            regex: '^I[A-Z]',
            match: true
          }
        }
      ],

      '@typescript-eslint/no-unused-vars': [
        'warn',
        {
          args: 'none'
        }
      ],

      '@typescript-eslint/no-use-before-define': 'off',
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/no-non-null-assertion': 'off',
      '@typescript-eslint/no-namespace': 'off',
      '@typescript-eslint/interface-name-prefix': 'off',
      '@typescript-eslint/explicit-function-return-type': 'off',

      '@typescript-eslint/ban-ts-comment': [
        'warn',
        {
          'ts-ignore': true
        }
      ],

      '@typescript-eslint/no-non-null-asserted-optional-chain': 'warn',
      '@typescript-eslint/no-var-requires': 'off',
      '@typescript-eslint/no-empty-interface': 'off',
      '@typescript-eslint/no-empty-object-type': 'off',
      '@typescript-eslint/triple-slash-reference': 'warn',
      '@typescript-eslint/no-inferrable-types': 'off',
      '@typescript-eslint/switch-exhaustiveness-check': 'error',
      '@typescript-eslint/consistent-type-imports': [
        'error',
        {
          prefer: 'type-imports',
          fixStyle: 'separate-type-imports'
        }
      ],
      '@typescript-eslint/no-unsafe-function-type': 'warn',
      '@typescript-eslint/no-unused-expressions': 'warn',
      '@typescript-eslint/no-require-imports': 'warn',
      'preserve-caught-error': 'off',
      'no-useless-assignment': 'warn',

      camelcase: [
        'error',
        {
          allow: [
            '__webpack_public_path__',
            '__webpack_share_scopes__',
            '__webpack_init_sharing__',
            '_jupyter_types_experimental',
            'allow_stdin',
            'allowed_extensions',
            'allowed_extensions_uris',
            'blocked_extensions',
            'blocked_extensions_uris',
            'bundles_extension',
            'cell_type',
            'check_update',
            'clear_output',
            'codemirror_mode',
            'comm_close',
            'comm_id',
            'comm_msg',
            'comm_open',
            'copy_from',
            'creation_date',
            'cursor_end',
            'cursor_pos',
            'cursor_start',
            'date_created',
            'detail_level',
            'display_data',
            'display_id',
            'display_name',
            'embed_options',
            'en_US',
            'execute_input',
            'execute_result',
            'execution_count',
            'execution_state',
            'extension_data',
            'extension_name',
            'file_extension',
            'file_size',
            'hash_algorithm',
            'help_links',
            'hist_access_type',
            'ids_only',
            'implementation_version',
            'installed_version',
            'is_allowed',
            'is_selected',
            'jlab_core',
            'jupyterlab_extensions',
            'jupyterlab_mime_extensions',
            'kernel_spec',
            'language_info',
            'last_modified',
            'last_update_date',
            'latest_version',
            'lineWrap_type',
            'msg_type',
            'msg_id',
            'msgid_plural',
            'nbconverter_exporter',
            'nbformat_minor',
            'needs_restart',
            'orig_nbformat',
            'output_mimetype',
            'output_type',
            'outputs_hidden',
            'parent_header',
            'per_page',
            'plugin_name',
            'plural_forms',
            'pf_re',
            'pkg_type',
            'protocol_version',
            'pygments_lexer',
            'request_seq',
            'slide_type',
            'source_hidden',
            'shutdown_reply',
            'stop_on_error',
            'store_history',
            'subshell_id',
            'target_name',
            'target_module',
            'UNSAFE_componentWillUpdate',
            'UNSAFE_componentWillReceiveProps',
            'user_expressions',
            'zh_CN'
          ]
        }
      ],

      'id-match': ['error', '^[a-zA-Z_]+[a-zA-Z0-9_]*$'],
      'no-inner-declarations': 'off',
      'no-prototype-builtins': 'off',
      'no-control-regex': 'warn',
      'no-undef': 'warn',
      'no-case-declarations': 'warn',
      'no-useless-escape': 'off',
      'prefer-const': 'off',
      curly: ['error', 'all'],
      eqeqeq: 'error',
      'prefer-arrow-callback': 'error',
      'react/prop-types': 'warn',

      'sort-imports': [
        'error',
        {
          ignoreCase: true,
          ignoreDeclarationSort: true,
          ignoreMemberSort: false,
          memberSyntaxSortOrder: ['none', 'all', 'multiple', 'single'],
          allowSeparatedGroups: false
        }
      ]
    },

    settings: {
      react: {
        version: 'detect'
      }
    }
  },
  {
    files: ['packages/**/*.spec.ts', 'testutils/**/*.spec.ts'],

    plugins: {
      jest: jestPlugin
    },

    rules: {
      '@typescript-eslint/no-require-imports': 'off',
      ...jestPlugin.configs.recommended.rules,
      'jest/no-conditional-expect': 'warn',
      'jest/valid-title': 'warn',
      'jest/no-standalone-expect': [
        'error',
        {
          additionalTestBlockFunctions: ['it']
        }
      ]
    }
  },
  {
    files: [
      '**/*.spec.ts',
      '**/*.spec.tsx',
      '**/test/**/*.ts',
      '**/test/**/*.tsx',
      'testutils/**/*.ts',
      'testutils/**/*.tsx',
      'galata/test/**/*.ts',
      'galata/test/**/*.tsx'
    ],

    rules: {
      '@typescript-eslint/no-explicit-any': 'off'
    }
  },
  {
    files: [
      '**/*.spec.ts',
      '**/*.spec.tsx',
      '**/test/**/*.ts',
      'examples/**/*.ts',
      'packages/*/examples/**/*.ts',
      'packages/services/src/serverconnection.ts',
      'docs/source/extension/*.tsx'
    ],

    rules: {
      'jupyter/no-pageconfig-base-url': 'off',
      'jupyter/command-described-by': 'off',
      'jupyter/no-untranslated-string': 'off'
    }
  },
  {
    // Disposables created in a test are torn down with the jest environment,
    // and the example applications keep theirs for the lifetime of the page,
    // so neither has an owner to hand them to.
    files: [
      '**/*.spec.ts',
      '**/*.spec.tsx',
      '**/test/**/*.ts',
      '**/test/**/*.tsx',
      'packages/*/src/testutils.ts',
      'testutils/**/*.ts',
      'examples/**/*.ts',
      'examples/**/*.tsx',
      'packages/*/examples/**/*.ts',
      'packages/*/examples/**/*.tsx'
    ],

    rules: {
      'jupyter/require-disposable-ownership': 'off',
      'jupyter/require-disposable-transfer': 'off'
    }
  },
  {
    files: ['galata/test/**/*.ts', 'galata/test/**/*.tsx'],
    plugins: { jupyter: jupyterPlugin },
    rules: {
      'jupyter/galata-prefer-filebrowser-helper': 'error',
      // Custom Galata guards not covered by eslint-plugin-playwright.
      'no-restricted-syntax': [
        'error',
        {
          selector:
            "CallExpression[callee.property.name='screenshot'] > ObjectExpression > Property[key.name='path']",
          message:
            "Do not pass 'path' to screenshot(). Save the result of toMatchSnapshot() or use expect() assertions instead."
        },
        {
          selector:
            "CallExpression[callee.object.object.name='test'][callee.object.property.name='describe'][callee.property.name='configure'] > ObjectExpression > Property[key.name='mode'][value.value='serial']",
          message:
            "Do not use test.describe.configure({ mode: 'serial' }). Tests should run in parallel for better performance and to allow updating all snapshots at once."
        }
      ]
    }
  },
  {
    files: ['**/schema/*.json'],
    languageOptions: { parser: jsoncParser },
    plugins: { jupyter: jupyterPlugin },
    rules: {
      'jupyter/no-schema-enum': 'error'
    }
  },
  prettierPluginRecommended,
  {
    files: ['**/*.ts', '**/*.tsx'],
    rules: {
      eqeqeq: 'off',
      curly: 'off',
      'prefer-arrow-callback': 'off'
    }
  }
]);
