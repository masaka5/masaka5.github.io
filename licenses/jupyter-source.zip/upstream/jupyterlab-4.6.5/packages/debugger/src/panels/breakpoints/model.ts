// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.

import type { ISignal } from '@lumino/signaling';
import { Signal } from '@lumino/signaling';
import type { IDebugger, IDebuggerDisplayRegistry } from '../../tokens';
import { DebuggerDisplayRegistry } from '../../displayregistry';

/**
 * A model for a list of breakpoints.
 */
export class BreakpointsModel implements IDebugger.Model.IBreakpoints {
  constructor(options: { displayRegistry?: IDebuggerDisplayRegistry }) {
    this._displayRegistry =
      options.displayRegistry ?? new DebuggerDisplayRegistry();
  }

  /**
   * Signal emitted when the model changes.
   */
  get changed(): ISignal<this, IDebugger.IBreakpoint[]> {
    return this._changed;
  }

  /**
   * Signal emitted when the breakpoints are restored.
   */
  get restored(): ISignal<this, void> {
    return this._restored;
  }

  /**
   * Signal emitted when a breakpoint is clicked.
   */
  get clicked(): Signal<this, IDebugger.IBreakpoint> {
    return this._clicked;
  }

  /**
   * Signal emitted when the selected breakpoint changes.
   */
  get selectedChanged(): Signal<this, IDebugger.IBreakpoint> {
    return this._selectedChanged;
  }

  /**
   * Get selected breakpoint
   */
  get selectedBreakpoint(): IDebugger.IBreakpoint {
    return this._selectedBreakpoint;
  }

  /**
   * Set selected breakpoint
   */
  set selectedBreakpoint(selected: IDebugger.IBreakpoint) {
    this._selectedBreakpoint = selected;
    this._selectedChanged.emit(selected);
  }

  /**
   * Get all the breakpoints.
   */
  get breakpoints(): Map<string, IDebugger.IBreakpoint[]> {
    return this._breakpoints;
  }

  /**
   * Set the breakpoints for a given id (path).
   *
   * @param id The code id (path).
   * @param breakpoints The list of breakpoints.
   */
  setBreakpoints(id: string, breakpoints: IDebugger.IBreakpoint[]): void {
    this._breakpoints.set(id, breakpoints);
    this._changed.emit(breakpoints);
  }

  /**
   * Get the breakpoints for a given id (path).
   *
   * @param id The code id (path).
   */
  getBreakpoints(id: string): IDebugger.IBreakpoint[] {
    return this._breakpoints.get(id) ?? [];
  }

  /**
   * Restore a map of breakpoints.
   *
   * @param breakpoints The map of breakpoints
   */
  restoreBreakpoints(breakpoints: Map<string, IDebugger.IBreakpoint[]>): void {
    this._breakpoints = breakpoints;
    this._restored.emit();
  }

  /**
   * Get a human-readable display string for a breakpoint.
   * Shows execution count if notebook cell, [*] if running, [ ] if never executed.
   */
  getDisplayName(breakpoint: IDebugger.IBreakpoint): string {
    return this._displayRegistry.getDisplayName(
      breakpoint.source as IDebugger.Source
    );
  }

  private _breakpoints = new Map<string, IDebugger.IBreakpoint[]>();
  private _changed = new Signal<this, IDebugger.IBreakpoint[]>(this);
  private _restored = new Signal<this, void>(this);
  private _clicked = new Signal<this, IDebugger.IBreakpoint>(this);
  private _selectedBreakpoint: IDebugger.IBreakpoint;
  private _selectedChanged = new Signal<this, IDebugger.IBreakpoint>(this);
  private _displayRegistry: IDebuggerDisplayRegistry;
}

/**
 * Namespace for BreakpointsModel
 */
export namespace BreakpointsModel {
  /**
   * Instantiation options for a BreakpointsModel.
   */
  export interface IOptions {
    /**
     * The debugger display registry.
     */
    displayRegistry: IDebuggerDisplayRegistry;
  }
}
