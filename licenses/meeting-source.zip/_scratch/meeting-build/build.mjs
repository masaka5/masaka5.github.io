import {build} from 'esbuild';
import {mkdir,copyFile,writeFile,readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const target=resolve('../../toolbox-site/vendor/meeting');
await mkdir(target,{recursive:true});
for(const [name,pkg] of [['nostr','trystero'],['mqtt','@trystero-p2p/mqtt']]){
 await build({stdin:{contents:`export {joinRoom,getRelaySockets,defaultRelayUrls} from '${pkg}';`,resolveDir:process.cwd()},bundle:true,format:'esm',target:'es2022',minify:true,legalComments:'eof',outfile:resolve(target,name+'.js')});
}
await copyFile('node_modules/trystero/LICENSE',resolve(target,'LICENSE.txt'));
await writeFile(resolve(target,'SOURCE.txt'),'Trystero 0.27.0 (MIT)\nhttps://github.com/dmotz/trystero\nBundled using esbuild 0.25.12.\nSource and locked build: ../../licenses/meeting-source.zip\n');
await writeFile(resolve(target,'versions.json'),JSON.stringify({trystero:'0.27.0',mqtt:'0.27.0',esbuild:'0.25.12'},null,2));
console.log('Built local meeting runtimes');
