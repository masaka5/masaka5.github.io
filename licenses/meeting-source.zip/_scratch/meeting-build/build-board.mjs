import {build} from 'esbuild';import {mkdir,readFile,writeFile} from 'node:fs/promises';import {resolve} from 'node:path';import {createHash} from 'node:crypto';
const output=resolve('../../toolbox-site/tools/meeting/meeting-board.js');
await build({entryPoints:['src/board-ui.mjs'],outfile:output,bundle:true,minify:true,format:'esm',target:'es2022',legalComments:'eof'});
const dir=resolve('../../toolbox-site/licenses/meeting-whiteboard');await mkdir(dir,{recursive:true});const licenses=[];
for(const name of ['yjs','lib0','isomorphic.js']){const pkg=JSON.parse(await readFile('node_modules/'+name+'/package.json','utf8'));const license=await readFile('node_modules/'+name+'/LICENSE','utf8');licenses.push(`===== ${name}@${pkg.version} (${pkg.license}) =====\n${license}`);}
await writeFile(resolve(dir,'THIRD-PARTY-NOTICES.txt'),licenses.join('\n\n'));
const data=await readFile(output);console.log(JSON.stringify({boardBytes:data.length,sha256:createHash('sha256').update(data).digest('hex')}));
