export const W=1600,H=900;
export function bounds(s){if(s.type==='stroke'){const xs=s.points.filter((_,i)=>i%2===0),ys=s.points.filter((_,i)=>i%2);return{x:Math.min(...xs),y:Math.min(...ys),w:Math.max(...xs)-Math.min(...xs),h:Math.max(...ys)-Math.min(...ys)};}return{x:Math.min(s.x,s.x+s.w),y:Math.min(s.y,s.y+s.h),w:Math.abs(s.w),h:Math.abs(s.h)};}
export function draw(ctx,s){
 ctx.save();ctx.strokeStyle=s.color;ctx.fillStyle=s.color;ctx.lineWidth=s.width;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();
 if(s.type==='stroke'){ctx.moveTo(s.points[0],s.points[1]);for(let i=2;i<s.points.length;i+=2)ctx.lineTo(s.points[i],s.points[i+1]);if(s.points.length===2){ctx.lineTo(s.points[0]+.1,s.points[1]+.1);}}
 else if(s.type==='rect')ctx.rect(s.x,s.y,s.w,s.h);
 else if(s.type==='ellipse')ctx.ellipse(s.x+s.w/2,s.y+s.h/2,Math.abs(s.w/2),Math.abs(s.h/2),0,0,Math.PI*2);
 else if(s.type==='line'||s.type==='arrow'){ctx.moveTo(s.x,s.y);ctx.lineTo(s.x+s.w,s.y+s.h);if(s.type==='arrow'){const a=Math.atan2(s.h,s.w),l=14+s.width;ctx.moveTo(s.x+s.w-l*Math.cos(a-.45),s.y+s.h-l*Math.sin(a-.45));ctx.lineTo(s.x+s.w,s.y+s.h);ctx.lineTo(s.x+s.w-l*Math.cos(a+.45),s.y+s.h-l*Math.sin(a+.45));}}
 else if(s.type==='text'){ctx.font='28px "Microsoft YaHei",sans-serif';ctx.textBaseline='top';s.text.split('\n').forEach((line,i)=>ctx.fillText(line,s.x,s.y+i*36));}
 ctx.stroke();ctx.restore();
}
export function hit(s,p){const b=bounds(s),pad=12;if(p.x<b.x-pad||p.x>b.x+b.w+pad||p.y<b.y-pad||p.y>b.y+b.h+pad)return false;if(s.type==='line'||s.type==='arrow'){const dx=s.w,dy=s.h,len=dx*dx+dy*dy,t=len?Math.max(0,Math.min(1,((p.x-s.x)*dx+(p.y-s.y)*dy)/len)):0;return Math.hypot(p.x-s.x-t*dx,p.y-s.y-t*dy)<pad;}return true;}
export function move(s,dx,dy){if(s.type==='stroke')return{points:s.points.map((n,i)=>Math.max(0,Math.min(i%2?H:W,n+(i%2?dy:dx))))};return{x:Math.max(0,Math.min(W-Math.abs(s.w),s.x+dx)),y:Math.max(0,Math.min(H-Math.abs(s.h),s.y+dy))};}
