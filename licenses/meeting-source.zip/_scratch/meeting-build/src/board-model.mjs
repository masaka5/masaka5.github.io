import * as Y from 'yjs';
export const MAX_PACKET=900*1024,MAX_STATE=800*1024;
const LOCAL=Symbol('local'),REMOTE=Symbol('remote'),types=new Set(['stroke','rect','ellipse','line','arrow','text']);
const keys=new Set(['type','x','y','w','h','color','width','points','text']);
function shapeOK(s){
 if(!s||!types.has(s.type)||Object.keys(s).some(k=>!keys.has(k)))throw Error('白板元素格式无效');
 for(const k of ['x','y','w','h'])if(!Number.isFinite(s[k])||Math.abs(s[k])>3200)throw Error('白板坐标无效');
 if(!/^#[0-9a-f]{6}$/i.test(s.color)||!Number.isFinite(s.width)||s.width<1||s.width>20)throw Error('白板样式无效');
 if(s.type==='stroke'&&(!Array.isArray(s.points)||s.points.length<2||s.points.length%2||s.points.length>4096||s.points.some(n=>!Number.isFinite(n)||n<0||n>1600)))throw Error('笔迹数据无效');
 if(s.type!=='stroke'&&s.points!==undefined)throw Error('白板元素格式无效');
 if(s.type==='text'&&(typeof s.text!=='string'||s.text.length>1000))throw Error('文字最多 1000 字');
 if(s.type!=='text'&&s.text!==undefined)throw Error('白板元素格式无效');return s;
}
function validate(doc){const map=doc.getMap('shapes');if(map.size>1000)throw Error('白板元素已达上限');for(const[id,value]of map){if(id.length>100||!(value instanceof Y.Map))throw Error('白板元素无效');shapeOK(value.toJSON());}}
export class WhiteboardDoc{
 constructor(){this.doc=new Y.Doc();this.shapes=this.doc.getMap('shapes');this.undoManager=new Y.UndoManager(this.shapes,{trackedOrigins:new Set([LOCAL]),captureTimeout:500});}
 items(){return [...this.shapes].map(([id,value])=>({id,...value.toJSON()})).sort((a,b)=>a.id.localeCompare(b.id));}
 get(id){const value=this.shapes.get(id);return value?{id,...value.toJSON()}:null;}
 reserve(fields){if(Y.encodeStateAsUpdate(this.doc).length+JSON.stringify(fields).length*2+512>600*1024)throw Error('白板内容较多，请导出并清理后继续');}
 add(shape){shapeOK(shape);if(this.shapes.size>=1000)throw Error('白板元素已达上限');this.reserve(shape);const id=crypto.randomUUID();this.doc.transact(()=>{this.shapes.set(id,new Y.Map(Object.entries(shape)));},LOCAL);return id;}
 edit(id,fields){const item=this.shapes.get(id);if(!item)return;const next={...item.toJSON(),...fields};shapeOK(next);this.reserve(fields);this.doc.transact(()=>{for(const [key,value]of Object.entries(fields))item.set(key,value);},LOCAL);}
 remove(ids){this.commit();this.doc.transact(()=>{for(const id of ids)this.shapes.delete(id);},LOCAL);this.commit();}
 clear(){this.remove([...this.shapes.keys()]);}
 undo(){this.undoManager.undo();}
 redo(){this.undoManager.redo();}
 commit(){this.undoManager.stopCapturing();}
 encode(){return Y.encodeStateAsUpdate(this.doc);}
 vector(){return Y.encodeStateVector(this.doc);}
 diff(vector){if(!(vector instanceof Uint8Array)||vector.length>12000)throw Error('白板同步参数无效');return Y.encodeStateAsUpdate(this.doc,vector);}
 apply(update){
  if(!(update instanceof Uint8Array)||update.length>MAX_PACKET)throw Error('白板同步包超出限制');
  const check=new Y.Doc();try{Y.applyUpdate(check,this.encode());Y.applyUpdate(check,update);validate(check);if(Y.encodeStateAsUpdate(check).length>MAX_STATE)throw Error('白板内容超出限制');}catch(error){throw Error(error.message?.includes('白板')?error.message:'白板同步数据无效');}finally{check.destroy();}
  Y.applyUpdate(this.doc,update,REMOTE);
 }
 onUpdate(callback){const handler=(update,origin)=>callback(update,origin===REMOTE);this.doc.on('update',handler);return()=>this.doc.off('update',handler);}
 destroy(){this.undoManager.destroy();this.doc.destroy();}
}
