export class BoardSync{
 constructor(model,transport,onError){
  this.model=model;this.transport=transport;this.onError=onError;this.closed=false;this.pending=[];this.flushing=false;
  this.off=model.onUpdate((update,remote)=>{if(!remote){this.pending.push(update);this.flush();}});
  this.message=e=>this.receive(e.detail);this.peer=e=>this.hello(e.detail.peerId);
  transport.addEventListener('board',this.message);transport.addEventListener('peerjoin',this.peer);
  this.online=()=>this.hello();globalThis.addEventListener?.('online',this.online);
  this.timer=setInterval(()=>this.hello(),15000);this.hello();
 }
 async hello(target){if(this.closed)return;try{await this.send(0,this.model.vector(),target);}catch{if(!this.closed)this.onError('白板同步待恢复，已保留本地内容');}}
 async send(type,bytes,target){if(this.closed)return;const packet=new Uint8Array(bytes.length+1);packet[0]=type;packet.set(bytes,1);await this.transport.sendBoard(packet,target);}
 async flush(){if(this.flushing||this.closed)return;this.flushing=true;try{while(this.pending.length&&!this.closed){const update=this.pending.shift();await this.send(1,update);}}catch{this.pending=[];if(!this.closed)this.onError('白板同步待恢复，已保留本地内容');}finally{this.flushing=false;}}
 async receive({data,peerId}){if(this.closed||!(data instanceof Uint8Array)||!data.length)return;try{if(data[0]===0)await this.send(1,this.model.diff(data.subarray(1)),peerId);else if(data[0]===1)this.model.apply(data.subarray(1));else throw Error('白板消息无效');}catch(error){if(!this.closed)this.onError(error.message||'白板同步失败');}}
 close(){this.closed=true;clearInterval(this.timer);this.pending=[];this.off();this.transport.removeEventListener('board',this.message);this.transport.removeEventListener('peerjoin',this.peer);globalThis.removeEventListener?.('online',this.online);}
}
