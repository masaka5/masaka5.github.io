import test from 'node:test';import assert from 'node:assert/strict';import * as Y from 'yjs';import {WhiteboardDoc} from '../src/board-model.mjs';
const rect=(x=10)=>({type:'rect',x,y:20,w:100,h:60,color:'#315fc9',width:3});
const sync=(a,b)=>{const x=a.diff(b.vector()),y=b.diff(a.vector());a.apply(y);b.apply(x);};
test('simultaneous drawings and independent edits converge with duplicate and reordered updates',()=>{
 const a=new WhiteboardDoc(),b=new WhiteboardDoc();const x=a.add(rect()),y=b.add(rect(200));sync(a,b);
 assert.equal(a.items().length,2);a.edit(x,{x:44});b.edit(x,{color:'#111111'});sync(a,b);
 assert.deepEqual(a.items(),b.items());assert.equal(a.get(x).x,44);assert.equal(a.get(x).color,'#111111');
 const updates=[];a.onUpdate(u=>updates.push(u));a.edit(y,{x:205});a.edit(y,{x:210});for(const u of updates.toReversed())b.apply(u);for(const u of updates)b.apply(u);
 assert.deepEqual(a.items(),b.items());a.destroy();b.destroy();
});
test('undo changes only local history, deletions and stale peers merge without resurrecting elements',()=>{
 const a=new WhiteboardDoc(),b=new WhiteboardDoc();const x=a.add(rect());a.commit();sync(a,b);const y=b.add(rect(300));b.commit();sync(a,b);
 a.undo();sync(a,b);assert.equal(b.get(x),null);assert.ok(b.get(y));a.redo();sync(a,b);assert.ok(b.get(x));
 a.remove([x]);b.edit(x,{x:99});sync(a,b);assert.equal(b.get(x),null);assert.ok(b.get(y));
 a.destroy();b.destroy();
});
test('clear keeps concurrent new drawings; snapshot supports late join and replay',()=>{
 const a=new WhiteboardDoc(),b=new WhiteboardDoc();a.add(rect());sync(a,b);a.clear();const id=b.add(rect(400));sync(a,b);assert.deepEqual(a.items(),b.items());assert.ok(a.get(id));
 const c=new WhiteboardDoc();c.apply(a.encode());assert.deepEqual(a.items(),c.items());a.destroy();b.destroy();c.destroy();
});
test('invalid geometry, payloads and packets are rejected without poisoning the active document',()=>{
 const a=new WhiteboardDoc();assert.throws(()=>a.add({...rect(),x:NaN}));assert.throws(()=>a.add({...rect(),type:'script'}));assert.throws(()=>a.add({...rect(),points:new Array(5000).fill(1)}));
 const id=a.add(rect());assert.throws(()=>a.apply(new Uint8Array(950000)));assert.throws(()=>a.apply(new Uint8Array([1,2,3])));assert.ok(a.get(id));a.destroy();
});
test('a structurally valid CRDT update with invalid shape data is quarantined',()=>{
 const a=new WhiteboardDoc(),malicious=new Y.Doc();a.add(rect());const before=a.items();
 malicious.getMap('shapes').set('bad',new Y.Map(Object.entries({...rect(),type:'script'})));
 assert.throws(()=>a.apply(Y.encodeStateAsUpdate(malicious)),/白板/);assert.deepEqual(a.items(),before);malicious.destroy();a.destroy();
});
