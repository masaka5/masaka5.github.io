import test from 'node:test';import assert from 'node:assert/strict';import {WhiteboardDoc} from '../src/board-model.mjs';import {BoardSync} from '../src/board-sync.mjs';
class Transport extends EventTarget{async sendBoard(data){if(!this.blocked)this.other.dispatchEvent(new CustomEvent('board',{detail:{data,peerId:'peer'}}));}}
const wait=()=>new Promise(r=>setTimeout(r,5));
test('state vectors reconcile independent edits after interrupted delivery without echo storms',async()=>{
 const a=new WhiteboardDoc(),b=new WhiteboardDoc(),ta=new Transport(),tb=new Transport();ta.other=tb;tb.other=ta;
 const errors=[],sa=new BoardSync(a,ta,e=>errors.push(e)),sb=new BoardSync(b,tb,e=>errors.push(e));
 ta.blocked=tb.blocked=true;const shape={type:'rect',x:10,y:20,w:100,h:60,color:'#315fc9',width:3};a.add(shape);b.add({...shape,x:200});await wait();assert.equal(a.items().length,1);
 ta.blocked=tb.blocked=false;await sa.hello();await sb.hello();await wait();assert.deepEqual(a.items(),b.items());assert.equal(a.items().length,2);assert.deepEqual(errors,[]);
 sa.close();sb.close();const before=b.items();a.add(shape);await wait();assert.deepEqual(b.items(),before);a.destroy();b.destroy();
});
