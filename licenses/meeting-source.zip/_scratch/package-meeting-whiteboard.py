"""Update the meeting source archive without duplicating new dependency bundles."""
from pathlib import Path
import json,zipfile,hashlib,os
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site';BUILD=ROOT/'_scratch/meeting-build'
sha=lambda data:hashlib.sha256(data).hexdigest()
updates={}
for name in ['package.json','package-lock.json','build.mjs','build-board.mjs','README-whiteboard.md']:
 updates['_scratch/meeting-build/'+name]=BUILD/name
for folder in ['src','tests']:
 for p in(BUILD/folder).rglob('*'):
  if p.is_file()and '__pycache__'not in p.parts:updates['_scratch/meeting-build/'+p.relative_to(BUILD).as_posix()]=p
for p in(SITE/'tools/meeting').glob('*'):
 if p.is_file()and p.name!='manifest.json':updates['toolbox-site/tools/meeting/'+p.name]=p
updates['_scratch/ops-tests/meeting-whiteboard.py']=ROOT/'_scratch/ops-tests/meeting-whiteboard.py'
updates['_scratch/ops-tests/meeting-whiteboard-cross.py']=ROOT/'_scratch/ops-tests/meeting-whiteboard-cross.py'
updates['_scratch/package-meeting-whiteboard.py']=Path(__file__).resolve()
updates['toolbox-site/licenses/meeting-whiteboard/THIRD-PARTY-NOTICES.txt']=SITE/'licenses/meeting-whiteboard/THIRD-PARTY-NOTICES.txt'
archive=SITE/'licenses/meeting-source.zip';temp=archive.with_suffix('.board.zip')
with zipfile.ZipFile(archive)as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for info in old.infolist():
  if info.filename not in updates:z.writestr(info,old.read(info.filename))
 for name,path in updates.items():z.write(path,name)
os.replace(temp,archive)
rows=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}for name,path in sorted(updates.items())]
(SITE/'licenses/meeting-whiteboard/source-manifest.json').write_text(json.dumps({'sourceArchive':'../meeting-source.zip','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'updatedSources':rows,'dependency':'yjs@13.6.31 (MIT)'},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
files=[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted((SITE/'tools/meeting').glob('*'))if p.is_file()and p.name!='manifest.json']
(SITE/'tools/meeting/manifest.json').write_text(json.dumps({'name':'在线会议与协作白板','files':files},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'sourceUpdatedFiles':len(rows),'meetingArchiveBytes':archive.stat().st_size,'runtimeFiles':len(files)}))
