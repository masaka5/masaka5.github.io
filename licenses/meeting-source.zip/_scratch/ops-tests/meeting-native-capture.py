"""Exercise Chromium's real getDisplayMedia, without replacing the API."""
import asyncio,json,os,sys
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8')
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch(channel='chrome',headless=True,ignore_default_args=['--mute-audio'],args=['--enable-usermedia-screen-capturing','--auto-select-tab-capture-source-by-title=Toolbox capture target','--allow-http-screen-capture'])
  target=await browser.new_page();await target.set_content('''<title>Toolbox capture target</title><button id="tone">Play test audio</button><h1 id="frame">Native tab capture</h1><script>let n=0;setInterval(()=>document.querySelector('#frame').textContent='Native tab capture '+n++,200);document.querySelector('#tone').onclick=()=>{window.ac=new AudioContext();window.osc=ac.createOscillator();const gain=ac.createGain();gain.gain.value=.03;osc.connect(gain);gain.connect(ac.destination);osc.start()};</script>''')
  await target.locator('#tone').click()
  page=await browser.new_page();await page.goto(BASE+'/tools/meeting/')
  await page.locator('#createMeeting').click();await page.wait_for_function('meetingApp.transport?.self')
  receiver=await browser.new_page();await receiver.goto(page.url);await receiver.locator('#joinMeeting').click();await receiver.wait_for_function('meetingApp.transport?.members.size===1',timeout=60000)
  await page.locator('#shareScreen').click()
  try:
   await page.wait_for_function("meetingApp.media.entries.has('screen')",timeout=20000)
   await receiver.wait_for_function("document.querySelector('[data-kind=screen] video')?.videoWidth>0",timeout=30000)
   if await receiver.locator('#enableSound').is_visible():await receiver.locator('#enableSound').click()
   await receiver.wait_for_timeout(3000)
   received=await receiver.evaluate('''async()=>{let frames=0,energy=0,packets=0;for(const p of Object.values(meetingApp.transport.room.getPeers())){const s=await p.connection.getStats();s.forEach(r=>{if(r.type==='inbound-rtp'){frames+=r.framesDecoded||0;energy+=r.totalAudioEnergy||0;packets+=r.packetsReceived||0}})}return {frames,energy,packets}}''')
   print('SOURCE_AUDIO',await target.evaluate('({state:ac.state,time:ac.currentTime})'),flush=True)
   print('CAPTURE_SETTINGS',await page.evaluate("meetingApp.media.entries.get('screen').stream.getAudioTracks()[0]?.getSettings()"),flush=True)
   assert received['frames']>0 and received['energy']>0.000001,received
   print('NATIVE_RECEIVER',json.dumps(received),flush=True)
   print(json.dumps(await page.evaluate("(()=>{const s=meetingApp.media.entries.get('screen').stream;return {native_capture:true,tracks:s.getTracks().map(t=>({kind:t.kind,state:t.readyState,settings:t.getSettings()}))}})()")),flush=True)
   await page.locator('#shareScreen').click();await page.locator('#leaveMeeting').click();await receiver.locator('#leaveMeeting').click()
  finally:
   print('CAPTURE_STATUS',await page.locator('#meetingNotice').inner_text(),flush=True)
   await browser.close()
asyncio.run(main())
