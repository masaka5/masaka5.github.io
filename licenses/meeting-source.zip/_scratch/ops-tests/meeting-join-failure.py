"""Media publish failure must leave an actionable meeting instead of a dead UI."""
import asyncio,sys
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch(headless=True,args=['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
  page=await browser.new_page(permissions=['camera','microphone']);await page.goto('http://127.0.0.1:8765/tools/meeting/')
  await page.locator('#previewCamera').click();await page.wait_for_function("meetingApp.media.entries.has('camera')")
  await page.evaluate("async()=>{const {MeetingTransport}=await import('./meeting-transport.js');MeetingTransport.prototype.publish=async()=>{throw Error('injected media publication failure')}}")
  await page.locator('#createMeeting').click();await page.wait_for_timeout(1500)
  assert await page.evaluate("!document.querySelector('#meetingRoom').hidden && !!meetingApp.transport && !meetingApp.transport.closed"),'Media failure stranded a joined room'
  assert '发送' in await page.locator('#meetingNotice').inner_text()
  await page.locator('#leaveMeeting').click();assert await page.evaluate("meetingApp.media.entries.size===0")
  await browser.close();print('PASS media failure keeps text meeting usable, leave releases camera')
asyncio.run(main())
