"""Three isolated browser participants, public signaling and real WebRTC RTP."""
import asyncio,json,os,sys,time
from pathlib import Path
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8',errors='backslashreplace')
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
# Capture a moving canvas + oscillator: real MediaStreams and RTP without
# claiming this replaces device-permission or cross-ISP verification.
CAPTURE='''(()=>{window.testCaptures=[];navigator.mediaDevices.getDisplayMedia=async()=>{
 const c=document.createElement('canvas');c.width=640;c.height=360;const ctx=c.getContext('2d');let n=0;
 const timer=setInterval(()=>{ctx.fillStyle=n++%2?'#285de5':'#217c59';ctx.fillRect(0,0,640,360);ctx.fillStyle='white';ctx.font='30px sans-serif';ctx.fillText('Shared screen '+n,40,100)},100);
 const s=c.captureStream(10);const a=new AudioContext(),o=a.createOscillator(),d=a.createMediaStreamDestination();o.connect(d);o.start();s.addTrack(d.stream.getAudioTracks()[0]);
 const stop=s.getVideoTracks()[0].stop.bind(s.getVideoTracks()[0]);s.getVideoTracks()[0].stop=()=>{stop();clearInterval(timer);a.close()};testCaptures.push(s);return s;};})();'''
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,args=['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required'])
  contexts=[await browser.new_context(permissions=['camera','microphone'],viewport={'width':1440,'height':900}) for _ in range(3)]
  pages=[await c.new_page() for c in contexts];errors=[]
  for page in pages:
   page.on('pageerror',lambda e:errors.append(str(e)))
   await page.add_init_script(CAPTURE)
  response=await pages[0].goto(BASE+'/tools/meeting/');assert response.status==200,'Meeting page not implemented'
  await pages[0].locator('#displayName').fill('测试甲')
  await pages[0].locator('#createMeeting').click()
  await pages[0].wait_for_function("document.querySelector('#meetingRoom').hidden===false")
  invitation=pages[0].url
  async def join(i):
   await pages[i].goto(invitation);await pages[i].locator('#displayName').fill(['甲','乙','丙'][i]);await pages[i].locator('#joinMeeting').click()
   await pages[i].wait_for_function('n=>window.meetingApp?.transport?.members.size===n',arg=i,timeout=60000)
  await join(1)
  await pages[0].locator('#toggleMic').click();await pages[0].locator('#toggleCamera').click()
  await pages[0].locator('#shareScreen').click();await pages[1].locator('#shareScreen').click()
  await join(2)
  await asyncio.gather(*[page.wait_for_function('meetingApp.transport.members.size===2',timeout=60000) for page in pages])
  for page in pages:await page.wait_for_function("document.querySelectorAll('[data-kind=screen]').length===2",timeout=30000)
  await pages[2].wait_for_function("[...meetingApp.transport.remote.values()].filter(e=>e.kind==='screen').length===2 && [...meetingApp.transport.remote.values()].some(e=>e.kind==='mic') && [...meetingApp.transport.remote.values()].some(e=>e.kind==='camera')",timeout=30000)
  await pages[0].locator('#openChat').click();await pages[0].locator('#chatText').fill('<img src=x onerror=alert(1)> 中文消息');await pages[0].locator('#sendChat').click()
  for page in pages[1:]:await page.wait_for_function("document.querySelector('#chatMessages').textContent.includes('中文消息')",timeout=15000)
  assert await pages[1].locator('#chatMessages img').count()==0
  await pages[2].wait_for_function("[...document.querySelectorAll('[data-kind=screen] video')].every(v=>v.readyState>=2&&v.videoWidth>0)",timeout=30000)
  await pages[2].wait_for_function("meetingApp.audio.size===3",timeout=15000)
  await pages[2].wait_for_timeout(3000)
  stats=await pages[2].evaluate('''async()=>{let video=0,audio=0,bytes=0;for(const p of Object.values(meetingApp.transport.room.getPeers())){const s=await p.connection.getStats();s.forEach(r=>{if(r.type==='inbound-rtp'){bytes+=r.bytesReceived||0;if(r.kind==='video')video+=r.framesDecoded||0;if(r.kind==='audio')audio+=r.packetsReceived||0}})}return {video,audio,bytes}}''')
  assert stats['video']>0 and stats['audio']>0 and stats['bytes']>0,stats
  # A failed autoplay must produce an actionable button; retry must restore it.
  await pages[2].evaluate("(()=>{const saved=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){return Promise.reject(Error('blocked'))};meetingApp.originalPlay=saved;})()")
  await pages[2].locator('#enableSound').evaluate('b=>b.hidden=false');await pages[2].locator('#enableSound').click();assert await pages[2].locator('#enableSound').is_visible()
  await pages[2].evaluate('()=>{HTMLMediaElement.prototype.play=meetingApp.originalPlay}');await pages[2].locator('#enableSound').click();await pages[2].locator('#enableSound').wait_for(state='hidden',timeout=15000)
  await pages[0].locator('#shareScreen').click()
  await pages[2].wait_for_function("document.querySelectorAll('[data-kind=screen]').length===1",timeout=15000)
  await pages[0].screenshot(path='_scratch/meeting-desktop.png')
  await pages[2].set_viewport_size({'width':390,'height':844})
  assert await pages[2].evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight')
  await pages[2].locator('#openChat').click();await pages[2].screenshot(path='_scratch/meeting-mobile.png')
  await pages[1].locator('#leaveMeeting').click()
  await pages[2].wait_for_function('meetingApp.transport.members.size===1')
  assert await pages[1].evaluate('testCaptures.every(s=>s.getTracks().every(t=>t.readyState==="ended"))')
  await pages[1].locator('#joinMeeting').click();await pages[1].wait_for_function('meetingApp.transport.members.size===2',timeout=60000)
  for page in pages:await page.locator('#leaveMeeting').click()
  assert not errors,errors
  result={'base':BASE,'participants':3,'public_signaling':'MQTT','real_webrtc_rtp':stats,'simulated_capture_sources':True,'late_join':True,'multi_screen':True,'chat_xss_safe':True,'stop_share_and_rejoin':True,'errors':errors}
  Path('_scratch/meeting-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
  await browser.close()
asyncio.run(main())
