const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const file='toolbox-site/tools/meeting/meeting-core.js';
const ready=fs.existsSync(file)?import('data:text/javascript;base64,'+fs.readFileSync(file).toString('base64')):Promise.resolve(null);
test('meeting core exists',async()=>assert.ok(await ready,'meeting core has not been implemented'));
test('invites use random credentials and fragment-only links',async()=>{
 const c=await ready;assert.ok(c);const a=c.createInvite(),b=c.createInvite();
 assert.match(a.room,/^[\w-]{22}$/);assert.match(a.key,/^[\w-]{32}$/);assert.notDeepEqual(a,b);
 const link=c.inviteURL(a,'https://tools.manshii.asia/tools/meeting/?old=1');
 assert.equal(new URL(link).search,'');assert.deepEqual(c.parseInvite(link),a);
 assert.deepEqual(c.parseInvite(c.inviteCode(a)),a);
 for(const bad of ['abc','https://evil.test/#room=a&key=b',c.inviteCode(a).replace('.mqtt','.bad')])assert.throws(()=>c.parseInvite(bad));
});
test('received messages and media descriptors are strictly bounded',async()=>{
 const c=await ready;assert.ok(c);assert.equal(c.validChat({id:'a'.repeat(22),text:'中文',at:1}),true);
 assert.equal(c.validChat({id:'a'.repeat(22),text:'x'.repeat(2001),at:1}),false);
 assert.equal(c.validChat({id:'a'.repeat(22),text:'',at:1}),false);
 assert.equal(c.cleanName('  张三\n '),'张三');assert.equal(c.cleanName('x'.repeat(60)).length,24);
 assert.equal(c.validMedia({kind:'screen',token:'a'.repeat(22)}),true);
 assert.equal(c.validMedia({kind:'bad',token:'a'.repeat(22)}),false);
 assert.equal(c.validMedia({kind:'screen',token:'../x'}),false);
});
test('TURN settings reject non-TURN URLs and incomplete credentials',async()=>{
 const c=await ready;assert.ok(c);assert.deepEqual(c.turnConfig('','',''),[]);
 assert.equal(c.turnConfig('turn:example.com:3478?transport=udp','alice','secret')[0].username,'alice');
 for(const u of ['https://evil.test','turn:evil.test/path','turn:host\nattack'])assert.throws(()=>c.turnConfig(u,'a','b'));
 assert.throws(()=>c.turnConfig('turn:example.com','',''));
});
