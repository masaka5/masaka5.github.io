const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const url=p=>'data:text/javascript;base64,'+fs.readFileSync(p).toString('base64');
const core=url('toolbox-site/tools/meeting/meeting-core.js');
const ready=import('data:text/javascript;base64,'+Buffer.from(fs.readFileSync('toolbox-site/tools/meeting/meeting-transport.js','utf8').replace("'./meeting-core.js'",JSON.stringify(core))).toString('base64'));
async function transport(){const {MeetingTransport}=await ready;return new MeetingTransport({invite:{room:'a'.repeat(22),key:'b'.repeat(32),via:'mqtt'},name:'测试'});}
test('stopping a source during profile send never adds the stopped stream',async()=>{
 const t=await transport(),calls=[];let resolve;t.profileAction={send:()=>new Promise(r=>resolve=r)};t.stopAction={send:async()=>{}};
 t.room={addStream:async()=>calls.push('add'),removeStream:()=>calls.push('remove')};
 const entry={kind:'screen',token:'a'.repeat(22),stream:{}};const publish=t.publish(entry);
 t.profileAction={send:async()=>{}};await t.unpublish(entry);resolve();await publish;assert.deepEqual(calls,['remove']);
});
test('old source stop cannot remove a replacement of the same kind',async()=>{
 const t=await transport();t.room={removeStream:()=>{}};t.profileAction=t.stopAction={send:async()=>{}};
 const previous={kind:'screen',token:'a'.repeat(22),stream:{}},next={kind:'screen',token:'b'.repeat(22),stream:{}};
 t.local.set('screen',next);await t.unpublish(previous);assert.equal(t.local.get('screen'),next);
});
