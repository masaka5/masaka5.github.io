"""Real public-relay discovery and WebRTC data channels, without app UI."""
import asyncio,json,sys
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8')
BASE='http://127.0.0.1:8765'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True)
  for strategy in ['mqtt','nostr']:
   contexts=[await browser.new_context() for _ in range(3)]
   pages=[await c.new_page() for c in contexts]
   for page in pages:await page.goto(BASE)
   room='meeting-test-'+__import__('uuid').uuid4().hex
   await asyncio.gather(*[page.evaluate('''async ({strategy,room})=>{
    const {joinRoom,getRelaySockets}=await import('/vendor/meeting/'+strategy+'.js');
    window.received=[];window.peers=[];window.failures=[];
    const r=window.room=joinRoom({appId:'tools.manshii.asia/meeting-test',identity:'none',password:'real-test-secret',relayConfig:{redundancy:4}},room);
    r.onPeerJoin(ctx=>peers.push(ctx));r.onError(e=>failures.push({code:e.code,message:e.message}));
    const action=r.makeAction('test');action.onMessage((m,ctx)=>received.push({m,ctx}));window.send=action.send;window.sockets=getRelaySockets;
   }''',{'strategy':strategy,'room':room}) for page in pages])
   try:
    await asyncio.gather(*[page.wait_for_function('peers.length===2',timeout=60000) for page in pages])
    for i,page in enumerate(pages):await page.evaluate('i=>send({hello:i})',i)
    await asyncio.gather(*[page.wait_for_function('received.length===2',timeout=15000) for page in pages])
    print('PUBLIC_RELAY_PASS',strategy,flush=True)
   except Exception as e:
    print('PUBLIC_RELAY_FAIL',strategy,str(e)[:100],flush=True)
   for page in pages:print(json.dumps(await page.evaluate('({peers,received,failures,sockets:Object.fromEntries(Object.entries(sockets()).map(([u,s])=>[u,s.readyState]))})')),flush=True)
   for c in contexts:await c.close()
  await browser.close()
asyncio.run(main())
