"""Permission denial, external share end, no-audio capture and async cleanup."""
import asyncio,json,sys
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8',errors='backslashreplace')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True)
  page=await browser.new_page(viewport={'width':390,'height':844});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.add_init_script("navigator.mediaDevices.getUserMedia=async()=>{throw new DOMException('denied','NotAllowedError')}")
  await page.goto('http://127.0.0.1:8765/tools/meeting/')
  await page.locator('#previewMic').click();assert '授权' in await page.locator('#lobbyStatus').inner_text()
  assert not await page.locator('#createMeeting').is_disabled()
  await page.screenshot(path='_scratch/meeting-lobby-mobile.png')
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/meeting-lobby.png')
  for width,height in [(1440,900),(390,844),(320,568),(844,390)]:
   await page.set_viewport_size({'width':width,'height':height})
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(width,height)
   assert await page.locator('.lobby-form').evaluate("e=>getComputedStyle(e).scrollbarWidth==='none'")
  await page.evaluate('''async()=>{
   const {MeetingMedia}=await import('./meeting-media.js');window.events=[];window.m=new MeetingMedia((e,a)=>events.push({kind:e.kind,active:a}));
   navigator.mediaDevices.getDisplayMedia=async()=>{const c=document.createElement('canvas');c.width=100;c.height=100;window.capture=c.captureStream();return capture;};
   const entry=await m.start('screen');if(entry.audio)throw Error('No audio was captured');
   const t=entry.stream.getVideoTracks()[0];t.stop();t.dispatchEvent(new Event('ended'));
   if(m.entries.size||!events.some(e=>!e.active))throw Error('External share end did not clean up');
   navigator.mediaDevices.getUserMedia=()=>new Promise(r=>window.resolveMedia=r);
   const pending=m.start('camera');m.stopAll();const c=document.createElement('canvas');window.late=c.captureStream();resolveMedia(late);await pending;
   if(m.entries.size||late.getTracks().some(t=>t.readyState!=='ended'))throw Error('Late permission result leaked capture');
  }''')
  await page.locator('#openSettings').click();await page.locator('#settingsDialog summary').click();await page.locator('#turnURL').fill('https://example.com');await page.locator('#settingsForm .primary').click()
  assert 'TURN' in await page.locator('#settingsStatus').inner_text()
  assert not errors,errors;print(json.dumps({'permissions_denied':True,'external_stop':True,'no_audio':True,'async_cleanup':True,'layouts':4,'errors':errors}))
  await browser.close()
asyncio.run(main())
