from pathlib import Path
import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.environ.get('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  chromium=await p.chromium.launch();firefox=await p.firefox.launch();edge=await p.chromium.launch(channel='msedge')
  a=await chromium.new_page();b=await firefox.new_page();c=await edge.new_page();errors=[]
  for page in[a,b,c]:page.on('pageerror',lambda e:errors.append(str(e)))
  await a.goto(BASE+'/tools/meeting/');await a.locator('#createMeeting').click();await a.locator('#meetingRoom').wait_for(state='visible',timeout=45000);url=a.url
  for page in[b,c]:await page.goto(url);await page.locator('#joinMeeting').click();await page.wait_for_function('meetingApp.whiteboard.sync!==null',timeout=45000)
  for page in[a,b,c]:await page.wait_for_function('meetingApp.transport.members.size===2',timeout=45000);await page.locator('#openWhiteboard').click()
  for i,page in enumerate([a,b,c]):
   await page.get_by_role('button',name='矩形',exact=True).click();box=await page.locator('canvas').bounding_box();x=box['x']+box['width']*(.1+i*.25);y=box['y']+box['height']*.2;await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+45,y+40,steps=4);await page.mouse.up()
  for page in[a,b,c]:await page.wait_for_function('meetingApp.whiteboard.model.items().length===3',timeout=30000)
  for attempt in range(40):
   states=await asyncio.gather(*[page.evaluate('meetingApp.whiteboard.model.items()')for page in[a,b,c]])
   if states[0]==states[1]==states[2]:break
   await a.wait_for_timeout(100)
  assert states[0]==states[1]==states[2];assert not errors,errors
  for page in[a,b,c]:await page.locator('#leaveMeeting').click()
  await chromium.close();await firefox.close();await edge.close();print(json.dumps({'engines':['chromium','firefox','edge'],'actualWebRTC':True,'CRDTConverged':True,'pageErrors':errors}))
asyncio.run(main())
