"""Real WebRTC room whiteboard: independent contexts, CRDT and UI operations."""
from pathlib import Path
import asyncio,json,os
from playwright.async_api import async_playwright,expect
BASE=os.environ.get('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'_scratch/meeting-whiteboard-tests';OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch(args=['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--autoplay-policy=no-user-gesture-required'])
  contexts=[await browser.new_context(viewport={'width':1440,'height':900},permissions=['microphone','camera'],accept_downloads=True)for _ in range(3)]
  pages=[await c.new_page()for c in contexts];errors=[]
  for page in pages:page.on('pageerror',lambda e:errors.append(str(e)))
  a,b,c=pages;await a.goto(BASE+'/tools/meeting/');await a.locator('#displayName').fill('白板甲');await a.locator('#createMeeting').click();await a.locator('#meetingRoom').wait_for(state='visible',timeout=45000)
  invitation=a.url
  async def join(page,name):
   await page.goto(invitation);await page.locator('#displayName').fill(name);await page.locator('#joinMeeting').click();await page.wait_for_function('meetingApp.whiteboard.sync!==null',timeout=45000)
  async def draw(page,tool,x,y):
   await page.get_by_role('button',name=tool,exact=True).click();box=await page.locator('#meetingWhiteboard canvas').bounding_box();assert box and box['width']>100
   px=box['x']+box['width']*x;py=box['y']+box['height']*y
   await page.mouse.move(px,py);await page.mouse.down();await page.mouse.move(px+box['width']*.12,py+box['height']*.15,steps=8);await page.mouse.up()
  await a.locator('#openWhiteboard').click();await draw(a,'矩形',.1,.1)
  await join(b,'白板乙');await b.locator('#openWhiteboard').click();await b.wait_for_function('meetingApp.whiteboard.model.items().length===1',timeout=30000)
  await asyncio.gather(draw(a,'画笔',.3,.3),draw(b,'椭圆',.6,.3))
  for page in[a,b]:await page.wait_for_function('meetingApp.whiteboard.model.items().length===3',timeout=15000)
  for attempt in range(40):
   left=await a.evaluate('meetingApp.whiteboard.model.items()');right=await b.evaluate('meetingApp.whiteboard.model.items()')
   if left==right:break
   await a.wait_for_timeout(100)
  assert left==right,(left,right)
  # Only the local participant's most recent ellipse is undone, then restored.
  await b.get_by_role('button',name='撤销',exact=True).click();await a.wait_for_function('meetingApp.whiteboard.model.items().length===2');await b.get_by_role('button',name='重做',exact=True).click();await a.wait_for_function('meetingApp.whiteboard.model.items().length===3')
  # Text is rendered into canvas, never parsed into HTML.
  await a.get_by_role('button',name='文字',exact=True).click();await a.locator('#meetingWhiteboard canvas').click(position={'x':120,'y':100});await a.get_by_role('textbox',name='白板文字',exact=True).fill('<img src=x onerror=alert(1)> 中文');await a.get_by_role('button',name='添加文字').click();await b.wait_for_function('meetingApp.whiteboard.model.items().length===4')
  assert await a.locator('#meetingWhiteboard img').count()==0
  await join(c,'白板丙');await c.wait_for_function('meetingApp.whiteboard.model.items().length===4',timeout=30000);await c.locator('#openWhiteboard').click()
  # Select and drag an existing rectangle, then delete using keyboard.
  await c.get_by_role('button',name='选择',exact=True).click();box=await c.locator('#meetingWhiteboard canvas').bounding_box();x=box['x']+box['width']*.14;y=box['y']+box['height']*.17
  await c.mouse.move(x,y);await c.mouse.down();await c.mouse.move(x+30,y+30,steps=5);await c.mouse.up();await c.locator('canvas').press('Delete');await a.wait_for_function('meetingApp.whiteboard.model.items().length===3')
  # Chat and RTP audio stay available while the board is open.
  await a.locator('#toggleMic').click();await b.wait_for_function("[...meetingApp.transport.remote.values()].some(e=>e.kind==='mic')",timeout=20000)
  await a.locator('#openChat').click();await a.locator('#chatText').fill('白板会议消息');await a.locator('#sendChat').click();await b.wait_for_function("document.querySelector('#chatMessages').textContent.includes('白板会议消息')")
  await b.wait_for_timeout(800)
  stats=await b.evaluate("""async()=>{let packets=0;for(const peer of Object.values(meetingApp.transport.room.getPeers())){(await peer.connection.getStats()).forEach(r=>{if(r.type==='inbound-rtp'&&r.kind==='audio')packets+=r.packetsReceived||0;});}return packets;}""");assert stats>0,stats
  await a.locator('#closePanel').click()
  # Refresh restores the room's cached CRDT and then syncs with connected peers.
  await c.reload();await c.locator('#joinMeeting').click();await c.wait_for_function('meetingApp.whiteboard.model?.items().length===3&&meetingApp.whiteboard.sync!==null',timeout=45000);await c.locator('#openWhiteboard').click();await draw(c,'箭头',.7,.6);await a.wait_for_function('meetingApp.whiteboard.model.items().length===4',timeout=30000)
  await c.locator('#leaveMeeting').click();await draw(a,'直线',.4,.7);await c.locator('#joinMeeting').click();await c.wait_for_function('meetingApp.whiteboard.model?.items().length===5',timeout=45000);await c.locator('#openWhiteboard').click()
  # Export bytes and layout/toolbar bounds.
  async with c.expect_download()as event:await c.get_by_role('button',name='导出白板图片').click()
  download=await event.value;await download.save_as(OUT/'board.png');assert(OUT/'board.png').read_bytes().startswith(b'\x89PNG')
  for width,height in[(1440,900),(1280,720),(390,844),(320,568),(844,390)]:
   await c.set_viewport_size({'width':width,'height':height});await c.wait_for_timeout(180)
   metrics=await c.evaluate("""()=>({ok:document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight,canvas:document.querySelector('#meetingWhiteboard canvas').getBoundingClientRect().toJSON(),buttons:[...document.querySelectorAll('.board-toolbar button')].map(b=>b.getBoundingClientRect().toJSON())})""")
   assert metrics['ok'],metrics;assert metrics['canvas']['width']>100 and metrics['canvas']['bottom']<=height,metrics
   assert all(b['right']<=width and b['left']>=0 for b in metrics['buttons']),metrics
   if width in[1440,390,320]:await c.screenshot(path=str(OUT/f'board-{width}.png'))
  # Clear requires confirmation and is synchronized, and can be undone.
  await c.set_viewport_size({'width':1440,'height':900});await c.get_by_role('button',name='清空白板',exact=True).click();await expect(c.get_by_role('alertdialog',name='清空白板')).to_be_visible();await c.get_by_role('button',name='清空',exact=True).click();await a.wait_for_function('meetingApp.whiteboard.model.items().length===0');await c.get_by_role('button',name='撤销',exact=True).click();await a.wait_for_function('meetingApp.whiteboard.model.items().length===5')
  # Pause one participant's whiteboard protocol to simulate a partition while
  # keeping the actual room/data channel. Both sides edit, then state vectors
  # must reconcile through the real WebRTC channel.
  await b.evaluate('window.PausedSync=meetingApp.whiteboard.sync.constructor;meetingApp.whiteboard.sync.close()')
  await asyncio.gather(draw(a,'矩形',.1,.7),draw(b,'椭圆',.6,.7))
  assert await b.evaluate('meetingApp.whiteboard.model.items().length')==6
  await b.evaluate('meetingApp.whiteboard.sync=new PausedSync(meetingApp.whiteboard.model,meetingApp.transport,e=>console.error(e))')
  for page in pages:await page.wait_for_function('meetingApp.whiteboard.model.items().length===7',timeout=30000)
  for attempt in range(40):
   states=await asyncio.gather(*[page.evaluate('meetingApp.whiteboard.model.items()')for page in pages])
   if states[0]==states[1]==states[2]:break
   await a.wait_for_timeout(100)
  assert states[0]==states[1]==states[2]
  # Native Chromium touch events reach the same pointer capture path.
  await c.set_viewport_size({'width':390,'height':844});await c.get_by_role('button',name='画笔',exact=True).click();box=await c.locator('#meetingWhiteboard canvas').bounding_box();touch={'x':box['x']+box['width']*.2,'y':box['y']+box['height']*.3};session=await contexts[2].new_cdp_session(c)
  await session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[touch]});await session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':touch['x']+30,'y':touch['y']+20}]});await session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});await a.wait_for_function('meetingApp.whiteboard.model.items().length===8')
  for page in pages:await page.locator('#leaveMeeting').click()
  assert not errors,errors
  result={'base':BASE,'participants':3,'realWebRTC':True,'concurrentDrawings':True,'localUndoRedo':True,'textXssSafe':True,'lateJoin':True,'dragDelete':True,'chatAndAudioPackets':stats,'refreshResume':True,'rejoinMerge':True,'pngExport':True,'responsiveLayouts':5,'clearUndo':True,'partitionMerge':True,'nativeTouch':True,'pageErrors':errors};(OUT/'results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result),flush=True);await browser.close()
asyncio.run(main())
