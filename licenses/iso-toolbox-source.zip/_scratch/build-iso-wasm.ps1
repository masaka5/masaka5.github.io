$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$codecRoot = Join-Path $projectRoot 'toolbox-site/tools/iso'
& 'C:/Program Files/LLVM/bin/clang.exe' --target=wasm32 -O2 -nostdlib -fno-builtin '-Wl,--no-entry' '-Wl,--export=iso_input' '-Wl,--export=iso_output' '-Wl,--export=iso_record' '-Wl,--export=iso_path' '-Wl,--export=iso_descriptor' '-Wl,--export-memory' '-Wl,--initial-memory=131072' '-Wl,--max-memory=131072' '-Wl,--strip-all' (Join-Path $codecRoot 'iso-codec.c') -o (Join-Path $codecRoot 'iso-codec.wasm')
if ($LASTEXITCODE -ne 0) { throw 'ISO WebAssembly compilation failed' }
Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $codecRoot 'iso-codec.wasm')
