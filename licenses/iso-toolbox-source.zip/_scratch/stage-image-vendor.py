"""Pinned open-source browser codecs; keep corresponding source archives."""
from pathlib import Path
import hashlib,io,json,tarfile,urllib.request,zipfile
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'_scratch/image-build'
def fetch(url):
 with urllib.request.urlopen(url,timeout=60) as r:return r.read()
def stage(package,version,sha,files):
 archive=BASE/f'{package}-{version}.tgz'
 if not archive.exists():archive.write_bytes(fetch(f'https://registry.npmjs.org/{package}/-/{package}-{version}.tgz'))
 data=archive.read_bytes();assert hashlib.sha1(data).hexdigest()==sha
 out=ROOT/'toolbox-site/vendor'/package;out.mkdir(parents=True,exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(data)) as tar:
  for source,target in files.items():(out/target).write_bytes(tar.extractfile('package/'+source).read())
 with zipfile.ZipFile(ROOT/f'toolbox-site/licenses/{package}-source.zip','w',zipfile.ZIP_DEFLATED) as z:z.writestr(archive.name,data)
 return out
out=stage('hash-wasm','4.13.0','714d58df2b630385ec6286833095b871e8d7e90e',{'dist/index.esm.min.js':'hash-wasm.js','LICENSE':'LICENSE.txt'})
(out/'SOURCE.txt').write_text('hash-wasm 4.13.0, MIT\nhttps://github.com/Daninet/hash-wasm\nUnmodified ESM with embedded WebAssembly.\n',encoding='utf8')
out=stage('7z-wasm','1.2.0','f2ddb8b87880bee37bfca70f001b639a12448ef5',{'7zz.es6.js':'7zz.mjs','7zz.wasm':'7zz.wasm','License.txt':'LICENSE.txt','unRarLicense.txt':'unRarLicense.txt'})
(out/'SOURCE.txt').write_text('7z-wasm 1.2.0 / 7-Zip 24.09\nhttps://github.com/use-strict/7z-wasm\nLGPL-2.1-or-later with unRAR restriction. Unmodified runtime, renamed .mjs.\n',encoding='utf8')
out=stage('fatfs-wasm','4.0.0','34a7455f74d21d4917df819298fdd599de76f4c6',{'fatfs.min.mjs':'fatfs.mjs','ff.wasm':'ff.wasm','ff_exfat.wasm':'ff_exfat.wasm','src/fatfs.ts':'fatfs-upstream.ts'})
code=(out/'fatfs.mjs').read_text(encoding='utf8')
assert code.count('typeof window<`u`')==1
(out/'fatfs.mjs').write_text(code.replace('typeof window<`u`','typeof window<`u`||typeof WorkerGlobalScope<`u`').replace('//# sourceMappingURL=fatfs.min.mjs.map',''),encoding='utf8')
# Distribute pinned build source, including native FatFs and build configuration.
for name,repo,ref in [('7z-wasm','use-strict/7z-wasm','10ae71a413a5589a48d11a75ed61f83d90d256db'),('fatfs-wasm','parkertomatoes/fatfs-wasm','9a6f4d0393fa0377723ec767c0a364e584f58fe2')]:
 archive=BASE/(name+'-upstream-source.zip')
 if not archive.exists():archive.write_bytes(fetch(f'https://codeload.github.com/{repo}/zip/{ref}'))
 with zipfile.ZipFile(archive) as z:
  license_names=[n for n in z.namelist()if n.rsplit('/',1)[-1].lower()in ['license','license.txt','copying']]
  if name=='fatfs-wasm':
   assert license_names,'upstream license missing'
   (ROOT/'toolbox-site/vendor'/name/'LICENSE.txt').write_bytes(z.read(license_names[0]))
   native=next(n for n in z.namelist()if n.endswith('/native/ff16/LICENSE.txt'))
   (ROOT/'toolbox-site/vendor'/name/'FATFS-LICENSE.txt').write_bytes(z.read(native))
 with zipfile.ZipFile(ROOT/f'toolbox-site/licenses/{name}-source.zip','a',zipfile.ZIP_DEFLATED) as z:z.writestr(archive.name,archive.read_bytes())
archive=BASE/'7zip-24.09-source.zip'
if not archive.exists():archive.write_bytes(fetch('https://codeload.github.com/ip7z/7zip/zip/refs/tags/24.09'))
with zipfile.ZipFile(ROOT/'toolbox-site/licenses/7z-wasm-source.zip','a',zipfile.ZIP_DEFLATED) as z:
 z.writestr(archive.name,archive.read_bytes())
 z.writestr('BUILD.md','7z-wasm upstream source, Emscripten patch and Docker build scripts are in the pinned upstream archive. 7zip-24.09-source.zip is the corresponding official 7-Zip 24.09 C/C++ source (ip7z/7zip tag 24.09; original 7z2409-src.7z URL now 404). Extract it as /7z-src for the supplied Dockerfile build. Runtime unmodified; ES module renamed .mjs.\n7-Zip source SHA256: '+hashlib.sha256(archive.read_bytes()).hexdigest()+'\n')
(out/'SOURCE.txt').write_text('fatfs-wasm 4.0.0, MIT / FatFs by ChaN\nhttps://github.com/parkertomatoes/fatfs-wasm\nPatch: include WorkerGlobalScope in browser WASM loader; remove unavailable source map comment. Native WASM unchanged.\nCorresponding upstream source commit: 9a6f4d0393fa0377723ec767c0a364e584f58fe2\n',encoding='utf8')
(out/'fatfs-upstream.ts').unlink(missing_ok=True)
for name in ['hash-wasm','7z-wasm','fatfs-wasm']:
 out=ROOT/'toolbox-site/vendor'/name
 (out/'manifest.json').write_text(json.dumps({'files':[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.iterdir())if p.is_file()and p.name!='manifest.json']},indent=2)+'\n',encoding='utf8')
print('Staged hash-wasm and 7z-wasm')
