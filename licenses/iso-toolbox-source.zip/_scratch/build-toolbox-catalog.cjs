const fs=require('fs'),path=require('path');
const base=require('../toolbox-site/assets/catalog-base.js');
const cache=JSON.parse(fs.readFileSync('_scratch/ui-zh-cache.json','utf8'));
const categories=[...base.categories.filter(c=>c.id!=='ai'),...Object.entries({pdf:'PDF 文档',image:'图片设计',media:'音频视频',data:'数据处理',encoding:'编码与校验',web:'开发工具',time:'时间日期',math:'计算换算',color:'颜色工具',convert:'格式转换',studio:'创作与辅助'}).map(([id,name])=>({id,name,icon:id==='media'?'record':id==='time'?'monitor':'convert'})),...base.categories.filter(c=>c.id==='ai')];
const tools=base.tools.map(t=>({...t,variants:[{name:'标准',href:t.href,source:'toolbox',sourceId:t.id}]}));
const byId=new Map(tools.map(t=>[t.id,t])), byName=new Map(),sources=[],unavailable=[];
const aliases={
 'merge-pdf':'pdf-merge','merge':'pdf-merge','split-pdf':'pdf-split','split':'pdf-split','rotate-pdf':'pdf-rotate','rotate':'pdf-rotate','pdf-metadata':'pdf-metadata','view-metadata':'pdf-metadata','edit-metadata':'pdf-metadata','remove-metadata':'pdf-metadata',
 'image-to-pdf':'images-to-pdf','jpg-to-pdf':'images-to-pdf','png-to-pdf':'images-to-pdf','webp-to-pdf':'images-to-pdf','heic-to-pdf':'images-to-pdf','bmp-to-pdf':'images-to-pdf','tiff-to-pdf':'images-to-pdf','psd-to-pdf':'images-to-pdf',
 'pdf-to-image':'pdf-images','pdf-to-png':'pdf-images','pdf-to-jpg':'pdf-images','pdf-to-webp':'pdf-images','pdf-to-bmp':'pdf-images','pdf-to-tiff':'pdf-images','pdf-to-images':'pdf-images',
 'pdf-compress':'pdf-compress','compress':'pdf-compress','password':'pdf-protect','protect':'pdf-protect','unlock':'pdf-unlock','watermark':'pdf-watermark','page-numbers':'pdf-page-numbers','organize':'pdf-organize','sign':'pdf-sign','pdf-crop':'pdf-crop',
 'edit':'pdf-edit','edit-pdf':'pdf-edit','redact-pdf':'pdf-redact','to-docx':'pdf-to-word','from-docx':'word-to-pdf','from-xlsx':'excel-to-pdf','grayscale':'pdf-to-greyscale',
 'base64':'base64-text','url-encode':'url-encode','json':'json-formatter','json-minify':'json-formatter','json-validator':'json-formatter','json-tree-viewer':'json-tree-viewer','hash':'hash','diff':'text-diff',
 'ip-subnet-calculator':'subnet','web-cidr-calculator':'subnet','web-mac-address-formatter':'mac','dns-propagation-comparison':'dns','dns-record-dig-ui':'dns',
 'web-json-flatten':'json-flatten','web-json-path-extractor':'json-path-extractor','web-json-to-query-string':'json-to-query-string','web-json-to-jsonschema':'json-to-json-schema','web-json-to-toml':'json-to-toml','web-json-tree-viewer':'json-tree-viewer',
 'web-css-variable-extractor':'web-css-variables-extractor','web-css-color-format-converter':'color-converter','web-media-query-generator':'web-media-query-builder','web-box-shadow-generator':'box-shadow-generator','web-status-code-explainer':'http-status-codes','web-mimetype-from-extension':'mime-types',
 'web-url-inspector':'url-parser','web-query-string-parser':'query-params','web-query-string-editor':'query-params','web-html-escape-unescape':'html-entities','web-regex-escape':'encoding-regex-literal-escape','web-shell-arg-escaper':'encoding-shell-arg-escape',
 'nanoid-generator':'generate-nanoid','ulid-generator':'generate-ulid','random-string':'generate-random-string','passphrase-generator':'generate-passphrase','generate-hex-color':'random-hex-color-palette','generate-placeholder-image':'placeholder-image','generators-fake-credit-card-luhn-set':'generate-credit-card',
 'encoding-xxencode':'encoding-uuencode-xxencode','encoding-uuencode':'encoding-uuencode-xxencode','encoding-caesar-cipher':'encoding-rot-n-cipher',
};
const names={'pdf-merge':'PDF 合并','pdf-split':'PDF 拆分','pdf-rotate':'PDF 旋转','pdf-metadata':'PDF 元数据','images-to-pdf':'图片转 PDF','pdf-images':'PDF 转图片','pdf-protect':'PDF 加密与权限','pdf-unlock':'PDF 解密','pdf-watermark':'PDF 水印','pdf-page-numbers':'PDF 页码','pdf-organize':'PDF 页面整理','pdf-sign':'PDF 签名','pdf-edit':'PDF 编辑','pdf-redact':'PDF 涂黑与脱敏','hash':'哈希与校验','file-convert':'文件格式转换'};
function add({id,category,name,description='',href,source,sourceId,keywords='',key}){
 key=key||aliases[id]||id;
 const normalized=category+':'+name.replace(/[\s·/／：:（）()]/g,'').toLowerCase();
 let target=byId.get(key)||byName.get(normalized);
 if(!target){target={id:key,category,name:names[key]||name,description,icon:category==='media'?'record':'convert',tags:[],keywords,variants:[]};tools.push(target);byId.set(key,target);byName.set(normalized,target);}
 const existing=target.variants.find(v=>v.href===href);if(!existing)target.variants.push({name,href,source,sourceId});else{existing.origins??=[{source:existing.source,sourceId:existing.sourceId}];existing.origins.push({source,sourceId});}
 target.keywords+=' '+keywords+' '+id+' '+name;sources.push({source,sourceId,tool:target.id});
}
for(const t of JSON.parse(fs.readFileSync('_scratch/openutility-catalog.json','utf8'))){
 const c={crypto:'encoding',generators:'web',text:'text'}[t.category]||t.category;
 add({...t,id:t.slug,category:c,href:'../utilities/?tool='+encodeURIComponent(t.slug)+'&embed=1',source:'openutility',sourceId:t.slug,keywords:[...(t.keywords||[]),...(t.tags||[])].join(' ')});
}
for(const t of JSON.parse(fs.readFileSync('_scratch/browsersnip-catalog.json','utf8'))){
 if(t.unavailable){unavailable.push({source:'browsersnip',sourceId:t.id,name:t.name,reason:t.unavailable});continue;}
 const video=t.category==='video';const id=video?'video-'+t.id:t.id;
 add({...t,id,category:video?'media':'pdf',name:video?({trim:'视频裁剪',resize:'视频尺寸',crop:'视频画面裁切',compress:'视频压缩',gif:'视频转 GIF',audio:'视频音频处理',speed:'视频速度',metadata:'视频元数据'}[t.id]||t.name):t.name.replace(/ to /g,' 转 '),href:'../documents/?embed=1#/tool/'+t.id,source:'browsersnip',sourceId:t.id});
}
const lcroot='_scratch/localconvert-upstream';const zh=JSON.parse(fs.readFileSync(lcroot+'/messages/zh-Hans.json','utf8'));function flat(obj,p='',out={}){for(const[k,v]of Object.entries(obj))if(typeof v==='string')out[(p?p+'_':'')+k]=v;else if(v&&typeof v==='object')flat(v,(p?p+'_':'')+k,out);return out;}const messages=flat(zh);
const imageAliases={batch:'image-resize-pixels',blur:'image-gaussian-blur','color-picker':'image-dominant-color',crop:'image-crop-aspect',filters:'image-filter-adjust',meme:'image-meme-text',qr:'qr-generator',rotate:'image-rotate-flip','video-to-gif':'video-gif',watermark:'image-watermark-text'};
for(const [folder,category]of Object.entries({'pdf-tools':'pdf','image-tools':'image','dev-tools':'text'}))for(const dir of fs.readdirSync(lcroot+'/src/routes/'+folder,{withFileTypes:true}).filter(e=>e.isDirectory())){
 const sourceId=folder+'/'+dir.name,src=fs.readFileSync(lcroot+'/src/routes/'+sourceId+'/+page.svelte','utf8'),titleKey=src.match(/(tool_pages_\w+_title)\(\)/)?.[1];
 add({id:dir.name,key:category==='image'?imageAliases[dir.name]:undefined,category,name:messages[titleKey]||dir.name,href:'../conversion/?tool='+sourceId+'&embed=1',source:'localconvert',sourceId});
}
add({id:'file-convert',category:'convert',name:'文件格式转换',description:'图片 · 音频 · 视频 · 文档',href:'../conversion/?tool=convert&embed=1',source:'localconvert',sourceId:'convert'});
if(fs.existsSync('_scratch/studio-catalog.json'))for(const t of JSON.parse(fs.readFileSync('_scratch/studio-catalog.json','utf8')))add(t);
for(const t of tools){
 if(t.variants.length===1&&t.variants[0].source==='toolbox')continue;
 // Original toolbox links are relative to the home page; embedded variants are relative to the tool host.
 for(const v of t.variants)if(v.source==='toolbox')v.href='../'+v.href.replace(/^tools\//,'');
 t.href='tools/tool/?id='+encodeURIComponent(t.id);
 t.keywords=[...new Set(t.keywords.split(/\s+/))].join(' ');
 if(t.variants.length>1){const used=new Map();for(const v of t.variants){const n=(used.get(v.name)||0)+1;used.set(v.name,n);if(n>1)v.name+=' · 方案 '+n;}}
}
const vm=tools.find(t=>t.id==='webvm');Object.assign(vm,{name:'浏览器虚拟机',description:'Linux x64 · PowerShell 7 · 中文终端',tags:['v86','Linux','PowerShell'],keywords:'虚拟机 v86 x86_64 Alpine Linux WASM PowerShell 中文 网络 AI 快照'});
const taxonomy=require('./toolbox-taxonomy.cjs');
categories.splice(0,categories.length,...taxonomy.apply(tools));
const iconRules=require('./tool-icon-rules.cjs');
const uiCopy=require('./toolbox-copy-overrides.cjs');
for(const item of categories)item.icon=iconRules.categories[item.id];
for(const tool of tools){tool.name=uiCopy[tool.name]||tool.name;for(const variant of tool.variants)variant.name=uiCopy[variant.name]||variant.name;Object.assign(tool,iconRules.identify(tool));}
const catalog={categories,tools};fs.writeFileSync('toolbox-site/assets/catalog.js','/* Generated by build-toolbox-catalog.cjs */\nconst ToolboxCatalog = '+JSON.stringify(catalog,null,2)+';\nif(typeof module!=="undefined"&&module.exports)module.exports=ToolboxCatalog;\n');
fs.writeFileSync('toolbox-site/assets/integration-manifest.json',JSON.stringify({generated:new Date().toISOString(),sources,unavailable},null,2));
console.log(JSON.stringify({tools:tools.length,implementations:sources.length,merged:tools.filter(t=>t.variants.length>1).length,unavailable:unavailable.length}));
