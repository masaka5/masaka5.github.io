// Apply after upstream catalog merging, so every implementation retains its ID and URL.
const categories=[
 ['files','文件与镜像','folder-open'],['pdf','PDF 文档','file-text'],['image','图片处理','image'],['media','音频视频','clapperboard'],
 ['text','文本处理','text-cursor-input'],['data','数据与表格','database'],['network','网络运维','network'],['windows','系统运维','terminal'],
 ['hardware','硬件检测','cpu'],['peripheral','设备与采集','keyboard'],['web','代码与开发','code-xml'],['frontend','网页与样式','panels-top-left'],
 ['security','安全与认证','shield-check'],['encoding','编码与校验','binary'],['time','日期时间','calendar-days'],['math','计算与单位','calculator'],
 ['color','颜色搭配','palette'],['collaboration','协作与绘图','users-round'],['ai','AI 助手','messages-square']
].map(([id,name,icon])=>({id,name,icon}));
const exact={
 iso:'files',archives:'files','file-convert':'files','file-watermark':'files',reader:'files',
 nfc:'peripheral',uid:'peripheral',whiteboard:'collaboration','3d-model':'collaboration',
 'text-to-speech':'media',ssml:'media',dictation:'media',pronunciation:'media',phonetic:'text',flashcards:'text','voice-dialogue':'media',
 hash:'encoding','file-hash':'encoding','hash-compare-verify':'encoding','subresource-integrity-generator':'encoding',
 'generate-css-gradient':'frontend','random-hex-color-palette':'color','placeholder-image':'image','generate-svg-pattern':'image',
 'generate-barcode':'image','ean-upc-barcode-data-generator':'image','vcard-qr-payload-generator':'image',
 'generate-iban':'math','generate-credit-card':'math','bic-swift-test-generator':'math','ssn-format-test-generator':'math',
 'generate-mac-address':'network','fake-ipv4-ipv6-generator':'network','ip-cidr-list-generator':'network','generators-ssh-config-builder':'windows',
 'generate-cron-expression':'time','crontab-recipe-generator':'time','convert-cron-to-human-and-quartz':'time','convert-cron-to-human-multi':'time',
 'text-anonymizer':'security','htpasswd-generator':'security','chmod-calculator':'windows','tls-rpt-record-builder':'network',
 'wifi-qr-payload-generator':'network','markdown':'text','markdown-to-html':'text','html-to-markdown':'text',
 'markdown-table-to-html':'data','markdown-list-to-json':'data','markdown-table-to-csv':'data','html-table-to-markdown':'data',
 'hex-to-rgb-code':'color','convert-color-list-to-tailwind-config':'color','px-rem-converter':'frontend','typography-units-converter':'frontend','css-shorthand-expander':'frontend',
 'base64-to-file':'encoding','unicode-code-point-converter':'encoding','number-to-words':'math','number-base-words':'math',
 'generate-random-date':'time','random-date-range-generator':'time','generate-random-number':'math','random-coordinates-generator':'math',
 'svg-path-rounder':'image','convert-svg-to-jsx':'frontend','html-to-pug':'frontend','pug-to-html':'frontend','jsx-to-html':'frontend',
 'convert-graphql-query-to-curl':'web','convert-openapi-to-curl':'web','convert-har-to-curl':'web','querystring-to-curl':'web','curl-to-httpie':'web','httpie-to-curl':'web',
 'web-ip-address-converter':'network','web-ip-cidr-membership':'network','web-ipv6-expander':'network',
 'web-cron-explainer':'time','web-regex-cheatsheet':'web','web-regex-match-lines':'web','web-regex-named-group-converter':'web','web-regex-pattern-library':'web','regex-tester':'web',
 'web-data-uri-builder-text':'encoding','web-data-uri-decoder':'encoding','web-data-uri-size-estimator':'encoding','html-entities':'encoding',
 'generate-markdown-table':'data','generate-mock-json':'data','mock-data':'data','generators-json-server-routes':'web',
 'generate-passphrase':'security','generate-pin':'security','generate-random-string':'security','generate-slug':'text','vcard-generator':'text',
 'html-to-text':'text','web-html-attributes-stripper':'text','web-html-class-attr-extractor':'web','web-html-entity-picker':'encoding',
 'web-dotenv-to-json':'data','web-xml-formatter':'data','web-xml-to-json':'data','query-params':'web','url-parser':'web'
 ,'env-to-shell-exports':'web','markdown-to-jsx':'frontend','encoding-jwt-inspector':'security'
};
function classify(t){
 const id=t.id;if(exact[id])return exact[id];
 if(/^(?:aes-|bcrypt$|bip39-|certificate-|crypto-|csr-|diceware-|ecdsa-|hkdf-|hmac-|jwk|jwt|ocsp-|otp-|passphrase-|password-|pbkdf2-|rsa-|scrypt-|shamir-|tls-cipher|totp-|webhook-signature|api-key|basic-auth|bearer-token|memorable-password|mnemonic-pin|oauth-|oidc-|otp-secret|pattern-password|pronounceable-password|saml-|security-headers|web-(?:bearer-auth|content-security|jwt|permissions-policy|referrer-policy|www-authenticate|csp-))/.test(id))return 'security';
 if(/^(?:bimi-|dkim-|dmarc-|dns-|dnssec-|hsts-|mta-sts-|spf-|mqtt-|web-hsts)/.test(id))return 'network';
 if(/^(?:css-|web-(?:aspect-ratio-css|bem-|border-|clamp-|clip-path|css-|cubic-bezier|favicon-|filter-|flexbox-|grid-|html-minify|html-to-jsx|json-to-html-form|jsonld-|keyframes-|link-header|lorem-html|media-query|multi-column|open-graph|preload-|robots-|scrollbar-|srcset-|text-shadow|transform-|transition-|z-index))/.test(id))return 'frontend';
 if(/^(?:json-to-(?:csharp|dart|go|java$|jsdoc|kotlin|mongoose|php|protobuf|pydantic|python|ruby|rust|swift|typescript|zod)|web-json-to-java)/.test(id))return 'web';
 if(t.category==='convert'){
  if(/(?:json|csv|tsv|ndjson|jsonl|yaml|toml|plist|properties|ini-to|xml|key-value|kv-pairs|list-to-json|ascii-table)/.test(id))return 'data';
  return 'math';
 }
 if(t.category==='studio')return 'collaboration';if(t.category==='nfc')return 'peripheral';
 return t.category;
}
function apply(tools){for(const tool of tools)tool.category=classify(tool);return categories.map(c=>({...c}));}
module.exports={categories,apply,classify};
