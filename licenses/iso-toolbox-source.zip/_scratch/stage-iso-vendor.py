"""Stage pinned MIT format encoders, preserving upstream sources verbatim."""
from pathlib import Path
import hashlib,json,zipfile,urllib.request,tarfile,io
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'_scratch/iso-build';SOURCE=BASE/'package'
archive=BASE/'gcu-iso9660-0.1.0.tgz'
if not archive.exists():
 with urllib.request.urlopen('https://registry.npmjs.org/@gcu/iso9660/-/iso9660-0.1.0.tgz',timeout=30)as response:archive.write_bytes(response.read())
assert hashlib.sha1(archive.read_bytes()).hexdigest()=='0a96277003fc32ca57cdf089ab9f06bcc19a57a4'
with tarfile.open(archive)as tar:tar.extractall(BASE,filter='data')
OUT=ROOT/'toolbox-site/vendor/iso9660';OUT.mkdir(parents=True,exist_ok=True)
for name in ['both.js','constants.js','dates.js','dir-record.js','path-table.js','pvd.js','ucs2.js']:(OUT/name).write_bytes((SOURCE/'src'/name).read_bytes())
(OUT/'LICENSE.txt').write_bytes((SOURCE/'LICENSE').read_bytes())
(OUT/'SOURCE.txt').write_text('@gcu/iso9660 0.1.0 (MIT)\nhttps://github.com/endarthur/auditable/tree/main/ext/iso9660\nPinned npm SHA1: 0a96277003fc32ca57cdf089ab9f06bcc19a57a4\nUnmodified format encoders; toolbox supplies directory layout, unique ASCII aliases and streaming writer.\n',encoding='utf8')
files=[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(OUT.iterdir())if p.is_file()and p.name!='manifest.json']
(OUT/'manifest.json').write_text(json.dumps({'version':'0.1.0','files':files},indent=2)+'\n',encoding='utf8')
print(json.dumps({'vendor_files':len(files),'version':'0.1.0'}))
