"""Archive first-party sources and checks for the ISO/favorites release."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site'
vendor=SITE/'vendor/iso9660';assert vendor.is_dir()
sources=SITE/'licenses/sources.json';records=json.loads(sources.read_text(encoding='utf8'))
records=[r for r in records if r.get('project')!='iso9660']
records.append({'project':'iso9660','source':'https://github.com/endarthur/auditable/tree/main/ext/iso9660','version':'0.1.0','license':'MIT','licenseFile':'vendor/iso9660/LICENSE.txt','sourceArchive':'licenses/iso-toolbox-source.zip','changes':'Unmodified format encoders; toolbox supplies streaming layout, unique fallback names and UI.'})
for name,version,repo,license,changes in [('hash-wasm','4.13.0','Daninet/hash-wasm','MIT','Unmodified bundled ESM and embedded WASM.'),('7z-wasm','1.2.0','use-strict/7z-wasm','LGPL-2.1-or-later with unRAR restriction','Unmodified runtime renamed .mjs; pinned build scripts and 7-Zip 24.09 source supplied.'),('fatfs-wasm','4.0.0','parkertomatoes/fatfs-wasm','MIT / FatFs by ChaN','WorkerGlobalScope loader detection patch; native WASM unchanged; corresponding source supplied.')]:
 records=[r for r in records if r.get('project')!=name]
 records.append({'project':name,'version':version,'source':'https://github.com/'+repo,'license':license,'licenseFile':'vendor/'+name+'/LICENSE.txt','sourceArchive':'licenses/'+name+'-source.zip','changes':changes})
sources.write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
folder=SITE/'tools/iso';files=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(folder.iterdir())if p.is_file()and p.name!='manifest.json'and p.suffix!='.c']
(folder/'manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n',encoding='utf8')
folder=SITE/'tools/folder-analysis'
(folder/'manifest.json').write_text(json.dumps({'files':[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(folder.iterdir())if p.is_file()and p.name!='manifest.json']},indent=2)+'\n',encoding='utf8')
archive=SITE/'licenses/iso-toolbox-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name in ['tools/iso','tools/folder-analysis','vendor/iso9660']:
  for p in (SITE/name).iterdir():
   if p.is_file():z.write(p,'toolbox-site/'+p.relative_to(SITE).as_posix())
 for name in ['index.html','assets/home.js','assets/home.css','assets/catalog-base.js']:
  z.write(SITE/name,'toolbox-site/'+name)
 for name in ['toolbox-taxonomy.cjs','tool-icon-rules.cjs','build-toolbox-catalog.cjs','build-toolbox-icons.cjs','stage-iso-vendor.py','stage-image-vendor.py','build-iso-wasm.ps1','package-iso-toolbox-source.py']:
  z.write(ROOT/'_scratch'/name,'_scratch/'+name)
 for p in (ROOT/'_scratch/ops-tests').iterdir():
  if p.is_file()and(p.name.startswith(('iso','image','folder','home-favorites','taxonomy'))or p.name in ['home-mobile-nav.py','icon-home-layout.py'])and p.name!='iso-diagnostics.py':z.write(p,'_scratch/ops-tests/'+p.name)
 z.writestr('IMAGE-ENGINES.md','镜像引擎：7z-wasm 1.2.0、fatfs-wasm 4.0.0；目录重复检测：hash-wasm 4.13.0。对应源码和许可见各自 source.zip 和 licenses/sources.json。ISO WASM C 源码含 MIT 归属，可用 _scratch/build-iso-wasm.ps1 重建；其他 vendor 用 stage-image-vendor.py 固定版本获取。读取采用 Worker+WORKERFS；WIM 写入、FAT IMG/固定 VHD 编辑及提取数据上限 256 MiB，WASM 工作内存和副本有额外开销。ISO 流式制作下载上限512 MiB；直接保存流式写入。动态 VHD、复杂分区/NTFS/Ext 等仅按 7-Zip 能力只读提取。ISO 重建资料盘不保留引导。原文件通过新副本输出与句柄同一性检查保护。\n')
 z.writestr('BUILD.md','# ISO 与目录源码\n\n纯静态网页。Python 3 运行 `_scratch/stage-iso-vendor.py` 获取锁定 MIT 编码模块（校验 npm SHA1），然后运行 Node `_scratch/build-toolbox-catalog.cjs` 与 `_scratch/build-toolbox-icons.cjs` 更新目录。完整目录构建还需 integration-source.zip 中的现有上游项目和锁文件；已有部署包内的 vendor 与资产可直接使用，无构建步骤。\n\n生成资料 ISO 9660 + Joliet，无系统引导。Chrome/Edge 直接保存分块写入；下载方式上限 512 MiB。单文件 <4 GiB、目录最多 7 层，名称不受支持时明确拒绝。运行 `node --test _scratch/ops-tests/iso.test.cjs`；Python 独立解析测试需 pycdlib==1.14.0 安装到 _scratch/qa-python。浏览器测试需 Playwright；TOOLBOX_TEST_BASE 可指向静态站。\n')
print(json.dumps({'source_archive_kb':round(archive.stat().st_size/1024,1),'iso_files':len(files)}))
