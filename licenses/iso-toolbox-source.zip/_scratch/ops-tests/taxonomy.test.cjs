const {test}=require('node:test'),assert=require('node:assert/strict');
test('all tools are classified by purpose with files, security and frontend separated',()=>{
 const c=require('../../toolbox-site/assets/catalog.js');
 const cases={iso:'files',archives:'files','file-watermark':'files',hash:'encoding',nfc:'hardware',uid:'hardware','aes-encrypt-decrypt':'security','password-generator':'security','saml-response-decoder':'security','web-css-to-tailwind':'frontend','web-ipv6-expander':'network','json-to-yaml':'data','length-converter':'math','text-to-speech':'media',reader:'files',whiteboard:'collaboration','code':'workspace',webvm:'workspace',meeting:'meetings',stress:'hardware',monitor:'hardware',devices:'hardware',scan:'hardware',recorder:'hardware',serial:'hardware','folder-analysis':'windows',bsod:'windows','windows-errors':'windows','system-commands':'windows'};
 for(const[id,category]of Object.entries(cases))assert.equal(c.tools.find(t=>t.id===id)?.category,category,id);
 assert.ok(!c.categories.some(t=>['convert','studio','nfc'].includes(t.id)));
 for(const t of c.tools)assert.ok(c.categories.some(x=>x.id===t.category),t.id);
 for(const[id,name]of Object.entries({hardware:'硬件与外设',windows:'电脑维护',workspace:'开发与虚拟机',meetings:'在线协作'}))assert.equal(c.categories.find(c=>c.id===id)?.name,name);
 assert.ok(!c.categories.some(c=>c.id==='peripheral'));
});
test('unrelated tools and categories retain their classification',()=>{
 const fs=require('node:fs'),vm=require('node:vm');
 const path='_scratch/masaka5-toolbox-upstream/assets/catalog.js';
 const before={module:{exports:{}}};vm.runInNewContext(fs.readFileSync(path,'utf8'),before);
 const old=before.module.exports,c=require('../../toolbox-site/assets/catalog.js');
 const changed=new Set(['folder-analysis','webvm','code','meeting']);
 for(const t of old.tools){if(t.category==='peripheral'||changed.has(t.id))continue;assert.equal(c.tools.find(x=>x.id===t.id)?.category,t.category,t.id);}
 for(const group of old.categories){if(['hardware','windows','peripheral'].includes(group.id))continue;assert.equal(c.categories.find(x=>x.id===group.id)?.name,group.name,group.id);}
});
