const {test}=require('node:test'),assert=require('node:assert/strict');
test('all tools are classified by purpose with files, security and frontend separated',()=>{
 const c=require('../../toolbox-site/assets/catalog.js');
 const cases={iso:'files',archives:'files','file-watermark':'files',hash:'encoding',nfc:'peripheral',uid:'peripheral','aes-encrypt-decrypt':'security','password-generator':'security','saml-response-decoder':'security','web-css-to-tailwind':'frontend','web-ipv6-expander':'network','json-to-yaml':'data','length-converter':'math','text-to-speech':'media',reader:'files',whiteboard:'collaboration','code':'web'};
 for(const[id,category]of Object.entries(cases))assert.equal(c.tools.find(t=>t.id===id)?.category,category,id);
 assert.ok(!c.categories.some(t=>['convert','studio','nfc'].includes(t.id)));
 for(const t of c.tools)assert.ok(c.categories.some(x=>x.id===t.category),t.id);
});
