import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True);page=await browser.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  response=await page.goto(BASE+'/tools/folder-analysis/');assert response.status==200
  await page.evaluate('''async()=>{const root=await navigator.storage.getDirectory();try{await root.removeEntry('folder-test',{recursive:true})}catch{}const d=await root.getDirectoryHandle('folder-test',{create:true});const nested=await d.getDirectoryHandle('中文',{create:true});await d.getDirectoryHandle('空目录',{create:true});async function write(dir,name,data){const h=await dir.getFileHandle(name,{create:true});const w=await h.createWritable();await w.write(data);await w.close();}await write(d,'a.txt','same');await write(nested,'副本.txt','same');await write(d,'other.txt','diff');await write(d,'=formula.txt','unique-size');await write(d,'empty','');await write(nested,'zero','');window.folderHandle=d;window.showDirectoryPicker=async()=>d;}''')
  await page.locator('#choose').click();await page.wait_for_function("document.querySelector('#status').textContent.startsWith('扫描完成')")
  assert '6 个文件 · 2 个文件夹'==await page.locator('#counts').inner_text()
  assert await page.locator('#total').inner_text()=='23 B'
  await page.locator('#rows button').filter(has_text='中文').click();assert '副本.txt' in await page.locator('#rows').inner_text();await page.locator('#up').click()
  await page.locator('#duplicate').click();await page.wait_for_function("document.querySelector('#status').textContent.startsWith('检测完成')")
  assert '2 组' in await page.locator('#status').inner_text();assert '跳过 1 个唯一大小' in await page.locator('#status').inner_text();assert await page.locator('#saved').inner_text()=='重复冗余 4 B'
  text=await page.locator('#rows').inner_text();assert '副本.txt' in text and 'other.txt' not in text and 'empty' in text
  async with page.expect_download() as capture:await page.locator('#export').click()
  download=await capture.value
  with open(await download.path(),encoding='utf-8-sig') as f:csv=f.read()
  assert '"\'=formula.txt"' in csv and '中文/副本.txt' in csv
  direct=await page.evaluate('''async()=>{const w=new Worker('./folder-worker.js',{type:'module'});const wait=type=>new Promise((resolve,reject)=>{w.onmessage=({data})=>{if(data.type===type)resolve(data);if(data.type==='error')reject(Error(data.message));};});let done=wait('scan');w.postMessage({type:'scan',handle:folderHandle});await done;done=wait('duplicates');w.postMessage({type:'duplicates'});const exact=await done;const h=await folderHandle.getFileHandle('a.txt');const writer=await h.createWritable();await writer.write('EDIT');await writer.close();done=wait('duplicates');w.postMessage({type:'duplicates'});const changed=await done;w.terminate();return {exact,changed};}''')
  assert direct['exact']['stats']['readBytes']==20,direct
  assert direct['exact']['stats']['compared']==1,direct
  assert direct['changed']['stats']['changed']==1,direct
  assert len(direct['changed']['groups'])==1,direct
  await page.locator('[data-view=extension]').click();assert '.txt' in await page.locator('#rows').inner_text()
  await page.locator('#search').fill('不存在');assert await page.locator('#empty').is_visible();await page.locator('#search').fill('')
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(100)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   for selector in ['#choose','#duplicate','#export','#search','#sort','.pager']:
    rect=await page.locator(selector).bounding_box();assert rect and rect['y']>=0 and rect['y']+rect['height']<=h,(w,h,selector,rect)
  # Real worker hash is cancellable between bounded chunks.
  await page.set_viewport_size({'width':1440,'height':900})
  await page.evaluate('''async()=>{for(const name of ['large-a','large-b']){const h=await folderHandle.getFileHandle(name,{create:true}),w=await h.createWritable();await w.write(new Uint8Array(32*1024*1024));await w.close();}}''')
  await page.locator('#choose').click();await page.wait_for_function("document.querySelector('#status').textContent.startsWith('扫描完成')")
  await page.locator('#duplicate').click();await page.locator('#cancel').click();await page.wait_for_function("document.querySelector('#status').textContent.startsWith('检测已取消')")
  assert await page.locator('#choose').is_enabled();assert not errors,errors
  print(json.dumps({'base':BASE,'real_worker_WASM_exact_duplicates':True,'OPFS_nested_empty':True,'CSV_formula_safe':True,'cancel':True,'layouts':5,'errors':errors}));await browser.close()
asyncio.run(main())
