const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),{pathToFileURL}=require('node:url'),path=require('node:path');
test('ISO metadata uses a real compiled WebAssembly codec',async()=>{
 const bytes=fs.readFileSync('toolbox-site/tools/iso/iso-codec.wasm');
 const module=await WebAssembly.compile(bytes);
 for(const name of ['iso_record','iso_path','iso_descriptor'])assert.ok(WebAssembly.Module.exports(module).some(e=>e.name===name));
 const codec=await import(pathToFileURL(path.resolve('toolbox-site/tools/iso/iso-codec.js')));
 assert.equal(codec.codecBackend,'webassembly');
 const reference=await import(pathToFileURL(path.resolve('toolbox-site/vendor/iso9660/dir-record.js')));
 const date=new Date('2025-04-05T06:07:08Z');
 for(const identifier of [new Uint8Array([0]),new Uint8Array([1]),new TextEncoder().encode('TEST.TXT;1'),new Uint8Array([0x4e,0x2d,0x65,0x87])]){
  const opts={extentLBA:0x12345678,dataLen:0x87654321,date,isDir:identifier.length<3,identifier};
  const actual=new Uint8Array(256),expected=new Uint8Array(256);
  assert.equal(codec.encodeDirRecord(actual,3,opts),reference.encodeDirRecord(expected,3,opts));assert.deepEqual(actual,expected);
 }
});
test('WASM descriptors and both path table orders match ISO reference bytes',async()=>{
 const load=p=>import(pathToFileURL(path.resolve(p)));
 const codec=await load('toolbox-site/tools/iso/iso-codec.js'),pvd=await load('toolbox-site/vendor/iso9660/pvd.js'),paths=await load('toolbox-site/vendor/iso9660/path-table.js');
 const date=new Date('2024-12-31T23:59:58Z'),rootRecord=new Uint8Array(34);
 codec.encodeDotRecord(rootRecord,0,0x12345,4096,date);
 const opts={volumeId:'TEST_DISC',application:'TOOLBOX',volumeSpaceSize:0x12345678,pathTableSize:1234,pathTableLBA_LE:0x123456,pathTableLBA_BE:0x789abc,rootRecord,date};
 assert.deepEqual(codec.encodePVD(opts),pvd.encodePVD(opts));assert.deepEqual(codec.encodeSVD(opts),pvd.encodeSVD(opts));assert.deepEqual(codec.encodeTerminator(),pvd.encodeTerminator());
 const dirs=[{nameBytes:new Uint8Array([0]),extentLBA:23,parentIndex:1},{nameBytes:new Uint8Array([0x4e,0x2d,0x65,0x87]),extentLBA:0x12345678,parentIndex:256}];
 for(const order of ['le','be'])assert.deepEqual(codec.encodePathTable(dirs,order),paths.encodePathTable(dirs,order));
 // Returned output must be owned, since subsequent calls share a small WASM scratch arena.
 const saved=codec.encodePVD(opts),copy=saved.slice();codec.encodeSVD(opts);assert.deepEqual(saved,copy);
});
