import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);context=await b.new_context(viewport={'width':1440,'height':900});page=await context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE);await page.locator('#toolSearch').fill('硬件压测')
  button=page.get_by_role('button',name='收藏 硬件压测',exact=True);await button.click(timeout=4000)
  assert await page.get_by_role('button',name='取消收藏 硬件压测',exact=True).get_attribute('aria-pressed')=='true'
  await page.locator('#toolSearch').fill('');await page.locator('#categoryNav [data-category=favorites]').click()
  assert await page.locator('.tool-card:not([hidden])').count()==1
  await page.reload();await page.locator('#categoryNav [data-category=favorites]').click();assert await page.locator('.tool-card:not([hidden])').count()==1
  other=await context.new_page();await other.goto(BASE);await other.locator('#toolSearch').fill('硬件压测');await other.get_by_role('button',name='取消收藏 硬件压测',exact=True).click();await page.wait_for_function("document.querySelectorAll('.tool-card:not([hidden])').length===0")
  for w,h in [(1440,900),(390,844),(320,568),(844,390)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(150);assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.set_viewport_size({'width':1440,'height':900});await page.locator('#categoryNav [data-category=all]').click();await page.screenshot(path='_scratch/home-favorites-desktop.png')
  # Malformed saved data and denied browser storage must not disable catalog or favorites.
  await page.evaluate("localStorage.setItem('toolbox-favorites-v1','{}')");await page.reload();await page.locator('#toolSearch').fill('硬件压测');assert await page.get_by_role('button',name='收藏 硬件压测',exact=True).count()==1
  await page.evaluate("()=>{Storage.prototype.setItem=function(){throw new DOMException('Denied','SecurityError')}}")
  await page.get_by_role('button',name='收藏 硬件压测',exact=True).focus();await page.keyboard.press('Space');assert await page.get_by_role('button',name='取消收藏 硬件压测',exact=True).get_attribute('aria-pressed')=='true'
  assert '本次访问'in await page.locator('#homeStatus').inner_text()
  assert not errors,errors;print(json.dumps({'base':BASE,'favorite_toggle':True,'refresh_persistence':True,'cross_tab_sync':True,'malformed_storage':True,'denied_storage_session':True,'keyboard_toggle':True,'layouts':4,'errors':errors}));await b.close()
asyncio.run(main())
