from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2] / 'toolbox-site'


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def main():
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(ROOT)))
    Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch()
            page = browser.new_page(viewport={'width': 390, 'height': 844})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(f'http://127.0.0.1:{server.server_port}/', wait_until='networkidle')
            nav = page.locator('#mobileCategoryNav')
            assert nav.is_visible(), 'mobile category navigation is missing'
            category_count = page.evaluate('ToolboxCatalog.categories.length')
            assert nav.locator('button').count() == category_count + 2
            assert not page.locator('#categorySelect').is_visible(), 'mobile categories should not be a dropdown'
            nav.locator('[data-category="windows"]').click()
            cards = page.locator('.tool-card:not([hidden])')
            assert cards.count() == page.evaluate("ToolboxCatalog.tools.filter(t=>t.category==='windows').length")
            assert page.locator('[data-tool="system-commands"]').is_visible()
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
            assert page.evaluate('document.documentElement.scrollHeight <= innerHeight')
            page.set_viewport_size({'width':390,'height':400})
            nav.locator('[data-category="all"]').click()
            box=nav.bounding_box()
            assert box and box['height']>=39 and box['y']>=0 and box['y']+box['height']<=400,box
            assert nav.locator('[data-category="all"]').evaluate('(e)=>{const r=e.getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===e||e.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
            assert not errors, errors
            browser.close()
    finally:
        server.shutdown()
        server.server_close()
    print('Mobile category navigation passed')


if __name__ == '__main__':
    main()
