import asyncio,os,json,sys,io
from pathlib import Path
from playwright.async_api import async_playwright
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qa-python'))
import pycdlib
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  r=await page.goto(BASE+'/tools/iso/');assert r.status==200,'ISO page missing'
  await page.locator('#files').set_input_files([{'name':'中文.txt','mimeType':'text/plain','buffer':'内容测试'.encode()},{'name':'empty.txt','mimeType':'text/plain','buffer':b''}])
  await page.wait_for_function("document.querySelector('#fileCount').textContent==='2'")
  await page.locator('#volumeId').fill('MY_DISC');await page.locator('#outputMode').select_option('download')
  await page.locator('#generate').click();await page.locator('#download').wait_for(state='visible')
  async with page.expect_download()as capture:await page.locator('#download').click()
  download=await capture.value;iso=pycdlib.PyCdlib();iso.open(await download.path());out=io.BytesIO();iso.get_file_from_iso_fp(out,joliet_path='/中文.txt;1');assert out.getvalue()=='内容测试'.encode();iso.close()
  # Real OPFS handle, only the user's picker selection is substituted.
  await page.evaluate("async()=>{const root=await navigator.storage.getDirectory();window.isoTestHandle=await root.getFileHandle('acceptance.iso',{create:true});window.showSaveFilePicker=async()=>isoTestHandle}")
  await page.locator('#outputMode').select_option('direct');await page.locator('#generate').click();await page.wait_for_function("document.querySelector('#status').textContent.includes('已保存')")
  size=await page.evaluate('async()=>(await isoTestHandle.getFile()).size');assert size>32768
  await page.locator('[data-remove]').first.click();assert await page.locator('#fileCount').inner_text()=='1'
  for w,h in [(1440,900),(390,844),(320,568),(844,390)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(100);assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/iso-desktop.png')
  await page.add_init_script('delete window.showSaveFilePicker');await page.reload();await page.wait_for_function("document.querySelector('#outputMode').value==='download' && document.querySelector('#outputMode option[value=direct]').disabled")
  assert not errors,errors;print(json.dumps({'base':BASE,'iso_independently_read':True,'direct_save_real_opfs':True,'layouts':4,'errors':errors}));await b.close()
asyncio.run(main())
