import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page()
  # Reduce only the served test copy's constant, never production configuration.
  async def cap(route):
   response=await route.fetch();body=await response.text();body=body.replace('LIMIT=200000','LIMIT=5').replace('LIMIT = 200000','LIMIT = 5');await route.fulfill(response=response,body=body)
  await page.route('**/folder-worker.js',cap)
  await page.goto(BASE+'/tools/folder-analysis/')
  result=await page.evaluate('''async()=>{const files=['a/b/one','a/b/two','c/d/three'].map(path=>({file:new File(['xx'],path.split('/').pop()),path}));const w=new Worker('./folder-worker.js',{type:'module'});const wait=type=>new Promise(resolve=>{w.onmessage=({data})=>{if(data.type===type)resolve(data)}});let done=wait('scan');w.postMessage({type:'scan',files});const scan=await done;done=wait('duplicates');w.postMessage({type:'duplicates'});const duplicate=await done;w.terminate();return {scan,duplicate};}''')
  assert result['scan']['stats']['entries']==5,result
  assert result['scan']['stats']['limited'] and result['scan']['partial'],result
  assert len(result['scan']['files'])+len(result['scan']['directories'])==5,result
  assert result['duplicate']['partial'] and result['duplicate']['scanPartial'],result
  # Cancel fallback enumeration via its first real progress event, then run UI detection.
  await page.unroute('**/folder-worker.js',cap);await page.reload()
  await page.evaluate('''()=>{const NativeWorker=window.Worker;window.Worker=class extends NativeWorker{constructor(...args){super(...args);this.addEventListener('message',({data})=>{if(data.type==='progress'&&data.phase==='scan')this.postMessage({type:'cancel'});});}};}''')
  # Worker is already instantiated by module; reload with constructor interception persisted.
  await page.add_init_script('''const NativeWorker=window.Worker;window.Worker=class extends NativeWorker{constructor(...args){super(...args);this.addEventListener('message',({data})=>{if(data.type==='progress'&&data.phase==='scan')this.postMessage({type:'cancel'});});}};''')
  await page.reload()
  await page.evaluate('''()=>{const dt=new DataTransfer();for(let i=0;i<100;i++)dt.items.add(new File(['xx'],'f'+i));const input=document.querySelector('#fallback');input.files=dt.files;input.dispatchEvent(new Event('change'));}''')
  await page.wait_for_function("document.querySelector('#status').textContent.startsWith('部分扫描')")
  await page.locator('#duplicate').click();await page.wait_for_function("!document.querySelector('#choose').disabled")
  text=await page.locator('#status').inner_text();assert '部分扫描' in text and '检测完成' not in text,text
  print(json.dumps({'fallback_entry_cap':True,'cancelled_snapshot_duplicate_remains_partial':True}));await b.close()
asyncio.run(main())
