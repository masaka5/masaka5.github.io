const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),{pathToFileURL}=require('node:url');
const core=()=>import(pathToFileURL(path.resolve('toolbox-site/tools/iso/iso-core.js')));
const file=(name,content='中文')=>({path:name,kind:'file',blob:new Blob([content])});
test('ISO planner rejects path conflicts, unrepresentable names and format limits',async()=>{
 const {planImage}=await core();
 for(const entries of [[],[file('../bad')],[file('a'),file('a')],[file('a'),file('a/b')],[file('x'.repeat(63))],[file('😀.txt')],[file('a/b/c/d/e/f/g/h/x')],[file('bad;name')]])assert.throws(()=>planImage(entries,{volumeId:'DATA'}));
 assert.throws(()=>planImage([file('a')],{volumeId:'中文'}));
 assert.throws(()=>planImage([{path:'large.bin',kind:'file',blob:{size:4294967296,slice(){}}}],{volumeId:'DATA'}));
});
test('ISO chunks preserve file payload, sector boundaries, empty files and progress',async()=>{
 const {planImage,imageChunks}=await core(),entries=[file('文档/说明.txt'),file('文档/报告.txt','报告'),file('empty',''),{path:'空目录',kind:'directory'},file('large.bin',new Uint8Array(5*1024*1024+3).fill(123))];
 const plan=planImage(entries,{volumeId:'TEST_DISC'}),chunks=[],progress=[];
 for await(const chunk of imageChunks(plan,{onProgress:n=>progress.push(n)})){assert.ok(chunk.length<=4*1024*1024);chunks.push(chunk);}
 const image=new Uint8Array(await new Blob(chunks).arrayBuffer());assert.equal(image.length,plan.totalBytes);assert.equal(image.length%2048,0);assert.equal(new TextDecoder().decode(image.slice(32769,32774)),'CD001');assert.equal(progress.at(-1),plan.totalBytes);
 for(const record of plan.files){assert.equal(record.offset%2048,0);assert.deepEqual(image.slice(record.offset,record.offset+record.size),new Uint8Array(await record.blob.arrayBuffer()));}
 const fs=require('node:fs');fs.writeFileSync('_scratch/iso-acceptance.iso',image);
});
test('ISO streaming checks cancellation and never reads entire source files',async()=>{
 const {planImage,imageChunks}=await core();const size=9*1024*1024;let reads=0;
 const source={size,slice(start,end){assert.ok(end-start<=4*1024*1024);reads++;return new Blob([new Uint8Array(end-start)]);},arrayBuffer(){throw Error('Whole file read');}};
 const plan=planImage([{path:'stream.bin',kind:'file',blob:source}],{volumeId:'DATA'}),controller=new AbortController();
 await assert.rejects(async()=>{for await(const chunk of imageChunks(plan,{signal:controller.signal})){if(reads)controller.abort();}},e=>e.name==='AbortError');assert.equal(reads,1);
});
test('Large directories and ASCII fallback collisions remain independent files',async()=>{
 const {planImage,imageChunks}=await core();const entries=Array.from({length:300},(_,i)=>file('版本.v1/文档_'+String(i).padStart(3,'0')+'.txt',String(i)));
 entries.push(file('版本.v1/说明.txt','a'),file('版本.v1/报告.txt','b'));
 const plan=planImage(entries,{volumeId:'MANY_FILES'}),chunks=[];for await(const c of imageChunks(plan))chunks.push(c);
 require('node:fs').writeFileSync('_scratch/iso-many.iso',new Uint8Array(await new Blob(chunks).arrayBuffer()));
 assert.equal(plan.fileCount,302);
});
