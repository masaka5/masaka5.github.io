import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'_scratch/integration-fixtures'
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch(headless=True);page=await browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  for w,h in [(320,568),(390,844),(844,390),(1024,768),(1440,900),(1920,1080)]:
   await page.set_viewport_size({'width':w,'height':h});await page.goto('http://127.0.0.1:8765/');await page.wait_for_timeout(150)
   for group in ['all','network','pdf','image','data','color']:
    selector=('#mobileCategoryNav'if w<=800 and h>500 else '#categoryNav')+f' [data-category="{group}"]'
    if await page.locator(selector).is_visible():await page.locator(selector).click()
    else:await page.locator('#categorySelect').select_option(group)
    await page.wait_for_timeout(50)
    metrics=await page.evaluate('''()=>({w:document.documentElement.scrollWidth,h:document.documentElement.scrollHeight,cards:[...document.querySelectorAll('.tool-card:not([hidden])')].map(n=>({id:n.dataset.tool,bottom:n.getBoundingClientRect().bottom,left:n.getBoundingClientRect().left,right:n.getBoundingClientRect().right,svg:!!n.querySelector('svg path,svg circle,svg rect,svg polygon,svg line,svg polyline,svg ellipse')})),end:document.querySelector('#toolsViewport').getBoundingClientRect().bottom})''')
    assert metrics['w']<=w and metrics['h']<=h+1,(w,h,group,metrics)
    for card in metrics['cards']:assert card['bottom']<=metrics['end']+1 and card['right']<=w and card['left']>=0 and card['svg'],(w,h,group,card,metrics['end'])
    if (w,h)in [(390,844),(1440,900)]and group in ['all','pdf','data']:await page.screenshot(path=str(OUT/f'icons-{group}-{w}.png'))
  await page.set_viewport_size({'width':1440,'height':900});await page.goto('http://127.0.0.1:8765/')
  await page.locator('#toolSearch').fill('json');await page.wait_for_timeout(100)
  assert await page.locator('.tool-card:not([hidden])').count()>0
  await page.get_by_role('button',name='下一页',exact=True).click()
  assert '2 /'in await page.locator('#pageStatus').inner_text()
  await page.goto('http://127.0.0.1:8765/tools/tool/?id=pdf-merge');await page.wait_for_timeout(300)
  assert await page.locator('.tool-heading .tool-icon svg').count()==1
  assert not errors,errors
  await browser.close()
 print(json.dumps({'viewports':6,'categories':6,'search_and_pagination':True,'errors':errors}),flush=True)
asyncio.run(main())
