import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto(BASE+'/tools/iso/')
  original=await page.evaluate('''async()=>{const {ImageEngine}=await import('./image-engine.js');const e=new ImageEngine(),blob=await e.create({format:'img',entries:[{path:'old.txt',blob:new Blob(['original'])}]});const r=await navigator.storage.getDirectory();window.sourceHandle=await r.getFileHandle('source.img',{create:true});const w=await sourceHandle.createWritable();await w.write(blob);await w.close();window.sourceBytes=await (await sourceHandle.getFile()).arrayBuffer();window.showOpenFilePicker=async()=>[sourceHandle];window.showSaveFilePicker=async()=>sourceHandle;return blob.size}''')
  await page.locator('#browseTab').click();await page.locator('#openImage').click();await page.wait_for_function("document.querySelector('#imageRows').textContent.includes('old.txt')")
  await page.locator('#imageAddInput').set_input_files({'name':'new.txt','mimeType':'text/plain','buffer':b'new'});await page.locator('#saveImage').click()
  await page.wait_for_function("document.querySelector('#browseStatus').textContent.includes('源镜像不能覆盖')")
  assert await page.evaluate('async()=>{const a=new Uint8Array(sourceBytes),b=new Uint8Array(await(await sourceHandle.getFile()).arrayBuffer());return a.length===b.length&&a.every((v,i)=>v===b[i])}')
  await page.evaluate('async()=>{const r=await navigator.storage.getDirectory();window.copyHandle=await r.getFileHandle("copy.img",{create:true});window.showSaveFilePicker=async()=>copyHandle}')
  await page.locator('#saveImage').click();await page.wait_for_function("document.querySelector('#browseStatus').textContent==='已保存副本'")
  assert await page.evaluate("async()=>{const {ImageEngine}=await import('./image-engine.js');const e=new ImageEngine();const out=await e.extract(await copyHandle.getFile(),['old.txt','new.txt']);return await out[0].blob.text()==='original'&&await out[1].blob.text()==='new'}")
  await page.evaluate('async()=>{window.showOpenFilePicker=async()=>[copyHandle];const r=await navigator.storage.getDirectory();window.exportDir=await r.getDirectoryHandle("exports",{create:true});window.showDirectoryPicker=async()=>exportDir}')
  await page.locator('#openImage').click();await page.wait_for_function("document.querySelector('#imageRows').textContent.includes('new.txt')&&!document.querySelector('#imageRows').textContent.includes('待添加')")
  await page.locator('#selectImagePage').check();await page.locator('#extractSelected').click();await page.wait_for_function("document.querySelector('#browseStatus').textContent.includes('已导出')")
  assert await page.evaluate('async()=>(await(await exportDir.getFileHandle("old.txt")).getFile()).text()')=='original'
  await page.evaluate('''async()=>{const {planImage,imageChunks}=await import('./iso-core.js');const chunks=[];for await(const c of imageChunks(planImage([{path:'test.txt',kind:'file',blob:new Blob(['iso original'])}])))chunks.push(c);const r=await navigator.storage.getDirectory();window.isoOriginal=await r.getFileHandle('original.iso',{create:true});const w=await isoOriginal.createWritable();await w.write(new Blob(chunks));await w.close();window.showOpenFilePicker=async()=>[isoOriginal];window.showSaveFilePicker=async()=>isoOriginal;}''')
  await page.locator('#openImage').click();await page.wait_for_function("document.querySelector('#imageCapability').textContent==='只读'")
  page.on('dialog',lambda d:d.accept());await page.locator('#rebuildISO').click();await page.locator('#createPanel').wait_for(state='visible');await page.locator('#generate').click();await page.wait_for_function("document.querySelector('#status').textContent.includes('源镜像不能覆盖')")
  assert await page.evaluate("async()=>{const {ImageEngine}=await import('./image-engine.js');const out=await new ImageEngine().extract(await isoOriginal.getFile(),['test.txt']);return await out[0].blob.text()==='iso original'}")
  print(json.dumps({'base':BASE,'same_source_rejected':True,'original_bytes_preserved':original,'new_copy_roundtrip':True,'batch_export':True,'iso_rebuild_source_protected':True}));await b.close()
asyncio.run(main())
