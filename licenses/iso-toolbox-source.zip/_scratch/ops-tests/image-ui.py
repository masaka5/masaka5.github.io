import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/iso/');assert await page.locator('h1').inner_text()=='镜像工具'
  await page.locator('#browseTab').click();assert await page.locator('#openImage').is_visible()
  await page.locator('#createTab').click();await page.locator('#imageFormat').select_option('img')
  await page.locator('#files').set_input_files({'name':'中文.txt','mimeType':'text/plain','buffer':'测试内容'.encode()})
  await page.locator('#outputMode').select_option('download');await page.locator('#generate').click();await page.locator('#download').wait_for(state='visible',timeout=90000)
  async with page.expect_download() as d:await page.locator('#download').click()
  download=await d.value;path=await download.path();assert download.suggested_filename.endswith('.img')
  await page.locator('#browseTab').click();await page.locator('#imageInput').set_input_files(path)
  await page.locator('#imageRows tr').first.wait_for(timeout=90000);assert '中文.txt' in await page.locator('#imageRows').inner_text()
  assert await page.locator('#saveImage').is_enabled()
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(100)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   for selector in ['#openImage','#createTab','#browseTab']:
    box=await page.locator(selector).bounding_box();assert box and box['y']>=0 and box['y']+box['height']<=h,(selector,w,h,box)
  await page.screenshot(path='_scratch/image-browser-mobile.png');assert not errors,errors
  await page.goto(BASE+'/tools/webvm/');assert await page.locator('a[href="../../licenses/vm.html"]').count()==0
  print(json.dumps({'image_ui':True,'real_FAT_roundtrip':True,'layouts':5,'VM_license_link_removed':True,'errors':errors}));await b.close()
asyncio.run(main())
