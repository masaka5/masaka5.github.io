import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
  await page.goto(BASE+'/tools/iso/')
  await page.evaluate('''async()=>{
   const {ImageEngine}=await import('./image-engine.js');const e=new ImageEngine();
   const inner=await e.create({format:'img',entries:[{path:'内部/old.txt',blob:new Blob(['old'])},{path:'keep.txt',blob:new Blob(['keep'])}]});
   const zip=await e.create({format:'zip',entries:[{path:'镜像/disk.img',blob:inner},{path:'z.txt',blob:new Blob(['zip keep'])}]});
   const root=await e.create({format:'iso',entries:[{path:'资料/bundle.zip',blob:zip},{path:'root.txt',blob:new Blob(['root keep'])}]});e.destroy();
   const dir=await navigator.storage.getDirectory();window.originalImage=await dir.getFileHandle('nested.iso',{create:true});let w=await originalImage.createWritable();await w.write(root);await w.close();
   window.savedImage=await dir.getFileHandle('edited.iso',{create:true});window.showOpenFilePicker=async()=>[originalImage];window.showSaveFilePicker=async()=>savedImage;
  }''')
  await page.locator('#browseTab').click();await page.locator('#openImage').click()
  await page.locator('[data-open="资料"]').click(timeout=3000)
  await page.locator('[data-open="资料/bundle.zip"]').click();await page.locator('[data-open="镜像"]').click()
  await page.locator('[data-open="镜像/disk.img"]').click();await page.locator('[data-open="内部"]').click()
  await page.locator('[data-select="内部/old.txt"]').check();await page.locator('#deleteImageEntries').click();await page.locator('#confirmImageDelete').click()
  assert await page.locator('[data-open="内部/old.txt"]').count()==0
  await page.locator('#imageAddInput').set_input_files({'name':'新增.txt','mimeType':'text/plain','buffer':'新内容'.encode()})
  await page.locator('#imageUp').click();await page.locator('#imageUp').click()
  await page.locator('[data-open="镜像/disk.img"]').wait_for()
  await page.locator('#imageUp').click();await page.locator('#imageUp').click()
  await page.locator('[data-open="资料/bundle.zip"]').wait_for();await page.locator('#saveImage').click()
  await page.wait_for_function("document.querySelector('#browseStatus').textContent==='已保存副本'")
  result=await page.evaluate('''async()=>{
   const {ImageEngine}=await import('./image-engine.js');const e=new ImageEngine();const root=await savedImage.getFile();
   const [zip]=await e.extract(root,['资料/bundle.zip']);const [disk]=await e.extract(zip.blob,['镜像/disk.img']);
   const list=await e.list(disk.blob);if(list.entries.some(n=>n.path==='内部/old.txt'))throw Error('deleted member returned');
   const [added,keep]=await e.extract(disk.blob,['内部/新增.txt','keep.txt']);if(await added.blob.text()!=='新内容'||await keep.blob.text()!=='keep')throw Error('inner bytes');
   const [rootKeep]=await e.extract(root,['root.txt']);if(await rootKeep.blob.text()!=='root keep')throw Error('root bytes');
   const [oz]=await e.extract(await originalImage.getFile(),['资料/bundle.zip']);const [oi]=await e.extract(oz.blob,['镜像/disk.img']);if(!(await e.list(oi.blob)).entries.some(n=>n.path==='内部/old.txt'))throw Error('source changed');
   e.destroy();return {nested_iso_zip_img:true,delete:true,add_in_subdirectory:true,writeback:true,source_preserved:true};
  }''')
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h})
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   await page.locator('[data-open="资料/bundle.zip"]').scroll_into_view_if_needed()
   for selector in ['#imageUp','#deleteImageEntries','#saveImage','[data-open="资料/bundle.zip"]']:
    assert await page.locator(selector).evaluate('(e)=>{const b=e.getBoundingClientRect();return e.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2))}'),(selector,w,h)
  await page.screenshot(path='_scratch/image-nested-mobile.png');assert not errors,errors
  print(json.dumps({**result,'layouts':5,'errors':errors}));await b.close()
asyncio.run(main())
