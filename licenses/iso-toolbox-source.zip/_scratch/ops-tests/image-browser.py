import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page();await page.goto(BASE+'/tools/iso/')
  result=await page.evaluate('''async()=>{
   const {ImageEngine}=await import('./image-engine.js');const engine=new ImageEngine();
   const assert=(v,m)=>{if(!v)throw Error(m)};const results={};
   for(const format of ['img','vhd','wim']){
    const blob=await engine.create({format,entries:[{path:'资料/hello.txt',blob:new Blob(['hello'])},{path:'empty',kind:'directory'}]});
    const listed=await engine.list(blob);
    assert(listed.writable===format,'writable '+format+JSON.stringify(listed));
    const file=listed.entries.find(e=>e.path.endsWith('hello.txt'));assert(file,'file '+format);assert(file.path==='资料/hello.txt','unicode path '+JSON.stringify(file));
    assert(listed.entries.some(e=>e.path.endsWith('empty')&&e.directory),'empty dir '+format);
    const out=await engine.extract(blob,[file.path]);assert(await out[0].blob.text()==='hello','extract '+format);
    const updated=await engine.update({format,blob,entries:[{path:'added.txt',blob:new Blob(['new'])}]});
    const again=await engine.list(updated),add=again.entries.find(e=>e.path.endsWith('added.txt'));assert(add?.path==='added.txt','merge exact path '+format);
    assert(add,'updated '+format);assert(await (await engine.extract(updated,[add.path]))[0].blob.text()==='new','update bytes '+format);
    const old=again.entries.find(e=>e.path.endsWith('hello.txt'));assert(old,'preserved '+format);assert(await (await engine.extract(updated,[old.path]))[0].blob.text()==='hello','old bytes '+format);
    const replacement=await engine.update({format,blob:updated,entries:[{path:'资料/hello.txt',blob:new Blob(['replaced'])}]});
    assert(await (await engine.extract(replacement,['资料/hello.txt']))[0].blob.text()==='replaced','replace '+format);
    assert(await (await engine.extract(blob,['资料/hello.txt']))[0].blob.text()==='hello','original unchanged '+format);
    if(format==='img'||format==='vhd'){
     const aliasSource=await engine.create({format,entries:[{path:'hello.txt',blob:new Blob(['original'])},{path:'Parent/nested.txt',blob:new Blob(['nested'])}]});
     for(const path of ['HELLO.TXT','parent/new.txt','parent/nested.txt']){
      let rejected=false;try{await engine.update({format,blob:aliasSource,entries:[{path,blob:new Blob(['wrong'])}]})}catch(e){rejected=e.message.includes('大小写冲突')}
      assert(rejected,'existing FAT alias rejected '+format+' '+path);
     }
     const exact=await engine.update({format,blob:aliasSource,entries:[{path:'hello.txt',blob:new Blob(['exact'])},{path:'Parent/nested.txt',blob:new Blob(['exact nested'])}]});
     assert(await (await engine.extract(exact,['hello.txt']))[0].blob.text()==='exact','exact FAT replacement '+format);
     assert(await (await engine.extract(exact,['Parent/nested.txt']))[0].blob.text()==='exact nested','exact parent FAT replacement '+format);
     assert(await (await engine.extract(aliasSource,['hello.txt']))[0].blob.text()==='original','alias source unchanged '+format);
    }
    results[format]={bytes:blob.size,entries:listed.entries.length,roundtrip:true};
    if(format==='img')window.imageTestBlob=blob;
   }
   for(const options of [{format:'img',capacityMiB:257},{format:'wim',entries:[{path:'../escape',blob:new Blob(['x'])}]},{format:'img',entries:[{path:'A.txt',blob:new Blob(['1'])},{path:'a.txt',blob:new Blob(['2'])}]},{format:'wim',entries:Array.from({length:10001},(_,i)=>({path:'f'+i,kind:'directory'}))}]){let failed=false;try{await engine.create(options)}catch{failed=true}assert(failed,'rejection');}
   const {planImage,imageChunks}=await import('./iso-core.js'),isoPlan=planImage([{path:'iso.txt',kind:'file',blob:new Blob(['iso bytes']),size:9},{path:'empty',kind:'directory'}]),parts=[];for await(const chunk of imageChunks(isoPlan))parts.push(chunk);
   const iso=new File(parts,'wrong.img'),isoList=await engine.list(iso);assert(isoList.writable===null,'ISO readonly');assert(isoList.format==='iso','ISO detected by contents');
   assert(await (await engine.extract(iso,['iso.txt']))[0].blob.text()==='iso bytes','ISO extraction');results.iso={readonly:true,roundtrip:true};
   const {fixedVhd}=await import('./image-engine-core.js'),dynamic=fixedVhd(new Uint8Array(1024*1024)),footer=dynamic.subarray(-512),view=new DataView(footer.buffer,footer.byteOffset,512);view.setUint32(60,3);view.setUint32(64,0);let sum=0;for(const n of footer)sum=(sum+n)>>>0;view.setUint32(64,~sum>>>0);
   let dynamicRejected=false;try{await engine.update({format:'vhd',blob:new Blob([dynamic]),entries:[]})}catch{dynamicRejected=true}assert(dynamicRejected,'dynamic VHD readonly');
   const fakeFat=new Uint8Array(1024*1024);fakeFat.set(new TextEncoder().encode('FAT16   '),54);let fakeRejected=false;try{await engine.update({format:'img',blob:new Blob([fakeFat]),entries:[]})}catch{fakeRejected=true}assert(fakeRejected,'FAT signature alone not writable');
   let largeRejected=false;try{await engine.create({format:'wim',entries:[{path:'big.bin',blob:new Blob(Array(257).fill(new Uint8Array(1024*1024)))}]})}catch{largeRejected=true}assert(largeRejected,'large files preflight');
   let bad=false;try{await engine.list(new Blob(['invalid']))}catch{bad=true}assert(bad,'bad image');
   const pending=engine.list(new Blob(['cancel']));let busy=false;try{await engine.list(new Blob(['busy']))}catch{busy=true}assert(busy,'single operation');engine.cancel();let canceled=false;try{await pending}catch(e){canceled=e.name==='AbortError'}assert(canceled,'cancel settled');
   engine.destroy();return {...results,cancel:true,bounds:true};
  }''')
  async def bounded_array_buffer(route):
   response=await route.fetch();source=await response.text()
   source="const nativeArrayBuffer=Blob.prototype.arrayBuffer;Blob.prototype.arrayBuffer=function(){if(this.size>1024*1024)throw Error('whole image read');return nativeArrayBuffer.call(this);};\n"+source
   await route.fulfill(response=response,body=source)
  await page.context.route('**/image-engine-worker.js',bounded_array_buffer)
  lazy=await page.evaluate("async()=>{const {ImageEngine}=await import('./image-engine.js');const e=new ImageEngine();const r=await e.list(imageTestBlob);return r.writable==='img'}")
  assert lazy;result['lazy_input']=True
  await page.context.unroute('**/image-engine-worker.js',bounded_array_buffer)
  print(json.dumps(result));await b.close()
asyncio.run(main())
