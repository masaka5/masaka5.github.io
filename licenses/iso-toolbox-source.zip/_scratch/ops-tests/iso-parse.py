"""Independent ISO parser, deliberately unrelated to writer implementation."""
import sys,io,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qa-python'))
import pycdlib
p=Path(sys.argv[1])if len(sys.argv)>1 else Path('_scratch/iso-acceptance.iso')
iso=pycdlib.PyCdlib();iso.open(str(p))
expected={'/文档/说明.txt':'中文'.encode(),'/文档/报告.txt':'报告'.encode(),'/empty':b'','/large.bin':bytes([123])*(5*1024*1024+3)}
for path,data in expected.items():
 out=io.BytesIO();iso.get_file_from_iso_fp(out,joliet_path=path+';1');assert out.getvalue()==data,path
assert iso.get_record(joliet_path='/空目录').is_dir()
base=[]
for root,dirs,files in iso.walk(iso_path='/'):
 assert len(files)==len(set(files)),(root,files)
 base.extend(files)
iso.close();print(json.dumps({'independent_parser':'pycdlib','chinese_paths':True,'empty_directory':True,'payloads_exact':True,'unique_base_names':True}))
if len(sys.argv)==1:
 iso=pycdlib.PyCdlib();iso.open('_scratch/iso-many.iso')
 for n in range(300):
  out=io.BytesIO();iso.get_file_from_iso_fp(out,joliet_path=f'/版本.v1/文档_{n:03}.txt;1');assert out.getvalue()==str(n).encode()
 for root,dirs,files in iso.walk(iso_path='/'):
  assert len(files)==len(set(files))
  for d in dirs:assert '.'not in d,d
 iso.close();print(json.dumps({'large_directory_files':302,'base_alias_collisions':False,'dotted_directory_base_valid':True}))
