from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,json
ROOT=Path(__file__).resolve().parents[2];BASE='https://tools.manshii.asia/'
paths=['tools/iso/'+p.name for p in (ROOT/'toolbox-site/tools/iso').iterdir()if p.is_file()and p.suffix!='.c']+['licenses/sources.json','licenses/iso-toolbox-source.zip']
def check(path):
 with urllib.request.urlopen(BASE+path+'?release=image-navigation-20261112',timeout=30)as r:data=r.read();assert r.status==200
 assert hashlib.sha256(data).digest()==hashlib.sha256((ROOT/'toolbox-site'/path).read_bytes()).digest(),path
 return path
with ThreadPoolExecutor(max_workers=6)as pool:verified=list(pool.map(check,paths))
print(json.dumps({'https_files_match':len(verified)}))
