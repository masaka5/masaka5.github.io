import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto(BASE+'/tools/iso/')
  result=await page.evaluate('''async()=>{
   const {ImageEngine}=await import('./image-engine.js');const e=new ImageEngine(),results={};
   for(const format of ['img','vhd','wim','zip','7z','iso']){
    const original=await e.create({format,entries:[{path:'资料/remove.txt',blob:new Blob(['delete'])},{path:'资料/empty',directory:true},{path:'资料2/keep.txt',blob:new Blob(['keep'])}]});
    const out=await e.update({format,blob:original,remove:['资料'],entries:[{path:'added/new.txt',blob:new Blob(['new'])}]});
    const listed=await e.list(out);if(listed.entries.some(n=>n.path==='资料'||n.path.startsWith('资料/')))throw Error('delete failed '+format);
    const files=await e.extract(out,['资料2/keep.txt','added/new.txt']);if(await files[0].blob.text()!=='keep'||await files[1].blob.text()!=='new')throw Error('bytes '+format);
    if(!(await e.list(original)).entries.some(n=>n.path==='资料/remove.txt'))throw Error('source changed '+format);
    const allPaths=listed.entries.map(n=>n.path);const empty=await e.update({format,blob:out,remove:allPaths,entries:[]});
    if((await e.list(empty)).entries.length)throw Error('delete all '+format);
    results[format]=true;
   }e.destroy();return results;
  }''');print(json.dumps(result));await b.close()
asyncio.run(main())
