"""Real Worker and OPFS write transactions; fault injection only simulates I/O failure."""
import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);context=await b.new_context();page=await context.new_page();await page.goto(BASE+'/tools/iso/');await page.wait_for_function("document.querySelector('#files').onchange!==null")
  await page.evaluate('''async()=>{
   const root=await navigator.storage.getDirectory(),handle=await root.getFileHandle('transaction.iso',{create:true}),writer=await handle.createWritable();await writer.write('original');await writer.close();
   window.isoTestHandle=handle;window.showSaveFilePicker=async()=>handle;
   const input=document.querySelector('#files'),data=new DataTransfer();data.items.add(new File([new Uint8Array(64*1024*1024)],'large.bin'));input.files=data.files;input.dispatchEvent(new Event('change'));
  }''')
  await page.locator('#generate').click();await page.wait_for_function("document.querySelector('#status').textContent.includes('正在制作 ')");await page.locator('#cancel').click();await page.wait_for_function("document.querySelector('#status').textContent==='已取消'")
  assert await page.evaluate('async()=>(await isoTestHandle.getFile()).text()')=='original'
  assert await page.locator('#generate').is_enabled()
  async def fault(route):
   response=await route.fetch();source=await response.text();assert 'if(writable)await writable.write(chunk);else chunks.push(chunk);'in source
   await route.fulfill(response=response,body=source.replace('if(writable)await writable.write(chunk);else chunks.push(chunk);',"if(writable)throw Error('测试写入失败');else chunks.push(chunk);"))
  await context.route('**/tools/iso/iso-worker.js',fault);await page.locator('#generate').click();await page.wait_for_function("document.querySelector('#status').textContent==='测试写入失败'")
  assert await page.evaluate('async()=>(await isoTestHandle.getFile()).text()')=='original';assert await page.locator('#generate').is_enabled()
  await context.unroute('**/tools/iso/iso-worker.js',fault)
  # Empty directories survive native directory selection.
  await page.locator('#clear').click();await page.evaluate('''async()=>{const r=await navigator.storage.getDirectory(),d=await r.getDirectoryHandle('资料目录',{create:true});await d.getDirectoryHandle('空目录',{create:true});window.showDirectoryPicker=async()=>d}''');await page.locator('#addFolder').click();await page.wait_for_function("document.querySelector('#fileList').textContent.includes('空目录')")
  assert await page.locator('#generate').is_enabled()
  await page.evaluate('''()=>{const input=document.querySelector('#files'),data=new DataTransfer(),part=new Uint8Array(1024*1024);data.items.add(new File(Array(513).fill(part),'limit.bin'));input.files=data.files;input.dispatchEvent(new Event('change'))}''')
  await page.locator('#outputMode').select_option('download');await page.locator('#generate').click();assert '512 MiB'in await page.locator('#status').inner_text()
  print(json.dumps({'base':BASE,'cancel_aborts_transaction':True,'io_failure_preserves_original':True,'empty_folder_import':True,'blob_size_limit':True}));await b.close()
asyncio.run(main())
