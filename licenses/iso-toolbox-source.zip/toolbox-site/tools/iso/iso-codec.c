/* ISO 9660/Joliet metadata encoder, freestanding WebAssembly.
 * Field layouts adapted from vendor/iso9660/{pvd,dir-record,path-table}.js
 * @gcu/iso9660 0.1.0, Copyright (c) 2025 Arthur Endlein Correia.
 * No libc or host imports.
 *
 * MIT License
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
typedef unsigned char u8;
typedef unsigned int u32;
static u8 input[1024], output[2048];
u8 *iso_input(void){return input;}
u8 *iso_output(void){return output;}
static void zero(u32 n){for(u32 i=0;i<n;i++)output[i]=0;}
static void copy(u8 *d,const u8 *s,u32 n){for(u32 i=0;i<n;i++)d[i]=s[i];}
static void word(u8 *d,u32 v,u32 n,int le){for(u32 i=0;i<n;i++)d[i]=(u8)(v>>(8*(le?i:n-1-i)));}
static void both(u8 *d,u32 v,u32 n){word(d,v,n,1);word(d+n,v,n,0);}
u32 iso_record(u32 lba,u32 size,u32 directory,u32 length){
 if(length>222)return 0;
 u32 n=(34+length)&~1u;zero(n);output[0]=(u8)n;
 both(output+2,lba,4);both(output+10,size,4);copy(output+18,input+256,7);
 output[25]=directory?2:0;both(output+28,1,2);output[32]=(u8)length;copy(output+33,input,length);return n;
}
u32 iso_path(u32 lba,u32 parent,u32 length,u32 le){
 if(length>255||parent>65535)return 0;
 u32 n=8+length+(length&1);zero(n);output[0]=(u8)length;
 word(output+2,lba,4,le);word(output+6,parent,2,le);copy(output+8,input,length);return n;
}
static void text(u32 at,u32 length,u32 start,u32 count,int joliet){
 for(u32 i=0;i<length;i++)output[at+i]=joliet?0:32;
 for(u32 i=0;i<count&&i<(joliet?length/2:length);i++)output[at+(joliet?i*2+1:i)]=input[start+i];
}
u32 iso_descriptor(u32 type,u32 sectors,u32 pathsize,u32 le,u32 be,u32 rootlba,u32 rootsize,u32 labelsize){
 zero(2048);output[0]=(u8)type;output[1]='C';output[2]='D';output[3]='0';output[4]='0';output[5]='1';output[6]=1;
 if(type==255)return 2048;
 int joliet=type==2;
 text(8,32,0,0,joliet);text(40,32,0,labelsize,joliet);
 both(output+80,sectors,4);if(joliet){output[88]=37;output[89]=47;output[90]=69;}
 both(output+120,1,2);both(output+124,1,2);both(output+128,2048,2);both(output+132,pathsize,4);
 word(output+140,le,4,1);word(output+148,be,4,0);
 output[156]=34;both(output+158,rootlba,4);both(output+166,rootsize,4);copy(output+174,input+256,7);output[181]=2;both(output+184,1,2);output[188]=1;
 text(190,128,0,0,joliet);text(318,128,0,0,joliet);text(446,128,0,0,joliet);text(574,128,64,7,joliet);
 text(702,37,0,0,joliet);text(739,37,0,0,joliet);text(776,37,0,0,joliet);
 copy(output+813,input+272,17);copy(output+830,input+272,17);output[881]=1;return 2048;
}
