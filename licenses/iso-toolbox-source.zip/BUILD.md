# ISO 与目录源码

纯静态网页。Python 3 运行 `_scratch/stage-iso-vendor.py` 获取锁定 MIT 编码模块（校验 npm SHA1），然后运行 Node `_scratch/build-toolbox-catalog.cjs` 与 `_scratch/build-toolbox-icons.cjs` 更新目录。完整目录构建还需 integration-source.zip 中的现有上游项目和锁文件；已有部署包内的 vendor 与资产可直接使用，无构建步骤。

生成资料 ISO 9660 + Joliet，无系统引导。Chrome/Edge 直接保存分块写入；下载方式上限 512 MiB。单文件 <4 GiB、目录最多 7 层，名称不受支持时明确拒绝。运行 `node --test _scratch/ops-tests/iso.test.cjs`；Python 独立解析测试需 pycdlib==1.14.0 安装到 _scratch/qa-python。浏览器测试需 Playwright；TOOLBOX_TEST_BASE 可指向静态站。
