import {pinyin} from 'pinyin-pro';
export function convert(text,options={}){
 const {mode='tone',case:letterCase='lower',separator=' ',flatten=false}=options;
 const items=pinyin(text,{type:'all',toneType:mode==='number'?'num':mode==='none'||mode==='initial'?'none':'symbol'});
 let previous=false;return items.map(item=>{if(!item.isZh){previous=false;return flatten?item.origin.replace(/\r?\n/g,' '):item.origin;}let s=mode==='initial'?item.first:item.pinyin;if(letterCase==='upper')s=s.toUpperCase();else if(letterCase==='capitalize')s=s[0].toUpperCase()+s.slice(1);const out=(previous?separator:'')+s;previous=true;return out;}).join('');
}
