import React from 'react';import './style.css';
export function Shell({title,actions,children,status='',page=''}){return <div className={'creative '+page}><header><a href="../../">← 口袋工具箱</a><h1>{title}</h1><div className="header-actions">{actions}</div></header><main>{children}</main><div className="status" role="status">{status}</div></div>;}
export function save(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
export async function copy(text,setStatus){try{await navigator.clipboard.writeText(text);setStatus('已复制');}catch{setStatus('复制失败，请选中文本复制');}}
