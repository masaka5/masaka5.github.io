import {RegExpParser} from '@eslint-community/regexpp';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const move=(box,x,y)=>`<g transform="translate(${x} ${y})">${box.svg}</g>`;
const line=(x1,y1,x2,y2)=>`<path d="M${x1},${y1}H${x2}V${y2}"/>`;
function label(text,x,y){return `<text x="${x}" y="${y}" text-anchor="middle">${esc(text)}</text>`;}
function leaf(text,raw,assertion=false){const w=Math.max(76,Math.min(330,Array.from(text).length*8+24)),shown=Array.from(text).slice(0,35).join('');return {w,h:48,svg:`<g class="${assertion?'assertion':'token'}"><title>${esc(raw)}</title><rect x="0" y="6" width="${w}" height="36" rx="6"/>${label(shown,w/2,29)}</g>`};}
function sequence(children){if(!children.length)return leaf('ε（空串）','');const boxes=children.map(draw),h=Math.max(...boxes.map(b=>b.h));let x=0,svg='';for(const b of boxes){if(x)svg+=line(x-24,h/2,x,h/2);svg+=move(b,x,(h-b.h)/2);x+=b.w+24;}return{w:x-24,h,svg};}
function branch(alternatives){if(alternatives.length===1)return sequence(alternatives[0].elements);const boxes=alternatives.map(a=>sequence(a.elements)),w=Math.max(...boxes.map(b=>b.w))+80,centers=[];let y=28,svg=label('选择',w/2,14);for(const b of boxes){const cy=y+b.h/2;centers.push(cy);svg+=`<path d="M16,${cy}H40M${40+b.w},${cy}H${w-16}"/>`+move(b,40,y);y+=b.h+18;}const h=y+10;svg+=`<path d="M0,${h/2}H16M16,${centers[0]}V${centers.at(-1)}M${w-16},${centers[0]}V${centers.at(-1)}M${w-16},${h/2}H${w}"/>`;return{w,h,svg};}
function wrap(box,title,kind='group'){const w=box.w+32,h=box.h+56;return{w,h,svg:`<g class="${kind}"><rect x="0" y="0" width="${w}" height="${h}" rx="7"/>${label(title,w/2,18)}<path d="M0,${h/2}H16M${w-16},${h/2}H${w}"/>${move(box,16,28)}</g>`};}
function draw(node){
 switch(node.type){
  case 'Pattern':return branch(node.alternatives);
  case 'Alternative':return sequence(node.elements);
  case 'CapturingGroup':return wrap(branch(node.alternatives),'分组 '+(node.name||node._number));
  case 'Group':return wrap(branch(node.alternatives),'非捕获组');
  case 'Quantifier':{const b=draw(node.element),min=node.min,max=node.max===Infinity?'∞':node.max,w=b.w+72,h=b.h+72;const title=`重复 ${min}–${max}${node.greedy?'':' · 懒惰'}`;return{w,h,svg:label(title,w/2,17)+move(b,36,36)+`<path d="M0,${h/2}H36M${w-36},${h/2}H${w}M${w-36},${h/2}H${w-18}V${h-10}H18V${h/2}H36"/>`+(min===0?`<path class="skip" d="M0,${h/2}H8V25H${w-8}V${h/2}H${w}"/>`:'')};}
  case 'Assertion':{if(node.alternatives)return wrap(branch(node.alternatives),(node.kind==='lookahead'?'向前':'向后')+(node.negate?'否定':'肯定')+'断言','assertion');return leaf(({start:'行首 ^',end:'行尾 $',word:node.negate?'非单词边界':'单词边界'})[node.kind]||node.raw,node.raw,true);}
  case 'Character':return leaf(node.value===10?'换行 \\n':node.value===9?'制表符 \\t':String.fromCodePoint(node.value),node.raw);
  case 'CharacterSet':return leaf((node.negate?'非':'')+({digit:'数字',space:'空白',word:'单词字符',any:'任意字符',property:node.raw}[node.kind]||node.raw),node.raw);
  case 'CharacterClass':case 'ExpressionCharacterClass':return leaf((node.negate?'排除':'')+'字符集 '+node.raw,node.raw);
  case 'Backreference':return leaf('反向引用 '+node.ref,node.raw);
  default:return leaf(node.raw||'ε',node.raw||'');
 }
}
export function diagram(source,flags=''){
 if(source.length>1500)throw Error('表达式请控制在 1500 字符以内');
 if(!/^[dgimsuvy]*$/.test(flags)||new Set(flags).size!==flags.length||flags.includes('u')&&flags.includes('v'))throw Error('标志无效，u 与 v 不能同时使用');
 const tree=new RegExpParser({ecmaVersion:2025}).parsePattern(source,0,source.length,{unicode:flags.includes('u'),unicodeSets:flags.includes('v')});
 let count=0,groups=0;function visit(n){if(++count>700)throw Error('表达式结构过于复杂');if(n.type==='CapturingGroup')n._number=++groups;for(const k of ['alternatives','elements'])for(const c of n[k]||[])visit(c);if(n.element)visit(n.element);}visit(tree);
 const b=draw(tree),w=b.w+80,h=b.h+48;if(w>24000||h>24000)throw Error('结构图过大，请缩短表达式');
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" role="img" aria-label="正则表达式结构图"><style>text{font:12px 'Microsoft YaHei',system-ui,sans-serif;fill:#27364b}path{fill:none;stroke:#728095;stroke-width:1.5}.token rect{fill:#eff4ff;stroke:#b9cbee}.group>rect{fill:#fff;stroke:#ccd6e5}.assertion>rect{fill:#f8fafc;stroke:#91a3bc;stroke-dasharray:4 3}.skip{stroke-dasharray:4 3}</style><rect width="100%" height="100%" fill="white"/><circle cx="12" cy="${h/2}" r="4" fill="#285de5"/>${line(16,h/2,40,h/2)}${move(b,40,24)}${line(w-40,h/2,w-16,h/2)}<circle cx="${w-12}" cy="${h/2}" r="4" fill="#285de5"/></svg>`;
}
