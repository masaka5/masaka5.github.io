import {defineConfig} from 'vite';
import {resolve} from 'node:path';
export default defineConfig({base:'./',build:{outDir:'../../toolbox-site/tools/creative',emptyOutDir:true,rollupOptions:{input:{regex:resolve(import.meta.dirname,'regex.html'),pinyin:resolve(import.meta.dirname,'pinyin.html'),canvas:resolve(import.meta.dirname,'canvas.html')}}}});
