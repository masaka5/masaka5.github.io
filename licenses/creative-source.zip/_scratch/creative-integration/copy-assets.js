import{cp,mkdir,readFile,writeFile}from'node:fs/promises';
await mkdir('../../toolbox-site/tools/creative/assets/fonts',{recursive:true});
await cp('node_modules/@excalidraw/excalidraw/dist/prod/fonts','../../toolbox-site/tools/creative/assets/fonts',{recursive:true});
for(const name of ['canvas.html','regex.html','pinyin.html']){
 const target='../../toolbox-site/tools/creative/'+name;
 await writeFile(target,(await readFile(target,'utf8')).replace('</head>','<link rel="stylesheet" href="../../assets/tool-shell.css"></head>'));
}
