import{readFile,writeFile}from'node:fs/promises';
const file='node_modules/@excalidraw/excalidraw/dist/prod/locales/zh-CN-LNUGB5OW.js';
let text=await readFile(file,'utf8');if(!text.includes('createFlowchart:')){if(!text.includes('bindTextToElement:'))throw Error('Chinese locale format changed');text=text.replace('bindTextToElement:','createFlowchart:"按住 Ctrl 或 Cmd 和方向键创建流程图",bindTextToElement:');await writeFile(file,text);}
