"""Build license/source artifacts and exact runtime manifest."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site';PROJECT=ROOT/'_scratch/creative-integration';CLOUD=ROOT/'toolbox-cloud'
out=SITE/'licenses/creative';out.mkdir(exist_ok=True)
previous=out/'dependencies.json'
if previous.exists():
 for entry in json.loads(previous.read_text(encoding='utf8')):
  target=(SITE/'licenses'/entry['file']).resolve()
  assert target.is_relative_to(out.resolve()),entry
  if target.is_file():target.unlink()
notices=[]
for package in (PROJECT/'node_modules').rglob('package.json'):
 try:info=json.loads(package.read_text(encoding='utf8'))
 except:continue
 name=info.get('name');version=info.get('version')
 if not name or not version:continue
 for item in package.parent.iterdir():
  if item.is_file()and item.name.lower().startswith(('license','licence','notice','copying')):
   dest=out/(name.replace('/','_').replace('@','')+'-'+version+'-'+item.name)
   dest.write_bytes(item.read_bytes());notices.append({'package':name,'version':version,'license':info.get('license'),'file':'creative/'+dest.name})
(out/'dependencies.json').write_text(json.dumps(notices,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
manifest={'files':[{'file':p.relative_to(SITE/'tools/creative').as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted((SITE/'tools/creative').rglob('*'))if p.is_file()and p.name!='manifest.json']}
(SITE/'tools/creative/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(SITE/'licenses/creative-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for folder,prefix in [(PROJECT,'_scratch/creative-integration'),(CLOUD,'toolbox-cloud')]:
  for p in sorted(folder.rglob('*')):
   rel=p.relative_to(folder)
   if not p.is_file()or any(part in {'node_modules','.wrangler','.git'}for part in rel.parts)or p.name=='.dev.vars':continue
   z.write(p,prefix+'/'+rel.as_posix())
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'toolbox-site/licenses/creative/'+p.name)
 for p in (ROOT/'_scratch/ops-tests').glob('*'):
  if p.is_file()and p.name.startswith(('creative-','home-usage','usage-')):z.write(p,'_scratch/ops-tests/'+p.name)
 z.write(Path(__file__),'_scratch/package-creative.py')
 z.writestr('BUILD.md','''# 口袋工具箱：画布、正则、拼音与统计

Node.js 22+。部署包提供第三方字体、Wasm 等运行资源。

```sh
cd _scratch/creative-integration
npm ci --no-audit --no-fund
npm test
npm run build
```

构建后站点 tools/creative/ 可直接由静态 HTTPS 服务提供。Excalidraw 0.18.1、regexpp 4.12.3、pinyin-pro 3.29.5 均保留 MIT 许可；各依赖许可见 licenses/creative/。本项目没有复制菜鸟网站的非开源页面代码，只参考其功能。

统计服务部署步骤和隐私边界见 toolbox-cloud/README.md。Worker 及 Pages 入口从同一 src/worker.js 编译，绑定同一个 D1；Pages secrets 不写入构建文件。源码包没有实际凭据。
''')
refs=[{'project':'toolbox-creative','source':'first-party integration','sourceArchive':'licenses/creative-source.zip','changes':'Self-hosted Excalidraw, regexpp railroad diagrams and pinyin-pro; Cloudflare usage collector source.'},{'project':'excalidraw','source':'https://github.com/excalidraw/excalidraw','version':'0.18.1','license':'MIT'},{'project':'regexpp','source':'https://github.com/eslint-community/regexpp','version':'4.12.3','license':'MIT'},{'project':'pinyin-pro','source':'https://github.com/zh-lx/pinyin-pro','version':'3.29.5','license':'MIT'}]
path=SITE/'licenses/sources.json';items=json.loads(path.read_text());names={r['project']for r in refs};path.write_text(json.dumps([r for r in items if r.get('project')not in names]+refs,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'runtime_files':len(manifest['files']),'license_notices':len(notices),'source_bytes':(SITE/'licenses/creative-source.zip').stat().st_size}))
