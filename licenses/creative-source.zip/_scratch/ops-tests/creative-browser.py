"""Real local-tool workflows and responsive checks in Chromium."""
import asyncio,json,os,sys
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
sys.stdout.reconfigure(encoding='utf8')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch();page=await browser.new_page(viewport={'width':1440,'height':900},accept_downloads=True);errors=[];failed=[];external=[]
  page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:failed.append(r.url)if r.status>=400 and '/tools/creative/'in r.url else None)
  page.on('request',lambda r:external.append(r.url)if r.url.startswith('http')and not r.url.startswith(BASE)else None)
  await page.goto(BASE+'/tools/creative/pinyin.html');await page.get_by_role('textbox',name='汉字文本',exact=True).fill('重庆银行\n你好 ABC 123')
  assert await page.get_by_role('textbox',name='拼音结果').input_value()=='chóng qìng yín háng\nnǐ hǎo ABC 123'
  await page.get_by_label('拼音格式').select_option('initial');await page.get_by_label('字母大小写').select_option('upper');await page.get_by_label('分隔符').select_option('-')
  assert await page.get_by_role('textbox',name='拼音结果').input_value()=='C-Q-Y-H\nN-H ABC 123'
  async with page.expect_download()as info:await page.get_by_role('button',name='下载',exact=True).click()
  download=await info.value;assert Path(await download.path()).read_text(encoding='utf8')=='C-Q-Y-H\nN-H ABC 123'
  await page.goto(BASE+'/tools/creative/regex.html');await page.get_by_label('正则表达式',exact=True).fill('(?<word>ab|cd)+\\d{2,4}');await page.get_by_label('测试文本').fill('abcd123 xx cd45')
  await page.wait_for_function("document.querySelectorAll('.match').length===2")
  assert '分组 word' in await page.locator('.diagram-viewport').inner_text()
  async with page.expect_download()as info:await page.get_by_role('button',name='PNG',exact=True).click()
  download=await info.value;assert Path(await download.path()).read_bytes().startswith(b'\x89PNG')
  await page.get_by_label('正则表达式',exact=True).fill('(');await page.get_by_text('语法错误，请检查括号、字符集、量词或转义。',exact=True).first.wait_for()
  await page.get_by_label('正则表达式',exact=True).fill('(a+)+$');await page.get_by_label('测试文本').fill('a'*40+'!');await page.get_by_text('匹配超时，请简化表达式或缩短文本。',exact=True).first.wait_for(timeout=10000)
  await page.get_by_label('正则表达式',exact=True).fill('a');await page.wait_for_function("document.querySelectorAll('.match').length===40")
  await page.goto(BASE+'/tools/creative/canvas.html');await page.locator('.excalidraw canvas').first.wait_for();await page.wait_for_timeout(1000)
  await page.locator('.excalidraw').click(position={'x':300,'y':300});await page.keyboard.press('r');box=await page.locator('.canvas-panel').bounding_box();x=box['x']+box['width']*.4;y=box['y']+box['height']*.4
  await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+160,y+100,steps=12);await page.mouse.up();await page.wait_for_timeout(700)
  async with page.expect_download()as info:await page.get_by_role('button',name='保存',exact=True).click()
  scene=json.loads(Path(await(await info.value).path()).read_text(encoding='utf8'));await page.screenshot(path='_scratch/creative-debug.png');assert any(e['type']=='rectangle'for e in scene['elements']),scene
  await page.reload();await page.locator('.excalidraw canvas').first.wait_for();await page.wait_for_timeout(700)
  async with page.expect_download()as info:await page.get_by_role('button',name='保存',exact=True).click()
  restored=json.loads(Path(await(await info.value).path()).read_text(encoding='utf8'));assert restored['elements'][0]['id']==scene['elements'][0]['id']
  await page.locator('.excalidraw').click(position={'x':300,'y':300});await page.keyboard.press('t');await page.mouse.click(x+50,y+160);await page.keyboard.insert_text('口袋画布 ABC');await page.keyboard.press('Escape');await page.wait_for_timeout(500)
  async with page.expect_download()as info:await page.get_by_role('button',name='保存',exact=True).click()
  with_text=json.loads(Path(await(await info.value).path()).read_text(encoding='utf8'));assert any(e.get('text')=='口袋画布 ABC'for e in with_text['elements'])
  # Import an actual scene file including an embedded image; reload must keep bytes.
  import base64
  image_data='data:image/png;base64,'+base64.b64encode(Path('_scratch/creative-debug.png').read_bytes()).decode()
  image_id='test-fixture-image';with_text['files'][image_id]={'id':image_id,'dataURL':image_data,'mimeType':'image/png','created':1}
  with_text['elements'].append({'id':'test-image','type':'image','x':100,'y':100,'width':80,'height':50,'angle':0,'strokeColor':'transparent','backgroundColor':'transparent','fillStyle':'solid','strokeWidth':1,'strokeStyle':'solid','roughness':0,'opacity':100,'seed':1,'version':1,'versionNonce':1,'isDeleted':False,'groupIds':[],'frameId':None,'roundness':None,'boundElements':None,'updated':1,'link':None,'locked':False,'fileId':image_id,'status':'saved','scale':[1,1]})
  await page.locator('input[type=file]').set_input_files({'name':'fixture.excalidraw','mimeType':'application/json','buffer':json.dumps(with_text).encode()});await page.wait_for_timeout(800);await page.reload();await page.locator('.excalidraw canvas').first.wait_for();await page.wait_for_timeout(500)
  async with page.expect_download()as info:await page.get_by_role('button',name='保存',exact=True).click()
  with_image=json.loads(Path(await(await info.value).path()).read_text(encoding='utf8'));assert with_image['files'][image_id]['dataURL']==image_data
  await page.locator('input[type=file]').set_input_files({'name':'broken.excalidraw','mimeType':'application/json','buffer':b'{broken'});await page.get_by_text('无法导入，请选择有效的画布或嵌入画布数据的 PNG / SVG').wait_for()
  async with page.expect_download()as info:await page.get_by_role('button',name='保存',exact=True).click()
  intact=json.loads(Path(await(await info.value).path()).read_text(encoding='utf8'));assert len(intact['elements'])==len(with_image['elements'])
  async with page.expect_download()as info:await page.get_by_role('button',name='PNG',exact=True).click()
  assert Path(await(await info.value).path()).read_bytes().startswith(b'\x89PNG')
  async with page.expect_download()as info:await page.get_by_role('button',name='SVG',exact=True).click()
  assert b'<svg' in Path(await(await info.value).path()).read_bytes()
  await page.screenshot(path='_scratch/creative-canvas.png')
  for width,height in [(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
   await page.set_viewport_size({'width':width,'height':height})
   for name in ['regex','pinyin','canvas']:
    await page.goto(BASE+'/tools/creative/'+name+'.html');await page.wait_for_timeout(350)
    assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(name,width,height)
    if name!='canvas':await page.get_by_role('textbox').first.wait_for()
  assert not errors,errors;assert not failed,failed;assert not external,external
  print(json.dumps({'base':BASE,'pinyin_context_options_download':True,'regex_diagram_match_export':True,'invalid_and_timeout_recovery':True,'canvas_draw_refresh_exports':True,'responsive_viewports':5,'page_errors':errors}),flush=True)
  await browser.close()
asyncio.run(main())
