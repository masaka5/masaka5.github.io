import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto('http://127.0.0.1:8765/tools/creative/canvas.html');await page.wait_for_timeout(800)
  print(await page.locator('.excalidraw').evaluate("(e)=>Object.fromEntries(['--color-primary','--color-primary-light','--color-brand-active','--color-selection','--color-surface-primary-container'].map(k=>[k,getComputedStyle(e).getPropertyValue(k)]))"))
  print(await page.get_by_role('radio',name='选择',exact=True).evaluate("(e)=>({self:getComputedStyle(e).backgroundColor,parent:getComputedStyle(e.parentElement).backgroundColor,html:e.parentElement.outerHTML.slice(0,500)})"))
  await b.close()
asyncio.run(main())
