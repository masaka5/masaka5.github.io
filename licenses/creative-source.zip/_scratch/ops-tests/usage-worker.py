"""Exercise the real Workers runtime and SQLite-backed D1, using isolated local data."""
import concurrent.futures,json,urllib.request,urllib.error,uuid
BASE='http://127.0.0.1:8788'
def call(path,body=None,origin='https://tools.manshii.asia',auth=None):
 headers={'Origin':origin,'Content-Type':'text/plain'}
 if auth:headers['Authorization']='Bearer '+auth
 try:
  with urllib.request.urlopen(urllib.request.Request(BASE+path,data=json.dumps(body).encode()if body is not None else None,headers=headers),timeout=30)as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:return e.code,json.load(e)
base=call('/counts')[1]['counts']['pinyin'];event={'id':str(uuid.uuid4()),'tool':'pinyin'}
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:responses=list(pool.map(lambda _:call('/events',event),range(12)))
assert all(s==200 and b['accepted']for s,b in responses),responses
assert call('/counts')[1]['counts']['pinyin']==base+1,'duplicate/concurrent event counted twice'
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:responses=list(pool.map(lambda _:call('/events',{'id':str(uuid.uuid4()),'tool':'pinyin'}),range(8)))
assert all(s==200 for s,b in responses),responses
assert call('/counts')[1]['counts']['pinyin']==base+9
assert call('/events',{'id':str(uuid.uuid4()),'tool':'made-up'})[0]==400
assert call('/events',event,origin='https://evil.invalid')[0]==403
assert call('/events',{'id':str(uuid.uuid4()),'tool':'pinyin','padding':'x'*300})[0]==413
assert call('/snapshot')[0]==401
assert call('/snapshot',auth='local-test-only-not-production')[0]==200
limited=False
for _ in range(65):
 if call('/events',{'id':str(uuid.uuid4()),'tool':'pinyin'})[0]==429:limited=True;break
assert limited
print(json.dumps({'real_worker':True,'D1_atomic_idempotency':True,'concurrent_increments':True,'allowed_ids':True,'origin_rejected':True,'bounded_body':True,'snapshot_auth':True,'rate_limit':True}))
