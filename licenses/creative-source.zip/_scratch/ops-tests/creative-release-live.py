"""Check deployed bytes, actual cloud reads and homepage entries without test clicks."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,os
ROOT=Path(__file__).resolve().parents[2];BASE=os.getenv('TOOLBOX_TEST_BASE','https://tools.manshii.asia').rstrip('/')
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page(viewport={'width':1440,'height':900});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'/');page.wait_for_function("document.querySelectorAll('.tool-card').length>1000")
 assert page.title()=='口袋工具箱 · 工具目录'
 assert page.locator('.brand').inner_text()=='口袋工具箱'
 live=page.evaluate('''async()=>{let r=await fetch('https://pocket-toolbox-usage.pages.dev/counts?verify='+Date.now(),{credentials:'omit'});return {status:r.status,data:await r.json()};}''')
 expected=json.loads((ROOT/'toolbox-cloud/src/tool-ids.json').read_text())
 assert live['status']==200 and set(live['data']['counts'])==set(expected),live['status']
 for tool,href in [('photo-editor','tools/photo-editor/'),('pinyin','tools/creative/pinyin.html'),('whiteboard','tools/creative/canvas.html'),('regex-tester','tools/creative/regex.html'),('markdown','tools/markdown/'),('web-adb','tools/web-adb/'),('archives','tools/archives/'),('jupyter','tools/jupyter/'),('python-ide','tools/python-ide/'),('powershell-ide','tools/powershell-ide/')]:
  link=page.locator('.tool-card[data-tool="'+tool+'"] .tool-link')
  assert link.count(),tool
  assert link.get_attribute('href')==href,(tool,link.get_attribute('href'))
  card=link.locator('xpath=..')
  # Counters use confirmed cloud totals, including a real zero at launch.
  page.wait_for_function("!document.querySelector('.tool-usage').textContent.includes('—')")
 assert page.locator('.tool-card.ant-card').count()==len(expected)
 assert page.locator('.tool-card:not([hidden])').count()>0
 assert page.locator('.tool-card:not([hidden])').count()<len(expected)
 for tool in ['jupyter','python-ide','powershell-ide']:
  name=page.evaluate('(id)=>ToolboxCatalog.tools.find(t=>t.id===id).name',tool)
  page.locator('#toolSearch').fill(name)
  assert page.locator('.tool-card:not([hidden])[data-tool="'+tool+'"]').count()==1
 page.locator('#toolSearch').fill('')
 paths=['index.html','assets/usage.js','assets/usage-config.json','assets/catalog.js','assets/design-system.css','assets/home-react/home.js','assets/home-react/home.css','assets/home-react/manifest.json','licenses/home-react/THIRD-PARTY-NOTICES.txt','tools/photo-editor/index.html','tools/photo-editor/dist/bundle.js','tools/creative/canvas.html','tools/creative/regex.html','tools/creative/pinyin.html','tools/markdown/index.html','tools/web-adb/index.html','tools/archives/index.html','tools/jupyter/index.html','tools/python-ide/index.html','tools/powershell-ide/index.html']
 for name in paths:
  response=page.request.get(BASE+'/'+name+'?release='+str((ROOT/'toolbox-site'/name).stat().st_mtime_ns))
  assert response.status==200,(name,response.status)
  assert hashlib.sha256(response.body()).digest()==hashlib.sha256((ROOT/'toolbox-site'/name).read_bytes()).digest(),name
 for width,height in [(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
  page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(150)
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(width,height)
 assert not errors,errors
 page.locator('#commentsOpen').click();page.wait_for_function("!document.querySelector('#commentsStatus').textContent.includes('加载')")
 assert not page.locator('#commentsStatus').inner_text(),page.locator('#commentsStatus').inner_text()
 assert page.get_by_role('dialog').is_visible()
 assert page.locator('#commentsOpen').get_attribute('aria-expanded')=='true'
 print(json.dumps({'base':BASE,'brand':True,'new_entries':10,'live_cloud_tools':len(expected),'live_cloud_status':live['status'],'deployed_files_match':len(paths),'responsive_viewports':5,'comments_live_read':True,'page_errors':errors}),flush=True);b.close()
