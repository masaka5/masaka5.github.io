"""Verify a production write/duplicate with real CORS. The test UUID is removed afterwards."""
import asyncio,json,uuid
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 event={'id':str(uuid.uuid4()),'tool':'pinyin'}
 async with async_playwright()as p:
  browser=await p.chromium.launch();page=await browser.new_page();await page.goto('https://tools.manshii.asia/')
  result=await page.evaluate("""async event=>{const base='https://pocket-toolbox-usage.pages.dev';const before=(await(await fetch(base+'/counts?check='+crypto.randomUUID())).json()).counts.pinyin;const posts=await Promise.all([1,2].map(()=>fetch(base+'/events',{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(event)}).then(async r=>({status:r.status,...await r.json()}))));const after=(await(await fetch(base+'/counts?check='+crypto.randomUUID())).json()).counts.pinyin;return{before,posts,after};}""",event)
  assert all(r['status']==200 and r['accepted']for r in result['posts']),result
  assert result['after']==result['before']+1,result
  Path('_scratch/usage-e2e-event.json').write_text(json.dumps(event),encoding='utf8')
  print(json.dumps({'production_CORS_write':True,'duplicate_counted_once':True,'event_id':event['id'],'before':result['before'],'after':result['after']}));await browser.close()
asyncio.run(main())
