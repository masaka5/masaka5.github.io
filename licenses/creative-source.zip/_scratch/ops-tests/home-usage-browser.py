import asyncio,json,os,sys
from pathlib import Path
from playwright.async_api import async_playwright
sys.stdout.reconfigure(encoding='utf8')
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch();page=await browser.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  state={'counts':{},'events':[],'ids':set(),'fail':False}
  async def api(route):
   if state['fail']:await route.abort();return
   if route.request.method=='POST':
    e=json.loads(route.request.post_data);state['events'].append(e)
    if e['id']not in state['ids']:state['counts'][e['tool']]+=1;state['ids'].add(e['id'])
    await route.fulfill(json={'accepted':True,'count':state['counts'][e['tool']]})
   else:await route.fulfill(json={'schema':1,'updatedAt':'2026-11-12T00:00:00Z','counts':state['counts']})
  await page.route('**/assets/usage-config.json',lambda r:r.fulfill(json={'endpoint':'https://usage.test','snapshotURL':'https://snapshot.test/counts.json'}))
  await page.route('https://usage.test/**',api)
  await page.route('https://snapshot.test/**',lambda r:r.fulfill(json={'schema':1,'updatedAt':'2026-11-12T00:00:00Z','counts':state['counts']}))
  # Initialize before the normal deferred scripts read the cached snapshot.
  await page.goto(BASE+'/');ids=await page.evaluate('ToolboxCatalog.tools.map(t=>t.id)');state['counts']={id:0 for id in ids};state['counts']['pinyin']=9;state['counts']['whiteboard']=7;state['counts']['regex-tester']=4
  await page.reload();await page.wait_for_function("document.querySelector('.tool-card:not([hidden])').dataset.tool==='pinyin'")
  assert await page.locator('.brand').inner_text()=='口袋工具箱'
  assert '打开 9 次' in await page.locator('[data-tool=pinyin] .tool-usage').inner_text()
  await page.locator('[data-tool=pinyin] .favorite-toggle').click();assert len(state['events'])==0
  assert await page.locator('[data-tool=pinyin] .favorite-toggle').evaluate('(e)=>document.activeElement===e')
  await page.locator('[data-tool=pinyin] .tool-link').focus();await page.keyboard.press('Enter');await page.wait_for_url('**/pinyin.html');await page.wait_for_timeout(200)
  assert state['counts']['pinyin']==10 and len(state['events'])==1
  await page.go_back();await page.wait_for_function("document.querySelector('[data-tool=pinyin] .tool-usage').textContent.includes('10')")
  await page.locator('[data-tool=whiteboard] .tool-link').click(button='middle')
  await page.wait_for_timeout(250);assert state['counts']['whiteboard']==8
  await page.get_by_role('button',name='常用').first.click();assert await page.locator('.tool-card:not([hidden])').count()==1
  await page.get_by_role('button',name='全部工具').first.click();await page.locator('#toolSearch').fill('正则可视化');assert await page.locator('.tool-card:not([hidden])').count()==1
  state['fail']=True;await page.reload();await page.wait_for_function("document.querySelector('[data-tool=pinyin] .tool-usage').textContent.includes('10')")
  for w,h in [(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(200)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h)
   for b in await page.locator('.tool-card:not([hidden])').all():
    assert await b.locator('.tool-usage').is_visible()
  assert not errors,errors;await page.screenshot(path='_scratch/home-usage.png');await browser.close()
  print(json.dumps({'stable_ranking':True,'confirmed_counts':True,'keyboard_and_middle_click':True,'favorite_not_counted':True,'search_category':True,'cached_offline_fallback':True,'viewports':5,'errors':errors}))
asyncio.run(main())
