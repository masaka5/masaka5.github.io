"""Read actual cloud counts from a browser with the production site's origin."""
import asyncio,json
from playwright.async_api import async_playwright
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto('https://tools.manshii.asia/')
  out=await page.evaluate("""async()=>{const response=await fetch('https://pocket-toolbox-usage.pages.dev/counts',{credentials:'omit'});const data=await response.json();const comments=await fetch('https://pocket-toolbox-usage.pages.dev/comments',{credentials:'omit'});const thread=await comments.json();return {status:response.status,schema:data.schema,tools:Object.keys(data.counts||{}).length,total:Object.values(data.counts||{}).reduce((a,b)=>a+b,0),comments_status:comments.status,comments_schema:thread.schema};}""")
  assert out['status']==200 and out['schema']==1 and out['tools']>=1109,out
  assert out['comments_status']==200 and out['comments_schema']==1,out
  print(json.dumps(out));await b.close()
asyncio.run(main())
