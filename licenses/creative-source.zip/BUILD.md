# 口袋工具箱：画布、正则、拼音与统计

Node.js 22+。部署包提供第三方字体、Wasm 等运行资源。

```sh
cd _scratch/creative-integration
npm ci --no-audit --no-fund
npm test
npm run build
```

构建后站点 tools/creative/ 可直接由静态 HTTPS 服务提供。Excalidraw 0.18.1、regexpp 4.12.3、pinyin-pro 3.29.5 均保留 MIT 许可；各依赖许可见 licenses/creative/。本项目没有复制菜鸟网站的非开源页面代码，只参考其功能。

统计服务部署步骤和隐私边界见 toolbox-cloud/README.md。Worker 及 Pages 入口从同一 src/worker.js 编译，绑定同一个 D1；Pages secrets 不写入构建文件。源码包没有实际凭据。
