# 办公编辑器源码

纯静态本地处理。Node 22+ / npm / Python 3。

1. 在 `_scratch/office-integration` 中运行 `npm ci`、`npm run build`，输出 `toolbox-site/tools/office-editors`。
2. 在 `_scratch/web-ppt-build` 中运行 `npm ci`、`npm run build`，输出 `toolbox-site/tools/web-ppt`。基于 duchao-duchao/web-ppt 6d07815384197d7e7409b5af9743db6ea39bc29a，保留 MIT。
3. 将 drawio-source.zip 的 drawio-upstream 解压至 `_scratch/drawio-upstream`，运行 `python _scratch/stage-drawio-runtime.py`；shell 源码在本包 tools/drawio 中，原始 Apache-2.0 与组件许可保留。

版本锁与依赖许可见 package-lock.json、licenses/office/dependencies.json；Tiptap 3.33.1 MIT，Univer 开源 presets 1.4.0 Apache-2.0。表格支持 XLSX/CSV/JSON；两个文档入口支持标准 DOCX/JSON，Tiptap 另有 HTML。ExcelJS 4.4.0、Mammoth 1.13.0、docx 9.15.3 均为本地浏览器转换，不依赖商业 Office 转换服务。输入20MiB、ZIP展开100MiB、20万已用单元格、文档5MiB文字；保留常用内容与格式，复杂分页、批注、修订、宏和旧DOC/XLS不在本轮兼容范围。测试office-files.py需 openpyxl==3.1.5、python-docx==1.2.0，安装至_scratch/qa-office，浏览器测试需Playwright。Web-PPT 导出静态 PPTX。draw.io XML 保留多页，SVG/PNG 导出当前页。IndexedDB 草稿仅在当前浏览器，清理站点数据会删除草稿。
