# 办公编辑器源码

纯静态本地处理。Node 22+ / npm / Python 3。

1. 在 `_scratch/office-integration` 中运行 `npm ci`、`npm run build`，输出 `toolbox-site/tools/office-editors`。
2. 在 `_scratch/web-ppt-build` 中运行 `npm ci`、`npm run build`，输出 `toolbox-site/tools/web-ppt`。基于 duchao-duchao/web-ppt 6d07815384197d7e7409b5af9743db6ea39bc29a，保留 MIT。
3. 将 drawio-source.zip 的 drawio-upstream 解压至 `_scratch/drawio-upstream`，运行 `python _scratch/stage-drawio-runtime.py`；shell 源码在本包 tools/drawio 中，原始 Apache-2.0 与组件许可保留。

版本锁与依赖许可见 package-lock.json、licenses/office/dependencies.json；Tiptap 3.33.1 MIT，Univer 开源 presets 1.4.0 Apache-2.0。Univer 项目 JSON 和 CSV 为当前支持的导入导出格式，未集成商业 Office 二进制转换服务。Web-PPT 导出静态 PPTX。draw.io XML 保留多页，SVG/PNG 导出当前页。IndexedDB 草稿仅在当前浏览器，清理站点数据会删除草稿。
