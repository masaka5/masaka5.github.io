# Office Files Implementation Plan

> 执行方式：本轮 inline execution，沿用已有部署授权。

**Goal:** 现有表格导入导出 XLSX、两个文档入口导入导出 DOCX。

**Architecture:** 按需加载本地转换模块，统一 ZIP 校验，成功转换后调用现有事务式替换。使用现有 IndexedDB 保存模型，不持久化转换过程。

**Tech Stack:** ExcelJS 4.4.0, Mammoth 1.13.0, docx 9.15.3, Univer 1.4.0, Tiptap 3.33.1, Vite。

## 约束

纯静态、本地文件、中文；20MiB输入/100MiB展开；损坏导入保留当前内容；不改变分类、图标及无外层滚动布局。

### 1. 真实文件 RED 测试

- [ ] `_scratch/ops-tests/office-files.py` 用 openpyxl/python-docx 生成中文多工作表、公式、合并、样式及含表格图片的文档。
- [ ] 针对现有网页查找 `#exportOffice` / `#exportDOCX` 并导入文件，确认因缺少控件而失败。

### 2. 转换器

- [ ] `office-zip.js` ZIP目录与解压边界校验。
- [ ] `xlsx-bridge.js`: `readXlsx(file)` 返回 Univer sheet data；`writeXlsx(snapshot)` 返回真实 XLSX Blob，映射多工作表、样式和公式。
- [ ] `word-bridge.js`: `readDocx(file)` 返回安全HTML；`writeDocx(html,title)` 返回 DOCX Blob；使用 DOM 树转换 docx 段落、表格、列表和图片。
- [ ] `univer-word.js` 使用原生 HTML→UDM；UDM→HTML 保留文字样式、表格和内嵌图片。
- [ ] 安装固定版本、构建并运行单元/浏览器验证。

### 3. 接入现有界面

- [ ] `office.js` / `office.html` “打开”接受 XLSX、DOCX、JSON，“导出 Excel/Word”按模式变化。通过现有串行 exclusive / switchMode 接入。
- [ ] `document.js` / `document.html` “打开”接受 DOCX，新增“导出 Word”，成功转换后应用，保持失败原稿。标题输入样式统一。
- [ ] 运行真实输入与独立输出检查、损坏输入恢复、中文图片表格验证，执行现有三套办公回归和五种视口检查。

### 4. 打包与部署

- [ ] 更新源码/许可/来源、清理由本次构建替代的哈希资产，保持无关文件。
- [ ] 运行 release-check，限定路径 staging，推送 main。
- [ ] 确认 Pages成功，HTTPS运行新格式测试和核心回归；报告格式兼容边界。
