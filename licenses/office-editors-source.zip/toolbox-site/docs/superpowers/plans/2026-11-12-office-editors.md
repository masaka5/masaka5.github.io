# 办公编辑器集成计划

使用subagent-driven-development逐项实现并审查。原工作区脏文件不提交，部署使用既有独立检出，根任务统一更新目录/归档/发布。

1. Web-PPT：读_scratch/office-web-ppt-brief.md；改造固定上游构建至tools/web-ppt，自包含、中文、统一主题、本地草稿/JSON/PPTX/预览测试；只操作专属目录。
2. draw.io：本地静态精简运行资源至tools/drawio，固定版本源码和构建脚本、中文嵌入、图表模板/思维导图、保存/导入/导出与草稿测试；独立资源预算检查。
3. Tiptap与Univer：独立Vite构建目录_scratch/office-integration，两个入口tools/document和tools/office，中文主题、本地快照/导入导出、真实编辑回归测试。库使用开源功能，无虚构Office文件转换。
4. 每项独立只读审查，修复关键发现；根任务目录图标、许可证/源码归档、manifest、链接/资源/大小检查，最终整体审查；已授权main发布并等Pages成功，HTTPS正式站真实编辑验收。
