# draw.io integration report

Status: DONE. Tool lives exclusively in `toolbox-site/tools/drawio/`.

Pinned upstream https://github.com/jgraph/drawio at
`c72c9a98b7a6ce392556ed04c05e0ff19f43f5c3`, version 32.6.10,
Apache-2.0. Local `SOURCE.md` records provenance; upstream LICENSE and component
licenses are included as `.txt`. Upstream checkout stays unmodified.

Real upstream prebuilt draw.io/mxGraph engine runs in a same-origin local iframe.
Chinese native menus/palettes, local editing/arrange/view, original shapes and
stencils, default editable mindmap, blank diagram, XML import/export, SVG export,
client SVG-to-Canvas PNG export and IndexedDB draft recovery are implemented.
Host is white/gray/blue with 工具箱 return link. Native file/help/cloud/account
menus are omitted; offline/stealth mode and iframe CSP prevent remote requests.
Native document drops and Ctrl+O route to the host importer.

Importer limits files to 10 MiB, rejects malformed XML/DOCTYPE/entities, limits
plain mxCell count, and checks compressed diagram expansion using streaming
DecompressionStream with a 10 MiB expansion limit. Invalid import retains model
and last good draft. Native rich content relies on upstream sanitization.

Reproduce: checkout pinned upstream with `src/main/webapp` sparse path, then
`python _scratch/stage-drawio-runtime.py`. This copies prebuilt runtime, retaining
all shapes/stencils/templates and MathJax; excludes server files, cloud integration
bundle, viewer bundles, source maps, development editor sources and unused locales.
Source archive is root agent's responsibility, using pinned upstream checkout.

Runtime measurement: 2,842 files; **54,526,213 bytes** (52.00 MiB).
Largest file `vendor/js/app.min.js`: 10,827,765 bytes.
Runtime suffixes: .css .gif .html .ico .js .json .md .png .svg .ttf .txt .xml.
**Packaging must add `.xml` and `.ico`** (not present in inspected shared whitelist).

Verification: `python _scratch/ops-tests/drawio-browser.py` against
http://127.0.0.1:8765 (supports TOOLBOX_TEST_BASE).
RED before implementation: AssertionError Missing Chinese draw.io tool.
Additional RED exposed native graph disabled before embed initialization; fixed
through the native load lifecycle and asserted enabled state.
GREEN final: real browser contenteditable Chinese branch edit, mxGraph vertex,
default mindmap, XML download/import, invalid import keeps model, reload restores
IndexedDB draft, downloaded SVG contains Chinese and PNG has valid signature,
native Chinese edit menu opens, 1440/1024/768/390/320 viewports have no outer overflow,
zero pageerror and local404. Mobile screenshot `_scratch/ops-tests/drawio-mobile.png`.

Independent review follow-up: semantic XML such as
`<mxGraphModel><nonsense/></mxGraphModel>` initially cleared the draft. Added RED
regression, then semantic graph validation requiring one root, unique cell IDs,
one model base and layer, valid parent/source/target references, and no parent
cycles. The same checks apply after bounded compressed-page expansion. GREEN
regressions reject both plain and compressed semantic-invalid input and prove
the good draft survives another reload.

Limits: cloud services and server-only PDF/export deliberately unavailable. Native
diagram canvas scrolls internally on mobile; sidebar collapses and native toggle
remains available. SVG/PNG export targets currently visible page; XML retains
whole multipage document. External images/fonts are blocked by CSP and can prevent
PNG export; error is shown. Native shape library proper names remain upstream.
