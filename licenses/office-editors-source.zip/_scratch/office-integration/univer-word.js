import {convertClipboardHtmlToDocumentData} from '@univerjs/docs-ui';
import {safeWordHTML} from './word-bridge.js';
export function htmlToUniver(html,title){
 const source=new DOMParser().parseFromString(safeWordHTML(html),'text/html'),marker='\uE001';
 for(const br of source.querySelectorAll('br'))br.replaceWith(source.createTextNode(marker));
 for(const li of [...source.querySelectorAll('li')].reverse()){let group=[];const flush=()=>{if(group.length){const p=source.createElement('p');group[0].before(p);p.append(...group);group=[];}};for(const node of [...li.childNodes]){if(node.nodeType===1&&/^(P|DIV|OL|UL|H[1-6])$/.test(node.tagName))flush();else group.push(node);}flush();}
 const id='word-'+crypto.randomUUID(),data=convertClipboardHtmlToDocumentData(source.body.innerHTML,id);
 // The generic clipboard converter omits paragraph alignment and BR boundaries.
 const alignments=new Map();for(const el of source.querySelectorAll('p,h1,h2,h3,h4,h5,h6')){const key=el.textContent.replace(/\s+/g,' ').trim();const queue=alignments.get(key)||[];queue.push(['','left','center','right','justify'].indexOf(el.style.textAlign));alignments.set(key,queue);}
 let start=0;for(const p of data.body.paragraphs||[]){const key=data.body.dataStream.slice(start,p.startIndex).replace(/[\x00-\x1f]/g,'').replace(/\s+/g,' ').trim(),align=alignments.get(key)?.shift();if(align>0)p.paragraphStyle={...p.paragraphStyle,horizontalAlign:align};start=p.startIndex+1;}
 const original=[...(data.body.paragraphs||[])];for(let i=0;i<data.body.dataStream.length;i++)if(data.body.dataStream[i]===marker){const next=original.find(p=>p.startIndex>i);data.body.paragraphs.push({...next,startIndex:i,paragraphId:crypto.randomUUID()});}data.body.dataStream=data.body.dataStream.replaceAll(marker,'\r');data.body.paragraphs.sort((a,b)=>a.startIndex-b.startIndex);
 data.id=id;data.title=title;data.locale='zhCN';data.documentStyle={...data.documentStyle,pageSize:{width:794,height:1123},marginTop:50,marginBottom:50,marginLeft:60,marginRight:60};
 data.drawingsOrder=Object.keys(data.drawings||{});return data;
}
export function univerToHTML(data){
 const body=data.body||{},text=body.dataStream||'',doc=document.implementation.createHTMLDocument(''),root=doc.body;
 const paragraphs=new Map((body.paragraphs||[]).map(p=>[p.startIndex,p])),blocks=new Map((body.customBlocks||[]).map(b=>[b.startIndex,b]));
 const ranges=body.textRuns||[],links=body.customRanges||[];let pos=0;const listStacks=new WeakMap();
 function inline(parent,start,end){
  for(let i=start;i<end;){const block=blocks.get(i);if(block){const drawing=data.drawings?.[block.blockId];if(drawing?.source){const img=doc.createElement('img');img.src=drawing.source;img.width=drawing.docTransform?.size?.width||drawing.transform?.width||100;img.height=drawing.docTransform?.size?.height||drawing.transform?.height||100;parent.append(img);}i++;continue;}
   if(/[\x00-\x08\x0b-\x1f]/.test(text[i])&&text[i]!=='\t'){i++;continue;}
   const run=ranges.find(r=>r.st<=i&&r.ed>i),link=links.find(r=>r.rangeType===0&&r.startIndex<=i&&r.endIndex>=i),style=run?.ts||{};let endRun=i+1;
   while(endRun<end&&!blocks.has(endRun)&&!/[\x00-\x1f]/.test(text[endRun])&&ranges.find(r=>r.st<=endRun&&r.ed>endRun)===run&&links.find(r=>r.rangeType===0&&r.startIndex<=endRun&&r.endIndex>=endRun)===link)endRun++;
   const span=doc.createElement('span');span.textContent=text.slice(i,endRun);if(style.bl)span.style.fontWeight='bold';if(style.it)span.style.fontStyle='italic';if(style.ul?.s)span.style.textDecoration='underline';if(style.st?.s)span.style.textDecoration+=' line-through';if(style.ff)span.style.fontFamily=style.ff;if(style.fs)span.style.fontSize=style.fs+'pt';if(style.cl?.rgb)span.style.color=style.cl.rgb;
   if(link?.properties?.url){const a=doc.createElement('a');a.href=link.properties.url;a.append(span);parent.append(a);}else parent.append(span);i=endRun;
  }
 }
 function paragraph(parent,start,end){const meta=paragraphs.get(end)||{},named=meta.paragraphStyle?.namedStyleType,level=Number(named)-3,el=doc.createElement(level>=1&&level<=6?'h'+level:'p');inline(el,start,end);const align=['','left','center','right','justify'][meta.paragraphStyle?.horizontalAlign];if(align)el.style.textAlign=align;
  if(meta.bullet){const ordered=/ORDER|NUMBER|DECIMAL/i.test(meta.bullet.listType||''),tag=ordered?'ol':'ul',level=Math.min(8,Math.max(0,meta.bullet.nestingLevel||0));let stack=listStacks.get(parent)||[];stack.length=Math.min(stack.length,level+1);for(let n=0;n<=level;n++){if(stack[n]?.tagName.toLowerCase()!==tag&&n===level)stack.length=n;if(!stack[n]){const list=doc.createElement(tag),host=n?(stack[n-1].lastElementChild||stack[n-1].appendChild(doc.createElement('li'))):parent;host.append(list);stack[n]=list;}}const li=doc.createElement('li');li.append(el);stack[level].append(li);listStacks.set(parent,stack);}else{listStacks.delete(parent);parent.append(el);}
 }
 function content(parent,stop){let start=pos;while(pos<text.length){const c=text[pos];if(stop?.includes(c)){if(pos>start)paragraph(parent,start,pos);return;}
   if(c==='\x1a'){if(pos>start)paragraph(parent,start,pos);table(parent);start=pos;continue;}
   if(c==='\r'){paragraph(parent,start,pos);pos++;if(text[pos]==='\n')pos++;start=pos;continue;}
   if(c==='\n'){pos++;start=pos;continue;}pos++;
  }if(pos>start)paragraph(parent,start,pos);
 }
 function table(parent){const range=(body.tables||[]).find(t=>t.startIndex===pos),model=data.tableSource?.[range?.tableId],el=doc.createElement('table');parent.append(el);pos++;let r=0;
  while(pos<text.length&&text[pos]!=='\x0f'){if(text[pos]!=='\x1b'){pos++;continue;}pos++;const row=doc.createElement('tr');el.append(row);let col=0;
   while(pos<text.length&&!['\x0e','\x0f'].includes(text[pos])){if(text[pos]!=='\x1c'){pos++;continue;}pos++;const cell=doc.createElement('td'),meta=model?.tableRows?.[r]?.tableCells?.[col++];content(cell,['\x1d']);if(text[pos]==='\x1d')pos++;if(meta?.rowSpan===0||meta?.columnSpan===0)continue;if(meta?.rowSpan>1)cell.rowSpan=meta.rowSpan;if(meta?.columnSpan>1)cell.colSpan=meta.columnSpan;row.append(cell);}
   if(text[pos]==='\x0e')pos++;r++;
  }if(text[pos]==='\x0f')pos++;
 }
 content(root);return safeWordHTML(root.innerHTML);
}
