import {Editor} from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import {TableKit} from '@tiptap/extension-table';
import Image from '@tiptap/extension-image';
import TextAlign from '@tiptap/extension-text-align';
import DOMPurify from 'dompurify';
import {$,status,download,readDraft,textFile,safeName,draftSaver} from './shared.js';
import './editor.css';
const KEY='tiptap-v1';
const embedded=src=>/^data:image\/(png|jpeg|webp|gif);base64,/.test(src||'');
const clean=html=>{const safe=DOMPurify.sanitize(html,{ADD_TAGS:['table','thead','tbody','tr','td','th'],FORBID_TAGS:['script','iframe','object','embed','style']});const probe=new DOMParser().parseFromString(safe,'text/html');for(const el of probe.querySelectorAll('[style]')){const align=el.style.textAlign;el.removeAttribute('style');if(['left','center','right','justify'].includes(align)&&/^(P|H[1-6])$/.test(el.tagName))el.style.textAlign=align;}for(const img of probe.images)if(!embedded(img.getAttribute('src')))img.remove();return probe.body.innerHTML;};
const LocalImage=Image.extend({parseHTML(){return [{tag:'img[src]',getAttrs:element=>embedded(element.getAttribute('src'))?null:false}];},addInputRules(){return [];}});
let editor,saver;
const snapshot=()=>({version:1,kind:'tiptap',title:$('title').value,content:editor.getJSON()});
function validate(data){
 if(!data||data.version!==1||data.kind!=='tiptap'||typeof data.title!=='string'||data.title.length>100||data.content?.type!=='doc')throw Error('文档格式无效');
 const candidate=editor.schema.nodeFromJSON(data.content);candidate.check();
 let count=0;candidate.descendants(node=>{if(++count>50000)throw Error('文档节点过多');if(node.type.name==='image'&&!/^data:image\/(png|jpeg|webp|gif);base64,/.test(node.attrs.src||''))throw Error('图片须为本地嵌入格式');});
 return data;
}
function render(){for(const [id,type]of [['docBold','bold'],['docItalic','italic'],['docUnderline','underline']])$(id).setAttribute('aria-pressed',String(editor.isActive(type)));$('undo').disabled=!editor.can().undo();$('redo').disabled=!editor.can().redo();}
try{
 editor=new Editor({element:$('editor'),extensions:[StarterKit.configure({link:{openOnClick:false,protocols:['https','http','mailto']}}),TableKit,LocalImage.configure({allowBase64:true}),TextAlign.configure({types:['heading','paragraph']})],editorProps:{transformPastedHTML:clean},content:'<p></p>',onUpdate:()=>{saver?.schedule();render();},onSelectionUpdate:render});
 window.documentEditor=editor;saver=draftSaver(KEY,snapshot);
 let draft;try{draft=await readDraft(KEY);if(draft){validate(draft);editor.commands.setContent(draft.content,{emitUpdate:false});$('title').value=draft.title;status('已恢复草稿');}else status('本地文档');}catch{status('草稿无法恢复，请导入备份',true);}
 const command=(id,fn)=>$(id).onclick=()=>{try{fn(editor.chain().focus()).run();render();}catch(e){status(e.message,true);}};
 for(const [id,fn]of [['docBold','toggleBold'],['docItalic','toggleItalic'],['docUnderline','toggleUnderline'],['bulletList','toggleBulletList'],['orderedList','toggleOrderedList'],['quote','toggleBlockquote'],['codeBlock','toggleCodeBlock'],['undo','undo'],['redo','redo'],['row','addRowAfter'],['column','addColumnAfter'],['removeTable','deleteTable']])command(id,c=>c[fn]());
 for(const [id,align]of [['alignLeft','left'],['alignCenter','center'],['alignRight','right']])command(id,c=>c.setTextAlign(align));
 $('heading').onchange=()=>{const level=Number($('heading').value);level?editor.chain().focus().toggleHeading({level}).run():editor.chain().focus().setParagraph().run();};
 command('table',c=>c.insertTable({rows:3,cols:3,withHeaderRow:true}));
 $('link').onclick=()=>{const value=prompt('链接地址',editor.getAttributes('link').href||'https://');if(value===null)return;if(!value){editor.chain().focus().unsetLink().run();return;}try{const url=new URL(value);if(!['https:','http:','mailto:'].includes(url.protocol))throw Error();editor.chain().focus().setLink({href:url.href}).run();}catch{status('请输入有效的 HTTPS、HTTP 或邮件链接',true);}};
 $('image').onclick=()=>$('imageFile').click();$('imageFile').onchange=async()=>{const file=$('imageFile').files[0];$('imageFile').value='';if(!file)return;try{if(!['image/png','image/jpeg','image/webp','image/gif'].includes(file.type)||file.size>8*1024**2)throw Error('请选择8 MiB以内的图片');const src=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});editor.chain().focus().setImage({src,alt:file.name}).run();}catch(e){status(e.message||'无法读取图片',true);}};
 $('title').oninput=()=>saver.schedule();$('importButton').onclick=()=>$('importFile').click();
 $('importFile').onchange=async()=>{const file=$('importFile').files[0];$('importFile').value='';if(!file)return;try{const text=await textFile(file);if(/\.html?$/i.test(file.name)){const html=clean(text);const probe=new DOMParser().parseFromString(html,'text/html');for(const img of probe.images)if(!/^data:image\/(png|jpeg|webp|gif);base64,/.test(img.src))img.remove();editor.commands.setContent(probe.body.innerHTML,{errorOnInvalidContent:true});}else{const data=validate(JSON.parse(text));editor.commands.setContent(data.content,{errorOnInvalidContent:true});$('title').value=data.title;}await saver.flush();status('已导入');}catch(e){status(e.message||'文档无法打开',true);}};
 $('exportJSON').onclick=()=>download(JSON.stringify(snapshot(),null,2),safeName($('title').value)+'.json');
 $('exportHTML').onclick=()=>download('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><body>'+clean(editor.getHTML())+'</body></html>',safeName($('title').value)+'.html','text/html');render();
}catch(e){status(e.message||'编辑器加载失败',true);}
