import {createUniver,LocaleType,mergeLocales,defaultTheme} from '@univerjs/presets';
import {UniverSheetsCorePreset} from '@univerjs/preset-sheets-core';
import sheetsZh from '@univerjs/preset-sheets-core/locales/zh-CN';
import {UniverDocsCorePreset} from '@univerjs/preset-docs-core';
import docsZh from '@univerjs/preset-docs-core/locales/zh-CN';
import '@univerjs/preset-sheets-core/lib/index.css';
import '@univerjs/preset-docs-core/lib/index.css';
import {$,status,download,readDraft,textFile,draftSaver} from './shared.js';
import './editor.css';
const app=window.officeApp={mode:'sheet',unit:undefined,api:null,univer:null};let saver,switching=false;
const theme={...defaultTheme,primary:{50:'#f0f5ff',100:'#e0eaff',200:'#bdd0ff',300:'#94aff3',400:'#6389e4',500:'#315dcb',600:'#294fb3',700:'#244395',800:'#223978',900:'#203261'}};
function snapshot(){return {version:1,kind:'univer',mode:app.mode,data:app.unit.save()};}
function validateBodies(value,depth=0){
 if(depth>40)throw Error('项目结构过深');if(!value||typeof value!=='object')return;
 if(Object.hasOwn(value,'dataStream')){
  if(typeof value.dataStream!=='string'||!value.dataStream.endsWith('\r\n')||value.dataStream.length>5*1024**2)throw Error('文档内容无效');
  const limit=value.dataStream.length;
  for(const key of ['renderedPageBreaks','textRuns','paragraphs','sectionBreaks','customBlocks','docxRawCustomBlocks','docxRawBlocks','docxExportExcludedRanges','tables','columnGroups','blockRanges','customRanges','customDecorations']){
   if(value[key]==null)continue;if(!Array.isArray(value[key])||value[key].length>100000)throw Error('文档段落结构无效');
   for(const item of value[key]){if(key==='renderedPageBreaks'){if(!Number.isInteger(item)||item<0||item>=limit)throw Error('分页位置无效');continue;}if(!item||typeof item!=='object'||Array.isArray(item))throw Error('文档段落数据无效');
    for(const index of ['st','ed','startIndex','endIndex'])if(Object.hasOwn(item,index)&&(!Number.isInteger(item[index])||item[index]<0||item[index]>limit))throw Error('文档位置无效');
    if(key==='textRuns'&&(!Number.isInteger(item.st)||!Number.isInteger(item.ed)||item.ed<item.st))throw Error('文字范围无效');
    if(['paragraphs','sectionBreaks'].includes(key)&&!Number.isInteger(item.startIndex))throw Error('段落位置无效');
   }
  }
 }
 for(const [key,child]of Object.entries(value)){if(['__proto__','constructor','prototype'].includes(key))throw Error('项目属性无效');validateBodies(child,depth+1);}
}
function validate(project){
 if(project?.version!==1||project.kind!=='univer'||!['sheet','doc'].includes(project.mode)||!project.data||typeof project.data!=='object')throw Error('项目格式无效');
 const d=project.data;validateBodies(d);if(project.mode==='sheet'){
  if(!Array.isArray(d.sheetOrder)||!d.sheetOrder.length||d.sheetOrder.length>100||!d.sheets)throw Error('表格结构无效');
  if(new Set(d.sheetOrder).size!==d.sheetOrder.length||d.sheetOrder.some(id=>typeof id!=='string'||!id||['__proto__','constructor','prototype'].includes(id)))throw Error('工作表标识无效');
  let count=0;for(const id of d.sheetOrder){const s=d.sheets[id];if(!s||!Number.isInteger(s.rowCount)||!Number.isInteger(s.columnCount)||s.rowCount<1||s.rowCount>100000||s.columnCount<1||s.columnCount>2000)throw Error('表格大小无效');for(const [row,cells]of Object.entries(s.cellData||{})){if(!/^\d+$/.test(row)||Number(row)>=s.rowCount||!cells||typeof cells!=='object')throw Error('单元格结构无效');for(const [col,cell]of Object.entries(cells)){if(++count>200000||!/^\d+$/.test(col)||Number(col)>=s.columnCount||!cell||typeof cell!=='object'||Array.isArray(cell))throw Error('单元格数据无效');if(cell.v!=null&&!['string','number','boolean'].includes(typeof cell.v)||cell.f!=null&&typeof cell.f!=='string'||cell.p!=null&&(typeof cell.p?.body?.dataStream!=='string'||!cell.p.body.dataStream.endsWith('\r\n')))throw Error('单元格内容无效');}}
  }
 }else if(typeof d.body?.dataStream!=='string'||!d.body.dataStream.endsWith('\r\n')||d.body.dataStream.length>5*1024**2)throw Error('文档内容无效');
 return project;
}
function empty(mode){return mode==='sheet'?{id:'toolbox-sheet',name:'未命名表格',locale:LocaleType.ZH_CN,sheetOrder:['sheet1'],sheets:{sheet1:{id:'sheet1',name:'工作表1',rowCount:1000,columnCount:26,cellData:{}}}}:{id:'toolbox-doc',title:'未命名文档',body:{dataStream:'\r\n',paragraphs:[{startIndex:0}],sectionBreaks:[{startIndex:1}]},documentStyle:{pageSize:{width:794,height:1123},marginTop:50,marginBottom:50,marginLeft:60,marginRight:60}};}
async function mount(mode,data){
 switching=true;saver?.dispose();app.unit=undefined;app.univer?.dispose();$('univer').replaceChildren();
 const preset=mode==='sheet'?UniverSheetsCorePreset:UniverDocsCorePreset;
 const {univer,univerAPI}=createUniver({locale:LocaleType.ZH_CN,locales:{[LocaleType.ZH_CN]:mergeLocales(sheetsZh,docsZh)},theme,presets:[preset({container:'univer',header:true,toolbar:true})]});
 app.univer=univer;app.api=univerAPI;app.mode=mode;app.unit=mode==='sheet'?univerAPI.createWorkbook(data||empty(mode)):univerAPI.createDocument(data||empty(mode));
 saver=draftSaver('univer-'+mode,()=>snapshot());status('本地项目');
 $('officeMode').value=mode;$('exportCSV').hidden=$('importCSV').hidden=mode!=='sheet';
 univerAPI.addEvent(univerAPI.Event.CommandExecuted,()=>{if(!switching)saver?.schedule();});
 switching=false;
}
try{
 let mode='sheet';try{mode=localStorage.getItem('toolbox-univer-mode')==='doc'?'doc':'sheet';}catch{}
 let draft,recoveryError;try{draft=await readDraft('univer-'+mode);if(draft)validate(draft);}catch{draft=null;recoveryError=true;}
 try{await mount(mode,draft?.data);}catch(e){if(!draft)throw e;draft=null;recoveryError=true;await mount(mode);}
 status(recoveryError?'草稿无法恢复，请导入备份':draft?'已恢复草稿':'本地项目',!!recoveryError);
 let operation=Promise.resolve();
 const exclusive=fn=>{operation=operation.catch(()=>{}).then(async()=>{for(const id of ['officeMode','newProject','importButton','importCSV'])$(id).disabled=true;try{await fn();}catch(e){status(e.message||'项目无法打开',true);}finally{for(const id of ['officeMode','newProject','importButton','importCSV'])$(id).disabled=false;$('officeMode').value=app.mode;}});return operation;};
 async function switchMode(mode,data){const previous=structuredClone(snapshot());await saver.flush();try{await mount(mode,data);}catch(e){await mount(previous.mode,previous.data);throw Error('项目无法打开，已保留当前内容');}try{localStorage.setItem('toolbox-univer-mode',mode);}catch{}}
 $('officeMode').onchange=()=>{const mode=$('officeMode').value;return exclusive(async()=>{let draft;try{draft=await readDraft('univer-'+mode);if(draft)validate(draft);}catch{throw Error('草稿无法恢复，请先导出当前项目');}await switchMode(mode,draft?.data);status(draft?'已恢复草稿':'本地项目');});};
 $('newProject').onclick=()=>exclusive(async()=>{if(!confirm('新建空白项目？当前内容请先保存项目。'))return;await switchMode(app.mode);await saver.flush();});
 $('importButton').onclick=()=>$('importFile').click();$('importFile').onchange=()=>{const file=$('importFile').files[0];$('importFile').value='';if(!file)return;return exclusive(async()=>{const project=validate(JSON.parse(await textFile(file)));await switchMode(project.mode,project.data);await saver.flush();status('已导入');});};
 $('exportProject').onclick=()=>download(JSON.stringify(snapshot(),null,2),(app.mode==='sheet'?'表格':'文档')+'.univer.json');
 $('exportCSV').onclick=()=>{try{const s=app.unit.getActiveSheet(),d=s.getSheet().getSnapshot?.()||app.unit.save().sheets[s.getSheetId()],cells=d.cellData||{};let maxRow=0,maxCol=0;for(const [row,cols]of Object.entries(cells))for(const [col,c]of Object.entries(cols))if(c.v!==undefined||c.f||c.p){maxRow=Math.max(maxRow,Number(row));maxCol=Math.max(maxCol,Number(col));}if((maxRow+1)*(maxCol+1)>1000000)throw Error('CSV区域超过100万单元格');const values=s.getRange(0,0,maxRow+1,maxCol+1).getDisplayValues(),csv=values.map(row=>row.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\r\n');download('\ufeff'+csv,'工作表.csv','text/csv;charset=utf-8');}catch(e){status(e.message,true);}};
 $('importCSV').onclick=()=>$('csvFile').click();$('csvFile').onchange=()=>{const file=$('csvFile').files[0];$('csvFile').value='';if(!file)return;return exclusive(async()=>{if(app.mode!=='sheet')throw Error('请先切换到表格');const {parseCSV}=await import('./office-validation.js');const values=parseCSV(await textFile(file));if(!confirm('将 CSV 导入当前表格 A1 开始的区域？'))return;const sheet=app.unit.getActiveSheet();if(values.length>sheet.getMaxRows())sheet.insertRowsAfter(sheet.getMaxRows()-1,values.length-sheet.getMaxRows());if(values[0].length>sheet.getMaxColumns())sheet.insertColumnsAfter(sheet.getMaxColumns()-1,values[0].length-sheet.getMaxColumns());sheet.getRange(0,0,values.length,values[0].length).setValues(values);await saver.flush();});};
}catch(e){status(e.message||'办公编辑器加载失败',true);}
