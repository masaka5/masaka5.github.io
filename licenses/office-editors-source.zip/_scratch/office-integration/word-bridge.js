import mammoth from 'mammoth/mammoth.browser.js';
import DOMPurify from 'dompurify';
import {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,ImageRun,ExternalHyperlink,HeadingLevel,AlignmentType,WidthType,LevelFormat} from 'docx';
import {officeZip} from './office-zip.js';
const MIME='application/vnd.openxmlformats-officedocument.wordprocessingml.document';
export const embeddedImage=src=>/^data:image\/(png|jpeg|webp|gif);base64,/.test(src||'');
export function safeWordHTML(html){
 const value=DOMPurify.sanitize(html,{ALLOWED_TAGS:['p','div','span','br','h1','h2','h3','h4','h5','h6','strong','b','i','em','u','s','strike','sup','sub','ul','ol','li','blockquote','pre','code','a','img','table','thead','tbody','tfoot','tr','td','th','hr'],ALLOWED_ATTR:['href','src','alt','title','width','height','colspan','rowspan','start','style']});
 const doc=new DOMParser().parseFromString(value,'text/html');
 for(const el of doc.querySelectorAll('[style]')){const source=el.style,properties={};for(const key of ['text-align','font-weight','font-style','text-decoration','color','background-color','font-size','font-family','vertical-align']){const v=source.getPropertyValue(key);if(v&&!/url\s*\(|expression|javascript|[<>]/i.test(v))properties[key]=v;}el.removeAttribute('style');for(const [k,v]of Object.entries(properties))el.style.setProperty(k,v);}
 for(const img of doc.images)if(!embeddedImage(img.getAttribute('src')))img.remove();
 for(const a of doc.querySelectorAll('a'))if(!/^(https?:|mailto:)/i.test(a.getAttribute('href')||''))a.removeAttribute('href');
 if(doc.body.textContent.length>5*1024**2||doc.body.querySelectorAll('*').length>50000)throw Error('文档内容超限');
 return doc.body.innerHTML;
}
export async function readDocx(file){
 const {bytes}=await officeZip(file,'word/document.xml');
 const styles=['u => u','strike => s'];
 for(const align of ['left','center','right','justify'])for(const tag of ['p','h1','h2','h3','h4','h5','h6'])styles.push("p[style-name='toolbox-"+tag+'-'+align+"'] => "+tag+'.toolbox-align-'+align+':fresh');
 const transformDocument=mammoth.transforms.paragraph(p=>{const align={both:'justify',distribute:'justify'}[p.alignment]||p.alignment;if(!['left','center','right','justify'].includes(align)||p.numbering)return p;const heading=(p.styleId||p.styleName||'').match(/heading\s*([1-6])/i);return {...p,styleName:'toolbox-'+(heading?'h'+heading[1]:'p')+'-'+align};});
 const result=await mammoth.convertToHtml({arrayBuffer:bytes.buffer},{externalFileAccess:false,includeEmbeddedStyleMap:false,styleMap:styles,transformDocument,convertImage:mammoth.images.imgElement(async image=>{if(!['image/png','image/jpeg','image/webp','image/gif'].includes(image.contentType))throw Error('文档含不支持的图片，请使用 PNG 或 JPEG');const base64=await image.read('base64');if(base64.length>Math.ceil(8*1024**2*4/3))throw Error('文档内图片超过8 MiB');return {src:'data:'+image.contentType+';base64,'+base64};})});
 const html=new DOMParser().parseFromString(result.value,'text/html');for(const el of html.querySelectorAll('[class]')){const align=el.className.match(/toolbox-align-(left|center|right|justify)/)?.[1];if(align)el.style.textAlign=align;}
 return safeWordHTML(html.body.innerHTML);
}
function style(node,base={}){
 if(node.nodeType!==1)return base;const s=node.style,t=node.tagName,out={...base};
 if(['B','STRONG'].includes(t)||Number(s.fontWeight)>=600||s.fontWeight==='bold')out.bold=true;
 if(['I','EM'].includes(t)||s.fontStyle==='italic')out.italics=true;
 if(t==='U'||s.textDecoration.includes('underline'))out.underline={};if(['S','STRIKE'].includes(t)||s.textDecoration.includes('line-through'))out.strike=true;
 if(t==='SUP')out.superScript=true;if(t==='SUB')out.subScript=true;
 const match=s.color.match(/^rgb\(\s*(\d+),\s*(\d+),\s*(\d+)\)$/);if(match)out.color=match.slice(1).map(v=>Number(v).toString(16).padStart(2,'0')).join('');else if(/^#[\da-f]{6}$/i.test(s.color))out.color=s.color.slice(1);
 if(s.fontFamily)out.font=s.fontFamily.split(',')[0].replace(/["']/g,'');if(s.fontSize){const value=parseFloat(s.fontSize);if(Number.isFinite(value))out.size=Math.min(192,Math.max(8,Math.round(value*(s.fontSize.endsWith('px')?1.5:2))));}
 return out;
}
async function picture(el){
 const src=el.getAttribute('src');if(!embeddedImage(src))return null;
 const type=src.match(/^data:image\/(\w+)/)[1];let bytes=Uint8Array.from(atob(src.split(',')[1]),c=>c.charCodeAt(0));if(bytes.length>8*1024**2)throw Error('图片超过8 MiB');
 const img=new Image();img.src=src;await img.decode();let width=Number(el.getAttribute('width'))||img.naturalWidth,height=Number(el.getAttribute('height'))||img.naturalHeight;
 if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1)throw Error('图片尺寸无效');if(width>600){height*=600/width;width=600;}height=Math.min(900,height);
 let format=type==='jpeg'?'jpg':type;if(type==='webp'||type==='gif'){const c=document.createElement('canvas');c.width=Math.max(1,Math.round(width));c.height=Math.max(1,Math.round(height));c.getContext('2d').drawImage(img,0,0,c.width,c.height);bytes=Uint8Array.from(atob(c.toDataURL('image/png').split(',')[1]),v=>v.charCodeAt(0));format='png';}
 return new ImageRun({type:format,data:bytes,transformation:{width:Math.max(1,width),height:Math.max(1,height)},altText:{title:el.alt||'图片',description:el.alt||'图片',name:el.alt||'图片'}});
}
async function inline(nodes,base={}){
 const children=[];for(const node of nodes){if(node.nodeType===3){if(node.textContent)children.push(new TextRun({...base,text:node.textContent}));continue;}if(node.nodeType!==1)continue;
  if(node.tagName==='BR'){children.push(new TextRun({...base,break:1}));continue;}
  if(node.tagName==='IMG'){const item=await picture(node);if(item)children.push(item);continue;}
  const runs=await inline(node.childNodes,style(node,base));if(node.tagName==='A'&&/^(https?:|mailto:)/i.test(node.getAttribute('href')||''))children.push(new ExternalHyperlink({link:node.getAttribute('href'),children:runs}));else children.push(...runs);
 }return children;
}
const isBlock=node=>node.nodeType===1&&/^(P|DIV|H[1-6]|UL|OL|LI|BLOCKQUOTE|PRE|TABLE|HR)$/.test(node.tagName);
async function blocks(nodes,context={}){
 const result=[];let loose=[];
 const flush=async()=>{if(loose.length){const children=await inline(loose);if(children.length)result.push(new Paragraph({children}));loose=[];}};
 for(const node of nodes){if(!isBlock(node)){loose.push(node);continue;}await flush();const tag=node.tagName;
  if(tag==='TABLE'){
   const rows=[];for(const row of node.rows){const cells=[];for(const cell of row.cells){const children=await blocks(cell.childNodes);if(!children.length||children.at(-1)instanceof Table)children.push(new Paragraph(''));cells.push(new TableCell({children,columnSpan:Number(cell.getAttribute('colspan'))||1,rowSpan:Number(cell.getAttribute('rowspan'))||1,width:{size:100/Math.max(1,row.cells.length),type:WidthType.PERCENTAGE}}));}if(cells.length)rows.push(new TableRow({children:cells}));}
   if(rows.length)result.push(new Table({rows,width:{size:100,type:WidthType.PERCENTAGE}}));continue;
  }
  if(tag==='UL'||tag==='OL'){const ref=tag==='UL'?'bullets':'numbers';for(const li of [...node.children].filter(x=>x.tagName==='LI')){const own=[...li.childNodes].filter(n=>!(n.nodeType===1&&['OL','UL'].includes(n.tagName)));result.push(new Paragraph({children:await inline(own),numbering:{reference:ref,level:Math.min(context.level||0,8)}}));for(const list of [...li.children].filter(n=>['UL','OL'].includes(n.tagName)))result.push(...await blocks([list],{level:(context.level||0)+1}));}continue;}
  if(tag==='DIV'&&[...node.children].some(isBlock)){result.push(...await blocks(node.childNodes,context));continue;}
  const alignment={left:AlignmentType.LEFT,center:AlignmentType.CENTER,right:AlignmentType.RIGHT,justify:AlignmentType.JUSTIFIED}[node.style.textAlign];
  result.push(new Paragraph({children:await inline(node.childNodes,style(node)),alignment,...(/^H[1-6]$/.test(tag)?{heading:HeadingLevel['HEADING_'+tag[1]]}:{}),...(tag==='BLOCKQUOTE'?{indent:{left:480}}:{})}));
 }
 await flush();return result;
}
export async function writeDocx(html,title='文档'){
 const safe=safeWordHTML(html),body=new DOMParser().parseFromString(safe,'text/html').body,children=await blocks(body.childNodes);if(!children.length)children.push(new Paragraph(''));
 const numbering={config:[{reference:'bullets',levels:Array.from({length:9},(_,level)=>({level,format:LevelFormat.BULLET,text:'•',alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720*(level+1),hanging:360}}}}))},{reference:'numbers',levels:Array.from({length:9},(_,level)=>({level,format:LevelFormat.DECIMAL,text:'%'+(level+1)+'.',alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720*(level+1),hanging:360}}}}))}]};
 const doc=new Document({creator:'工具箱',title,styles:{default:{document:{run:{font:'Microsoft YaHei',size:22}}}},numbering,sections:[{properties:{},children}]});
 return new Blob([await Packer.toBlob(doc)],{type:MIME});
}
