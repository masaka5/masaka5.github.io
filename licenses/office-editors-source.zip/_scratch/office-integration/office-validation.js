export function parseCSV(text){
 text=text.replace(/^\ufeff/,'');const delimiter=text.includes('\t')&&!text.includes(',')?'\t':',';const rows=[],row=[];let value='',quoted=false,closed=false;
 const cell=()=>{row.push(value);value='';closed=false;if(row.length>2000)throw Error('CSV最多10000行、2000列');};
 const line=()=>{cell();rows.push([...row]);row.length=0;if(rows.length>10000)throw Error('CSV最多10000行、2000列');};
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'){if(text[i+1]==='"'){value+='"';i++;}else{quoted=false;closed=true;}}else value+=c;continue;}
  if(c===delimiter)cell();else if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;line();}
  else if(c==='"'&&!value&&!closed)quoted=true;else if(c==='"'||closed)throw Error('CSV引号无效');else value+=c;
 }
 if(quoted)throw Error('CSV引号未闭合');if(value||closed||row.length||!rows.length)line();
 const width=Math.max(...rows.map(r=>r.length));if(rows.length*width>200000)throw Error('CSV最多20万单元格');return rows.map(r=>Array.from({length:width},(_,i)=>r[i]||''));
}
