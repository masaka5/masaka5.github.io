import JSZip from 'jszip';
export const MAX_INPUT=20*1024**2,MAX_EXPANDED=100*1024**2;
export async function officeZip(file,required){
 if(!file||!file.size||file.size>MAX_INPUT)throw Error('请选择20 MiB以内的 Office 文件');
 const bytes=new Uint8Array(await file.arrayBuffer()),v=new DataView(bytes.buffer);let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(v.getUint32(i,true)===0x06054b50&&i+22+v.getUint16(i+20,true)===bytes.length){end=i;break;}
 if(end<0||v.getUint16(end+4,true)||v.getUint16(end+6,true))throw Error('文件损坏或格式不受支持');
 const count=v.getUint16(end+10,true),start=v.getUint32(end+16,true),length=v.getUint32(end+12,true);
 if(!count||count>5000||start+length>end)throw Error('Office 文件结构超限');
 let pos=start,total=0;const paths=new Set(),decoder=new TextDecoder();
 for(let i=0;i<count;i++){
  if(pos+46>start+length||v.getUint32(pos,true)!==0x02014b50)throw Error('文件目录损坏');
  const flags=v.getUint16(pos+8,true),method=v.getUint16(pos+10,true),packed=v.getUint32(pos+20,true),size=v.getUint32(pos+24,true),n=v.getUint16(pos+28,true),extra=v.getUint16(pos+30,true),comment=v.getUint16(pos+32,true),local=v.getUint32(pos+42,true);
  if(pos+46+n+extra+comment>start+length)throw Error('文件目录损坏');
  const path=decoder.decode(bytes.subarray(pos+46,pos+46+n));
  if(flags&1||![0,8].includes(method))throw Error('不支持加密 Office 文件');
  if(!path||path.startsWith('/')||path.includes('\\')||path.split('/').some(p=>p==='..'||p==='.')||paths.has(path)||local+30>start||size>32*1024**2||(total+=size)>MAX_EXPANDED)throw Error('Office 文件内容超限或路径无效');
  paths.add(path);
  if(v.getUint32(local,true)!==0x04034b50||local+30+v.getUint16(local+26,true)+v.getUint16(local+28,true)+packed>start)throw Error('Office 文件数据损坏');
  pos+=46+n+extra+comment;
 }
 if(pos!==start+length||!paths.has('[Content_Types].xml')||!paths.has(required))throw Error('请选择有效的 '+(required.startsWith('xl/')?'XLSX':'DOCX')+' 文件');
 const zip=await JSZip.loadAsync(bytes);let actual=0;
 for(const item of Object.values(zip.files))if(!item.dir){
  let current=0,chunks=[];const xml=/\.xml$|\.rels$/i.test(item.name);
  await new Promise((resolve,reject)=>{const stream=item.internalStream('uint8array');stream.on('data',chunk=>{current+=chunk.length;actual+=chunk.length;if(current>32*1024**2||actual>MAX_EXPANDED){stream.pause();reject(Error('Office 文件展开后过大'));}else if(xml)chunks.push(chunk);}).on('error',reject).on('end',resolve).resume();});
  if(xml&&/<!DOCTYPE|<!ENTITY/i.test(await new Blob(chunks).text()))throw Error('Office XML 结构不受支持');
 }
 return {bytes,zip};
}
