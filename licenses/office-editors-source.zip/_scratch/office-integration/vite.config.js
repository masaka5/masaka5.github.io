import {defineConfig} from 'vite';
import {resolve} from 'node:path';
export default defineConfig({base:'./',build:{target:'es2022',outDir:'../../toolbox-site/tools/office-editors',emptyOutDir:true,chunkSizeWarningLimit:15000,rollupOptions:{input:{document:resolve(import.meta.dirname,'document.html'),office:resolve(import.meta.dirname,'office.html')},onwarn(warning,handler){if(warning.code==='MODULE_LEVEL_DIRECTIVE'&&warning.message.includes('use client'))return;handler(warning);}}}});
