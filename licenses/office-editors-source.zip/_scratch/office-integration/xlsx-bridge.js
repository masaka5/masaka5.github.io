import ExcelJS from 'exceljs';
import {officeZip} from './office-zip.js';
const borders=['','thin','hair','dotted','dashed','dashDot','dashDotDot','double','medium','mediumDashed','mediumDashDot','mediumDashDotDot','slantDashDot','thick'];
const h=['','left','center','right','justify','justify','distributed'],vert=['','top','middle','bottom'];
const rgb=c=>c?.argb?'#'+c.argb.slice(-6):undefined;
const argb=c=>{const s=c?.rgb;if(!s)return;const hex=s.match(/^#([\da-f]{6})$/i);if(hex)return 'FF'+hex[1].toUpperCase();const match=s.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);if(match)return 'FF'+match.slice(1).map(n=>Math.min(255,Number(n)).toString(16).padStart(2,'0')).join('').toUpperCase();};
function readStyle(c){
 const f=c.font||{},a=c.alignment||{},s={};
 if(f.name)s.ff=f.name;if(f.size)s.fs=f.size;if(f.bold)s.bl=1;if(f.italic)s.it=1;if(f.underline)s.ul={s:1};if(f.strike)s.st={s:1};if(rgb(f.color))s.cl={rgb:rgb(f.color)};
 if(c.fill?.type==='pattern'&&c.fill.pattern==='solid'&&rgb(c.fill.fgColor))s.bg={rgb:rgb(c.fill.fgColor)};
 if(a.horizontal)s.ht=Math.max(0,h.indexOf(a.horizontal));if(a.vertical)s.vt=Math.max(0,vert.indexOf(a.vertical));if(a.wrapText)s.tb=3;if(typeof a.textRotation==='number')s.tr={a:a.textRotation};
 if(c.numFmt&&c.numFmt!=='General')s.n={pattern:c.numFmt};
 for(const [side,key]of [['top','t'],['bottom','b'],['left','l'],['right','r']])if(c.border?.[side]?.style){s.bd||={};s.bd[key]={s:Math.max(1,borders.indexOf(c.border[side].style)),cl:{rgb:rgb(c.border[side].color)||'#000000'}};}
 return Object.keys(s).length?s:undefined;
}
function writeStyle(c,s={}){
 c.font={name:s.ff||'Microsoft YaHei',size:s.fs||11,bold:!!s.bl,italic:!!s.it,underline:!!s.ul?.s,strike:!!s.st?.s,...(argb(s.cl)?{color:{argb:argb(s.cl)}}:{})};
 if(argb(s.bg))c.fill={type:'pattern',pattern:'solid',fgColor:{argb:argb(s.bg)}};
 c.alignment={horizontal:h[s.ht]||undefined,vertical:vert[s.vt]||undefined,wrapText:s.tb===3,textRotation:s.tr?.a||0};
 if(s.n?.pattern)c.numFmt=s.n.pattern;
 const bd={};for(const [side,key]of [['top','t'],['bottom','b'],['left','l'],['right','r']])if(s.bd?.[key]?.s)bd[side]={style:borders[s.bd[key].s]||'thin',color:{argb:argb(s.bd[key].cl)||'FF000000'}};c.border=bd;
}
function scalar(value,date1904){
 if(value instanceof Date)return (value.getTime()-Date.UTC(1899,11,30))/86400000;
 if(value&&typeof value==='object'){if(value.richText)return value.richText.map(r=>r.text).join('');if(value.hyperlink)return value.text||value.hyperlink;if(value.error)return value.error;return null;}
 return value??null;
}
export async function readXlsx(file){
 const {bytes}=await officeZip(file,'xl/workbook.xml'),book=new ExcelJS.Workbook();await book.xlsx.load(bytes);
 if(!book.worksheets.length||book.worksheets.length>100)throw Error('工作表数量超限');
 const data={id:'xlsx-'+crypto.randomUUID(),name:file.name.replace(/\.xlsx$/i,''),locale:'zhCN',sheetOrder:[],sheets:{},styles:{}};let count=0;
 for(const [i,ws]of book.worksheets.entries()){
  const id='sheet'+i,rowCount=Math.max(1000,ws.rowCount),columnCount=Math.max(26,ws.columnCount);
  if(rowCount>100000||columnCount>2000)throw Error('表格最多100000行、2000列');
  const sheet={id,name:ws.name,rowCount,columnCount,cellData:{},rowData:{},columnData:{},mergeData:[],defaultRowHeight:24,defaultColumnWidth:88};data.sheetOrder.push(id);data.sheets[id]=sheet;
  // ExcelJS is pinned: sparse model arrays retain styled blanks without allocating a dense rectangle.
  ws._rows.forEach(row=>{const r=row.number;if(row.height)sheet.rowData[r-1]={h:row.height*4/3};if(row.hidden)sheet.rowData[r-1]={...sheet.rowData[r-1],hd:1};row._cells.forEach(cell=>{const col=cell.col;
   const style=readStyle(cell);if(cell.type===ExcelJS.ValueType.Merge||cell.value==null&&!style)return;if(++count>200000)throw Error('最多20万个已用单元格');
   const c={},v=cell.value;let result=v;
   if(v&&typeof v==='object'&&('formula'in v||'sharedFormula'in v)){c.f='='+cell.formula;result=v.result;}
   c.v=scalar(result,book.properties.date1904);c.t=typeof c.v==='number'?2:typeof c.v==='boolean'?3:1;
   if(v?.richText){let text='',runs=[];for(const item of v.richText){const st=text.length;text+=item.text;runs.push({st,ed:text.length,ts:readStyle({font:item.font})||{}});}c.p={id:crypto.randomUUID(),body:{dataStream:text+'\r\n',textRuns:runs,paragraphs:[{startIndex:text.length}],sectionBreaks:[{startIndex:text.length+1}]}};}
   if(style)c.s=style;if(v?.error)c.custom={toolboxExcelError:v.error};(sheet.cellData[r-1]??={})[col-1]=c;
  });});
  for(const [j,col]of (ws.columns||[]).entries())if(col?.width||col?.hidden)sheet.columnData[j]={...(col.width?{w:Math.round(col.width*7+5)}:{}),...(col.hidden?{hd:1}:{})};
  for(const range of ws.model.merges||[]){const cells=range.split(':').map(x=>ws.getCell(x));sheet.mergeData.push({startRow:cells[0].row-1,startColumn:cells[0].col-1,endRow:cells.at(-1).row-1,endColumn:cells.at(-1).col-1});}
  const view=ws.views?.find(v=>v.state==='frozen');if(view)sheet.freeze={startRow:view.ySplit||0,startColumn:view.xSplit||0,xSplit:view.xSplit||0,ySplit:view.ySplit||0};
 }
 const names={};for(const item of book.definedNames.model||[]){const id=crypto.randomUUID();names[id]={id,name:item.name,formulaOrRefString:item.ranges.join(',')};}if(Object.keys(names).length)data.resources=[{name:'SHEET_DEFINED_NAME_PLUGIN',data:JSON.stringify(names)}];
 return data;
}
export async function writeXlsx(data){
 const book=new ExcelJS.Workbook();book.creator='工具箱';book.calcProperties.fullCalcOnLoad=true;let count=0;
 for(const id of data.sheetOrder){const s=data.sheets[id],ws=book.addWorksheet(s.name);for(const [r,cells]of Object.entries(s.cellData||{}))for(const [col,c]of Object.entries(cells)){
  if(++count>200000)throw Error('最多导出20万个已用单元格');const cell=ws.getCell(Number(r)+1,Number(col)+1);let value=c.v??null;
  if(c.p?.body?.dataStream){const body=c.p.body,text=body.dataStream.replace(/\r\n$/,'');const runs=body.textRuns||[];if(runs.length){let pos=0,list=[];for(const run of [...runs].sort((a,b)=>a.st-b.st)){if(run.st>pos)list.push({text:text.slice(pos,run.st)});const holder={};writeStyle(holder,run.ts);list.push({text:text.slice(run.st,run.ed),font:holder.font});pos=run.ed;}if(pos<text.length)list.push({text:text.slice(pos)});value={richText:list};}else value=text;}
  if(c.custom?.toolboxExcelError===value&&['#N/A','#REF!','#NAME?','#DIV/0!','#NULL!','#VALUE!','#NUM!'].includes(value))value={error:value};if(c.f)value={formula:c.f.replace(/^=/,''),...(typeof c.v==='string'||typeof c.v==='number'||typeof c.v==='boolean'?{result:c.v}:{})};cell.value=value;
  const style=typeof c.s==='string'?data.styles?.[c.s]:c.s;writeStyle(cell,style);
 }
 for(const [r,row]of Object.entries(s.rowData||{})){const target=ws.getRow(Number(r)+1);if(row.h)target.height=row.h*3/4;if(row.hd){target.hidden=true;target.height||=(s.defaultRowHeight||24)*3/4;}}
 for(const [col,c]of Object.entries(s.columnData||{})){if(c.w)ws.getColumn(Number(col)+1).width=Math.max(1,(c.w-5)/7);if(c.hd)ws.getColumn(Number(col)+1).hidden=true;}
 for(const m of s.mergeData||[])ws.mergeCells(m.startRow+1,m.startColumn+1,m.endRow+1,m.endColumn+1);
 if(s.freeze?.xSplit||s.freeze?.ySplit)ws.views=[{state:'frozen',xSplit:s.freeze.xSplit||0,ySplit:s.freeze.ySplit||0}];
 }
 const names=data.resources?.find(r=>r.name==='SHEET_DEFINED_NAME_PLUGIN');if(names?.data)for(const item of Object.values(JSON.parse(names.data)))book.definedNames.add(item.formulaOrRefString,item.name);
 return new Blob([await book.xlsx.writeBuffer()],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
