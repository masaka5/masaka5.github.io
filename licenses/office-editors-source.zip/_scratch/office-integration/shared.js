export const $=id=>document.getElementById(id);
export function status(text,error=false){$('saveStatus').textContent=text;$('saveStatus').dataset.tone=error?'error':'';}
export function download(data,name,type='application/json'){
 const blob=data instanceof Blob?data:new Blob([data],{type});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
let dbPromise;
export function database(){return dbPromise||=new Promise((resolve,reject)=>{const r=indexedDB.open('toolbox-office-editors',1);r.onupgradeneeded=()=>r.result.createObjectStore('drafts');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export async function readDraft(key){const db=await database();return new Promise((resolve,reject)=>{const r=db.transaction('drafts').objectStore('drafts').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export async function writeDraft(key,data){const db=await database();return new Promise((resolve,reject)=>{const t=db.transaction('drafts','readwrite');t.objectStore('drafts').put(data,key);t.oncomplete=resolve;t.onabort=()=>reject(t.error);t.onerror=()=>{};});}
export async function textFile(file,max=20*1024**2){if(!file||file.size>max)throw Error('文件超过20 MiB');return file.text();}
export function safeName(value){return (value||'未命名').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,100);}
export function draftSaver(key,getData,delay=500){
 let timer,queue=Promise.resolve(),failed=false,pending=0;
 const flush=()=>{clearTimeout(timer);timer=null;let data;try{data=getData();}catch(e){status(e.message,true);return Promise.reject(e);}
  status('正在保存');pending++;queue=queue.catch(()=>{}).then(()=>writeDraft(key,data)).then(()=>{failed=false;status('已保存');},()=>{failed=true;status('保存失败，请导出备份',true);throw Error('保存失败，请先导出备份');}).finally(()=>{pending--;});return queue;
 };
 const schedule=()=>{clearTimeout(timer);status('未保存');timer=setTimeout(()=>flush().catch(()=>{}),delay);};
 const onHide=()=>{clearTimeout(timer);try{const data=getData();writeDraft(key,data).catch(()=>{});}catch{}};
 const onUnload=e=>{if(timer||pending||failed){e.preventDefault();e.returnValue='';}};
 window.addEventListener('pagehide',onHide);window.addEventListener('beforeunload',onUnload);
 return {schedule,flush,dispose(){clearTimeout(timer);timer=null;window.removeEventListener('pagehide',onHide);window.removeEventListener('beforeunload',onUnload);}};
}
