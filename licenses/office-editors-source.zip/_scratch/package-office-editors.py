"""Package editable sources, pinned provenance and dependency licenses."""
from pathlib import Path
import json,zipfile,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site'
excluded={'.git','node_modules','dist','__pycache__'}
out=SITE/'licenses/office';out.mkdir(exist_ok=True)
records=[]
for folder in ['office-integration','web-ppt-build']:
 base=ROOT/'_scratch'/folder
 lock=json.loads((base/'package-lock.json').read_text())
 for key,pkg in lock['packages'].items():
  if not key or '/node_modules/' in key:continue
  directory=base/key
  licenses=[p for p in directory.iterdir() if p.is_file() and p.name.lower().startswith(('license','copying','notice'))] if directory.exists()else[]
  manifest=directory/'package.json'
  meta=json.loads(manifest.read_text(encoding='utf8')) if manifest.exists()else{}
  item={'name':meta.get('name',key),'version':pkg.get('version'),'license':pkg.get('license',meta.get('license')),'resolved':pkg.get('resolved'),'integrity':pkg.get('integrity'),'texts':[]}
  for p in licenses:
   name=(item['name']+'-'+item['version']+'-'+p.name).replace('/','__').replace('@','')+'.txt'
   (out/name).write_bytes(p.read_bytes());item['texts'].append('licenses/office/'+name)
  records.append(item)
(out/'dependencies.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
upstream=ROOT/'_scratch/drawio-upstream'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=upstream,text=True).strip()
with zipfile.ZipFile(SITE/'licenses/drawio-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in upstream.rglob('*'):
  rel=p.relative_to(upstream)
  # Raw editor sources only. Unmodified generated runtimes and shape assets are
  # already supplied in the deploy archive; do not duplicate them on Pages.
  source=rel.as_posix().startswith(('src/main/webapp/js/diagramly/','src/main/webapp/js/grapheditor/'))or len(rel.parts)==1
  if p.is_file()and source and not excluded.intersection(rel.parts):z.write(p,'drawio-upstream/'+rel.as_posix())
 z.writestr('SOURCE.md',f'Original draw.io source at https://github.com/jgraph/drawio/tree/{sha}. This archive supplies raw editor sources and provenance; unmodified prebuilt runtimes and shape assets are in tools/drawio/vendor of the deploy archive. For a full upstream build, checkout the pinned Git revision using the upstream README. Runtime selection is performed by _scratch/stage-drawio-runtime.py in office-editors-source.zip. Apache-2.0; component licenses preserved.\n')
with zipfile.ZipFile(SITE/'licenses/office-editors-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for folder in ['office-integration','web-ppt-build']:
  for p in (ROOT/'_scratch'/folder).rglob('*'):
   rel=p.relative_to(ROOT)
   if p.is_file()and not excluded.intersection(rel.parts):z.write(p,rel.as_posix())
 for p in (SITE/'tools/drawio').iterdir():
  if p.is_file():z.write(p,'toolbox-site/tools/drawio/'+p.name)
 for p in (ROOT/'_scratch/ops-tests').glob('*'):
  if p.is_file()and p.suffix in {'.py','.cjs'}and p.name.startswith(('office-','drawio-','web-ppt-')):z.write(p,'_scratch/ops-tests/'+p.name)
 for name in ['stage-drawio-runtime.py','package-office-editors.py','office-drawio-report.md','office-web-ppt-report.md']:
  z.write(ROOT/'_scratch'/name,'_scratch/'+name)
 for p in (SITE/'docs/superpowers').rglob('*office-editors.md'):z.write(p,'toolbox-site/'+p.relative_to(SITE).as_posix())
 z.writestr('BUILD.md','''# 办公编辑器源码

纯静态本地处理。Node 22+ / npm / Python 3。

1. 在 `_scratch/office-integration` 中运行 `npm ci`、`npm run build`，输出 `toolbox-site/tools/office-editors`。
2. 在 `_scratch/web-ppt-build` 中运行 `npm ci`、`npm run build`，输出 `toolbox-site/tools/web-ppt`。基于 duchao-duchao/web-ppt 6d07815384197d7e7409b5af9743db6ea39bc29a，保留 MIT。
3. 将 drawio-source.zip 的 drawio-upstream 解压至 `_scratch/drawio-upstream`，运行 `python _scratch/stage-drawio-runtime.py`；shell 源码在本包 tools/drawio 中，原始 Apache-2.0 与组件许可保留。

版本锁与依赖许可见 package-lock.json、licenses/office/dependencies.json；Tiptap 3.33.1 MIT，Univer 开源 presets 1.4.0 Apache-2.0。Univer 项目 JSON 和 CSV 为当前支持的导入导出格式，未集成商业 Office 二进制转换服务。Web-PPT 导出静态 PPTX。draw.io XML 保留多页，SVG/PNG 导出当前页。IndexedDB 草稿仅在当前浏览器，清理站点数据会删除草稿。
''')
sources=SITE/'licenses/sources.json';items=json.loads(sources.read_text())
new=[{'project':'drawio','source':'https://github.com/jgraph/drawio','revision':sha,'license':'Apache-2.0','sourceArchive':'licenses/drawio-source.zip','changes':'Local Chinese draw.io runtime; corresponding toolbox shell/build sources in licenses/office-editors-source.zip.'},
 {'project':'tiptap','source':'https://github.com/ueberdosis/tiptap','version':'3.33.1','license':'MIT','sourceArchive':'licenses/office-editors-source.zip'},
 {'project':'univer','source':'https://github.com/dream-num/univer','version':'1.4.0','license':'Apache-2.0','sourceArchive':'licenses/office-editors-source.zip'},
 {'project':'web-ppt','source':'https://github.com/duchao-duchao/web-ppt','revision':'6d07815384197d7e7409b5af9743db6ea39bc29a','license':'MIT','sourceArchive':'licenses/office-editors-source.zip'}]
items=[x for x in items if x.get('project')not in {x['project']for x in new}]+new
sources.write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for name in ['drawio','office-editors','web-ppt']:
 folder=SITE/'tools'/name
 files=[{'file':p.relative_to(folder).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(folder.rglob('*'))if p.is_file()and p.name!='manifest.json']
 (folder/'manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n',encoding='utf8')
print(json.dumps({'office_source_bytes':(SITE/'licenses/office-editors-source.zip').stat().st_size,'drawio_source_bytes':(SITE/'licenses/drawio-source.zip').stat().st_size,'dependency_records':len(records),'site_bytes':sum(p.stat().st_size for p in SITE.rglob('*')if p.is_file())}))
