import asyncio,os,sys,json,io,zipfile,base64,datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qa-office'))
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.workbook.defined_name import DefinedName
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZfWQAAAAASUVORK5CYII=')
def fixtures():
 w=Workbook();s=w.active;s.title='中文数据';s.append(['项目',12,34,'=SUM(B1:C1)']);s['A1'].font=Font(bold=True,color='FF234567');s['A1'].fill=PatternFill('solid',fgColor='FFF0C040');s['A1'].alignment=Alignment(horizontal='center');s['B2']='合并中文';s.merge_cells('B2:C2');s.column_dimensions['A'].width=24;s.row_dimensions[1].height=28;s['B3']=0.25;s['B3'].number_format='0.00%';s['C3']=datetime.datetime(2026,11,12);s['C3'].number_format='yyyy-mm-dd';w.create_sheet('第二工作表')['A1']='第二页';x=io.BytesIO();w.save(x)
 s['B5'].fill=PatternFill('solid',fgColor='FFFF0000');s['B5'].border=Border(bottom=Side(style='thin'));s.row_dimensions[7].height=50;s.row_dimensions[8].hidden=True;w.defined_names.add(DefinedName('TotalValues',attr_text="'中文数据'!$B$1:$C$1"));s['D3']='=SUM(TotalValues)';x=io.BytesIO();w.save(x)
 d=Document();heading=d.add_heading('中文工作文档',level=1);heading.alignment=WD_ALIGN_PARAGRAPH.CENTER;p=d.add_paragraph('正文中文');p.add_run('加粗内容').bold=True;p.add_run('下划线').underline=True;d.add_paragraph('列表项目',style='List Bullet');d.add_paragraph().add_run('换行前\n换行后');t=d.add_table(rows=2,cols=2);t.cell(0,0).text='表头';t.cell(1,1).text='数据中文';d.add_picture(io.BytesIO(PNG),width=Inches(0.3));y=io.BytesIO();d.save(y);return x.getvalue(),y.getvalue()
async def downloaded(page,selector):
 try:
  async with page.expect_download(timeout=15000)as d:await page.locator(selector).click()
 except:raise AssertionError(('download',selector,await page.locator('#saveStatus').inner_text()))
 return Path(await(await d.value).path()).read_bytes()
async def main():
 x,y=fixtures()
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/office-editors/office.html');await page.wait_for_function('window.officeApp?.unit')
  assert await page.locator('#exportOffice').count()==1,'缺少 Excel / Word 导出入口'
  await page.locator('#importFile').set_input_files({'name':'中文.xlsx','mimeType':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','buffer':x})
  await page.wait_for_function("officeApp.mode==='sheet'&&officeApp.unit.save().sheetOrder.length===2")
  assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').getValue()")=='项目'
  await page.evaluate("officeApp.unit.getActiveSheet().getRange('A3').setValue('浏览器编辑')")
  await page.evaluate("officeApp.unit.getActiveSheet().getRange('E1').setValues([[{v:'00123',t:4}]])")
  out=load_workbook(io.BytesIO(await downloaded(page,'#exportOffice')),data_only=False)
  assert out.sheetnames==['中文数据','第二工作表'];s=out.worksheets[0];assert s['A3'].value=='浏览器编辑';assert s['D1'].value=='=SUM(B1:C1)';assert s['A1'].font.bold;assert s['A1'].fill.fgColor.rgb[-6:]=='F0C040';assert str(next(iter(s.merged_cells.ranges)))=='B2:C2';assert s['B3'].number_format=='0.00%';assert s['C3'].value==datetime.datetime(2026,11,12);assert s['A1'].alignment.horizontal=='center';assert abs(s.column_dimensions['A'].width-24)<1
  assert s['B5'].fill.fgColor.rgb[-6:]=='FF0000' and s['B5'].border.bottom.style=='thin';assert s.row_dimensions[7].height==50 and s.row_dimensions[8].hidden;assert 'TotalValues'in out.defined_names;assert s['E1'].value=='00123'and s['E1'].data_type=='s'
  await page.locator('#importFile').set_input_files({'name':'坏.xlsx','mimeType':'application/zip','buffer':b'PKbad'})
  await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone==='error'")
  assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A3').getValue()")=='浏览器编辑'
  results={'xlsx_multisheet_formula_style_merge':True,'xlsx_corrupt_preserves':True}
  await page.wait_for_timeout(700)
  await page.evaluate("() => {const original=IDBObjectStore.prototype.put;let calls=0;IDBObjectStore.prototype.put=function(...args){if(++calls===2)throw new DOMException('quota','QuotaExceededError');return original.apply(this,args);};}")
  await page.locator('#importFile').set_input_files({'name':'重试.xlsx','mimeType':'application/zip','buffer':x})
  await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone==='error'&&!document.querySelector('#importButton').disabled")
  assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A3').getValue()")=='浏览器编辑'
  results['failed_save_preserves']=True
  for filename,selector in [('document.html','#exportDOCX'),('office.html','#exportOffice')]:
   print('Testing '+filename,flush=True)
   await page.goto(BASE+'/tools/office-editors/'+filename)
   await page.locator(selector).wait_for()
   await page.locator('#importFile').set_input_files({'name':'中文.docx','mimeType':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','buffer':y})
   try:await page.wait_for_function("window.documentEditor?.getText().includes('中文工作文档')||window.officeApp?.mode==='doc'&&officeApp.unit?.save().body.dataStream.includes('中文工作文档')")
   except:raise AssertionError((filename,await page.locator('#saveStatus').inner_text(),errors))
   output=await downloaded(page,selector);doc=Document(io.BytesIO(output));text='\n'.join(q.text for q in doc.paragraphs)
   assert '中文工作文档'in text and '正文中文'in text and '列表项目'in text,(filename,text)
   assert '换行前\n换行后'in text,(filename,'line break',text)
   assert any(r.bold and '加粗内容'in r.text for q in doc.paragraphs for r in q.runs),(filename,'bold')
   assert doc.tables and '数据中文'in doc.tables[0].cell(1,1).text,(filename,'table')
   assert doc.paragraphs[0].style.name=='Heading 1',(filename,'heading')
   assert doc.paragraphs[0].alignment==WD_ALIGN_PARAGRAPH.CENTER,(filename,'alignment')
   assert any(r.underline and '下划线'in r.text for q in doc.paragraphs for r in q.runs),(filename,'underline')
   with zipfile.ZipFile(io.BytesIO(output))as z:assert any(n.startswith('word/media/')for n in z.namelist()),(filename,'image')
   await page.locator('#importFile').set_input_files({'name':'往返.docx','mimeType':'application/zip','buffer':output});await page.wait_for_function("document.querySelector('#importButton').disabled===false")
   await page.reload();await page.locator(selector).wait_for();assert '中文工作文档' in '\n'.join(q.text for q in Document(io.BytesIO(await downloaded(page,selector))).paragraphs)
   await page.locator('#importFile').set_input_files({'name':'坏.docx','mimeType':'application/zip','buffer':b'PKbad'})
   await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone==='error'")
   assert '中文工作文档'in '\n'.join(q.text for q in Document(io.BytesIO(await downloaded(page,selector))).paragraphs)
   for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
    await page.set_viewport_size({'width':w,'height':h});assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(filename,w,h)
   results[filename]={'docx_text_bold_list_table_image':True,'restore':True,'corrupt_preserves':True,'layouts':5}
  assert not errors,errors;results['errors']=errors;print(json.dumps(results));await b.close()
asyncio.run(main())
