import asyncio,os
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch()
  for filename,ready,name in [('document.html','window.documentEditor','document'),('office.html','window.officeApp?.unit','univer')]:
   page=await b.new_page(viewport={'width':1440,'height':900});await page.goto(BASE+'/tools/office-editors/'+filename);await page.wait_for_function(ready)
   if name=='document':await page.locator('.tiptap').fill('项目计划\n需求整理与任务分工。')
   else:await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1:B3').setValues([['项目','进度'],['界面优化','完成'],['功能验证','完成']])")
   await page.wait_for_timeout(2000);await page.screenshot(path=str(Path('_scratch')/(name+'-desktop.png')))
   await page.set_viewport_size({'width':390,'height':844});await page.wait_for_timeout(500);await page.screenshot(path=str(Path('_scratch')/(name+'-mobile.png')));await page.close()
  await b.close()
 print('PASS office desktop/mobile screenshots')
asyncio.run(main())
