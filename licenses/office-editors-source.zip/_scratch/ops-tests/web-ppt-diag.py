import asyncio
from playwright.async_api import async_playwright
async def m():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page();page.on('pageerror',lambda e:print(e));await page.goto('http://127.0.0.1:8765/tools/web-ppt/');await page.wait_for_timeout(500);print(await page.locator('body').inner_text());await page.get_by_role('button',name='插入文本',exact=True).click();print(await page.locator('body').inner_text());await page.wait_for_timeout(500);print(await page.get_by_role('status').inner_text());await page.reload();await page.wait_for_timeout(500);print('RELOAD',await page.locator('body').inner_text());await b.close()
asyncio.run(m())

