import asyncio,os
from playwright.async_api import async_playwright,expect
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));await page.goto(BASE+'/tools/web-ppt/');await page.get_by_role('button',name='插入文本',exact=True).click();text=page.locator('#ppt-main-canvas [contenteditable=true]');await text.fill('画布直接编辑未失焦保存');await text.press('End');await text.press_sequentially('连续输入');assert await text.evaluate('(el)=>el===document.activeElement');await expect(page.get_by_label('文本内容')).to_have_value('画布直接编辑未失焦保存连续输入');await page.get_by_role('status').filter(has_text='已保存到本地').wait_for();await page.reload();await expect(page.locator('#ppt-main-canvas')).to_contain_text('画布直接编辑未失焦保存连续输入');assert not errors,errors;print('PASS canvas contenteditable input autosaves before blur and restores Chinese text');await b.close()
asyncio.run(main())
