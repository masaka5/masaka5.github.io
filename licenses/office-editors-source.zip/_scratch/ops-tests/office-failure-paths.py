import asyncio
import base64
import json
import os
from pathlib import Path

from playwright.async_api import async_playwright

BASE = os.getenv('TOOLBOX_TEST_BASE', 'http://127.0.0.1:8765')
ROOT = BASE + '/tools/office-editors/'


async def download_text(page, selector, encoding='utf8'):
    async with page.expect_download() as download:
        await page.locator(selector).click()
    return Path(await (await download.value).path()).read_text(encoding)


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        context = await browser.new_context()
        page = await context.new_page()
        errors = []
        remote_images = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('request', lambda request: remote_images.append(request.url)
                if 'example.invalid' in request.url else None)
        await page.goto(ROOT + 'document.html')
        await page.locator('.tiptap').wait_for()
        await page.evaluate('''() => {
          documentEditor.commands.setContent('<p style="text-align:center">居中内容</p>');
          documentEditor.view.pasteHTML('<p>粘贴内容</p><img src="https://example.invalid/image.png">');
        }''')
        assert not await page.locator('.tiptap img').count()
        assert not remote_images, remote_images
        html = await download_text(page, '#exportHTML')
        assert 'text-align: center' in html, html
        png = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Zl1sAAAAASUVORK5CYII=')
        await page.locator('#imageFile').set_input_files({'name': 'pixel.png', 'mimeType': 'image/png', 'buffer': png})
        await page.locator('.tiptap img').wait_for()
        await page.wait_for_function("document.querySelector('#saveStatus').textContent === '已保存'")
        await page.reload()
        await page.locator('.tiptap img').wait_for()
        assert (await page.locator('.tiptap img').get_attribute('src')).startswith('data:image/png;base64,')
        await page.goto(ROOT + 'office.html')
        await page.wait_for_function('officeApp.unit !== undefined')
        await page.evaluate(r'''() => {
          const sheet = officeApp.unit.getActiveSheet();
          sheet.getRange('B3').setValues([[{p:{id:'rich',body:{dataStream:'富文本\r\n',paragraphs:[{startIndex:3}],textRuns:[{st:0,ed:1,ts:{bl:1}}]}}}]]);
        }''')
        csv = await download_text(page, '#exportCSV', 'utf-8-sig')
        assert '富文本' in csv and len(csv.splitlines()) == 3, repr(csv)
        await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').setValue('必须保留')")
        project = await page.evaluate("({version:1,kind:'univer',mode:'sheet',data:officeApp.unit.save()})")
        project['data']['sheets']['sheet1']['cellData']['0']['0']['v'] = {'invalid': 'value'}
        await page.locator('#importFile').set_input_files({'name': 'invalid.json', 'mimeType': 'application/json', 'buffer': json.dumps(project).encode()})
        await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone === 'error'")
        assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').getValue()") == '必须保留'
        malformed_doc = {'version': 1, 'kind': 'univer', 'mode': 'doc', 'data': {
            'id': 'bad-doc', 'body': {'dataStream': 'broken\r\n', 'paragraphs': {'invalid': True}, 'sectionBreaks': [{'startIndex': 7}]}}}
        await page.locator('#importFile').set_input_files({'name': 'invalid-doc.json', 'mimeType': 'application/json', 'buffer': json.dumps(malformed_doc).encode()})
        await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone === 'error' && !document.querySelector('#officeMode').disabled")
        assert await page.evaluate('officeApp.mode') == 'sheet'
        assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').getValue()") == '必须保留'
        await page.evaluate("() => { IDBObjectStore.prototype.put = function() { throw new DOMException('quota', 'QuotaExceededError'); }; }")
        await page.locator('#officeMode').select_option('doc')
        await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone === 'error' && !document.querySelector('#officeMode').disabled")
        assert await page.evaluate('officeApp.mode') == 'sheet'
        assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').getValue()") == '必须保留'
        assert '必须保留' in await download_text(page, '#exportProject')
        await context.close()

        # Invalid IndexedDB records must leave usable controls on both entries.
        for filename, key, ready in [('document.html', 'tiptap-v1', 'documentEditor'), ('office.html', 'univer-sheet', 'officeApp?.unit')]:
            context = await browser.new_context()
            await context.add_init_script("window.addEventListener('pagehide', event => { if(window.__blockPagehide) event.stopImmediatePropagation(); }, true);")
            page = await context.new_page()
            page.on('pageerror', lambda error: errors.append(str(error)))
            await page.goto(ROOT + filename)
            await page.wait_for_function('window.' + ready + ' !== undefined')
            await page.evaluate('window.__blockPagehide = true')
            await page.evaluate('''key => new Promise((resolve, reject) => {
              const request = indexedDB.open('toolbox-office-editors', 1);
              request.onsuccess = () => {
                const transaction = request.result.transaction('drafts', 'readwrite');
                transaction.objectStore('drafts').put({version: -1}, key);
                transaction.oncomplete = resolve;
                transaction.onerror = reject;
              };
            })''', key)
            await page.reload()
            await page.wait_for_function('window.' + ready + ' !== undefined')
            await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone === 'error'")
            if filename == 'document.html':
                await page.locator('.tiptap').fill('恢复后可继续编辑')
                assert '恢复后可继续编辑' in await download_text(page, '#exportJSON')
            else:
                await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').setValue('恢复后可继续编辑')")
                assert '恢复后可继续编辑' in await download_text(page, '#exportProject')
            await context.close()
        assert not errors, errors
        print(json.dumps({'HTML_alignment': True, 'remote_images_blocked': True, 'embedded_image_restore': True, 'rich_text_CSV': True, 'malformed_cell_preserved': True, 'malformed_doc_preserved': True, 'quota_failure_preserved': True, 'invalid_draft_recovery': True, 'errors': errors}))
        await browser.close()


asyncio.run(main())
