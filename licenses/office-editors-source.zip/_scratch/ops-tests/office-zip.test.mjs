import {test} from 'node:test';
import assert from 'node:assert/strict';
import JSZip from '../office-integration/node_modules/jszip/lib/index.js';
import {officeZip} from '../office-integration/office-zip.js';
async function file(entries){const z=new JSZip();for(const [path,value]of Object.entries(entries))z.file(path,value);return new File([await z.generateAsync({type:'uint8array',compression:'DEFLATE'})],'test.docx');}
test('valid local OOXML reads, corrupted/foreign files reject',async()=>{const good=await file({'[Content_Types].xml':'<Types/>','word/document.xml':'<document/>'});assert.equal((await officeZip(good,'word/document.xml')).zip.file('word/document.xml').name,'word/document.xml');await assert.rejects(officeZip(new File(['PKbad'],'bad.docx'),'word/document.xml'));await assert.rejects(officeZip(good,'xl/workbook.xml'));});
test('ZIP traversal and entity declarations are rejected before conversion',async()=>{await assert.rejects(officeZip(await file({'[Content_Types].xml':'<Types/>','word/document.xml':'<document/>','../outside':'bad'}),'word/document.xml'));await assert.rejects(officeZip(await file({'[Content_Types].xml':'<Types/>','word/document.xml':'<!DOCTYPE x [<!ENTITY e "x">]><x/>'}),'word/document.xml'));});
test('highly compressed oversized payload is bounded',async()=>{const f=await file({'[Content_Types].xml':'<Types/>','word/document.xml':'x'.repeat(33*1024**2)});assert(f.size<1024**2);await assert.rejects(officeZip(f,'word/document.xml'),/超限/);});
