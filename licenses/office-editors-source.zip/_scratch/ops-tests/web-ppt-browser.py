import asyncio,os,json,zipfile,io
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(); page=await b.new_page(accept_downloads=True); errors=[]; missing=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:missing.append(r.url) if r.status==404 else None)
  await page.goto(BASE+'/tools/web-ppt/');await page.get_by_role('button',name='插入文本',exact=True).click(timeout=5000)
  await page.get_by_label('文本内容').fill('中文演示验收');await page.get_by_label('文本内容').blur()
  await page.get_by_role('button',name='新增幻灯片',exact=True).click()
  await page.get_by_role('button',name='插入文本',exact=True).click();await page.get_by_label('文本内容').fill('第二页内容');await page.get_by_label('文本内容').blur()
  async with page.expect_download() as d: await page.get_by_role('button',name='导出项目',exact=True).click()
  download=await d.value;path=await download.path();data=json.load(open(path,encoding='utf8'));assert len(data['slides'])==2
  await page.get_by_role('status').filter(has_text='已保存到本地').wait_for();await page.reload();await page.get_by_role('button',name='第 2 页',exact=True).wait_for();assert await page.locator('#ppt-main-canvas').inner_text()=='第二页内容'
  await page.get_by_label('演示文稿名称').fill('导入前修改');await page.locator('input[aria-label="导入项目"]').set_input_files(path)
  await page.wait_for_function("document.querySelector('[aria-label=演示文稿名称]').value === '未命名演示'")
  async with page.expect_download() as d:await page.get_by_role('button',name='导出演示文件',exact=True).click()
  ppt=await(await d.value).path();z=zipfile.ZipFile(ppt);assert '中文演示验收' in z.read('ppt/slides/slide1.xml').decode();assert '第二页内容' in z.read('ppt/slides/slide2.xml').decode()
  await page.get_by_role('button',name='预览',exact=True).click();await page.get_by_role('button',name='上一页',exact=True).click();assert '中文演示验收' in await page.locator('[role=dialog]').inner_text();await page.get_by_role('button',name='退出预览',exact=True).click()
  for w,h in [(1440,900),(1024,768),(768,1024),(390,844),(320,640)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(100);assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h)
   assert await page.get_by_role('button',name='插入文本',exact=True).is_visible()
  assert not errors,errors;assert not missing,missing
  print('PASS Chinese text / 2 slides / JSON roundtrip / draft reload / PPTX XML / preview / 5 viewports / 0 pageerrors / 0 local404');await b.close()
asyncio.run(main())
