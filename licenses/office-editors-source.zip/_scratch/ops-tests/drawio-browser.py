import asyncio, os, pathlib, json, zlib, base64, urllib.parse
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(); page=await b.new_page(accept_downloads=True); errors=[]; missing=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:missing.append(r.url) if r.status==404 and r.url.startswith(BASE) else None)
  await page.goto(BASE+'/tools/drawio/')
  assert await page.get_by_role('heading',name='图表与思维导图').count()==1,'Missing Chinese draw.io tool'
  await page.wait_for_function('window.drawioReady === true',timeout=60000)
  frame=page.frame_locator('#editor')
  assert await page.evaluate("document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.isEnabled()"),'Native editor must accept real user input'
  assert await frame.locator('body').inner_text() != ''
  assert await page.evaluate("document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.getModel().getCell('topic').value")=='中心主题'
  await page.evaluate("() => {let g=document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph;g.startEditingAtCell(g.model.getCell('idea1'));}")
  await frame.locator('.mxCellEditor').fill('中文分支编辑')
  await page.keyboard.press('F2')
  assert await page.evaluate("document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.getModel().getCell('idea1').value")=='中文分支编辑'
  await page.evaluate("""() => {const w=document.querySelector('#editor').contentWindow,g=w.toolboxEditor.editor.graph;g.insertVertex(g.getDefaultParent(),'test-chinese','中文流程验收',60,250,160,60,'rounded=1;whiteSpace=wrap;html=1;');}""")
  await page.wait_for_timeout(750)
  async with page.expect_download() as d: await page.get_by_role('button',name='导出 XML',exact=True).click()
  xml=pathlib.Path(await (await d.value).path()).read_text(encoding='utf8'); assert '中文流程验收' in xml
  await page.reload(); await page.wait_for_function('window.drawioReady === true',timeout=60000)
  assert await page.evaluate("!!document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.getModel().getCell('test-chinese')")
  await page.locator('#importFile').set_input_files({'name':'test.drawio','mimeType':'application/xml','buffer':xml.encode()})
  await page.get_by_text('图表已导入',exact=True).wait_for()
  await page.locator('#importFile').set_input_files({'name':'bad.xml','mimeType':'application/xml','buffer':b'<!DOCTYPE a><bad>'})
  await page.get_by_text('导入失败：请选择有效的 draw.io XML 文件',exact=True).wait_for()
  assert await page.evaluate("!!document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.getModel().getCell('test-chinese')"),'Invalid import polluted the good model'
  await page.locator('#importFile').set_input_files({'name':'semantic-invalid.xml','mimeType':'application/xml','buffer':b'<mxGraphModel><nonsense/></mxGraphModel>'})
  await page.get_by_text('导入失败：请选择有效的 draw.io XML 文件',exact=True).wait_for()
  assert await page.evaluate("!!document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.getModel().getCell('test-chinese')"),'Semantic invalid XML polluted model'
  compressed=base64.b64encode(zlib.compress(urllib.parse.quote('<mxGraphModel><nonsense/></mxGraphModel>',safe='').encode())[2:-4]).decode()
  await page.locator('#importFile').set_input_files({'name':'compressed-invalid.drawio','mimeType':'application/xml','buffer':f'<mxfile><diagram>{compressed}</diagram></mxfile>'.encode()})
  await page.get_by_text('导入失败：请选择有效的 draw.io XML 文件',exact=True).wait_for()
  await page.reload(); await page.wait_for_function('window.drawioReady === true',timeout=60000)
  assert await page.evaluate("!!document.querySelector('#editor').contentWindow.toolboxEditor.editor.graph.getModel().getCell('test-chinese')"),'Invalid compressed import overwrote the saved draft'
  await frame.get_by_text('编辑',exact=True).click(); await frame.get_by_text('全选',exact=False).first.wait_for(); await page.keyboard.press('Escape')
  for fmt in ['SVG','PNG']:
   async with page.expect_download() as d: await page.get_by_role('button',name='导出 '+fmt,exact=True).click()
   data=pathlib.Path(await (await d.value).path()).read_bytes()
   assert (b'<svg' in data and '中文流程验收'.encode() in data) if fmt=='SVG' else data[:8]==b'\x89PNG\r\n\x1a\n'
  for w,h in [(1440,900),(1024,768),(768,1024),(390,844),(320,640)]:
   await page.set_viewport_size({'width':w,'height':h}); await page.wait_for_timeout(150)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h)
   assert await page.get_by_role('button',name='导出 XML',exact=True).is_visible()
  assert not errors,errors; assert not missing,missing
  await page.screenshot(path='_scratch/ops-tests/drawio-mobile.png')
  print('PASS original mxGraph Chinese editing / mindmap / XML roundtrip / invalid import protection / IndexedDB reload / SVG+PNG / 5 sizes / zero pageerror+local404')
  await b.close()
asyncio.run(main())
