from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,json
ROOT=Path(__file__).resolve().parents[2]/'toolbox-site';BASE='https://tools.manshii.asia/'
paths=['assets/catalog-base.js','assets/catalog.js','assets/tool-icon-paths.js','licenses/sources.json']
for folder in ['drawio','office-editors','web-ppt']:
 manifest=json.loads((ROOT/'tools'/folder/'manifest.json').read_text())
 paths+=['tools/'+folder+'/manifest.json']
 paths+=['tools/'+folder+'/'+e['file']for e in manifest['files']if folder!='drawio'or not e['file'].startswith('vendor/')]
paths+=['tools/drawio/vendor/js/app.min.js','tools/drawio/vendor/resources/dia_zh.txt','tools/drawio/vendor/styles/grapheditor.css']
def check(path):
 with urllib.request.urlopen(BASE+path+'?release=office-ab7d6f9',timeout=60)as r:data=r.read();assert r.status==200
 assert hashlib.sha256(data).digest()==hashlib.sha256((ROOT/path).read_bytes()).digest(),path
 return path
with ThreadPoolExecutor(max_workers=8)as pool:verified=list(pool.map(check,paths))
print(json.dumps({'https_files_match':len(verified)}))
