import asyncio,io,json,sys,datetime,base64,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qa-office'))
from openpyxl import Workbook,load_workbook
from openpyxl.utils.datetime import CALENDAR_MAC_1904
from openpyxl.styles import PatternFill,Border,Side
from openpyxl.workbook.defined_name import DefinedName
from docx import Document
from playwright.async_api import async_playwright

BASE='http://127.0.0.1:8765/tools/office-editors/'
async def download(page,selector):
    async with page.expect_download() as d: await page.locator(selector).click()
    return Path(await(await d.value).path()).read_bytes()
async def upload(page,name,buffer):
    await page.locator('#importFile').set_input_files({'name':name,'mimeType':'application/zip','buffer':buffer})
    await page.wait_for_function("!document.querySelector('#importButton').disabled")
    return await page.locator('#saveStatus').inner_text()
async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch();page=await browser.new_page()
        await page.goto(BASE+'office.html');await page.wait_for_function('officeApp?.unit')
        w=Workbook();w.epoch=CALENDAR_MAC_1904;s=w.active
        s['A1']=True;s['A2']=False;s['A3']=datetime.datetime(2026,11,12);s['A4']='=IF(A1,123,0)';s['A5']='=1/0'
        s['A6']='#DIV/0!';s['A6'].data_type='e'
        b=io.BytesIO();w.save(b);print('import types',await upload(page,'types.xlsx',b.getvalue()))
        print('snapshot types',await page.evaluate('officeApp.unit.save().sheets[officeApp.unit.save().sheetOrder[0]].cellData'))
        wb=load_workbook(io.BytesIO(await download(page,'#exportOffice')))
        print('export types',[(c.coordinate,str(c.value),c.data_type)for row in wb.active for c in row])
        await page.wait_for_timeout(500)
        print('formula values',await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1:A6').getValues()"))
        w=Workbook();s=w.active;s['A1']=10;s['A2']=20;s['A3']='=SUM(TotalValues)';w.defined_names.add(DefinedName('TotalValues',attr_text="'Sheet'!$A$1:$A$2"));s['B5'].fill=PatternFill('solid',fgColor='FFFF0000');s['B5'].border=Border(bottom=Side(style='thin'));s.row_dimensions[7].height=50;s.row_dimensions[8].hidden=True;b=io.BytesIO();w.save(b)
        print('import styles',await upload(page,'styles.xlsx',b.getvalue()))
        print('styles snapshot',await page.evaluate('officeApp.unit.save().sheets[officeApp.unit.save().sheetOrder[0]]'))
        wb=load_workbook(io.BytesIO(await download(page,'#exportOffice')))
        print('blank style result',wb.active['B5'].fill.patternType,wb.active['B5'].border.bottom.style,'row7',wb.active.row_dimensions[7].height,'row8',wb.active.row_dimensions[8].hidden,'named formula',wb.active['A3'].value,'names',list(wb.defined_names))
        # A final draft-save failure occurs only after the replacement succeeded.
        await page.evaluate("officeApp.unit.getActiveSheet().getRange('B1').setValue('OLD-CONTENT')")
        await page.wait_for_timeout(700)
        await page.evaluate("() => { const original=IDBObjectStore.prototype.put;let calls=0; IDBObjectStore.prototype.put=function(...args){ if(++calls>=2)throw new DOMException('quota','QuotaExceededError'); return original.apply(this,args); }; }")
        w=Workbook();w.active['A1']='NEW-IMPORT';b=io.BytesIO();w.save(b)
        print('failed final flush status',await upload(page,'save-fail.xlsx',b.getvalue()))
        print('failed final flush content',await page.evaluate('officeApp.unit.save().sheets[officeApp.unit.save().sheetOrder[0]].cellData'))
        page=await browser.new_page();await page.goto(BASE+'office.html');await page.wait_for_function('officeApp?.unit')
        xbundle=next(Path('toolbox-site/tools/office-editors/assets').glob('xlsx-bridge-*.js')).name
        encoded=await page.evaluate('''async name=>{const m=await import('./assets/'+name),b=await m.writeXlsx({sheetOrder:['s'],sheets:{s:{name:'s',cellData:{0:{0:{v:'00123',t:4}}}}}});return btoa(String.fromCharCode(...new Uint8Array(await b.arrayBuffer())));}''',xbundle)
        forced=load_workbook(io.BytesIO(base64.b64decode(encoded))).active['A1'];print('force string export',forced.value,forced.data_type)
        bundle=next(Path('toolbox-site/tools/office-editors/assets').glob('univer-word-*.js')).name
        for html in ['<p>before<br>after</p>', '<ol><li>top<ol><li>nested</li></ol></li><li>next</li></ol>', '<table><tr><td rowspan="2">merged</td><td>top</td></tr><tr><td>bottom</td></tr></table>', '<p>before <a href="https://example.org">link</a> after</p>']:
            print('Word roundtrip',await page.evaluate('''async ([bundle,html])=>{const m=await import('./assets/'+bundle);const d=m.htmlToUniver(html,'t');return {input:html,output:m.univerToHTML(d),body:d.body,tableSource:d.tableSource};}''',[bundle,html]))
        png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZfWQAAAAASUVORK5CYII='
        print('terminal image',await page.evaluate('''async ([bundle,png])=>{const m=await import('./assets/'+bundle);const d=m.htmlToUniver('<p>start</p><p><img src="'+png+'"></p>','t');return {out:m.univerToHTML(d),body:d.body,drawings:d.drawings};}''',[bundle,png]))
        await browser.close()
asyncio.run(main())
