import asyncio,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));await page.goto(BASE+'/tools/web-ppt/');await page.get_by_role('button',name='插入文本',exact=True).click();await page.get_by_label('文本内容').fill('预览保护');await page.get_by_label('文本内容').blur();await page.get_by_role('button',name='预览',exact=True).click();await page.keyboard.press('Delete');await page.keyboard.press('Escape');assert '预览保护' in await page.locator('#ppt-main-canvas').inner_text();assert not errors;print('PASS preview keyboard isolation');await b.close()
asyncio.run(main())
