import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  r=await page.goto(BASE+'/tools/office-editors/document.html');assert r.status==200,'document editor missing'
  await page.locator('.tiptap').fill('中文测试 文档')
  await page.locator('#docBold').click();await page.locator('.tiptap').press('End');await page.locator('.tiptap').type(' 加粗')
  await page.wait_for_function("document.querySelector('#saveStatus').textContent==='已保存'")
  async with page.expect_download()as d:await page.locator('#exportJSON').click()
  project=Path(await(await d.value).path()).read_bytes();assert '中文测试'.encode()in project
  await page.reload();await page.locator('.tiptap').wait_for();assert '中文测试' in await page.locator('.tiptap').inner_text()
  await page.locator('#importFile').set_input_files({'name':'bad.json','mimeType':'application/json','buffer':b'{bad'})
  await page.wait_for_function("document.querySelector('#saveStatus').dataset.tone==='error'")
  assert '中文测试' in await page.locator('.tiptap').inner_text()
  await page.locator('#importFile').set_input_files({'name':'saved.json','mimeType':'application/json','buffer':project})
  async with page.expect_download()as d:await page.locator('#exportHTML').click()
  html=Path(await(await d.value).path()).read_text('utf8');assert '中文测试'in html and '<script' not in html
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  assert not errors,errors;print(json.dumps({'tiptap_edit':True,'JSON_roundtrip':True,'HTML_export':True,'refresh_restore':True,'bad_import_preserves':True,'layouts':5,'errors':errors}));await b.close()
asyncio.run(main())
