import asyncio,os,json
from playwright.async_api import async_playwright,expect
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
def project(slides):return {'format':'toolbox-web-ppt','version':1,'name':'边界项目','currentSlideIndex':0,'slides':slides}
def element(i,content='内容'):return {'id':f'e{i}','type':'text','x':0,'y':0,'width':100,'height':50,'content':content}
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto(BASE+'/tools/web-ppt/');await page.get_by_role('button',name='插入文本',exact=True).wait_for()
  async def load(data):
   await page.locator('input[aria-label="导入项目"]').set_input_files({'name':'limit.json','mimeType':'application/json','buffer':json.dumps(data,ensure_ascii=False).encode()});await page.wait_for_timeout(350)
  async def exported():
   async with page.expect_download()as d:await page.get_by_role('button',name='导出项目',exact=True).click()
   return json.load(open(await(await d.value).path(),encoding='utf8'))
  await load(project([{'id':f's{i}','elements':[]}for i in range(200)]));await page.get_by_role('button',name='新增幻灯片',exact=True).click();await page.get_by_role('status').filter(has_text='操作未应用').wait_for();assert len((await exported())['slides'])==200;await page.reload();await page.get_by_role('button',name='第 200 页',exact=True).wait_for()
  await load(project([{'id':'s1','elements':[element(i)for i in range(3000)]}]));await page.get_by_role('button',name='插入文本',exact=True).click();await page.get_by_role('status').filter(has_text='操作未应用').wait_for();assert len((await exported())['slides'][0]['elements'])==3000
  # Maximum-size project, including embedded image payloads, uses the same aggregate cap on every store mutation.
  image='data:image/png;base64,'+'A'*(7*1024*1024)
  elements=[{'id':f'img{i}','type':'image','x':100,'y':100,'width':100,'height':100,'content':image}for i in range(4)]
  await load(project([{'id':'images','elements':elements}]));await page.locator('#ppt-main-canvas img').first.click(force=True);await page.get_by_role('button',name='复制',exact=True).click();await page.get_by_role('button',name='粘贴',exact=True).click();await page.get_by_role('status').filter(has_text='操作未应用').wait_for();assert len((await exported())['slides'][0]['elements'])==4
  await page.evaluate('''async()=>{const d=await new Promise(r=>{const q=indexedDB.open('toolbox-web-ppt',1);q.onsuccess=()=>r(q.result)});await new Promise(r=>{const t=d.transaction('draft','readwrite');t.objectStore('draft').put({broken:'preserve-this'},'current');t.oncomplete=r});d.close()}''');await page.reload();await page.get_by_role('status').filter(has_text='原草稿已保留').wait_for();await page.wait_for_timeout(500)
  saved=await page.evaluate('''async()=>{const d=await new Promise(r=>{const q=indexedDB.open('toolbox-web-ppt',1);q.onsuccess=()=>r(q.result)});return await new Promise(r=>{const q=d.transaction('draft').objectStore('draft').get('current');q.onsuccess=()=>r(q.result)})}''');assert saved=={'broken':'preserve-this'}
  print('PASS 200-page creation cap / 3000-element cap / aggregate embedded-image cap / recovery failure retains original IndexedDB draft');await b.close()
asyncio.run(main())

