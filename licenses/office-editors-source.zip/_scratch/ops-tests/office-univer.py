import asyncio,os,json
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  r=await page.goto(BASE+'/tools/office-editors/office.html');assert r.status==200,'univer missing'
  await page.wait_for_function("window.officeApp?.unit!==undefined")
  await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1:B2').setValues([['中文',12],['数据',34]])")
  await page.wait_for_function("document.querySelector('#saveStatus').textContent==='已保存'")
  async with page.expect_download()as d:await page.locator('#exportProject').click()
  project=Path(await(await d.value).path()).read_bytes();assert '中文'.encode()in project
  await page.reload();await page.wait_for_function("window.officeApp?.unit!==undefined")
  assert await page.evaluate("officeApp.unit.getActiveSheet().getRange('A1').getValue()")=='中文'
  async with page.expect_download()as d:await page.locator('#exportCSV').click()
  csv=Path(await(await d.value).path()).read_text('utf-8-sig');assert '中文'in csv and '34'in csv
  await page.locator('#importFile').set_input_files({'name':'project.json','mimeType':'application/json','buffer':project})
  await page.wait_for_function("document.querySelector('#saveStatus').textContent==='已导入'")
  await page.locator('#officeMode').select_option('doc');await page.wait_for_function("officeApp.mode==='doc'&&officeApp.unit!==undefined")
  inserted=await page.evaluate("officeApp.unit.insertText(0,'文档中文内容')")
  assert inserted,await page.evaluate('officeApp.unit.save()')
  await page.wait_for_function("officeApp.unit.save().body.dataStream.includes('文档中文内容')")
  await page.wait_for_function("document.querySelector('#saveStatus').textContent==='已保存'")
  await page.reload();await page.wait_for_function("officeApp.mode==='doc'&&officeApp.unit!==undefined")
  assert '文档中文内容'in await page.evaluate('officeApp.unit.save().body.dataStream')
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  assert not errors,errors;print(json.dumps({'univer_sheets':True,'JSON_roundtrip':True,'CSV_export':True,'docs_edit':True,'refresh_restore':True,'layouts':5,'errors':errors}));await b.close()
asyncio.run(main())
