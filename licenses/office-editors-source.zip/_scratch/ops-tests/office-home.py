import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page()
  await page.goto(BASE+'/');await page.locator('#toolSearch').wait_for()
  expected={'drawio':'tools/drawio/','tiptap':'tools/office-editors/document.html','web-ppt':'tools/web-ppt/','univer':'tools/office-editors/office.html'}
  for name,path in expected.items():
   tool=await page.evaluate('(id)=>ToolboxCatalog.tools.find(t=>t.id===id)',name);assert tool['href']==path,(name,tool)
   await page.locator('#toolSearch').fill(tool['name']);await page.locator(f'.tool-card[data-tool="{name}"]:not([hidden])').wait_for()
   assert await page.locator(f'.tool-card[data-tool="{name}"] svg').count()>0
  await b.close();print(json.dumps({'home_entries':4,'search':True,'distinct_icons':True}))
asyncio.run(main())
