import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/office-editors/office.html');await page.wait_for_function('window.officeApp?.unit');await page.get_by_text('公式',exact=True).wait_for()
  assert await page.get_by_text('公式',exact=True).is_visible()
  # Native canvas keyboard editing, not only calls through the spreadsheet facade.
  await page.mouse.dblclick(130,233);await page.keyboard.press('ControlOrMeta+a');await page.keyboard.insert_text('键盘输入');await page.keyboard.press('Enter')
  await page.wait_for_function("officeApp.unit.getActiveSheet().getRange('A1').getValue()==='键盘输入'")
  # Imported CSV can exceed the initial grid in both dimensions.
  rows=[','.join([f'行{i}']+['']*25+['末列'])for i in range(1001)]
  page.on('dialog',lambda dialog:dialog.accept())
  await page.locator('#csvFile').set_input_files({'name':'wide.csv','mimeType':'text/csv','buffer':'\r\n'.join(rows).encode()})
  await page.wait_for_function("officeApp.unit.getActiveSheet().getMaxRows()>=1001&&officeApp.unit.getActiveSheet().getMaxColumns()>=27")
  await page.wait_for_function("officeApp.unit.getActiveSheet().getRange('AA1001').getValue()==='末列'")
  assert not errors,errors;await b.close();print(json.dumps({'native_toolbar':True,'keyboard_edit':True,'CSV_grid_expansion':True,'errors':errors}))
asyncio.run(main())
