from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'_scratch/drawio-upstream/src/main/webapp'
dest=ROOT/'toolbox-site/tools/drawio/vendor'
for p in src.rglob('*'):
 rel=p.relative_to(src)
 skip=rel.as_posix() in {'js/integrate.min.js','js/viewer-static.min.js','js/viewer.min.js','js/embed.dev.js'} or ('resources' in rel.parts and p.name.startswith('dia_') and p.name not in {'dia_zh.txt'})
 if p.is_file() and not skip and not {'WEB-INF','META-INF','connect','plugins','diagramly','grapheditor'}.intersection(rel.parts) and p.suffix not in {'.map','.jar'}:
  q=dest/p.relative_to(src)
  if p.name=='LICENSE':q=q.with_name('LICENSE.txt')
  q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copy2(src.parents[2]/'LICENSE',dest/'LICENSE.txt')
print('draw.io runtime staged')
