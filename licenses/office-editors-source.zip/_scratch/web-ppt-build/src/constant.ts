export const initialSlides=[{id:'first-slide',elements:[],background:{color:'#ffffff'}}];
