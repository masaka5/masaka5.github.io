import { Slide } from "./types/presentation";
export type Project = {
  format: "toolbox-web-ppt";
  version: 1;
  name: string;
  slides: Slide[];
  currentSlideIndex: number;
};
const limit = 30 * 1024 * 1024;
export function validate(value: any): Project {
  if (
    !value ||
    value.format !== "toolbox-web-ppt" ||
    value.version !== 1 ||
    typeof value.name !== "string" ||
    value.name.length > 200 ||
    !Array.isArray(value.slides) ||
    value.slides.length < 1 ||
    value.slides.length > 200
  )
    throw Error("项目结构无效");
  const ids = new Set();
  let count = 0;
  const str = (s: any, max = 100000) =>
    typeof s === "string" && s.length <= max;
  const image = (s: any) =>
    str(s, limit) &&
    /^data:image\/(png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$/.test(s);
  const num = (n: any, min = -10000, max = 10000) =>
    typeof n === "number" && Number.isFinite(n) && n >= min && n <= max;
  for (const slide of value.slides) {
    if (
      !str(slide.id, 200) ||
      ids.has(slide.id) ||
      !Array.isArray(slide.elements)
    )
      throw Error("幻灯片结构无效");
    ids.add(slide.id);
    if (
      slide.background &&
      ((slide.background.color &&
        !/^#[0-9a-f]{3,8}$/i.test(slide.background.color)) ||
        (slide.background.image && !image(slide.background.image)))
    )
      throw Error("背景格式无效");
    for (const e of slide.elements) {
      if (
        ++count > 3000 ||
        !str(e.id, 200) ||
        ids.has(e.id) ||
        !["text", "image", "shape", "line"].includes(e.type) ||
        !num(e.x ?? e.left ?? 0) ||
        !num(e.y ?? e.top ?? 0) ||
        !num(e.width, 1) ||
        !num(e.height, 1) ||
        (e.rotation !== undefined && !num(e.rotation)) ||
        !str(e.content ?? "", e.type === "image" ? limit : 100000)
      )
        throw Error("元素结构无效");
      ids.add(e.id);
      if (e.type === "image" && !image(e.content))
        throw Error("图片必须保存在项目中");
      if (e.style) {
        if (typeof e.style !== "object" || Array.isArray(e.style))
          throw Error("样式结构无效");
        const enums = {
          fontStyle: ["normal", "italic"],
          textDecoration: ["none", "underline"],
          textAlign: ["left", "center", "right"],
          strokeLinecap: ["butt", "round", "square"],
        };
        for (const [key, allowed] of Object.entries(enums))
          if (e.style[key] !== undefined && !allowed.includes(e.style[key]))
            throw Error("样式格式无效");
        if (
          e.style.fontWeight !== undefined &&
          !(
            typeof e.style.fontWeight === "number" &&
            num(e.style.fontWeight, 1, 1000)
          )
        )
          throw Error("字重格式无效");
        if (
          e.style.strokeDasharray !== undefined &&
          !/^[0-9 ,.]{0,100}$/.test(e.style.strokeDasharray)
        )
          throw Error("线条样式无效");
        for (const [k, v] of Object.entries(e.style)) {
          if (
            ["color", "backgroundColor", "fill", "stroke"].includes(k) &&
            !/^#[0-9a-f]{3,8}$/i.test(String(v)) &&
            v !== "transparent"
          )
            throw Error("颜色格式无效");
          if (["fontSize", "strokeWidth"].includes(k) && !num(v, 0, 1000))
            throw Error("样式数值无效");
        }
      }
    }
  }
  if (JSON.stringify(value).length > limit) throw Error("项目超过 30 MB");
  return {
    format: "toolbox-web-ppt",
    version: 1,
    name: value.name,
    slides: value.slides,
    currentSlideIndex: Math.min(
      value.slides.length - 1,
      Math.max(
        0,
        Number.isInteger(value.currentSlideIndex) ? value.currentSlideIndex : 0,
      ),
    ),
  };
}
let database: Promise<IDBDatabase>;
function db() {
  return (database ??= new Promise((resolve, reject) => {
    const r = indexedDB.open("toolbox-web-ppt", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("draft");
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  }));
}
export async function readDraft() {
  const d = await db();
  return new Promise<any>((resolve, reject) => {
    const r = d.transaction("draft").objectStore("draft").get("current");
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
export async function saveDraft(project: Project) {
  const d = await db();
  return new Promise<void>((resolve, reject) => {
    const t = d.transaction("draft", "readwrite");
    t.objectStore("draft").put(project, "current");
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}
export function download(data: Blob, name: string) {
  const url = URL.createObjectURL(data),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
export async function exportPpt(project: Project) {
  const { default: PptxGenJS } = await import("pptxgenjs");
  const ppt = new PptxGenJS();
  ppt.defineLayout({ name: "TOOLBOX", width: 10, height: 6 });
  ppt.layout = "TOOLBOX";
  ppt.author = "1103工具箱";
  ppt.title = project.name;
  ppt.lang = "zh-CN";
  for (const s of project.slides) {
    const slide = ppt.addSlide();
    slide.background = { color: (s.background?.color || "#ffffff").slice(1) };
    if (s.background?.image)
      slide.addImage({ data: s.background.image, x: 0, y: 0, w: 10, h: 6 });
    for (const e of s.elements) {
      const st = e.style || {},
        box = {
          x: (e.x ?? e.left ?? 0) / 100,
          y: (e.y ?? e.top ?? 0) / 100,
          w: e.width / 100,
          h: e.height / 100,
          rotate: e.rotation || 0,
        };
      if (e.type === "text")
        slide.addText(e.content || "", {
          ...box,
          fontFace: "Microsoft YaHei",
          fontSize: (st.fontSize || 28) * 0.72,
          color: (st.color || "#172b4d").slice(1),
          bold: Number(st.fontWeight) >= 600,
          align: st.textAlign || "left",
          margin: 0.03,
          breakLine: false,
        });
      else if (e.type === "image") slide.addImage({ ...box, data: e.content });
      else
        slide.addShape(
          e.type === "line"
            ? ppt.ShapeType.line
            : e.content === "circle"
              ? ppt.ShapeType.ellipse
              : e.content === "triangle"
                ? ppt.ShapeType.triangle
                : e.content === "rounded-rectangle"
                  ? ppt.ShapeType.roundRect
                  : ppt.ShapeType.rect,
          {
            ...box,
            fill: { color: (st.fill || "#4096ff").slice(1) },
            line: {
              color: (st.stroke || "#1677ff").slice(1),
              width: st.strokeWidth || 1,
            },
          },
        );
    }
  }
  await ppt.writeFile({ fileName: project.name + ".pptx" });
}
