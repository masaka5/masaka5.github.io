import React from "react";
interface Props {
  x: number;
  y: number;
  visible: boolean;
  onClose: () => void;
  onSelect: (key: string) => void;
}
export default function ContextMenu({
  x,
  y,
  visible,
  onClose,
  onSelect,
}: Props) {
  if (!visible) return null;
  return (
    <div
      role="menu"
      style={{
        position: "fixed",
        left: x,
        top: y,
        zIndex: 2000,
        background: "#fff",
        padding: 6,
        border: "1px solid #d6deea",
        boxShadow: "0 4px 20px #14294720",
      }}
      onMouseLeave={onClose}
    >
      {[
        ["copy", "复制"],
        ["paste", "粘贴"],
        ["delete", "删除"],
        ["bringForward", "上移一层"],
        ["sendBackward", "下移一层"],
      ].map(([key, label]) => (
        <button
          role="menuitem"
          style={{
            display: "block",
            width: "100%",
            textAlign: "left",
            border: 0,
          }}
          key={key}
          onClick={() => onSelect(key)}
        >
          {label}
        </button>
      ))}
    </div>
  );
}
