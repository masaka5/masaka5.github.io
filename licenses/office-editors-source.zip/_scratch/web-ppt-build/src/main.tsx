import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import Canvas from "./components/Canvas";
import { usePresentationStore as store } from "./stores/presentationStore";
import {
  Project,
  validate,
  readDraft,
  saveDraft,
  download,
  exportPpt,
} from "./project";
import "./style.css";
function App() {
  const s = store(),
    [ready, setReady] = useState(false),
    [status, setStatus] = useState("正在读取草稿…"),
    [preview, setPreview] = useState(false),
    [page, setPage] = useState(0),
    [scale, setScale] = useState(0.7),
    [busy, setBusy] = useState(false);
  const stage = useRef<HTMLDivElement>(null),
    importRef = useRef<HTMLInputElement>(null),
    imageRef = useRef<HTMLInputElement>(null),
    saveNumber = useRef(0),
    recoveryBlocked = useRef(false);
  const project = (): Project => ({
    format: "toolbox-web-ppt",
    version: 1,
    name: store.getState().name,
    slides: store.getState().slides,
    currentSlideIndex: store.getState().currentSlideIndex,
  });
  useEffect(() => {
    let alive = true;
    readDraft()
      .then((v) => {
        if (v)
          store
            .getState()
            .loadState({ ...validate(v), selectedElementIds: [] });
        if (alive) setStatus(v ? "已恢复本地草稿" : "更改自动保存在此浏览器");
      })
      .catch(() => {
        recoveryBlocked.current = true;
        setStatus(
          "草稿读取失败，原草稿已保留；自动保存已暂停，请导入有效项目后继续",
        );
      })
      .finally(() => {
        if (alive) {
          setReady(true);
          store.temporal.getState().clear();
        }
      });
    return () => {
      alive = false;
    };
  }, []);
  useEffect(() => {
    if (!ready || recoveryBlocked.current) return;
    const id = ++saveNumber.current;
    setStatus("正在保存…");
    saveDraft(project())
      .then(() => {
        if (id === saveNumber.current) setStatus("已保存到本地");
      })
      .catch(() => setStatus("本地保存失败，请导出项目备份"));
  }, [s.slides, s.name, s.currentSlideIndex, ready]);
  useEffect(() => {
    const resize = () => {
      const r = stage.current?.getBoundingClientRect();
      if (r)
        setScale(
          Math.max(
            0.1,
            Math.min((r.width - 32) / 1000, (r.height - 32) / 600, 1),
          ),
        );
    };
    const obs = new ResizeObserver(resize);
    if (stage.current) obs.observe(stage.current);
    resize();
    return () => obs.disconnect();
  }, [ready, preview]);
  useEffect(() => {
    if (!preview) return;
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPreview(false);
      if (["ArrowRight", "PageDown", " "].includes(e.key)) {
        e.preventDefault();
        setPage((v) => Math.min(v + 1, s.slides.length - 1));
      }
      if (["ArrowLeft", "PageUp"].includes(e.key)) {
        e.preventDefault();
        setPage((v) => Math.max(v - 1, 0));
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [preview, s.slides.length]);
  useEffect(() => {
    const limited = (e: Event) =>
      setStatus(
        "操作未应用：" + (e as CustomEvent).detail + "。请删减项目后重试",
      );
    window.addEventListener("project-limit", limited);
    return () => window.removeEventListener("project-limit", limited);
  }, []);
  const selected = s.slides[s.currentSlideIndex]?.elements.find(
    (e) => e.id === s.selectedElementIds[0],
  );
  const update = (v: any) => selected && s.updateElement(selected.id, v);
  const add = (type: "text" | "shape", content: string) =>
    s.addElement({
      type,
      content,
      left: 100,
      top: 100,
      width: type === "text" ? 420 : 180,
      height: type === "text" ? 90 : 140,
      style:
        type === "text"
          ? { fontSize: 32, color: "#172b4d" }
          : { fill: "#4096ff", stroke: "#1677ff", strokeWidth: 2 },
    });
  const importProject = async (file?: File) => {
    if (!file) return;
    try {
      if (file.size > 30 * 1024 * 1024) throw Error("项目超过 30 MB");
      const p = validate(
        JSON.parse(
          await file.text().catch(() => {
            throw Error("无法读取项目文件");
          }),
        ),
      );
      await saveDraft(p);
      recoveryBlocked.current = false;
      s.loadState({ ...p, selectedElementIds: [] });
      store.temporal.getState().clear();
      setStatus("项目已导入");
    } catch (e) {
      setStatus(
        "导入失败：" +
          (e instanceof SyntaxError
            ? "项目文件不是有效的 JSON"
            : (e as Error).message),
      );
    } finally {
      if (importRef.current) importRef.current.value = "";
    }
  };
  const image = async (file?: File) => {
    if (!file) return;
    try {
      if (
        file.size > 8 * 1024 * 1024 ||
        !["image/png", "image/jpeg", "image/gif", "image/webp"].includes(
          file.type,
        )
      )
        throw Error("请选择 8 MB 以内的 PNG、JPEG、GIF 或 WebP 图片");
      const data = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result));
        r.onerror = reject;
        r.readAsDataURL(file);
      });
      const img = new Image();
      img.src = data;
      await img.decode();
      const w = Math.min(500, img.naturalWidth),
        h = (w * img.naturalHeight) / img.naturalWidth;
      s.addElement({
        type: "image",
        content: data,
        left: 100,
        top: 100,
        width: w,
        height: h,
      });
    } catch (e) {
      setStatus("图片读取失败：" + (e as Error).message);
    } finally {
      if (imageRef.current) imageRef.current.value = "";
    }
  };
  return (
    <div className="app">
      <header>
        <a href="../../">← 工具箱</a>
        <strong>演示文稿</strong>
        <input
          aria-label="演示文稿名称"
          maxLength={200}
          value={s.name}
          onChange={(e) => s.setName(e.target.value || "未命名演示")}
        />
      </header>
      <nav aria-label="编辑工具栏">
        <button disabled={!ready} onClick={() => add("text", "输入文本")}>
          插入文本
        </button>
        <button disabled={!ready} onClick={() => imageRef.current?.click()}>
          插入图片
        </button>
        <select
          aria-label="插入形状"
          defaultValue=""
          onChange={(e) => {
            if (e.target.value) add("shape", e.target.value);
            e.target.value = "";
          }}
        >
          <option value="">插入形状</option>
          <option value="rectangle">矩形</option>
          <option value="circle">圆形</option>
          <option value="triangle">三角形</option>
          <option value="rounded-rectangle">圆角矩形</option>
        </select>
        <span className="divider" />
        <button onClick={() => store.temporal.getState().undo()}>撤销</button>
        <button onClick={() => store.temporal.getState().redo()}>重做</button>
        <button disabled={!selected} onClick={() => s.copyElements()}>
          复制
        </button>
        <button onClick={() => s.pasteElements()}>粘贴</button>
        <button
          disabled={!selected}
          onClick={() => s.selectedElementIds.forEach(s.deleteElement)}
        >
          删除元素
        </button>
        <span className="divider" />
        <button
          onClick={() =>
            download(
              new Blob([JSON.stringify(project(), null, 2)], {
                type: "application/json",
              }),
              s.name + ".json",
            )
          }
        >
          导出项目
        </button>
        <button onClick={() => importRef.current?.click()}>导入项目</button>
        <button
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            try {
              await exportPpt(project());
              setStatus("演示文件已导出");
            } catch {
              setStatus("导出失败，请重试");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "正在导出…" : "导出演示文件"}
        </button>
        <button
          className="primary"
          onClick={() => {
            setPage(s.currentSlideIndex);
            setPreview(true);
          }}
        >
          预览
        </button>
      </nav>
      <input
        ref={importRef}
        hidden
        type="file"
        aria-label="导入项目"
        accept=".json,application/json"
        onChange={(e) => importProject(e.target.files?.[0])}
      />
      <input
        ref={imageRef}
        hidden
        type="file"
        aria-label="上传图片"
        accept="image/png,image/jpeg,image/gif,image/webp"
        onChange={(e) => image(e.target.files?.[0])}
      />
      <main>
        <aside>
          <div className="slide-actions">
            <button onClick={s.addSlide}>新增幻灯片</button>
            <button
              disabled={s.slides.length === 1}
              onClick={() => s.deleteSlide(s.currentSlideIndex)}
            >
              删除本页
            </button>
          </div>
          <div className="slides">
            {s.slides.map((slide, i) => (
              <button
                key={slide.id}
                aria-label={`第 ${i + 1} 页`}
                aria-current={i === s.currentSlideIndex}
                onClick={() => s.setCurrentSlideIndex(i)}
              >
                <span>{i + 1}</span>
                <Canvas
                  slideIndex={i}
                  interactive={false}
                  embedded
                  width={1000}
                  height={600}
                  scale={0.14}
                />
              </button>
            ))}
          </div>
        </aside>
        <section className="workspace">
          <div className="workspace-heading">
            第 {s.currentSlideIndex + 1} 页 / 共 {s.slides.length} 页{" "}
            <span>拖动元素调整位置 · 选中文本后编辑</span>
          </div>
          <div className="stage" ref={stage}>
            <div style={{ width: 1000 * scale, height: 600 * scale }}>
              <div
                style={{
                  width: 1000,
                  height: 600,
                  transform: `scale(${scale})`,
                  transformOrigin: "top left",
                }}
              >
                <Canvas
                  embedded
                  interactive={!preview}
                  width={1000}
                  height={600}
                />
              </div>
            </div>
          </div>
          <div className="properties" aria-label="元素属性">
            {selected ? (
              <>
                <strong>
                  {selected.type === "text"
                    ? "文本"
                    : selected.type === "image"
                      ? "图片"
                      : "形状"}
                  属性
                </strong>
                {selected.type === "text" && (
                  <label>
                    内容
                    <input
                      aria-label="文本内容"
                      value={selected.content || ""}
                      onChange={(e) => update({ content: e.target.value })}
                    />
                  </label>
                )}
                {(["x", "y", "width", "height"] as const).map((k, i) => (
                  <label key={k}>
                    {["横坐标", "纵坐标", "宽度", "高度"][i]}
                    <input
                      aria-label={["横坐标", "纵坐标", "宽度", "高度"][i]}
                      type="number"
                      value={Math.round(selected[k] ?? 0)}
                      onChange={(e) => {
                        const n = Number(e.target.value);
                        if (Number.isFinite(n))
                          update({
                            [k]: Math.max(
                              i > 1 ? 1 : -10000,
                              Math.min(10000, n),
                            ),
                          });
                      }}
                    />
                  </label>
                ))}
                <label>
                  颜色
                  <input
                    type="color"
                    aria-label="元素颜色"
                    value={
                      selected.style?.color || selected.style?.fill || "#4096ff"
                    }
                    onChange={(e) =>
                      update({
                        style: {
                          ...selected.style,
                          [selected.type === "text" ? "color" : "fill"]:
                            e.target.value,
                        },
                      })
                    }
                  />
                </label>
                {selected.type === "text" && (
                  <label>
                    字号
                    <input
                      aria-label="字号"
                      type="number"
                      min={1}
                      max={300}
                      value={selected.style?.fontSize || 32}
                      onChange={(e) =>
                        update({
                          style: {
                            ...selected.style,
                            fontSize: Math.max(
                              1,
                              Math.min(300, Number(e.target.value)),
                            ),
                          },
                        })
                      }
                    />
                  </label>
                )}
                <button onClick={s.bringForward}>上移一层</button>
                <button onClick={s.sendBackward}>下移一层</button>
              </>
            ) : (
              <span>选择元素以编辑属性</span>
            )}
          </div>
        </section>
      </main>
      <footer role="status">
        {status}
        <span>仅在本机处理 · 图片随项目保存</span>
      </footer>
      {preview && (
        <div
          className="preview"
          role="dialog"
          aria-label="演示预览"
          aria-modal="true"
        >
          <div className="preview-board">
            <Canvas
              slideIndex={page}
              interactive={false}
              embedded
              width={1000}
              height={600}
              scale={Math.min(
                (window.innerWidth - 32) / 1000,
                (window.innerHeight - 110) / 600,
                1.4,
              )}
            />
          </div>
          <div className="preview-controls">
            <button
              onClick={() => setPage(Math.max(page - 1, 0))}
              disabled={page === 0}
            >
              上一页
            </button>
            <span>
              第 {page + 1} / {s.slides.length} 页
            </span>
            <button
              onClick={() => setPage(Math.min(page + 1, s.slides.length - 1))}
              disabled={page === s.slides.length - 1}
            >
              下一页
            </button>
            <button onClick={() => setPreview(false)}>退出预览</button>
          </div>
        </div>
      )}
    </div>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
