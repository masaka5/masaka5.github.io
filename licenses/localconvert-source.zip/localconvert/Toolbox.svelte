<script lang="ts">
 import {onMount,untrack,tick} from 'svelte';import Toasts from './src/lib/components/layout/Toasts.svelte';import Dialogs from './src/lib/components/layout/Dialogs.svelte';import {Settings} from './src/lib/sections/settings/index.svelte';import {isMobile,effects,theme,files} from './src/lib/store/index.svelte';
 import {restore,snapshot,persist,flush} from './src/lib/store/recovery';
 import type {VertFile} from './src/lib/types';import type {Component} from 'svelte';
 let recovered=$state(false);let previous=new Set<VertFile>();
 const modules=import.meta.glob<{default:Component}>('./src/routes/{pdf-tools,image-tools,dev-tools}/*/+page.svelte');
 const slug=new URLSearchParams(location.search).get('tool')||'convert';
 let workspace:HTMLElement|undefined=$state();let scrollReady=false;let scrollEdited=false;
 const scrollKey='toolbox-localconvert-scroll:'+slug;
 function saveScroll(){if(!scrollReady)return;scrollEdited=true;try{sessionStorage.setItem(scrollKey,String(workspace?.scrollTop||0));}catch{}}
 const titles=JSON.parse(import.meta.env.VITE_TOOLBOX_TITLES||'{}');
 const loader=slug==='convert'?()=>import('./src/routes/convert/+page.svelte'):modules[`./src/routes/${slug}/+page.svelte`];
 const promise=(async()=>{files.files=await restore();recovered=true;return loader?loader():Promise.reject(new Error('未找到工具'));})();const title=titles[slug]||'文件转换';
 $effect(()=>{if(!recovered)return;const current=new Set(files.files);const value=snapshot(files.files);untrack(()=>{for(const file of previous)if(!current.has(file))file.dispose();previous=current;persist(value);});});
 onMount(()=>{const save=()=>{if(recovered){persist(snapshot(files.files));flush();}};addEventListener('pagehide',save);const visibility=()=>{if(document.visibilityState==='hidden')save();};document.addEventListener('visibilitychange',visibility);return()=>{removeEventListener('pagehide',save);document.removeEventListener('visibilitychange',visibility);};});
 onMount(()=>{let saved=0;try{saved=Number(sessionStorage.getItem(scrollKey))||0;}catch{};void promise.then(async()=>{await tick();scrollReady=true;if(workspace&&!scrollEdited)workspace.scrollTop=Math.max(0,Math.min(saved,workspace.scrollHeight));}).catch(()=>{});});
 onMount(()=>{isMobile.set(innerWidth<=768);effects.set(false);theme.set('light');document.documentElement.classList.add('light');Settings.instance.settings.filenameFormat='%name%';Settings.instance.load();Settings.instance.settings.plausible=false;const resize=()=>isMobile.set(innerWidth<=768);addEventListener('resize',resize);return()=>removeEventListener('resize',resize);});
</script>
<Dialogs/>
<svelte:head><title>{title} · 工具箱</title></svelte:head>
<div class="toolbox-shell"><header class="toolbox-header"><a href="../../">← 工具箱</a><h1>{title}</h1><span>文件工具</span></header>
<!-- Focusable internal scroller lets keyboard users reach results below the viewport. -->
<!-- svelte-ignore a11y_no_noninteractive_tabindex -->
<main class="toolbox-workspace" bind:this={workspace} onscroll={saveScroll} tabindex="0" aria-label={title}>{#await promise}<p class="toolbox-loading">正在加载…</p>{:then module}<module.default/>{:catch error}<div class="toolbox-loading"><p>工具加载失败：{error.message}</p><button onclick={()=>location.reload()}>重新加载</button></div>{/await}</main><footer class="toolbox-footer"><span></span></footer></div><Toasts/>
