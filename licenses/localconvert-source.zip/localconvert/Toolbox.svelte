<script lang="ts">
 import {onMount} from 'svelte';import Toasts from './src/lib/components/layout/Toasts.svelte';import Dialogs from './src/lib/components/layout/Dialogs.svelte';import {Settings} from './src/lib/sections/settings/index.svelte';import {isMobile,effects,theme} from './src/lib/store/index.svelte';
 const modules=import.meta.glob('./src/routes/{pdf-tools,image-tools,dev-tools}/*/+page.svelte');
 const slug=new URLSearchParams(location.search).get('tool')||'convert';
 const titles=JSON.parse(import.meta.env.VITE_TOOLBOX_TITLES||'{}');
 const loader=slug==='convert'?()=>import('./src/routes/convert/+page.svelte'):modules[`./src/routes/${slug}/+page.svelte`];
 const promise=loader?loader():Promise.reject(new Error('未找到工具'));const title=titles[slug]||'文件转换';
 onMount(()=>{isMobile.set(innerWidth<=768);effects.set(false);theme.set('light');document.documentElement.classList.add('light');Settings.instance.settings.filenameFormat='%name%';Settings.instance.load();Settings.instance.settings.plausible=false;const resize=()=>isMobile.set(innerWidth<=768);addEventListener('resize',resize);return()=>removeEventListener('resize',resize);});
</script>
<Dialogs/>
<svelte:head><title>{title} · 工具箱</title></svelte:head>
<div class="toolbox-shell"><header class="toolbox-header"><a href="../../">← 工具箱</a><h1>{title}</h1><span>文件工具</span></header>
<!-- Focusable internal scroller lets keyboard users reach results below the viewport. -->
<!-- svelte-ignore a11y_no_noninteractive_tabindex -->
<main class="toolbox-workspace" tabindex="0" aria-label={title}>{#await promise}<p class="toolbox-loading">正在加载…</p>{:then module}<module.default/>{:catch error}<div class="toolbox-loading"><p>工具加载失败：{error.message}</p><button onclick={()=>location.reload()}>重新加载</button></div>{/await}</main><footer class="toolbox-footer"><span></span></footer></div><Toasts/>
