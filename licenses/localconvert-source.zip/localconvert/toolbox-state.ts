export const page={url:new URL(location.href),params:{},data:{},route:{id:null},status:200,error:null};
