export async function loadFontForLocale(_locale:string):Promise<void>{document.documentElement.style.setProperty('--font-body','"Microsoft YaHei","Segoe UI",system-ui,sans-serif');}
