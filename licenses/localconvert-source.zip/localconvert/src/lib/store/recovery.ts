/** Explicit, bounded, local conversion snapshot. No workers, credentials or URLs. */
import { VertFile } from '$lib/types';
import { loadConverters } from '$lib/converters';
import type { Converter } from '$lib/converters/converter.svelte';

export const CACHE = { database: 'toolbox-localconvert-v1', store: 'snapshots', key: 'convert',
  maxBytes: 64 * 1024 * 1024, maxFiles: 32, maxAge: 7 * 86400 * 1000, timeout: 1800 };
type Options = Pick<VertFile, 'optQuality'|'optBitrate'|'optWidth'|'optHeight'|'optTrimStart'|'optTrimEnd'>;
type Item = { file: File; to: string; options: Options; converterNames?: string[]; output: { file: File; to: string } | null };
type Snapshot = { version: 1; savedAt: number; items: Item[] };
let database: IDBDatabase | null = null;
let pending: Snapshot | null = null;
let writing = false;
let stamp = 0;

function open(): Promise<IDBDatabase | null> {
  return new Promise(resolve => {
    let settled = false;
    const finish = (db: IDBDatabase | null) => {
      if (settled) { db?.close(); return; }
      settled = true; clearTimeout(timer); resolve(db);
    };
    const timer = setTimeout(() => finish(null), CACHE.timeout);
    try {
      const request = indexedDB.open(CACHE.database, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(CACHE.store);
      request.onsuccess = () => finish(request.result);
      request.onerror = request.onblocked = () => finish(null);
    } catch { finish(null); }
  });
}

function transaction<T>(mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    if (!database) { reject(new Error('Cache unavailable')); return; }
    try {
      const tx = database.transaction(CACHE.store, mode);
      const request = action(tx.objectStore(CACHE.store));
      const timer = setTimeout(() => { try { tx.abort(); } catch {} reject(new Error('Cache timeout')); }, CACHE.timeout);
      tx.oncomplete = () => { clearTimeout(timer); resolve(request.result); };
      tx.onabort = tx.onerror = () => { clearTimeout(timer); reject(tx.error || new Error('Cache transaction failed')); };
    } catch (error) { reject(error); }
  });
}

const format = (v: unknown): v is string => typeof v === 'string' && /^\.[a-z0-9]{1,16}$/i.test(v);
const validFile = (v: unknown): v is File => v instanceof Blob && typeof (v as File).name === 'string' && (v as File).name.length <= 1024;
function options(value: Partial<Options> | undefined): Options {
  const number = (v: unknown, max: number, fallback: number | null = null) =>
    typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= max ? v : fallback;
  return { optQuality: number(value?.optQuality, 100), optWidth: number(value?.optWidth, 100000),
    optHeight: number(value?.optHeight, 100000), optTrimStart: number(value?.optTrimStart, 864000, 0)!,
    optTrimEnd: number(value?.optTrimEnd, 864000, 0)!,
    optBitrate: typeof value?.optBitrate === 'string' && /^[a-z0-9.]{1,12}$/i.test(value.optBitrate) ? value.optBitrate : null };
}
const named = (v: File) => new File([v], v.name, { type: v.type, lastModified: v.lastModified });

/** Last-added items win; oversized entries evict their previous persisted copy. */
export function snapshot(list: VertFile[]): Snapshot {
  let bytes = 0;
  const items: Item[] = [];
  for (let i = list.length - 1; i >= 0 && items.length < CACHE.maxFiles; i--) {
    const item = list[i];
    const output = item.result ? { file: item.result.file, to: item.result.to } : null;
    const size = item.file.size + (output?.file.size || 0);
    if (!validFile(item.file) || !format(item.to) || size + bytes > CACHE.maxBytes) continue;
    bytes += size;
    items.unshift({ file: item.file, to: item.to, options: options(item),
      converterNames: item.converters.map(c=>c.name).slice(0,10), output });
  }
  stamp = Math.max(Date.now(), stamp + 0.01);
  return { version: 1, savedAt: stamp, items };
}

export async function restore(): Promise<VertFile[]> {
  database = await open();
  if (!database) return [];
  database.onversionchange = () => { database?.close(); database = null; };
  try {
    const data = await transaction<Snapshot>('readonly', store => store.get(CACHE.key));
    if (!data) return [];
    if (data.version !== 1 || !Number.isFinite(data.savedAt) || data.savedAt > Date.now() + 60000 || Date.now() - data.savedAt > CACHE.maxAge || !Array.isArray(data.items) || data.items.length > CACHE.maxFiles)
      throw new Error('Invalid or expired snapshot');
    let size = 0;
    for (const row of data.items) {
      if (!row || !validFile(row.file) || !format(row.to) || (row.output && (!validFile(row.output.file) || !format(row.output.to)))) throw new Error('Invalid cached file');
      size += row.file.size + (row.output?.file.size || 0);
    }
    if (size > CACHE.maxBytes) throw new Error('Snapshot exceeds cache limit');
    const converters: Converter[] = data.items.length ? await loadConverters() : [];
    return data.items.map(row => {
      const file = new VertFile(named(row.file), row.to, undefined,
        converters.filter(c => c.formatStrings().includes('.' + row.file.name.split('.').pop()?.toLowerCase()) ||
          (row.file.name.toLowerCase().endsWith('.zip') && Array.isArray(row.converterNames) && row.converterNames.includes(c.name))));
      Object.assign(file, options(row.options));
      file.restored = true;
      // Recreate a current-document preview URL; never trust a serialized blob URL.
      if (file.file.type.startsWith('image/') || /\.(png|jpe?g|gif|webp|avif|bmp)$/i.test(file.name))
        file.blobUrl = URL.createObjectURL(file.file);
      if (row.output) file.result = new VertFile(named(row.output.file), row.output.to);
      return file;
    });
  } catch {
    try { await transaction('readwrite', store => store.delete(CACHE.key)); } catch {}
    return [];
  }
}

/** One ordered writer with a single newest pending snapshot, never a stale queue. */
export function persist(value: Snapshot) {
  if (!database) return;
  pending = value;
  if (writing) return;
  void drain();
}
/** Queue the latest state before a document leaves; IndexedDB orders readwrite transactions. */
export function flush() {
  if (!pending || !database) return;
  const value = pending; pending = null;
  void transaction('readwrite', store => store.put(value, CACHE.key)).catch(() => discardOlder(value.savedAt));
}
async function discardOlder(savedAt: number) {
  try {
    await transaction('readwrite', store => {
      const read = store.get(CACHE.key);
      read.onsuccess = () => { if (!read.result || !Number.isFinite(read.result.savedAt) || read.result.savedAt <= savedAt) store.delete(CACHE.key); };
      return read;
    });
  } catch {}
}
async function drain() {
  writing = true;
  while (pending && database) {
    const value = pending; pending = null;
    try { await transaction('readwrite', store => store.put(value, CACHE.key)); }
    catch {
      // Quota/security/corrupt cache must not resurrect an older snapshot.
      await discardOlder(value.savedAt);
    }
  }
  writing = false;
}

export function readJsonDraft(): { input?: string; indent?: number; action?: 'format'|'minify'|null } {
  try {
    const value = localStorage.getItem('toolbox-localconvert-json-v1');
    if (!value || value.length > 256 * 1024) return {};
    const data = JSON.parse(value);
    return { input: typeof data.input === 'string' ? data.input : undefined, indent: data.indent === 4 ? 4 : 2,
      action: data.action === 'format' || data.action === 'minify' ? data.action : null };
  } catch { return {}; }
}
export function saveJsonDraft(input: string, indent: number, action: 'format'|'minify'|null = null) {
  try {
    const value = JSON.stringify({ input, indent, action });
    if (value.length > 256 * 1024) localStorage.removeItem('toolbox-localconvert-json-v1');
    else localStorage.setItem('toolbox-localconvert-json-v1', value);
  } catch { /* Storage-disabled mode remains fully usable. */ }
}
