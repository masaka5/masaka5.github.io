<script lang="ts">
	import { page_titles_home, meta_descriptions_home } from '$lib/paraglide/messages/_barrel.js';
	import { localizeHref } from '$lib/paraglide/runtime';
	import Uploader from "$lib/components/functional/Uploader.svelte";
	import clsx from "clsx";
	import { Check, ShieldCheck, Code, Ban, ChevronDown, FileText, Palette, Wrench, ZapIcon } from "lucide-svelte";
	import { landing_pills_no_uploads, landing_pills_tools_count, landing_pills_open_source, landing_pills_works_locally, landing_toolkit_pdf_title, landing_toolkit_pdf_desc, landing_toolkit_pdf_count, landing_toolkit_image_title, landing_toolkit_image_desc, landing_toolkit_image_count, landing_toolkit_dev_title, landing_toolkit_dev_desc, landing_toolkit_dev_count, landing_faq_q1, landing_faq_a1, landing_faq_q2, landing_faq_a2, landing_faq_q3, landing_faq_a3, landing_faq_q4, landing_faq_a4, landing_faq_q5, landing_faq_a5, upload_title, upload_subtitle, landing_toolkit_label, landing_toolkit_title, landing_toolkit_explore, landing_formats_label, landing_formats_title, landing_gpu_badge, landing_gpu_title, landing_gpu_desc, landing_gpu_full_label, landing_gpu_input_label, landing_privacy_label, landing_privacy_title, landing_privacy_point1, landing_privacy_point2, landing_privacy_point3, landing_faq_label, landing_faq_title } from "$lib/paraglide/messages/_barrel.js";
	import { onMount } from "svelte";

	let formatExplorerVisible = $state(false);
	let formatSentinel = $state<HTMLDivElement>();

	onMount(() => {
		if (!formatSentinel) return;
		const observer = new IntersectionObserver(
			([entry]) => {
				if (entry.isIntersecting) {
					formatExplorerVisible = true;
					observer.disconnect();
				}
			},
			{ rootMargin: "200px" },
		);
		observer.observe(formatSentinel);
		return () => observer.disconnect();
	});

	import privacyBadge from "$lib/assets/privacy-badge.webp";

	const pills = [
		{ icon: Ban, label: landing_pills_no_uploads() },
		{ icon: Wrench, label: landing_pills_tools_count() },
		{ icon: Code, label: landing_pills_open_source() },
		{ icon: ShieldCheck, label: landing_pills_works_locally() },
	];

	const toolkitCategories = [
		{
			title: landing_toolkit_pdf_title(),
			desc: landing_toolkit_pdf_desc(),
			count: landing_toolkit_pdf_count(),
			href: "/pdf-tools/",
			color: "green" as const,
			icon: FileText,
		},
		{
			title: landing_toolkit_image_title(),
			desc: landing_toolkit_image_desc(),
			count: landing_toolkit_image_count(),
			href: "/image-tools/",
			color: "blue" as const,
			icon: Palette,
		},
		{
			title: landing_toolkit_dev_title(),
			desc: landing_toolkit_dev_desc(),
			count: landing_toolkit_dev_count(),
			href: "/dev-tools/",
			color: "purple" as const,
			icon: Code,
		},
	];

	const faqs = [
		{ q: landing_faq_q1(), a: landing_faq_a1() },
		{ q: landing_faq_q2(), a: landing_faq_a2() },
		{ q: landing_faq_q3(), a: landing_faq_a3() },
		{ q: landing_faq_q4(), a: landing_faq_a4() },
		{ q: landing_faq_q5(), a: landing_faq_a5() },
	];

	const softwareSchema = JSON.stringify({
		"@context": "https://schema.org",
		"@type": "SoftwareApplication",
		name: "LocalConvert",
		applicationCategory: "UtilitiesApplication",
		operatingSystem: "Web",
		description: "Free, private toolkit with 39 tools for PDFs, images, and developer workflows — all running in your browser. No uploads, no server.",
		url: "https://localconvert.app",
		offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
		featureList: [
			"No server uploads \u2014 100% local processing",
			"21 PDF tools (merge, split, compress, watermark, sign, edit, Word/Excel to PDF, and more)",
			"10 image tools (crop, resize, filters, blur, watermark, meme generator)",
			"8 developer tools (JSON formatter, hash generator, Base64, diff, markdown)",
			"200+ format conversions (images, audio, video, documents)",
			"Works offline as a PWA",
		],
	});

	const websiteSchema = JSON.stringify({
		"@context": "https://schema.org",
		"@type": "WebSite",
		name: "LocalConvert",
		url: "https://localconvert.app",
		potentialAction: {
			"@type": "SearchAction",
			target: { "@type": "EntryPoint", urlTemplate: "https://localconvert.app/{search_term_string}-converter/" },
			"query-input": "required name=search_term_string",
		},
	});
</script>



<!-- ═══ HERO ═══ -->
<section class="hero-section relative w-full overflow-hidden">
	<div class="hero-bg absolute inset-0"></div>
	<div class="hero-overlay absolute inset-0"></div>

	<div class="relative max-w-5xl mx-auto px-6 md:px-8 pt-14 md:pt-24 pb-20 md:pb-32 flex flex-col items-center">

		<!-- Pills -->
		<div class="flex flex-wrap justify-center gap-2 mb-8 hero-animate">
			{#each pills as pill}
				{@const Icon = pill.icon}
				<span class="pill">
					<Icon size="12" strokeWidth={2.5} />
					{pill.label}
				</span>
			{/each}
		</div>

		<!-- Headline (no animation; stays in final position so it's an instant LCP candidate) -->
		<h1 class="hero-headline">
			{upload_title()}
		</h1>

		<!-- Uploader -->
		<div class="w-full max-w-2xl mt-10 mb-6 hero-animate delay-2">
			<Uploader class="w-full" />
		</div>

		<!-- Subtitle -->
		<p class="hero-subhead hero-animate delay-3">
			{upload_subtitle()}
		</p>
	</div>
</section>

<!-- ═══ TOOLKIT ═══ -->
<section class="section-wrapper">
	<div class="section-inner">
		<div class="section-label">{landing_toolkit_label()}</div>
		<h2 class="section-headline">{landing_toolkit_title()}</h2>

		<div class="toolkit-grid">
			{#each toolkitCategories as cat, i}
				{@const Icon = cat.icon}
				<a href={localizeHref(cat.href)} class={clsx("toolkit-card", `toolkit-card--${cat.color}`, "fade-in-up", i === 0 && "fade-delay-1", i === 1 && "fade-delay-2", i === 2 && "fade-delay-3")}>
					<div class="toolkit-card-header">
						<div class={clsx("toolkit-icon", `toolkit-icon--${cat.color}`)}>
							<Icon size="20" />
						</div>
						<span class={clsx("toolkit-count", `toolkit-count--${cat.color}`)}>{cat.count}</span>
					</div>
					<h3 class="toolkit-title">{cat.title}</h3>
					<p class="toolkit-desc">{cat.desc}</p>
					<span class="toolkit-explore">
						{landing_toolkit_explore()}
					</span>
				</a>
			{/each}
		</div>
	</div>
</section>

<!-- ═══ FORMATS ═══ -->
<section class="section-wrapper section-alt">
	<div class="section-inner">
		<div class="section-label">{landing_formats_label()}</div>
		<h2 class="section-headline">{landing_formats_title()}</h2>

		<div bind:this={formatSentinel}>
			{#if formatExplorerVisible}
				{#await import("$lib/components/functional/FormatExplorer.svelte") then { default: FormatExplorer }}
					<FormatExplorer />
				{/await}
			{/if}
		</div>

		<div class="flex justify-center mt-6">
			<a href={localizeHref("/formats/")} class="formats-link">
				See all formats &rarr;
			</a>
		</div>
	</div>
</section>

<!-- ═══ GPU CALLOUT ═══ -->
<section class="section-wrapper">
	<div class="section-inner">
		<div class="gpu-callout">
			<div class="gpu-callout-left">
				<div class="gpu-callout-icon">
					<ZapIcon size={20} />
				</div>
				<div class="gpu-callout-text">
					<span class="gpu-callout-badge">{landing_gpu_badge()}</span>
					<h3 class="gpu-callout-title">{landing_gpu_title()}</h3>
					<p class="gpu-callout-desc">
						{landing_gpu_desc()}
					</p>
				</div>
			</div>

			<!-- Schematic -->
			<div class="gpu-schematic">
				<!-- Full GPU formats (bidirectional) -->
				<div class="gpu-group">
					<span class="gpu-group-label">
						<ZapIcon size={9} />
						{landing_gpu_full_label()}
					</span>
					<div class="gpu-format-ring">
						{#each ['MP4', 'WebM', 'MOV', 'M4V', '3GP'] as fmt, i}
							<span class="gpu-format gpu-format--full">{fmt}</span>
							{#if i < 4}<span class="gpu-arrow">⇄</span>{/if}
						{/each}
					</div>
				</div>

				<!-- Input-only GPU formats -->
				<div class="gpu-group">
					<span class="gpu-group-label gpu-group-label--muted">
						<ZapIcon size={9} />
						{landing_gpu_input_label()}
					</span>
					<div class="gpu-format-ring">
						{#each ['MKV', 'AVI', 'FLV', 'TS', 'WMV', 'OGG', 'OGV'] as fmt}
							<span class="gpu-format gpu-format--input">{fmt}</span>
						{/each}
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ═══ PRIVACY ═══ -->
<section class="privacy-section">
	<div class="privacy-inner max-w-5xl mx-auto px-6 md:px-8">
		<div class="privacy-badge-wrap">
			<img src={privacyBadge} alt="Privacy badge" class="privacy-badge" width="196" height="196" loading="lazy" decoding="async" />
		</div>
		<div class="privacy-content">
			<div class="section-label privacy-label">{landing_privacy_label()}</div>
			<h2 class="privacy-headline">{landing_privacy_title()}</h2>
			<ul class="privacy-list">
				{#each [landing_privacy_point1(), landing_privacy_point2(), landing_privacy_point3()] as point}
					<li class="privacy-item">
						<span class="privacy-check">
							<Check size="14" strokeWidth={3} />
						</span>
						<span class="privacy-text">{point}</span>
					</li>
				{/each}
			</ul>
		</div>
	</div>
</section>

<!-- ═══ FAQ ═══ -->
<section class="section-wrapper">
	<div class="section-inner">
		<div class="section-label">{landing_faq_label()}</div>
		<h2 class="section-headline">{landing_faq_title()}</h2>

		<div class="faq-list">
			{#each faqs as faq}
				<details class="faq-item">
					<summary class="faq-q">
						<span>{faq.q}</span>
						<span class="faq-icon"><ChevronDown size="18" /></span>
					</summary>
					<p class="faq-a">{faq.a}</p>
				</details>
			{/each}
		</div>
	</div>
</section>

<style lang="postcss">
/* ── Reveal animation (no opacity so hero H1 remains LCP-eligible) ── */
@keyframes revealUp {
	from { transform: translateY(20px); }
	to   { transform: translateY(0); }
}

.hero-animate { animation: revealUp 0.65s cubic-bezier(0.16, 1, 0.3, 1) both; }
.delay-1 { animation-delay: 0.08s; }
.delay-2 { animation-delay: 0.18s; }
.delay-3 { animation-delay: 0.30s; }

/* ── Hero ── */
.hero-section {
	min-height: 70vh;
	display: flex;
	align-items: center;
}

.hero-bg {
	background-image: url('/bg-dark.webp');
	background-size: cover;
	background-position: center top;
}

:global(.light) .hero-bg {
	background-image: none;
}

@media (prefers-color-scheme: light) {
	:global(:root:not(.dark)) .hero-bg {
		background-image: none;
	}
}

.hero-overlay {
	background:
		radial-gradient(ellipse 80% 50% at 50% -5%, hsla(162, 65%, 45%, 0.38) 0%, transparent 62%),
		linear-gradient(to bottom, hsla(20, 8%, 5%, 0.12) 0%, var(--bg) 88%);
}

:global(.light) .hero-overlay {
	background:
		radial-gradient(ellipse 80% 45% at 50% -8%, hsl(162, 55%, 88%) 0%, transparent 58%),
		linear-gradient(to bottom, transparent 0%, var(--bg) 80%);
}

@media (prefers-color-scheme: light) {
	:global(:root:not(.dark)) .hero-overlay {
		background:
			radial-gradient(ellipse 80% 45% at 50% -8%, hsl(162, 55%, 88%) 0%, transparent 58%),
			linear-gradient(to bottom, transparent 0%, var(--bg) 80%);
	}
}

.hero-headline {
	font-family: var(--font-display);
	font-size: clamp(2rem, 5.5vw, 4.75rem);
	font-weight: 700;
	text-align: center;
	letter-spacing: -0.04em;
	line-height: 1.05;
	max-width: 900px;
}

.hero-subhead {
	font-size: clamp(0.875rem, 1.6vw, 1rem);
	text-align: center;
	color: var(--fg-muted);
	max-width: 560px;
	font-weight: 400;
	line-height: 1.75;
}

/* Pills */
.pill {
	@apply flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold;
	background: var(--bg-badge);
	color: var(--fg-on-badge);
	letter-spacing: 0.01em;
	border: 1px solid hsla(162, 40%, 35%, 0.15);
}

:global(.dark) .pill {
	border-color: hsla(162, 40%, 60%, 0.15);
}

@media (prefers-color-scheme: dark) {
	:global(:root:not(.light)) .pill {
		border-color: hsla(162, 40%, 60%, 0.15);
	}
}

/* ── Sections ── */
.section-wrapper {
	@apply w-full py-16 md:py-24;
}

.section-alt {
	background: linear-gradient(to bottom, var(--bg-panel-highlight), transparent);
}

.section-inner {
	@apply max-w-5xl mx-auto px-6 md:px-8;
}

.section-label {
	font-family: var(--font-mono);
	font-size: 0.85rem;
	font-weight: 700;
	letter-spacing: 0.14em;
	text-transform: uppercase;
	color: var(--fg-accent, var(--accent));
	margin-bottom: 0.75rem;
}

.section-headline {
	font-family: var(--font-display);
	font-size: clamp(1.75rem, 3.5vw, 2.75rem);
	font-weight: 700;
	letter-spacing: -0.04em;
	line-height: 1.1;
	margin-bottom: 2.5rem;
}

/* ── Toolkit ── */
.toolkit-grid {
	@apply grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6;
}

.toolkit-card {
	@apply relative overflow-hidden rounded-2xl p-6 flex flex-col gap-3;
	background: var(--bg-panel);
	box-shadow: var(--shadow-panel);
	border: 1px solid var(--bg-separator);
	transition: transform 0.22s ease, box-shadow 0.22s ease, border-color 0.22s ease;
	text-decoration: none;
	color: var(--fg);
}

.toolkit-card::before {
	content: '';
	position: absolute;
	top: 0; left: 0; right: 0;
	height: 3px;
	border-radius: 2px 2px 0 0;
}

.toolkit-card--green::before { background: var(--accent-green); }
.toolkit-card--blue::before  { background: var(--accent-blue); }
.toolkit-card--purple::before { background: var(--accent-purple); }

.toolkit-card:hover {
	transform: translateY(-4px);
	box-shadow: var(--shadow-panel), 0 16px 40px hsla(162, 40%, 20%, 0.12);
}

.toolkit-card--green:hover { border-color: var(--accent-green); }
.toolkit-card--blue:hover  { border-color: var(--accent-blue); }
.toolkit-card--purple:hover { border-color: var(--accent-purple); }

:global(.dark) .toolkit-card:hover {
	box-shadow: var(--shadow-panel), 0 16px 48px hsla(20, 15%, 0%, 0.5);
}

.toolkit-card-header {
	@apply flex items-center justify-between;
}

.toolkit-icon {
	@apply w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0;
	color: white;
}

.toolkit-icon--green  { background: var(--accent-green); }
.toolkit-icon--blue   { background: var(--accent-blue); }
.toolkit-icon--purple { background: var(--accent-purple); }

.toolkit-count {
	font-family: var(--font-mono);
	font-size: 0.7rem;
	font-weight: 700;
	letter-spacing: 0.06em;
	padding: 3px 10px;
	border-radius: 9999px;
}

.toolkit-count--green  { background: hsla(158, 65%, 37%, 0.12); color: var(--accent-green); }
.toolkit-count--blue   { background: hsla(217, 82%, 58%, 0.12); color: var(--accent-blue); }
.toolkit-count--purple { background: hsla(258, 68%, 62%, 0.12); color: var(--accent-purple); }

.toolkit-title {
	font-family: var(--font-display);
	font-size: 1.1rem;
	font-weight: 700;
	letter-spacing: -0.03em;
	color: var(--fg);
	margin-top: 0.25rem;
}

.toolkit-desc {
	font-size: 0.875rem;
	font-weight: 400;
	color: var(--fg-muted);
	line-height: 1.65;
}

.toolkit-explore {
	font-family: var(--font-mono);
	font-size: 0.75rem;
	font-weight: 700;
	letter-spacing: 0.02em;
	color: var(--fg-muted);
	margin-top: auto;
	padding-top: 0.5rem;
	transition: color 0.15s ease;
}

.toolkit-card:hover .toolkit-explore {
	color: var(--fg);
}

/* ── Formats link ── */
.formats-link {
	font-family: var(--font-mono);
	font-size: 0.8rem;
	font-weight: 700;
	letter-spacing: 0.02em;
	color: var(--fg-muted);
	text-decoration: none;
	transition: color 0.15s ease;
}

.formats-link:hover {
	color: var(--accent);
}

/* ── GPU Callout ── */
.gpu-callout {
	display: flex;
	flex-direction: column;
	gap: 1.5rem;
	padding: 1.5rem;
	border-radius: 1rem;
	background: var(--bg-panel);
	border: 1px solid var(--bg-separator);
	border-inline-start: 3px solid var(--accent-red);
	box-shadow: var(--shadow-panel);
}

@media (min-width: 768px) {
	.gpu-callout {
		flex-direction: row;
		align-items: flex-start;
	}
}

.gpu-callout-left {
	display: flex;
	gap: 1rem;
	flex-shrink: 0;
}

@media (min-width: 768px) {
	.gpu-callout-left { max-width: 20rem; }
}

.gpu-callout-icon {
	width: 2.75rem;
	height: 2.75rem;
	border-radius: 0.75rem;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-shrink: 0;
	background: hsla(14, 80%, 60%, 0.1);
	color: var(--accent-red);
}

.gpu-callout-text {
	display: flex;
	flex-direction: column;
	gap: 0.375rem;
}

.gpu-callout-badge {
	font-family: var(--font-mono);
	font-size: 0.75rem;
	font-weight: 700;
	letter-spacing: 0.1em;
	text-transform: uppercase;
	color: var(--accent-red);
	opacity: 0.85;
}

.gpu-callout-title {
	font-family: var(--font-display);
	font-size: 1rem;
	font-weight: 700;
	letter-spacing: -0.02em;
	color: var(--fg);
}

.gpu-callout-desc {
	font-size: 0.8125rem;
	font-weight: 400;
	line-height: 1.65;
	color: var(--fg-muted);
}

.gpu-inline-badge {
	display: inline-flex;
	align-items: center;
	gap: 1px;
	padding: 0 3px;
	border-radius: 3px;
	background: hsla(14, 80%, 60%, 0.1);
	color: var(--accent-red);
	vertical-align: middle;
}

/* ── GPU Schematic ── */
.gpu-schematic {
	flex: 1;
	display: flex;
	flex-direction: column;
	gap: 0.75rem;
	min-width: 0;
}

@media (min-width: 768px) {
	.gpu-schematic {
		border-inline-start: 1px solid var(--bg-separator);
		padding-inline-start: 1.5rem;
	}
}

.gpu-group {
	display: flex;
	flex-direction: column;
	gap: 0.5rem;
}

.gpu-group-label {
	display: flex;
	align-items: center;
	gap: 0.25rem;
	font-family: var(--font-mono);
	font-size: 0.5625rem;
	font-weight: 700;
	letter-spacing: 0.08em;
	text-transform: uppercase;
	color: var(--accent-red);
}

.gpu-group-label--muted {
	color: var(--fg-muted);
}

.gpu-format-ring {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	gap: 0.25rem;
}

.gpu-format {
	font-family: var(--font-mono);
	font-size: 0.625rem;
	font-weight: 700;
	letter-spacing: 0.06em;
	padding: 3px 8px;
	border-radius: 5px;
}

.gpu-format--full {
	background: hsla(14, 80%, 60%, 0.12);
	color: var(--accent-red);
	border: 1px solid hsla(14, 80%, 60%, 0.2);
}

.gpu-format--input {
	background: var(--bg-panel-highlight);
	color: var(--fg-muted);
	border: 1px solid var(--bg-separator);
}

.gpu-arrow {
	font-size: 0.625rem;
	color: var(--accent-red);
	opacity: 0.5;
}

/* ── Privacy ── */
.privacy-section {
	@apply w-full py-16 md:py-20;
	background: var(--accent);
	position: relative;
	overflow: hidden;
}

.privacy-section::before {
	content: '';
	position: absolute;
	inset: 0;
	background:
		radial-gradient(ellipse 60% 80% at 0% 50%, hsla(0,0%,0%,0.12) 0%, transparent 60%),
		radial-gradient(ellipse 40% 60% at 100% 20%, hsla(0,0%,100%,0.06) 0%, transparent 50%);
	pointer-events: none;
}

.privacy-inner {
	@apply flex flex-col md:flex-row items-center gap-10 md:gap-14;
	position: relative;
}

.privacy-badge-wrap {
	@apply flex-shrink-0;
}

.privacy-badge {
	@apply w-28 h-28 md:w-44 md:h-44 object-contain;
	filter: drop-shadow(0 8px 24px hsla(0,0%,0%,0.25));
}

.privacy-content {
	@apply flex flex-col;
}

.privacy-label {
	color: hsla(0, 0%, 100%, 0.6);
}

.privacy-headline {
	font-family: var(--font-display);
	font-size: clamp(1.75rem, 3.5vw, 2.75rem);
	font-weight: 700;
	letter-spacing: -0.04em;
	line-height: 1.1;
	color: var(--fg-on-accent);
	margin-bottom: 1.5rem;
}

.privacy-list {
	@apply flex flex-col gap-4;
}

.privacy-item {
	@apply flex items-start gap-3;
}

.privacy-check {
	@apply flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center mt-0.5;
	background: hsla(0, 0%, 100%, 0.2);
	color: var(--fg-on-accent);
}

.privacy-text {
	font-size: 1rem;
	font-weight: 400;
	line-height: 1.65;
	color: var(--fg-on-accent);
	opacity: 0.9;
}

/* ── FAQ ── */
.faq-list {
	@apply flex flex-col gap-3 max-w-3xl;
}

.faq-item {
	@apply rounded-xl overflow-hidden;
	background: var(--bg-panel);
	box-shadow: var(--shadow-panel);
	border: 1px solid var(--bg-separator);
	transition: border-color 0.2s ease;
}

.faq-item[open] {
	border-color: hsla(162, 40%, 40%, 0.3);
}

.faq-q {
	@apply flex items-center justify-between gap-4 px-5 py-4 cursor-pointer select-none list-none;
	font-size: 0.9375rem;
	font-weight: 600;
	color: var(--fg);
	transition: background-color 0.15s ease;
}

.faq-q:hover {
	background: var(--bg-panel-highlight);
}

.faq-q::-webkit-details-marker { display: none; }

.faq-icon {
	@apply flex-shrink-0 transition-transform duration-200;
	color: var(--fg-muted);
}

details[open] .faq-icon {
	transform: rotate(180deg);
	color: var(--accent);
}

.faq-a {
	@apply px-5 pb-5 text-sm font-normal leading-relaxed;
	padding-top: 0.875rem;
	color: var(--fg-muted);
	border-top: 1px solid var(--bg-separator);
}
</style>
