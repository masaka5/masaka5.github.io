<script lang="ts">
	const __nkm = {'image_tools.tools.crop_name': image_tools_tools_crop_name, 'image_tools.tools.filters_name': image_tools_tools_filters_name, 'image_tools.tools.batch_name': image_tools_tools_batch_name};
	import { tools_common_failed, tool_pages_video_to_gif_title, tool_pages_video_to_gif_desc, tools_common_back_image, tool_pages_video_to_gif_upload, upload_uploader_browse, tool_pages_video_to_gif_width, tool_pages_video_to_gif_start, tool_pages_video_to_gif_duration, tool_pages_video_to_gif_btn_busy, tool_pages_video_to_gif_btn, tools_common_ready, tool_pages_video_to_gif_save, tools_common_privacy_note, tool_pages_img_video_to_gif_seo_faq1_q, tool_pages_img_video_to_gif_seo_faq1_a, tool_pages_img_video_to_gif_seo_faq2_q, tool_pages_img_video_to_gif_seo_faq2_a, image_tools_tools_crop_name, image_tools_tools_filters_name, image_tools_tools_batch_name, aria_start_time, aria_duration , navbar_home, navbar_image_tools, meta_descriptions_image_video_to_gif} from "$lib/paraglide/messages/_barrel.js";
	import { localizeHref } from '$lib/paraglide/runtime';
	import { browser } from '$app/environment';
	import { videoToGif } from '$lib/converters/video-to-gif';
	import { downloadBlob, formatFileSize, getOutputName } from '$lib/image/utils';
	import { dropping } from '$lib/store/index.svelte';
	import { FilmIcon } from 'lucide-svelte';
	import ToolPageHeader from '$lib/components/layout/ToolPageHeader.svelte';
	import ToolSeoBlock from '$lib/components/layout/ToolSeoBlock.svelte';
	import { toolSeo } from '$lib/data/tool-seo';

	let files = $state<File[]>([]);
	let fileInput = $state<HTMLInputElement>();
	let fps = $state(10);
	let width = $state(0);
	let startTime = $state(0);
	let duration = $state(0);
	let processing = $state(false);
	let progress = $state(0);
	let error = $state('');
	let resultBlob = $state<Blob | null>(null);
	let previewUrl = $state('');

	$effect(() => {
		void files; // track files for cleanup
		return () => {
			if (previewUrl) URL.revokeObjectURL(previewUrl);
		};
	});

	$effect(() => {
		if (files.length === 0) return;
		// Reset state on new file
		resultBlob = null;
		previewUrl = '';
		error = '';
	});

	function onFileSelect(e: Event) {
		const input = e.target as HTMLInputElement;
		if (input.files?.[0]) files = [input.files[0]];
	}

	function onDrop(e: DragEvent) {
		e.preventDefault();
		e.stopPropagation();
		dropping.set(false);
		const f = e.dataTransfer?.files;
		if (f?.[0] && f[0].type.startsWith('video/')) files = [f[0]];
	}

	async function convert() {
		if (!browser || files.length === 0) return;
		error = '';
		processing = true;
		progress = 0;
		resultBlob = null;
		try {
			resultBlob = await videoToGif(files[0], { fps, width: width || undefined, startTime, duration: duration || undefined }, (pct) => { progress = pct; });
			if (previewUrl) URL.revokeObjectURL(previewUrl);
			previewUrl = URL.createObjectURL(resultBlob);
		} catch (e: unknown) {
			error = e instanceof Error ? e.message : tools_common_failed();
		}
		processing = false;
	}

	function download() {
		if (!resultBlob) return;
		downloadBlob(resultBlob, getOutputName(files[0].name, '', 'gif'));
	}
</script>



<div class="gif-page">
	<ToolPageHeader
		category="image"
		title={tool_pages_video_to_gif_title()}
		description={tool_pages_video_to_gif_desc()}
		icon={FilmIcon}
		backHref="/image-tools/"
		backLabel={tools_common_back_image()}
	/>

	<!-- File upload -->
	<input bind:this={fileInput} type="file" accept="video/*" class="hidden" onchange={onFileSelect} />
	<button
		class="drop-zone"
		onclick={() => fileInput?.click()}
		ondragover={(e) => e.preventDefault()}
		ondrop={onDrop}
	>
		{#if files.length > 0}
			<p class="text-sm font-medium">{files[0].name}</p>
			<p class="text-xs text-muted">{formatFileSize(files[0].size)}</p>
		{:else}
			<p class="text-sm">{tool_pages_video_to_gif_upload()}</p>
			<p class="text-xs text-muted">{upload_uploader_browse()}</p>
		{/if}
	</button>

	{#if files.length > 0}
		<div class="opt-section">
			<div class="opt-row">
				<span class="opt-label">帧率</span>
				<div class="flex gap-2">
					{#each [5, 10, 15, 20] as f}
						<button class="btn text-sm px-3 py-1.5 {fps === f ? 'highlight' : ''}" onclick={() => fps = f}>{f}</button>
					{/each}
				</div>
			</div>
			<div class="opt-row">
				<span class="opt-label">{tool_pages_video_to_gif_width()}</span>
				<div class="flex gap-2">
					{#each [{ label: 'Original', value: 0 }, { label: '480px', value: 480 }, { label: '320px', value: 320 }, { label: '240px', value: 240 }] as w}
						<button class="btn text-sm px-3 py-1.5 {width === w.value ? 'highlight' : ''}" onclick={() => width = w.value}>{w.label}</button>
					{/each}
				</div>
			</div>
			<div class="opt-row">
				<span class="opt-label">{tool_pages_video_to_gif_start()}</span>
				<input type="number" min={0} step={0.5} bind:value={startTime} class="num-input" aria-label={aria_start_time()} />
				<span class="text-xs text-muted">秒</span>
			</div>
			<div class="opt-row">
				<span class="opt-label">{tool_pages_video_to_gif_duration()}</span>
				<input type="number" min={0} step={0.5} bind:value={duration} class="num-input" aria-label={aria_duration()} />
				<span class="text-xs text-muted">秒（0 表示全部）</span>
			</div>
		</div>

		<button class="btn highlight" disabled={processing} onclick={convert}>
			{processing ? `${tool_pages_video_to_gif_btn_busy()} ${progress}%` : tool_pages_video_to_gif_btn()}
		</button>

		{#if processing}
			<div class="h-1.5 rounded-full overflow-hidden" style="background: var(--bg-separator)">
				<div class="h-full rounded-full transition-all" style="background: var(--accent); width: {progress}%"></div>
			</div>
		{/if}
	{/if}

	{#if error}<p class="text-sm text-failure">{error}</p>{/if}

	{#if resultBlob && previewUrl}
		<div class="result-section">
			<img src={previewUrl} alt="GIF preview" class="gif-preview" />
			<div class="result-box">
				<p class="text-sm font-medium">{tools_common_ready()} <b>{formatFileSize(resultBlob.size)}</b></p>
				<button class="btn" onclick={download}>{tool_pages_video_to_gif_save()}</button>
			</div>
		</div>
	{/if}

	<p class="text-xs text-muted mt-2">{tools_common_privacy_note()}</p>

	{#if toolSeo['img-video-to-gif']}
		<ToolSeoBlock
			faqs={toolSeo['img-video-to-gif'].faqKeys.length >= 4 ? [
				{ q: tool_pages_img_video_to_gif_seo_faq1_q?.() ?? '', a: tool_pages_img_video_to_gif_seo_faq1_a?.() ?? '' },
				{ q: tool_pages_img_video_to_gif_seo_faq2_q?.() ?? '', a: tool_pages_img_video_to_gif_seo_faq2_a?.() ?? '' },
			] : []}
			relatedTools={toolSeo['img-video-to-gif'].related.map(r => ({ href: r.href, name: __nkm[r.nameKey]?.() ?? '', icon: r.icon }))}
		/>
	{/if}
</div>

<style>
	.gif-page { max-width: 42rem; margin: 0 auto; padding: 2.5rem 1rem; display: flex; flex-direction: column; gap: 1.5rem; }
.drop-zone {
		width: 100%; padding: 2.5rem 1.5rem; border-radius: 1rem; border: 2px dashed var(--bg-separator);
		display: flex; flex-direction: column; align-items: center; gap: 0.25rem;
		cursor: pointer; background: var(--bg-panel); transition: border-color 0.15s;
	}
	.drop-zone:hover { border-color: var(--accent); }
	.opt-section { display: flex; flex-direction: column; gap: 1rem; padding: 1rem; border-radius: 1rem; background: var(--bg-panel); box-shadow: var(--shadow-panel); }
	.opt-row { display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; }
	.opt-label { font-size: 0.8125rem; font-weight: 600; width: 4.5rem; flex-shrink: 0; }
	.num-input {
		width: 5rem; padding: 0.375rem 0.5rem; border-radius: 0.5rem; font-size: 0.875rem;
		border: 1px solid var(--bg-separator); background: var(--bg-panel-alt, var(--bg-panel)); color: var(--fg);
	}
	.num-input:focus { outline: 1.5px solid var(--accent); }
	.result-section { display: flex; flex-direction: column; align-items: center; gap: 1rem; }
	.gif-preview { max-width: 100%; max-height: 20rem; border-radius: 0.75rem; box-shadow: var(--shadow-panel); }
	.result-box { display: flex; flex-direction: column; gap: 0.75rem; padding: 1rem; border-radius: 1rem; background: var(--bg-panel); box-shadow: var(--shadow-panel); width: 100%; }
</style>
