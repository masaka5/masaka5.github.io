export function goto(url: string | URL) {
 const target = new URL(String(url), location.href);
 const current = new URL(location.href);
 if (target.origin === current.origin &&
     (target.searchParams.get('tool') || 'convert') === (current.searchParams.get('tool') || 'convert')) {
  // The standalone host already has this tool mounted; retain its in-memory files.
  for (const [key, value] of target.searchParams) current.searchParams.set(key, value);
  history.replaceState(history.state, '', current);
 } else {
  if (current.searchParams.has('embed')) target.searchParams.set('embed', current.searchParams.get('embed')!);
  location.href = target.href;
 }
 return Promise.resolve();
}
export function beforeNavigate(){}export function afterNavigate(){}export function invalidateAll(){return Promise.resolve();}export function preloadData(){return Promise.resolve();}export function pushState(){}export function replaceState(){}
