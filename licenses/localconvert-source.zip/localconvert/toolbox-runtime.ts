export const locales=['zh-Hans'] as const;export const baseLocale='zh-Hans';export function getLocale(){return 'zh-Hans';}export function setLocale(){}
export function localizeHref(path:string){
 const route = new URL(path, location.origin);
 const query = new URLSearchParams(route.search);
 query.set('tool', route.pathname.replace(/^\/+|\/+$/g,'') || 'convert');
 return './toolbox.html?' + query.toString() + route.hash;
}
export function deLocalizeHref(path:string){return path;}
