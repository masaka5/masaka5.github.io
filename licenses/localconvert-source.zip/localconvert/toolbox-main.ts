import {mount} from 'svelte';import App from './Toolbox.svelte';import './toolbox.css';
mount(App,{target:document.getElementById('app')!});
