// Standalone equivalent of the generated Paraglide message namespace.
import * as m from './toolbox-messages.js';
export { m };
