"""Package matching modified source and stage only this integration (no network)."""
import hashlib, json, shutil, subprocess, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parents[1]
SITE=WORK/'toolbox-site'
DEPLOY=WORK/'_scratch/masaka5-toolbox-upstream'
BUILD=ROOT/'.toolbox-build'
LICENSES=SITE/'licenses'
excluded={'.git','.github','.svelte-kit','.toolbox-build','node_modules','docs','.vscode','nginx'}
archive=LICENSES/'localconvert-source.zip'
records=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,9) as z:
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if any(x in excluded for x in rel.parts) or p.name.startswith('.env') and p.name!='.env.example':continue
  if p.suffix in {'.wasm','.mjs'} and rel.parts[0]=='static':continue
  if p.name.startswith('sitemap') or p.name in {'toolbox-messages.js'}:continue
  raw=p.read_bytes();z.writestr('localconvert/'+rel.as_posix(),raw)
  records.append({'path':rel.as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 z.write(WORK/'_scratch/ops-tests/ant-localconvert.py','tests/ant-localconvert.py')
 z.write(WORK/'_scratch/ops-tests/conversion-workflows.py','tests/conversion-workflows.py')
 z.write(WORK/'_scratch/ops-tests/localconvert-recovery.py','tests/localconvert-recovery.py')
 z.write(WORK/'_scratch/ops-tests/localconvert-recovery-edges.py','tests/localconvert-recovery-edges.py')
manifest={'project':'LocalConvert','upstream':'https://github.com/Sp3llC0d3/localconvert','upstreamCommit':'d3fd6ea358e14f6d31e144a290e13eb592fb487c','license':'AGPL-3.0','modified':True,'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':records,'build':'npm ci; npx vite build --config toolbox.vite.config.ts --outDir .toolbox-build --emptyOutDir; python scripts/package-toolbox.py','runtimeAssets':'Original deployed cmaps, pdf.worker.min.mjs and web-demuxer.wasm remain shared at tools/conversion; dependency sources resolved by package-lock.json. No duplicated engine binaries in source archive.'}
(LICENSES/'localconvert-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(LICENSES/'localconvert-theme-notice.txt').write_text('LocalConvert standalone toolbox adaptation\nCopyright belongs to the original contributors. License: AGPL-3.0 (localconvert-AGPL.txt).\nModified: standalone Svelte routing/localization and Ant theme shell/controls. Original converter engines retained.\nCorresponding modified source: localconvert-source.zip; manifest: localconvert-source-manifest.json.\nDependency license texts are in third-party-notices.txt; source references and locked versions are in package-lock.json.\nBuild: npm ci; npx vite build --config toolbox.vite.config.ts --outDir .toolbox-build --emptyOutDir.\nOriginal static runtime worker, cmaps and demuxer remain at tools/conversion and are not copied into the source ZIP.\n',encoding='utf-8')
# Remove only obsolete tracked generated assets. Keep user/untracked files and runtime assets.
tracked=subprocess.check_output(['git','ls-files','tools/conversion/assets'],cwd=DEPLOY,text=True).splitlines()
generated={p.relative_to(BUILD).as_posix() for p in BUILD.rglob('*') if p.is_file()}
for name in tracked:
 rel=name.removeprefix('tools/conversion/')
 if rel not in generated:
  for base in [SITE,DEPLOY]:
   p=base/name
   if p.exists():p.unlink()
for p in BUILD.rglob('*'):
 if p.is_file():
  rel=p.relative_to(BUILD)
  for base in [SITE,DEPLOY]:
   dest=base/'tools/conversion'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for base in [SITE,DEPLOY]:
 shutil.copy2(base/'tools/conversion/toolbox.html',base/'tools/conversion/index.html')
for name in ['localconvert-source.zip','localconvert-source-manifest.json','localconvert-theme-notice.txt','localconvert-AGPL.txt']:
 shutil.copy2(LICENSES/name,DEPLOY/'licenses'/name)
print(json.dumps({'sourceBytes':archive.stat().st_size,'files':len(records),'buildFiles':len(generated),'generatedBytes':sum(p.stat().st_size for p in BUILD.rglob('*') if p.is_file())}))
