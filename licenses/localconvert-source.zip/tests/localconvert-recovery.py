import asyncio,hashlib,json,os
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright,expect
ROOT=Path(__file__).resolve().parents[2]
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8774').rstrip('/')+'/tools/conversion/'
async def download(page):
 async with page.expect_download() as e:await page.locator('.act-btn--download:not([disabled])').click()
 return Path(await (await e.value).path()).read_bytes()
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  f=ROOT/'_scratch/integration-fixtures/recover.png';Image.new('RGB',(320,180),(20,80,210)).save(f)
  await page.goto(BASE+'?tool=convert&to=jpg')
  await page.locator('input[type=file]').set_input_files(str(f))
  await page.locator('.act-btn--convert').click();await page.locator('.act-btn--download:not([disabled])').wait_for(timeout=60000)
  original=await download(page)
  await page.evaluate("localStorage.setItem('settings',JSON.stringify({magickQuality:77,plausible:false}))")
  await page.reload()
  await expect(page.get_by_text('recover.png',exact=True)).to_be_visible(timeout=8000)
  await expect(page.locator('.act-btn--download:not([disabled])')).to_be_visible()
  await expect(page.get_by_role('slider')).to_have_value('77')
  assert original==await download(page),'Recovered output bytes differ'
  await page.goto(BASE+'?tool=dev-tools/json');await page.locator('textarea').first.fill('{"draft":"saved","n":42}')
  await page.get_by_role('button',name='格式化',exact=True).click();await page.wait_for_timeout(80)
  await page.reload();await expect(page.locator('textarea').first).to_have_value('{"draft":"saved","n":42}')
  assert json.loads(await page.locator('textarea').nth(1).input_value())=={'draft':'saved','n':42}
  await page.get_by_role('button',name='格式化',exact=True).click()
  assert json.loads(await page.locator('textarea').nth(1).input_value())=={'draft':'saved','n':42}
  await page.go_back();await expect(page.get_by_text('recover.png',exact=True)).to_be_visible()
  assert original==await download(page)
  await page.go_forward();await expect(page.locator('textarea').first).to_have_value('{"draft":"saved","n":42}')
  await page.go_back();await expect(page.get_by_text('recover.png',exact=True)).to_be_visible()
  await page.get_by_role('button',name='移除文件').click();await page.wait_for_timeout(100)
  await page.reload();await expect(page.get_by_text('recover.png',exact=True)).to_have_count(0)
  assert not errors,errors
  await b.close();print('PASS real output exact bytes refresh/back; JSON draft refresh/reformat; remove refresh empty')
asyncio.run(main())
