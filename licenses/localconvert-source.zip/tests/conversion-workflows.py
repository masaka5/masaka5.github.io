import asyncio,json,os
from io import BytesIO
from pathlib import Path
from PIL import Image
from pypdf import PdfReader
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2];F=ROOT/'_scratch/integration-fixtures'
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch(headless=True);page=await browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/conversion/?tool=convert&to=jpg&embed=1')
  await page.locator('input[type=file]').set_input_files(str(F/'image.png'))
  await page.wait_for_timeout(1200)
  assert await page.get_by_text('image.png',exact=True).count(),'Uploaded image disappeared after navigation'
  await page.screenshot(path=str(F/'converter-uploaded.png'))
  await page.locator('.act-btn--convert').click()
  await page.locator('.act-btn--download:not([disabled])').wait_for(timeout=60000)
  async with page.expect_download()as event:await page.locator('.act-btn--download').click()
  download=await event.value
  image=Image.open(BytesIO(Path(await download.path()).read_bytes()))
  assert image.format=='JPEG',image.format
  assert image.size==(240,120),image.size
  assert 'embed=1' in page.url and 'to=jpg' in page.url,page.url
  print('PNG to JPEG: downloaded file format and dimensions verified; upload and embed state retained',flush=True)
  await page.goto(BASE+'/tools/conversion/?tool=pdf-tools/merge')
  await page.locator('input[type=file]').first.set_input_files([str(F/'part1.pdf'),str(F/'part2.pdf')])
  await page.get_by_role('button',name='合并 PDF',exact=True).click()
  button=page.locator('.result-box button');await button.wait_for(timeout=30000)
  async with page.expect_download()as event:await button.click()
  pdf=PdfReader(BytesIO(Path(await(await event.value).path()).read_bytes()))
  assert len(pdf.pages)==2,len(pdf.pages)
  print('LocalConvert PDF merge: downloaded two-page document verified',flush=True)
  assert not errors,errors
  await browser.close()
asyncio.run(main())
