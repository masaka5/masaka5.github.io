import asyncio, json, os
from io import BytesIO
from PIL import Image
from pypdf import PdfReader
from playwright.async_api import expect
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page(viewport={'width':1440,'height':900})
  errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
  await page.goto(BASE+'/tools/conversion/?tool=convert');await page.wait_for_timeout(1200)
  values=await page.evaluate('''() => ({font:getComputedStyle(document.body).fontSize,buttons:[...document.querySelectorAll('button')].slice(0,5).map(e=>({text:e.innerText,height:e.offsetHeight,bg:getComputedStyle(e).backgroundColor,radius:getComputedStyle(e).borderRadius}))})''')
  print(json.dumps(values,ensure_ascii=True))
  assert values['font']=='14px',values
  assert all(x['height']==36 for x in values['buttons'][:4]),values
  assert values['buttons'][0]['bg']=='rgb(49, 95, 201)'
  f=ROOT/'_scratch/integration-fixtures';f.mkdir(exist_ok=True)
  Image.new('RGB',(240,120),(210,60,40)).save(f/'ant-sample.png')
  await page.goto(BASE+'/tools/conversion/?tool=convert&to=jpg&embed=1')
  await page.evaluate("localStorage.setItem('settings',JSON.stringify({magickQuality:73,plausible:false}))")
  await page.reload()
  await page.locator('input[type=file]').set_input_files(str(f/'ant-sample.png'))
  await expect(page.get_by_role('slider')).to_have_value('73')
  await page.locator('.act-btn--convert').click()
  await page.locator('.act-btn--download:not([disabled])').wait_for(timeout=60000)
  async with page.expect_download() as event:await page.locator('.act-btn--download').click()
  data=Path(await (await event.value).path()).read_bytes();im=Image.open(BytesIO(data));assert im.format=='JPEG' and im.size==(240,120)
  await page.locator('input[type=file]').set_input_files({'name':'roundtrip.jpg','mimeType':'image/jpeg','buffer':data})
  await expect(page.get_by_text('roundtrip.jpg',exact=True)).to_be_visible()
  await page.screenshot(path=str(ROOT/'.superpowers/task-4-desktop.png'))
  await page.set_viewport_size({'width':390,'height':844})
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await page.screenshot(path=str(ROOT/'.superpowers/task-4-convert-mobile.png'))
  await page.set_viewport_size({'width':1440,'height':900})
  # Remove invokes original cancellation path and clears queued/result files.
  await page.get_by_role('button',name='移除文件').first.click()
  await expect(page.get_by_text('ant-sample.png',exact=True)).to_have_count(0)
  await page.locator('input[type=file]').set_input_files({'name':'unsupported.xyz','mimeType':'application/octet-stream','buffer':b'unsupported'})
  await expect(page.get_by_text('unsupported.xyz',exact=True)).to_be_visible()
  await page.evaluate("localStorage.removeItem('settings')")
  await page.goto(BASE+'/tools/conversion/?tool=dev-tools/json')
  await page.locator('textarea').first.fill('{broken')
  await expect(page.locator('.text-failure')).to_be_visible()
  await page.locator('textarea').first.fill('{"hello":"世界","n":42}')
  await page.get_by_role('button',name='格式化',exact=True).click()
  assert json.loads(await page.locator('textarea').nth(1).input_value())=={'hello':'世界','n':42}
  await page.locator('textarea').first.fill(json.dumps({str(i):'value'*100 for i in range(300)}))
  await page.get_by_role('button',name='格式化',exact=True).click()
  for viewport,name in [({'width':1440,'height':900},'long'),({'width':390,'height':844},'mobile')]:
   await page.set_viewport_size(viewport)
   assert await page.evaluate('document.documentElement.scrollHeight<=innerHeight')
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   assert await page.locator('textarea').nth(1).evaluate('(e)=>e.scrollHeight>e.clientHeight')
   await page.screenshot(path=str(ROOT/f'.superpowers/task-4-{name}.png'))
  manifest=json.loads((ROOT/'toolbox-site/assets/integration-manifest.json').read_text(encoding='utf-8'))
  routes=[r['sourceId'] for r in manifest['sources'] if r['source']=='localconvert'];report=[]
  for slug in routes:
   await page.goto(BASE+'/tools/conversion/?tool='+slug)
   await page.locator('.toolbox-workspace>div').first.wait_for()
   await page.wait_for_timeout(80)
   assert '工具加载失败' not in await page.locator('body').inner_text(),slug
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth'),slug
   report.append({'route':slug,'test':'load-only','passed':True})
  assert len(routes)==40,len(routes)
  assert not errors,errors
  (ROOT/'.superpowers/task-4-routes.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
  await page.set_viewport_size({'width':1440,'height':900})
  await page.goto(BASE+'/tools/conversion/?tool=pdf-tools/merge')
  await page.locator('input[type=file]').first.set_input_files([str(f/'part1.pdf'),str(f/'part2.pdf')])
  await page.get_by_role('button',name='合并 PDF',exact=True).click()
  button=page.locator('.result-box button');await button.wait_for(timeout=30000)
  async with page.expect_download() as event:await button.click()
  merged=Path(await (await event.value).path()).read_bytes();assert len(PdfReader(BytesIO(merged)).pages)==2
  await page.goto(BASE+'/tools/conversion/?tool=pdf-tools/merge')
  await page.locator('input[type=file]').first.set_input_files([{'name':'roundtrip.pdf','mimeType':'application/pdf','buffer':merged},{'name':'part1.pdf','mimeType':'application/pdf','buffer':(f/'part1.pdf').read_bytes()}])
  await page.get_by_role('button',name='合并 PDF',exact=True).click()
  button=page.locator('.result-box button');await button.wait_for(timeout=30000)
  async with page.expect_download() as event:await button.click()
  assert len(PdfReader(BytesIO(Path(await (await event.value).path()).read_bytes())).pages)==3
  assert not errors,errors
  print('PASS: PNG/JPEG decode and download/reimport; original remove/cancel path; unsupported input; JSON invalid/recovery/long output; desktop/mobile bounds; 40 independent load-only routes')
  await b.close()
asyncio.run(main())
