import asyncio,os,json
from pathlib import Path
from playwright.async_api import async_playwright,expect
ROOT=Path(__file__).resolve().parents[2]
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8774').rstrip('/')+'/tools/conversion/'
FILE=ROOT/'_scratch/integration-fixtures/recover.png'
READ="""() => new Promise((resolve,reject)=>{let r=indexedDB.open('toolbox-localconvert-v1',1);r.onsuccess=()=>{let db=r.result,t=db.transaction('snapshots'),q=t.objectStore('snapshots').get('convert');t.oncomplete=()=>{db.close();resolve(q.result?.items.map(x=>({name:x.file.name,to:x.to,options:x.options,output:!!x.output}))||[])}};r.onerror=()=>reject(r.error)})"""
INSTRUMENT="""() => {const create=URL.createObjectURL.bind(URL),revoke=URL.revokeObjectURL.bind(URL);window.urls={created:[],revoked:[]};URL.createObjectURL=(b)=>{const u=create(b);urls.created.push(u);return u};URL.revokeObjectURL=u=>{urls.revoked.push(u);revoke(u)};const OriginalWorker=Worker;window.workerCount=0;window.workerUrls=[];window.pauseWorkers=false;window.Worker=class extends OriginalWorker{constructor(...args){super(...args);workerCount++;workerUrls.push(String(args[0]))}postMessage(...args){if(!window.pauseWorkers)super.postMessage(...args)}}}"""
async def open_convert(page):
 await page.goto(BASE+'?tool=convert&to=jpg');await page.locator('input[type=file]').wait_for(state='attached')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();c=await b.new_context(viewport={'width':390,'height':844});await c.add_init_script('('+INSTRUMENT+')()')
  page=await c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await open_convert(page);await page.locator('input[type=file]').set_input_files(str(FILE))
  await page.get_by_role('slider').fill('61');await page.get_by_role('spinbutton').first.fill('160');await page.get_by_role('spinbutton').nth(1).fill('90')
  await page.wait_for_function("async()=>{let r=await ("+READ+")();return r[0]?.options.optQuality===61&&r[0]?.options.optHeight===90}")
  await page.reload();await expect(page.get_by_role('slider')).to_have_value('61');await expect(page.get_by_role('spinbutton').first).to_have_value('160')
  preview=await page.locator('.toolbox-workspace img').first.get_attribute('src');assert preview.startswith('blob:')
  await page.get_by_role('button',name='移除文件').click();await page.wait_for_timeout(100)
  assert preview in await page.evaluate('urls.revoked'),'Removed restored preview not revoked'
  assert not await page.evaluate(READ)
  # Hold real worker messages while conversion is running; refresh must restore a stopped input.
  await page.locator('input[type=file]').set_input_files(str(FILE));await page.evaluate('pauseWorkers=true')
  await page.locator('.act-btn--convert').click();await page.locator('.act-btn__spin').wait_for();await page.wait_for_timeout(150)
  await page.reload();await expect(page.get_by_text('recover.png',exact=True)).to_be_visible()
  assert await page.locator('.act-btn__spin').count()==0
  await expect(page.locator('.act-btn--download')).to_be_disabled();assert not any('magick' in u for u in await page.evaluate('workerUrls')),'Automatic conversion worker restarted'
  # Newest queued edits and a clear cannot be overwritten by an older write.
  await page.get_by_role('button',name='移除文件').click()
  for i in range(5):
   await page.locator('input[type=file]').set_input_files({'name':f'new-{i}.xyz','mimeType':'application/octet-stream','buffer':b'data'})
  await page.get_by_role('button',name='删除所有文件',exact=True).click();await page.wait_for_timeout(150)
  assert not await page.evaluate(READ);await page.reload();await expect(page.locator('.act-btn')).to_have_count(0)
  assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight')
  await page.screenshot(path=str(ROOT/'.superpowers/task-12-mobile.png'))
  # Bounded count keeps most-recent 32 entries.
  await page.locator('input[type=file]').set_input_files([{'name':f'bound-{i}.xyz','mimeType':'application/octet-stream','buffer':b'x'} for i in range(34)])
  await page.wait_for_timeout(150);rows=await page.evaluate(READ);assert len(rows)==32 and rows[0]['name']=='bound-2.xyz',rows
  await page.locator('.toolbox-workspace').evaluate('(e)=>e.scrollTop=500')
  await page.wait_for_timeout(80);await page.reload();await page.get_by_text('bound-2.xyz',exact=True).wait_for()
  await page.wait_for_timeout(100);assert await page.locator('.toolbox-workspace').evaluate('(e)=>e.scrollTop')>=490,'Workspace scroll not restored'
  # Expired/corrupt snapshot safely removed rather than partially interpreted.
  await page.evaluate("""() => new Promise(resolve=>{let r=indexedDB.open('toolbox-localconvert-v1',1);r.onsuccess=()=>{let db=r.result,t=db.transaction('snapshots','readwrite');t.objectStore('snapshots').put({version:1,savedAt:0,items:[{password:'NEVER'}]},'convert');t.oncomplete=()=>{db.close();resolve()}}})""")
  await page.reload();await page.locator('input[type=file]').wait_for(state='attached');assert not await page.evaluate(READ)
  await page.evaluate("""() => new Promise(resolve=>{let r=indexedDB.open('toolbox-localconvert-v1',1);r.onsuccess=()=>{let db=r.result,t=db.transaction('snapshots','readwrite');t.objectStore('snapshots').put({version:1,savedAt:Date.now(),items:[{file:'corrupt',to:'.jpg',password:'NEVER'}]},'convert');t.oncomplete=()=>{db.close();resolve()}}})""")
  await page.reload();await page.locator('input[type=file]').wait_for(state='attached');assert not await page.evaluate(READ)
  await page.locator('input[type=file]').set_input_files(str(FILE))
  await page.evaluate("""() => {const input=document.querySelector('input[type=file]'),data=new DataTransfer();data.items.add(new File([new Uint8Array(65*1024*1024)],'oversize.xyz'));input.files=data.files;input.dispatchEvent(new Event('change',{bubbles:true}))}""")
  await expect(page.get_by_text('oversize.xyz',exact=True)).to_be_visible();await page.wait_for_timeout(150)
  rows=await page.evaluate(READ);assert len(rows)==1 and rows[0]['name']=='recover.png','64MiB bound must skip oversized input'
  assert not errors,errors
  await c.close()
  # Quota failure cannot leave a stale prior snapshot that resurrects removed inputs.
  c=await b.new_context();page=await c.new_page();await open_convert(page)
  await page.locator('input[type=file]').set_input_files(str(FILE));await page.wait_for_timeout(100)
  await page.evaluate("""() => {const raw=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(...a){if(this.name==='snapshots')throw new DOMException('Quota full','QuotaExceededError');return raw.apply(this,a)}}""")
  await page.get_by_role('button',name='移除文件').click();await page.wait_for_timeout(150)
  await page.reload();await page.locator('input[type=file]').wait_for(state='attached');await expect(page.get_by_text('recover.png',exact=True)).to_have_count(0);await c.close()
  # Slow startup is gated: no tool inputs until restoration completes. First edit then wins.
  c=await b.new_context();page=await c.new_page();await open_convert(page)
  await page.locator('input[type=file]').set_input_files(str(FILE));await page.wait_for_timeout(100)
  await c.add_init_script("""const raw=indexedDB.open.bind(indexedDB);indexedDB.open=(...a)=>{const r=raw(...a);return new Proxy(r,{set(t,k,v){if(k==='onsuccess'){t[k]=e=>setTimeout(()=>v.call(t,e),500);return true}t[k]=v;return true},get(t,k){const v=t[k];return typeof v==='function'?v.bind(t):v}})}""")
  await page.reload();await page.wait_for_timeout(80);assert await page.locator('input[type=file]').count()==0
  await page.locator('input[type=file]').wait_for(state='attached');await page.locator('input[type=file]').set_input_files({'name':'fresh.png','mimeType':'image/png','buffer':FILE.read_bytes()});await page.wait_for_timeout(600)
  await expect(page.get_by_text('recover.png',exact=True)).to_be_visible();await expect(page.get_by_text('fresh.png',exact=True)).to_be_visible();await c.close()
  # Disabled localStorage and IndexedDB may fail; conversion/JSON must remain functional.
  c=await b.new_context();await c.add_init_script("""Object.defineProperty(window,'localStorage',{get(){throw new DOMException('Disabled','SecurityError')}});Object.defineProperty(window,'indexedDB',{get(){throw new DOMException('Disabled','SecurityError')}})""")
  page=await c.new_page();disabled=[];page.on('pageerror',lambda e:disabled.append(str(e)))
  await open_convert(page);await page.locator('input[type=file]').set_input_files(str(FILE));await page.locator('.act-btn--convert').click();await page.locator('.act-btn--download:not([disabled])').wait_for(timeout=60000)
  await page.goto(BASE+'?tool=dev-tools/json');await page.locator('textarea').first.fill('{"disabled":true}');await page.get_by_role('button',name='格式化',exact=True).click()
  assert json.loads(await page.locator('textarea').nth(1).input_value())=={'disabled':True};assert not disabled,disabled
  await b.close();print('PASS options; URL revoke; paused in-progress refresh stops; ordered clear;32-file eviction; corrupt/expired;quota failure; gated startup race; disabled storage; mobile bounds')
asyncio.run(main())
