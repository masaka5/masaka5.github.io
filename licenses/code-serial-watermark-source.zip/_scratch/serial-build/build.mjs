import {build} from 'esbuild';
await build({entryPoints:['entry.js'],outfile:'../../toolbox-site/vendor/esptool/esptool.js',bundle:true,format:'esm',platform:'browser',target:'es2022',minify:true,legalComments:'eof'});
