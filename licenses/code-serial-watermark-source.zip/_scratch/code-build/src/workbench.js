import {initialize,getService,IEditorService,IExtensionService} from '@codingame/monaco-vscode-api';
import getWorkbench from '@codingame/monaco-vscode-workbench-service-override';
import getConfiguration from '@codingame/monaco-vscode-configuration-service-override';
import {initUserConfiguration} from '@codingame/monaco-vscode-configuration-service-override/common';
import getExtensions from '@codingame/monaco-vscode-extensions-service-override';
import getGallery from '@codingame/monaco-vscode-extension-gallery-service-override';
import getExplorer from '@codingame/monaco-vscode-explorer-service-override';
import {createIndexedDBProviders,createHTMLFileSystemProvider,IndexedDB,IndexedDBFileSystemProvider,registerFileSystemOverlay,registerCustomProvider,DelegateFileSystemProvider,initFile} from '@codingame/monaco-vscode-files-service-override';
import getKeys from '@codingame/monaco-vscode-keybindings-service-override';
import getModel from '@codingame/monaco-vscode-model-service-override';
import getNotifications from '@codingame/monaco-vscode-notifications-service-override';
import getPreferences from '@codingame/monaco-vscode-preferences-service-override';
import getQuickAccess from '@codingame/monaco-vscode-quickaccess-service-override';
import getSearch from '@codingame/monaco-vscode-search-service-override';
import getStorage from '@codingame/monaco-vscode-storage-service-override';
import getTextmate from '@codingame/monaco-vscode-textmate-service-override';
import getTheme from '@codingame/monaco-vscode-theme-service-override';
import getLanguages from '@codingame/monaco-vscode-languages-service-override';
import getDialogs from '@codingame/monaco-vscode-dialogs-service-override';
import getTitleBar from '@codingame/monaco-vscode-view-title-bar-service-override';
import {registerExtension,ExtensionHostKind,getBuiltinExtensions} from '@codingame/monaco-vscode-api/extensions';
import {createModelReference} from '@codingame/monaco-vscode-api/monaco';
import * as monaco from 'monaco-editor';
import * as vscode from 'vscode';
import 'vscode/localExtensionHost';
import '@codingame/monaco-vscode-javascript-default-extension';
import '@codingame/monaco-vscode-typescript-basics-default-extension';
import '@codingame/monaco-vscode-typescript-language-features-default-extension';
import '@codingame/monaco-vscode-python-default-extension';
import '@codingame/monaco-vscode-powershell-default-extension';
import '@codingame/monaco-vscode-rust-default-extension';
import '@codingame/monaco-vscode-json-default-extension';
import '@codingame/monaco-vscode-theme-defaults-default-extension';
import '@codingame/monaco-vscode-theme-seti-default-extension';
import editorWorkerURL from 'monaco-editor/esm/vs/editor/editor.worker.js?worker&url';
import extensionWorkerURL from '@codingame/monaco-vscode-api/workers/extensionHost.worker?worker&url';
import textmateWorkerURL from '@codingame/monaco-vscode-textmate-service-override/worker?worker&url';
import searchWorkerURL from '@codingame/monaco-vscode-search-service-override/worker?worker&url';

const workers={editorWorkerService:editorWorkerURL,extensionHostWorkerMain:extensionWorkerURL,TextMateWorker:textmateWorkerURL,LocalFileSearchWorker:searchWorkerURL};
window.MonacoEnvironment={getWorkerUrl:(_,label)=>workers[label],getWorkerOptions:()=>({type:'module'})};
await createIndexedDBProviders();
// Persist browser workspaces independently from settings and external directory grants.
const database=await IndexedDB.create('toolbox-code-workspaces',1,['files']);
const drafts=new IndexedDBFileSystemProvider('file',database,'files',true);
registerFileSystemOverlay(1,drafts);
const nativeFiles=createHTMLFileSystemProvider();
const watchNative=nativeFiles.watch.bind(nativeFiles);
nativeFiles.watch=(resource,options)=>{let watch,disposed=false;nativeFiles.getHandle(resource).then(handle=>{if(handle&&!disposed)watch=watchNative(resource,options);}).catch(()=>{});return {dispose(){disposed=true;watch?.dispose();}};};
const toNative=uri=>uri.with({scheme:'file'}),fromNative=uri=>uri.with({scheme:'local'});
registerCustomProvider('local',new DelegateFileSystemProvider({delegate:nativeFiles,toDelegate:toNative,fromDeletate:fromNative}));
const home=vscode.Uri.file('/workspace');
await drafts.mkdir(home);
const workspaceFile=vscode.Uri.file('/toolbox.code-workspace');
try{await drafts.stat(workspaceFile);}catch{await drafts.writeFile(workspaceFile,new TextEncoder().encode(JSON.stringify({folders:[{path:'/workspace',name:'浏览器文件'}]})),{create:true,overwrite:false});}
const samples={'main.js':'const message = "你好，世界";\nconsole.log(message);\n','main.py':'print("你好，世界")\n','main.ps1':'Write-Host "你好，世界"\n','main.rs':'fn main() {\n    println!("你好，世界");\n}\n','jsconfig.json':'{"compilerOptions":{"target":"ES2022","checkJs":true},"include":["**/*.js"]}'};
for(const [name,content] of Object.entries(samples)){
 const uri=vscode.Uri.file('/workspace/'+name);
 try{await drafts.stat(uri);}catch{await drafts.writeFile(uri,new TextEncoder().encode(content),{create:true,overwrite:false});}
}
await initUserConfiguration(JSON.stringify({
 'workbench.colorTheme':'Default Light Modern','workbench.iconTheme':'vs-seti',
 'workbench.startupEditor':'none','workbench.activity.showAccounts':false,
 'workbench.secondarySideBar.defaultVisibility':'hidden','workbench.layoutControl.enabled':true,
 'window.commandCenter':true,'window.menuBarVisibility':'compact','window.title':'${activeEditorShort}${separator}代码工作台',
 'files.autoSave':'afterDelay','files.autoSaveDelay':700,'editor.fontSize':14,
 'editor.minimap.enabled':false,'telemetry.telemetryLevel':'off','update.mode':'none',
 'extensions.ignoreRecommendations':true,'chat.disableAIFeatures':true,
 'typescript.tsserver.web.projectWideIntellisense.enabled':true,
 'typescript.tsserver.web.typeAcquisition.enabled':false
}));
const commands=[['toolbox.home','返回工具箱'],['toolbox.import','导入文件'],['toolbox.openFile','打开本地文件'],['toolbox.saveAs','另存到本地'],['toolbox.export','下载当前文件'],['toolbox.folder','打开本地文件夹'],['toolbox.languages','内置语言支持']];
const extension=registerExtension({name:'browser-tools',publisher:'toolbox',displayName:'工具箱',description:'本地文件与语言支持',version:'1.0.0',engines:{vscode:'*'},contributes:{commands:commands.map(([command,title])=>({command,title,category:'工具箱'})),menus:{commandPalette:commands.map(([command])=>({command})), 'editor/title':[{command:'toolbox.export',group:'navigation'}]}}},ExtensionHostKind.LocalProcess);
await initialize({
 ...getModel(),...getNotifications(),...getKeys(),...getTextmate(),...getTheme(),...getLanguages(),
 ...getPreferences(),...getSearch(),...getStorage(),...getExplorer(),...getDialogs(),...getTitleBar(),
 ...getConfiguration(),...getExtensions({enableWorkerExtensionHost:true,iframeAlternateDomain:location.origin+'/'}),
 ...getGallery({webOnly:true}),...getWorkbench(),
 ...getQuickAccess({isKeybindingConfigurationVisible:()=>true,shouldUseGlobalPicker:()=>true})
},document.querySelector('#workbench'),{
 workspaceProvider:{trusted:true,workspace:{workspaceUri:workspaceFile},open:async()=>false},
 enableWorkspaceTrust:false,
 configurationDefaults:{'window.title':'${activeEditorShort}${separator}代码工作台'},
 productConfiguration:{nameShort:'代码工作台',nameLong:'代码工作台',applicationName:'toolbox-code',version:'1.0.0',extensionsGallery:{serviceUrl:'https://open-vsx.org/vscode/gallery',resourceUrlTemplate:'https://open-vsx.org/vscode/unpkg/{publisher}/{name}/{version}/{path}',extensionUrlTemplate:'https://open-vsx.org/vscode/gallery/{publisher}/{name}/latest',controlUrl:'',nlsBaseUrl:''}},
 defaultLayout:{editors:[{uri:vscode.Uri.file('/workspace/main.js')}],views:[{id:'workbench.explorer.fileView'}]}
},{userHome:vscode.Uri.file('/')});
await extension.setAsDefaultApi();
function download(data,name){const url=URL.createObjectURL(new Blob([data]));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}
vscode.commands.registerCommand('toolbox.home',()=>location.assign('../../'));
vscode.commands.registerCommand('toolbox.export',async()=>{const d=vscode.window.activeTextEditor?.document;if(d)download(d.getText(),d.uri.path.split('/').pop());});
vscode.commands.registerCommand('toolbox.openFile',async()=>{if(!window.showOpenFilePicker)return vscode.commands.executeCommand('toolbox.import');try{for(const handle of await showOpenFilePicker({multiple:true})){const uri=fromNative(await nativeFiles.registerFileHandle(handle));await vscode.window.showTextDocument(uri);}}catch(e){if(e.name!=='AbortError')vscode.window.showErrorMessage('无法打开文件：'+e.message);}});
vscode.commands.registerCommand('toolbox.saveAs',async()=>{const doc=vscode.window.activeTextEditor?.document;if(!doc)return;if(!window.showSaveFilePicker)return vscode.commands.executeCommand('toolbox.export');try{const handle=await showSaveFilePicker({suggestedName:doc.uri.path.split('/').pop()||'untitled.txt'});const writable=await handle.createWritable();try{await writable.write(doc.getText());await writable.close();}catch(e){await writable.abort().catch(()=>{});throw e;}}catch(e){if(e.name!=='AbortError')vscode.window.showErrorMessage('无法保存文件：'+e.message);}});
vscode.commands.registerCommand('toolbox.import',()=>{const input=document.createElement('input');input.type='file';input.multiple=true;input.onchange=async()=>{try{for(const file of input.files){const uri=vscode.Uri.joinPath(home,file.name);try{await vscode.workspace.fs.stat(uri);if(await vscode.window.showWarningMessage('覆盖 '+file.name+'？',{modal:true},'覆盖')!=='覆盖')continue;}catch{}await vscode.workspace.fs.writeFile(uri,new Uint8Array(await file.arrayBuffer()));await vscode.window.showTextDocument(uri);}}catch(e){vscode.window.showErrorMessage(e.message);}};input.click();});
vscode.commands.registerCommand('toolbox.folder',async()=>{if(!window.showDirectoryPicker)return vscode.window.showInformationMessage('此浏览器不支持文件夹授权，请使用“导入文件”。');try{const handle=await showDirectoryPicker({mode:'readwrite'});const uri=fromNative(await nativeFiles.registerDirectoryHandle(handle));vscode.workspace.updateWorkspaceFolders(vscode.workspace.workspaceFolders?.length||0,0,{uri,name:handle.name});}catch(e){if(e.name!=='AbortError')vscode.window.showErrorMessage('无法打开文件夹：'+e.message);}});
vscode.commands.registerCommand('toolbox.languages',()=>vscode.window.showQuickPick([
 {label:'JavaScript / TypeScript',description:'语法 · 补全 · 类型检查'},
 {label:'Python',description:'语法 · 缩进 · 注释'},
 {label:'PowerShell',description:'语法 · 缩进 · 注释（无桌面语言服务）'},
 {label:'Rust',description:'语法 · 缩进 · 注释（无 rust-analyzer）'}
],{title:'内置语言支持'}));
const status=vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left,1000);status.text='$(arrow-left) 工具箱';status.command='toolbox.home';status.tooltip='返回工具箱';status.show();
const languageStatus=vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right,1);languageStatus.text='$(extensions) 内置语言';languageStatus.command='toolbox.languages';languageStatus.show();
document.querySelector('#loading').hidden=true;
// Diagnostics use the same public commands and document API as interactive editing.
window.toolboxCode={ready:true,
 inspect:async()=>({languages:await vscode.languages.getLanguages(),extensions:getBuiltinExtensions().map(e=>e.identifier.id),activation:vscode.extensions.all.map(e=>({id:e.id,active:e.isActive,browser:e.packageJSON.browser}))}),
 activate:async()=>{const service=await getService(IExtensionService);await service.activateByEvent('onLanguage:javascript');return {extensions:service.extensions.map(e=>({id:e.identifier.value,browser:e.browser,main:e.main})),status:service.getExtensionsStatus(),commands:(await vscode.commands.getCommands()).filter(c=>c.includes('typescript'))};},
 command:(id)=>vscode.commands.executeCommand(id),
 write:async(path,content)=>{await vscode.workspace.fs.writeFile(vscode.Uri.file(path),new TextEncoder().encode(content));},
 read:async path=>new TextDecoder().decode(await vscode.workspace.fs.readFile(vscode.Uri.file(path))),
 createAndInspect:async({filename,content})=>{const uri=vscode.Uri.joinPath(home,filename);await vscode.workspace.fs.writeFile(uri,new TextEncoder().encode(content));const doc=await vscode.workspace.openTextDocument(uri);await vscode.window.showTextDocument(doc);await new Promise(r=>setTimeout(r,700));const ref=await createModelReference(uri);const model=ref.object.textEditorModel;model.tokenization.forceTokenization(model.getLineCount());const tokens=model.tokenization.getLineTokens(1).getCount();ref.dispose();return {language:doc.languageId,tokens};},
 completions:async(path,line,column)=>{let items=[];for(let i=0;i<30;i++){const list=await vscode.commands.executeCommand('vscode.executeCompletionItemProvider',vscode.Uri.file(path),new vscode.Position(line-1,column-1));items=(list?.items||[]).map(i=>typeof i.label==='string'?i.label:i.label.label);if(items.includes('toUpperCase'))break;await new Promise(r=>setTimeout(r,1000));}return items;}
};
