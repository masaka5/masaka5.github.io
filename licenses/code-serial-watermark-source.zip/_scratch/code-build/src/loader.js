try{
 if(!crossOriginIsolated&&isSecureContext&&'serviceWorker' in navigator){
  if(sessionStorage.getItem('toolbox-code-isolation'))throw Error('无法启用语言服务，请允许 Service Worker 后重新打开页面。');
  const registration=await navigator.serviceWorker.register(new URL('./isolation-worker.js',location.href),{scope:'./',updateViaCache:'none'});
  await Promise.race([navigator.serviceWorker.ready,new Promise((_,reject)=>setTimeout(()=>reject(Error('语言服务启动超时')),15000))]);
  sessionStorage.setItem('toolbox-code-isolation','1');location.reload();
 }else{
  sessionStorage.removeItem('toolbox-code-isolation');
  await import('@codingame/monaco-vscode-language-pack-zh-hans');
  await import('./workbench.js');
 }
}catch(e){document.querySelector('#loading span').textContent='工作台加载失败：'+e.message;console.error(e);}
