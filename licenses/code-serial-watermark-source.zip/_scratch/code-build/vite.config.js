import {defineConfig} from 'vite';
export default defineConfig({
 base:'./',
 build:{target:'esnext',outDir:'../../toolbox-site/tools/code',emptyOutDir:true,assetsInlineLimit:0,minify:'esbuild',chunkSizeWarningLimit:20000},
 worker:{format:'es'},
 plugins:[{name:'textmate-runtime-import',transform(code,id){
  if(!id.endsWith('/textMateWorkerTokenizerController.js'))return;
  const source="import('@codingame/monaco-vscode-api/_virtual/main').then(function (n) { return n.main; })";
  if(!code.includes(source))throw Error('TextMate compatibility patch no longer matches');
  return "import {main as textmateRuntime} from '@codingame/monaco-vscode-api/_virtual/main';\n"+code.replace(source,'Promise.resolve(textmateRuntime)');
 }},{name:'vscode-css',enforce:'pre',async resolveId(source,importer,options){
  if(!source.endsWith('.css'))return;
  const resolved=await this.resolve(source,importer,{...options,skipSelf:true});
  if(resolved&&/node_modules[\\/](?:@codingame[\\/]monaco-vscode|vscode|monaco-editor)/.test(resolved.id))return {...resolved,id:resolved.id+'?inline'};
 }}]
});
