import asyncio,json,os,io,hashlib,zipfile
from PIL import Image
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/file-watermark/')
  for fmt,name in [('PNG','pixel.png'),('JPEG','pixel.jpg')]:
   original=io.BytesIO();Image.new('RGB',(16,16),(20,100,200)).save(original,format=fmt);source=original.getvalue()
   await page.locator('#file').set_input_files({'name':name,'mimeType':'image/'+fmt.lower(),'buffer':source});await page.locator('#label').fill('<b>中文编号 123</b>');await page.locator('#password').fill('test-secret')
   async with page.expect_download() as capture:await page.locator('#run').click()
   download=await capture.value;out=open(await download.path(),'rb').read();assert out!=source
   with Image.open(io.BytesIO(source)) as before,Image.open(io.BytesIO(out)) as after:assert before.tobytes()==after.tobytes()
   assert '校验通过' in await page.locator('#results').inner_text();assert await page.locator('#results b').count()==0
   async with page.expect_download() as capture:await page.locator('#restore').click()
   restored=await capture.value;assert open(await restored.path(),'rb').read()==source
   await page.locator('[data-mode=verify]').click();await page.locator('#file').set_input_files({'name':name,'mimeType':'image/'+fmt.lower(),'buffer':out});await page.locator('#run').click();await page.wait_for_function("document.querySelector('#status').textContent==='校验通过'")
   await page.locator('[data-mode=embed]').click()
  for w,h in [(1440,900),(390,844),(320,568),(844,390)]:
   await page.set_viewport_size({'width':w,'height':h});assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/watermark-desktop.png')
  assert not errors,errors;print(json.dumps({'base':BASE,'png_jpeg_pixels_unchanged':True,'reversible_byte_exact':True,'hmac':True,'safe_rendering':True,'layouts':4,'errors':errors}));await b.close()
asyncio.run(main())
