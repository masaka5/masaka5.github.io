import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page()
  await page.add_init_script('''Object.defineProperty(navigator,'serial',{value:{requestPort:async()=>({getInfo:()=>({}),async open(){this.readable=new ReadableStream({start(c){window.input=c;}});this.writable=new WritableStream();},async close(){return new Promise((resolve,reject)=>{window.rejectClose=reject;window.resolveClose=resolve;});}})}});''')
  await page.goto(BASE+'/tools/serial/');await page.locator('#connect').click();await page.evaluate("input.error(Error('removed'))");await page.wait_for_function("document.querySelector('#state').textContent==='正在断开'")
  assert await page.locator('#connect').is_disabled();assert await page.locator('#flash').is_disabled()
  await page.evaluate("rejectClose(Error('close failed'))");await page.wait_for_function("document.querySelector('#state').textContent==='端口未释放'");assert await page.locator('#connect').is_disabled();assert await page.locator('#flash').is_disabled()
  print(json.dumps({'base':BASE,'auto_close_pending_gated':True,'auto_close_failure_blocked':True}));await b.close()
asyncio.run(main())
