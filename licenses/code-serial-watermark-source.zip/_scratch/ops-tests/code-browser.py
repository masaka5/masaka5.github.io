"""Static workbench acceptance; uses its actual VS Code API, not a substitute editor."""
import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True)
  page=await browser.new_page(viewport={'width':1440,'height':900})
  errors=[];missing=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:missing.append(r.url) if r.status==404 and r.url.startswith(BASE) else None)
  r=await page.goto(BASE+'/tools/code/',wait_until='domcontentloaded');assert r.status==200,'Code workbench is missing'
  await page.wait_for_function('window.toolboxCode?.ready',timeout=120000)
  assert await page.locator('.monaco-workbench').count()==1
  assert await page.get_by_role('tab',name='资源管理器',exact=False).count()>0 or await page.locator('[aria-label*="资源管理器"]').count()>0
  info=await page.evaluate('async()=>await toolboxCode.inspect()')
  assert all(x in info['languages'] for x in ['powershell','python','javascript','rust']),info
  for filename,language,content in [('acceptance.ps1','powershell','Write-Host "中文"'),('acceptance.py','python','print("中文")'),('acceptance.rs','rust','fn main() { println!("中文"); }'),('acceptance.js','javascript','export {};\nconst greetingValue = "中文";\ngreetingValue.')]:
   result=await page.evaluate('async x=>await toolboxCode.createAndInspect(x)',{'filename':filename,'content':content})
   assert result['language']==language and result['tokens']>1,result
  completions=await page.evaluate('async()=>await toolboxCode.completions("/workspace/acceptance.js",3,15)')
  assert 'toUpperCase' in completions,completions[:20]
  await page.locator('.monaco-editor .view-lines').last.click();await page.keyboard.press('Control+a');await page.keyboard.insert_text('export {};\nconst savedByKeyboard = "autosave 中文";')
  await page.wait_for_function("async expected=>await toolboxCode.read('/workspace/acceptance.js')===expected",arg='export {};\nconst savedByKeyboard = "autosave 中文";')
  async with page.expect_download() as capture:await page.evaluate("toolboxCode.command('toolbox.export')")
  download=await capture.value
  with open(await download.path(),'r',encoding='utf8')as file:assert 'savedByKeyboard' in file.read()
  await page.evaluate('async()=>await toolboxCode.write("/workspace/persist.txt","刷新保存 中文")')
  await page.reload();await page.wait_for_function('window.toolboxCode?.ready',timeout=120000)
  assert await page.evaluate('async()=>await toolboxCode.read("/workspace/persist.txt")')=='刷新保存 中文'
  for w,h in [(1440,900),(390,844),(844,390)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(300)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/code-desktop.png')
  assert not errors,errors;assert not missing,missing
  print(json.dumps({'base':BASE,'workbench':True,'languages':info,'js_completions':len(completions),'refresh_persistence':True,'errors':errors,'missing':missing}))
  await browser.close()
asyncio.run(main())
