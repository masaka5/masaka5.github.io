import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page()
  await page.add_init_script('''window.calls=0;window.ends=0;Object.defineProperty(navigator,'serial',{value:{requestPort:async()=>({getInfo:()=>({}),async open(){this.readable=new ReadableStream();this.writable=new WritableStream({async write(){calls++;await new Promise(r=>setTimeout(r,300));ends++;}});},async close(){}})}});''')
  await page.goto(BASE+'/tools/serial/');await page.locator('#connect').click();await page.locator('#payload').fill('x');await page.locator('#periodic').check();await page.locator('#interval').fill('100');await page.locator('#send').click()
  await page.wait_for_function('calls===2&&ends===1');await page.locator('#send').click();await page.wait_for_timeout(650);assert await page.evaluate('calls')==2
  assert not await page.locator('#periodic').is_checked();await page.locator('#disconnect').click();print(json.dumps({'base':BASE,'stopping_during_slow_write':True,'no_extra_timer_chain':True}));await b.close()
asyncio.run(main())
