"""Browser-native OPFS handles simulate user authorized files without touching user disk."""
import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page()
  await page.goto(BASE+'/tools/code/');await page.wait_for_function('window.toolboxCode?.ready',timeout=120000)
  result=await page.evaluate('''async()=>{
   const root=await navigator.storage.getDirectory(),folder=await root.getDirectoryHandle('hardware-workspace',{create:true}),file=await folder.getFileHandle('device.txt',{create:true});
   let w=await file.createWritable();await w.write('Native file');await w.close();
   await toolboxCode.write('/workspace/device.txt','Browser draft');
   window.showDirectoryPicker=async()=>folder;await toolboxCode.command('toolbox.folder');
   await new Promise(resolve=>setTimeout(resolve,1500));
   if(!document.body.innerText.includes('hardware-workspace'))throw Error('Authorized folder missing from Explorer');
   const sameName=await root.getDirectoryHandle('workspace',{create:true}),collision=await sameName.getFileHandle('device.txt',{create:true});
   const collisionWriter=await collision.createWritable();await collisionWriter.write('Native collision');await collisionWriter.close();
   window.showDirectoryPicker=async()=>sameName;await toolboxCode.command('toolbox.folder');
   window.showOpenFilePicker=async()=>[file];await toolboxCode.command('toolbox.openFile');
   const source=await toolboxCode.read('/workspace/device.txt');if(source!=='Browser draft')throw Error('Native workspace shadowed drafts');
   const destination=await root.getFileHandle('saved.txt',{create:true});window.showSaveFilePicker=async()=>destination;await toolboxCode.command('toolbox.saveAs');
   if(await (await destination.getFile()).text()!=='Native file')throw Error('Save picker did not write active native file');
   return {draft_isolation:true,native_file_open:true,native_save_as:true};
  }''')
  print(json.dumps({'base':BASE,**result,'source':'real OPFS handles; picker selection supplied by test'}));await b.close()
asyncio.run(main())
