import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
FAKE='''(()=>{const serial=new EventTarget();window.writes=[];window.serialClosed=0;window.opened=0;serial.requestPort=async()=>{const port={getInfo:()=>({usbVendorId:0x10c4,usbProductId:0xea60}),async open(options){opened++;window.options=options;this.readable=new ReadableStream({start(c){window.serialInput=c;}});this.writable=new WritableStream({write(data){writes.push([...data]);}});},async close(){if(this.readable.locked||this.writable.locked)throw Error('Locked');serialClosed++;}};window.testPort=port;return port;};Object.defineProperty(navigator,'serial',{value:serial,configurable:true});})();'''
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True);page=await browser.new_page(viewport={'width':1440,'height':900})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)));await page.add_init_script(FAKE)
  await page.goto(BASE+'/tools/serial/');await page.locator('#connect').click();await page.wait_for_function('window.opened===1')
  await page.evaluate(r'''()=>{const b=new TextEncoder().encode('中文\n');serialInput.enqueue(b.slice(0,2));serialInput.enqueue(b.slice(2));}''')
  await page.wait_for_function("document.querySelector('#log').textContent.includes('中文')")
  await page.locator('#sendMode').select_option('hex');await page.locator('#payload').fill('01 fF');await page.locator('#send').click();await page.wait_for_function('writes.length===1');assert await page.evaluate('writes[0]')==[1,255]
  await page.locator('#payload').fill('0g');await page.locator('#send').click();assert await page.evaluate('writes.length')==1
  await page.locator('#payload').fill('aa');await page.locator('#periodic').check();await page.locator('#interval').fill('100');await page.locator('#send').click();await page.wait_for_function('writes.length>=3');await page.locator('#disconnect').click();await page.wait_for_function('serialClosed===1');n=await page.evaluate('writes.length');await page.wait_for_timeout(250);assert n==await page.evaluate('writes.length')
  await page.locator('[data-tab=firmware]').click();await page.locator('#flash').click();await page.wait_for_function("document.querySelector('#flashStatus').textContent.includes('固件')")
  await page.locator('.firmware-row input[type=file]').set_input_files({'name':'test.bin','mimeType':'application/octet-stream','buffer':b'\xe9\x00\x00\x00'})
  await page.locator('.address').fill('0x1000');await page.locator('#flash').click();await page.locator('#flashConfirm').wait_for(state='visible');assert await page.evaluate('opened')==1;await page.locator('#flashConfirm [value=cancel]').click();assert await page.evaluate('opened')==1
  for w,h in [(1440,900),(390,844),(320,568),(844,390)]:
   await page.set_viewport_size({'width':w,'height':h});assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.set_viewport_size({'width':1440,'height':900});await page.locator('[data-tab=monitor]').click();await page.screenshot(path='_scratch/serial-desktop.png')
  unsupported=await browser.new_page();await unsupported.add_init_script("Object.defineProperty(navigator,'serial',{value:undefined})");await unsupported.goto(BASE+'/tools/serial/');assert await unsupported.locator('#connect').is_disabled()
  assert not errors,errors;print(json.dumps({'base':BASE,'simulated_port':True,'split_utf8':True,'hex_validation':True,'stop_on_disconnect':True,'flash_confirmation_cancel':True,'layouts':4,'errors':errors}));await browser.close()
asyncio.run(main())
