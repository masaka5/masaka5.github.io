"""Render genuine PDF and open genuine DOCX/ZIP after browser metadata insertion."""
import asyncio,io,zipfile,os,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qa-python'))
import fitz
from docx import Document
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 pdf=fitz.open();pdf.new_page().insert_text((72,72),'Watermark compatibility');pdfbytes=pdf.tobytes();pdf.close()
 document=Document();document.add_paragraph('Office 中文内容');buf=io.BytesIO();document.save(buf);docbytes=buf.getvalue()
 zipbuf=io.BytesIO()
 with zipfile.ZipFile(zipbuf,'w')as z:z.writestr('content.txt','中文 ZIP');z.comment=b'existing comment'
 async with async_playwright()as p:
  browser=await p.chromium.launch(headless=True);page=await browser.new_page();await page.goto(BASE+'/tools/file-watermark/')
  for name,data in [('example.pdf',pdfbytes),('example.docx',docbytes),('example.zip',zipbuf.getvalue())]:
   out=bytes(await page.evaluate('''async x=>{const c=await import('./watermark-core.js');const b=new Uint8Array(x.data);const out=await c.embed(b,x.name,'兼容性测试 '+'.'.repeat(1900),'secret');const result=await c.verify(out,x.name,'secret');if(!result.markerValid||!result.contentValid)throw Error('Verification failed');const original=c.extract(out,x.name).original;if(original.length!==b.length||original.some((v,i)=>v!==b[i]))throw Error('Restoration failed');return [...out]}''',{'data':list(data),'name':name}))
   if name.endswith('.pdf'):
    before=fitz.open(stream=data,filetype='pdf');after=fitz.open(stream=out,filetype='pdf');assert len(before)==len(after)==1;assert before[0].get_text()==after[0].get_text();assert before[0].get_pixmap().samples==after[0].get_pixmap().samples;before.close();after.close()
   elif name.endswith('.docx'):assert [p.text for p in Document(io.BytesIO(out)).paragraphs]==['Office 中文内容']
   else:
    with zipfile.ZipFile(io.BytesIO(out))as z:assert z.testzip() is None;assert z.read('content.txt').decode()=='中文 ZIP'
  await browser.close()
 print(json.dumps({'base':BASE,'pdf_render_identical':True,'docx_open_content':True,'zip_members_intact':True,'long_marker':True,'restored_byte_exact':True}))
asyncio.run(main())
