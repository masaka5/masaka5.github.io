"""Generate reproducible source archive, dependency notices and runtime checksums."""
from pathlib import Path
import json,zipfile,hashlib,re
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site'
records=[]
for folder,section in [('code-build','code'),('serial-build','esptool')]:
 base=ROOT/'_scratch'/folder;out=SITE/'licenses'/section;out.mkdir(parents=True,exist_ok=True);texts=out/'texts';texts.mkdir(exist_ok=True)
 dependencies=[]
 for package in sorted((base/'node_modules').rglob('package.json')):
  try:meta=json.loads(package.read_text(encoding='utf8'))
  except Exception:continue
  if not meta.get('name') or not meta.get('version'):continue
  # Only actual package roots, not example fixture manifests.
  parent=package.parent
  if parent.parent.name!='node_modules' and not(parent.parent.name.startswith('@')and parent.parent.parent.name=='node_modules'):continue
  item={k:meta.get(k) for k in ['name','version','license','repository']};licenses=[]
  for p in parent.iterdir():
   if p.is_file()and re.match(r'^(license|licence|notice|thirdparty|third-party)',p.name,re.I):
    name=re.sub(r'[^a-zA-Z0-9_.-]','_',meta['name']+'_'+meta['version']+'_'+p.name)+'.txt';target=texts/name;target.write_bytes(p.read_bytes());licenses.append('texts/'+name)
  item['license_files']=licenses;dependencies.append(item)
 (out/'dependencies.json').write_text(json.dumps(dependencies,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 runtime=SITE/('tools/code' if section=='code' else 'vendor/esptool')
 manifest=[{'file':p.relative_to(runtime).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(runtime.rglob('*'))if p.is_file()and p.name!='manifest.json']
 (runtime/'manifest.json').write_text(json.dumps({'files':manifest},indent=2)+'\n',encoding='utf8')
 records.append({'project':section,'source':'https://github.com/CodinGame/monaco-vscode-api'if section=='code'else'https://github.com/espressif/esptool-js','version':'39.0.4'if section=='code'else'0.7.1','license':'MIT'if section=='code'else'Apache-2.0','dependencies':'licenses/'+section+'/dependencies.json','sourceArchive':'licenses/code-serial-watermark-source.zip'})
source=SITE/'licenses/sources.json';sources=json.loads(source.read_text(encoding='utf8'));sources=[s for s in sources if s.get('project')not in ['code','esptool']];sources.extend(records);source.write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
archive=SITE/'licenses/code-serial-watermark-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for folder in ['code-build','serial-build']:
  for p in (ROOT/'_scratch'/folder).rglob('*'):
   rel=p.relative_to(ROOT/'_scratch'/folder)
   if not p.is_file()or 'node_modules'in rel.parts or p.suffix=='.log':continue
   z.write(p,'_scratch/'+folder+'/'+rel.as_posix())
 for folder in ['serial','file-watermark']:
  for p in (SITE/'tools'/folder).glob('*'):
   if p.is_file():z.write(p,'toolbox-site/tools/'+folder+'/'+p.name)
 for p in (ROOT/'_scratch/ops-tests').glob('*'):
  if p.is_file()and p.name.startswith(('code-','serial','flash','watermark')):z.write(p,'_scratch/ops-tests/'+p.name)
 z.write(Path(__file__),'_scratch/'+Path(__file__).name)
 z.writestr('BUILD.md','# 构建\n\nNode 22+、npm、Python 3。\n\n`npm ci --prefix _scratch/code-build` 后 `npm run build --prefix _scratch/code-build`；`npm ci --prefix _scratch/serial-build` 后 `npm run build --prefix _scratch/serial-build`；运行 `python _scratch/package-code-serial-watermark.py` 重建许可清单。两个构建目录必须在项目根的 _scratch 下，构建产物写入 toolbox-site。所有运行库固定锁文件，直接 npm 获取，无新增后端。\n\n代码工作台使用 Code OSS/MIT 部件，不是 Microsoft vscode.dev 官方部署。扩展能力见工具箱的“内置语言”命令。串口烧录为 esptool-js 支持的 ESP 芯片，真实设备需另验；水印为可逆格式元数据，不保证抗删除。\n')
print(json.dumps({'source_archive_mb':round(archive.stat().st_size/1048576,2),'projects':records}))
