# 构建

Node 22+、npm、Python 3。

`npm ci --prefix _scratch/code-build` 后 `npm run build --prefix _scratch/code-build`；`npm ci --prefix _scratch/serial-build` 后 `npm run build --prefix _scratch/serial-build`；运行 `python _scratch/package-code-serial-watermark.py` 重建许可清单。两个构建目录必须在项目根的 _scratch 下，构建产物写入 toolbox-site。所有运行库固定锁文件，直接 npm 获取，无新增后端。

代码工作台使用 Code OSS/MIT 部件，不是 Microsoft vscode.dev 官方部署。扩展能力见工具箱的“内置语言”命令。串口烧录为 esptool-js 支持的 ESP 芯片，真实设备需另验；水印为可逆格式元数据，不保证抗删除。
