import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { AppRoot } from './AppRoot';
import './index.css';
import './toolbox.css';
import {TOOLS} from './lib/constants';
import {TOOL_CATALOGUE,isToolAlias} from './lib/pdf/tools/registry';
(window as any).ToolboxDocumentTools=TOOLS.filter(t=>!isToolAlias(t.id)).map(t=>({...t,unavailable:TOOL_CATALOGUE.find(p=>p.id===t.id)?.unavailable||''}));

// The router flags and the error boundary that keep a tool from blanking the
// whole app live in AppRoot, so a test can mount this exact tree.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppRoot />
  </StrictMode>
);
