import { useFileStore, type ToolFileSlot } from './file-store';
import { useProcessStore, emptyProcessSlot, type ProcessSlot } from './process-store';

export interface SnapshotStorage { read(): Promise<unknown>; write(value: unknown): Promise<void> }
const MAX_BYTES = 128 * 1024 * 1024;
const MAX_TOOLS = 10;
const MAX_AGE = 7 * 24 * 60 * 60 * 1000;
const sensitive = /password|passphrase|cookie|token|credential|secret|authorization|private.?key|certificate|pkcs/i;
interface StoredFile { blob: Blob; name: string; lastModified: number }
interface Entry { touched: number; files: StoredFile[]; params: Record<string, unknown>; preview: number; outputs: Blob[]; names: string[]; label: string; suffix: string; pagesOut: number | null; bytes: number }
interface Snapshot { version: 1; entries: Record<string, Entry> }

/** Only bounded structured parameter data. Credentials and ephemeral URLs never go to disk. */
export function safeParams(input: unknown, depth = 0): any {
  if (depth > 12) return undefined;
  if (typeof input === 'string') return input.startsWith('blob:') || input.length > 131072 ? undefined : input;
  if (typeof input === 'number') return Number.isFinite(input) ? input : undefined;
  if (input === null || typeof input === 'boolean') return input;
  if (Array.isArray(input)) return input.slice(0, 2000).map(v => safeParams(v, depth + 1)).filter(v => v !== undefined);
  if (input && Object.getPrototypeOf(input) === Object.prototype) {
    return Object.fromEntries(Object.entries(input).filter(([key]) => !sensitive.test(key) && !['__proto__','constructor','prototype'].includes(key))
      .map(([key,value]) => [key,safeParams(value,depth+1)]).filter(([,value]) => value !== undefined));
  }
  return undefined;
}
function hasSecrets(value: unknown, depth=0): boolean {
  if(depth>12)return false;
  return !!value && typeof value === 'object' && Object.entries(value).some(([key,v]) => (sensitive.test(key) && Boolean(v)) || hasSecrets(v,depth+1));
}
function allFiles(slot: ToolFileSlot): File[] { return slot.files.length ? slot.files : slot.file ? [slot.file] : []; }
const encryptionChecks = new WeakMap<File,Promise<boolean>>();
async function encrypted(files: File[], slot?: ProcessSlot) {
  if (Object.values(slot?.fileStates ?? {}).some(s => s.lock && s.lock !== 'none')) return true;
  // Preserve original encrypted inputs, but no decoded output/authority from those inputs.
  for (const file of files) if (/pdf/i.test(file.type) || /\.pdf$/i.test(file.name)) {
    let check=encryptionChecks.get(file);
    if(!check){check=file.arrayBuffer().then(buffer=>/\/Encrypt\b/.test(new TextDecoder('latin1').decode(buffer)));encryptionChecks.set(file,check);}
    if(await check)return true;
  }
  return false;
}
function valid(value: unknown): value is Snapshot { return !!value && (value as Snapshot).version === 1 && typeof (value as Snapshot).entries === 'object'; }
function trim(entries: Record<string,Entry>, budget = MAX_BYTES) {
  const list = Object.entries(entries).filter(([,entry])=>entry&&Number.isFinite(entry.touched)&&Number.isFinite(entry.bytes)&&entry.bytes>=0).sort((a,b)=>b[1].touched-a[1].touched);
  let bytes = 0; return Object.fromEntries(list.filter(([,entry],index) => {
    if (!entry || !Array.isArray(entry.files) || !Array.isArray(entry.outputs) || Date.now()-entry.touched > MAX_AGE || index >= MAX_TOOLS || entry.bytes > budget || bytes+entry.bytes > budget) return false;
    bytes += entry.bytes; return true;
  }));
}

/** One atomic IndexedDB record; bounded read/open time and no localStorage binary copies. */
export function indexedDbStorage(): SnapshotStorage {
  async function transaction(mode: IDBTransactionMode, value?: unknown) {
    return new Promise<unknown>((resolve,reject) => {
      if (!globalThis.indexedDB) return reject(new Error('IndexedDB unavailable'));
      let database: IDBDatabase | undefined,activeTx:IDBTransaction|undefined,settled=false;
      const timer = setTimeout(()=>{settled=true;try{activeTx?.abort();}catch{}database?.close();reject(new Error('IndexedDB unavailable'));},2000);
      const fail = (error: unknown) => {clearTimeout(timer);database?.close();reject(error);};
      let request: IDBOpenDBRequest;
      try { request=indexedDB.open('toolbox-browsersnip-sessions',1); } catch(error) {fail(error);return;}
      request.onupgradeneeded=()=>request.result.createObjectStore('snapshots');
      request.onerror=()=>fail(request.error);
      request.onblocked=()=>fail(new Error('IndexedDB blocked'));
      request.onsuccess=()=>{
        database=request.result;if(settled){database.close();return;}let result:unknown;
        try {
          const tx=database.transaction('snapshots',mode);activeTx=tx;const store=tx.objectStore('snapshots');
          const op=mode==='readonly'?store.get('current'):store.put(value,'current');
          op.onsuccess=()=>{result=op.result;};
          tx.oncomplete=()=>{clearTimeout(timer);database?.close();resolve(result);};
          tx.onerror=()=>fail(tx.error);tx.onabort=()=>fail(tx.error);
        }catch(error){fail(error);}
      };
    });
  }
  return {read:()=>transaction('readonly'),write:async value=>{await transaction('readwrite',value);}};
}

export function createSessionRecovery(storage: SnapshotStorage = indexedDbStorage()) {
  let revision=0, hydrated=false, applying=false, disposed=false, pending=false;
  let timer: ReturnType<typeof setTimeout> | undefined, writing: Promise<void> | undefined;
  let known: Record<string,Entry> = {};
  const visited = new Map<string,number>();
  const changed=()=>{if(applying||disposed)return;revision++;pending=true;if(hydrated&&!timer)timer=setTimeout(()=>{timer=undefined;void flush();},0);};
  const stopFiles=useFileStore.subscribe((state,previous)=>{
    if(!applying&&state.activeTool===previous.activeTool&&(state.files!==previous.files||state.file!==previous.file)){
      const result=useProcessStore.getState();
      if(result.activeTool===state.activeTool&&(result.outputBlobs.length||result.report))result.reset();
    }
    if(state.activeTool&&state.activeTool!==previous.activeTool)visited.set(state.activeTool,Date.now());
    changed();
  }),stopProcess=useProcessStore.subscribe(changed);
  async function capture(): Promise<Snapshot> {
    const fs=useFileStore.getState(),ps=useProcessStore.getState();
    const fileSlots={...fs.sessions,...(fs.activeTool?{[fs.activeTool]:fs}:{})};
    const processSlots: Record<string,ProcessSlot|undefined>={...ps.sessions,...(ps.activeTool?{[ps.activeTool]:ps}:{})};
    const entries: Record<string,Entry>={};
    for(const [id,slot] of Object.entries(fileSlots)){
      if(!slot)continue;const files=allFiles(slot);const result=processSlots[id];
      if(files.reduce((n,f)=>n+f.size,0)>MAX_BYTES)continue;
      const params=safeParams(slot.params)??{};
      const protectedResult=hasSecrets(slot.params)||await encrypted(files,result);
      const outputs=result?.phase==='done'&&!result.isProcessing&&!protectedResult?result.outputBlobs:[];
      if(!files.length&&!Object.keys(params).length&&!outputs.length)continue;
      const bytes=files.reduce((n,f)=>n+f.size,0)+outputs.reduce((n,b)=>n+b.size,0)+JSON.stringify(params).length*2;
      const previous=known[id];const touched=id===fs.activeTool?Date.now()+1:visited.get(id)??previous?.touched??Date.now();
      entries[id]={touched,files:files.map(file=>({blob:file,name:file.name,lastModified:file.lastModified})),params,preview:slot.previewFileIndex??0,outputs,names:outputs.map((_,i)=>result?.outputNames[i]??`output-${i+1}`),label:result?.label??'',suffix:result?.suffix??'',pagesOut:result?.pagesOut??null,bytes};
    }
    return {version:1,entries:trim(entries)};
  }
  async function hydrate(){
    const initial=revision;
    try {
      const stored=await storage.read();
      if(disposed||revision!==initial||!valid(stored))return;
      known=trim(stored.entries);
      const fileSlots: Record<string,ToolFileSlot>={},processSlots: Record<string,ProcessSlot>={};
      for(const [id,entry] of Object.entries(known)){
        try{
          if(!entry.files.every(f=>f?.blob instanceof Blob&&typeof f.name==='string')||!entry.outputs.every(b=>b instanceof Blob)||!Array.isArray(entry.names)||!entry.names.every(n=>typeof n==='string'))continue;
          const restored=entry.files.map(f=>new File([f.blob],f.name,{type:f.blob.type,lastModified:f.lastModified}));
          fileSlots[id]={file:restored[0]??null,files:restored,params:safeParams(entry.params)??{},previewFileIndex:Math.max(0,Math.min(Number.isFinite(entry.preview)?entry.preview:0,Math.max(0,restored.length-1))),metadata:null,codecWarning:null,isLargeFile:restored.some(f=>f.size>500*1024*1024)};
          const urls=entry.outputs.map(blob=>URL.createObjectURL(blob));
          processSlots[id]={...emptyProcessSlot(),phase:entry.outputs.length?'done':restored.length?'ready':'idle',outputBlobs:entry.outputs,outputBlob:entry.outputs[0]??null,outputUrls:urls,outputUrl:urls[0]??null,outputNames:entry.names,label:entry.label,suffix:entry.suffix,pagesOut:entry.pagesOut,sizeAfter:entry.outputs.reduce((n,b)=>n+b.size,0)};
        }catch{/* Ignore a corrupt entry; other tools remain recoverable. */}
      }
      applying=true;useFileStore.setState({sessions:fileSlots,probing:false});useProcessStore.setState({sessions:processSlots,isProcessing:false});applying=false;
    }catch{/* Storage is optional; tools remain usable. */}
    finally{hydrated=true;if(pending)void flush();}
  }
  async function flush(): Promise<void>{
    if(timer){clearTimeout(timer);timer=undefined;}
    if(disposed||!hydrated)return;
    if(writing){await writing;if(pending)return flush();return;}
    writing=(async()=>{
      while(pending&&!disposed){pending=false;let snapshot:Snapshot;try{snapshot=await capture();}catch{continue;}
        // Ordered, coalesced writes; a newer snapshot always follows an older in-flight write.
        try{await storage.write(snapshot);known=snapshot.entries;}catch{
          try{snapshot.entries=trim(snapshot.entries,MAX_BYTES/4);await storage.write(snapshot);known=snapshot.entries;}catch{/* Quota/private-mode failure does not affect live stores. */}
        }
      }
    })();
    try{await writing;}finally{writing=undefined;}
  }
  function dispose(){disposed=true;stopFiles();stopProcess();if(timer)clearTimeout(timer);}
  return {hydrate,flush,dispose};
}
