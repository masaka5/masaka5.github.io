import { create } from 'zustand';
import type { VideoMetadata, PDFMetadata, ToolId } from '@/types';

export interface ToolFileSlot {
  file: File | null;
  files: File[];
  metadata: VideoMetadata | PDFMetadata | null;
  isLargeFile: boolean;
  params: Record<string, unknown>;
  codecWarning: string | null;
  previewFileIndex: number;
}

interface FileState {
  activeTool: ToolId | null;
  sessions: Partial<Record<ToolId, ToolFileSlot>>;
  file: File | null;
  files: File[];
  metadata: VideoMetadata | PDFMetadata | null;
  isLargeFile: boolean;
  params: Record<string, unknown>;
  codecWarning: string | null;
  probing: boolean;
  previewFileIndex: number;

  setActiveTool: (tool: ToolId | null) => void;
  setFile: (file: File | null) => void;
  addFile: (file: File) => void;
  removeFile: (index: number) => void;
  reorderFiles: (from: number, to: number) => void;
  setFiles: (files: File[]) => void;
  setMetadata: (meta: VideoMetadata | PDFMetadata | null) => void;
  setParams: (params: Record<string, unknown>) => void;
  setCodecWarning: (warning: string | null) => void;
  setProbing: (probing: boolean) => void;
  setPreviewFileIndex: (index: number) => void;
  persistCurrent: () => void;
  clearCurrent: () => void;
}

const emptySlot = (): ToolFileSlot => ({
  file: null,
  files: [],
  metadata: null,
  isLargeFile: false,
  params: {},
  codecWarning: null,
  previewFileIndex: 0,
});

export const useFileStore = create<FileState>((set, get) => ({
  activeTool: null,
  sessions: {},
  file: null,
  files: [],
  metadata: null,
  isLargeFile: false,
  params: {},
  codecWarning: null,
  probing: false,
  previewFileIndex: 0,

  setActiveTool: (tool) => {
    const state = get();
    if (state.activeTool === tool) return;
    if (state.activeTool && state.activeTool !== tool) {
      set((s) => ({
        sessions: {
          ...s.sessions,
          [state.activeTool!]: {
            file: s.file,
            files: s.files,
            metadata: s.metadata,
            isLargeFile: s.isLargeFile,
            params: s.params,
            codecWarning: s.codecWarning,
            previewFileIndex: s.previewFileIndex,
          },
        },
      }));
    }
    const slot = tool ? state.sessions[tool] : null;
    set({
      activeTool: tool ?? undefined,
      file: slot?.file ?? null,
      files: slot?.files ?? [],
      metadata: slot?.metadata ?? null,
      isLargeFile: slot?.isLargeFile ?? false,
      params: slot?.params ?? {},
      codecWarning: slot?.codecWarning ?? null,
      previewFileIndex: slot?.previewFileIndex ?? 0,
      probing: false,
    });
  },

  setFile: (file) =>
    set({
      file,
      files: file ? [file] : [],
      isLargeFile: (file?.size ?? 0) > 500 * 1024 * 1024,
      metadata: null,
      codecWarning: null,
      previewFileIndex: 0,
    }),

  addFile: (file) =>
    set((state) => {
      const files = [...state.files, file];
      return {
        files,
        file: files[0] ?? null,
        isLargeFile: files.some((f) => f.size > 500 * 1024 * 1024),
        metadata: null,
      };
    }),

  removeFile: (index) =>
    set((state) => {
      const files = state.files.filter((_, i) => i !== index);
      return {
        files,
        file: files[0] ?? null,
        isLargeFile: files.some((f) => f.size > 500 * 1024 * 1024),
      };
    }),

  reorderFiles: (from, to) =>
    set((state) => {
      const files = [...state.files];
      const [moved] = files.splice(from, 1);
      files.splice(to, 0, moved);
      return { files };
    }),

  setFiles: (files) =>
    set({
      files,
      file: files[0] ?? null,
      isLargeFile: files.some((f) => f.size > 500 * 1024 * 1024),
    }),

  setMetadata: (meta) => set({ metadata: meta }),

  setParams: (params) => set({ params }),

  setCodecWarning: (warning) => set({ codecWarning: warning }),

  setProbing: (probing) => set({ probing }),

  setPreviewFileIndex: (index) => set({ previewFileIndex: index }),

  persistCurrent: () => {
    const state = get();
    if (!state.activeTool) return;
    set((s) => ({
      sessions: {
        ...s.sessions,
        [state.activeTool!]: {
          file: s.file,
          files: s.files,
          metadata: s.metadata,
          isLargeFile: s.isLargeFile,
          params: s.params,
          codecWarning: s.codecWarning,
          previewFileIndex: s.previewFileIndex,
        },
      },
    }));
  },

  clearCurrent: () =>
    set(state => ({
      sessions: state.activeTool ? {...state.sessions,[state.activeTool]:emptySlot()} : state.sessions,
      file: null,
      files: [],
      metadata: null,
      isLargeFile: false,
      params: {},
      codecWarning: null,
      previewFileIndex: 0,
    })),
}));

