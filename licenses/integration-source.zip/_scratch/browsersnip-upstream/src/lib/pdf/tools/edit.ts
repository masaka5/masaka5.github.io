/**
 * Edit PDF tools — page marks, stamps, navigation and content colour.
 *
 * Everything here draws real PDF content through `core/fonts`, which is what
 * fixes the long-standing crash where any Cyrillic, Greek or CJK watermark,
 * page number or Bates stamp threw `WinAnsi cannot encode …`.
 *
 * Two rules govern every mark drawn below, because these tools write into the
 * page itself:
 *
 * - Geometry is worked out in *displayed* coordinates and converted back to PDF
 *   user space (`frameOf`, `placeRun`, `toUserSpace`). A `/Rotate 90` page turns
 *   the rendered sheet 90° clockwise, so anchoring on the crop box directly put
 *   a "bottom centre" page number on the left edge and drew it sideways (E9).
 * - The frame comes from the page being drawn on, never from page 1, so a mixed
 *   size document measures each page on its own (E8).
 *
 * Anything a tool could not do exactly as asked — a clamped value, a skipped
 * page, a substituted typeface — is collected in a `notes` array and returned
 * as `result.warnings`, never buried in a success message.
 */
import type { PDFDocument, PDFPage, PDFFont } from '../core/doc';
import { PDFArray, PDFName, PDFRef, degrees, rgb, savePDF } from '../core/doc';
import { drawTextU, measureText, wrapText } from '../core/fonts';
import { mergeFaceStyle, standardFamilyFace, standardFacesSpell, type FaceStyle } from '../core/text-style';
import { faceColor, readTextStyle, rememberTextStyle, textStyleFields } from './textStyleFields';
import { cropBox, displayedSize, resolvePages, type PageBox } from '../core/pages';
import { addPageLabels, readPageLabels, writeOutline, readOutline, type OutlineNode } from '../core/bookmarks';
import { hasXfa, listFormFields, type CreateFieldSpec } from '../core/forms';
import type { OcrPageResult } from '../core/ocr';
import { canvasToBlob } from '../core/render';
import { embedImageBytes } from '../core/pack';
import { newPDF } from '../core/doc';
import { clampNumber, openInputs, pagesField, pdfResult, reportResult, throwIfAborted, withRender, downloadStem, type OpenedInput } from './helpers';
import {
  booleanValue,
  numberValue,
  stringValue,
  stringValues,
  type PdfToolDefinition,
  type ToolResult,
  type ToolRunContext,
} from './types';

type Anchor = 'top-left' | 'top-center' | 'top-right' | 'center-left' | 'center' | 'center-right' | 'bottom-left' | 'bottom-center' | 'bottom-right';

/** A rectangle in the coordinates a viewer shows the page in. */
interface RunRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * The page as the reader sees it.
 *
 * `/Rotate` is *not* applied to the stored geometry, only to the rendering, so
 * on a `/Rotate 90` page the visible corners are nowhere near the page-space
 * ones and the visible width is the stored height. Marks are placed here and
 * converted back before they are drawn (E9).
 */
interface PageFrame {
  /** Crop box in unrotated PDF user space. */
  box: PageBox;
  /** `/Rotate` normalised to a multiple of 90. */
  rotation: 0 | 90 | 180 | 270;
  /** Visible width and height, after `/Rotate`. */
  width: number;
  height: number;
}

function frameOf(page: PDFPage): PageFrame {
  const box = cropBox(page);
  const angle = Math.round(page.getRotation().angle / 90) * 90;
  const rotation = (((angle % 360) + 360) % 360) as 0 | 90 | 180 | 270;
  const quarter = rotation === 90 || rotation === 270;
  return {
    box,
    rotation,
    width: quarter ? box.height : box.width,
    height: quarter ? box.width : box.height,
  };
}

/** A displayed-space point (origin: bottom-left of the visible page) in PDF user space. */
function toUserSpace(frame: PageFrame, x: number, y: number): { x: number; y: number } {
  const { box, rotation } = frame;
  if (rotation === 90) return { x: box.x + box.width - y, y: box.y + x };
  if (rotation === 180) return { x: box.x + box.width - x, y: box.y + box.height - y };
  if (rotation === 270) return { x: box.x + y, y: box.y + box.height - x };
  return { x: box.x + x, y: box.y + y };
}

/**
 * A displayed-space rectangle in PDF user space. Still axis-aligned, because
 * `/Rotate` is always a multiple of 90 — the sizes just swap on a quarter turn.
 */
function toUserRect(frame: PageFrame, rect: RunRect): PageBox {
  const a = toUserSpace(frame, rect.x, rect.y);
  const b = toUserSpace(frame, rect.x + rect.width, rect.y + rect.height);
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    width: Math.abs(b.x - a.x),
    height: Math.abs(b.y - a.y),
  };
}

/** Which edges an anchor name refers to, once, instead of re-deriving them by string position. */
const ANCHOR_AXIS: Record<Anchor, { horizontal: 'left' | 'center' | 'right'; vertical: 'top' | 'center' | 'bottom' }> = {
  'top-left': { horizontal: 'left', vertical: 'top' },
  'top-center': { horizontal: 'center', vertical: 'top' },
  'top-right': { horizontal: 'right', vertical: 'top' },
  'center-left': { horizontal: 'left', vertical: 'center' },
  center: { horizontal: 'center', vertical: 'center' },
  'center-right': { horizontal: 'right', vertical: 'center' },
  'bottom-left': { horizontal: 'left', vertical: 'bottom' },
  'bottom-center': { horizontal: 'center', vertical: 'bottom' },
  'bottom-right': { horizontal: 'right', vertical: 'bottom' },
};

function anchorAxis(anchor: string): { horizontal: 'left' | 'center' | 'right'; vertical: 'top' | 'center' | 'bottom' } {
  return ANCHOR_AXIS[anchor as Anchor] ?? ANCHOR_AXIS.center;
}

/** The visible bounding box of a `width` × `height` run turned by `angle` degrees. */
function runBounds(width: number, height: number, angle: number) {
  const rad = (angle * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  const corner = (x: number, y: number) => ({ x: x * cos - y * sin, y: x * sin + y * cos });
  const points = [corner(0, 0), corner(width, 0), corner(width, height), corner(0, height)];
  const xs = points.map((point) => point.x);
  const ys = points.map((point) => point.y);
  const minX = Math.min(...xs);
  const minY = Math.min(...ys);
  return { minX, minY, width: Math.max(...xs) - minX, height: Math.max(...ys) - minY };
}

/**
 * Where a run starts in displayed coordinates so its visible box sits at
 * `anchor` with `margin` of clearance.
 *
 * The margin shrinks when the page is too small for it (E8: a business card is
 * measured as a business card), and a run wider than the page is centred rather
 * than pushed off the edge — the caller reports the overhang.
 */
function placeRun(frame: PageFrame, width: number, height: number, angle: number, anchor: string, margin: number) {
  const bounds = runBounds(width, height, angle);
  const axis = anchorAxis(anchor);
  const roomX = frame.width - bounds.width;
  const roomY = frame.height - bounds.height;
  const mx = Math.min(Math.max(margin, 0), Math.max(0, roomX) / 2);
  const my = Math.min(Math.max(margin, 0), Math.max(0, roomY) / 2);
  const leftEdge = { left: mx, right: roomX - mx, center: roomX / 2 }[axis.horizontal];
  const topEdge = { top: roomY - my, bottom: my, center: roomY / 2 }[axis.vertical];
  return {
    x: leftEdge - bounds.minX,
    y: topEdge - bounds.minY,
    bounds,
    overflow: roomX < -0.5 || roomY < -0.5,
  };
}

/**
 * Record an admission once.
 *
 * A 500-page run stamps the same page size five hundred times; the result card
 * needs the sentence once (E7).
 */
function note(notes: string[], message: string): void {
  if (!notes.includes(message)) notes.push(message);
}

/** Latin-only standard faces, keyed the way the `font` picker names them. */
/**
 * Position text inside the page as the reader sees it, honouring /Rotate (E9),
 * measuring that page alone (E8) and never drawing unsupported glyphs with a
 * WinAnsi face (E11). Returns the run width in points.
 */
async function stamp(
  doc: PDFDocument,
  page: PDFPage,
  text: string,
  options: {
    anchor: Anchor;
    /** The shared style model: family, weight, slant, size and colour. */
    style: FaceStyle;
    rotation?: number;
    opacity?: number;
    margin?: number;
    notes?: string[];
  },
): Promise<number> {
  const notes = options.notes ?? [];
  const style = options.style;
  const size = style.size;
  const frame = frameOf(page);
  const angle = options.rotation ?? 0;
  // The face is chosen the way every other writer chooses it: a standard-14 family
  // answers with its own named face at the asked posture (a real oblique, not a
  // slanted regular), and anything past that goes through `core/fonts`, which embeds
  // a subset and is reported. A posture the answering face cannot carry is said.
  const face = await railFace(doc, style, text, notes);
  const width = face
    ? face.widthOfTextAtSize(text, size)
    : (await measureText(doc, { text, x: 0, y: 0, size, bold: style.bold, italic: style.italic })).width;
  const run = placeRun(frame, width, size, angle, options.anchor, options.margin ?? 24);
  if (run.overflow) {
    note(notes, `“${[...text].slice(0, 18).join('')}” does not fit inside a ${Math.round(frame.width)}×${Math.round(frame.height)} pt page, so it runs past the edges.`);
  }
  const origin = toUserSpace(frame, run.x, run.y);
  // Text is turned by the page's own /Rotate on top of the requested angle, so
  // what the user sees as "45°" reads as 45° in a viewer whatever /Rotate is.
  const pageAngle = angle + frame.rotation;
  if (face) {
    page.drawText(text, {
      x: origin.x,
      y: origin.y,
      size,
      font: face,
      color: faceColor(style.color),
      opacity: options.opacity,
      rotate: degrees(pageAngle),
    });
  } else {
    await drawTextU(page, {
      text,
      x: origin.x,
      y: origin.y,
      size,
      color: faceColor(style.color),
      bold: style.bold,
      italic: style.italic,
      opacity: options.opacity,
      rotation: pageAngle,
    });
  }
  return width;
}

/**
 * The named face for a rail style, or `null` when the embedded path must answer.
 *
 * `null` is not a failure: it is the case where the family has no face for the run
 * (a Latin-only pick past WinAnsi, or a pick this tab has no bytes for), and
 * `drawTextU` then embeds one. The caller reports which happened, so a substituted
 * folio never looks like the family that was chosen.
 *
 * A standard-14 family answers from its **own named faces** at the asked posture —
 * `Helvetica-Bold`, `Times-Italic`, `Courier-BoldOblique` — which is the whole reason
 * italic is offered for those three and nowhere else: the app has no italic file for
 * the bundled Noto, and a slant the file cannot carry is a preview that lies.
 */
async function railFace(
  doc: PDFDocument,
  style: FaceStyle,
  text: string,
  notes: string[],
): Promise<PDFFont | null> {
  const face = standardFamilyFace(style.fontFamily, style.bold, style.italic);
  if (!face) return null;
  if (!standardFacesSpell(text)) {
    const sample = [...text].slice(0, 12).join('');
    note(notes, `“${style.fontFamily.replace(/^std:/, '')}” cannot render “${sample}” — it is a Latin-only face, so an embedded Unicode font was used instead${style.italic ? ', and the slant with it: the bundled faces hold no italic' : ''}.`);
    return null;
  }
  return doc.embedFont(face);
}

/**
 * The face a stamp label is drawn with, embedded if need be.
 *
 * `addAnnotations` is synchronous (contract §2), so a stamp whose family is not one
 * of the three named ones cannot have its face fetched by the annotation writer. The
 * tool embeds it here and the appearance stream writes exactly that. `null` means the
 * writer's own standard-14 answer is already the right one.
 */
async function stampLabelFace(
  doc: PDFDocument,
  style: FaceStyle,
  label: string,
  notes: string[],
): Promise<PDFFont | null> {
  const named = await railFace(doc, style, label, notes);
  if (named) return named;
  const { getFont } = await import('../core/fonts');
  return getFont(doc, {
    text: label,
    size: style.size,
    bold: style.bold,
    italic: style.italic,
    fontFamily: style.fontFamily || undefined,
  });
}

/** Numeric option bounds, mirroring what the rail declared for the same field (E15). */
interface NumberOption {
  key: string;
  label: string;
  fallback: number;
  min: number;
  max: number;
  integer?: boolean;
  unit?: string;
}

/**
 * Clamp one form value and admit it (E15: "clamped or rejected with a reason").
 *
 * `core/guard` clamps the same fields in the runner; this is the backstop for
 * values that arrive from a bespoke pane, the legacy `params` objects, or a
 * direct `run()` call, where nothing else has looked at them.
 */
/**
 * Clamp one option into range and record it (E15: "clamped or rejected with a
 * reason").
 *
 * `core/guard` clamps the same fields in the runner with the same sentence, so a
 * corrected value reads identically whichever layer caught it; this is the
 * backstop for values that arrive from a bespoke pane, the legacy `params`
 * objects, or a direct `run()` call, where nothing else has looked at them.
 */
function bounded(
  notes: string[],
  label: string,
  raw: number,
  option: { min: number; max: number; integer?: boolean; unit?: string },
): number {
  const value = clampNumber(raw, option.min, option.max, { integer: option.integer });
  if (value !== raw) {
    note(notes, `${label} must be ${boundsSentence(option)}: ${raw} became ${value}.`);
  }
  return value;
}

function boundsSentence(option: { min: number; max: number; unit?: string }): string {
  const unit = option.unit ? ` ${option.unit}` : '';
  const hasMin = Number.isFinite(option.min);
  const hasMax = Number.isFinite(option.max);
  if (hasMin && hasMax) {
    return option.min === option.max ? `${option.min}${unit}` : `between ${option.min} and ${option.max}${unit}`;
  }
  if (hasMin) return `at least ${option.min}${unit}`;
  if (hasMax) return `at most ${option.max}${unit}`;
  return 'a number';
}

function readNumber(context: ToolRunContext, notes: string[], option: NumberOption): number {
  const raw = numberValue(context.values, option.key, option.fallback);
  return bounded(notes, option.label, raw, option);
}

/** Attach the run's admissions to a result — `pdfResult` takes no warnings option. */
function admit(result: ToolResult, notes: string[]): ToolResult {
  if (notes.length > 0) result.warnings = notes;
  return result;
}

async function pdfOutput(doc: PDFDocument, notes: string[], message: string): Promise<ToolResult> {
  return admit(await pdfResult(doc, { message }), notes);
}

/**
 * Draw with `paint`'s operators placed *behind* the page's existing content.
 *
 * pdf-lib appends one content stream per draw call and `/Contents` is painted in
 * order, so the streams that appeared during `paint` are joined into one and put
 * in front of the streams that were already there. Without this, "Placement:
 * Behind content" was a zero-size no-op rectangle that still reported a
 * watermark (E13).
 */
async function drawBehind(page: PDFPage, paint: () => Promise<void> | void): Promise<void> {
  const { joinContentStreams, pageContentStreams, setContentStreams } = await import('../core/content');
  const before = new Set(pageContentStreams(page).map((stream) => stream.ref.toString()));
  await paint();
  const streams = pageContentStreams(page);
  const kept = streams.filter((stream) => before.has(stream.ref.toString()));
  const fresh = streams.filter((stream) => !before.has(stream.ref.toString()));
  if (fresh.length === 0) return;
  const mark = joinContentStreams(page, fresh.map((stream) => stream.ref), { textFirst: true });
  if (kept.length === 0) {
    setContentStreams(page, [mark]);
    return;
  }
  // pdf-lib wraps a loaded page's content in its own `q`/`Q` streams. They belong
  // with the content they wrap, so the group is folded into one stream and the
  // mark becomes the only stream in front of it.
  const first = kept[0].ref;
  joinContentStreams(page, kept.map((stream) => stream.ref), { into: first });
  setContentStreams(page, [mark, first]);
}

/**
 * True when the page writes `/CropBox` as an empty array.
 *
 * An absent `/CropBox` means "the MediaBox is the crop"; an empty one is a
 * producer saying this page has no visible box, which no measurement of the
 * MediaBox can reveal.
 */
function declaredCropBoxIsEmpty(page: PDFPage): boolean {
  const raw = page.node.get(PDFName.of('CropBox'));
  const value = raw instanceof PDFRef ? page.doc.context.lookup(raw) : raw;
  return value instanceof PDFArray && value.size() === 0;
}

const ANCHOR_OPTIONS = [
  { value: 'top-left', label: "左上" },
  { value: 'top-center', label: "顶部中心" },
  { value: 'top-right', label: "右上角" },
  { value: 'center-left', label: "中左" },
  { value: 'center', label: "中心" },
  { value: 'center-right', label: "右中" },
  { value: 'bottom-left', label: "左下角" },
  { value: 'bottom-center', label: "底部中心" },
  { value: 'bottom-right', label: "右下" },
];

/** The six text slots a header/footer run can fill, in draw order. */
const HEADER_SLOTS = ['headerLeft', 'headerCenter', 'headerRight'] as const;
const FOOTER_SLOTS = ['footerLeft', 'footerCenter', 'footerRight'] as const;

/** Parse the fallback textual region format used when the surface is absent. */
function parseRegions(
  raw: unknown,
  doc: PDFDocument,
  notes: string[],
): { page: number; x: number; y: number; width: number; height: number }[] {
  const text = typeof raw === 'string' ? raw : '';
  const out: { page: number; x: number; y: number; width: number; height: number }[] = [];
  let unparseable = 0;
  let offDocument = 0;
  const accept = (region: { page: number; x: number; y: number; width: number; height: number }): void => {
    const frame = frameOf(doc.getPage(region.page));
    const x = Math.min(Math.max(region.x, frame.box.x), frame.box.x + Math.max(0, frame.box.width - 1));
    const y = Math.min(Math.max(region.y, frame.box.y), frame.box.y + Math.max(0, frame.box.height - 1));
    const width = Math.min(region.width, frame.box.x + frame.box.width - x);
    const height = Math.min(region.height, frame.box.y + frame.box.height - y);
    if (x !== region.x || y !== region.y || width !== region.width || height !== region.height) {
      note(notes, `A box on page ${region.page + 1} hung past the edge of the page, so it was trimmed to fit.`);
    }
    if (width > 0 && height > 0) out.push({ page: region.page, x, y, width, height });
    else note(notes, `A box on page ${region.page + 1} has no size once it is inside the page, so it was ignored.`);
  };
  if (Array.isArray(raw)) {
    for (const region of raw as { page: number; x: number; y: number; width: number; height: number }[]) {
      if (!Number.isInteger(region.page) || region.page < 0 || region.page >= doc.getPageCount()) {
        offDocument += 1;
        continue;
      }
      accept(region);
    }
  } else {
    for (const chunk of text.split(/[;\n]+/)) {
      if (!chunk.trim()) continue;
      const match = /^\s*(\d+)\s*:\s*([\d.-]+)\s*,\s*([\d.-]+)\s*,\s*([\d.-]+)\s*,\s*([\d.-]+)\s*$/.exec(chunk);
      if (!match) {
        unparseable += 1;
        continue;
      }
      const page = Number(match[1]) - 1;
      if (page < 0 || page >= doc.getPageCount()) {
        offDocument += 1;
        continue;
      }
      accept({ page, x: Number(match[2]), y: Number(match[3]), width: Number(match[4]), height: Number(match[5]) });
    }
  }
  if (unparseable > 0) {
    note(notes, `${countLabel(unparseable, 'entry', 'entries')} could not be read — use page:x,y,w,h, separated by semicolons.`);
  }
  if (offDocument > 0) {
    note(notes, `${countLabel(offDocument, 'box', 'boxes')} named a page outside this ${doc.getPageCount()}-page document and was ignored.`);
  }
  return out;
}

/** How many marks one page may receive from a tiled pattern (E7). */
const MAX_TILES = 400;

export const editTools: PdfToolDefinition[] = [
  {
    id: 'edit-pdf',
    name: "PDF编辑器",
    actionLabel: "保存PDF",
    description: "注释、突出显示、编辑和评论，或重写页面上已有的文字",
    icon: '✏️',
    category: 'edit',
    // `edit-pdf-text` is folded into this id, and the palette matches on keywords:
    // someone who remembers the old page types its name, and must get this tool.
    keywords: ['annotate', 'highlight', 'comment', 'draw', 'markup', 'pen', 'shapes', 'edit text', 'rewrite text', 'edit-pdf-text'],
    surface: 'custom',
    outputSuffix: '_edited.pdf',
    promise: 'Mark up the page, or retype the words already in it — one editor, one export, and it stays a standard PDF.',
    notes: [
      'Annotations are written as standard PDF annotations, so other readers show and edit them.',
      'Marks follow the page as you see it: on a rotated page a box you drew stays where you put it.',
      'The Edit text mode deletes the original glyph runs and redraws the block, so the old words are not left hiding underneath.',
      'Changing mode keeps the open document, every mark, every unfinished rewrite and the page you were on; each mode has its own undo, and it survives the trip.',
    ],
  },

  {
    /**
     * A folded route, not a second tool: `TOOL_ALIASES` sends this id to
     * `edit-pdf`, so it has no card, no palette row and no place in the count.
     * The definition stays because the bookmarks name it, because the text
     * editor's tests drive it by id, and because the pane lookup still answers it.
     */
    id: 'edit-pdf-text',
    name: "编辑PDF文本",
    actionLabel: "保存文本",
    description: "单击一个段落并使用重排、字体和样式重写它",
    icon: '🖊️',
    category: 'edit',
    keywords: ['rewrite text', 'change wording', 'content editor', 'typo', 'in place'],
    surface: 'custom',
    outputSuffix: '_edited.pdf',
    promise: 'Rewrite a paragraph where it sits: the old glyphs are removed and the block is redrawn, not covered up.',
    notes: [
      'Editing deletes the original glyph runs and redraws the block, so the old text is not left hiding underneath.',
      'Blocks that PyMuPDF-grade surgery is needed for are reported instead of silently doubled.',
    ],
  },

  {
    id: 'page-numbers',
    name: "页码",
    description: "具有位置、格式、范围和样式控制的页码",
    icon: '🔢',
    category: 'edit',
    keywords: ['pagination', 'footer numbers', 'folio'],
    outputSuffix: '_numbered.pdf',
    actionLabel: "添加号码",
    promise: 'A folio drawn into the page itself, in the position and style you choose, on the pages you select.',
    fields: [
      { key: 'position', label: "位置", type: 'select', default: 'bottom-center', options: ANCHOR_OPTIONS, group: "放置", help: "在每页上绘制对开页的位置，从您所看到的页面开始测量。" },
      { key: 'margin', label: "保证金", type: 'number', default: 24, min: 0, max: 200, step: 1, unit: "pt", half: true, group: "放置", help: "从每页的可见边缘测量，包括其旋转。" },
      pagesField({ group: "放置" }),
      { key: 'skip', label: "跳过前N页", type: 'number', default: 0, min: 0, max: 5000, step: 1, integer: true, half: true, group: "放置", help: "从选择开始算起，因此封面页保持空白。限制为您选择的页数。" },
      { key: 'step', label: "计算每个", type: 'number', default: 1, min: 1, max: 10, step: 1, integer: true, half: true, group: "放置", help: "从第一页开始每隔两页有 2 个编号，对于折叠的小册子很有用。" },
      { key: 'startAt', label: "第一个数字", type: 'number', default: 1, min: 0, max: 100000, step: 1, integer: true, half: true, group: "格式", help: "第一页上的对开页。从 3 开始，前两张是封面。" },
      { key: 'style', label: "号码样式", type: 'select', default: 'decimal', options: [
        { value: 'decimal', label: '1, 2, 3' },
        { value: 'roman-upper', label: "一、二、三" },
        { value: 'roman-lower', label: "一、二、三" },
        { value: 'letters', label: 'A, B, C' },
        { value: 'padded', label: '01, 02, 03' },
      ], group: "格式", help: "罗马和字母样式从您设置的第一个数字重新开始； padded 保持您手写时的宽度。" },
      { key: 'prefix', label: "前缀", type: 'text', default: 'Page ', half: true, group: "格式", help: "写在数字之前，因此“Page”将3变成“Page 3”。" },
      { key: 'suffix', label: "后缀", type: 'text', default: ' of {total}', half: true, group: "格式", help: 'Written after the number. {total} and {page} are replaced.' },
      ...textStyleFields({
        surface: 'page-numbers',
        group: "风格",
        size: {
          default: 11,
          min: 5,
          max: 72,
          step: 0.5,
          help: "抽奖号码的大小，以磅为单位：12pt是普通正文文本。",
        },
        color: { default: '#1b1b18', help: "应用于号码及其周围的任何前缀或后缀。" },
      }),
    ],
    notes: [
      'Numbers are drawn into the page, not stored as metadata, so they print and appear in every viewer.',
      'Each page is measured on its own: a mixed-size or rotated document keeps its folios inside the visible edge.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const all = resolvePages(stringValue(context.values, 'pages', 'all'), input.pageCount);
      const startAt = readNumber(context, notes, { key: 'startAt', label: "第一个数字", fallback: 1, min: 0, max: 100000, integer: true });
      const step = readNumber(context, notes, { key: 'step', label: "计算每个", fallback: 1, min: 1, max: 10, integer: true });
      const skip = bounded(notes, 'Skip first N pages', numberValue(context.values, 'skip', 0), { min: 0, max: all.length, integer: true });
      const style = stringValue(context.values, 'style', 'decimal');
      const size = readNumber(context, notes, { key: 'fontSize', label: "字体大小", fallback: 11, min: 5, max: 72, unit: "pt" });
      // The family, weight, slant and colour come from the shared model; the size is
      // read through the tool's own clamp so a `fontSize: 0` is still reported
      // before it reaches a writer.
      const textStyle = mergeFaceStyle(readTextStyle(context.values, 'page-numbers'), { size });
      rememberTextStyle('page-numbers', textStyle);
      const margin = readNumber(context, notes, { key: 'margin', label: "保证金", fallback: 24, min: 0, max: 200, unit: "pt" });
      const anchor = stringValue(context.values, 'position', 'bottom-center');
      const pages = input.doc.getPages();
      // Numbering restarts at `startAt` on the first page that is actually
      // numbered, and the step counts from there — previously the step was
      // measured from page 1, so "skip 2, every 2nd" began mid-count and the
      // `First number` the user typed never appeared.
      const targets: { page: number; number: number }[] = [];
      for (let i = skip; i < all.length; i += step) {
        targets.push({ page: all[i], number: startAt + targets.length });
      }
      if (targets.length === 0) {
        return admit(
          reportResult(
            [{
              title: "没有编号",
              text: skip > 0
                ? `The selection holds ${countLabel(all.length, 'page')} and "skip first ${skip}" covers all of them, so no page was left to stamp.`
                : `The selection holds ${countLabel(all.length, 'page')}, which is not enough to number.`,
            }],
            { message: "未对页面进行编号 — 文件未更改。" },
          ),
          notes,
        );
      }
      const total = targets[targets.length - 1].number;
      for (let i = 0; i < targets.length; i++) {
        const { page, number } = targets[i];
        const text = stringValue(context.values, 'prefix', 'Page ')
          + formatNumber(number, style)
          + stringValue(context.values, 'suffix', ' of {total}')
            .replace('{total}', formatNumber(total, style))
            .replace('{page}', formatNumber(number, style));
        await stamp(input.doc, pages[page], text, {
          anchor: anchor as Anchor,
          style: textStyle,
          margin,
          notes,
        });
        context.progress((i + 1) / targets.length, `Numbered page ${page + 1}`);
      }
      return pdfOutput(
        input.doc,
        notes,
        `Numbered ${countLabel(targets.length, 'page')}, ${formatNumber(targets[0].number, style)} to ${formatNumber(total, style)}.`,
      );
    },
  },

  {
    id: 'watermark',
    name: "添加水印",
    description: "通过不透明度、角度和平铺在页面上标记文本或图像",
    icon: '💧',
    category: 'edit',
    keywords: ['draft', 'confidential', 'logo', 'stamp overlay'],
    outputSuffix: '_watermarked.pdf',
    actionLabel: "添加水印",
    promise: 'A text or image mark drawn into the page, over or behind the existing content, on the pages you select.',
    fields: [
      { key: 'type', label: "水印", group: "马克", type: 'segmented', default: 'text', options: [
        { value: 'text', label: "文本" }, { value: 'image', label: "图像" },
      ],
        help: "将文本标记绘制为文本；图像标记被嵌入并缩放。两者都被绘制到页面本身中。",
      },
      { key: 'text', label: "文本", type: 'text', default: 'DRAFT', when: (v) => v.type === 'text', group: "马克", help: "绘制到页面中，不存储为评论，因此它被打印并且不能被读者隐藏。" },
      { key: 'image', label: "水印图像", type: 'file', accept: 'image/*', when: (v) => v.type === 'image', group: "马克", help: "PNG、JPEG 或 WebP — 在此选项卡中转换，从未上传。" },
      ...textStyleFields({
        surface: 'watermark',
        group: "马克",
        when: (values) => values.type === 'text',
        boldDefault: true,
        size: {
          default: 64,
          min: 6,
          max: 400,
          step: 1,
          help: "在缩放至其自身尺寸的页面上的点——A4尺寸的水印在Letter扫描件上的着陆方式不同。",
        },
        color: { default: '#888888', help: "仅用于文字标记；图像保留其自己的颜色。" },
      }),
      { key: 'scale', label: "图像比例", type: 'slider', default: 0.35, min: 0.02, max: 2, step: 0.01, when: (v) => v.type === 'image', group: "马克", help: "每页自身宽度的分数——每页测量，因此混合尺寸保持成比例。" },
      { key: 'opacity', label: "不透明度", type: 'slider', default: 0.25, min: 0.02, max: 1, step: 0.01, group: "看", help: "足够低以使得下面的文字保持可读，足够高以使得标记在打印机中保存下来。" },
      { key: 'rotation', label: "角度", type: 'slider', default: 45, min: -180, max: 180, step: 1, unit: '°', group: "看", help: "在显示页面时测量，因此在旋转的页面上角度相同。" },
      { key: 'layer', label: "放置", type: 'segmented', default: 'over', options: [
        { value: 'over', label: "内容过多" }, { value: 'under', label: "内容背后" },
      ], group: "看", help: "后面将文本保持在标记之上； over 隐藏它所覆盖的所有内容。" },
      { key: 'position', label: "位置", type: 'select', default: 'center', options: ANCHOR_OPTIONS, when: (v) => v.tile !== true, group: "重复", help: "单个标记在未平铺时所处的位置。" },
      { key: 'tile', label: "作为模式重复", type: 'toggle', default: false, group: "重复", help: "在整个页面上重复标记而不是放置标记，这可以阻止裁剪删除证据。" },
      { key: 'tileGap', label: "图案间距", type: 'slider', default: 1.5, min: 0.2, max: 5, step: 0.1, when: (v) => v.tile === true, group: "重复", help: "作为标记自身尺寸的倍数，因此较大的水印将其自身间隔得更远。" },
      pagesField({ group: "重复" }),
    ],
    notes: [
      'Behind content puts the mark before the page\u2019s own drawing operators, so it sits underneath and the text stays readable on top.',
      'A mark wider than the page is centred and reported rather than clipped silently.',
    ],
    validate: (values) => {
      if (values.type === 'image') {
        const file = values['image'];
        const hasFile = Array.isArray(file) ? file.length > 0 : Boolean(file);
        return hasFile ? null : 'Choose the image to use as a watermark.';
      }
      return stringValue(values, 'text').trim() === ''
        ? 'Enter the watermark text, or switch to an image watermark.'
        : null;
    },
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const type = stringValue(context.values, 'type', 'text');
      const pages = resolvePages(stringValue(context.values, 'pages', 'all'), input.pageCount);
      const opacity = readNumber(context, notes, { key: 'opacity', label: "不透明度", fallback: 0.25, min: 0.02, max: 1 });
      const rotation = readNumber(context, notes, { key: 'rotation', label: "角度", fallback: 45, min: -180, max: 180, unit: '°' });
      const tile = booleanValue(context.values, 'tile');
      const gap = readNumber(context, notes, { key: 'tileGap', label: "图案间距", fallback: 1.5, min: 0.2, max: 5 });
      const anchor = stringValue(context.values, 'position', 'center') as Anchor;
      const behind = stringValue(context.values, 'layer', 'over') === 'under';
      const imageBytes = firstFileBytes(context.values, 'image');

      if (type === 'image' && !imageBytes) {
        throw new Error("选择用作水印的图像。");
      }
      const embedded = type === 'image'
        ? await input.doc.embedPng(await toPng(input.doc, imageBytes!))
        : null;
      const text = stringValue(context.values, 'text', 'DRAFT');
      const size = readNumber(context, notes, { key: 'fontSize', label: "字体大小", fallback: 64, min: 6, max: 400, unit: "pt" });
      // Family, weight, slant and colour come from the shared model; the size is read
      // through the tool's own clamp so a `fontSize: 0` is still reported before it
      // reaches a writer.
      const style = mergeFaceStyle(readTextStyle(context.values, 'watermark'), { size });
      rememberTextStyle('watermark', style);
      const scale = readNumber(context, notes, { key: 'scale', label: "图像比例", fallback: 0.35, min: 0.02, max: 2 });
      // Measured once: the face is cached, and a 500-page document must not
      // re-measure the same string five hundred times (E7).
      const textWidth = type === 'image' || !tile
        ? (await measureText(input.doc, {
            text,
            x: 0,
            y: 0,
            size,
            bold: style.bold,
            italic: style.italic,
            fontFamily: style.fontFamily || undefined,
          })).width
        : 0;

      for (let i = 0; i < pages.length; i++) {
        const page = input.doc.getPage(pages[i]);
        const frame = frameOf(page);
        throwIfAborted(context.signal);
        const paint = async (): Promise<void> => {
          if (type === 'image' && embedded) {
            const width = frame.width * scale;
            const height = (embedded.height / Math.max(1, embedded.width)) * width;
            const spots = tile
              ? tilePoints(frame, width * gap, height * gap, notes)
              : [placeRun(frame, width, height, rotation, anchor, 0)];
            for (const spot of spots) {
              const origin = toUserSpace(frame, spot.x, spot.y);
              page.drawImage(embedded, {
                x: origin.x,
                y: origin.y,
                width,
                height,
                opacity,
                rotate: degrees(rotation + frame.rotation),
              });
            }
          } else if (tile) {
            for (const spot of tilePoints(frame, textWidth * gap, size * gap * 2, notes)) {
              await stampText(page, text, spot, { style, opacity, rotation });
            }
          } else {
            await stamp(input.doc, page, text, {
              anchor,
              style,
              opacity,
              rotation,
              margin: 0,
              notes,
            });
          }
        };
        if (behind) await drawBehind(page, paint);
        else await paint();
        context.progress((i + 1) / pages.length, `Watermarked page ${pages[i] + 1}`);
      }
      return pdfOutput(
        input.doc,
        notes,
        `Watermarked ${countLabel(pages.length, 'page')}${type === 'image' ? ' with your image' : ''}${behind ? ', behind the page content' : ''}.`,
      );
    },
  },

  {
    id: 'header-footer',
    name: "页眉和页脚",
    description: "使用样式面板将文本添加到每个页面的顶部和底部",
    icon: '📝',
    category: 'edit',
    keywords: ['running head', 'footer', 'document title bar'],
    outputSuffix: '_header_footer.pdf',
    actionLabel: "添加页眉和页脚",
    promise: 'Left, centre and right text at the top and bottom of each selected page, with page numbers and document fields.',
    fields: [
      { key: 'headerLeft', label: "标题向左", type: 'text', group: "标题", help: 'Tokens such as {page} {total} {title} {author} {date} {file} are filled in per page.' },
      { key: 'headerCenter', label: "头部中心", type: 'text', default: '{title}', group: "标题", help: "左、中、右共享同一条线，因此最宽的一对决定它们是否碰撞。" },
      { key: 'headerRight', label: "标题右", type: 'text', default: '{date}', group: "标题", help: "左、中、右共享一行：它们必须一起适合页面宽度。" },
      { key: 'footerLeft', label: "页脚左", type: 'text', default: '{author}', group: "页脚", help: "左下槽。任何必须出现在每一页上的内容都属于此处或中心。" },
      { key: 'footerCenter', label: "页脚中心", type: 'text', group: "页脚", help: "底部中心槽，这是对开页通常所在的位置。" },
      { key: 'footerRight', label: "页脚右", type: 'text', default: 'Page {page} of {total}', group: "页脚", help: "右下槽，按页测量，以便混合尺寸文档将其保持在边缘内。" },
      ...textStyleFields({
        surface: 'header-footer',
        group: "类型",
        size: {
          default: 9,
          min: 5,
          max: 36,
          step: 0.5,
          help: "以点为单位。页眉和页脚文本通常小于其标记的正文。",
        },
        color: { default: '#55554e', help: "一起应用于文本和规则。" },
      }),
      { key: 'margin', label: "保证金", type: 'number', default: 28, min: 4, max: 120, step: 1, unit: "pt", half: true, group: "风格", help: "文本及其规则位于每页内部多远。" },
      {
        key: 'rule',
        label: "绘制发际线规则",
        type: 'toggle',
        default: true,
        group: "风格",
        help: "页眉下方和页脚上方的细线，绘制到相同的边距。",
      },
      pagesField({ group: "风格" }),
    ],
    notes: [
      'Tokens: {page} {total} {title} {author} {subject} {date} {file}. They are filled in per page.',
      'Every page is measured on its own, so a mixed-size or rotated document keeps its rules inside the visible area.',
    ],
    validate: (values) =>
      [...HEADER_SLOTS, ...FOOTER_SLOTS].every((key) => stringValue(values, key).trim() === '')
        ? 'Type something for the header or the footer — with all six boxes empty there is nothing to add.'
        : null,
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const pages = resolvePages(stringValue(context.values, 'pages', 'all'), input.pageCount);
      const size = readNumber(context, notes, { key: 'fontSize', label: "字体大小", fallback: 9, min: 5, max: 36, unit: "pt" });
      const style = mergeFaceStyle(readTextStyle(context.values, 'header-footer'), { size });
      rememberTextStyle('header-footer', style);
      const margin = readNumber(context, notes, { key: 'margin', label: "保证金", fallback: 28, min: 4, max: 120, unit: "pt" });
      const color = style.color;
      const rule = booleanValue(context.values, 'rule', true);
      const meta = {
        title: input.doc.getTitle() ?? input.name,
        author: input.doc.getAuthor() ?? '',
        subject: input.doc.getSubject() ?? '',
        date: new Date().toLocaleDateString(),
        total: String(input.pageCount),
        file: input.name,
      };
      const rows = [
        { label: "标题", keys: HEADER_SLOTS, anchors: ['top-left', 'top-center', 'top-right'] as Anchor[], above: true },
        { label: "页脚", keys: FOOTER_SLOTS, anchors: ['bottom-left', 'bottom-center', 'bottom-right'] as Anchor[], above: false },
      ];
      for (let i = 0; i < pages.length; i++) {
        throwIfAborted(context.signal);
        const page = input.doc.getPage(pages[i]);
        const frame = frameOf(page);
        const values = { ...meta, page: String(pages[i] + 1) };
        for (const row of rows) {
          const texts = row.keys.map((key) => expand(stringValue(context.values, key), values).trim());
          const widths = await Promise.all(texts.map((text) => (text
            ? measureText(input.doc, {
                text,
                x: 0,
                y: 0,
                size,
                bold: style.bold,
                italic: style.italic,
                fontFamily: style.fontFamily || undefined,
              }).then((m) => m.width)
            : Promise.resolve(0))));
          const used = widths.reduce((sum, width) => sum + width, 0);
          if (texts.filter(Boolean).length > 1 && used + margin * 2 > frame.width) {
            note(notes, `The ${row.label} text is wider than a ${Math.round(frame.width)} pt page, so its left, centre and right parts overlap.`);
          }
          for (let s = 0; s < row.anchors.length; s++) {
            if (!texts[s]) continue;
            await stamp(input.doc, page, texts[s], { anchor: row.anchors[s], style, margin, notes });
          }
          if (rule) {
            // The rule is drawn where the reader sees it, then turned with the
            // page: on a /Rotate 90 sheet a page-space horizontal line runs off
            // the side of the paper.
            const y = row.above ? frame.height - margin - size - 4 : margin + size + 4;
            const { strokeLine } = await import('../core/content');
            const start = toUserSpace(frame, margin, y);
            const end = toUserSpace(frame, Math.max(margin, frame.width - margin), y);
            strokeLine(page, start, end, { thickness: 0.5, color });
          }
        }
        context.progress((i + 1) / pages.length, `Page ${pages[i] + 1}`);
      }
      return pdfOutput(input.doc, notes, `Added headers and footers to ${countLabel(pages.length, 'page')}.`);
    },
  },

  {
    id: 'bates-numbering',
    name: "贝茨编号",
    description: "在一个或多个文件中添加连续的合法贝茨编号",
    icon: '⚖️',
    category: 'edit',
    keywords: ['legal', 'discovery', 'production', 'sequential numbering'],
    multiFile: true,
    outputSuffix: '_bates.pdf',
    actionLabel: "对文件进行编号",
    promise: 'A sequential, zero-padded production number stamped on every page of every file, continuing across files or restarting in each one.',
    notes: [
      'Bates numbering is permanent: the number is drawn into the page, so a second run writes a second number.',
      'One number is consumed per page across the whole batch, which is what a discovery production expects.',
    ],
    fields: [
      { key: 'format', label: "数字格式", type: 'text', default: '{prefix}-{n}', help: 'Tokens: {n} {page} {total} {prefix} {date} {time}.', group: "数量" },
      { key: 'prefix', label: "前缀", type: 'text', default: 'DOC', half: true, group: "数量", help: 'Substituted into {prefix} in the format above, so the pattern decides whether it appears.' },
      { key: 'digits', label: "数字宽度", type: 'number', default: 6, min: 1, max: 12, step: 1, integer: true, half: true, group: "数量", help: "比你将达到的最高数字短，并且序列默默地增长一列；每张纸垫更长。" },
      { key: 'start', label: "开头为", type: 'number', default: 1, min: 0, max: 1000000, step: 1, integer: true, half: true, group: "数量", help: "第一个文件的第一页的编号从哪里开始——继续现有的制作而不是重新启动它。" },
      { key: 'perFile', label: "对每个文件重新开始编号", type: 'toggle', default: false, group: "数量", help: "Off在整个批次中运行一个序列，这是生产装置所期望的； on 在每个文件内的起始值处重新启动。" },
      { key: 'position', label: "位置", type: 'select', default: 'bottom-right', options: ANCHOR_OPTIONS, group: "标记", help: "在每页上绘制数字的位置。探索制作通常使用右下角。" },
      ...textStyleFields({
        surface: 'bates-numbering',
        group: "标记",
        family: false,
        size: {
          default: 9,
          min: 5,
          max: 36,
          step: 0.5,
          help: "小到足以不覆盖任何东西，大到足以读出复印件。",
        },
        color: { default: '#000000', help: "黑色为惯例；其他任何东西都有可能在复印机上消失。" },
      }),
      { key: 'margin', label: "保证金", type: 'number', default: 18, min: 0, max: 120, step: 1, unit: "pt", half: true, group: "标记", help: "每页测量的距每页的选定角的距离。" },
    ],
    async run(context) {
      const notes: string[] = [];
      const inputs = await openInputs(context);
      const digits = readNumber(context, notes, { key: 'digits', label: "数字宽度", fallback: 6, min: 1, max: 12, integer: true });
      const start = readNumber(context, notes, { key: 'start', label: "开头为", fallback: 1, min: 0, max: 1000000, integer: true });
      const perFile = booleanValue(context.values, 'perFile');
      const format = stringValue(context.values, 'format', '{prefix}-{n}');
      const prefix = stringValue(context.values, 'prefix', 'DOC');
      // The size is read through the tool's own clamp so an out-of-range value is
      // still admitted before it reaches a writer.
      const batesSize = readNumber(context, notes, { key: 'fontSize', label: "字体大小", fallback: 9, min: 5, max: 36, unit: "pt" });
      const batesStyle = mergeFaceStyle(readTextStyle(context.values, 'bates-numbering'), { size: batesSize });
      rememberTextStyle('bates-numbering', batesStyle);
      let counter = start;
      let stamped = 0;
      // The literal last number painted, so the admission cannot disagree with
      // the file: with "restart in every file" the batch total is not the last
      // number anything carries.
      let lastNumber = '';
      const total = inputs.reduce((sum, input) => sum + input.pageCount, 0);
      const seen = new Set<string>();
      for (const input of inputs) {
        // E16: the same document added twice is two productions here, and the
        // output names collide, so say which copy is which.
        if (seen.has(input.name)) {
          note(notes, `Two documents are named "${input.name}"; both were stamped, and both downloads carry the same name.`);
        }
        seen.add(input.name);
        for (let index = 0; index < input.pageCount; index++) {
          throwIfAborted(context.signal);
          const number = String(counter).padStart(digits, '0');
          lastNumber = number;
          const text = expand(format, {
            n: number,
            page: String(index + 1),
            total: String(input.pageCount),
            prefix,
            date: new Date().toISOString().slice(0, 10),
            time: new Date().toTimeString().slice(0, 8),
          });
          await stamp(input.doc, input.doc.getPage(index), text, {
            anchor: stringValue(context.values, 'position', 'bottom-right') as Anchor,
            style: batesStyle,
            margin: readNumber(context, notes, { key: 'margin', label: "保证金", fallback: 18, min: 0, max: 120, unit: "pt" }),
            notes,
          });
          counter += 1;
          stamped += 1;
          context.progress(stamped / (total || 1), `Stamped page ${index + 1} of ${input.name}`);
        }
        if (perFile) counter = start;
      }
      if (stamped > 0 && stamped < 10) {
        note(notes, `The last number written was ${lastNumber}.`);
      }
      const files = [];
      const written: string[] = [];
      for (const input of inputs) {
        const bytes = await savePDF(input.doc);
        const name = `${downloadStem(input.name)}_bates.pdf`;
        files.push({
          blob: new Blob([bytes as BlobPart], { type: 'application/pdf' }),
          name,
        });
        written.push(`${name} ${countLabel(input.doc.getPageCount(), 'page')}`);
      }
      const result: ToolResult = {
        kind: 'files',
        files,
        // One output per input, in the same order, so the first document's page
        // count describes the file the card calls primary. That is what
        // `RunOutcome.pagesOut` means for a multi-file run (pinned by
        // `tests/pdf/pages-out.test.ts`), and it is why the sentence names every
        // file's own count: a row reading `9 → 4` beside "9 numbers" otherwise
        // looks like five pages went missing.
        pages: inputs[0].doc.getPageCount(),
        message: `Applied ${countLabel(stamped, 'Bates number')} across ${countLabel(inputs.length, 'file')}`
          + `${inputs.length > 1 ? ` (${written.join(', ')})` : ''}`
          + `${perFile ? ', restarting at each file' : ''}.`,
      };
      return admit(result, notes);
    },
  },

  {
    id: 'add-page-labels',
    name: "添加页面标签",
    description: "将页码编号为 i、ii … 1、2、3，带前缀和自定义开头",
    icon: '🔠',
    category: 'edit',
    keywords: ['roman numerals', 'front matter', 'label ranges'],
    outputSuffix: '_labelled.pdf',
    actionLabel: "应用标签",
    promise: 'A /PageLabels dictionary, so the page number in the reader\u2019s toolbar reads i, ii, 1, 2 \u2014 nothing is drawn on the page.',
    fields: [
      {
        key: 'ranges',
        label: "标签范围",
        group: "标签",
        type: 'textarea',
        default: '1-3 roman 1\n4-99 decimal 1',
        help: "每行一个：开始-结束样式[开始编号][前缀]。样式：十进制、罗马、罗马、阿尔法、阿尔法、无。一个范围持续到下一行开始。",
      },
    ],
    notes: [
      'PDF page labels are start-based: a line takes effect on its first page and lasts until the next line or the end of the document.',
      'Labels change what the reader shows, not what is printed on the sheet. Use Page Numbers to stamp visible folios.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const parsed = parseLabelRanges(stringValue(context.values, 'ranges'), input.pageCount, notes);
      if (parsed.length === 0) {
        throw new Error(`No usable label range. ${notes[0] ?? 'Enter at least one line such as "1-3 roman 1".'}`);
      }
      addPageLabels(input.doc, parsed);
      const labels = readPageLabels(input.doc);
      const shown = Math.min(labels.length, 12);
      return pdfOutput(
        input.doc,
        notes,
        `Applied ${countLabel(parsed.length, 'label range')}. The first ${countLabel(shown, 'page')} now read: ${labels.slice(0, shown).map((l) => l.label).join(', ')}${labels.length > shown ? ', \u2026' : ''}.`,
      );
    },
  },

  {
    id: 'bookmarks',
    name: "编辑书签",
    description: "查看、替换、导入和导出文档大纲",
    icon: '🔖',
    category: 'edit',
    keywords: ['outline', 'toc structure', 'navigate'],
    outputSuffix: '_bookmarks.pdf',
    surface: 'none',
    actionLabel: "保存书签",
    promise: 'The outline as text you can read, edit and paste back — leaving the box empty just shows you what is there.',
    fields: [
      {
        key: 'outline',
        label: "概要",
        group: "概要",
        type: 'textarea',
        default: '',
        help: "每行一个条目，子项用空格缩进：“第 1 章”或“第 1.1 节”，可选的第 4 页的“标题::4”。",
      },
      { key: 'replace', label: "替换现有轮廓", type: 'toggle', default: true, group: "概要", help: "Off保留存在的大纲并附加在其下方； on 将整个轮廓替换为框中的内容。" },
    ],
    notes: [
      'Page numbers are 1-based positions in the document as it stands now, before the new outline is written.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const raw = stringValue(context.values, 'outline');
      if (!raw.trim()) {
        const existing = readOutline(input.doc);
        if (existing.length === 0) {
          return reportResult([{ title: "书签", text: 'This document has no outline. Add entries above and run again.' }], {
            message: "没有找到书签——没有任何改变。",
          });
        }
        const size = countOutline(existing);
        return reportResult([{ title: "当前概要", text: outlineToText(existing) }], {
          message: `${countLabel(size.total, 'bookmark')} (${countLabel(existing.length, 'at the top level')}${size.targetless > 0 ? `, ${countLabel(size.targetless, 'without a page')}` : ''}). Copy the text, edit it, and run again to replace them.`,
        });
      }
      const nodes = textToOutline(raw, input.pageCount, notes);
      if (countOutline(nodes).total === 0) {
        throw new Error(`No bookmark could be read from that text. ${notes[0] ?? 'Use one entry per line, "Title :: page".'}`.trim());
      }
      const replace = booleanValue(context.values, 'replace', true);
      const current = readOutline(input.doc);
      // Counted the same way in both modes: the whole tree, not just its top
      // level, so "after the 2 existing outline" cannot describe 2 of 9 entries.
      const before = countOutline(current).total;
      writeOutline(input.doc, replace ? nodes : [...current, ...nodes]);
      const written = countOutline(nodes);
      return pdfOutput(
        input.doc,
        notes,
        replace
          ? `Wrote ${countLabel(written.total, 'bookmark')} (${countLabel(nodes.length, 'top-level one', 'top-level ones')})${before > 0 ? `, replacing the ${countLabel(before, 'bookmark')} already in the document` : ''}.`
          : `Added ${countLabel(written.total, 'bookmark')} after the ${countLabel(before, 'existing')} outline.`,
      );
    },
  },

  {
    id: 'table-of-contents',
    name: "目录",
    description: "从文档大纲生成可点击的内容页面",
    icon: '📚',
    category: 'edit',
    keywords: ['toc', 'index page', 'contents'],
    outputSuffix: '_toc.pdf',
    actionLabel: "插入内容",
    promise: 'A real contents page — drawn text with clickable links to the outline it reads.',
    fields: [
      { key: 'title', label: "标题", type: 'text', default: 'Contents', half: true, group: "目录页", help: "绘制为插入页面上列表上方的标题。" },
      { key: 'insertAt', label: "在第页插入", type: 'number', default: 1, min: 1, max: 5000, step: 1, integer: true, half: true, group: "目录页", help: "夹在该文档中，因此超过末端的一页落在后面。" },
      { key: 'leader', label: "领导者", type: 'segmented', default: 'dots', options: [
        { value: 'dots', label: "点" }, { value: 'none', label: "无" },
      ], group: "目录页", help: "当两个条目相距很远时，点将条目与其页码连接起来。" },
      { key: 'fontSize', label: "字体大小", type: 'number', default: 11, min: 7, max: 24, step: 0.5, unit: "pt", half: true, group: "风格", help: "适用于参赛作品；标题画得比这个大一点。" },
      { key: 'showPageNumbers', label: "显示页码", type: 'toggle', default: true, group: "风格", help: "Off列出没有页码的内容，这仅对短文档有用。" },
    ],
    notes: [
      'The list comes from the document outline, so a PDF with no bookmarks has nothing to list.',
      'Entries are numbered against the finished document, including the contents pages just inserted.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const outline = readOutline(input.doc);
      if (outline.length === 0) {
        throw new Error("该PDF没有用于构建目录的书签。首先使用“编辑书签”添加它们。");
      }
      const size = countOutline(outline);
      if (size.targetless > 0) {
        note(notes, `${countLabel(size.targetless, 'entry', 'entries')} has no page target, so it is listed without a number.`);
      }
      const insertAt = bounded(notes, 'Insert at page', numberValue(context.values, 'insertAt', 1), { min: 1, max: input.pageCount, integer: true });
      const fontSize = readNumber(context, notes, { key: 'fontSize', label: "字体大小", fallback: 11, min: 7, max: 24, unit: "pt" });
      const { generateTocPage } = await import('../core/bookmarks');
      const pages = await generateTocPage(input.doc, {
        nodes: outline,
        title: stringValue(context.values, 'title', 'Contents'),
        fontSize,
        leader: stringValue(context.values, 'leader', 'dots') === 'dots' ? 'dots' : 'none',
        rightAlignPageNumbers: booleanValue(context.values, 'showPageNumbers', true),
        startPage: insertAt - 1,
      });
      return pdfOutput(
        input.doc,
        notes,
        `Inserted a ${countLabel(pages.length, 'page')} table of contents at page ${insertAt}, listing ${countLabel(size.total, 'entry', 'entries')} from the outline.`,
      );
    },
  },

  {
    id: 'add-stamps',
    name: "添加印章",
    description: "将图像或标准印记放置在所选页面上",
    icon: '📌',
    category: 'edit',
    keywords: ['approved', 'signed seal', 'logo stamp', 'date stamp'],
    surface: 'surface',
    outputSuffix: '_stamped.pdf',
    actionLabel: "放置邮票",
    promise: 'A standard or image stamp as a real PDF annotation, one per page you click or per page you list.',
    fields: [
      { key: 'stamp', label: "邮票", group: "邮票", type: 'select', default: 'APPROVED', options: [
        { value: 'APPROVED', label: "已批准" }, { value: 'AS IS', label: "原样" },
        { value: 'CONFIDENTIAL', label: "机密" }, { value: 'DRAFT', label: "草案" },
        { value: 'EXPRESS', label: "快递" }, { value: 'NOT APPROVED', label: "未获批准" },
        { value: 'PRELIMINARY RESULTS', label: "初步结果" },
        { value: 'SOLD', label: "已售出" }, { value: 'TOP SECRET', label: "最高机密" },
        { value: 'custom', label: "自定义图像……" },
      ], help: "标准图章是命名的PDF注释，因此其他读者可以识别它并允许人们移动或删除它。" },
      { key: 'image', label: "印章图像", type: 'file', accept: 'image/*', when: (v) => v.stamp === 'custom', group: "邮票", help: "当上面的印记被设置为自定义图像时使用。保留为注释，以便以后仍可以移动。" },
      { key: 'position', label: "位置", type: 'select', default: 'top-right', options: ANCHOR_OPTIONS, group: "马克", help: "显示每个页面的角，因此旋转的页面会在您可以看到它的地方标记。" },
      { key: 'width', label: "宽度", type: 'number', default: 140, min: 20, max: 600, step: 1, unit: "pt", half: true, group: "马克", help: "印章被缩放至该宽度并保持其自身的比例。在旋转的页面上，它是根据显示的页面进行测量的。" },
      { key: 'opacity', label: "不透明度", type: 'slider', default: 1, min: 0.1, max: 1, step: 0.05, half: true, group: "马克", help: "下面1页面显示通过，这就是您想要的签名。" },
      ...textStyleFields({
        surface: 'add-stamps',
        group: "邮票",
        when: (values) => values.stamp !== 'custom',
        boldDefault: true,
        size: {
          default: 22,
          min: 6,
          max: 72,
          step: 1,
          half: true,
          help: "标签被绘制成这个尺寸，并且如果它不走的话则缩小以适合邮票盒——与预览显示的答案相同。",
        },
        color: {
          default: '#dc2626',
          help: "标准邮票的邮票文字颜色。自定义图像保留其自己的颜色。",
        },
      }),
      { key: 'regions', label: "安置", type: 'text', default: '', help: "通过点击页面填写。格式页：x,y,w,h。", group: "放置" },
      pagesField({ default: '1', group: "放置" }),
    ],
    notes: [
      'Standard stamps are written as PDF Stamp annotations, so other readers show, move and delete them.',
      'A stamp placed on a rotated page sits in the corner you see; its label follows the page orientation.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { addAnnotations } = await import('../core/annotations');
      const name = stringValue(context.values, 'stamp', 'APPROVED');
      const custom = name === 'custom' ? firstFileBytes(context.values, 'image') : null;
      if (name === 'custom' && !custom) throw new Error("选择要加印的图像。");
      const pages = resolvePages(stringValue(context.values, 'pages', '1'), input.pageCount);
      const width = readNumber(context, notes, { key: 'width', label: "印章宽度", fallback: 140, min: 20, max: 600, unit: "pt" });
      const embedded = custom ? await input.doc.embedPng(await toPng(input.doc, custom)) : null;
      // Keep the picture's own proportions: the appearance is stretched to the rect.
      const aspect = embedded ? embedded.height / Math.max(1, embedded.width) : 0.42;
      const explicit = parseRegions(context.values['regions'], input.doc, notes);
      const targets = explicit.length > 0
        ? explicit
        : pages.map((page) => ({ page, ...anchorRect(input.doc.getPage(page), stringValue(context.values, 'position', 'top-right') as Anchor, width, aspect, notes) }));
      if (targets.length === 0) {
        throw new Error(`No stamp could be placed. ${notes[0] ?? 'The page selection matched no page of this document.'}`);
      }
      if (targets.some((region) => frameOf(input.doc.getPage(region.page)).rotation !== 0)) {
        note(notes, 'Some stamps landed on rotated pages: they sit in the corner as you see it, but the label follows the page orientation.');
      }
      // The label is type, so it takes the shared style model. A family past the
      // three named ones has its face embedded here — `addAnnotations` is
      // synchronous, so it cannot fetch one itself — and the appearance stream writes
      // exactly that face rather than falling back to Helvetica quietly.
      const labelStyle = mergeFaceStyle(readTextStyle(context.values, 'add-stamps'), {
        size: readNumber(context, notes, { key: 'fontSize', label: "字体大小", fallback: 22, min: 6, max: 72, unit: "pt" }),
      });
      rememberTextStyle('add-stamps', labelStyle);
      const labelFace = embedded ? null : await stampLabelFace(input.doc, labelStyle, name, notes);
      addAnnotations(
        input.doc,
        targets.map((region) => ({
          kind: 'Stamp' as const,
          page: region.page,
          rect: { x: region.x, y: region.y, width: region.width, height: region.height },
          stampName: embedded ? undefined : name,
          // The embedded picture, not the bytes: `embedPng` already dealt with an
          // alpha channel (which a stamp appearance cannot carry inline), and the
          // appearance draws the very image that was measured for the rect.
          stampXObject: embedded
            ? { ref: embedded.ref, width: embedded.width, height: embedded.height }
            : undefined,
          opacity: readNumber(context, notes, { key: 'opacity', label: "不透明度", fallback: 1, min: 0.1, max: 1 }),
          color: labelStyle.color,
          // A labelled stamp is type set into a box, so it carries the model and the
          // face the model answered with.
          textStyle: embedded ? undefined : { style: labelStyle, ...(labelFace ? { font: labelFace } : {}) },
          contents: name,
        })),
      );
      return pdfOutput(
        input.doc,
        notes,
        `Placed ${countLabel(targets.length, 'stamp')} on ${countLabel(new Set(targets.map((region) => region.page)).size, 'page')}.`,
      );
    },
  },

  {
    id: 'background-color',
    name: "背景颜色",
    description: "在每个页面的内容后面绘制纯色",
    icon: '🎨',
    category: 'edit',
    keywords: ['page colour', 'behind content', 'tint', 'reading tint'],
    outputSuffix: '_background.pdf',
    actionLabel: "油漆背景",
    promise: 'A flat colour laid under each selected page, tagged as a background artifact so text extraction ignores it.',
    fields: [
      { key: 'color', label: "颜色", type: 'color', default: '#f7f7f4', group: "油漆", help: "页面内容后面的平面填充。文本保持可选择状态，并且提取会忽略矩形。" },
      pagesField({ group: "页面" }),
    ],
    notes: [
      'Solid colour only. For an image behind the page use Add Watermark with Placement: Behind content.',
      'The rectangle covers each page\u2019s own crop box, so mixed sizes stay covered edge to edge.',
      'A page that declares an empty /CropBox is left unpainted and named: painting its media box would cover an area the file says is not there.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { prependBackground } = await import('../core/content');
      const pages = resolvePages(stringValue(context.values, 'pages', 'all'), input.pageCount);
      const color = stringValue(context.values, 'color', '#f7f7f4');
      let painted = 0;
      for (let i = 0; i < pages.length; i++) {
        throwIfAborted(context.signal);
        const page = input.doc.getPage(pages[i]);
        const box = cropBox(page);
        // A page may declare `/CropBox []` — an empty array is a box that exists
        // and covers nothing, and `cropBox` falls back to the MediaBox for it.
        // Painting there would cover a page whose producer said it has no visible
        // area, so the page is left alone and named.
        if (box.width <= 0 || box.height <= 0 || declaredCropBoxIsEmpty(page)) {
          note(notes, `Page ${pages[i] + 1} has an empty crop box, so it was left unpainted.`);
          continue;
        }
        prependBackground(page, { x: box.x, y: box.y, width: box.width, height: box.height }, color);
        painted += 1;
        context.progress((i + 1) / pages.length, `Page ${pages[i] + 1}`);
      }
      const skipped = pages.length - painted;
      return pdfOutput(
        input.doc,
        notes,
        `Painted a ${color} background behind ${countLabel(painted, 'page')}`
          + `${skipped > 0 ? `, not ${countLabel(skipped, 'page')} of the ${countLabel(pages.length, 'page')} selected` : ''}.`,
      );
    },
  },

  {
    id: 'text-color',
    name: "改变文本颜色",
    description: "对文档中已有的文本重新着色",
    icon: '🖌️',
    category: 'edit',
    keywords: ['recolour', 'black text', 'colour swap'],
    outputSuffix: '_recoloured.pdf',
    actionLabel: "重新着色文本",
    promise: 'The colour operators in front of existing text are rewritten — no page is rasterised, so the text stays selectable.',
    fields: [
      { key: 'to', label: "新颜色", type: 'color', default: '#000000', group: "重新着色", help: "每个匹配的运行都会重新绘制这种颜色，包括页眉、页脚和注释标签中的文本。" },
      { key: 'from', label: "替换哪种颜色", group: "重新着色", type: 'select', default: 'any', options: [
        { value: 'any', label: "任何颜色" },
        { value: '#000000', label: "仅限黑色" },
        { value: '#ff0000', label: "仅限红色" },
        { value: '#0000ff', label: "仅限蓝色" },
      ], help: "与涂装的颜色准确匹配；扫描仪中的近乎黑色不会被视为黑色。" },
      pagesField({ group: "页面" }),
    ],
    notes: [
      'Only text drawn in the page\u2019s own content streams is recoloured. Text inside an image is part of the picture, and text carried inside a Form XObject stays in that XObject.',
      'Pages with no matching text are reported, not quietly skipped.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { recolourText } = await import('../core/content');
      const pages = resolvePages(stringValue(context.values, 'pages', 'all'), input.pageCount);
      const from = stringValue(context.values, 'from', 'any');
      const to = stringValue(context.values, 'to', '#000000');
      let changed = 0;
      const untouched: number[] = [];
      for (let i = 0; i < pages.length; i++) {
        throwIfAborted(context.signal);
        const before = changed;
        changed += recolourText(input.doc.getPage(pages[i]), from, to);
        if (changed === before) untouched.push(pages[i] + 1);
        context.progress((i + 1) / pages.length, `Page ${pages[i] + 1}`);
      }
      if (changed === 0) {
        return admit(
          reportResult(
            [{
              title: "没有任何东西被重新着色",
              text: from === 'any'
                ? `None of the ${countLabel(pages.length, 'page')} you selected draws text with a colour operator — scanned pages, or text painted inside an image, look like this.`
                : `No text painted in ${from} was found on the ${countLabel(pages.length, 'page')} you selected. Try "Any colour", which changes every text run.`,
            }],
            { message: "没有匹配的文本，因此文件未更改。" },
          ),
          notes,
        );
      }
      // E13 in the partial case: a recolour that reached three of ten pages has
      // to say which seven it did not, or the user assumes the whole file changed.
      if (untouched.length > 0 && untouched.length < pages.length) {
        const list = untouched.slice(0, 8).join(', ') + (untouched.length > 8 ? ', …' : '');
        const where = untouched.length === 1 ? `page ${list}` : `pages ${list}`;
        note(notes, `Nothing on ${where} was drawn in ${from === 'any' ? 'a colour operator' : from}, so ${untouched.length === 1 ? 'it was' : 'they were'} left as ${untouched.length === 1 ? 'it is' : 'they are'}.`);
      }
      return pdfOutput(input.doc, notes, `Recoloured ${countLabel(changed, 'text run')} to ${to}.`);
    },
  },

  {
    id: 'invert-colors',
    name: "反转颜色",
    description: "制作文档的暗模式版本",
    icon: '🌗',
    category: 'edit',
    keywords: ['dark mode', 'negative', 'night reading'],
    outputSuffix: '_inverted.pdf',
    actionLabel: "反转",
    promise: 'A dark-mode copy of the pages you choose, each one a photograph of the inverted original.',
    fields: [
      { key: 'dpi', label: "分辨率", type: 'slider', default: 200, min: 96, max: 400, step: 1, unit: "dpi", group: "输出", help: "每一页都是以此分辨率拍摄的，因此文件随着其平方而增长。" },
      pagesField({ group: "页面" }),
    ],
    notes: [
      'The output is images, so text stops being selectable and the file usually grows. Links and annotations are not carried over.',
      'Only the selected pages are in the result: a narrower selection produces a shorter document, not the same document with some pages untouched.',
      'Each page is re-rendered at its own displayed size, including its /Rotate, so mixed and rotated documents keep their shape.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      return rerasterise(context, notes, input, {
        pages: stringValue(context.values, 'pages', 'all'),
        dpi: readNumber(context, notes, { key: 'dpi', label: "分辨率", fallback: 200, min: 96, max: 400, integer: true, unit: "dpi" }),
        filter: { invert: true },
      }, 'Inverted');
    },
  },

  {
    id: 'adjust-colors',
    name: "调整颜色",
    description: "调整亮度、对比度、饱和度和色调",
    icon: '🎛️',
    category: 'edit',
    keywords: ['brightness', 'contrast', 'saturation', 'sharpen', 'scan cleanup'],
    outputSuffix: '_adjusted.pdf',
    actionLabel: "调整颜色",
    promise: 'The pages you select, re-rendered with your colour settings burned into the pixels — including a true black-and-white cutoff.',
    fields: [
      { key: 'brightness', label: "亮度", type: 'slider', default: 1, min: 0.2, max: 2, step: 0.02, group: "颜色", help: "以上1使整个页面图像变亮； 2 吹掉扫描的背景。" },
      { key: 'contrast', label: "对比", type: 'slider', default: 1, min: 0.2, max: 3, step: 0.02, group: "颜色", help: "高于1使灯光变亮而黑暗变暗。过了 2，灰色扫描就会失去中间色调。" },
      { key: 'saturation', label: "饱和度", type: 'slider', default: 1, min: 0, max: 3, step: 0.02, group: "颜色", help: "颜色有多浓。 0 已经是灰度，所以下面的切换是极端情况。" },
      { key: 'hue', label: "色调旋转", type: 'slider', default: 0, min: -180, max: 180, step: 1, unit: '°', group: "颜色", help: "将每种颜色绕轮子旋转该角度。 180 度将蓝色海豹变成橙色。" },
      { key: 'grayscale', label: "灰度", type: 'toggle', default: false, group: "颜色", help: "完全去除颜色并覆盖饱和度滑块。" },
      { key: 'threshold', label: "设为黑白", type: 'slider', default: 0, min: 0, max: 1, step: 0.02, help: "0保持颜色。向上拖动以对扫描进行二值化 - 这是真正的像素截止，而不是对比度增强。", group: "输出" },
      { key: 'dpi', label: "分辨率", type: 'slider', default: 200, min: 96, max: 400, step: 1, unit: "dpi", group: "输出", help: "页面以该分辨率呈现并重新嵌入为图像，因此越高意味着更清晰和更大。" },
      pagesField(),
    ],
    notes: [
      'The output is images: text stops being selectable, and pages you did not select are not carried over.',
      'Each page is rendered at its own displayed size and rotation, so mixed and rotated documents keep their shape.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const threshold = readNumber(context, notes, { key: 'threshold', label: "黑白截止", fallback: 0, min: 0, max: 1 });
      return rerasterise(context, notes, input, {
        pages: stringValue(context.values, 'pages', 'all'),
        dpi: readNumber(context, notes, { key: 'dpi', label: "分辨率", fallback: 200, min: 96, max: 400, integer: true, unit: "dpi" }),
        threshold: threshold > 0 ? Math.round(threshold * 255) : undefined,
        filter: {
          brightness: readNumber(context, notes, { key: 'brightness', label: "亮度", fallback: 1, min: 0.2, max: 2 }),
          contrast: readNumber(context, notes, { key: 'contrast', label: "对比", fallback: 1, min: 0.2, max: 3 }),
          // "Greyscale" wins over saturation; keeping both would
          // fight, and the slider would quietly lose.
          saturation: booleanValue(context.values, 'grayscale') ? 1 : readNumber(context, notes, { key: 'saturation', label: "饱和度", fallback: 1, min: 0, max: 3 }),
          hue: readNumber(context, notes, { key: 'hue', label: "色调旋转", fallback: 0, min: -180, max: 180, unit: '°' }),
          grayscale: booleanValue(context.values, 'grayscale'),
        },
      }, threshold > 0 ? 'Adjusted and binarised' : 'Adjusted');
    },
  },

  {
    id: 'scanner-effect',
    name: "扫描仪效果",
    description: "使 PDF 看起来像干净的灰度扫描件",
    icon: '📄',
    category: 'edit',
    keywords: ['scan look', 'whitening', 'binarise', 'photocopy'],
    outputSuffix: '_scanned.pdf',
    actionLabel: "应用扫描效果",
    promise: 'The pages you choose, whitened and sharpened into a clean greyscale scan — a real pixel pass, not just a colour filter.',
    fields: [
      { key: 'whitening', label: "使背景变白", type: 'toggle', default: true, group: "看", help: "将纸张背景推至白色，这使得灰色复印件看起来干净。" },
      { key: 'sharpen', label: "锐化边缘", type: 'toggle', default: true, group: "看", help: "使字形的边缘变得清晰。过头了，它会在每个字母周围留下光环。" },
      { key: 'grayscale', label: "灰度", type: 'toggle', default: true, group: "看", help: "降低颜色，这就是真实文档扫描的样子并且打印成本更低。" },
      { key: 'contrast', label: "对比", type: 'slider', default: 1.35, min: 1, max: 3, step: 0.05, group: "看", help: "通过将墨水与纸张分离的难度如何。" },
      { key: 'dpi', label: "分辨率", type: 'slider', default: 220, min: 96, max: 400, step: 1, unit: "dpi", group: "输出", help: "300是打印页面在屏幕上清晰读取的点；在它之上，效果会变慢并且文件会变大。" },
      pagesField(),
    ],
    notes: [
      'Whitening and sharpening are applied per pixel, so they are the slowest of the colour tools — a 500-page document is a lot of canvases.',
      'The output is images; selectable text is lost, and only the selected pages are written into it.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      return rerasterise(context, notes, input, {
        pages: stringValue(context.values, 'pages', 'all'),
        dpi: readNumber(context, notes, { key: 'dpi', label: "分辨率", fallback: 220, min: 96, max: 400, integer: true, unit: "dpi" }),
        filter: {
          contrast: readNumber(context, notes, { key: 'contrast', label: "对比", fallback: 1.35, min: 1, max: 3 }),
          grayscale: booleanValue(context.values, 'grayscale', true),
        },
        whitening: booleanValue(context.values, 'whitening', true),
        sharpen: booleanValue(context.values, 'sharpen', true),
      }, 'Applied the scanner effect to');
    },
  },

  {
    id: 'ocr-pdf',
    name: 'PDF 文字识别',
    description: "识别扫描页面中的文本并添加可搜索、可选择的图层",
    icon: '🔡',
    category: 'edit',
    keywords: ['recognise', 'searchable pdf', 'text layer', 'abbyy alternative'],
    outputSuffix: '_ocr.pdf',
    actionLabel: "识别文本",
    promise: 'A hidden text layer over the scan, so pages become selectable and searchable without changing how they look.',
    fields: [
      { key: 'language', label: "语言", group: "认可", type: 'select', default: 'en', options: [
        { value: 'en', label: "英语" }, { value: 'de', label: "德语" },
        { value: 'es', label: "西班牙语" }, { value: 'fr', label: "法语" },
        { value: 'it', label: "意大利语" }, { value: 'pt', label: "葡萄牙语" },
        { value: 'ru', label: "俄语" }, { value: 'zh', label: "中文" },
        { value: 'ja', label: "日语" }, { value: 'ko', label: "韩语" },
      ], help: "随运行记录。此版本附带一个英语-拉丁语阅读器，因此选择不会改变所识别的内容 - 无论您在此处选择什么，另一个脚本中的页面都会返回乱码。" },
      { key: 'mode', label: "输出", group: "输出", type: 'segmented', default: 'searchable', options: [
        { value: 'searchable', label: "不可见文本层（保持扫描）" },
        { value: 'replace', label: "用文本替换页面" },
        { value: 'report', label: "只需显示文本即可" },
      ], help: "不可见文本使扫描看起来与原来一模一样。替换会丢弃图片并为您提供更小、更简洁的页面。报告显示文本而不触及文件。" },
      { key: 'dpi', label: "分辨率", type: 'slider', default: 300, min: 150, max: 600, step: 10, integer: true, unit: "dpi", group: "输出", help: "识别前页面被拍摄的位置。 300以下丢失小字；超过 400 会消耗内存，但几乎没有什么收获。" },
      { key: 'skipSearchable', label: "跳过已有文本的页面", type: 'toggle', default: true, group: "认可", help: "留下的页面已经具有与原样完全相同的文本，这正是混合扫描和导出文档所需要的。" },
      pagesField({ group: "页面" }),
    ],
    notes: [
      'The OCR model is downloaded once and cached; the pages themselves are recognised on this device.',
      'Pages that already carry a text layer are left alone unless you ask for a fresh read, so a mixed document keeps what it has.',
      'Language is a label on the run, not a switch: only the English–Latin dictionary is bundled, so every choice reads the page with the same model.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { ocrDocument, addSearchableTextLayer, OcrEngineUnavailable } = await import('../core/ocr');
      const session = await withRender(input, context).then((result) => result.session);
      const dpi = readNumber(context, notes, { key: 'dpi', label: "分辨率", fallback: 300, min: 150, max: 600, integer: true, unit: "dpi" });
      let results;
      try {
        results = await ocrDocument(session, {
          pages: stringValue(context.values, 'pages', 'all'),
          dpi,
          lang: stringValue(context.values, 'language', 'en'),
          signal: context.signal,
          // The rail has offered this switch since the tool was written; until now
          // nothing read it, so "skip pages that already have text" always applied.
          force: !booleanValue(context.values, 'skipSearchable', true),
          onProgress: (done, total) => context.progress(done / total * 0.8, `Recognised page ${done} of ${total}`),
          onStatus: (status) => context.log(status),
        });
      } catch (error) {
        if (context.signal.aborted) throw error;
        // E20, and the distinction this tool exists to get right: an engine that
        // never arrived is not a document with nothing in it. Both branches name
        // what failed, say that the file was **not read**, and say what would fix
        // it. An engine is a capability that degrades with a warning, never into
        // a silent success, and here there is nothing to degrade to.
        if (error instanceof OcrEngineUnavailable) {
          throw new Error(error.phase === 'load'
            ? `The recogniser could not run in this tab, so nothing in "${input.name}" was read: ${error.detail} The OCR model is downloaded once and cached — check the connection (or let this page reach the CDN), then run this again.`
            : `The recogniser could not run past page ${error.page ?? '?'} of "${input.name}", so the file was not read: ${error.detail} Run it again; a lower "Resolution" hands it a smaller picture of each page.`);
        }
        // Anything else is a document or renderer failure. Wrapping it in "the
        // recogniser could not run" would be the same lie wearing another hat.
        throw new Error(`OCR could not run on "${input.name}": ${error instanceof Error ? error.message : String(error)}`);
      }
      try {
        const mode = stringValue(context.values, 'mode', 'searchable');
        const skipped = results.filter((page) => page.alreadySearchable);
        if (skipped.length > 0) {
          note(notes, `${countLabel(skipped.length, 'page')} already had a text layer and was left as it was.${booleanValue(context.values, 'skipSearchable', true) ? ' Turn off "skip pages that already have text" to read them again.' : ''}`);
        }
        // E10: "no text" is three different findings — never read, blank sheet,
        // sheet with ink that is not letters — and the ink measured off the
        // painted bitmap is what tells them apart. One sentence must not stand
        // in for another.
        const quiet = ocrQuietPages(results);
        for (const line of ocrQuietSummary(quiet)) note(notes, line);
        if (results.length === 0) {
          return admit(
            reportResult([{ title: "没有什么可读的", text: 'The page selection matched no page of this document.' }], { message: "没有读取任何内容：没有选择页面。" }),
            notes,
          );
        }
        if (mode === 'report') {
          const characters = results.reduce((sum, page) => sum + page.text.trim().length, 0);
          const outcome = reportResult(
            results.map((page) => ({ title: `Page ${page.page}`, text: page.text.trim() || ocrQuietPageLine(page) })),
            { message: characters > 0
              ? `Read ${characters.toLocaleString()} characters across ${countLabel(results.length, 'page')}.`
              : `Read nothing: ${ocrQuietSummary(quiet).join(' ') || `not one of the ${countLabel(results.length, 'page')} carries readable text.`}` },
          );
          if (characters === 0) {
            note(notes, 'No page has a text layer. Run this tool with "Invisible text layer" or "Replace the page with text" to make the document searchable.');
          }
          return admit(outcome, notes);
        }
        if (mode === 'searchable') {
          const added = await addSearchableTextLayer(input.doc, results, { invisible: true });
          if (added.pages === 0) {
            // The refusal has to be readable on its own: the report card shows
            // these blocks, not the run's `warnings`, so the line names how many
            // pages the recogniser actually read as well as what it found there.
            const examined = results.length - skipped.length;
            return admit(
              reportResult(
                [
                  {
                    title: "未添加任何层",
                    text: `No text was recognised on the ${countLabel(examined, 'page')} the recogniser read${skipped.length > 0 ? `, and ${countLabel(skipped.length, 'page')} already had its own text layer and was left alone` : ''}, so the document was not changed.`,
                  },
                  ...quiet.blocks,
                ],
                // A page that was skipped was never analysed, so "nothing was
                // recognised" would be a claim about a read that did not happen.
                { message: examined === 0
                  ? 'Nothing was read — every page you picked already has a text layer, so the file is unchanged.'
                  : 'No text was recognised — the file is unchanged.' },
              ),
              notes,
            );
          }
          if (added.skipped > 0) {
            note(notes, `${countLabel(added.skipped, 'page')} had no recognised words to place and was left as it was.`);
          }
          return pdfOutput(
            input.doc,
            notes,
            `Added ${countLabel(added.words, 'recognised word')} to ${countLabel(added.pages, 'page')} as an invisible layer — the scan looks unchanged but the text is now selectable and searchable.`,
          );
        }
        if (quiet.read > 0 && quiet.pages.length === quiet.read) {
          // "Replace the page with text" over sheets that produced no text would
          // ship blank pages under a line about rebuilt documents.
          return admit(
            reportResult(
              [
                { title: "什么也没写", text: `The ${countLabel(quiet.read, 'page')} the recogniser read produced no text, so a rebuilt file would hold sheets of paper beside whatever you wanted kept. Nothing was changed.` },
                ...quiet.blocks,
              ],
              { message: "未写入任何内容 — 文件未更改。" },
            ),
            notes,
          );
        }
        const rebuilt = await textOnlyPdf(input.doc, results);
        if (results.length < input.pageCount) {
          // The rebuilt file is a new document: whatever was not recognised is
          // simply not in it, which the user must hear before they download it.
          note(notes, `The result is a new ${countLabel(results.length, 'page')} document, so the ${countLabel(input.pageCount - results.length, 'other page')} of "${input.name}" ${input.pageCount - results.length === 1 ? 'is' : 'are'} not in the download.`);
        }
        return pdfOutput(
          rebuilt,
          notes,
          `Rebuilt ${countLabel(results.length, 'page')} as selectable text. The original page images were replaced, so any layout, image or handwriting in them is gone.`,
        );
      } finally {
        await session.destroy();
      }
    },
  },

  {
    id: 'form-filler',
    name: "PDF 表单填写器",
    description: "直接在浏览器中填写AcroForm和XFA表单",
    icon: '🗒️',
    category: 'edit',
    keywords: ['fill form', 'acroform', 'xfa', 'tax form'],
    surface: 'custom',
    outputSuffix: '_filled.pdf',
    actionLabel: "填写表格",
    promise: 'Your answers written into the form\u2019s own fields, optionally flattened into page content on save.',
    fields: [{ key: 'flatten', label: "保存时压平", group: "保存", type: 'toggle', default: false ,
    help: "On将答案写入页面并删除字段，因此没有人可以重新输入它们。关闭后，表格可填写。",}],
    notes: [
      'Values are written into the form fields themselves, so the file stays fillable unless you flatten it.',
      'XFA-only forms cannot be rendered in a browser; the tool says so instead of filling an invisible copy.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { fillForm } = await import('../core/forms');
      const fields = listFormFields(input.doc);
      if (fields.length === 0) {
        throw new Error(hasXfa(input.doc)
          ? "该表单的字段仅存在于其 XFA 流中，这里没有任何内容可以呈现。使用创建 PDF 表单添加真实的 AcroForm 字段。"
          : "该PDF没有可填写的表单字段。尝试创建 PDF 表单来添加一些。");
      }
      if (hasXfa(input.doc)) {
        note(notes, 'This document also carries an XFA form. Only the AcroForm values were written, so a viewer that renders XFA may still show the old text.');
      }
      const values = context.values['fieldValues'];
      const record = values && typeof values === 'object' && !Array.isArray(values)
        ? values as Record<string, string | boolean>
        : {};
      const result = fillForm(input.doc, record);
      let baked = '';
      if (booleanValue(context.values, 'flatten')) {
        // `core/forms` owns the field-aware baker: the generic annotation
        // flattener chokes on the appearance streams pdf-lib writes for a widget
        // (`Expected instance of PDFDict, but got instance of PDFContentStream`),
        // which turned "flatten when saving" into a crash on our own forms.
        const { flattenForm } = await import('../core/forms');
        const outcome = await flattenForm(input.doc);
        if (outcome.flattened === 0) {
          note(notes, 'Nothing could be baked into the page, so the fields were left interactive.');
        } else {
          baked = ` ${countLabel(outcome.flattened, 'field')} became page content.`;
        }
        if (outcome.needsRender) {
          note(notes, 'Some answers had no appearance this browser could draw, so they may be missing from the flattened page.');
        }
      }
      if (result.filled === 0) {
        note(notes, `No value reached any of the ${countLabel(fields.length, 'field')} in this form, so it was saved unchanged.`);
      }
      return pdfOutput(
        input.doc,
        notes,
        result.missing.length > 0
          ? `Filled ${countLabel(result.filled, 'field')}; no value given for ${result.missing.slice(0, 4).join(', ')}${result.missing.length > 4 ? ', …' : ''}.${baked}`
          : `Filled ${countLabel(result.filled, 'field')}.${baked}`,
      );
    },
  },

  {
    id: 'form-creator',
    name: "创建PDF表格",
    description: "通过拖动添加可填写文本、复选框、选择和签名字段",
    icon: '🧾',
    category: 'edit',
    keywords: ['make form', 'fillable', 'design form', 'widgets'],
    surface: 'custom',
    outputSuffix: '_form.pdf',
    actionLabel: "创建表格",
    promise: 'The fields you dropped, turned into real AcroForm widgets that any viewer can type into.',
    notes: [
      'A field dropped on a page that no longer exists is moved to the nearest page and the run says how many moved.',
    ],
    fields: [{ key: 'fieldSpecs', label: "字段", group: "设计", type: 'text', default: '', help: "按选项卡顺序保存您放入设计器中的字段。设计师写下它；在这里打字什么也不做。" }],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const specs = context.values['fieldSpecs'];
      if (!Array.isArray(specs) || specs.length === 0) {
        throw new Error("首先将至少一个字段拖到页面上。");
      }
      const { createFormField, listFormFields } = await import('../core/forms');
      // Field names are the form's addresses: two widgets called the same thing
      // is what pdf-lib refuses outright, and the pane lets the name be typed.
      const taken = new Set(listFormFields(input.doc).map((field) => field.name));
      let created = 0;
      let offPage = 0;
      const unwritable: string[] = [];
      for (const spec of specs as (CreateFieldSpec & { page: number })[]) {
        // E15: a field left on a page that no longer exists is clamped to the
        // nearest one, and the run says how many moved. A spec that names no page
        // at all is on page 1 and has not been moved anywhere.
        const asked = Number(spec.page);
        const page = bounded(
          notes,
          'Field page',
          Number.isFinite(asked) ? Math.trunc(asked) : 0,
          { min: 0, max: input.pageCount - 1, integer: true },
        );
        if (Number.isFinite(asked) && Math.trunc(asked) !== page) offPage += 1;
        const named = String(spec.name ?? '').trim();
        // A radio group is one widget per option. With none, `createFormField`
        // makes a field nobody can see or type into, so it is refused out loud
        // instead of being counted as "created".
        if (spec.type === 'radio' && (spec.options?.length ?? 0) === 0) {
          unwritable.push(`the radio group${named ? ` "${named}"` : ''} has no options, so nothing could be placed for it`);
          continue;
        }
        if (!named) {
          unwritable.push(`a ${spec.type} field with no name`);
          continue;
        }
        let name = named;
        if (taken.has(name)) {
          let suffix = 2;
          while (taken.has(`${named}_${suffix}`)) suffix += 1;
          name = `${named}_${suffix}`;
          note(notes, `A field was already named "${named}", so this one is stored as "${name}" and both stay reachable.`);
        }
        taken.add(name);
        const { page: _dropped, ...field } = spec;
        try {
          if (createFormField(input.doc, page, { ...field, name }) >= 0) created += 1;
          else note(notes, `The "${spec.type}" field "${name}" could not be created on page ${page + 1}.`);
        } catch (error) {
          note(notes, `The "${spec.type}" field "${name}" could not be created: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      if (offPage > 0) {
        note(notes, `${countLabel(offPage, 'field')} was dropped on a page outside this document and moved to the nearest page.`);
      }
      if (created === 0) {
        // Nothing was placed, so there is no file to hand back — but the reason is
        // a report the user can act on, not a crash.
        return admit(
          reportResult(
            [{
              title: "无法放置字段",
              text: unwritable.length > 0
                ? `${countLabel(unwritable.length, 'field')} was refused: ${unwritable.join('; ')}.`
                : `${countLabel(specs.length, 'field')} was asked for and none of them could be placed. Check the page and name each field was given.`,
            }],
            { message: `None of the ${countLabel(specs.length, 'field')} could be placed${unwritable[0] ? `: ${unwritable[0]}` : ''}.`, }
          ),
          notes,
        );
      }
      if (unwritable.length > 0) {
        note(notes, `${countLabel(unwritable.length, 'field')} was not added: ${unwritable.join('; ')}.`);
      }
      return pdfOutput(
        input.doc,
        notes,
        `Added ${countLabel(created, 'fillable field')} of ${countLabel(specs.length, 'field')} requested. Viewers can now type into this document.`,
      );
    },
  },

  {
    id: 'pdf-layers',
    name: "PDF OCG层",
    description: "列出、切换、添加或删除可选内容组",
    icon: '🧬',
    category: 'edit',
    keywords: ['ocg', 'optional content', 'layers panel', 'cad export'],
    surface: 'none',
    outputSuffix: '_layers.pdf',
    actionLabel: "改变层",
    promise: 'The optional-content groups of a CAD or GIS export, switched on or off in the default view.',
    fields: [
      { key: 'hide', label: "隐藏这些层", type: 'multiselect', default: [], options: [], group: "默认视图", help: "在默认视图中关闭。内容保留在文件中，任何读者都可以将其重新打开。" },
      { key: 'show', label: "显示这些层", type: 'multiselect', default: [], options: [], group: "默认视图", help: "在默认视图中打开，覆盖文件的保存内容。" },
      { key: 'add', label: "添加一个名为", type: 'text', placeholder: "修订版B", group: "管理", help: "创建空的可选内容组，准备好在其他地方将内容分配给它。" },
      { key: 'remove', label: "删除名为的层", type: 'textarea', group: "管理", help: "删除组定义。属于它的内容会回落到大多数读者中始终可见。" },
    ],
    validate: (values) => {
      const asked = stringValues(values, 'hide').length
        + stringValues(values, 'show').length
        + (stringValue(values, 'add').trim() ? 1 : 0)
        + (stringValues(values, 'remove').flatMap((entry) => entry.split(/[\n,]+/)).filter((name) => name.trim() !== '').length);
      return asked === 0
        ? 'Choose layers to hide or show, or name one to add or delete — with none of those ticked nothing would change.'
        : null;
    },
    notes: [
      'Only the default viewing configuration is edited; named configurations keep their own state, as in other viewers.',
      'Hiding a layer turns it off in the layers panel; it does not delete the content.',
      'To take hidden ink out of the file instead, use Sanitize PDF with "Remove hidden layer content": that deletes the operators, and cannot be undone in the output.',
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { listLayers, setLayerVisibility, addLayer, deleteLayer } = await import('../core/layers');
      const layers = listLayers(input.doc);
      if (layers.length === 0 && !stringValue(context.values, 'add')) {
        return reportResult([{ title: "层数", text: 'This document has no optional-content groups (OCGs). CAD and GIS exports usually do; add one above to create the structure.' }], {
          message: "未找到任何层 — 没有任何改变。",
        });
      }
      const missing: string[] = [];
      const hidden = stringValues(context.values, 'hide');
      const shown = stringValues(context.values, 'show');
      const both = hidden.filter((name) => shown.some((other) => other.toLowerCase() === name.toLowerCase()));
      if (both.length > 0) {
        // The lists are applied in order, so a name in both is switched off and
        // the user needs to know which instruction the file ended up obeying.
        note(notes, `${both.map((name) => `"${name}"`).join(', ')} was listed in both hide and show, so it is hidden — the show instruction did nothing.`);
      }
      for (const name of hidden) {
        if (!setLayerVisibility(input.doc, name, false)) missing.push(name);
      }
      for (const name of shown) {
        // A name in both lists is hidden and stays hidden: running the show here
        // would leave the file disagreeing with the sentence above.
        if (both.some((other) => other.toLowerCase() === name.toLowerCase())) continue;
        if (!setLayerVisibility(input.doc, name, true)) missing.push(name);
      }
      let added = '';
      const wanted = stringValue(context.values, 'add').trim();
      if (wanted) {
        if (layers.some((layer) => layer.name.toLowerCase() === wanted.toLowerCase())) {
          note(notes, `A layer named "${wanted}" already exists, so it was kept and no duplicate was added.`);
          setLayerVisibility(input.doc, wanted, true);
        } else {
          addLayer(input.doc, wanted);
          added = wanted;
        }
      }
      const deletions = stringValues(context.values, 'remove')
        .flatMap((entry) => entry.split(/[\n,]+/))
        .map((name) => name.trim())
        .filter(Boolean);
      let deleted = 0;
      for (const name of deletions) {
        if (deleteLayer(input.doc, name)) deleted += 1;
        else missing.push(name);
      }
      if (missing.length > 0) {
        note(notes, `No layer is named ${missing.map((name) => `"${name}"`).join(', ')} in this document, so those instructions did nothing.`);
      }
      const remaining = listLayers(input.doc);
      const visible = remaining.filter((layer) => layer.on !== false).map((layer) => layer.name);
      return pdfOutput(
        input.doc,
        notes,
        `${added ? `Added "${added}" and ` : ''}${deleted > 0 ? `deleted ${countLabel(deleted, 'layer')} and ` : ''}the document now has ${countLabel(remaining.length, 'layer')}: ${remaining.map((layer) => layer.name).join(', ') || 'none'}${visible.length > 0 ? `, of which ${visible.map((name) => `"${name}"`).join(', ')} ${visible.length === 1 ? 'shows' : 'show'} by default` : ''}.`,
      );
    },
  },

  {
    id: 'remove-annotations',
    name: "删除注释",
    description: "从整个文档中删除注释、突出显示、墨迹和链接",
    icon: '🧽',
    category: 'edit',
    keywords: ['clean markup', 'drop comments', 'flatten away'],
    outputSuffix: '_clean.pdf',
    actionLabel: "删除注释",
    promise: 'Comments, highlights, ink and links deleted from the pages you select — as a report when there is nothing to delete.',
    notes: [
      'Removal is permanent: the annotation objects are deleted, not hidden.',
      'Annotations inherited from a shared parent node are removed for every page beneath it.',
    ],
    fields: [
      pagesField({ group: "页面" }),
    ],
    async run(context) {
      const notes: string[] = [];
      const [input] = await openInputs(context);
      const { removeAnnotations } = await import('../core/annotations');
      const { listAnnotations } = await import('../core/annotations');
      const pages = resolvePages(stringValue(context.values, 'pages', 'all'), input.pageCount);
      const scope = new Set(pages);
      const before = listAnnotations(input.doc);
      const outside = before.filter((mark) => !scope.has(mark.page)).length;
      const removed = removeAnnotations(input.doc, { pages });
      if (removed === 0) {
        // E13: an unchanged file is not a result. Say what is actually there.
        return admit(
          reportResult(
            [{
              title: "没有可删除的内容",
              text: outside > 0
                ? `The ${countLabel(outside, 'annotation')} this document carries sit${outside === 1 ? 's' : ''} outside the ${countLabel(pages.length, 'page')} you selected. Widen the Pages range and run again.`
                : 'This document has no annotations at all — nothing was removed, and the download would be byte-for-byte the file you started with.',
            }],
            { message: "没有要删除的注释。" },
          ),
          notes,
        );
      }
      if (outside > 0) {
        note(notes, `${countLabel(outside, 'annotation')} on the pages you did not select is still there.`);
      }
      // Two numbers the written file has to back up. A note's `/Popup` is an entry
      // in `/Annots` but not a mark a reader lists as a comment, so it is counted
      // and named apart; and the page count is the pages whose array actually
      // shrank, not the pages this run was asked to look at.
      const after = new Set(listAnnotations(input.doc).map((mark) => mark.ref.toString()));
      const gone = before.filter((mark) => !after.has(mark.ref.toString()));
      const popups = gone.filter((mark) => mark.kind === 'Popup').length;
      const marks = gone.length - popups;
      const changed = new Set(gone.map((mark) => mark.page)).size;
      return pdfOutput(
        input.doc,
        notes,
        `Removed ${countLabel(marks, 'annotation')}`
        + `${popups > 0 ? ` and ${countLabel(popups, 'note pop-up', 'note pop-ups')}` : ''}`
        + ` from ${countLabel(Math.max(changed, 1), 'page')}.`,
      );
    },
  },

  // The `redact` entry that used to close this list is retired. `8bb1c49` folded the
  // id into `redact-pdf` (see `TOOL_ALIASES` in `registry.ts`), `cafea60` made the
  // canonical pane reachable again, and from that moment nothing in the app ran this
  // definition: the route folds before it picks a surface, so `/tool/redact` mounts
  // `redact-pdf`'s canvas and panel, and the `regions` text field that carried this
  // tool's typed `page:x,y,w,h` grammar belonged to a rail that never mounts beside a
  // pane. The id still answers its URL; the second definition of one job does not.
  // `tests/pdf/edge-edit.test.ts` runs the job on `redact-pdf`, and
  // `tests/pdf/field-reach.test.ts` pins that the folded route reaches it.
];

// ── helpers ─────────────────────────────────────────────────────────────────

// ── helpers ────────────────────────────────────────────────────────────────

/** "1 page" / "4 pages" — the phrasing every count in this module reports. */
function countLabel(count: number, noun: string, plural?: string): string {
  const value = Math.trunc(count);
  return value === 1 ? `1 ${noun}` : `${value} ${plural ?? `${noun}s`}`;
}

/** What a raster colour tool asks for; see `rerasterise`. */
interface RasterJob {
  pages: string;
  dpi: number;
  /** CSS filter components, composed by `core/measure`'s `cssFilterString`. */
  filter?: { brightness?: number; contrast?: number; saturation?: number; hue?: number; invert?: boolean; grayscale?: boolean };
  /** Bilevel cutoff in 0..255, or undefined to keep anti-aliased grey. */
  threshold?: number;
  /** Scanner-mode pixel passes; each is a real per-pixel operation. */
  whitening?: boolean;
  sharpen?: boolean;
}

/**
 * Re-render the selected pages as images and rebuild the document.
 *
 * Every output page is sized from *its own* source page after that page's
 * `/Rotate` (E8/E9), one page is in flight at a time so memory stays bounded
 * (E7), cancellation is honoured between pages (E19), and the pixel controls the
 * rails expose — threshold, whitening, sharpen — are actually applied. The
 * previous version packed one PDF point per pixel, then resized the page to the
 * source size, so each output showed the bottom-left corner of its own scan at
 * roughly 7× zoom and the three toggles changed nothing but the label.
 */
async function rerasterise(
  context: ToolRunContext,
  notes: string[],
  input: OpenedInput,
  job: RasterJob,
  verb: string,
): Promise<ToolResult> {
  const selected = resolvePages(job.pages, input.pageCount);
  const { session } = await withRender(input, context);
  try {
    const { cssFilterString, thresholdPixels, whitenPixels, sharpenPixels } = await import('../core/measure');
    const doc = await newPDF();
    const filter = cssFilterString({
      brightness: job.filter?.brightness,
      contrast: job.filter?.contrast,
      saturation: job.filter?.saturation,
      hue: job.filter?.hue,
      invert: job.filter?.invert,
      grayscale: job.filter?.grayscale,
    });
    for (let i = 0; i < selected.length; i++) {
      throwIfAborted(context.signal);
      const index = selected[i];
      const size = displayedSize(input.doc.getPage(index));
      const render = await session.renderPage(index + 1, job.dpi / 72, {
        filter: filter || undefined,
        background: '#ffffff',
      });
      try {
        // `renderPage` settles when the task is *scheduled*; the pixels land on
        // `finished`. Reading the canvas before that shipped a page of paper — the
        // `pdf-to-cbz` / `rasterize-pdf` / `pdf-to-image` class, this copy reaching
        // `invert-colors`, `adjust-colors` and `scanner-effect` through one helper.
        await render.finished;
        if (job.whitening || job.sharpen || job.threshold !== undefined) {
          const data = render.ctx.getImageData(0, 0, render.width, render.height);
          if (job.whitening) whitenPixels(data.data, 0.45);
          if (job.threshold !== undefined) thresholdPixels(data.data, job.threshold);
          if (job.sharpen) sharpenPixels(data.data, render.width, render.height, 0.7);
          render.ctx.putImageData(data, 0, 0);
        }
        const blob = await canvasToBlob(render.canvas, 'jpeg', 0.9, { background: '#ffffff' });
        // `mime` as well as `format`: without it `embedImageBytes` re-decodes the
        // raster through a canvas, which never finishes in a tab without one.
        const image = await embedImageBytes(doc, new Uint8Array(await blob.arrayBuffer()), { mime: 'image/jpeg', format: 'jpeg' });
        const page = doc.addPage([size.width, size.height]);
        page.drawImage(image, { x: 0, y: 0, width: size.width, height: size.height });
      } finally {
        render.cancel();
      }
      context.progress((i + 1) / selected.length, `Re-rendered page ${index + 1}`);
    }
    if (selected.length < input.pageCount) {
      const left = input.pageCount - selected.length;
      note(notes, `These tools rebuild the document from the pages they render, so ${countLabel(left, 'page')} outside your selection ${left === 1 ? 'is' : 'are'} not in the output.`);
    }
    const outcome: ToolResult = {
      kind: 'pdf',
      bytes: await savePDF(doc),
      pages: doc.getPageCount(),
      message: `${verb} ${countLabel(selected.length, 'page')} at ${job.dpi} dpi. Text is now part of the image, so it is no longer selectable or searchable.`,
    };
    return admit(outcome, notes);
  } finally {
    await session.destroy();
  }
}

async function textOnlyPdf(source: PDFDocument, results: { page: number; text: string }[]): Promise<PDFDocument> {
  void source;
  const doc = await newPDF();
  for (const result of results) {
    const lines = await wrapText(doc, result.text, { size: 10, maxWidth: 480 });
    const pageHeight = Math.max(300, lines.length * 14 + 80);
    const page = doc.addPage([595.28, pageHeight]);
    let y = pageHeight - 48;
    for (const line of lines) {
      await drawTextU(page, { text: line.line, x: 48, y, size: 10, color: rgb(0, 0, 0) });
      y -= 14;
    }
  }
  return doc;
}

/**
 * Why a page the recogniser read produced no text. The three kinds are three
 * different claims — a sheet with nothing on it, a sheet whose ink is not
 * letters, and a page this run never looked at — so they must not share one
 * sentence, and none of them is the same as "the engine did not run".
 *
 * The percentages come from `core/ocr`'s measurement of the **painted** bitmap,
 * never from the word list: an empty word list is also what an absent reader
 * produces.
 */
type OcrQuietKind = 'blank' | 'unreadable' | 'unexamined';

interface OcrQuietPage {
  page: number;
  kind: OcrQuietKind;
  /** Non-white coverage of the rendered sheet, in percent; null if unmeasured. */
  percent: number | null;
}

interface OcrQuiet {
  pages: OcrQuietPage[];
  /** Pages the recogniser actually rendered and read, silent or not. */
  read: number;
  /** One block per silent page, for the report the rail shows. */
  blocks: { title: string; text: string }[];
}

function ocrQuietPages(results: OcrPageResult[]): OcrQuiet {
  const pages: OcrQuietPage[] = [];
  let read = 0;
  for (const result of results) {
    // A page left alone is not a silent page; its own note already says so.
    if (result.alreadySearchable) continue;
    read += 1;
    if (result.text.trim() !== '') continue;
    const entry = ocrQuietPageOf(result);
    if (entry) pages.push(entry);
  }
  return {
    pages,
    read,
    blocks: pages.map((entry) => ({ title: `Page ${entry.page}`, text: ocrQuietSentence(entry) })),
  };
}

/** Classify one silent page from the reading the recogniser left behind. */
function ocrQuietPageOf(result: OcrPageResult): OcrQuietPage | null {
  if (result.alreadySearchable) return null;
  if (!result.ink) return { page: result.page, kind: 'unexamined', percent: null };
  return {
    page: result.page,
    kind: result.ink.blank ? 'blank' : 'unreadable',
    percent: Math.round(result.ink.ratio * 10000) / 100,
  };
}

function ocrQuietSentence(entry: OcrQuietPage): string {
  if (entry.kind === 'blank') {
    return `blank — the rendered sheet measures ${entry.percent?.toFixed(2)} % ink, so there was nothing on it to read.`;
  }
  if (entry.kind === 'unreadable') {
    return `no letters found, and it is not a blank sheet: ${entry.percent?.toFixed(2)} % of the rendered page is ink. A picture, handwriting, or a scan too faint to resolve — try a higher Resolution.`;
  }
  return 'not analysed by this run, so nothing is claimed about it.';
}

/** One honest note per kind of silence. */
function ocrQuietSummary(quiet: OcrQuiet): string[] {
  const lines: string[] = [];
  const named = (kind: OcrQuietKind) =>
    quiet.pages
      .filter((entry) => entry.kind === kind)
      .map((entry) => (entry.percent === null ? `page ${entry.page}` : `page ${entry.page} at ${entry.percent.toFixed(2)} %`))
      .join(', ');
  const blank = quiet.pages.filter((entry) => entry.kind === 'blank');
  if (blank.length > 0) {
    lines.push(`${countLabel(blank.length, 'page')} yielded no text at all because there is nothing on ${blank.length === 1 ? 'it' : 'them'}: ${named('blank')} of the rendered sheet is ink.`);
  }
  const faint = quiet.pages.filter((entry) => entry.kind === 'unreadable');
  if (faint.length > 0) {
    lines.push(`${countLabel(faint.length, 'page')} yielded no text at all, though ${faint.length === 1 ? 'it carries' : 'they carry'} ink — ${named('unreadable')} of the rendered ${faint.length === 1 ? 'sheet is' : 'sheets are'} not paper. A picture, handwriting or a faint scan is what that measures; try a higher Resolution, or scan again at 300 dpi or better.`);
  }
  const never = quiet.pages.filter((entry) => entry.kind === 'unexamined');
  if (never.length > 0) {
    lines.push(`${countLabel(never.length, 'page')} ${never.length === 1 ? 'was' : 'were'} never analysed by this run (${named('unexamined')}), so nothing is claimed about ${never.length === 1 ? 'it' : 'them'}.`);
  }
  return lines;
}

/** The parenthetical a report-mode page gets when it holds no text. */
function ocrQuietPageLine(result: OcrPageResult): string {
  const entry = ocrQuietPageOf(result);
  if (entry) return `(${ocrQuietSentence(entry)})`;
  return result.alreadySearchable
    ? '(its own text layer was left as it was)'
    : '(no readable text found)';
}

async function toPng(doc: PDFDocument, bytes: Uint8Array): Promise<Uint8Array> {
  const { sniffImageMime, decodeImage, encodeImageBytes } = await import('../core/images');
  const mime = sniffImageMime(bytes) ?? 'image/png';
  if (mime === 'image/png') return bytes;
  const decoded = await decodeImage(bytes, { mime });
  const encoded = await encodeImageBytes(decoded.canvas, { format: 'png' });
  void doc;
  return encoded.bytes;
}

function firstFileBytes(values: Record<string, unknown>, key: string): Uint8Array | null {
  const value = values[key];
  const entry = Array.isArray(value) ? value[0] : value;
  if (entry && typeof entry === 'object' && 'bytes' in entry) {
    return (entry as { bytes: Uint8Array }).bytes;
  }
  return null;
}

/**
 * The page-space rectangle of a mark anchored in the displayed view (E8/E9).
 *
 * Stamps are annotations, and an annotation `/Rect` lives in unrotated user
 * space, so a `top-right` stamp on a `/Rotate 90` page has to be moved into the
 * page-space corner the reader sees as top right.
 */
function anchorRect(
  page: PDFPage,
  anchor: Anchor,
  width: number,
  aspect: number,
  notes: string[],
): PageBox {
  const frame = frameOf(page);
  const wanted = bounded(notes, 'Stamp width', width, { min: 20, max: 600, unit: "pt" });
  const boxWidth = Math.min(wanted, Math.max(24, frame.width - 24));
  if (boxWidth !== wanted) {
    note(notes, `A ${Math.round(wanted)} pt stamp does not fit a ${Math.round(frame.width)} pt wide page; it was drawn ${Math.round(boxWidth)} pt wide.`);
  }
  const height = boxWidth * aspect;
  const run = placeRun(frame, boxWidth, height, 0, anchor, 18);
  return toUserRect(frame, { x: run.x, y: run.y, width: boxWidth, height });
}

/**
 * A displayed-space grid of tile origins, capped so a tight spacing on a big
 * sheet cannot ask for thousands of draws per page (E7/E15).
 */
function tilePoints(
  frame: PageFrame,
  stepX: number,
  stepY: number,
  notes: string[],
): { x: number; y: number }[] {
  const dx = Math.max(24, stepX);
  const dy = Math.max(24, stepY);
  const planned = Math.ceil(frame.width / dx) * Math.ceil(frame.height / dy);
  if (planned > MAX_TILES) {
    note(notes, `This spacing would repeat the watermark ${planned} times per page; it is limited to ${MAX_TILES} repeats.`);
  }
  const out: { x: number; y: number }[] = [];
  for (let y = 0; y < frame.height && out.length < MAX_TILES; y += dy) {
    for (let x = 0; x < frame.width && out.length < MAX_TILES; x += dx) out.push({ x, y });
  }
  return out;
}

/** Draw one text run at a point in *displayed* coordinates (E9). */
async function stampText(
  page: PDFPage,
  text: string,
  at: { x: number; y: number },
  options: { style: FaceStyle; opacity: number; rotation: number },
): Promise<void> {
  const frame = frameOf(page);
  const origin = toUserSpace(frame, at.x, at.y);
  await drawTextU(page, {
    text,
    x: origin.x,
    y: origin.y,
    size: options.style.size,
    color: faceColor(options.style.color),
    bold: options.style.bold,
    italic: options.style.italic,
    // The family the model names, so a tiled watermark in the bundled face is the
    // same face a single watermark gets — not whichever one WinAnsi happened to allow.
    fontFamily: options.style.fontFamily || undefined,
    opacity: options.opacity,
    rotation: options.rotation + frame.rotation,
  });
}

function expand(template: string, values: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (whole, key: string) =>
    key in values ? String(values[key]) : whole,
  );
}

function formatNumber(value: number, style: string): string {
  if (style === 'roman-upper') return toRoman(value);
  if (style === 'roman-lower') return toRoman(value).toLowerCase();
  if (style === 'letters') return toLetters(value);
  if (style === 'padded') return String(value).padStart(3, '0');
  return String(value);
}

function toRoman(value: number): string {
  const table: [number, string][] = [
    [1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'],
    [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I'],
  ];
  let remaining = Math.max(0, Math.floor(value));
  let out = '';
  for (const [amount, symbol] of table) {
    while (remaining >= amount) {
      out += symbol;
      remaining -= amount;
    }
  }
  return out || '0';
}

function toLetters(value: number): string {
  let remaining = Math.max(1, Math.floor(value));
  let out = '';
  while (remaining > 0) {
    remaining -= 1;
    out = String.fromCharCode(65 + (remaining % 26)) + out;
    remaining = Math.floor(remaining / 26);
  }
  return out;
}

const LABEL_STYLE_NAMES: Record<string, 'D' | 'R' | 'r' | 'A' | 'a' | ''> = {
  decimal: 'D',
  D: 'D',
  roman: 'r',
  r: 'r',
  Roman: 'R',
  R: 'R',
  romancaps: 'R',
  alpha: 'a',
  a: 'a',
  Alpha: 'A',
  A: 'A',
  alphacaps: 'A',
  letters: 'a',
  none: '',
};

interface LabelRange {
  start: number;
  end: number;
  /** The end page the user typed, before the document's length trimmed it. */
  askedEnd: number;
  style: 'D' | 'R' | 'r' | 'A' | 'a' | '';
  prefix?: string;
  firstPageNumber?: number;
}

function parseLabelRanges(
  raw: string,
  total: number,
  notes: string[],
): LabelRange[] {
  const out: LabelRange[] = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const match = /^\s*(\d+)\s*-\s*(\d+)\s+(\w+)(?:\s+(\d+))?(?:\s+(\S+))?\s*$/.exec(line);
    if (!match) {
      note(notes, `"${line.trim()}" was not read — use "start-end style", for example "1-3 roman 1".`);
      continue;
    }
    const from = Number(match[1]);
    const to = Number(match[2]);
    if (to < from) {
      note(notes, `"${line.trim()}" runs backwards: page ${from} comes after page ${to}.`);
      continue;
    }
    if (from > total) {
      note(notes, `"${line.trim()}" starts at page ${from}, but this document has ${countLabel(total, 'page')}.`);
      continue;
    }
    // The spelling the user typed decides upper-case from lower-case: the help
    // lists `roman` and `Roman` as different styles, so folding the case made
    // "Roman" produce i, ii, iii.
    const style = LABEL_STYLE_NAMES[match[3]] ?? LABEL_STYLE_NAMES[match[3].toLowerCase()];
    if (style === undefined) {
      note(notes, `"${match[3]}" is not a label style, so "${line.trim()}" was read as decimal. Use decimal, roman, Roman, alpha, Alpha or none.`);
    }
    const start = from - 1;
    if (out.some((range) => range.start === start)) {
      note(notes, `Two ranges start at page ${from}; the first one wins, so "${line.trim()}" was ignored.`);
      continue;
    }
    out.push({
      start,
      end: Math.min(to, total) - 1,
      // What the user asked for, kept apart from what the document can hold:
      // a range typed `1-3` on a 2-page file has to say so out loud.
      askedEnd: to,
      style: style ?? 'D',
      firstPageNumber: match[4] ? Number(match[4]) : undefined,
      prefix: match[5],
    });
  }
  out.sort((a, b) => a.start - b.start);
  // A label is start-based in PDF, so the end page a user typed is only ever
  // honoured by the next line. Saying so is the difference between a legal
  // document with correct front matter and one with a mystery (E15).
  for (let i = 0; i < out.length; i++) {
    const reached = (i + 1 < out.length ? out[i + 1].start : total) - 1;
    if (reached === out[i].askedEnd - 1) continue;
    const reason = reached + 1 < out[i].askedEnd
      ? 'PDF labels last until the next range starts'
      : `this document has ${countLabel(total, 'page')}`;
    note(notes, `The labels from page ${out[i].start + 1} run to page ${reached + 1}, not page ${out[i].askedEnd}: ${reason}.`);
  }
  return out;
}

function outlineToText(nodes: OutlineNode[], depth = 0): string {
  return nodes
    .map((node) => `${'  '.repeat(depth)}${node.title}${node.page !== null ? ` :: ${node.page + 1}` : ''}\n${node.children ? outlineToText(node.children, depth + 1) : ''}`)
    .join('');
}

/** Bookmark tree size, for an honest "what did I just write" message. */
function countOutline(nodes: OutlineNode[]): { total: number; targetless: number } {
  let total = 0;
  let targetless = 0;
  for (const node of nodes) {
    total += 1;
    if (node.page === null) targetless += 1;
    if (node.children) {
      const inner = countOutline(node.children);
      total += inner.total;
      targetless += inner.targetless;
    }
  }
  return { total, targetless };
}

function textToOutline(raw: string, total: number, notes: string[]): OutlineNode[] {
  const root: OutlineNode[] = [];
  const stack: { depth: number; node: OutlineNode }[] = [];
  let offDocument = 0;
  let blank = 0;
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const depth = /^\s*/.exec(line)?.[0].replace(/\t/g, '  ').length ?? 0;
    const [title, pagePart] = line.split('::');
    if (!title.trim()) {
      blank += 1;
      continue;
    }
    const page = pagePart ? Number(pagePart.trim()) - 1 : NaN;
    if (pagePart && pagePart.trim() !== '' && !Number.isFinite(page)) {
      note(notes, `"${pagePart.trim()}" is not a page number, so "${title.trim()}" was written without a link.`);
    } else if (pagePart && Number.isFinite(page) && (page < 0 || page >= total)) {
      offDocument += 1;
    }
    const node: OutlineNode = {
      title: title.trim(),
      page: Number.isFinite(page) && page >= 0 && page < total ? page : null,
      children: [],
    };
    while (stack.length > 0 && stack[stack.length - 1].depth >= depth) stack.pop();
    const parent = stack[stack.length - 1]?.node;
    if (parent) (parent.children ??= []).push(node);
    else root.push(node);
    stack.push({ depth, node });
  }
  if (offDocument > 0) {
    note(notes, `${countLabel(offDocument, 'entry', 'entries')} named a page outside this ${total}-page document, so it opens nothing when clicked.`);
  }
  if (blank > 0) {
    note(notes, `${countLabel(blank, 'line')} had no title and was skipped.`);
  }
  return root;
}

