/**
 * Tools whose control surface is a bespoke React panel rather than a generated
 * form: they draw on the page, so they own both the sidebar and the main pane.
 *
 * These ids existed before the registry was introduced, and they are the ones a
 * returning visitor or a saved bookmark is most likely to use, so they stay
 * registered here. They are *not* a second implementation: each one has a `run`
 * on the same contract as every other tool, and the pane supplies the state a
 * field list cannot describe — placed marks, the dragged rectangle, the captured
 * frames — through `values`. So the guards (`core/guard`), the field clamping
 * (E15), the structural `warnings` and the per-file progress arrive through the
 * runner exactly as they do for the 100 generated tools, and the pane's only
 * private job is the interaction.
 *
 * A run with no pane state is the one case that must refuse rather than guess:
 * cropping by nothing, signing with nothing and scanning zero captures would all
 * hand back a file that is not what the user saw. Each refusal names the pane.
 *
 * Because the generated rail cannot fully describe them, the honesty also lives
 * in the definition: `promise` says what pressing the button gets you, and
 * `notes` say what the pane will *not* do.
 */
// `cropModel` is the crop pane's pure geometry module (no React), so the run and
// the rail agree on what "too little left to be a page" means.
import { MIN_KEPT_PT } from '@/components/tools/pdf/edit/cropModel';
import {
  ToolInputError,
  clampFields,
  clampNumber,
  openInputs,
  openPrimary,
  pagesField,
  pdfResult,
} from './helpers';
import { mediaBox, resolvePageSet, setMediaAndCrop, toPoints, type LengthUnit } from '../core/pages';
import {
  arrayValue,
  booleanValue,
  numberValue,
  objectValue,
  stringValue,
  type PdfToolDefinition,
  type ToolField,
  type ToolRunContext,
  type ToolValues,
} from './types';

/* ── field lists the run also reads ─────────────────────────────────────────
 *
 * These four tools have panes that can call `run` without the rail in front,
 * and `run` must not accept a value the rail would have refused (E15). So the
 * field list is a named constant the definition and the clamping share, instead
 * of a literal the run would have to describe a second time — and get wrong.
 */

/** Largest margin the rail will accept, counted in the unit the margins are typed in. */
const MAX_MARGIN = 2000;

/**
 * The crop margins as the tool and its panel show them.
 *
 * `unit: 'pt'` used to be printed beside a number the user could declare in
 * millimetres, and the help said “in points” two fields above a selector that
 * says otherwise — so the rail labelled 10 as `10 pt` while the crop took 28.3 pt
 * off the page. The bounds carry no unit for the same reason: `core/guard`’s
 * clamp sentence quotes them with the field's unit attached, and “at most 2000
 * pt” is not what a millimetre rail means.
 *
 * The unit is read, not decoration: `marginPoints` converts whatever the caller
 * declared into the points the page box is written in, and
 * `tests/pdf/crop-units.test.ts` proves one region declared in pt, mm, cm and in
 * lands on the same `/MediaBox`. The crop panel now renders this field and types
 * its margins in it, which is what makes the card's “type exact margins in
 * points, mm, cm or inches” a description rather than a promise.
 */
const CROP_SIDES = ['top', 'right', 'bottom', 'left'] as const;

const CROP_FIELDS: ToolField[] = [
  pagesField({ group: "页面" }),
  ...CROP_SIDES.map((side): ToolField => ({
    key: side,
    label: `${side.charAt(0).toUpperCase()}${side.slice(1)} margin`,
    type: 'number',
    default: 0,
    min: 0,
    max: MAX_MARGIN,
    step: 1,
    half: true,
    group: "边距",
    help: "从可见盒子的边缘切割，以下面选择的单位测量（72pt是一英寸，25.4mm是一英寸）。",
  })),
  {
    key: 'unit',
    label: "边距为",
    type: 'select',
    default: 'pt',
    group: "边距",
    help: "读入上述四个页边距的单元—10表示其中的10个，因此切换单元重新裁剪页面。页面框本身总是以点书写。",
    options: [
      { value: 'pt', label: "积分" },
      { value: 'mm', label: "毫米" },
      { value: 'cm', label: "厘米" },
      { value: 'in', label: "英寸" },
    ],
  },
  {
    key: 'allPages',
    label: "每一页",
    type: 'toggle',
    default: true,
    group: "页面",
    help: "仅裁剪下面列出的页面，这是从一张纸上去除杂散扫描边框的方式。",
  },
];

/** The comparison knobs, clamped by the run as well as by the rail. */
const COMPARE_FIELDS: ToolField[] = [
  {
    key: 'sensitivity',
    label: "灵敏度",
    type: 'slider',
    default: 30,
    min: 5,
    max: 150,
    step: 1,
    group: "标记",
    help: "像素在被标记之前必须改变多远。当抗锯齿使每个页面看起来不同时提高它。",
  },
  {
    key: 'highlightColor',
    label: "高亮颜色",
    type: 'color',
    default: '#ff0000',
    group: "标记",
    help: "在更改的区域上绘制，因此选择仍然可以读取下面的文本的颜色。",
  },
];

/**
 * Bound a pane's values with the rail's own rule, collecting the corrections
 * for the result card (E15).
 */
function clampToFields(
  fields: readonly ToolField[],
  values: ToolValues,
  warnings: string[],
): ToolValues {
  const clamped = clampFields(fields, values);
  for (const change of clamped.changes) warnings.push(change.message);
  return clamped.values;
}

export const legacyTools: PdfToolDefinition[] = [
  {
    id: 'sign',
    name: "签署 PDF",
    description: "绘制、键入或上传签名并将其放置在任何页面上",
    icon: '✍️',
    category: 'security',
    keywords: ['signature', 'initials', 'draw', 'sign document'],
    surface: 'custom',
    outputSuffix: '_signed.pdf',
    actionLabel: "放置签名",
    promise: 'Your mark, placed where you drop it, drawn into the page in this tab.',
    notes: [
      'This places a visual signature: the picture or typed name is drawn onto the page. It is not a cryptographic signature — a later edit leaves no trace. "Digital sign PDF" adds a PKCS#7 signature that does.',
      'Nothing is uploaded; the document never leaves this tab.',
    ],
    async run(context: ToolRunContext) {
      const input = await openPrimary(context);
      const marks = objectValue<PaneSignatureMark[]>(context.values, 'marks') ?? [];
      if (marks.length === 0) throw paneOnlyError("签署 PDF", "页面上放置的签名");
      const { drawSignatureMarks } = await import('@/lib/pdf-engine/commands');
      const outcome = await drawSignatureMarks(input.doc, marks, {
        progress: context.progress,
        signal: context.signal,
      });
      if (outcome.placed === 0) {
        throw new ToolInputError(
          "OUT_OF_RANGE",
          "放置的签名都不能被书写——每个签名都位于该文档没有的页面上，或者里面没有任何内容。",
          { fileName: input.name, hint: "将签名放置在您可以在预览中看到的页面上。" },
        );
      }
      const pages = new Set(marks.map((mark) => mark.page)).size;
      const result = await pdfResult(input.doc, {
        message: `Wrote ${count(outcome.placed, 'signature')} onto ${count(pages, 'page')} of "${input.name}".`,
      });
      return { ...result, warnings: outcome.notes };
    },
  },
  {
    id: 'pdf-crop',
    name: "裁剪 PDF",
    description: "拖动裁剪矩形或以点、毫米、厘米或英寸为单位键入精确边距",
    icon: '✂️',
    category: 'edit',
    keywords: ['trim margins', 'cut edges', 'bounds', 'mediabox'],
    surface: 'custom',
    outputSuffix: '_cropped.pdf',
    actionLabel: "作物",
    promise: 'The page shows only the rectangle you keep, on every page you select.',
    notes: [
      'Cropping sets the page’s visible box. Ink outside it is hidden, not deleted: the file barely shrinks, and text you cropped away can still be extracted. Use redaction to remove content for good.',
      'Margins are applied per page in the page’s own units, so mixed page sizes each keep their own geometry.',
    ],
    fields: CROP_FIELDS,
    async run(context: ToolRunContext) {
      const input = await openPrimary(context);
      const warnings: string[] = [];
      // E15 again: the rail bounds the margins, a pane may not. Clamped through
      // the same `core/guard` call the rail uses so the sentence matches.
      const values = clampToFields(CROP_FIELDS, context.values, warnings);
      const unit = stringValue(values, 'unit', 'pt') as LengthUnit;
      // What the user typed, and what the page box will actually lose: the two
      // are only the same number when the unit is points.
      const asked = CROP_SIDES.map((side) => numberValue(values, side, 0));
      const margins = asked.map((value) => marginPoints(value, unit));
      const [top, right, bottom, left] = margins;
      if (top + right + bottom + left <= 0) throw paneOnlyError("裁剪 PDF", "裁剪矩形");
      const targets = resolveTargets(context, input.pageCount);
      const tooSmall: number[] = [];
      let cropped = 0;
      for (const index of targets) {
        const page = input.doc.getPage(index);
        const box = mediaBox(page);
        const width = box.width - left - right;
        const height = box.height - top - bottom;
        // A page this panel never measured can still be too small for these
        // margins: report it instead of writing a zero-area page (E8, E13).
        if (width < MIN_KEPT_PT || height < MIN_KEPT_PT) {
          tooSmall.push(index + 1);
          continue;
        }
        setMediaAndCrop(page, { x: box.x + left, y: box.y + bottom, width, height });
        cropped += 1;
      }
      if (cropped === 0) {
        throw new ToolInputError(
          "OUT_OF_RANGE",
          `These margins leave nothing to keep on ${count(targets.length, 'page')} of "${input.name}".`,
          { fileName: input.name, hint: "将矩形拖得更小，或者裁剪更少的页面。" },
        );
      }
      if (tooSmall.length > 0) {
        warnings.push(`${count(tooSmall.length, 'page')} (${formatPageList(tooSmall)}) was smaller than the crop leaves room for and kept its own size.`);
      }
      const result = await pdfResult(input.doc, {
        message: `Cropped ${count(cropped, 'page')} to the kept rectangle; ${describeMargins(margins, asked, unit)}`,
      });
      return { ...result, warnings };
    },
  },
  {
    id: 'scan-to-pdf',
    name: "扫描为PDF",
    description: "使用相机捕获页面并从中构建一份干净的 PDF",
    icon: '📸',
    category: 'organize',
    // The pane fills the page from the camera or from photos picked off disk, so
    // a PDF must never be demanded of it — the shared gate would answer
    // "that is not a PDF" to the very files this tool takes (E2).
    inputKind: 'image',
    accept: '.jpg,.jpeg,.png,.webp,.heic,.heif,image/*',
    keywords: ['camera', 'document scanner', 'edge detection', 'perspective'],
    surface: 'custom',
    outputSuffix: '_scan.pdf',
    actionLabel: "生成 PDF",
    promise: 'One PDF from the pages you capture, each page a picture of the paper.',
    notes: [
      'Camera access is requested only when you start a scan; frames never leave the tab.',
      'Captures are photographs: each page is an image with no text layer, so the result cannot be searched or selected until you run OCR on it.',
      'This pane does not find the edges of the paper or correct perspective. It straightens tones (greyscale plus contrast) when enhancement is on; crop the page or re-shoot if the document fills too little of the frame.',
    ],
    fields: [
      {
        key: 'pageSize',
        label: "页面尺寸",
        type: 'select',
        default: 'a4',
        group: "页",
        help: "适合图像可保持纸张本身的比例，并为您提供没有边框需要修剪的页面。",
        options: [
          { value: 'a4', label: 'A4' },
          { value: 'letter', label: "美国信" },
          { value: 'fit', label: "适合图像" },
          { value: 'original', label: "原始尺寸" },
        ],
      },
      {
        key: 'orientation',
        label: "方向",
        type: 'select',
        default: 'portrait',
        group: "页",
        help: "仅当上面的片材是固定尺寸时使用。",
        when: (values) => values['pageSize'] !== 'fit' && values['pageSize'] !== 'original',
        options: [
          { value: 'portrait', label: "肖像" },
          { value: 'landscape', label: "风景" },
        ],
      },
      { key: 'margin', label: "保证金", type: 'slider', default: 10, min: 0, max: 40, step: 1, unit: "pt", group: "页", help: "在捕获的页面周围保留白色边框，因此没有无边框模式的打印机不会剪切文本。" },
      {
        key: 'fit',
        label: "适合",
        type: 'select',
        default: 'contain',
        group: "页",
        help: "将纸张的裁切部分填掉；拉伸会扭曲它。 Fit inside 是一款永远不会丢失扫描内容的产品。",
        options: [
          { value: 'contain', label: "适合页面内部" },
          { value: 'cover', label: "填充页面（裁剪）" },
          { value: 'stretch', label: "拉伸" },
        ],
      },
    ],
    async run(context: ToolRunContext) {
      if (context.inputs.length === 0) throw paneOnlyError("扫描为PDF", "捕获的页面");
      const images = await Promise.all(
        context.inputs.map(async (file) => ({
          name: file.name,
          mime: file.type || 'image/jpeg',
          bytes: await file.bytes(),
        })),
      );
      const { scanImagesToPdf } = await import('@/lib/pdf-engine/commands');
      const packed = await scanImagesToPdf(
        images,
        {
          pageSize: stringValue(context.values, 'pageSize', 'a4'),
          orientation: stringValue(context.values, 'orientation', 'portrait') as 'portrait' | 'landscape',
          margin: numberValue(context.values, 'margin', 10),
          fit: stringValue(context.values, 'fit', 'contain') as 'contain' | 'cover' | 'stretch',
        },
        { progress: context.progress, signal: context.signal },
      );
      if (packed.pages === 0) {
        throw new ToolInputError(
          "不支持",
          `None of the ${count(images.length, 'capture')} could be decoded by this browser.`,
          { hint: `The first said: ${packed.skipped[0]?.reason ?? 'no reason given'}. Re-shoot or convert the photo, then add it again.` },
        );
      }
      const warnings = packed.skipped.map(
        (skip) => `"${skip.name}" was not written to the PDF: ${skip.reason}.`,
      );
      if (packed.pages < images.length) {
        warnings.push(`${count(images.length - packed.pages, 'captured page')} became ${count(packed.pages, 'page')} in the file.`);
      }
      return {
        kind: 'pdf' as const,
        bytes: packed.bytes,
        // The packer counts its own pages as it lays them out; undecodable
        // captures are excluded there, so this is the output's real length.
        pages: packed.pages,
        message: `Built a ${count(packed.pages, 'page')} PDF from ${count(images.length, 'capture')}; each page is a photograph, so it is not searchable until you run OCR.`,
        warnings,
      };
    },
  },
  {
    id: 'compare',
    // The fold (`registry.ts` TOOL_ALIASES) points `compare` at `compare-pdfs`, so
    // only one "Compare PDFs" card is listed — but the page behind that card runs
    // *this* definition: `ToolWorkspace` mounts `CompareTool` as the panel for
    // `compare-pdfs`, and that panel calls `usePdfTool('compare')`. Measured on the
    // deployed route with two files loaded, the enabled buttons are this entry's
    // “Generate comparison PDF”, “◂ Prev” and “Next ▸” — no rail form, so
    // `compare-pdfs`'s own report `run` has no control that reaches it.
    name: "并排比较",
    description: "并排查看两个 PDF 并标记您的灵敏度捕捉到的差异",
    icon: '🔍',
    category: 'security',
    keywords: ['diff', 'changes', 'versions', 'redline'],
    multiFile: true,
    minFiles: 2,
    maxFiles: 2,
    surface: 'custom',
    outputSuffix: '_comparison.pdf',
    actionLabel: "比较",
    promise: 'Both files rendered side by side, with the pixels that differ marked up.',
    notes: [
      'Differences are found by rendering each page and comparing pixels at your sensitivity setting, not by reading text: a reflowed paragraph counts as a change and a swapped-in synonym may not.',
      'Only the pages both files have are compared. If one document is shorter, the extra pages are reported and left out of the result.',
      'Both PDFs are opened in this tab; nothing is uploaded.',
    ],
    fields: COMPARE_FIELDS,
    async run(context: ToolRunContext) {
      const [first, second] = await openInputs(context);
      const warnings: string[] = [];
      // E15, the same rule the rail applies: a pane (or a test) can hand `run`
      // a sensitivity of 9000, which marks every pixel on every page as changed
      // and still returns a file that looks like a verdict.
      const values = clampToFields(COMPARE_FIELDS, context.values, warnings);
      const sensitivity = numberValue(values, 'sensitivity', 30);
      const highlightColor = compareColor(values, warnings);
      const { comparePDFs } = await import('@/lib/pdf-engine/commands');
      const outcome = await comparePDFs(first.bytes, second.bytes, {
        sensitivity,
        highlightColor,
      }, { progress: context.progress, signal: context.signal });
      if (outcome.compared === 0) {
        throw new ToolInputError(
          "不支持",
          "两个文档都没有页面，因此没有什么可比较的。",
        );
      }
      if (outcome.onlyInFirst > 0 || outcome.onlyInSecond > 0) {
        warnings.push(
          `Only the first ${count(outcome.compared, 'page')} were compared: "${first.name}" has ${count(outcome.onlyInFirst, 'extra page')} the other does not, and "${second.name}" has ${count(outcome.onlyInSecond, 'extra page')}.`,
        );
      }
      return {
        kind: 'pdf' as const,
        bytes: outcome.bytes,
        // One output page is written per compared page, so `compared` is the
        // produced document's length — not the length of either input.
        pages: outcome.compared,
        message: `Compared ${count(outcome.compared, 'page')} of "${first.name}" against "${second.name}" and painted the differences onto the copy.`,
        warnings,
      };
    },
  },
];

/* ── helpers ──────────────────────────────────────────────────────────────── */

/** A mark the sign pane placed; `x`/`y` are fractions of the target page. */
interface PaneSignatureMark {
  type: 'text' | 'image';
  text: string;
  image?: Uint8Array | null;
  mime?: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  color?: string;
  fontFamily?: string;
}

/**
 * The four bespoke panes all have the same empty state: the work lives in the
 * pane, and the Run button was pressed before anything was put in it. Saying
 * "nothing to do" without naming where the input comes from is how a user
 * concludes the tool is broken.
 */
function paneOnlyError(tool: string, expected: string): ToolInputError {
  return new ToolInputError(
    "OUT_OF_RANGE",
    `${tool} needs ${expected} from its own editor pane, and there is none yet.`,
    { hint: "先在页面预览上设置，然后再运行。" },
  );
}

/**
 * Which pages to crop.
 *
 * The pane resolves its own page numbers (it knows the rectangle came from the
 * page it drew) and passes them as a 1-based list; a rail-driven run passes a
 * spec string. `core/pages` is the only parser for either.
 */
function resolveTargets(context: ToolRunContext, total: number): number[] {
  const list = arrayValue(context.values, 'pages');
  if (list.length > 0) return resolvePageSet(list, total);
  if (booleanValue(context.values, 'allPages', true)) return resolvePageSet('all', total);
  return resolvePageSet(stringValue(context.values, 'pages', 'all'), total);
}

/**
 * The highlight colour, in the `#rrggbb` spelling the comparison paints with.
 *
 * E15 again, for a value the browser's colour picker can leave empty while the
 * user is still typing it: an unparseable colour used to reach the pixel diff as
 * black, so the result said "painted the differences" in a colour nobody chose.
 * The default is used and the substitution is announced.
 */
function compareColor(values: ToolValues, warnings: string[]): string {
  const hex = stringValue(values, 'highlightColor', '#ff0000').trim();
  if (/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.test(hex)) return hex.startsWith('#') ? hex : `#${hex}`;
  warnings.push(`"${hex}" is not a colour the comparison can paint with, so the default #ff0000 was used.`);
  return '#ff0000';
}

/**
 * The margins in the page’s own points, whatever unit was typed.
 *
 * Exported because the crop panel predicts the file with it: the numbers the page
 * prints as “what will be written” are the numbers `run` goes on to write, rounding
 * included, so a person can check the box against the crop before clicking.
 */
export function marginPoints(value: number, unit: LengthUnit): number {
  return Math.round(toPoints(clampNumber(value, 0, MAX_MARGIN), unit) * 10) / 10;
}

/**
 * What the page boxes lost, in the unit the file is written in.
 *
 * `setMediaAndCrop` stores points, so printing the typed numbers with `mm` after
 * them claimed a 10 mm margin had taken 10 points off the page — the one figure
 * a person checks before trusting a crop. Both spellings appear now: the points
 * that went, and what the user entered to get there.
 */
function describeMargins(margins: number[], asked: number[], unit: LengthUnit): string {
  const points = `${margins[0]}/${margins[1]}/${margins[2]}/${margins[3]} pt (top/right/bottom/left)`;
  const typed = unit === 'pt' ? '' : ` — the ${asked.join('/')} ${unit} you entered, converted`;
  return `${points}${typed} were taken off each kept page.`;
}

function formatPageList(pages: number[]): string {
  if (pages.length <= 6) return pages.join(', ');
  return `${pages.slice(0, 6).join(', ')}, …`;
}

function count(value: number, noun: string, plural?: string): string {
  return value === 1 ? `1 ${noun}` : `${value} ${plural ?? `${noun}s`}`;
}
