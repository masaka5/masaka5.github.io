/**
 * Convert from PDF.
 *
 * Every extraction path is built on pdf.js text runs plus `core/convert` and
 * `core/tables`, so the output is real, selectable data rather than a
 * screenshot. The old `pdf-to-word` and `pdf-to-excel` forced every run to
 * Calibri and treated "items on the same line" as a table; both are replaced.
 */
import { savePDF } from '../core/doc';
import { PageSpecError, resolvePages, type PageSpec } from '../core/pages';
import { pageSizeReport } from '../core/measure';
import {
  countImages,
  documentToJson,
  jsonToLlamaIndex,
  jsonToMarkdown,
  jsonToText,
  detectHeadingHeights,
  type PdfJsonDocument,
  type PdfJsonPage,
} from '../core/convert';
import { detectTables, tablesToCsv, type DetectedTable } from '../core/tables';
import { canvasToBlob, concatTiffs } from '../core/raster';
import type { ExtractedImage, SkippedImage } from '../core/images-out';
import {
  ToolInputError,
  downloadStem,
  filesResult,
  openInputs,
  pagesField,
  qualityField,
  reportResult,
  resolutionField,
  throwIfAborted,
  withRender,
  type OpenedInput,
} from './helpers';
import {
  booleanValue,
  numberValue,
  stringValue,
  type PdfToolDefinition,
  type ToolReportSection,
  type ToolResult,
  type ToolRunContext,
  type ToolValues,
} from './types';

/* ── naming (E17) ─────────────────────────────────────────────────────────── */

/**
 * A safe stem for downloads and archive entries.
 *
 * The rules live in `helpers.downloadStem` so the runner, the archive exporters
 * and every per-tool name in this module sanitise the same way (E17).
 */
const outputStem = downloadStem;

/** `007`, `0007` — wide enough for the page numbers the document really has. */
function pageNumber(value: number, total: number): string {
  return String(value).padStart(Math.max(3, String(Math.max(1, total)).length), '0');
}

/* ── what a page actually gave us (E10, E13) ──────────────────────────────── */

/** NUL and the other invisible control characters a broken glyph map leaves. */
const CONTROL_JUNK = /[\u0000-\u0008\u000B\u000E-\u001F\u007F-\u009F]/g;

/**
 * Strip characters no reader can see.
 *
 * A subset font with a missing `/ToUnicode` map, or a sparse OCR layer, hands
 * back runs full of NULs. Left in, the page *looks* extracted — the file is
 * non-empty and the word count is up — while reading it shows nothing (E10).
 * Tab, newline and form feed survive because they are the layout.
 */
function tidy(text: string): string {
  return text.replace(CONTROL_JUNK, '');
}

/** Characters a reader could actually see — the honest "did this work?" test. */
function readableChars(text: string): number {
  return Array.from(tidy(text).replace(/\s+/g, '')).length;
}

/**
 * The text file, laid out the way the switch says.
 *
 * **On** (keep line layout) is the page’s own line breaks, with a form feed
 * where each page ended — what a text editor, `lpr` or `cat` uses to find the
 * page boundary again. **Off** is reflow: the wrapped lines of one paragraph are
 * rejoined, because a hard break in the middle of a sentence is damage in a file
 * whose whole point is that the reader’s window sets the line length. The two
 * readings genuinely differ, which is what the switch is for (E11).
 *
 * A detected table is never reflowed: its rows are the data.
 */
function textDocument(
  json: PdfJsonDocument,
  options: { layout: boolean; pageMarkers: boolean },
): string {
  return json.pages
    .map((page) => {
      const body = options.layout
        ? jsonToText({ pages: [page] }).trimEnd()
        : reflowedBody(page).trimEnd();
      const marker = options.pageMarkers ? `--- page ${page.page} ---\n` : '';
      return `${marker}${body}${options.layout ? '\n\f' : ''}`;
    })
    .join('\n')
    .concat('\n');
}

/** One paragraph per block, its wrapped lines joined with a single space. */
function reflowedBody(page: PdfJsonPage): string {
  const paragraphs = page.blocks
    .map((block) => {
      // A table’s rows are the data; rejoining their lines would glue two cells
      // into one word, so the grid is passed through as it stands.
      if (block.type === 'table') return (block.text ?? '').trim();
      const lines = block.lines?.length
        ? block.lines.map((line) => line.text)
        : (block.text ?? '').split('\n');
      return lines.join(' ').replace(/\s+/g, ' ').trim();
    })
    .filter((text) => text !== '');
  // A page whose blocks carry no text still has the page text pdf.js assembled
  // (an OCR layer, for instance), so fall back to that rather than emit nothing.
  if (paragraphs.length === 0) return page.text;
  return `${paragraphs.join('\n\n')}\n`;
}

interface ExtractionFacts {
  /** Visible characters per selected page, in page order. */
  pages: { page: number; chars: number; images: number; tables: number }[];
  /** Selected pages that produced at least one visible character. */
  withText: number[];
  /** Selected pages that hold images but no text layer: scans (E10). */
  scanned: number[];
  /** Selected pages with neither text nor images. */
  blank: number[];
  chars: number;
  tables: number;
  images: number;
}

/** What one sweep over the selected pages turned up: grids and the truth. */
interface TableHaul {
  input: OpenedInput;
  tables: DetectedTable[];
  facts: ExtractionFacts;
}

function factsFromPages(
  pages: ExtractionFacts['pages'],
): ExtractionFacts {
  const empty = pages.filter((item) => item.chars === 0);
  return {
    pages,
    withText: pages.filter((item) => item.chars > 0).map((item) => item.page),
    scanned: empty.filter((item) => item.images > 0).map((item) => item.page),
    blank: empty.filter((item) => item.images === 0).map((item) => item.page),
    chars: pages.reduce((sum, item) => sum + item.chars, 0),
    tables: pages.reduce((sum, item) => sum + item.tables, 0),
    images: pages.reduce((sum, item) => sum + item.images, 0),
  };
}

function extractionFacts(json: PdfJsonDocument): ExtractionFacts {
  return factsFromPages(
    json.pages.map((item) => ({
      page: item.page,
      chars: readableChars(item.text || item.blocks.map((block) => block.text ?? '').join(' ')),
      images: item.images,
      tables: item.blocks.filter((block) => block.type === 'table').length,
    })),
  );
}

/** `2, 4-6, 9` — a wall of 480 page numbers tells nobody anything (E7). */
function listPages(pages: readonly number[], limit = 10): string {
  const groups: string[] = [];
  let start: number | null = null;
  let last = 0;
  const flush = () => {
    if (start === null) return;
    groups.push(start === last ? `${start}` : last - start === 1 ? `${start}, ${last}` : `${start}-${last}`);
    start = null;
  };
  for (const page of pages) {
    if (start !== null && page === last + 1) {
      last = page;
      continue;
    }
    flush();
    start = page;
    last = page;
  }
  flush();
  if (groups.length === 0) return 'no page';
  if (groups.length <= limit) return groups.join(', ');
  return `${groups.slice(0, limit).join(', ')} and ${groups.length - limit} more`;
}

const singular = (count: number, word: string): string => `${count} ${word}${count === 1 ? '' : 's'}`;

const ofPages = (facts: ExtractionFacts): string =>
  `Page ${listPages(facts.scanned)} of the ${facts.pages.length} selected`;

/** Zero readable characters on every selected page: a report, never a download. */
function nothingToRead(
  input: OpenedInput,
  facts: ExtractionFacts,
  unit: string,
): ToolResult | null {
  if (facts.pages.length === 0) return noPagesSelected(input);
  if (facts.chars > 0) return null;
  return nothingFound('Nothing to extract', emptyReason(facts, unit), emptyAdvice(facts));
}

/**
 * A "nothing found" outcome that is not a download.
 *
 * An empty file is a lie twice over: the user opens a zero-byte .txt or a ZIP
 * with nothing in it, and the log says "done" (E13). A report names what was
 * searched, why it came up empty and what to press instead.
 */
function nothingFound(title: string, detail: string, suggestions: string[] = []): ToolResult {
  const sections: ToolReportSection[] = [{ title, text: detail }];
  if (suggestions.length > 0) {
    sections.push({
      title: "应该尝试什么",
      rows: suggestions.map((line, index) => ({ label: `Option ${index + 1}`, value: line })),
    });
  }
  return { kind: 'report', sections, message: title, warnings: [detail] };
}

/**
 * The `pages` field as a spec `core/pages` can resolve (E6).
 *
 * The rail sends a string — `all`, `1-3,7` — but the field type also allows a
 * list of numbers, and reading that with `stringValue` fell back to `all`. An
 * empty selection then exported the whole document instead of admitting that
 * nothing was picked.
 */
function pageSpec(values: ToolValues): PageSpec {
  const raw = values.pages;
  if (Array.isArray(raw)) {
    return raw
      .map((item) => (typeof item === 'number' ? item : Number(String(item).trim())))
      .filter((item) => Number.isFinite(item));
  }
  return typeof raw === 'string' && raw.trim() !== '' ? raw : 'all';
}

/**
 * The page selection as 1-based page numbers, or a sentence (E6).
 *
 * `core/pages` throws `PageSpecError`, and its class name was reaching the user
 * as `PageSpecError: "2" refers to page 2 …` — a stack trace where a sentence
 * belongs. The tool layer owns what the rail prints, so the spec failure is
 * translated into the same `ToolInputError` shape every other refusal uses and
 * the valid range is spelled out instead of left to be inferred.
 */
function pageSelection(input: OpenedInput, spec: PageSpec): number[] {
  try {
    return resolvePages(spec, input.pageCount).map((index) => index + 1);
  } catch (error) {
    if (!(error instanceof PageSpecError)) throw error;
    throw new ToolInputError(
      "OUT_OF_RANGE",
      `The page selection is outside "${input.name}" — ${error.message} Valid range: 1-${input.pageCount}.`,
      { fileName: input.name, hint: "使用“全部”，或按1-3,7的方式列出页面。" },
    );
  }
}

/** E18's honest cousin: a selection that matched no page is a report, not a file. */
function noPagesSelected(input: OpenedInput): ToolResult {
  return nothingFound(
    'No page selected',
    `"${input.name}" has ${singular(input.pageCount, 'page')} and the selection matched none of them.`,
    ['Use "all", or list pages the way 1-3,7.'],
  );
}

/** Why nothing readable was found — a scan and a blank page are different news. */
function emptyReason(facts: ExtractionFacts, unit: string): string {
  if (facts.scanned.length > 0 && facts.withText.length === 0) {
    return `${ofPages(facts)} page(s) hold images but no text layer, so they read as pictures. There is no ${unit} in them until the page has been OCR'd.`;
  }
  if (facts.scanned.length > 0) {
    return `Only ${singular(facts.scanned.length, 'page')} (${listPages(facts.scanned)}) had no text layer, and the rest held no ${unit} either.`;
  }
  if (facts.chars === 0 && facts.images > 0) {
    return `The ${facts.pages.length} selected page(s) are drawings and images with no text at all, so there is no ${unit} to read.`;
  }
  if (facts.chars === 0) {
    return `The ${facts.pages.length} selected page(s) are blank — no text, no images, nothing to write into ${unit}.`;
  }
  return `No ${unit} was found on ${facts.pages.length} page(s), although they do contain text.`;
}

function emptyAdvice(facts: ExtractionFacts): string[] {
  const advice: string[] = [];
  if (facts.scanned.length > 0) {
    advice.push('Run OCR (Searchable PDF) on this file first, then extract again.');
    advice.push('Or export the pages with PDF to Image and work from the pictures.');
  } else {
    advice.push('Widen the page selection — the content may be on a page that was left out.');
    advice.push('Check the file with View metadata or Page Dimensions to see what it holds.');
  }
  return advice;
}

/**
 * Partial successes, phrased for `result.warnings`: three good pages and one
 * scan must never be reported as a clean run (E10, E7).
 */
function degradedPages(facts: ExtractionFacts, consequence: string): string[] {
  const warnings: string[] = [];
  if (facts.scanned.length > 0) {
    warnings.push(
      `${ofPages(facts)} page(s) have no text layer (image only — a scan). ${consequence}`,
    );
  }
  if (facts.blank.length > 0) {
    warnings.push(`Page ${listPages(facts.blank)} is blank — no text and no images.`);
  }
  return warnings;
}

/** Anything the input guard already admitted (E3) rides along with the result. */
function inputNotices(input: OpenedInput): string[] {
  const seen = input.inspection;
  if (!seen?.recovered) return [];
  return [
    `"${seen.name}" is damaged: ${seen.pages} of ${seen.declaredPages ?? 'its'} page(s) could be read, so the output may be short.`,
  ];
}

function withWarnings<T extends ToolResult>(result: T, warnings: readonly string[]): T {
  const merged = [...new Set([...(result.warnings ?? []), ...warnings.filter(Boolean)])];
  return merged.length === 0 ? result : ({ ...result, warnings: merged } as T);
}

/* ── resolution (E15) ─────────────────────────────────────────────────────── */

const DPI_FLOOR = 24;
const DPI_CEILING = 3600;

/**
 * A resolution the renderer can act on.
 *
 * `0` is refused rather than clamped: at 0 dpi every page becomes a 1×1 pixel,
 * so the tool would "succeed" and hand back a handful of blank thumbnails. A
 * value that is merely outside the useful band is moved onto it and said out
 * loud, which is the other half of E15.
 */
function resolveDpi(value: number): { dpi: number; notice?: string } {
  if (!Number.isFinite(value) || value <= 0) {
    const shown = Number.isFinite(value) ? value : 'blank';
    throw new ToolInputError(
      "OUT_OF_RANGE",
      `A resolution of ${shown} dpi cannot be rendered: an image needs a positive number of dots per inch.`,
      { hint: `Use between ${DPI_FLOOR} and ${DPI_CEILING} dpi — 200 for screen, 300 for print.` },
    );
  }
  if (value < DPI_FLOOR) {
    return {
      dpi: DPI_FLOOR,
      notice: `Resolution raised from ${value} dpi to ${DPI_FLOOR} dpi, the smallest value that still renders a legible page.`,
    };
  }
  if (value > DPI_CEILING) {
    return {
      dpi: DPI_CEILING,
      notice: `Resolution lowered from ${value} dpi to ${DPI_CEILING} dpi so one page still fits in memory.`,
    };
  }
  return { dpi: Math.round(value) };
}

/* ── raster export (E7, E8, E9, E15, E17) ─────────────────────────────────── */

/** Extract → render → download helper shared by the image exporters. */
async function exportPages(
  context: ToolRunContext,
  options: {
    format: 'png' | 'jpeg' | 'webp' | 'bmp' | 'tiff';
    extension: string;
    dpi: number;
    quality: number;
    pages: PageSpec;
    zipWhenMany?: boolean;
  },
) {
  const [input] = await openInputs(context);
  const { session } = await withRender(input, context);
  try {
    const indices = pageSelection(input, options.pages);
    if (indices.length === 0) {
      return noPagesSelected(input);
    }
    const { dpi, notice } = resolveDpi(options.dpi);
    const scale = dpi / 72;
    const stem = outputStem(input.name);
    // Rotation-aware geometry, page by page: a document may mix A4, Letter and
    // landscape scans, and each image has to match its own page (E8, E9).
    const boxes = pageSizeReport(input.doc);
    const warnings: string[] = [...(notice ? [notice] : []), ...inputNotices(input)];
    const sizes = new Set<string>();
    let rotated = 0;
    const sideways: string[] = [];
    const files: { blob: Blob; name: string }[] = [];
    for (let i = 0; i < indices.length; i++) {
      const page = indices[i];
      throwIfAborted(context.signal);
      const box = boxes[page - 1];
      if (box) {
        sizes.add(`${box.widthPt}x${box.heightPt}`);
        if (box.rotation % 180 !== 0) rotated += 1;
      }
      const render = await session.renderPage(page, scale, { background: '#ffffff' });
      if (box && box.widthPt !== box.heightPt) {
        const wideOut = render.width > render.height;
        const wantWide = box.widthPt > box.heightPt;
        if (wideOut !== wantWide) {
          sideways.push(`${page} (image ${render.width}×${render.height} px, page shows as ${box.widthPt}×${box.heightPt} pt)`);
        }
      }
      // `renderPage` settles when the paint is *scheduled*; the pixels land on
      // `finished`. Encoding the canvas before that shipped four identical
      // 44 128-byte PNGs at 0.00 % ink on the deployed site (`exportPages` is the
      // only rasteriser in this file, and each of its five callers reaches it):
      // every page had its own correct pixel size and none had any paint, because
      // `canvasToBlob` → `flattenIfNeeded` copies the canvas synchronously. Same
      // one await `rasterizePages` needed in `6b9b479` and `rasterize-pdf` in
      // `4ba14b6`; the await belongs here, not in `core/raster.ts`, which only
      // encodes the canvas it is handed, nor in `core/render.ts`, which is already
      // honest about `finished`.
      await render.finished;
      const blob = await canvasToBlob(render.canvas, options.format, options.quality, {
        background: '#ffffff',
        // The density the user asked for travels into the file, not just into
        // the pixel count (E12, E15).
        dpi,
      });
      files.push({ blob, name: `${stem}-page-${pageNumber(page, input.pageCount)}.${options.extension}` });
      render.cancel();
      context.progress((i + 1) / indices.length, `Exported page ${page} of ${indices.length}`);
    }
    if (sideways.length > 0) {
      warnings.push(`Page ${sideways.join('; ')} came out the wrong way round: its /Rotate value was not applied.`);
    }
    if (files.length !== indices.length) {
      warnings.push(`${indices.length - files.length} selected page(s) produced no image and were skipped.`);
    }
    const summary = [
      `${singular(files.length, `${options.format.toUpperCase()} image`)} at ${dpi} dpi`,
      sizes.size > 1 ? `${sizes.size} different page sizes` : 'one page size',
      rotated > 0 ? `${rotated} rotated page(s) kept upright` : null,
    ]
      .filter(Boolean)
      .join(' · ')
      + '.';
    if (options.format === 'tiff' && files.length > 1) {
      const merged = await concatTiffs(files.map((file) => file.blob));
      return withWarnings(
        filesResult(
          [{ blob: merged, name: `${stem}.tif` }],
          `${summary} Written as ${files.length} pages in one multi-page TIFF.`,
        ),
        warnings,
      );
    }
    if (files.length > 1 && options.zipWhenMany !== false) {
      const { createZip } = await import('../core/archive');
      const blob = await createZip(files.map((file) => ({ name: file.name, data: file.blob })));
      return withWarnings(
        filesResult([{ blob, name: `${stem}-images.zip` }], `${summary} Packaged as one .zip.`),
        warnings,
      );
    }
    return withWarnings(filesResult(files, summary), warnings);
  } finally {
    await session.destroy();
  }
}

const RESOLUTION_FIELD = resolutionField({
  min: 72,
  max: 600,
  group: "输出",
  help: "200 dpi 适合屏幕，300 dpi 适合打印。越高越清晰、越重，每个页面都在此选项卡中呈现。",
});

const PAGES_FIELD = pagesField();

/** The disclosure every page-to-picture exporter owes the user (E10, E13). */
const RASTER_OUT_NOTES = [
  'A rendered page is a picture: the text layer does not travel with it, so the images cannot be searched or copied.',
  'More than one page is packaged as a single ZIP; a one-page selection downloads on its own.',
];

/** Shared by the text exporters: what a page with nothing to read costs. */
function textOutNotes(what: string): string[] {
  return [
    `Pages with no text layer contribute nothing to the ${what}, and the result names them instead of reporting a silent success.`,
    'A scan needs a text layer before it can be extracted: run OCR first if the output comes back empty.',
  ];
}

/**
 * Read the selected pages once, for every text-shaped exporter.
 *
 * `facts` is the honest answer to "did this work?": it counts the characters a
 * reader can actually see, per page, so a scan, a blank page and a page of
 * glyph-map noise are told apart instead of all reporting success (E10, E13).
 */
async function buildJson(context: ToolRunContext) {
  const [input] = await openInputs(context);
  const { session } = await withRender(input, context);
  try {
    const indices = pageSelection(input, pageSpec(context.values));
    if (indices.length === 0) {
      const json = { meta: {}, pages: [] } as PdfJsonDocument;
      return { input, json, facts: factsFromPages([]) };
    }
    const json = await documentToJson(input.doc, session, indices);
    context.progress(0.9, `Read ${json.pages.length} page(s)`);
    return { input, json, facts: extractionFacts(json) };
  } finally {
    await session.destroy();
  }
}

const TEXT_MIME: Record<string, string> = {
  txt: 'text/plain',
  md: 'text/markdown',
  csv: 'text/csv',
  json: 'application/json',
};

/**
 * One text download.
 *
 * CSV gets a UTF-8 byte-order mark because Excel and Sheets both assume a
 * legacy codepage without it, which turns CJK and accented output into mojibake
 * the moment the file is opened (E11).
 */
function textFiles(name: string, extension: string, content: string) {
  const body = extension === 'csv' ? `\uFEFF${content}` : content;
  return [{
    blob: new Blob([body], { type: TEXT_MIME[extension] ?? `text/${extension}` }),
    name: `${outputStem(name)}.${extension}`,
  }];
}

function jsonFile(name: string, suffix: string, value: unknown, options: { pretty?: boolean } = {}) {
  const body = typeof value === 'string' ? value : JSON.stringify(value, null, options.pretty === false ? undefined : 2);
  return [{
    blob: new Blob([body], { type: TEXT_MIME.json }),
    name: `${outputStem(name)}${suffix}`,
  }];
}

/**
 * A font height no text on earth is drawn at, which is how heading promotion
 * is switched **off**: `jsonToMarkdown` and friends read an empty
 * `headingHeights` list as "work the heights out yourself", so `[]` meant the
 * rail's "Detect headings" toggle could never actually be turned off.
 */
const NO_HEADING_HEIGHT = 0.01;

export const convertFromTools: PdfToolDefinition[] = [
  {
    id: 'pdf-to-text',
    name: "PDF 到文本",
    description: "将每个页面的文本提取为纯 .txt 文件",
    icon: '📃',
    category: 'convert-from',
    keywords: ['extract text', 'copy text', 'plain text', 'readability'],
    surface: 'none',
    outputSuffix: '.txt',
    readsOnly: true,
    promise: 'A .txt file holding the words from the pages you picked, with a word count you can check against the original.',
    actionLabel: "提取文本",
    notes: textOutNotes('text file'),
    fields: [
      PAGES_FIELD,
      { key: 'layout', label: "保持线路布局", type: 'toggle', default: true, group: "输出", help: "Off 将换行连接成流动的段落，这样可以更好地阅读并在任何编辑器中重新换行。" },
      { key: 'pageMarkers', label: "插入分页标记", type: 'toggle', default: false, group: "输出", help: "在页面之间写入换页，以便文本编辑器或“猫”可以再次找到页面边界。" },
    ],
    async run(context) {
      const { input, json, facts } = await buildJson(context);
      const blocker = nothingToRead(input, facts, 'text');
      if (blocker) return blocker;
      const text = tidy(textDocument(json, {
        layout: booleanValue(context.values, 'layout', true),
        pageMarkers: booleanValue(context.values, 'pageMarkers'),
      }));
      const words = text.split(/\s+/).filter(Boolean).length;
      return withWarnings(
        filesResult(
          textFiles(input.name, 'txt', text),
          `Extracted ${words.toLocaleString()} words from ${json.pages.length} page(s).`,
        ),
        [...degradedPages(facts, 'They contributed no text to the file.'), ...inputNotices(input)],
      );
    },
  },

  {
    id: 'pdf-to-markdown',
    name: "PDF 到 Markdown",
    description: "通过实时预览将标题、列表和表格转换为 Markdown",
    icon: '📝',
    category: 'convert-from',
    keywords: ['md', 'readme', 'llm', 'notes'],
    surface: 'none',
    outputSuffix: '.md',
    readsOnly: true,
    promise: 'A Markdown file with real headings, lists and tables — not a flat dump of every line.',
    actionLabel: "转换为 Markdown",
    notes: textOutNotes('Markdown'),
    fields: [
      PAGES_FIELD,
      { key: 'tables', label: "将表格重建为 Markdown 表格", type: 'toggle', default: true, group: "结构", help: "关闭将表格保持为普通线条，因为宽表格在管道网格中变得不可读。" },
      { key: 'headings', label: "根据字体大小检测标题", type: 'toggle', default: true, group: "结构", help: "大量文本变成“##”。当文档使用大小而不是结构来强调时，请将其关闭。" },
      { key: 'pageBreaks', label: "用规则分隔页面", type: 'toggle', default: false, group: "结构", help: "在每页结束处添加水平线，以便幻灯片保持其形状。" },
    ],
    async run(context) {
      const { input, json, facts } = await buildJson(context);
      const blocker = nothingToRead(input, facts, 'Markdown');
      if (blocker) return blocker;
      const markdown = jsonToMarkdown(json, {
        headingHeights: booleanValue(context.values, 'headings', true)
          ? detectHeadingHeights(json)
          : [NO_HEADING_HEIGHT],
        tables: booleanValue(context.values, 'tables', true),
        pageBreaks: booleanValue(context.values, 'pageBreaks'),
      });
      return withWarnings(
        filesResult(
          textFiles(input.name, 'md', markdown),
          `Wrote ${markdown.split('\n').length} lines of Markdown from ${json.pages.length} page(s).`,
        ),
        [...degradedPages(facts, 'Those pages became a comment, not prose.'), ...inputNotices(input)],
      );
    },
  },

  {
    id: 'pdf-to-json',
    name: "PDF 到 JSON",
    description: "具有边界框、字体和表格网格的结构化块",
    icon: '🧩',
    category: 'convert-from',
    keywords: ['data', 'api', 'structured', 'parsing'],
    surface: 'none',
    outputSuffix: '.json',
    readsOnly: true,
    promise: 'A JSON file with every block, its text, bounding box and fonts, plus the tables the grid implies.',
    actionLabel: "导出JSON",
    notes: textOutNotes('JSON'),
    // No `tables` switch, on purpose. `documentToJson` detects the grid and
    // splices it into every page's blocks inside `core/convert.ts`, before any
    // caller sees them, so both values of a toggle produced byte-identical JSON
    // (measured: 1696 B, sha 90772710962aff99 either way, one table block in each
    // — `docs/research/inert-field-sweep.md`, `tests/pdf/field-reach.test.ts`).
    // Making the option real is a `core/convert.ts` feature — a flag on
    // `documentToJson`, and an answer for what "off" costs in speed — not a
    // control this file can honour.
    fields: [PAGES_FIELD],
    async run(context) {
      const { input, json, facts } = await buildJson(context);
      // A page of pictures only is still worth describing, so the empty-result
      // report is reserved for a selection with no text *and* no images and no
      // tables (E13) — the scan case keeps its file and gains a warning.
      const blocker = nothingToRead(input, facts, 'content');
      if (blocker && facts.images + facts.tables === 0) return blocker;
      const body = JSON.stringify(json, null, 2);
      return withWarnings(
        filesResult(
          [{ blob: new Blob([body], { type: 'application/json' }), name: `${outputStem(input.name)}.json` }],
          `${json.pages.length} page(s), ${json.pages.reduce((n, page) => n + page.blocks.length, 0)} block(s).`,
        ),
        [
          ...degradedPages(facts, 'Their JSON carries an empty "text" field.'),
          ...inputNotices(input),
        ],
      );
    },
  },

  {
    id: 'prepare-pdf-for-ai',
    name: "为AI准备PDF",
    description: "将文档分块为 RAG 的 LlamaIndex 兼容 JSON",
    icon: '🤖',
    category: 'convert-from',
    keywords: ['rag', 'llm', 'embedding', 'chunks', ' llamaindex'],
    surface: 'none',
    outputSuffix: '-llamaindex.json',
    readsOnly: true,
    promise: 'One chunked, referenced JSON file an embedding pipeline can index without another pass.',
    actionLabel: "用于AI的块",
    notes: textOutNotes('chunks'),
    fields: [
      PAGES_FIELD,
      { key: 'title', label: "文档ID", type: 'text', group: "索引", placeholder: "文件名，如果留空", help: "每个块都指向该 ID，因此稍后更改它会孤立索引中已有的行。" },
      { key: 'extra', label: "额外元数据(JSON)", type: 'textarea', default: '', group: "索引", placeholder: '{ "source": "contracts" }', help: "字符串和数字的一个扁平对象，被复制到每个块上。任何嵌套的内容都会在运行之前被拒绝。" },
    ],
    async run(context) {
      const { input, json, facts } = await buildJson(context);
      const blocker = nothingToRead(input, facts, 'text to chunk');
      if (blocker) return blocker;
      const extra = stringValue(context.values, 'extra').trim();
      let parsed: Record<string, unknown> | undefined;
      if (extra) {
        try {
          parsed = JSON.parse(extra) as Record<string, unknown>;
        } catch {
          throw new ToolInputError(
            "OUT_OF_RANGE",
            'The extra metadata must be valid JSON, for example {"source": "contracts"}.',
            { hint: "字符串和数字的一个平面对象，这是索引存储的内容。" },
          );
        }
      }
      const doc = jsonToLlamaIndex(json, {
        title: stringValue(context.values, 'title') || input.name,
        extraMetadata: parsed,
      });
      const chunks = Object.keys(doc.ref_doc_info).length;
      return withWarnings(
        filesResult(
          jsonFile(input.name, '-llamaindex.json', doc, { pretty: false }),
          `Produced ${chunks} reference document(s) from ${json.pages.length} page(s), ready for an index.`,
        ),
        [...degradedPages(facts, 'They became an empty chunk in the index.'), ...inputNotices(input)],
      );
    },
  },

  {
    id: 'pdf-to-csv',
    name: "PDF转CSV",
    description: "检测表并将其导出为 CSV",
    icon: '🗃️',
    category: 'convert-from',
    keywords: ['spreadsheet', 'rows', 'extract table'],
    surface: 'none',
    outputSuffix: '.csv',
    readsOnly: true,
    promise: 'A CSV file with one row per detected table row — or an honest report when the pages hold no table at all.',
    actionLabel: "导出 CSV",
    notes: [
      'The file is written as UTF-8 with a byte-order mark, because Excel and Sheets both assume a legacy codepage without it and turn accented cells into mojibake.',
      'A block of prose is not a table: when nothing is detected you get a report naming the pages it looked at, not an empty download.',
    ],
    fields: [
      PAGES_FIELD,
      { key: 'minRows', label: "最小行数", type: 'number', default: 3, min: 2, max: 20, step: 1, integer: true, half: true, group: "表格", help: "文本块在算作表格之前需要这么多对齐的行。当列标题继续被读取为表格时，请提高它。" },
      { key: 'delimiter', label: "定界符", type: 'select', default: ',', group: "CSV文件", options: [
        { value: ',', label: "逗号" }, { value: ';', label: "分号" }, { value: '\t', label: "标签" },
      ], help: "分号或制表符在欧洲语言环境电子表格中打开后仍然存在，其中逗号是小数点。" },
    ],
    async run(context) {
      const { input, tables, facts } = await collectTables(context);
      if (tables.length === 0) return noTablesFound(input, facts, numberValue(context.values, 'minRows', 3));
      const csv = tablesToCsv(tables, stringValue(context.values, 'delimiter', ','));
      return withWarnings(
        filesResult(
          textFiles(input.name, 'csv', csv),
          `Extracted ${tables.length} table(s) totalling ${tables.reduce((n, table) => n + table.rows.length, 0)} rows.`,
        ),
        [...degradedPages(facts, 'No rows could be read from them, so they are missing from the CSV.'), ...inputNotices(input)],
      );
    },
  },

  {
    id: 'extract-tables',
    name: "提取表",
    description: "查找表格并将其导出为 CSV、JSON 或 Markdown",
    icon: '📊',
    category: 'convert-from',
    keywords: ['table detection', 'rows', 'columns', 'data'],
    surface: 'none',
    outputSuffix: '-tables.json',
    readsOnly: true,
    promise: 'Every table on the selected pages, as one file in the format you choose, with the page it came from.',
    actionLabel: "提取表",
    notes: [
      'Tables are found from ruled lines and aligned columns, so a table drawn as free text with no gaps can be missed — the report says which pages were checked.',
    ],
    fields: [
      PAGES_FIELD,
      { key: 'format', label: "文件格式", type: 'segmented', default: 'json', group: "输出", options: [
        { value: 'json', label: 'JSON' }, { value: 'csv', label: 'CSV' }, { value: 'md', label: "降价" },
      ], help: "JSON保存页面和单元格坐标； CSV 和 Markdown 是为了阅读，所以它们把它们压平了。" },
      { key: 'minRows', label: "最小行数", type: 'number', default: 2, min: 2, max: 20, step: 1, integer: true, group: "表格", help: "文本块在算作表格之前需要这么多对齐的行。" },
    ],
    async run(context) {
      const { input, tables, facts } = await collectTables(context);
      if (tables.length === 0) return noTablesFound(input, facts, numberValue(context.values, 'minRows', 2));
      const format = stringValue(context.values, 'format', 'json');
      const notices = [...degradedPages(facts, 'They held no table, so nothing was written for them.'), ...inputNotices(input)];
      if (format === 'csv') {
        return withWarnings(
          filesResult(textFiles(input.name, 'csv', tablesToCsv(tables)), `${tables.length} table(s).`),
          notices,
        );
      }
      if (format === 'md') {
        // A Markdown file needs a level-1 title before the per-table `##` ones,
        // or the first line is a section heading with no document heading.
        const body = [
          `# Tables from ${outputStem(input.name)}`,
          '',
          `Extracted from ${facts.pages.length} page(s); ${tables.length} table(s).`,
          ...tables.map((table, index) => `\n## Table ${index + 1}\n\n${toMarkdownTable(table)}`),
        ].join('\n');
        return withWarnings(
          filesResult(textFiles(input.name, 'md', body), `${tables.length} table(s).`),
          notices,
        );
      }
      return withWarnings(
        filesResult(
          jsonFile(input.name, '-tables.json', { tables }),
          `${tables.length} table(s) with ${tables.reduce((n, table) => n + table.rows.length, 0)} rows.`,
        ),
        notices,
      );
    },
  },

  {
    id: 'pdf-to-excel',
    name: "PDF 到 Excel",
    description: "每个检测到的表都成为真实.xlsx中的工作表",
    icon: '📈',
    category: 'convert-from',
    keywords: ['xlsx', 'workbook', 'spreadsheet', 'sheets'],
    surface: 'none',
    outputSuffix: '.xlsx',
    readsOnly: true,
    promise: 'A real .xlsx workbook with one worksheet per detected table, columns already widened.',
    actionLabel: "导出电子表格",
    notes: [
      'Cells arrive as text plus whatever number the text clearly was; a table drawn without a text layer cannot become a workbook, and the result says so.',
    ],
    fields: [
      PAGES_FIELD,
      { key: 'oneSheet', label: "将所有内容放在一张纸上", type: 'toggle', default: false, group: "练习册", help: "关闭为每个检测到的表保留一个工作表，这是您在旋转之前想要的；将它们堆叠起来，中间有一个空白行。" },
      { key: 'minRows', label: "最小行数", type: 'number', default: 2, min: 2, max: 20, step: 1, integer: true, group: "练习册", help: "文本块在算作表格之前需要这么多对齐的行。" },
    ],
    async run(context) {
      const { input, tables, facts } = await collectTables(context);
      if (tables.length === 0) {
        return noTablesFound(input, facts, numberValue(context.values, 'minRows', 2));
      }
      const XLSX = await import('xlsx');
      const workbook = XLSX.utils.book_new();
      if (booleanValue(context.values, 'oneSheet')) {
        const rows = tables.flatMap((table) => [...typedRows(table.rows), []]);
        XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet(rows), 'Tables');
      } else {
        tables.forEach((table, index) => {
          const sheet = XLSX.utils.aoa_to_sheet(typedRows(table.rows));
          const widths = (table.rows[0] ?? []).map((_, column) => ({
            wch: Math.min(60, Math.max(8, ...tables[index].rows.map((row) => (row[column] ?? '').length))),
          }));
          sheet['!cols'] = widths;
          XLSX.utils.book_append_sheet(workbook, sheet, `Table ${index + 1}`.slice(0, 31));
        });
      }
      // `bookSST` puts repeated text in `xl/sharedStrings.xml` and leaves the
      // cells pointing at it, which is how a workbook exported by Excel itself is
      // laid out; without it every cell carries its own copy of the string.
      const out: Uint8Array = XLSX.write(workbook, { type: 'array', bookType: 'xlsx', bookSST: true });
      return withWarnings(
        filesResult(
          [{
            blob: new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
            name: `${outputStem(input.name)}.xlsx`,
          }],
          `${tables.length} table(s) across ${workbook.SheetNames.length} worksheet(s).`,
        ),
        [
          ...degradedPages(facts, 'They are not in the workbook.'),
          ...inputNotices(input),
        ],
      );
    },
  },

  {
    id: 'pdf-to-word',
    name: "PDF 到 Word",
    description: "将文档重建为可编辑的 .docx，包含标题、列表和表格",
    icon: '📄',
    category: 'convert-from',
    keywords: ['docx', 'editable', 'office', 'rewrite'],
    surface: 'none',
    outputSuffix: '.docx',
    readsOnly: true,
    promise: 'An editable .docx rebuilt from the text, headings and tables — content you can rewrite, not a picture of the page.',
    actionLabel: "转换为Word",
    notes: [
      'Word re-flows the page, so line breaks, column positions and the original font are not preserved; anything that must land exactly where it was should stay a PDF.',
    ],
    fields: [
      PAGES_FIELD,
      { key: 'headings', label: "将字体大小映射到Word标题样式", type: 'toggle', default: true, group: "结构", help: "标题样式构成可导航文档；位置和原始字体不会在映射中保留下来。" },
      { key: 'tables', label: "将表格重建为Word表格", type: 'toggle', default: true, group: "结构", help: "“关闭”将行粘贴为纯段落，这对于具有合并或空单元格的表格来说更安全。" },
      { key: 'pageBreaks', label: "为每个PDF页面开始一个新页面", type: 'toggle', default: false, group: "结构", help: "打开保留您打印时使用的页码；关闭会让 Word 重新流动，因此页码将与原始页码不匹配。" },
    ],
    async run(context) {
      const { input, json, facts } = await buildJson(context);
      const blocker = nothingToRead(input, facts, 'text');
      if (blocker) return blocker;
      const { buildDocx } = await import('../core/docx-out');
      const blob = await buildDocx(json, {
        headings: booleanValue(context.values, 'headings', true),
        tables: booleanValue(context.values, 'tables', true),
        pageBreaks: booleanValue(context.values, 'pageBreaks'),
      });
      return withWarnings(
        filesResult(
          [{ blob, name: `${outputStem(input.name)}.docx` }],
          `Wrote a Word document from ${json.pages.length} page(s). Text is editable; original positions are not preserved.`,
        ),
        [...degradedPages(facts, 'They reached the document as an empty paragraph.'), ...inputNotices(input)],
      );
    },
  },

  {
    id: 'pdf-to-svg',
    name: "PDF 到 SVG",
    description: "矢量导出 — 路径和文本在任何尺寸下都保持清晰",
    icon: '🧷',
    category: 'convert-from',
    keywords: ['vector', 'illustrator', 'scale', 'svg'],
    surface: 'none',
    outputSuffix: '.svg',
    readsOnly: true,
    promise: 'Vector pages that stay sharp at any zoom, with the text left as text wherever the page allows it.',
    actionLabel: "导出SVG",
    notes: [
      'Fonts are referenced, not embedded, so an SVG opened without the original font installed is redrawn with a substitute.',
    ],
    fields: [
      PAGES_FIELD,
      { key: 'embedImages', label: "嵌入光栅图像作为数据URI", type: 'toggle', default: true, group: "输出", help: "关闭将照片保留在文件之外，这使其保持较小，但意味着在其他地方打开它会显示空白帧。" },
      { key: 'asOne', label: "每个文档一个SVG而不是每页一个SVG", type: 'toggle', default: false, group: "输出", help: "关闭为您每页提供一个 SVG。 On 将它们打包到 ZIP 中，因为单个 SVG 只能包含一页。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { session } = await withRender(input, context);
      try {
        const { documentToSvg } = await import('../core/convert');
        const indices = pageSelection(input, pageSpec(context.values));
        if (indices.length === 0) {
          return noPagesSelected(input);
        }
        const stem = outputStem(input.name);
        const files: { blob: Blob; name: string }[] = [];
        for (let i = 0; i < indices.length; i++) {
          const svg = await documentToSvg(input.doc, session, indices[i], {
            embedImages: booleanValue(context.values, 'embedImages', true),
          });
          files.push({
            blob: new Blob([svg], { type: 'image/svg+xml' }),
            name: `${stem}-page-${pageNumber(indices[i], input.pageCount)}.svg`,
          });
          context.progress((i + 1) / indices.length, `Vectorised page ${indices[i]}`);
        }
        if (files.length === 1 || !booleanValue(context.values, 'asOne')) return filesResult(files);
        const { createZip } = await import('../core/archive');
        const blob = await createZip(files.map((file) => ({ name: file.name, data: file.blob })));
        return filesResult([{ blob, name: `${stem}-svg.zip` }], `${files.length} SVG pages zipped.`);
      } finally {
        await session.destroy();
      }
    },
  },

  {
    id: 'extract-images',
    name: "提取图像",
    description: "将嵌入的图像以其原始分辨率从PDF中拉出",
    icon: '🖼️',
    category: 'convert-from',
    keywords: ['photos', 'unembed', 'gallery', 'assets'],
    surface: 'none',
    outputSuffix: '-images.zip',
    // The pictures are lifted out of the file rather than rendered, so on a
    // ciphered document this reports them missing instead of inventing them.
    readsOnly: true,
    promise: 'The original image bytes, page by page — no re-encoding, so what you get is what the file held.',
    actionLabel: "提取图像",
    notes: [
      'Only images actually stored in the file can be pulled out: a page drawn from text and vector shapes has none, and a scanned page has one image of the whole sheet (use PDF to Image for that).',
      'More than one image arrives as a single ZIP; a lone image downloads on its own.',
    ],
    fields: [
      PAGES_FIELD,
      { key: 'smallest', label: "忽略小于以下的图像", type: 'number', default: 64, min: 0, max: 2000, step: 8, integer: true, unit: "px", group: "过滤器", help: "图标、项目符号和1 px蒙版通常不是艺术品。设置 0 来拍摄页面上的每张图像。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { extractPageImages } = await import('../core/images-out');
      const indices = pageSelection(input, pageSpec(context.values));
      const smallest = numberValue(context.values, 'smallest', 64);
      const stem = outputStem(input.name);
      const found: { name: string; blob: Blob }[] = [];
      const unreadable: SkippedImage[] = [];
      for (let i = 0; i < indices.length; i++) {
        // The rail's own floor is the only size filter. The core helper also
        // drops anything 2 px or under as a decorative tile, which hid a real
        // 1x1 thumbnail the user had never asked to skip (E15).
        const images = await extractPageImages(input.doc, indices[i], {
          minSide: smallest,
          skipMasks: false,
          // E13: an image that was found and not returned has to say so. A page
          // of bilevel scans is not a page with "no embedded images", and the
          // specific cause (fax encoding, 12-bit samples, a /Separation tint
          // transform) is the only thing that tells the user what to do next.
          onSkipped: (skip) => unreadable.push({ ...skip, name: skip.name ?? `the ${skip.width}×${skip.height} image on page ${indices[i]}` }),
        });
        images.forEach((image: ExtractedImage, index: number) => {
          found.push({
            // Both counters are padded from the start: `shots-p2-9.png` sorts
            // after `shots-p12-1.png` in every file manager (E17).
            name: `${stem}-p${pageNumber(indices[i], input.pageCount)}-${String(index + 1).padStart(3, '0')}.${image.extension}`,
            blob: new Blob([image.bytes], { type: image.mime }),
          });
        });
        context.progress((i + 1) / indices.length, `Scanned page ${indices[i]}`);
        throwIfAborted(context.signal);
      }
      const partial = unusableNote(unreadable);
      if (found.length === 0) {
        return withWarnings(reportResult(emptyImageReport(unreadable, indices.length, smallest), {
          message: unreadable.length > 0
            ? `${unreadable.length} image(s) found, none of them readable here.`
            : 'No extractable images.',
        }), [...inputNotices(input), ...partial]);
      }
      if (found.length === 1) return withWarnings(filesResult(found), partial);
      const { createZip } = await import('../core/archive');
      const blob = await createZip(found.map((file) => ({ name: file.name, data: file.blob })));
      return withWarnings(
        filesResult(
          [{ blob, name: `${stem}-images.zip` }],
          `Extracted ${found.length} image(s) from ${indices.length} page(s).`,
        ),
        partial,
      );
    },
  },

  {
    id: 'pdf-to-image',
    name: "PDF到图像",
    description: "将页面呈现为JPG、PNG、WEBP、BMP或TIFF",
    icon: '🖼️',
    category: 'convert-from',
    keywords: ['jpg', 'png', 'webp', 'bmp', 'tiff', 'screenshot'],
    surface: 'none',
    outputSuffix: '_images',
    readsOnly: true,
    promise: 'One image per selected page in the format you choose, zipped when the selection runs to more than one page.',
    actionLabel: "导出图像",
    notes: [
      'A rendered page is a picture: the text layer does not travel with it, so the images cannot be searched or copied.',
      'More than one page is packaged as a single ZIP; a one-page selection downloads on its own. TIFF ignores this and carries every page in one file.',
    ],
    multiFile: false,
    fields: [
      {
        key: 'format',
        label: "文件格式",
        type: 'segmented',
        default: 'png',
        group: "输出",
        options: [
          { value: 'png', label: "巴布亚新几内亚" }, { value: 'jpeg', label: 'JPG' },
          { value: 'webp', label: 'WEBP' }, { value: 'bmp', label: 'BMP' }, { value: 'tiff', label: 'TIFF' },
        ],
        help: "BMP和TIFF是未压缩的，因此两者中的整个文档的大小是PDF的许多倍。",
      },
      RESOLUTION_FIELD,
      qualityField('jpeg', {
        default: 0.92,
        step: 0.02,
        group: "输出",
        help: "适用于JPG和WebP，上述两种有损格式。降低可以节省空间并增加小文本周围的块状效果。",
        when: (v) => v.format === 'jpeg' || v.format === 'webp',
      }),
      PAGES_FIELD,
      { key: 'zip', label: "多于一页时压缩", type: 'toggle', default: true, group: "输出", help: "几个页面是许多单独的下载。 TIFF 忽略这一点：它在一个文件中包含每一页。" },
    ],
    async run(context) {
      const format = stringValue(context.values, 'format', 'png') as 'png' | 'jpeg' | 'webp' | 'bmp' | 'tiff';
      return exportPages(context, {
        format,
        extension: format === 'jpeg' ? 'jpg' : format === 'tiff' ? 'tif' : format,
        dpi: numberValue(context.values, 'dpi', 200),
        quality: numberValue(context.values, 'quality', 0.92),
        pages: pageSpec(context.values),
        zipWhenMany: booleanValue(context.values, 'zip', true),
      });
    },
  },

  ...(['pdf-to-png', 'pdf-to-jpg', 'pdf-to-webp', 'pdf-to-bmp', 'pdf-to-tiff'] as const).map((id): PdfToolDefinition => {
    const format = id === 'pdf-to-jpg' ? 'jpeg' : id.replace('pdf-to-', '') as 'png' | 'webp' | 'bmp' | 'tiff';
    const label = format === 'jpeg' ? 'JPG' : format.toUpperCase();
    return {
      id,
      name: `PDF 转 ${label}`,
      description: `Convert each PDF page into a ${label} image`,
      icon: '🖼️',
      category: 'convert-from',
      keywords: ['image', label.toLowerCase(), 'raster', 'export'],
      group: "从 PDF 转换",
      surface: 'none',
      outputSuffix: `_${format}s`,
      promise:
        format === 'tiff'
          ? 'Every selected page as a TIFF, several pages written into one multi-page file.'
          : `Every selected page as its own ${label} image, packaged as one ZIP when there is more than one.`,
      actionLabel: `Export ${label}`,
      notes:
        format === 'tiff'
          ? ['A rendered page is a picture: the text layer does not travel with it.', 'Several pages are written into one multi-page TIFF rather than a ZIP.']
          : RASTER_OUT_NOTES,
      fields: [RESOLUTION_FIELD, PAGES_FIELD],
      async run(context) {
        return exportPages(context, {
          format,
          extension: format === 'jpeg' ? 'jpg' : format === 'tiff' ? 'tif' : format,
          dpi: numberValue(context.values, 'dpi', 200),
          quality: 0.92,
          pages: pageSpec(context.values),
          zipWhenMany: true,
        });
      },
    };
  }),

  {
    id: 'pdf-to-greyscale',
    name: "PDF 到灰度",
    description: "将您选择的页面上的颜色转换为黑白",
    icon: '⚪',
    category: 'convert-from',
    keywords: ['black and white', 'monochrome', 'print cheaper', 'desaturate'],
    outputSuffix: '_greyscale.pdf',
    promise: 'A black-and-white copy of the pages you choose, recoloured so the text stays selectable unless you ask for a re-render.',
    actionLabel: "转换为灰度",
    notes: [
      'Recolouring changes the colour operators only, and only on the pages you select: a page you left out keeps its colour. A page whose grey already equals black, or whose colour lives inside an image, comes out unchanged, and the result says how much was converted.',
      'Re-render mode photographs the selected pages and writes only those into the result: their text becomes pixels, the pages you left out are not carried over, and a page kept as a picture at the resolution you chose costs far more than the page did as operators.',
    ],
    fields: [
      { key: 'mode', label: "方法", type: 'segmented', default: 'vectors', group: "方法", options: [
        { value: 'vectors', label: "重新着色（保持文本可选）" },
        { value: 'raster', label: "重新渲染（保证，更大）" },
      ], help: "Recolour 会重写颜色运算符，并且不会丢失您可以选择的任何内容。重新渲染拍摄页面，捕获重新着色无法达到的颜色，并丢弃文本层。" },
      resolutionField({
        key: 'dpi',
        group: "方法",
        max: 400,
        when: (v) => v.mode === 'raster',
        help: "仅由重新渲染使用。越高则越清晰、越重，而且文本已经消失了。",
      }),
      PAGES_FIELD,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      if (stringValue(context.values, 'mode', 'vectors') === 'raster') {
        // Checked here, in words a user can read: `applyColorFilter` resolves the
        // same spec against the render session, where an unknown page surfaces
        // as a raw `PageSpecError` (E6).
        const wanted = pageSelection(input, pageSpec(context.values));
        const { dpi } = resolveDpi(numberValue(context.values, 'dpi', 200));
        const { applyColorFilter } = await import('../core/measure');
        const { session } = await withRender(input, context);
        try {
          const bytes = await applyColorFilter(session, input.doc, {
            grayscale: true,
            brightness: 1,
            contrast: 1,
            saturation: 1,
            hue: 0,
            invert: false,
            pages: wanted.join(','),
            dpi,
            progress: context.progress,
            signal: context.signal,
          });
          // The raster path rebuilds the file page by page inside
          // `core/measure`, so the count comes from the selection it was told to
          // render: `wanted` is resolved here and re-resolved there from the same
          // spec, which `pages-out.test.ts` pins by counting the produced file.
          return withWarnings(
            {
              kind: 'pdf',
              bytes,
              pages: wanted.length,
              message: `Re-rendered ${wanted.length} page(s) at ${dpi} dpi. Text is now part of the image and can no longer be selected or searched.`,
            },
            inputNotices(input),
          );
        } finally {
          await session.destroy();
        }
      }
      const { greyscalePage } = await import('../core/content');
      const indices = pageSelection(input, pageSpec(context.values)).map((page) => page - 1);
      let changed = 0;
      for (let i = 0; i < indices.length; i++) {
        changed += greyscalePage(input.doc.getPage(indices[i]));
        context.progress((i + 1) / indices.length, `Page ${indices[i] + 1}`);
      }
      const bytes = await savePDF(input.doc);
      return {
        kind: 'pdf',
        bytes,
        pages: input.doc.getPageCount(),
        message: changed > 0
          ? `Converted ${changed} colour operation(s) to grey across ${indices.length} page(s). Text stays selectable.`
          : 'This document already had no colour operations to convert.',
      };
    },
  },

  {
    id: 'page-dimensions',
    name: "页面尺寸",
    description: "报告每个页面的大小、方向和命名格式",
    icon: '📐',
    category: 'organize',
    keywords: ['measure', 'a4', 'letter', 'audit', 'size'],
    surface: 'none',
    outputSuffix: '_dimensions.txt',
    readsOnly: true,
    promise: 'A report of every page’s size in points and millimetres, its orientation, named format and rotation.',
    actionLabel: "测量页面",
    notes: [
      'Sizes are read from each page’s own crop box as a viewer displays it, so a page carrying /Rotate is reported the way it prints.',
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const rows = pageSizeReport(input.doc);
      const distinct = new Map<string, number>();
      for (const row of rows) distinct.set(row.name, (distinct.get(row.name) ?? 0) + 1);
      return reportResult(
        [
          {
            title: "总结",
            rows: [...distinct.entries()].map(([name, count]) => ({ label: name, value: `${count} page(s)` })),
          },
          {
            title: "每一页",
            rows: rows.map((row) => ({
              label: `Page ${row.page}`,
              value: `${row.widthPt.toFixed(1)} × ${row.heightPt.toFixed(1)} pt · ${row.widthMm.toFixed(0)} × ${row.heightMm.toFixed(0)} mm · ${row.orientation}${row.rotation ? ` · rotated ${row.rotation}°` : ''}`,
            })),
          },
        ],
        { message: `${rows.length} page(s), ${distinct.size} distinct size(s).` },
      );
    },
  },
];

// ── helpers ─────────────────────────────────────────────────────────────────

/**
 * Every table in the selection, plus what the pages actually gave up.
 *
 * The facts are collected on the same pass as the tables because "no tables
 * were found" is two different pieces of news (E10, E13): the page is prose,
 * or the page is a scan with no text layer at all. Only the second one wants
 * OCR.
 */
async function collectTables(context: ToolRunContext): Promise<TableHaul> {
  const [input] = await openInputs(context);
  const { session } = await withRender(input, context);
  try {
    const indices = pageSelection(input, pageSpec(context.values));
    const minRows = numberValue(context.values, 'minRows', 3);
    const out: DetectedTable[] = [];
    const pages: ExtractionFacts['pages'] = [];
    for (let i = 0; i < indices.length; i++) {
      const items = await session.textItems(indices[i]);
      const found = detectTables(items, { minRows }).map((table) => ({ ...table, page: indices[i] }));
      out.push(...found);
      pages.push({
        page: indices[i],
        chars: readableChars(items.map((item) => item.str).join(' ')),
        images: countImages(input.doc.getPage(indices[i] - 1)),
        tables: found.length,
      });
      context.progress((i + 1) / indices.length, `Looked for tables on page ${indices[i]}`);
    }
    return {
      input,
      tables: out.sort((a, b) => a.page - b.page),
      facts: factsFromPages(pages),
    };
  } finally {
    await session.destroy();
  }
}

/** E13 for the table trio, phrased for what the pages really were (E10). */
function noTablesFound(input: OpenedInput, facts: ExtractionFacts, minRows: number): ToolResult {
  if (facts.pages.length === 0) {
    return noPagesSelected(input);
  }
  const scanned = facts.chars === 0 && facts.images > 0;
  return nothingFound(
    'No tables found',
    scanned
      ? `${ofPages(facts)} page(s) hold images but no text layer, so there is no grid of cells to read — the page is a scan, not a table.`
      : `No grid of aligned columns was found on ${facts.pages.length} page(s), so there is nothing to put in a table.`,
    scanned
      ? ['Run OCR (Searchable PDF) on this file first, then extract the table again.', 'Or export the pages with PDF to Image and read the figures off the picture.']
      : [`Lower the minimum rows setting (now ${minRows}) — a short block still counts.`, 'Use PDF to Text when the page is prose: it keeps the words in reading order.'],
  );
}

/**
 * A detected table with the figures typed as numbers.
 *
 * Cells lifted out of a PDF arrive as text, and text is what the workbook would
 * hold: `1,200` left-aligned as a string, refused by `SUM`, which makes "a real
 * .xlsx" a false claim (E11). Only a cell a reader would unambiguously call a
 * number is converted — an optional sign, an optional currency mark on either
 * side, digit groups and a decimal point. `12%` stays text, because the value a
 * spreadsheet holds for it is `0.12` plus a percent format, and picking a format
 * the PDF never declared is a guess the cell should not make alone.
 */
function typedRows(rows: readonly string[][]): (string | number)[][] {
  return rows.map((row) => row.map((cell) => numericCell(cell) ?? cell));
}

/**
 * The three-letter codes this accepts as a currency, and nothing else: an
 * unknown 3-letter run like `CPU` must not turn `CPU 8` into the number 8.
 */
const ISO_CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD', 'NZD', 'SEK', 'NOK', 'DKK', 'CNY', 'HKD', 'SGD', 'INR', 'BRL', 'MXN', 'ZAR', 'KRW', 'PLN', 'RUB'];

const CURRENCY_SYMBOL = '$\u00a2-\u00a5\u20ac\u00a3';

const CURRENCY_LEAD = new RegExp(`^(?:[${CURRENCY_SYMBOL}]|${ISO_CURRENCIES.join('|')})\\s*`);

const CURRENCY_TRAIL = new RegExp(`\\s*(?:[${CURRENCY_SYMBOL}]|${ISO_CURRENCIES.join('|')})$`);

function numericCell(text: string): number | null {
  let body = (text ?? '').trim();
  if (body === '') return null;
  let negative = false;
  if (/^[+\-\u2212(]/.test(body)) {
    negative = /^[\-\u2212(]/.test(body);
    body = body.replace(/^[+-\u2212(]\s*/, '');
  }
  if (negative && body.endsWith(')')) body = body.slice(0, -1);
  body = body.trim();
  // A currency mark is presentation, not part of the number, so it comes off
  // either end — but only when a digit sits on its inner side.
  const lead = body.match(CURRENCY_LEAD);
  if (lead && /^[+\-]?\d/.test(body.slice(lead[0].length))) body = body.slice(lead[0].length);
  const trail = body.match(CURRENCY_TRAIL);
  if (trail && /\d$/.test(body.slice(0, body.length - trail[0].length))) {
    body = body.slice(0, body.length - trail[0].length);
  }
  body = body.trim();
  if (!/^(?:\d{1,3}(?:[,\u00a0]\d{3})+|\d+)(?:\.\d+)?$/.test(body)) return null;
  const value = Number(body.replace(/[,\u00a0]/g, ''));
  return Number.isFinite(value) ? (negative ? -value : value) : null;
}

/**
 * The Extract Images report for a run that wrote nothing.
 *
 * “No embedded image was found” is only true when the pages hold none, and a
 * page of fax scans disproves it (E13): the images are there, the browser just
 * cannot unpack them. When any were refused, each is named with its own cause —
 * that difference is the whole advice: a size limit the user set is theirs to
 * lower, a CCITT or JBIG2 stream is not.
 */
function emptyImageReport(skipped: SkippedImage[], pages: number, smallest: number): ToolReportSection[] {
  if (skipped.length === 0) {
    return [
      {
        title: "没有嵌入图像",
        text: `No embedded image was found on the ${pages} selected page(s)${smallest > 0 ? ` at or above the ${smallest} px size limit` : ' at all'}. A page drawn from vectors and text has nothing to pull out; a scanned page has one image of the whole sheet, which PDF to Image renders better.`,
      },
      {
        title: "应该尝试什么",
        rows: [
          { label: "选项1", value: smallest > 0 ? `Lower the size limit — "Ignore images smaller than" is now ${smallest} px.` : 'This document holds no images; try PDF to Text.' },
          { label: "选项2", value: 'Use PDF to Image to rasterise the pages themselves.' },
        ],
      },
    ];
  }
  const onlyTooSmall = skipped.every((skip) => /size limit/.test(skip.reason));
  return [
    {
      title: `${singular(skipped.length, 'image')} found, none of them readable here`,
      text: `The ${pages} selected page(s) do hold image${skipped.length === 1 ? '' : 's'}; ${skipped.length} of them could not be turned into pixels, so no file was written. What each one is, and why it was refused:`,
    },
    {
      title: "为什么每个图像都被遗漏了",
      rows: skipped.map((skip, index) => ({
        label: `${skip.name || `image ${index + 1}`} (${skip.width}×${skip.height})`,
        value: skip.reason,
      })),
    },
    {
      title: "应该尝试什么",
      rows: onlyTooSmall
        ? [
          { label: "选项1", value: `Every image here is under the size limit you set — lower "Ignore images smaller than" (now ${smallest} px), or set it to 0.` },
          { label: "选项2", value: 'Use PDF to Image to rasterise the pages themselves.' },
        ]
        : [
          { label: "选项1", value: 'Use PDF to Image to rasterise the pages themselves: the rendered page paints these images, fax encodings and all.' },
          { label: "选项2", value: 'Lower "Ignore images smaller than", or set it to 0, if a size limit is part of the story.' },
        ],
    },
  ];
}

/** A partial success says so: some images came out, others did not (E10, E13). */function unusableNote(skipped: readonly SkippedImage[]): string[] {
  if (skipped.length === 0) return [];
  const detail = skipped
    .slice(0, 6)
    .map((skip) => `${skip.name || `${skip.width}×${skip.height}`}: ${skip.reason}`)
    .join('; ');
  const rest = skipped.length > 6 ? `; and ${skipped.length - 6} more` : '';
  return [
    `${skipped.length} image(s) could not be read and are missing from the output — ${detail}${rest}.`,
  ];
}

function toMarkdownTable(table: DetectedTable): string {
  const header = table.headerRow ?? table.rows[0] ?? [];
  const body = table.headerRow ? table.rows : table.rows.slice(1);
  const line = (cells: string[]) => `| ${cells.map((cell) => cell.replace(/\|/g, '\\|')).join(' | ')} |`;
  if (header.length === 0) return line(body[0] ?? []);
  return [
    line(header),
    `|${header.map(() => ' --- ').join('|')}|`,
    ...body.map(line),
  ].join('\n');
}

