/**
 * PDF security tools.
 *
 * Encryption uses the `@maxwbh/pdf-lib` fork's crypto dictionary writer (RC4-40
 * and RC4-128, AES-128, AES-256, with the `/P` permissions dictionary). The
 * previous implementation called an RC4-128-only library and silently discarded
 * all seven permission checkboxes and the cipher selector.
 *
 * Nothing in this module claims a security property it has not checked: every
 * protect / unlock / restriction result is re-read through `core/guard` before
 * the tool describes it, so the message reports the cipher and permission bits
 * *the file carries*, not the ones the form asked for. Where the check shows a
 * compromise — a permission the file could not record, a rebuild that dropped
 * form fields, a signature that cannot be re-read — it is admitted in
 * `ToolResult.warnings` rather than buried in the log pane.
 */
import {
  PDFArray,
  PDFDict,
  PDFDocument,
  PDFName,
  PDFNumber,
  PDFRef,
  openPDF,
  savePDF,
  saveEncrypted,
} from '../core/doc';
import { looksEncrypted } from '../core/doc';
import type { PDFPermissions } from '../core/doc';
import type { PDFPage } from '../core/doc';
import { cropBox, formatPages, normaliseRotation } from '../core/pages';
import type { PageFrame } from '../core/tables';
import { viewerRectToUserSpace } from '../core/tables';
import { describeEncryption } from '../core/guard';
import { formatBytes, formatPdfDate, readInfo, readXmp, scrubMetadataText } from '../core/metadata';
import { listAttachments, removeAttachments } from '../core/attachments';
import { openRender } from '../core/render';
import type { ExtractedTextItem } from '../core/render';
import { annotationCount, listAnnotations } from '../core/annotations';
import { readOutline, writeOutline } from '../core/bookmarks';
import type { OutlineNode } from '../core/bookmarks';
import { pageContentStreams } from '../core/content';
import {
  booleanValue,
  fileValues,
  numberValue,
  objectValue,
  stringValue,
  type PdfToolDefinition,
} from './types';
import {
  downloadStem,
  inspectPdf,
  resolutionField,
  openInputs,
  pdfResult,
  filesResult,
  rebuildDocument,
  reportResult,
  type OpenedInput,
  type PdfInspection,
  type PdfPermissions,
} from './helpers';

/**
 * The `/P` flag bit positions, kept for the report text and for engines that
 * need the raw value (Table 25, ISO 32000-1).
 */
export const PERMISSION_BITS = {
  printLow: 3,
  modify: 4,
  copy: 5,
  annots: 6,
  forms: 9,
  accessibility: 10,
  assemble: 11,
  printHigh: 12,
} as const;

function permissionsObject(input: {
  printing: boolean;
  printLevel: string;
  modifying: boolean;
  copying: boolean;
  annotating: boolean;
  fillingForms: boolean;
  contentAccessibility: boolean;
  assembling: boolean;
}): PDFPermissions {
  return {
    printing: input.printing,
    printingHighQuality: input.printing && input.printLevel === 'high',
    modifying: input.modifying,
    copying: input.copying,
    annotating: input.annotating,
    fillingForms: input.fillingForms,
    contentAccessibility: input.contentAccessibility,
    documentAssembly: input.assembling,
  };
}

const PERMISSION_NOTES = [
  'Permissions are a request, not encryption of what you can see: the PDF standard lets a reader ignore the /P flags, and a tool that ignores the format (or a print-to-PDF pass) removes them entirely.',
  'The owner password is what unlocks the restrictions. Leave it blank and a random one is generated, so the limits hold but nobody can lift them by name later.',
];

/**
 * What this browser's engine does to the bytes, and what five outside readers
 * then say about them.
 *
 * `saveEncrypted` runs a real cipher: `core/crypto.ts:encryptDocument` derives
 * the revision-4 key from the password and AES-128-CBCs every stream (after the
 * flate) and every string on the way out, behind `/V 4 /R 4` with
 * `/CF /StdCF /CFM /AESV2 /Length 16` selected by `/StmF` and `/StrF`. The
 * reader table is measured file for file by `docs/research/protect-readers.py`
 * into `docs/research/protect-readers-*.log`: MuPDF reports the copy as
 * `Standard V4 R4 128-bit AES` and refuses it until the password is typed, qpdf
 * refuses an empty password and calls the syntax clean, pypdf extracts the
 * planted sentence with the password and none without, poppler now *asks* —
 * which it did not do for the `/None` gate this replaced — and Ghostscript
 * renders 3 pages of 3 with the secret and 0 pages without it.
 *
 * Before this, `protect` wrote a gate and no cipher, because the vendor's writer
 * never called its own `PDFSecurity.encryptStream`. poppler read those pages
 * without asking and Ghostscript collapsed three of them to one: a `/None` gate
 * is nothing for either to undo. Both now behave, which is the argument for
 * having run the cipher.
 */
const CIPHERTEXT_NOTE =
  'What lands in the file is AES-128 ciphertext: every page stream and every string is ciphered with the password you set (AES-128-CBC, `/V 4 /R 4`, crypt filter `/StdCF`), and MuPDF, qpdf, pypdf, poppler and Ghostscript all refuse the copy until it is typed. The strength is named because the file is written at it and read back at it — this app opens what this app protects.';

const CIPHER_STRENGTH_NOTE =
  'AES-128 is the only strength offered, because it is the only one this build has written and read back against an outside tool. What it opens is wider: RC4-128, AES-128 and AES-256 (`/R 6`, whose `/OE`, `/UE` and `/Perms` are derived here rather than refused) are decrypted when you open them and re-sealed at the strength they arrived at, so an AES-256 file edited here leaves as AES-256. AES-256 under another handler revision (`/R 5`, `/R 7`) is still refused by name. Offering a strength this app cannot prove it round-trips would turn a protected download into blank paper the moment you re-opened it here.';

const SCAN_ALTERNATIVE_NOTE =
  'A cipher hides the bytes, not the fact that a document exists: the page count, the object structure and any owner password remain readable. Where the pages themselves must carry no text layer at all, rasterise them first — PDF to Images, then Images to PDF — and protect the result; a scan is unreadable to a tool that never looks at a dictionary.';

/**
 * One spelling of the /P permission checkboxes, shared by both panels.
 *
 * Declared as two columns of four. The bar puts each `group` in its own column and
 * collapses to one truncated summary line, so eight checkboxes under one heading
 * is a column nobody finishes reading — and the summary never reaches the second
 * half of them.
 */
function permissionFields(whenSet?: (v: Record<string, unknown>) => boolean) {
  const shown = whenSet ? { when: whenSet } : {};
  return [
    { key: 'allowPrinting', label: "允许打印", type: 'toggle' as const, default: true, group: "读取和打印", help: "关闭仍打印自所有者密码；没有它的读者将被拒绝。", ...shown },
    {
      key: 'printLevel',
      label: "打印质量",
      type: 'select' as const,
      default: 'high',
      group: "读取和打印",
      options: [
        { value: 'high', label: "任何决议" },
        { value: 'low', label: "仅低分辨率(150 dpi)" },
      ],
      when: (v: Record<string, unknown>) => v.allowPrinting === true && (!whenSet || whenSet(v)),
      help: "低分辨率是大多数读者所尊重的提示；它不是下采样，因此全质量页面仍在文件中。",
    },
    { key: 'allowCopying', label: "允许复制文本和图像", type: 'toggle' as const, default: true, group: "读取和打印", help: "读者可以从文件中取出文本和图像——阻止合同被粘贴到其他地方的许可。", ...shown },
    { key: 'allowAccessibility', label: "允许屏幕阅读器", type: 'toggle' as const, default: true, group: "读取和打印", help: "提取辅助技术的文本。关闭此功能将使盲人读者无法使用该文档，仅此而已。", ...shown },
    { key: 'allowModifying', label: "允许修改", type: 'toggle' as const, default: true, group: "编辑权", help: "页面编辑、表单字段创建和文档主体的旋转。对于已经提交或签署的任何内容，请将其保留。", ...shown },
    { key: 'allowAnnotating', label: "允许评论", type: 'toggle' as const, default: true, group: "编辑权", help: "添加或改变注释、突出显示和表单字段外观(/Annotate标志)。", ...shown },
    { key: 'allowFillingForms', label: "允许填写表格", type: 'toggle' as const, default: true, group: "编辑权", help: "键入已经存在的字段(/QueryForms)。与添加评论分开：读者可以执行其中一项，而不执行另一项。", ...shown },
    { key: 'allowAssembling', label: "允许页面重组", type: 'toggle' as const, default: false, group: "编辑权", help: "插入、旋转、删除或提取页面以及编辑书签(/组合)。 Off 将一份归档文件保存为一个整体。", ...shown },
  ];
}

export const securityTools: PdfToolDefinition[] = [
  {
    id: 'protect',
    name: "保护PDF",
    description: "开放密码、所有者密码和/P权限，通过AES-128密文",
    icon: '🔐',
    category: 'security',
    // `aes`, `aes-256` and `rc4` stay searchable because that is what people type
    // when they have a locked PDF to make; the promise and the result say what the
    // file actually carries, which is AES-128 and not the other two.
    keywords: ['encrypt', 'encryption', 'aes', 'aes-256', 'rc4', 'cipher', 'password', 'restrict', 'lock'],
    outputSuffix: '_protected.pdf',
    promise: 'A copy that asks for your password before it opens, its pages ciphered in AES-128 and the permissions you ticked read back from the file.',
    actionLabel: "保护",
    notes: [CIPHERTEXT_NOTE, CIPHER_STRENGTH_NOTE, SCAN_ALTERNATIVE_NOTE, ...PERMISSION_NOTES],
    fields: [
      {
        key: 'mode',
        label: "保护类型",
        type: 'segmented',
        default: 'both',
        group: "密码",
        options: [
          { value: 'user', label: "开启密码" },
          { value: 'owner', label: "仅限权限" },
          { value: 'both', label: "两者" },
        ],
        help: "开放密码会阻止读取。仅限权限的密码允许任何人打开文件，但会限制在遵守该密码的阅读器中进行打印、复制和编辑。",
      },
      {
        key: 'userPassword',
        label: "开启密码",
        type: 'password',
        group: "密码",
        placeholder: "读者键入什么内容才能查看页面",
        when: (v) => v.mode !== 'owner',
        // A required field the user can actually find: the message lands on the box
        // it belongs to, which is the whole difference between three adjacent
        // password fields and one of them being clearly the one still needed.
        //
        // The predicate restates the `when` above rather than saying `true`, and
        // that is not decoration. A field that is required unconditionally can be
        // hidden by `when` while still blocking the run - a gate with nothing
        // behind it. Declaring the requirement with the same condition makes that
        // state unreachable: whenever this field disappears, it stops being a
        // requirement in the same breath.
        required: (v) => v.mode !== 'owner',
        missing: 'Enter the password readers must type to open this PDF.',
        help: "重命名或压缩文件不会在支持 /Encrypt 的阅读器中绕过此提示，并且页面已加密，因此忽略 /Encrypt 的工具会提升密文。",
      },
      {
        key: 'ownerPassword',
        label: "所有者密码",
        type: 'password',
        group: "密码",
        placeholder: "空白重用打开密码",
        // Only a permissions-only PDF needs this on its own; in every other mode
        // a blank owner password legitimately reuses the open one.
        required: (v) => stringValue(v, 'mode', 'both') === 'owner',
        missing: 'Enter an owner password — it is what unlocks the restrictions.',
        help: "留空以重复使用打开密码。如果两者都为空，则生成一个随机的。",
      },
      ...permissionFields(),
    ],
    validate(values) {
      const mode = stringValue(values, 'mode', 'both');
      const user = stringValue(values, 'userPassword');
      const owner = stringValue(values, 'ownerPassword');
      if (mode === 'both' && owner.length > 0 && user === owner) {
        return 'Use a different owner password, or choose "Open password" only. Sharing one password means anyone who can open the file can also remove the restrictions.';
      }
      return null;
    },
    async run(context) {
      const [input] = await openInputs(context);
      const mode = stringValue(context.values, 'mode', 'both');
      const user = mode === 'owner' ? '' : stringValue(context.values, 'userPassword');
      const owner = mode === 'user' ? '' : stringValue(context.values, 'ownerPassword') || user;
      const flags = permissionsObject({
        printing: booleanValue(context.values, 'allowPrinting', true),
        printLevel: stringValue(context.values, 'printLevel', 'high'),
        modifying: booleanValue(context.values, 'allowModifying', true),
        copying: booleanValue(context.values, 'allowCopying', true),
        annotating: booleanValue(context.values, 'allowAnnotating', true),
        fillingForms: booleanValue(context.values, 'allowFillingForms', true),
        contentAccessibility: booleanValue(context.values, 'allowAccessibility', true),
        assembling: booleanValue(context.values, 'allowAssembling'),
      });

      // A permissions-only file needs an empty user password so it still opens.
      const source = contentFingerprint(input.doc);
      const bytes = await saveEncrypted(input.doc, {
        userPassword: user,
        ownerPassword: owner || user,
        permissions: flags,
      });
      const { inspection, warnings } = await verifyProtection(bytes, input.name, flags, source, user === '', user || owner);
      // E5: the password that was just written has to be the one that opens it.
      const reopened = await inspectPdf(bytes, input.name, { password: user || owner });
      if (!reopened.passwordAccepted) {
        warnings.push(`The saved file did not open with the password that was just set${reopened.error ? `: ${reopened.message}` : '.'}`);
      }
      // One password for both jobs is the common case and the least protected
      // one, so it is named rather than left to the tooltip.
      if (user && !stringValue(context.values, 'ownerPassword')) {
        warnings.push('The open password is also the owner password here: anyone who can open the file can remove its restrictions. Set a separate owner password if that matters.');
      }
      // The gate is then checked from the outside, with the reader this app
      // draws its own previews with. Whatever the built-in engine recorded, a
      // reader that refuses the password is the fact the user needs (E5).
      const reader = user ? await probeReader(bytes, user) : await probeReader(bytes);
      const gateOpens = reader.verdict === 'opens';
      if (reader.verdict === 'unavailable' || reader.verdict === 'unreadable') {
        warnings.push(`No PDF reader could be started in this browser to re-check the saved file${reader.detail ? ` (${reader.detail})` : ''}, so only the built-in engine's own view of it was verified.`);
      } else if (user && reader.verdict !== 'opens') {
        warnings.push(`A PDF reader refused the password you set on the saved file (${reader.verdict === 'wrong-password' ? '“not correct”' : 'it still asks before it will open'}) while the built-in engine accepts it, so the gate is recorded but not portable. Open the copy in the reader your recipient uses before you rely on it.`);
      } else if (!user && reader.verdict !== 'opens') {
        warnings.push('No open password was set, yet a PDF reader will not open the saved file without one — check the copy before sending it.');
      }
      const pagesMatch = gateOpens && reader.pages === input.doc.getPageCount();
      if (gateOpens && !pagesMatch) {
        warnings.push(`The saved file shows ${reader.pages} page(s) to a PDF reader but ${input.doc.getPageCount()} to the engine that wrote it.`);
      }
      const how = user
        ? 'an open password'
        : 'restrictions only — no open password was set';
      return {
        kind: 'pdf',
        bytes,
        // The bytes were saved from `input.doc` a moment ago, so its page count
        // is the output's — the only moment this number is free.
        pages: input.doc.getPageCount(),
        message: `Protected with ${how}. The file is ciphered in AES-128 (/V 4 /R 4, crypt filter /StdCF) and carries the /P flags${user ? '' : ' with an empty open password, so it opens freely and is restricted rather than locked'}. As written to the file: ${permissionSentence(inspection.permissions ?? flags)}. ${
          gateOpens && user
            ? `A PDF reader opened the copy with that password and read ${reader.pages} page(s).`
            : gateOpens
              ? `A PDF reader opened the copy with no password and read ${reader.pages} page(s), with the restrictions above in force.`
              : 'Re-read by the built-in engine only; no independent reader could confirm the gate.'
        }`,
        warnings,
      };
    },
  },

  {
    id: 'unlock',
    // Removing protection is the whole point: the runner would otherwise
    // re-encrypt the output with the password that was just retired.
    stripsProtection: true,
    name: "解锁PDF",
    description: "删除密码以便可以自由打开文件",
    icon: '🔓',
    category: 'security',
    keywords: ['decrypt', 'remove password', 'open'],
    outputSuffix: '_unlocked.pdf',
    promise: 'The same pages, opening with no password asked — and a refusal to hand back a file that still carries one.',
    actionLabel: "解锁",
    notes: [
      'Protection lives in the trailer, so it is removed there: the page tree, the form fields, the comments, the bookmarks and any embedded files all stay where they were.',
      'A file that needs the password just to be read cannot lose it here: unlock it with the open password first. A restricted-but-openable one needs no password at all.',
      'If the fields, comments or bookmarks of the source do come out missing, the result names them; the page count is refused outright rather than reported.',
    ],
    fields: [{ key: 'password', label: "当前密码", type: 'password', group: "密码", placeholder: "该文件打开的密码", help: "用户或所有者密码有效。如果文件受限制但可读，则留空。" }],
    async run(context) {
      const [input] = await openInputs(context);
      const password = stringValue(context.values, 'password') || context.password || '';
      if (!input.inspection?.encrypted) {
        // Nothing to remove. Rebuilding the page tree for show would drop form
        // fields, comments and bookmarks from a file that never needed it.
        return {
          kind: 'pdf',
          bytes: input.bytes,
          pages: input.doc.getPageCount(),
          message: `"${input.name}" is not password protected — it already opens without one, so the file is returned unchanged.`,
          warnings: ['No /Encrypt entry was found, so there was no password to remove.'],
        };
      }
      const doc = await openForStripping(input, password);
      const removed = await stripProtectionFrom(input, doc, await sourceTextOf(input.bytes, password));
      return {
        kind: 'pdf',
        bytes: removed.bytes,
        pages: removed.pages,
        message: `Removed protection — the file opens without a password now: ${removed.pages} page(s), ${removed.contentKept ? 'page content verified' : 'page content re-read with differences'}, carrying ${structureSentence(removed.kept)}.`,
        warnings: removed.warnings,
      };
    },
  },

  {
    id: 'change-permissions',
    // Sets or clears the encryption dictionary itself, so the runner must not
    // second-guess the result: for `clear` the loss of protection is the point,
    // and for `set` the owner password is one this layer never sees.
    stripsProtection: true,
    name: "更改权限",
    description: "设置或清除打印、复制和编辑限制",
    icon: '🎛️',
    category: 'security',
    keywords: ['restrict', 'owner password', 'flags'],
    outputSuffix: '_permissions.pdf',
    promise: 'The printing, copying and editing limits on this file, rewritten — and the result reports what the saved file actually recorded.',
    actionLabel: "更改权限",
    notes: [
      'This tool writes the /P flags with no open password, so the document still opens: the pages are ciphered, but with a key anybody can derive from the empty user password. Use Protect to gate it with a password.',
      CIPHERTEXT_NOTE,
      ...PERMISSION_NOTES,
    ],
    fields: [
      { key: 'ownerPassword', label: "所有者密码", type: 'password', group: "密码", placeholder: "仅当文件已受保护时才需要", help: "当文件已受保护时需要。未受保护的文件上的空白表示生成随机文件。" },
      {
        key: 'action',
        label: "行动",
        type: 'segmented',
        default: 'set',
        group: "密码",
        options: [
          { value: 'set', label: "应用这些权限" },
          { value: 'clear', label: "删除所有限制" },
        ],
        help: "删除所有限制会删除加密字典，这是从该工具内部清除仅权限文件的唯一编辑。",
      },
      // No cipher control: AES-128 (`/CFM /AESV2`) is the one strength this build
      // both writes and reads back, so a selector here would offer names for the
      // same bytes rather than choices between different files.
      ...permissionFields((v) => v.action === 'set'),
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const owner = stringValue(context.values, 'ownerPassword') || context.password || '';
      const doc = await openForStripping(input, owner);
      const wasProtected = input.inspection?.encrypted === true;
      if (stringValue(context.values, 'action', 'set') === 'clear') {
        if (!wasProtected) {
          return {
            kind: 'pdf',
            bytes: input.bytes,
            pages: input.doc.getPageCount(),
            message: `"${input.name}" carries no encryption dictionary, so there were no restrictions to remove — the file is returned unchanged.`,
            warnings: ['Nothing to clear: this PDF is not protected.'],
          };
        }
        const cleared = await stripProtectionFrom(input, doc, await sourceTextOf(input.bytes, owner));
        return {
          kind: 'pdf',
          bytes: cleared.bytes,
          pages: cleared.pages,
          message: `All restrictions and the password were removed — ${cleared.pages} page(s) verified readable with no password, carrying ${structureSentence(cleared.kept)}.`,
          warnings: cleared.warnings,
        };
      }
      const flags = permissionsObject({
        printing: booleanValue(context.values, 'allowPrinting', true),
        // Read from the form, not assumed: this panel shows the same print-quality
        // choice `protect` does, and a recorded bit that ignores it is a
        // restriction the file does not carry.
        printLevel: stringValue(context.values, 'printLevel', 'high'),
        modifying: booleanValue(context.values, 'allowModifying', true),
        copying: booleanValue(context.values, 'allowCopying', true),
        annotating: booleanValue(context.values, 'allowAnnotating', true),
        fillingForms: booleanValue(context.values, 'allowFillingForms', true),
        contentAccessibility: booleanValue(context.values, 'allowAccessibility', true),
        assembling: booleanValue(context.values, 'allowAssembling'),
      });
      const source = contentFingerprint(doc);
      const bytes = await saveEncrypted(doc, {
        ownerPassword: owner || 'browsersnip',
        userPassword: '',
        permissions: flags,
      });
      const { inspection, warnings } = await verifyProtection(bytes, input.name, flags, source, true, '');
      if (wasProtected) {
        warnings.push('This replaced any protection the file already had. The copy opens without a password; only the owner password set here unlocks its restrictions.');
      }
      if (!owner) {
        warnings.push('No owner password was entered, so a random one was used: the restrictions can be changed again but not lifted by name.');
      }
      // The promise of this mode is that the file still opens: asked of a reader
      // rather than assumed from the empty user password we passed in.
      const reader = await probeReader(bytes);
      if (reader.verdict === 'unavailable' || reader.verdict === 'unreadable') {
        warnings.push(`No PDF reader could be started in this browser to re-open the saved copy${reader.detail ? ` (${reader.detail})` : ''}, so the restrictions were confirmed only with the built-in engine.`);
      } else if (reader.verdict !== 'opens') {
        warnings.push(`A PDF reader will not open the saved copy without a password (${reader.detail ?? reader.verdict}) even though no open password was set.`);
      }
      return {
        kind: 'pdf',
        bytes,
        pages: doc.getPageCount(),
        message: `Restrictions as recorded in the file: ${permissionSentence(inspection.permissions ?? flags)}. ${
          reader.verdict === 'opens'
            ? `A PDF reader opens it with no password: ${reader.pages} page(s) readable.`
            : 'The document is written to open without a password.'
        }`,
        warnings,
      };
    },
  },

  {
    id: 'remove-restrictions',
    // Removing protection is the whole point: the runner would otherwise
    // re-encrypt the output with the password that was just retired.
    stripsProtection: true,
    name: "移除限制",
    description: "清除锁定签名或受保护 PDF 的权限",
    icon: '🔓',
    category: 'security',
    keywords: ['unlock features', 'owner password', 'signed'],
    outputSuffix: '_unrestricted.pdf',
    promise: 'Every restriction lifted — the copy opens, prints, copies and edits without a password or an owner key.',
    actionLabel: "移除限制",
    notes: [
      'A signature in the source is broken by clearing its restrictions, whether the page tree is rebuilt or only the encryption entry is dropped: verify the signature first if the file is signed.',
      'A file with no /Encrypt entry is returned unchanged, and the result says so rather than claiming a removal.',
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const password = context.password ?? '';
      if (!input.inspection?.encrypted) {
        return {
          kind: 'pdf',
          bytes: input.bytes,
          pages: input.doc.getPageCount(),
          message: `"${input.name}" has no encryption dictionary, so nothing was restricting it — the file is returned unchanged.`,
          warnings: ['Nothing to clear: this PDF carries no /Encrypt entry, so a reader cannot be told to hold it back.'],
        };
      }
      const doc = await openForStripping(input, password);
      const cleared = await stripProtectionFrom(input, doc, await sourceTextOf(input.bytes, password));
      return {
        kind: 'pdf',
        bytes: cleared.bytes,
        pages: cleared.pages,
        message: `Restrictions cleared — ${cleared.pages} page(s) verified readable with no /Encrypt entry and no password needed, carrying ${structureSentence(cleared.kept)}.`,
        warnings: cleared.warnings,
      };
    },
  },

  {
    id: 'flatten-pdf',
    name: "拼合PDF",
    description: "使表单字段和注释成为页面的永久部分",
    icon: '🗜️',
    category: 'security',
    keywords: ['merge layers', 'non-editable', 'print ready'],
    outputSuffix: '_flattened.pdf',
    promise: 'Form answers baked into the page, and comments baked wherever they have an appearance to draw — the result counts what is still live.',
    actionLabel: "压平",
    notes: [
      'A flattened mark is page content: it can no longer be selected, moved, deleted or read as a comment by another reader.',
      'Baking copies what the annotation already draws — its appearance stream. A comment with no appearance of its own, or one flagged so no reader paints it, is left where it is and counted; nothing is rasterised here.',
      'Baking changes the bytes, so it breaks a signature that is already on the file — flatten first, then sign.',
    ],
    fields: [
      { key: 'forms', label: "展平表单字段", type: 'toggle', default: true, group: "烘烤什么", help: "字段值被绘制到页面中并且交互字段被移除，因此不能重新键入答案。" },
      { key: 'annotations', label: "压平评论", type: 'toggle', default: true, group: "烘烤什么", help: "高亮、墨迹、印记和文字注释成为页面内容并离开评论列表。关闭此选项以仅烘焙表单字段。" },
      { key: 'keepLinks', label: "保留可点击的链接", type: 'toggle', default: true, group: "烘烤什么", help: "“关闭”将链接自己的破折号烘焙到页面中并删除目标，这正是打印就绪或存档副本所需要的；读者绘制的链接而不是存储在文件中的链接不会留下任何痕迹。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { flattenAnnotations } = await import('../core/flatten');
      const { flattenForm } = await import('../core/forms');
      const bakeMarks = booleanValue(context.values, 'annotations', true);
      const bakeFields = booleanValue(context.values, 'forms', true);
      const keepLinks = booleanValue(context.values, 'keepLinks', true);
      const session = bakeMarks ? await openRender(input.bytes, { password: context.password }) : null;
      const warnings: string[] = [];
      // What the file carried before this run touched it. The counters say what
      // was baked; only the input says whether there was anything to bake.
      const had = await liveMarks(input.bytes);
      let bakedAnnotations = 0;
      let pagesTouched = 0;
      let skippedNoAppearance = 0;
      let skippedUnpainted = 0;
      let fieldsBaked = 0;
      try {
        const fields = bakeFields
          ? await flattenForm(input.doc, session ?? undefined)
          : { flattened: 0, needsRender: false };
        fieldsBaked = fields.flattened;
        if (fields.needsRender && fields.flattened === 0) {
          warnings.push('The form fields could not be baked from their appearances, so they are still interactive in the output.');
        }
        try {
          const outcome = await flattenAnnotations(input.doc, {
            kinds: bakeMarks ? undefined : ['Link'],
            keepLinks,
            onProgress: context.progress,
          });
          bakedAnnotations = outcome.flattened;
          pagesTouched = outcome.pagesTouched;
          skippedNoAppearance = outcome.skippedNoAppearance;
          skippedUnpainted = outcome.skippedUnpainted;
        } catch (error) {
          // An appearance the engine cannot draw is a comment left where it is,
          // not a flattened one: the run continues and the saved file is read
          // back, so the result reports what is really still live. The error's own
          // words are a library sentence (`Expected instance of PDFDict, but got
          // instance of PDFRawStream`), so they stay out of the card.
          void error;
          warnings.push(
            'The comments could not be drawn into the page content, so they were left as live annotations rather than reported as flattened.',
          );
        }
      } finally {
        await session?.destroy();
      }
      const bytes = await savePDF(input.doc);
      // The claim is read out of the output, not out of the counters: a field
      // that survived the bake is still typeable, whatever this run tallied.
      const saved = await liveMarks(bytes);
      if (skippedNoAppearance > 0) {
        warnings.push(`${skippedNoAppearance} annotation(s) had no appearance to draw and were left as live comments instead of being baked in.`);
      }
      if (skippedUnpainted > 0) {
        warnings.push(`${skippedUnpainted} annotation(s) carry a flag that keeps them off the page (Invisible, Hidden or NoView), so they were left as annotations rather than drawn in as ink.`);
      }
      if (saved.fields > 0) {
        warnings.push(bakeFields
          ? `${saved.fields} form field(s) are still interactive in the saved file, so their answers can still be retyped.`
          : `Form fields were left interactive, as asked: ${saved.fields} field(s) can still be retyped.`);
      }
      const liveMarksLeft = commentCount(saved, keepLinks);
      const liveLinksLeft = keepLinks ? 0 : saved.links;
      if (bakeMarks && liveMarksLeft > 0) {
        warnings.push(`${liveMarksLeft} comment(s) are still live annotations in the saved file rather than page content.`);
      }
      if (bakeMarks && liveLinksLeft > 0) {
        warnings.push(`${liveLinksLeft} link(s) carry no appearance of their own, so they were left clickable rather than baked.`);
      }
      if (!bakeMarks) {
        warnings.push(keepLinks
          ? 'Annotation flattening was off, so every comment was left live in the saved file.'
          : 'Annotation flattening was off, so comments were left live; only the links were baked into the page.');
      }
      // What the run was actually asked to bake, read off the input rather than
      // out of the counters: a file that carries nothing of the selected kind is a
      // different sentence from a file whose marks could not be drawn.
      const askedFor = (bakeMarks ? commentCount(had, keepLinks) : 0) + (bakeFields ? had.fields : 0);
      if (bakedAnnotations === 0 && fieldsBaked === 0) {
        warnings.push(askedFor === 0
          ? 'This PDF had nothing of the selected kind to flatten, so the file is effectively unchanged.'
          : `Nothing could be baked: the ${askedFor} item(s) of the selected kind in this file had no appearance this app can draw, so all of them are still live.`);
      }
      const stillLive = [
        ...(saved.fields > 0 ? [`${saved.fields} form field(s) still interactive`] : []),
        ...(liveMarksLeft > 0 ? [`${liveMarksLeft} comment(s) still live`] : []),
        ...(liveLinksLeft > 0 ? [`${liveLinksLeft} link(s) still clickable`] : []),
      ];
      return {
        kind: 'pdf',
        bytes,
        pages: input.doc.getPageCount(),
        // The two bakes are counted separately because only the annotation pass
        // reports pages: `flattenForm` answers with a field count, and a run whose
        // comments could not be drawn would otherwise read "into the content of
        // 0 page(s)" while two field values were in fact painted.
        message: bakeMarks
          ? `${bakedAnnotations} annotation(s) drawn into the content of ${pagesTouched} page(s) and ${fieldsBaked} form field(s) removed from the form${
              stillLive.length > 0 ? `; ${andList(stillLive)} in the saved file` : '; nothing of the selected kind is left live'
            }.`
          : `${fieldsBaked} form field(s) removed from the form and drawn into the page content${
              saved.fields > 0 ? `; ${saved.fields} field(s) are still interactive in the saved file` : ''
            }. Turn on flatten comments to bake the marks as well.`,
        warnings,
      };
    },
  },

  {
    id: 'redact-pdf',
    name: "编辑 PDF",
    description: "永久删除文本和区域——而不是它们上面的黑框",
    icon: '⬛',
    category: 'security',
    keywords: ['blackout', 'remove sensitive', 'censor', 'gdpr'],
    outputSuffix: '_redacted.pdf',
    surface: 'custom',
    promise: 'The words under each box deleted from the page, then painted over — select the black bar and there is nothing left to copy.',
    actionLabel: "编辑",
    notes: [
      'Redaction deletes glyphs from page content. With the metadata option on the same words are deleted from the document properties, the XMP packet and the bookmark titles as well; a comment’s own text and an embedded file’s bytes are never rewritten, and the result names whatever still holds the words.',
      'An area that lands inside an image is painted over rather than cut out: the pixels of a scanned page still contain the shape of what was there.',
    ],
    fields: [
      { key: 'fill', label: "密文颜色", type: 'color', default: '#000000', group: "标记", help: "在删除文本后绘制，因此只要文本从内容中消失，浅色就可以。" },
      { key: 'alsoMetadata', label: "还清除元数据和书签中的匹配文本", type: 'toggle', default: true, group: "标记", help: "关闭将单词保留在大纲和文档属性中，搜索仍然可以找到它。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const rects = objectValue<RedactionRegion[]>(context.values, 'regions') ?? [];
      if (rects.length === 0) throw new Error("首先在页面上绘制至少一个密文矩形。");
      const { applyRedactions } = await import('../core/redact');
      const fill = stringValue(context.values, 'fill', '#000000');
      // A box with no area removes no glyph, and counting it as redacted would
      // be the covered-but-selectable failure this tool exists to avoid (E13).
      const marked = rects.filter((r) => r.width > 0 && r.height > 0);
      const skipped = rects.length - marked.length;
      const pages = input.doc.getPages();
      const outOfRange = marked.filter((r) => !Number.isInteger(r.page) || r.page < 0 || r.page >= pages.length);
      if (outOfRange.length > 0) {
        throw new Error(
          `A redaction targets page ${(Number.isInteger(outOfRange[0].page) ? outOfRange[0].page : 0) + 1}, but this document has ${pages.length} page${pages.length === 1 ? '' : 's'}. Choose pages inside the document.`,
        );
      }
      // The marks arrive in the space the editor shows: the page as displayed,
      // origin top-left, `/Rotate` and an offset `/MediaBox` already folded in.
      // Page content is addressed in unrotated user space from the bottom-left,
      // so every mark is turned back through the same quarter-turn maths the
      // table and OCR paths use. Skipping that redacts the mirrored band: the
      // bar lands where the user drew it, the deleted words are someone else's.
      const placed = marked.map((region) => ({
        page: region.page,
        rect: viewerRectToUserSpace(
          { x: region.x, y: region.y, width: region.width, height: region.height },
          frameOf(pages[region.page]),
        ),
      }));
      // What a reader can lift out from under the marks beforehand. The claim
      // afterwards is only as good as this comparison, so a redaction that
      // painted a bar over still-selectable text cannot pass for one.
      const before = await readMarkedWords(input.bytes, context.password, marked);
      const outcome = applyRedactions(input.doc, placed, { fill });

      const warnings: string[] = [];
      if (skipped > 0) {
        warnings.push(`${skipped} marked area(s) had no width or height and were skipped — a redaction has to cover something to delete something.`);
      }
      if (outcome.rasterised) {
        warnings.push('At least one area fell inside an image, so the pixels there were painted over rather than cut out: text that is part of a scanned page survives as image data.');
      }
      if (!before.ok) {
        warnings.push(`No PDF reader could be started in this browser to re-read the text under the marked areas${before.detail ? ` (${before.detail})` : ''}, so the deletion was confirmed from the page content alone — spot-check the copy.`);
      }

      // The option promises the words go from the properties and the bookmarks
      // too, so they are deleted there and the result says where they were found.
      // Only words that sit under a mark and nowhere else on the page are taken
      // as redacted text: a term repeated in a heading the user did not mark is
      // not a secret.
      if (booleanValue(context.values, 'alsoMetadata', true) && before.unique.length > 0) {
        const scrubbed = scrubMetadataText(input.doc, before.unique);
        const titles = scrubOutlineTitles(input.doc, before.unique);
        if (scrubbed.properties.length > 0 || scrubbed.xmp || titles > 0) {
          const where = [
            ...(scrubbed.properties.length > 0
              ? [`${scrubbed.properties.length} document propert${scrubbed.properties.length === 1 ? 'y' : 'ies'}`]
              : []),
            ...(scrubbed.xmp ? ['the XMP packet'] : []),
            ...(titles > 0 ? [`${titles} bookmark title(s)`] : []),
          ];
          warnings.push(`Also deleted the redacted words from ${where.join(', ')} — a search that reads properties or the outline no longer finds them.`);
        }
      }
      const elsewhere = textHeldOutsidePageContent(input.doc);
      const clearEverywhere = booleanValue(context.values, 'alsoMetadata', true);
      if (clearEverywhere && elsewhere.length > 0) {
        warnings.push(`Redaction deletes text from page content and, with this option on, from the document properties and the outline — ${andList(elsewhere)} still hold other text this tool does not rewrite. Clear it with Remove Metadata if the file must not carry it at all.`);
      } else if (!clearEverywhere && before.unique.length > 0 && elsewhere.length > 0) {
        warnings.push(`"Also clear matching text from metadata and bookmarks" was off, so the redacted words stay in ${andList(elsewhere)} — a search that reads them still finds what the page no longer shows.`);
      }
      // Comment text and an enclosure's bytes are outside every store this tool
      // rewrites, and they are named separately from the generic caveat above:
      // one is the secret surviving, the other is merely other text (E20).
      const leaked = redactedWordsStillHeld(input.doc, before.unique);
      if (leaked.length > 0) {
        warnings.push(`${andList(leaked)} still hold the redacted words: this tool rewrites page content, the document properties and bookmark titles, not comment text or an embedded file's own bytes.`);
      }
      const bytes = await savePDF(input.doc);
      const after = before.ok ? await readMarkedWords(bytes, undefined, marked) : null;
      const survivors = after ? before.unique.filter((word) => after.all.includes(word)) : [];
      const destroyed = before.unique.length > 0 ? before.unique.filter((word) => !survivors.includes(word)) : [];
      if (survivors.length > 0) {
        warnings.push(`${survivors.length} word(s) under the marked areas are still extractable from the saved file: ${previewList(survivors)}. They are covered, not gone — widen the mark to cover the whole line, or convert that page to an image and redact the image.`);
      }
      return {
        kind: 'pdf',
        bytes,
        pages: input.doc.getPageCount(),
        message: outcome.removed === 0
          ? `Marked ${marked.length} area(s); none of them held text, so nothing was deleted — the fill was painted over the page only.`
          : survivors.length > 0
            ? `Deleted ${outcome.removed} text run(s) under ${marked.length} area(s) and painted the fill, but ${survivors.length} word(s) under those areas still extract from the saved file.`
            : `Redacted ${outcome.removed} text run(s) under ${marked.length} area(s) by deleting the glyphs themselves${
                after
                  ? destroyed.length > 0
                    ? `, then read the saved file back: none of the ${destroyed.length} word(s) that were under the marks still extracts.`
                    : '; no whole word under the marks could be located in the page text layer, so the deletion was confirmed from the page content alone.'
                  : '.'
              }`,
        warnings,
      };
    },
  },

  {
    id: 'compare-pdfs',
    name: "比较 PDF",
    description: "逐页比较两个 PDF 并导出第一个 PDF，标记它们的不同之处",
    icon: '🔍',
    category: 'security',
    keywords: ['diff', 'changes', 'versions', 'audit'],
    multiFile: true,
    minFiles: 2,
    maxFiles: 2,
    surface: 'custom',
    outputSuffix: '_comparison.pdf',
    // Despite the `_comparison.pdf` suffix this answers with a report and page
    // images: both come from pdf.js, which undoes RC4 and AES itself.
    readsOnly: true,
    // What the shipped page does, measured rather than remembered. It used to
    // promise "a page-by-page report of what differs, with a picture of each
    // changed area when you compare pixels", and three things contradicted that:
    // the route (`#/tool/compare-pdfs`) mounts the pane and this entry's own panel,
    // so the rail form whose Pixels / Text content / Both segment the sentence
    // leans on is never rendered — with two files loaded the only enabled buttons
    // on the deployed page were the panel's own “Generate comparison PDF”, “◂ Prev”
    // and “Next ▸”; the `run` below collects an overlay per differing page into
    // `images` and then returns without them, so no picture reaches anybody; and a
    // page that differs really does come back as one marked band across the sheet,
    // not as a cut-out of each area. The report this `run` writes is a true thing
    // to promise *when something calls it* — see `docs/TOOL-CAMPAIGN.md`, the
    // `compare-pdfs` row, for which side of that seam owns the decision.
    promise: 'Both pages side by side, the changed areas counted and located in the page’s own points, and a copy of the first file with those areas painted.',
    actionLabel: "比较",
    notes: [
      'Comparison works page against page by number, so a document with one page inserted reports every later page as different.',
      'A difference in rendering is not a difference in content: two files can hold the same text and still differ in pixels because of a font substitute.',
      'The numbers beside the pages are for the page in view; the marks are painted across every page both files have, and a page only one file has is reported and left out.',
    ],
    fields: [
      {
        key: 'mode',
        label: "比较",
        type: 'segmented',
        default: 'visual',
        group: "寻找什么",
        options: [
          { value: 'visual', label: "像素" },
          { value: 'text', label: "文字内容" },
          { value: 'both', label: "两者" },
        ],
        help: "像素捕获移动的标志或颜色变化；文本内容捕获渲染隐藏的改写句子。",
      },
      { key: 'sensitivity', label: "灵敏度", type: 'slider', default: 24, min: 1, max: 120, step: 1, integer: true, group: "寻找什么", when: (v) => v.mode !== 'text', help: "像素必须移动多远才算作不同。当抗锯齿使每个页面看起来都发生变化时提高它。" },
      resolutionField({ default: 150, min: 72, max: 300, group: "寻找什么", help: "两个页面在比较之前均以该分辨率呈现。较高的值可以发现更细微的差异，并且每页消耗更多的内存。" }),
    ],
    validate: (_v, { fileCount }) =>
      fileCount === 2 ? null : 'Add exactly two PDFs to compare.',
    async run(context) {
      const [a, b] = await openInputs(context);
      const mode = stringValue(context.values, 'mode', 'visual');
      const dpi = numberValue(context.values, 'dpi', 150);
      const sensitivity = numberValue(context.values, 'sensitivity', 24) / 255;
      const pages = Math.max(a.pageCount, b.pageCount);
      const rows: { label: string; value: string }[] = [];
      const images: { label: string; blob: Blob }[] = [];
      const textlessPages: number[] = [];
      /**
       * Pages this run can say differ, keyed by page number so a page examined twice
       * (`Both` mode reads its pixels and then its words) is counted once.
       *
       * The headline used to count rows matching `/differ|only in/`, and
       * “no visible difference” contains *differ* — so a pair that is the same file
       * twice was reported as “3 of 3 page(s) differ”, and a text change found in
       * `Both` mode was not counted at all. Reading the prose back was the bug;
       * every row now records its own verdict.
       */
      const differing = new Set<number>();
      const sa = await openRender(a.bytes, { password: context.password });
      const sb = await openRender(b.bytes, { password: context.password });
      try {
        for (let page = 1; page <= pages; page++) {
          if (page > a.pageCount) {
            rows.push({ label: `Page ${page}`, value: 'only in the second file' });
            differing.add(page);
            continue;
          }
          if (page > b.pageCount) {
            rows.push({ label: `Page ${page}`, value: 'only in the first file' });
            differing.add(page);
            continue;
          }
          if (mode !== 'visual' && mode !== 'both') {
            const ta = (await sa.textItems(page)).map((i) => i.str).join(' ');
            const tb = (await sb.textItems(page)).map((i) => i.str).join(' ');
            // Two pages with no text layer are not a match: they are two pages
            // this mode cannot read. Saying "identical text" over two different
            // scans told the user the documents agreed (E10, E13).
            const silent = ta.trim() === '' && tb.trim() === '';
            rows.push({
              label: `Page ${page}`,
              value: silent
                ? 'neither page has any extractable text — a scanned page: run OCR on both, or compare pixels'
                : ta === tb
                  ? 'identical text'
                  : `text differs (${diffWords(ta, tb)})`,
            });
            if (silent) textlessPages.push(page);
            else if (ta !== tb) differing.add(page);
            continue;
          }
          const scale = dpi / 72;
          const [ra, rb] = await Promise.all([sa.renderPage(page, scale), sb.renderPage(page, scale)]);
          // `renderPage` settles while pdf.js is still working; the pixels arrive on
          // `finished`. Reading both canvases a step early compared two sheets of
          // paper, which is how a page with a real change in it reported
          // “no visible difference”.
          await Promise.all([ra.finished, rb.finished]);
          const { percent, overlay } = visualDiff(ra.canvas, rb.canvas, sensitivity);
          ra.cancel();
          rb.cancel();
          rows.push({
            label: `Page ${page}`,
            value: percent < 0.05 ? 'no visible difference' : `${percent.toFixed(2)}% of pixels differ`,
          });
          if (percent >= 0.05) {
            differing.add(page);
            images.push({ label: `Page ${page}`, blob: await overlay });
          }
          if (mode === 'both') {
            const ta = (await sa.textItems(page)).map((i) => i.str).join(' ');
            const tb = (await sb.textItems(page)).map((i) => i.str).join(' ');
            if (ta !== tb) {
              differing.add(page);
              rows.push({ label: `Page ${page} text`, value: diffWords(ta, tb) });
            }
          }
          context.progress(page / pages, `Compared page ${page} of ${pages}`);
        }
      } finally {
        await sa.destroy();
        await sb.destroy();
      }
      const changed = differing.size;
      const message = textlessPages.length === pages
        ? `Nothing could be compared: none of the ${pages} page(s) carries a text layer. Run OCR on both files, or compare pixels.`
        : changed === 0
          ? `No differences found across ${pages} page(s).`
          : `${changed} of ${pages} page(s) differ.`;
      const warnings = textlessPages.length > 0 && textlessPages.length < pages
        ? [`${textlessPages.length} of ${pages} page(s) have no extractable text, so text mode could not compare them at all (pages ${textlessPages.join(', ')}). Run OCR, or compare pixels.`]
        : [];
      return { ...reportResult([{ title: "逐页比较", rows }], { message }), warnings };
    },
  },

  {
    id: 'view-metadata',
    name: "查看元数据",
    description: "检查PDF的属性、字体、图像和结构",
    icon: '🔎',
    category: 'security',
    keywords: ['properties', 'info', 'xmp', 'audit'],
    surface: 'none',
    outputSuffix: '_metadata.txt',
    readsOnly: true,
    promise: 'Everything the file says about itself — properties, XMP, fonts, images, protection and attachments — read back, not guessed.',
    actionLabel: "读取元数据",
    notes: [
      'The /P permission flags are reported as what the file records, not as a guarantee: a reader is free to ignore them.',
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { metadataReport } = await import('../core/metadata');
      const sections = metadataReport(input.doc, input.bytes);
      const inspection = input.inspection;
      // A file can be gated without being ciphered, and the two answers mean
      // different things to the person reading the report (E5). The cipher line is
      // the guard's own description of the dictionary — `AES-128 (crypt filter
      // /StdCF, revision 4)` — because a report that names a strength the file does
      // not carry is how this row began.
      const cipherSays = (): string => {
        if (!inspection?.encrypted) return 'no';
        if (!inspection.encryption) return inspection.algorithm ?? 'declared, but not readable from /V and /R';
        if (inspection.encryption.state === 'gate-only') {
          return 'no cipher — the file’s crypt filter is /None, so the pages are stored in the clear behind the password';
        }
        return describeEncryption(inspection.encryption);
      };
      const protection: { label: string; value: string }[] = [
        { label: "已加密", value: inspection?.encrypted ? 'yes' : 'no' },
      ];
      if (inspection?.encrypted) {
        protection.push({ label: "密码", value: cipherSays() });
        protection.push({
          label: "开启密码",
          // `/Encrypt` alone does not mean a password is asked for: a
          // permissions-only file hashes the empty user password, so it opens on
          // a double-click. Saying "required" there is contradicted by the file.
          value: inspection.passwordAccepted
            ? 'required, and the one supplied opened it'
            : inspection.opensWithEmptyPassword
              ? 'none — the user password is empty, so the file opens without one and only the restrictions apply'
              : 'required',
        });
        protection.push({
          label: "限制记录",
          value: inspection.permissions ? permissionSentence(inspection.permissions) : 'none — the file has no /P dictionary',
        });
        protection.push({ label: "原始/P值", value: inspection.permissions ? String(inspection.permissions.raw) : '—' });
        protection.push({
          label: "执行者",
          value: 'readers that honour the flags. Restrictions are a request, not encryption: treat them as polite, not private.',
        });
      }
      sections.push({ title: "保护", rows: protection });
      const attachments = listAttachments(input.doc);
      if (attachments.length > 0) {
        sections.push({
          title: "嵌入文件",
          rows: attachments.map((a) => ({ label: a.name, value: `${formatBytes(a.size)} · ${a.mimeType ?? 'unknown type'}` })),
        });
      }
      return {
        kind: 'report',
        sections,
        message: `Read ${sections.length} section(s) of document metadata.`,
        warnings: inspection?.encrypted
          ? [`This PDF is protected with ${cipherSays()}; the restrictions above are what its /P dictionary records, not a guarantee about a given reader.`]
          : [],
      };
    },
  },

  {
    id: 'edit-metadata',
    name: "编辑元数据",
    description: "更改标题、作者、主题、关键词和日期",
    icon: '🏷️',
    category: 'security',
    keywords: ['properties', 'document title', 'author', 'xmp'],
    outputSuffix: '_metadata.pdf',
    promise: 'The document properties you can see in a reader’s file panel, rewritten; the pages are left exactly as they were.',
    actionLabel: "保存属性",
    notes: [
      'Only the info dictionary and the XMP packet change — the page content is not re-written, so this cannot alter what the document says.',
      'Anything you leave blank keeps its current value. To erase a field rather than replace it, use Remove Metadata.',
    ],
    fields: [
      { key: 'title', label: "标题", type: 'text', group: "身份", placeholder: "阅读器在其选项卡中显示的名称", help: "这是大多数读者为窗口命名的——对于阅读者来说比文件名更明显。" },
      { key: 'author', label: "作者", type: 'text', group: "身份", help: "显示为文档的创建者并复制到 XMP dc:creator 字段中。" },
      { key: 'subject', label: "主题", type: 'text', group: "身份", placeholder: "一行关于该文档的内容", help: "一行描述；当数据包同步时，也会写入 XMP 描述字段。" },
      { key: 'keywords', label: "关键词", type: 'text', group: "身份", placeholder: "逗号，分隔", help: "逗号分隔的列表。桌面搜索对这些进行索引；读者通常只是显示它们。" },
      { key: 'docLanguage', label: "文档语言", type: 'text', group: "身份", placeholder: "en、de-DE、ja", help: "语言标签，而不是翻译。屏幕阅读器和拼写检查器从中选择他们的声音。" },
      { key: 'creator', label: "创建者应用程序", type: 'text', group: "出处", placeholder: "原始内容是什么产生的", help: "产生原始内容的应用程序，其与编写此PDF的应用程序不同。" },
      { key: 'producer', label: "制片人", type: 'text', group: "出处", placeholder: "此 PDF 的作者" , help: "命名是因为审计人员会寻找它：覆盖它会隐藏生成该文件的工具。" },
      { key: 'syncXmp', label: "将相同的值写入XMP数据包", type: 'toggle', default: true, group: "出处", help: "关闭使两个存储不一致，然后另一个读取器显示您未更改的值。" },
      { key: 'touchDates', label: "将修改日期设置为现在", type: 'toggle', default: true, group: "出处", help: "“关闭”保留原始 ModDate，这就是文件已根据该日期签名或归档时所需的内容。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { writeInfo, readInfo, writeXmp } = await import('../core/metadata');
      const current = readInfo(input.doc);
      const keywords = stringValue(context.values, 'keywords');
      const written: Parameters<typeof writeInfo>[1] = {
        title: stringValue(context.values, 'title') || current.title,
        author: stringValue(context.values, 'author') || current.author,
        subject: stringValue(context.values, 'subject') || current.subject,
        keywords: keywords ? keywords.split(',').map((k) => k.trim()).filter(Boolean).join(', ') : current.keywords,
        creator: stringValue(context.values, 'creator') || current.creator,
        producer: stringValue(context.values, 'producer') || current.producer,
        lang: stringValue(context.values, 'docLanguage') || current.lang,
      };
      // The control reads "Set the modification date to now", and `freshDates`
      // also overwrote CreationDate — a document's birthday is not this tool's to
      // change, and auditors read it.
      if (booleanValue(context.values, 'touchDates', true)) written.modDate = formatPdfDate(new Date());
      writeInfo(input.doc, written);
      if (booleanValue(context.values, 'syncXmp', true)) {
        const info = readInfo(input.doc);
        const previous = readXmp(input.doc);
        const subjects = (info.keywords ?? '')
          .split(/[,;]+/)
          .map((word) => word.trim())
          .filter(Boolean)
          .map((word) => `<rdf:li>${escapeXml(word)}</rdf:li>`)
          .join('');
        // A packet that declared PDF/A conformance keeps it: editing the
        // properties must not silently un-archive a filed document, and that
        // identity exists only in the XMP.
        const pdfa = previous?.pdfaPart !== undefined
          ? `<rdf:Description rdf:about="" xmlns:pdfaid="http://www.aiim.org/pdfa/ns/id/">` +
            `<pdfaid:part>${previous.pdfaPart}</pdfaid:part>` +
            (previous.pdfaConformance ? `<pdfaid:conformance>${escapeXml(previous.pdfaConformance)}</pdfaid:conformance>` : '') +
            `</rdf:Description>`
          : '';
        writeXmp(
          input.doc,
          `<?xpacket begin="\uFEFF" id="W5M0MpCehiHzreSzNTczkc9d"?>` +
          `<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999-02-22-rdf-syntax-ns#">` +
          `<rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:pdf="http://ns.adobe.com/pdf/1.3/" xmlns:xmp="http://ns.adobe.com/xap/1.0/">` +
          `<dc:title><rdf:Alt><rdf:li xml:lang="x-default">${escapeXml(info.title ?? '')}</rdf:li></rdf:Alt></dc:title>` +
          `<dc:creator><rdf:Seq><rdf:li>${escapeXml(info.author ?? '')}</rdf:li></rdf:Seq></dc:creator>` +
          `<dc:description><rdf:Alt><rdf:li xml:lang="x-default">${escapeXml(info.subject ?? '')}</rdf:li></rdf:Alt></dc:description>` +
          (subjects ? `<dc:subject><rdf:Seq>${subjects}</rdf:Seq></dc:subject>` : '') +
          (info.producer ? `<pdf:Producer>${escapeXml(info.producer)}</pdf:Producer>` : '') +
          (info.creator ? `<xmp:CreatorTool>${escapeXml(info.creator)}</xmp:CreatorTool>` : '') +
          `</rdf:Description>${pdfa}</rdf:RDF></x:xmpmeta><?xpacket end="w"?>`,
        );
      }
      return pdfResult(input.doc, { message: "更新了文档属性。" });
    },
  },

  {
    id: 'remove-metadata',
    name: "删除元数据",
    description: "剥离隐藏属性、XMP和可选嵌入数据",
    icon: '🕵️',
    category: 'security',
    keywords: ['privacy', 'clear properties', 'anonymise'],
    outputSuffix: '_stripped.pdf',
    promise: 'The hidden properties, XMP packet and reader settings taken out, with a list of what was actually found and removed.',
    actionLabel: "移除元数据",
    notes: [
      'Metadata is not the page. Words still sit in the content streams, bookmarks and annotations of a document, and text hidden under a redaction bar is removed by Redact PDF, not here.',
      'A store that was already empty is reported as untouched rather than counted as removed.',
    ],
    fields: [
      { key: 'info', label: "文档信息字典", type: 'toggle', default: true, group: "要删除什么", help: "标题、作者、主题、关键词、制作者和日期。这是读者在“属性”下显示的面板。" },
      { key: 'xmp', label: "XMP元数据流", type: 'toggle', default: true, group: "要删除什么", help: "相同事实的XML副本，加上一些应用程序嵌入的历史记录。删除一个商店并保留另一个商店是“清理后的”文件仍然保留您的名字的方式。" },
      { key: 'attachments', label: "嵌入文件", type: 'toggle', default: false, group: "要删除什么", help: "默认关闭，因为这些是有效负载，而不是家具：附件可以是合同本身。" },
      { key: 'readerSettings', label: "上次打开的页面和缩放存储器", type: 'toggle', default: true, group: "要删除什么", help: "文档在哪个页面和缩放比例下打开，以及是否显示标题或文件名。他们揭示了该文件的使用方式。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { stripInfo, stripXmp } = await import('../core/metadata');
      const done: string[] = [];
      if (booleanValue(context.values, 'info', true)) {
        // Measured once: calling `stripInfo` a second time just to pick the
        // plural would report 0 properties because the first call already
        // removed them. A zero count is not something that was removed, so it
        // is not added to the list either.
        const cleared = stripInfo(input.doc);
        if (cleared > 0) done.push(`${cleared} propert${cleared === 1 ? 'y' : 'ies'}`);
      }
      if (booleanValue(context.values, 'xmp', true) && stripXmp(input.doc)) done.push('XMP packet');
      if (booleanValue(context.values, 'attachments')) {
        const names = listAttachments(input.doc).map((a) => a.name);
        if (names.length) {
          removeAttachments(input.doc, names);
          done.push(`${names.length} embedded file(s)`);
        }
      }
      if (booleanValue(context.values, 'readerSettings', true)) {
        // Only claim the keys that were really there: this used to report
        // "reader settings" on a document that had none of them.
        const cleared: string[] = [];
        if (input.doc.catalog.delete(PDFName.of('PageMode'))) cleared.push('PageMode');
        const viewerPrefs = input.doc.catalog.get(PDFName.of('ViewerPreferences'));
        if (viewerPrefs instanceof PDFDict && viewerPrefs.delete(PDFName.of('DisplayDocTitle'))) {
          cleared.push('ViewerPreferences/DisplayDocTitle');
        }
        if (input.doc.catalog.delete(PDFName.of('Perms'))) cleared.push('Perms');
        if (cleared.length > 0) done.push(`reader settings (${cleared.join(', ')})`);
      }
      const bytes = await savePDF(input.doc);
      return {
        kind: 'pdf',
        bytes,
        pages: input.doc.getPageCount(),
        message: done.length
          ? `Removed ${done.join(', ')}.`
          : 'Nothing was removed: the selected stores were already empty in this PDF.',
        warnings: done.length
          ? []
          : ['This PDF held no document info, XMP packet, embedded files or reader settings of the kinds selected, so the output is the same document.'],
      };
    },
  },

  {
    id: 'add-attachments',
    name: "添加附件",
    description: "在 PDF 中嵌入任何文件，例如电子邮件附件",
    icon: '📎',
    category: 'security',
    keywords: ['attach file', 'embed', 'package'],
    outputSuffix: '_attached.pdf',
    promise: 'The files carried inside the PDF itself, so the document and its enclosures travel as one attachment.',
    actionLabel: "附加文件",
    notes: [
      'Nothing is uploaded: the bytes are stored inside the PDF, which grows by roughly the size of every file you add.',
      'An attachment is only as useful as the reader showing it. A viewer without an attachments panel — including a printout — gives no sign the files are there.',
    ],
    fields: [
      { key: 'files', label: "要附加的文件", type: 'file', accept: '*/*', multiple: true, maxFiles: 20, group: "文件", help: "最多 20 个任何类型的文件。它们是整体嵌入的，而不是引用的，因此 PDF 是您需要发送的唯一文件。" },
      { key: 'description', label: "与每个文件一起存储的注释", type: 'text', group: "文件", placeholder: "这个外壳是什么", help: "与本次运行中的每个文件一起存储，因此一个注释无法描述三个不同的外壳。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { addAttachments } = await import('../core/attachments');
      const extras = fileValues(context.values, 'files');
      if (extras.length === 0) throw new Error("选择至少一个要附加的文件。");
      const description = stringValue(context.values, 'description');
      const wanted = extras.map((f) => ({
        name: f.name,
        bytes: f.bytes,
        mimeType: f.mimeType,
        description: description || undefined,
      }));
      const before = new Map(listAttachments(input.doc).map((a) => [a.name, a]));
      // `addAttachments` returns how many the document carries afterwards, which
      // is not how many this run embedded: a document with one attachment and one
      // new file did not gain two. The names are diffed instead, and the saved
      // bytes are asked what they really carry.
      const had = before.size;
      await addAttachments(input.doc, wanted);
      const requested = [...new Set(wanted.map((file) => file.name))];
      const replaced = requested.filter((name) => before.has(name));
      const added = requested.filter((name) => !before.has(name));
      const collided = wanted.length - requested.length;
      const bytes = await savePDF(input.doc);
      const carried = listAttachments(await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false }));
      const warnings: string[] = [];
      if (collided > 0) {
        warnings.push(`${collided} file(s) shared a name with another in this run, and a PDF stores one attachment per name: only the last copy of each is embedded.`);
      }
      const missing = requested.filter((name) => !carried.some((a) => a.name === name));
      if (missing.length > 0) {
        warnings.push(`${missing.map((name) => `"${name}"`).join(', ')} is not in the saved file, so it is not among the attachments the recipient will see.`);
      }
      return {
        kind: 'pdf' as const,
        bytes,
        pages: input.doc.getPageCount(),
        message: `Embedded ${added.length} new file(s)${replaced.length > 0 ? ` and replaced ${replaced.length} already stored under the same name(s)` : ''}. The document now carries ${carried.length} attachment(s)${had > 0 ? `, up from ${had}` : ''}. Readers with an attachments panel will list them.`,
        warnings,
      };
    },
  },

  {
    id: 'extract-attachments',
    name: "提取附件",
    description: "从PDF中提取每个嵌入文件",
    icon: '📤',
    category: 'security',
    keywords: ['unpack', 'embedded files', 'unbundle'],
    surface: 'none',
    outputSuffix: '_attachments.zip',
    readsOnly: true,
    promise: 'Every embedded file out of the PDF, each under its own name — one file when there is one, a ZIP when there are several.',
    actionLabel: "提取附件",
    notes: [
      'A PDF with no embedded files returns a report saying so rather than an empty archive.',
      'The files are written out byte for byte, so a protected document still opens and a corrupted enclosure stays corrupted.',
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const found = listAttachments(input.doc);
      if (found.length === 0) {
        return reportResult([{ title: "附件", rows: [{ label: "结果", value: 'This PDF contains no embedded files.' }] }], {
          message: "未找到附件。",
        });
      }
      const { createZip } = await import('../core/archive');
      const single = found.length === 1
        ? new Blob([found[0].bytes as BlobPart], { type: found[0].mimeType ?? 'application/octet-stream' })
        : await createZip(
          found.map((a) => ({ name: a.filename ?? a.name, data: a.bytes })),
          { comment: `Extracted from ${input.name}` },
        );
      return filesResult(
        [{ blob: single, name: found.length === 1 ? (found[0].filename ?? found[0].name) : `${downloadStem(input.name)}-attachments.zip` }],
        `Found ${found.length} embedded file(s): ${found.map((a) => `${a.name} (${formatBytes(a.size)})`).join(', ')}.`,
      );
    },
  },

  {
    id: 'edit-attachments',
    name: "编辑附件",
    description: "列出和删除PDF中嵌入的文件",
    icon: '✂️',
    category: 'security',
    keywords: ['remove attachment', 'manage embedded', 'package', 'enclosed files'],
    outputSuffix: '_attachments.pdf',
    promise: 'The attachments listed with their sizes, and only the ones you name deleted — a name that is not there is reported, not ignored.',
    actionLabel: "删除附件",
    notes: [
      'Deleting an attachment is permanent in the output copy: an enclosure that was the only version of that file is gone.',
    ],
    fields: [
      { key: 'remove', label: "要删除的名称", type: 'textarea', group: "附件", placeholder: "每行一个附件名称", help: "从此工具首先显示的列表中复制名称。将框留空是要求查看，而不是删除。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { removeAttachments } = await import('../core/attachments');
      const existing = listAttachments(input.doc);
      const wanted = stringValue(context.values, 'remove')
        .split(/[\n,]+/)
        .map((s) => s.trim())
        .filter(Boolean);
      if (existing.length === 0) {
        throw new Error("此PDF没有要编辑的附件。");
      }
      if (wanted.length === 0) {
        return reportResult(
          [{ title: "附件", rows: existing.map((a) => ({ label: a.name, value: formatBytes(a.size) })) }],
          { message: `This PDF carries ${existing.length} attachment(s). List the names you want removed.` },
        );
      }
      const removed = removeAttachments(input.doc, wanted);
      const missing = wanted.filter((name) => !existing.some((a) => a.name === name || a.filename === name));
      const warnings = missing.length
        ? [`${missing.map((name) => `"${name}"`).join(', ')} ${missing.length === 1 ? 'is' : 'are'} not embedded in this PDF, so nothing was removed for ${missing.length === 1 ? 'it' : 'them'}.`]
        : [];
      if (removed === 0 && wanted.length > 0) {
        warnings.push('None of the names you listed matched an attachment, so the document is unchanged.');
      }
      const bytes = await savePDF(input.doc);
      return {
        kind: 'pdf',
        bytes,
        pages: input.doc.getPageCount(),
        message: `Removed ${removed} of ${wanted.length} requested attachment(s). Remaining: ${existing.length - removed}.`,
        warnings,
      };
    },
  },

  {
    id: 'digital-sign-pdf',
    name: "数字签名",
    description: "使用 X.509 证书进行签名，以便检测到篡改",
    icon: '🖋️',
    category: 'security',
    keywords: ['pkcs7', 'certificate', 'signature', 'pades'],
    outputSuffix: '_signed.pdf',
    promise: 'A signature that covers the bytes: change anything afterwards and validation says so. The private key never leaves this tab.',
    actionLabel: "标志",
    notes: [
      'Signing proves the document has not changed since. It does not prove the signer is who they claim: that needs a certificate issued by an authority the other side already trusts.',
      'A signature seals the document. Any later edit — flattening, timestamping, even opening and re-saving in some tools — invalidates it, so sign last.',
      'The signature is created in your browser from your own certificate. Certificate revocation checking needs a network connection; everything else is local.',
    ],
    fields: [
      { key: 'certificate', label: "证书（PEM 或 P12）", type: 'file', accept: '.pem,.crt,.cer,.p12,.pfx', group: "您的证书", required: true, help: "公共密钥的一半，加上私钥（当它是 .p12/.pfx 捆绑包时）。不会上传任何内容，之后也不会存储任何内容。" },
      { key: 'privateKey', label: "私钥（PEM）", type: 'file', accept: '.pem,.key', group: "您的证书", when: (v) => v.certKind !== 'p12', help: "当证书是裸 .pem 时需要。密钥被读取一次、签名，然后丢弃。" },
      { key: 'passphrase', label: "密钥/PKCS#12 密码", type: 'password', group: "您的证书", placeholder: "仅当密钥或捆绑包被加密时", help: "仅当密钥或包被加密时才需要。它仅用于签名一次，然后就被丢弃。" },
      { key: 'reason', label: "原因", type: 'text', default: 'I approve this document', half: true, group: "签名内容", help: "存储在签名内，因此它是验证器报告内容的一部分，并且以后不能悄悄地改写。" },
      { key: 'location', label: "位置", type: 'text', half: true, group: "签名内容", placeholder: "您在哪里签名", help: "存储在签名内，因此它是验证器报告内容的一部分。" },
      { key: 'contact', label: "联系方式", type: 'text', group: "签名内容", placeholder: "如何联系您了解此事", help: "收件人如何就该签名联系您。读者将其显示在签名面板中。" },
      { key: 'visible', label: "显示可见的签名块", type: 'toggle', default: true, group: "页面上的标记", help: "关闭以不可见的方式签署文档：它仍然有效，但没有人可以看到它已被签署。" },
      { key: 'page', label: "签名页", type: 'number', default: 1, min: 1, max: 5000, step: 1, integer: true, group: "页面上的标记", when: (v) => v.visible === true, help: "计入您投递的文件中；在使用密钥之前，超过末尾的页面将被拒绝。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { signDocument } = await import('../core/signature');
      const cert = fileValues(context.values, 'certificate')[0];
      const key = fileValues(context.values, 'privateKey')[0];
      if (!cert) throw new Error("选择您想要用来签名的证书。");
      // E6: a visible block on page 9 of a 3-page PDF is a mistake worth naming
      // before the signature is written somewhere unexpected.
      const total = input.doc.getPageCount();
      const page = numberValue(context.values, 'page', 1);
      if (booleanValue(context.values, 'visible', true) && (!Number.isInteger(page) || page < 1 || page > total)) {
        throw new Error(`The signature page must be between 1 and ${total} — this document has ${total} page${total === 1 ? '' : 's'}.`);
      }
      const result = await signDocument(input.doc, {
        certificate: cert.bytes,
        privateKey: key?.bytes,
        passphrase: stringValue(context.values, 'passphrase'),
        reason: stringValue(context.values, 'reason'),
        location: stringValue(context.values, 'location'),
        contact: stringValue(context.values, 'contact'),
        visible: booleanValue(context.values, 'visible', true),
        page: page - 1,
      });
      // A signature nobody can re-read signs nothing, so the bytes are checked
      // back before the tool claims the document is signed.
      const warnings: string[] = [];
      const { readSignatures } = await import('../core/signature');
      let readBack: Awaited<ReturnType<typeof readSignatures>> = [];
      try {
        readBack = await readSignatures(result.bytes);
      } catch (error) {
        warnings.push(`The signature was written but could not be read back from the saved file (${error instanceof Error ? error.message : 'unknown reason'}). Run Validate Signature on the output before relying on it.`);
      }
      const mine = readBack[readBack.length - 1];
      if (readBack.length > 0 && mine && !mine.digestMatches) {
        warnings.push('The signature does not verify against the file it was just written into, so treat this copy as unsigned.');
      }
      if (readBack.length > 0 && mine?.error) {
        warnings.push(`The saved signature could not be parsed: ${mine.error}`);
      }
      return {
        kind: 'pdf',
        bytes: result.bytes,
        // `signDocument` saves this same document and fills the `/ByteRange`
        // placeholder in place: the signature adds a field, never a page.
        pages: input.doc.getPageCount(),
        message: `Signed as ${result.signer}${result.hash ? ` using ${result.hash}` : ''}. The signature covers ${formatBytes(result.contentsLength)} of the file${readBack.length > 0 && mine?.digestMatches ? ' and verifies against it' : ''}.`,
        warnings,
      };
    },
  },

  {
    id: 'validate-signature-pdf',
    name: "验证签名",
    description: "检查数字签名是否完整以及签名者是谁",
    icon: '✅',
    category: 'security',
    keywords: ['verify', 'integrity', 'certificate details'],
    surface: 'none',
    outputSuffix: '_signature-report.txt',
    readsOnly: true,
    promise: 'Whether each signature still matches these bytes, who signed, and what an empty signature field really means.',
    actionLabel: "验证签名",
    notes: [
      'Intact means the signed bytes are unchanged. The certificate chain is not validated and revocation cannot be checked offline, so this does not tell you the signer is trusted.',
      'An empty signature field proves nothing: it is a box somebody prepared and never signed.',
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { readSignatures } = await import('../core/signature');
      const fields = signatureFields(input.doc);
      if (fields.length === 0) {
        return reportResult(
          [{ title: "数字签名", rows: [{ label: "结果", value: 'This document has no digital signature field — nobody has signed it, so nothing proves these bytes are unchanged.' }] }],
          { message: "未找到数字签名。" },
        );
      }
      let signatures: Awaited<ReturnType<typeof readSignatures>> = [];
      let readFailure: string | null = null;
      try {
        signatures = await readSignatures(input.bytes);
      } catch (error) {
        readFailure = error instanceof Error ? error.message : String(error);
      }
      if (signatures.length === 0) {
        return {
          kind: 'report',
          sections: [{
            title: "数字签名",
            rows: [{
              label: "结果",
              value: readFailure
                ? `The signature field exists but could not be read: ${readFailure}`
                : `There ${fields.length === 1 ? 'is' : 'are'} ${fields.length} signature field(s) with no signature value in them — the document was set up for signing but never signed.`,
            }],
          }],
          message: "签名字段为空。",
          warnings: fields.length > 0 && readFailure === null
            ? ['A signature field with no value restricts nothing and proves nothing; the document is unsigned.']
            : [],
        };
      }
      const now = Date.now();
      const broken = signatures.filter((signature) => !signature.error && !signature.digestMatches).length;
      const unreadable = signatures.filter((signature) => signature.error).length;
      const intact = signatures.length - broken - unreadable;
      const warnings: string[] = [];
      if (fields.length > signatures.length) {
        warnings.push(`${fields.length - signatures.length} signature field(s) sit in page annotations and are not registered in the document form, so they could not be verified.`);
      }
      if (intact > 0) {
        warnings.push('Intact means the bytes the signature covers have not changed. The certificate chain is not validated and revocation cannot be checked in the browser, so this does not confirm the signer is trusted.');
      }
      const expired = signatures.filter((signature) => signature.notAfter && signature.notAfter.getTime() < now).length;
      if (expired > 0) {
        warnings.push(`${expired} signature(s) used a certificate that has since passed its expiry date. That does not undo the signature — it was valid when applied — but the signing identity can no longer be confirmed from the certificate alone.`);
      }
      return {
        kind: 'report',
        sections: signatures.map((signature, index) => ({
          title: `Signature ${index + 1}${signature.fieldName ? ` — ${signature.fieldName}` : ''}`,
          rows: [
            {
              label: "字节范围完好无损",
              value: signature.error
                ? `Not checked — ${signature.error}`
                : signature.digestMatches
                  ? 'Yes — the document has not changed since signing'
                  : 'No — the file was modified after signing',
            },
            { label: "签名者", value: signature.signer ?? 'unknown' },
            { label: "发布者", value: signature.issuer ?? 'unknown' },
            { label: "签署于", value: signature.signedAt?.toISOString() ?? 'not recorded' },
            { label: "摘要", value: signature.digestAlgorithm ?? 'unknown' },
            { label: "证书有效期自", value: signature.notBefore?.toISOString() ?? 'unknown' },
            { label: "证书有效期至", value: signature.notAfter?.toISOString() ?? 'unknown' },
            { label: "撤销", value: 'not checked offline — a browser has no OCSP responder access for this chain' },
          ],
        })),
        message: broken === 0 && unreadable === 0
          ? `All ${signatures.length} signature(s) verify: the bytes they cover are unchanged since signing.`
          : `${intact} of ${signatures.length} signature(s) verify; ${broken} were broken by an edit after signing${unreadable > 0 ? `; ${unreadable} could not be read at all` : ''}.`,
        warnings,
      };
    },
  },

  {
    id: 'timestamp-pdf',
    name: "时间戳 PDF",
    description: "将RFC 3161可信时间戳添加到签名",
    icon: '🕐',
    category: 'security',
    keywords: ['tsa', 'rfc3161', 'proof of existence'],
    outputSuffix: '_timestamped.pdf',
    promise: 'A third-party stamp proving the signature existed at a stated moment, so it outlives the certificate that made it.',
    actionLabel: "添加时间戳",
    notes: [
      'The timestamp covers the signature, not the whole document, and the authority address is the only thing sent over the network: a digest of the signature, never the pages.',
      'This tool refuses an unsigned file rather than producing a timestamp on nothing.',
    ],
    fields: [
      {
        key: 'tsa',
        label: "时间戳权威URL",
        type: 'text',
        default: 'http://timestamp.digicert.com',
        group: "权威",
        required: true,
        pattern: '^https?://',
        help: "唯一需要网络的步骤：时间戳令牌来自受信任的第三方。最好使用 https 地址，因为摘要会传输。",
      },
      { key: 'fieldName', label: "要盖章的签名字段", type: 'text', group: "权威", placeholder: "唯一的签名，如果留空", help: "当一份文件带有多个签名且仅应在其中一个签名时需要盖章。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const { timestampDocument } = await import('../core/signature');
      // `core/signature` looks for a `/Contents` key to find the signature, and
      // every page has a `/Contents` — so an unsigned file used to come back
      // complaining about its PKCS#7 instead of saying it was never signed.
      const signatureCount = signatureFields(input.doc).length;
      if (signatureCount === 0) {
        throw new Error("此 PDF 没有时间戳的数字签名。首先对其运行数字签名，然后为签名文件添加时间戳。");
      }
      const tsaUrl = stringValue(context.values, 'tsa', 'http://timestamp.digicert.com');
      let result: Awaited<ReturnType<typeof timestampDocument>>;
      try {
        result = await timestampDocument(input.doc, {
          tsaUrl,
          fieldName: stringValue(context.values, 'fieldName') || undefined,
        });
      } catch (error) {
        throw timestampFailure(error, tsaUrl, signatureCount);
      }
      return {
        kind: 'pdf',
        bytes: result.bytes,
        pages: input.doc.getPageCount(),
        message: `Timestamped at ${result.attestedAt.toISOString()} by ${result.authority}.`,
        warnings: [`The timestamp covers the signature, not the document: it proves the signature existed at ${result.attestedAt.toISOString()}, and ${tsaUrl} is the one address this app sends a digest to.`],
      };
    },
  },
];

// ── helpers ─────────────────────────────────────────────────────────────────

/** Region captured by the redaction surface, in the space of the *displayed* page. */
interface RedactionRegion {
  /** 0-based page index. */
  page: number;
  /**
   * Top-left corner in points on the page as the editor shows it: origin
   * top-left, `/Rotate` applied, so on a quarter-turned sheet `width` runs
   * along the displayed long edge. `redact-pdf` turns each mark back into
   * unrotated user space before deleting anything.
   */
  x: number;
  y: number;
  width: number;
  height: number;
}

/* ------------------------------------------------------------------ *
 * Redaction proof — read the words back, do not infer them            *
 * ------------------------------------------------------------------ */

/** The frame a page's displayed coordinates are measured against. */
function frameOf(page: PDFPage): PageFrame {
  const box = cropBox(page);
  return {
    x0: box.x,
    y0: box.y,
    width: box.width,
    height: box.height,
    rotation: normaliseRotation(page.getRotation().angle),
  };
}

/** One word, with its box in the displayed page's space. */
interface MarkWord {
  word: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * The words of one extracted run, with a box each.
 *
 * pdf.js hands back a run per styling change, which is often a whole line. A
 * run is split on whitespace and its box shared out by character position: the
 * mark/word overlap only decides which words are *candidates* for verification,
 * so an approximate box widens the sample without ever letting a redaction pass
 * a word it did not delete.
 */
function wordsOfRun(item: ExtractedTextItem): MarkWord[] {
  const text = item.str ?? '';
  if (text.trim() === '') return [];
  const boxWidth = Math.abs(item.w) || 1;
  const height = Math.abs(item.h) || 1;
  const out: MarkWord[] = [];
  const pattern = /\S+/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(text)) !== null) {
    const start = match.index / text.length;
    const end = (match.index + match[0].length) / text.length;
    out.push({
      word: match[0],
      x: item.x + start * boxWidth,
      y: item.y,
      width: (end - start) * boxWidth,
      height,
    });
  }
  return out;
}

/** Whether the centre of a word box falls inside one marked area. */
function underMark(word: MarkWord, marks: { page: number; x: number; y: number; width: number; height: number }[], page: number): boolean {
  const cx = word.x + word.width / 2;
  const cy = word.y + word.height / 2;
  return marks.some((mark) =>
    mark.page === page
    && cx >= Math.min(mark.x, mark.x + mark.width) && cx <= Math.max(mark.x, mark.x + mark.width)
    && cy >= Math.min(mark.y, mark.y + mark.height) && cy <= Math.max(mark.y, mark.y + mark.height),
  );
}

/**
 * What a PDF reader can still extract from the pages the marks cover.
 *
 * `unique` is the useful half: words that sit under a mark and nowhere else on
 * that page. Those are the words the user meant to destroy, so their presence in
 * the saved file is a redaction that only looks like one, and their absence is
 * the proof the fill is covering deleted text rather than hiding live text.
 */
async function readMarkedWords(
  bytes: Uint8Array,
  password: string | undefined,
  marks: RedactionRegion[],
): Promise<{ ok: boolean; detail?: string; all: string[]; under: string[]; unique: string[] }> {
  const empty = { ok: false, detail: undefined as string | undefined, all: [] as string[], under: [] as string[], unique: [] as string[] };
  if (marks.length === 0) return { ...empty, ok: true };
  let session;
  try {
    session = await openRender(bytes, password ? { password } : {});
  } catch (error) {
    return { ...empty, detail: error instanceof Error ? error.message : String(error) };
  }
  try {
    const all = new Set<string>();
    const under = new Set<string>();
    const elsewhere = new Set<string>();
    const pages = [...new Set(marks.map((mark) => mark.page))];
    for (const page of pages) {
      if (!Number.isInteger(page) || page < 0 || page >= session.numPages) continue;
      for (const item of await session.textItems(page + 1)) {
        for (const word of wordsOfRun(item)) {
          all.add(word.word);
          if (underMark(word, marks, page)) under.add(word.word);
          else elsewhere.add(word.word);
        }
      }
    }
    return {
      ok: true,
      all: [...all],
      under: [...under],
      unique: [...under].filter((word) => !elsewhere.has(word)),
    };
  } catch (error) {
    return { ...empty, detail: error instanceof Error ? error.message : String(error) };
  } finally {
    await session.destroy();
  }
}

/**
 * Delete `terms` from every bookmark title, in place.
 *
 * An outline entry is a string the reader searches, so a title carrying a
 * redacted name leaks it back. The tree is rewritten through the same model the
 * bookmarks tool uses, which keeps destinations, nesting and styling.
 *
 * @returns how many titles changed.
 */
function scrubOutlineTitles(doc: PDFDocument, terms: readonly string[]): number {
  const wanted = [...new Set(terms.map((term) => term.trim()).filter(Boolean))];
  if (wanted.length === 0) return 0;
  const pattern = new RegExp(`\\b(?:${wanted.map((term) => term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\b`, 'gi');
  const nodes = readOutline(doc);
  if (nodes.length === 0) return 0;
  let changed = 0;
  const scrub = (list: OutlineNode[]): OutlineNode[] => list.map((node) => {
    const title = node.title.replace(pattern, '').replace(/\s+/g, ' ').trim();
    if (title !== node.title) changed += 1;
    return { ...node, title: title === '' ? '[redacted]' : title, children: node.children ? scrub(node.children) : undefined };
  });
  const next = scrub(nodes);
  if (changed > 0) writeOutline(doc, next);
  return changed;
}

/** A short, quoted list for a warning that has to name what it found. */
function previewList(words: readonly string[], limit = 6): string {
  const shown = words.slice(0, limit).map((word) => `“${word}”`).join(', ');
  return words.length > limit ? `${shown}, and ${words.length - limit} more` : shown;
}

/** `['a','b','c']` → `a, b and c`, for a sentence that has to read as English. */
function andList(items: readonly string[]): string {
  if (items.length <= 1) return items.join('');
  return `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

/**
 * Stores a redaction cannot rewrite that still carry one of the redacted words.
 *
 * `redact-pdf` deletes glyphs from page content and, when asked, scrubs the
 * `/Info` strings, the XMP packet and the outline. Annotation text and the bytes
 * of an embedded file are neither: a name blacked out on the page but living on
 * in a comment popover or in `enclosure.zip` has not been redacted, so the
 * warning has to say that in particular rather than lean on the generic caveat.
 */
function redactedWordsStillHeld(doc: PDFDocument, terms: readonly string[]): string[] {
  const wanted = [...new Set(terms.map((term) => term.trim()).filter(Boolean))];
  if (wanted.length === 0) return [];
  const pattern = new RegExp(`\\b(?:${wanted.map((term) => term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\b`, 'i');
  const holds = (value: string | undefined): boolean => value !== undefined && pattern.test(value);
  const found: string[] = [];
  const comments = listAnnotations(doc).filter((mark) => holds(mark.contents)).length;
  if (comments > 0) found.push(`${comments} comment${comments === 1 ? '' : 's'}`);
  const files = listAttachments(doc).filter((file) =>
    holds(file.name) || holds(file.description) || holds(latin1.decode(file.bytes)),
  ).length;
  if (files > 0) found.push(`${files} embedded file${files === 1 ? '' : 's'}`);
  return found;
}

/* ------------------------------------------------------------------ *
 * Verification — a security tool may only claim what it has re-read    *
 * ------------------------------------------------------------------ */

const latin1 = new TextDecoder('latin1');

/**
 * The readable page content of a document, as one string.
 *
 * Three sampled pages (first, middle, last) of decoded `/Contents` streams:
 * enough to prove that a rebuild carried the pages over unchanged and that an
 * encryption pass actually altered the bytes at rest, without reading all 500
 * pages of a large document twice (E7).
 */
function contentFingerprint(doc: PDFDocument): string {
  const pages = doc.getPages();
  const picks = [...new Set([0, Math.floor(pages.length / 2), pages.length - 1])];
  const parts: string[] = [];
  for (const index of picks) {
    const page = pages[index];
    if (!page) continue;
    try {
      for (const stream of pageContentStreams(page)) {
        parts.push(`${index + 1}:${stream.bytes.length}:${latin1.decode(stream.bytes)}`);
      }
    } catch {
      // A stream that will not decompress still fingerprints: its absence of
      // readable text is itself the fact the caller reports.
      parts.push(`${index + 1}:unreadable`);
    }
  }
  return parts.join('\n');
}

/** Read an entry whose value may be a reference or inlined, without throwing. */
function dictAt(doc: PDFDocument, value: unknown): PDFDict | undefined {
  if (value instanceof PDFRef) return doc.context.lookupMaybe(value, PDFDict);
  return value instanceof PDFDict ? value : undefined;
}

/* ------------------------------------------------------------------ *
 * The reader's point of view — what an independent engine can do      *
 * ------------------------------------------------------------------ */

/**
 * How this app's own rendering engine (pdf.js) answered when asked to open a
 * file. `protect`, `unlock` and the restriction tools report this, not the
 * options they were handed: a password gate nobody else can pass is not
 * protection, and a file that still demands a password is not unlocked (E4/E5).
 */
type ReaderVerdict = 'opens' | 'needs-password' | 'wrong-password' | 'unreadable' | 'unavailable';

interface ReaderProbe {
  verdict: ReaderVerdict;
  /** Pages the reader counted, when it got that far. */
  pages: number;
  /** Text of the sampled pages, in page order, when it could read them. */
  text: string[];
  detail?: string;
}

/** Pages sampled by `probeReader`: enough to prove content survived, bounded for E7. */
function sampledPages(total: number): number[] {
  const picks = [...new Set([1, Math.ceil(total / 2), total])];
  return picks.filter((page) => page >= 1 && page <= total);
}

async function probeReader(bytes: Uint8Array, password?: string): Promise<ReaderProbe> {
  let session;
  try {
    session = await openRender(bytes, password ? { password } : {});
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const named = error instanceof Error ? error.name : '';
    if (named !== 'PasswordRequiredError' && !/password/i.test(message)) {
      return { verdict: 'unavailable', pages: 0, text: [], detail: message };
    }
    return {
      verdict: /not correct/i.test(message) ? 'wrong-password' : 'needs-password',
      pages: 0,
      text: [],
      detail: message,
    };
  }
  try {
    const text: string[] = [];
    for (const page of sampledPages(session.numPages)) {
      text.push((await session.textItems(page)).map((item) => item.str).join(' '));
    }
    return { verdict: 'opens', pages: session.numPages, text };
  } catch (error) {
    return {
      verdict: 'unreadable',
      pages: session.numPages,
      text: [],
      detail: error instanceof Error ? error.message : String(error),
    };
  } finally {
    await session.destroy();
  }
}

/**
 * Save `doc` with no `/Encrypt` entry, page tree and all.
 *
 * Protection lives in the trailer and in the dictionary it points at, so
 * dropping both is the whole removal — and it is the only removal that keeps the
 * form fields, comments, bookmarks and embedded files a page-tree rebuild
 * leaves behind. The rebuild stays as the fallback for a file this does not
 * clear; the caller verifies which one it got.
 */
async function saveUnprotected(doc: PDFDocument): Promise<Uint8Array> {
  const entry = doc.context.trailerInfo.Encrypt;
  if (entry instanceof PDFRef) doc.context.delete(entry);
  doc.context.trailerInfo.Encrypt = undefined;
  return savePDF(doc, { useObjectStreams: true });
}

/**
 * A document opened however the file allows: with the password when it has one,
 * and without demanding one when the guard already read the file on the empty
 * password. `openPDF` refuses any `/Encrypt` entry it is not given a password
 * for, which used to make `unlock` answer "this PDF is password protected" for a
 * restricted-but-openable file — the exact case the tool exists for (E4/E5).
 */
async function openForStripping(input: OpenedInput, password: string): Promise<PDFDocument> {
  if (password) return openPDF(input.bytes, { password });
  if (input.inspection?.opensWithEmptyPassword) return input.doc;
  return openPDF(input.bytes, { password: '', ignoreEncryption: true });
}

function arrayAt(doc: PDFDocument, value: unknown): PDFArray | undefined {
  if (value instanceof PDFRef) return doc.context.lookupMaybe(value, PDFArray);
  return value instanceof PDFArray ? value : undefined;
}

/** `/AcroForm /Fields` size, without creating an AcroForm as a side effect. */
function formFieldCount(doc: PDFDocument): number {
  const acroForm = dictAt(doc, doc.catalog.get(PDFName.of('AcroForm')));
  return arrayAt(doc, acroForm?.get(PDFName.of('Fields')))?.size() ?? 0;
}

/**
 * The parts of a document a page-tree rebuild is known to leave behind.
 *
 * `countStructure` measures them, `missingStructure` turns a difference into the
 * sentence a result has to carry.
 */
interface StructureCounts {
  fields: number;
  annotations: number;
  bookmarks: number;
  attachments: number;
}

/** What a saved file still carries that a reader can edit or select. */
interface LiveMarks {
  /** Entries in `AcroForm /Fields`. */
  fields: number;
  /** Annotation objects reachable from a page, of any subtype. */
  marks: number;
  /** The `/Link` subset of `marks`. */
  links: number;
  /** The `/Widget` subset — form boxes, reported as fields rather than comments. */
  widgets: number;
  /** The `/Popup` subset — a note's bubble, which no user counts as a comment. */
  popups: number;
}

/**
 * Count the live fields and annotations in bytes that were just written.
 *
 * Flattening is the operation whose success is invisible from the document a run
 * mutated: an appearance that could not be drawn leaves its annotation exactly
 * where it was. Re-reading the output is the only way to tell "baked" from
 * "attempted", and it is what stops a result promising a page the reader can no
 * longer type into.
 *
 * The three subtype counts are kept apart because a card that calls a form box or
 * a note's bubble a "comment" is the same over-count `remove-annotations` was
 * charged with: the sentence has to name what the file actually holds.
 */
async function liveMarks(bytes: Uint8Array): Promise<LiveMarks> {
  const doc = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false });
  let marks = 0;
  let links = 0;
  let widgets = 0;
  let popups = 0;
  for (const page of doc.getPages()) {
    const annots = arrayAt(doc, page.node.get(PDFName.of('Annots')));
    if (!annots) continue;
    for (let index = 0; index < annots.size(); index++) {
      const annotation = dictAt(doc, annots.get(index));
      if (!annotation) continue;
      marks += 1;
      const subtype = annotation.get(PDFName.of('Subtype'));
      if (!(subtype instanceof PDFName)) continue;
      if (subtype.asString() === '/Link') links += 1;
      if (subtype.asString() === '/Widget') widgets += 1;
      if (subtype.asString() === '/Popup') popups += 1;
    }
  }
  return { fields: formFieldCount(doc), marks, links, widgets, popups };
}

/**
 * The annotations a reader lists as comments on the page: not the clickable areas,
 * not the note popups, and not the form boxes — those three are each counted, and
 * named, by their own number.
 */
function commentCount(marks: LiveMarks, keepLinks: boolean): number {
  return Math.max(0, marks.marks - marks.widgets - marks.popups - (keepLinks ? marks.links : 0));
}

/**
 * What one document holds of the four kinds a rebuild is known to lose.
 *
 * The tools that drop protection used to rebuild the page tree — the only way
 * they knew to clear the trailer's `/Encrypt` entry — and hand back a file
 * missing its form fields, comments, bookmarks or embedded files. Losing a
 * filled-in form while "just" removing a password is the silent failure this
 * measurement exists to prevent (E13).
 */
function countStructure(doc: PDFDocument): StructureCounts {
  return {
    fields: formFieldCount(doc),
    annotations: annotationCount(doc),
    bookmarks: readOutline(doc).length,
    attachments: listAttachments(doc).length,
  };
}

const STRUCTURE_LABELS: [keyof StructureCounts, (count: number) => string][] = [
  ['fields', (n) => `${n} form field(s)`],
  ['annotations', (n) => `${n} annotation(s) / comment(s)`],
  ['bookmarks', (n) => `${n} bookmark(s)`],
  ['attachments', (n) => `${n} embedded file(s)`],
];

/** The parts of `before` that `after` no longer carries, phrased for a warning. */
function missingStructure(before: StructureCounts, after: StructureCounts): string[] {
  return STRUCTURE_LABELS
    .map(([key, label]) => ({ key, label, gone: before[key] - after[key] }))
    .filter((entry) => entry.gone > 0)
    .map((entry) => entry.label(entry.gone));
}

/** What the file still holds, as a clause for the result message. */
function structureSentence(counts: StructureCounts): string {
  const held = STRUCTURE_LABELS
    .filter(([key]) => counts[key] > 0)
    .map(([key, label]) => label(counts[key]));
  return held.length > 0 ? held.join(', ') : 'no form fields, comments, bookmarks or embedded files';
}

/** The text a reader gets from a file, or `null` when it cannot read it. */
async function sourceTextOf(bytes: Uint8Array, password: string): Promise<string[] | null> {
  const probe = await probeReader(bytes, password || undefined);
  return probe.verdict === 'opens' ? probe.text : null;
}

interface StripResult {
  bytes: Uint8Array;
  pages: number;
  kept: StructureCounts;
  contentKept: boolean;
  rebuilt: boolean;
  warnings: string[];
}

/**
 * Remove the protection from `doc` and prove it from the saved bytes.
 *
 * The trailer's `/Encrypt` entry *is* protection, so dropping it and saving is
 * both the removal and the cheap one: the page tree, the AcroForm, the
 * annotations, the outline and the embedded files are untouched. The page-tree
 * rebuild is kept as the fallback for a file that still reports itself encrypted
 * afterwards, and the result says which path ran.
 *
 * Four facts are then re-read from the output rather than assumed: the
 * encryption flag and page count (through the same guard the file queue uses),
 * the structure counts, and — where a reader can be started at all — whether it
 * opens the copy with no password and still extracts the text it extracted from
 * the source. A file whose streams really are ciphertext loses its content when
 * the dictionary goes, and that is named instead of shipped quietly (E5).
 */
async function stripProtectionFrom(
  input: OpenedInput,
  doc: PDFDocument,
  sourceText: string[] | null,
): Promise<StripResult> {
  const source = countStructure(doc);
  const sourceContent = contentFingerprint(doc);
  let bytes = await saveUnprotected(doc);
  let inspection = await inspectPdf(bytes, input.name);
  let rebuilt = false;
  if (inspection.encrypted) {
    const cleared = await rebuildDocument(doc);
    bytes = await savePDF(cleared, { useObjectStreams: true });
    inspection = await inspectPdf(bytes, input.name);
    rebuilt = true;
  }
  if (inspection.encrypted) {
    throw new Error("保存的副本仍然带有/Encrypt条目并且会要求输入密码，因此它没有被返回。");
  }
  if (inspection.pages !== doc.getPageCount()) {
    throw new Error(`The saved copy has ${inspection.pages} of the ${doc.getPageCount()} pages the source has, so it was not returned.`);
  }
  const output = await PDFDocument.load(bytes, { updateMetadata: false });
  const kept = countStructure(output);
  const warnings: string[] = [];
  const lost = missingStructure(source, kept);
  if (lost.length > 0) {
    warnings.push(rebuilt
      ? `Dropping the protection had to copy the pages into a fresh document, so ${lost.join(', ')} did not carry over.`
      : `${lost.join(', ')} present in the source are missing from the copy that was unlocked, so check it before relying on it.`);
  }
  const contentKept = contentFingerprint(output) === sourceContent;
  if (!contentKept) {
    warnings.push('Some page content read differently once the password was removed, so check the copy before relying on it.');
  }
  const reader = await probeReader(bytes);
  if (reader.verdict === 'unavailable' || reader.verdict === 'unreadable') {
    warnings.push(`No PDF reader could be started in this browser to re-open the unlocked copy${reader.detail ? ` (${reader.detail})` : ''}; its /Encrypt entry was confirmed gone, but the pages were only checked with the built-in engine.`);
  } else if (reader.verdict !== 'opens') {
    warnings.push(`A PDF reader still will not open the saved copy without a password (${reader.detail ?? reader.verdict}), so this file is not free of its protection yet.`);
  } else if (reader.pages !== inspection.pages) {
    warnings.push(`A PDF reader counts ${reader.pages} page(s) in the saved copy where the engine that wrote it counts ${inspection.pages}.`);
  } else if (sourceText && sourceText.join('\n') !== reader.text.join('\n')) {
    // The observation, without a cause this build can no longer claim: the reader
    // undoes every cipher `core/crypto` refuses as well, so a difference here is
    // the rebuild talking, not a browser that could not read the page.
    warnings.push('A PDF reader extracts different text from the unlocked copy than it read from the protected one, so check the copy before relying on it.');
  }
  return { bytes, pages: inspection.pages, kept, contentKept, rebuilt, warnings };
}

/** The eight `/P` flags, in the order the report text lists them. */
const PERMISSION_REPORT: readonly [keyof PDFPermissions, string][] = [
  ['printing', 'printing'],
  ['printingHighQuality', 'full-resolution printing'],
  ['modifying', 'editing'],
  ['copying', 'copying text and images'],
  ['annotating', 'comments and form filling'],
  ['fillingForms', 'filling existing forms'],
  ['contentAccessibility', 'screen readers'],
  ['documentAssembly', 'rotating and inserting pages'],
];

/** One sentence describing the permissions a file really carries. */
function permissionSentence(permissions: PDFPermissions | PdfPermissions): string {
  const state = (key: keyof PDFPermissions): string =>
    permissions[key] === true ? 'allowed' : 'blocked';
  const printing = `printing ${state('printing')}`;
  const detail =
    permissions.printing === true
      ? permissions.printingHighQuality === true
        ? ' (any resolution)'
        : ' (low resolution only)'
      : '';
  return [
    `${printing}${detail}`,
    `editing ${state('modifying')}`,
    `copying ${state('copying')}`,
    `comments ${state('annotating')}`,
    `form filling ${state('fillingForms')}`,
    `screen readers ${state('contentAccessibility')}`,
    `page assembly ${state('documentAssembly')}`,
  ].join(', ');
}

/**
 * Every restriction that was asked for but is not what the written file says.
 *
 * The `/P` bitfield is the only thing a reader can honour, so a bit that did not
 * land is a real difference between a protected document and an unprotected one
 * — reported, never smoothed over (E5).
 */
function permissionMismatches(
  requested: PDFPermissions,
  recorded: PdfPermissions | null,
): string[] {
  if (!recorded) {
    return ['The protected file carries no /P dictionary, so no restriction was recorded in it.'];
  }
  const problems: string[] = [];
  for (const [key, label] of PERMISSION_REPORT) {
    const wanted = requested[key] === true;
    const got = recorded[key] === true;
    if (wanted !== got) {
      problems.push(`The file records ${label} as ${got ? 'allowed' : 'blocked'}, which is not what was asked for.`);
    }
  }
  return problems;
}

/**
 * Which stores outside the page still hold text at all.
 *
 * This is the *other text* inventory — the caveat that a redaction rewrites page
 * content, `/Info`, the XMP packet and bookmark titles, and nothing else. Whether
 * a **redacted** word specifically survived in a comment or an enclosure is
 * `redactedWordsStillHeld`'s question, and the two are reported as separate
 * sentences because only one of them is a leak (E13, E20).
 */
function textHeldOutsidePageContent(doc: PDFDocument): string[] {
  const stores: string[] = [];
  const info = readInfo(doc);
  const filled = (['title', 'author', 'subject', 'keywords'] as const)
    .map((key) => (info[key] ?? '').trim())
    .filter((value) => value.length > 0);
  if (filled.length > 0) stores.push(`the ${filled.length} document propert${filled.length === 1 ? 'y' : 'ies'} you can see under View Metadata`);
  if (readXmp(doc)) stores.push('the XMP packet');
  const bookmarks = readOutline(doc).length;
  if (bookmarks > 0) stores.push(`${bookmarks} bookmark title(s)`);
  const attachments = listAttachments(doc).length;
  if (attachments > 0) stores.push(`${attachments} embedded file(s)`);
  return stores;
}

/**
 * Every signature field in the document, wherever it is registered.
 *
 * `core/signature.readSignatures` walks `AcroForm /Fields` and throws when that
 * key is absent — which is the case for almost every unsigned PDF, so the tool
 * cannot call it blind. Looking here first keeps "this document is not signed"
 * an answer instead of a stack trace, and catches a signature stored only as a
 * page annotation, which the AcroForm walk misses.
 */
function signatureFields(doc: PDFDocument): PDFDict[] {
  const found: PDFDict[] = [];
  const consider = (entry: unknown): void => {
    const field = dictAt(doc, entry);
    if (!field) return;
    const fieldType = field.get(PDFName.of('FT'));
    const value = dictAt(doc, field.get(PDFName.of('V')));
    const valueType = value?.get(PDFName.of('Type'));
    const isSig =
      (fieldType instanceof PDFName && fieldType.asString() === '/Sig')
      || (valueType instanceof PDFName && valueType.asString() === '/Sig');
    if (isSig && !found.includes(field)) found.push(field);
  };
  const acroForm = dictAt(doc, doc.catalog.get(PDFName.of('AcroForm')));
  const fields = arrayAt(doc, acroForm?.get(PDFName.of('Fields')));
  if (fields) {
    for (let index = 0; index < fields.size(); index++) consider(fields.get(index));
  }
  for (const page of doc.getPages()) {
    const annots = arrayAt(doc, page.node.get(PDFName.of('Annots')));
    if (!annots) continue;
    for (let index = 0; index < annots.size(); index++) consider(annots.get(index));
  }
  return found;
}

/**
 * The timestamp tool's failures, phrased as an instruction (E13, E20).
 *
 * Three different things can go wrong and the old wording conflated them: the
 * document has no signature; the signature is there but the timestamp step
 * cannot read it; and the authority is unreachable. Only the last one has
 * anything to do with the network, and none of them should leave the user
 * thinking their document is now timestamped.
 */
function timestampFailure(error: unknown, tsaUrl: string, signatureCount: number): Error {
  const detail = error instanceof Error ? error.message : String(error ?? 'unknown reason');
  if (signatureCount === 0 || /has no signature/i.test(detail)) {
    return new Error("此 PDF 没有时间戳的数字签名。首先对其运行数字签名，然后为签名文件添加时间戳。");
  }
  if (/not a PKCS#7|no signer information|no message digest|could not be read/i.test(detail)) {
    return new Error(
      `The signature in this PDF could not be read by the timestamp step (${detail}), so no timestamp was attached and nothing was changed. The signature itself is untouched — Validate Signature still reports on it; a timestamp can be added when the authority answers this app's request.`,
    );
  }
  return new Error(
    `The timestamp authority at ${tsaUrl} could not be reached (${detail}). This is the only step in BrowserSnip that needs the network — the signature digest, never the document, is sent. Try again with a connection, or keep the untimed signature.`,
  );
}

/**
 * The cipher an encryption dictionary actually declares.
 *
 * `/V` and `/R` only name a strength through the crypt filter: `/V 4` with no
 * `/CF` entry, or one whose every filter is `/CFM /None`, means "there is a
 * password and no cipher" — `/StmF` and `/StrF` default to the predefined
 * `/None` filter (ISO 32000-1 §7.6.3.1, Table 20). This app's writer now selects
 * `/CFM /AESV2` and runs it, so a saved file that names no cipher here is the
 * regression, and the file — not the form — is where the truth lives (E5).
 */
function declaredCipher(doc: PDFDocument): string | null {
  const dict = encryptDictOf(doc);
  if (!dict) return null;
  const version = dict.lookupMaybe(PDFName.of('V'), PDFNumber)?.asNumber();
  if (version === undefined) return null;
  // `/V 1` and `/V 2` have no crypt-filter dictionary at all: RC4 is implied.
  if (version < 4) return 'RC4';
  const ciphers = [...new Set(cryptFilterNames(doc))].filter((name) => name !== 'None');
  return ciphers.length > 0 ? ciphers.join(' and ') : null;
}

/** The encryption dictionary itself, whether the trailer inlines it or points at it. */
function encryptDictOf(doc: PDFDocument): PDFDict | undefined {
  const entry = doc.context.trailerInfo.Encrypt;
  if (entry instanceof PDFDict) return entry;
  return entry instanceof PDFRef ? doc.context.lookupMaybe(entry, PDFDict) : undefined;
}

/** Every `/CFM` name the file's crypt filter dictionary declares. */
function cryptFilterNames(doc: PDFDocument): string[] {
  const filters = encryptDictOf(doc)?.lookupMaybe(PDFName.of('CF'), PDFDict);
  if (!filters) return [];
  const names: string[] = [];
  for (const [, value] of filters.entries()) {
    const filter = value instanceof PDFRef ? doc.context.lookupMaybe(value, PDFDict) : value;
    if (!(filter instanceof PDFDict)) continue;
    const name = filter.lookupMaybe(PDFName.of('CFM'), PDFName)?.decodeText();
    if (name) names.push(name);
  }
  return names;
}

/**
 * Re-read the bytes a protection tool just wrote, and describe what they say.
 *
 * Returns the recorded permissions plus the warnings the tool must carry: a gate
 * that did not reach the trailer, permissions the file does not record, a file
 * that opens on the empty password when one was set (and the other way round), a
 * dictionary that names no cipher although the engine was asked to run one, and
 * page content that did not come back through the cipher intact.
 *
 * The re-read runs the whole way round: the bytes are opened with the password
 * that was just written, `core/crypto` decrypts them, and the plaintext is
 * compared with the source. That is a round trip through the writer and the
 * reader of this app — not proof against another implementation, which is what
 * `docs/research/protect-readers.py` is for — but it is the proof that a user
 * re-opening their own file here gets their own pages back.
 */
async function verifyProtection(
  bytes: Uint8Array,
  name: string,
  requested: PDFPermissions,
  sourceFingerprint: string,
  opensFreely: boolean,
  password: string,
): Promise<{ inspection: PdfInspection; warnings: string[] }> {
  // No password: the gate is what a reader without one sees (E4).
  const inspection = await inspectPdf(bytes, name);
  const warnings: string[] = [];
  if (!inspection.encrypted) {
    warnings.push('The saved file carries no /Encrypt entry, so a reader will open it without asking for the password.');
  }
  warnings.push(...permissionMismatches(requested, inspection.permissions));
  if (!inspection.encrypted) return { inspection, warnings };
  // A restrictions-only file must still open on double-click; a file with an
  // open password must not. `PDFDocument.load` with an empty password is the
  // reader's point of view here, because the guard reports any /Encrypt as
  // needing a password (it cannot know the user password is empty).
  let opensWithoutOne = false;
  try {
    await PDFDocument.load(bytes, { password: '', updateMetadata: false });
    opensWithoutOne = true;
  } catch {
    opensWithoutOne = false;
  }
  if (opensFreely && !opensWithoutOne) {
    warnings.push('No open password was set, yet the saved file does not open on the empty password — check the copy before sending it.');
  }
  if (!opensFreely && opensWithoutOne) {
    warnings.push('The saved file opens without any password even though one was set, so it offers no confidentiality.');
  }
  try {
    // Two views of the same bytes, because one document cannot show both: the
    // dictionary is read from a load that leaves the cipher in place, and the
    // page content from one that runs it back out again.
    const sealed = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false });
    const cipher = declaredCipher(sealed);
    if (!cipher) {
      // The reverse of the old defect: a file whose dictionary selects `/None`
      // while the user was told their pages are ciphered. A tool that ignores
      // /Encrypt could lift their text straight out of it.
      warnings.push('The saved file names no crypt filter, so its pages are stored in the clear behind the password; a tool that ignores /Encrypt can still read the text.');
    } else {
      const opened = await openPDF(bytes, { password });
      if (contentFingerprint(opened) !== sourceFingerprint) {
        warnings.push('The page content read back different from the source through the cipher this app just wrote, so check the copy before relying on it.');
      }
    }
  } catch {
    warnings.push('The saved file could not be re-read with its own password to check its crypt filter and page content.');
  }
  return { inspection, warnings };
}


function escapeXml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function diffWords(a: string, b: string): string {
  const left = new Set(a.split(/\s+/).filter(Boolean));
  const right = new Set(b.split(/\s+/).filter(Boolean));
  const removed = [...left].filter((w) => !right.has(w)).length;
  const added = [...right].filter((w) => !left.has(w)).length;
  return `${removed} word(s) removed, ${added} added`;
}

/** Overlay two page renders and return the diff percentage plus an image. */
function visualDiff(
  a: HTMLCanvasElement,
  b: HTMLCanvasElement,
  threshold: number,
): { percent: number; overlay: Promise<Blob> } {
  const width = Math.max(a.width, b.width);
  const height = Math.max(a.height, b.height);
  const out = document.createElement('canvas');
  out.width = width;
  out.height = height;
  const ctx = out.getContext('2d');
  if (!ctx) throw new Error("该浏览器无法创建比较画布。");
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(a, 0, 0);
  const dataA = ctx.getImageData(0, 0, width, height).data;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(b, 0, 0);
  const dataB = ctx.getImageData(0, 0, width, height).data;

  const overlay = document.createElement('canvas');
  overlay.width = width;
  overlay.height = height;
  const overlayCtx = overlay.getContext('2d');
  if (!overlayCtx) throw new Error("该浏览器无法创建比较画布。");
  const image = overlayCtx.createImageData(width, height);
  let different = 0;
  for (let i = 0; i < dataA.length; i += 4) {
    const delta =
      Math.abs(dataA[i] - dataB[i]) +
      Math.abs(dataA[i + 1] - dataB[i + 1]) +
      Math.abs(dataA[i + 2] - dataB[i + 2]);
    const changed = delta / 3 > threshold * 255;
    if (changed) {
      different += 1;
      image.data[i] = 225;
      image.data[i + 1] = 29;
      image.data[i + 2] = 72;
      image.data[i + 3] = 200;
    } else {
      const grey = Math.round(0.299 * dataA[i] + 0.587 * dataA[i + 1] + 0.114 * dataA[i + 2]);
      const faded = Math.min(255, grey + 60);
      image.data[i] = faded;
      image.data[i + 1] = faded;
      image.data[i + 2] = faded;
      image.data[i + 3] = 255;
    }
  }
  overlayCtx.putImageData(image, 0, 0);
  const pixels = width * height;
  return {
    percent: pixels === 0 ? 0 : (different / pixels) * 100,
    overlay: new Promise<Blob>((resolve, reject) =>
      overlay.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("无法导出比较页面。"))), 'image/png'),
    ),
  };
}

export { permissionsObject, looksEncrypted, formatPages };
