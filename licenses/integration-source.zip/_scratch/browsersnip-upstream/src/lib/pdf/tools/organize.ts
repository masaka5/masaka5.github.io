/**
 * Organize PDF — page-order, page-geometry and imposition tools.
 *
 * Everything here is pure `pdf-lib`: page copying, form-XObject imposition and
 * page-box edits. No optional engine is required, so these tools work with the
 * network unplugged — what they cannot do is carry page furniture (links, form
 * fields, bookmarks) across a rebuild, and every tool that has to rebuild says
 * so through `result.warnings` rather than only in the log pane.
 *
 * The rules this module follows for each tool (`docs/REFINEMENT-BRIEF.md`):
 *
 * - inputs come from `openInputs`, i.e. the guard's gate — an empty file, a
 *   renamed JPEG, a locked document and a pageless PDF never reach a tool body
 *   (E1–E6);
 * - a "which pages" answer is resolved by `selection()`: `pageRangeProblem`
 *   first, so page 9 of a 3-page file names the real page count instead of
 *   being skipped (E6, E15);
 * - every numeric field declares its bounds once, on the field itself, and
 *   `numberOf()` re-applies them at the point of use and reports the
 *   correction (E15) — so the rail can block before the click;
 * - a 0-page plan or an empty selection is refused with what to do next, never
 *   saved as a one-blank-page PDF (E13, E18 — pdf-lib quietly *adds* a page to
 *   an empty document on save, which is exactly the plausible-looking lie);
 * - a page's own `/Rotate` and `CropBox` are honoured through `stamp()`,
 *   because `embedPage` captures pre-rotation MediaBox content (E8, E9);
 * - anything that had to compromise lands in `result.warnings` (E5, E14, E20).
 */
import type { PDFDocument, PDFEmbeddedPage, PDFPage } from '@maxwbh/pdf-lib';
import {
  PDFArray,
  PDFDict,
  PDFHexString,
  PDFName,
  PDFRef,
  degrees,
  rgb,
} from '../core/doc';
import {
  carryPageFurniture,
  collectPages,
  newPDF,
  openPDF,
  savePDF,
  type CopyFidelity,
  type PageCopyMap,
} from '../core/doc';
import { countOutlineNodes, readOutline } from '../core/bookmarks';
import { listAttachments } from '../core/attachments';
import { listFormFields } from '../core/forms';
import { PAGE_SIZES, cropBox, ensurePageContents, formatPages, mediaBox, normaliseRotation, pageSize as resolvePageSize, resolvePages } from '../core/pages';
import { findBlankPages } from '../core/blank';
import { createZip } from '../core/archive';
import {
  ToolInputError,
  clampNumber,
  describeSize,
  downloadStem,
  fieldBounds,
  openInputs,
  pageRangeProblem,
  pagesField,
  pdfResult,
  rebuildDocument,
  throwIfAborted,
  withRender,
  filesResult,
  type OpenedInput,
} from './helpers';
import {
  booleanValue,
  numberValue,
  stringValue,
  type PdfToolDefinition,
  type ToolField,
  type ToolResult,
  type ToolValues,
} from './types';

/* ── run plumbing ─────────────────────────────────────────────────────────── */

/** The compromises one run had to make, in the order they were noticed. */
interface Notes {
  readonly warnings: string[];
  add(message: string): void;
}

function createNotes(): Notes {
  const warnings: string[] = [];
  return {
    warnings,
    add: (message: string) => {
      if (!warnings.includes(message)) warnings.push(message);
    },
  };
}

/** A `{ kind: 'pdf' }` result that carries its warnings to the result card. */
async function pdfOut(doc: PDFDocument, notes: Notes, message: string): Promise<ToolResult> {
  const result = await pdfResult(doc, { message });
  return notes.warnings.length > 0 ? { ...result, warnings: notes.warnings } : result;
}

/**
 * A multi-file result.
 *
 * `filesResult` throws a bare `Error` on an empty list; refusing here instead
 * keeps E13's "honest empty state" a `ToolInputError` the rail can act on.
 */
function filesOut(files: { blob: Blob; name: string }[], notes: Notes, message: string): ToolResult {
  if (files.length === 0) {
    throw new ToolInputError('NO_PAGES', "什么也没产生。", {
      hint: "扩大页面选择范围，或选择不同的分割模式。",
    });
  }
  const result = filesResult(files, message);
  return notes.warnings.length > 0 ? { ...result, warnings: notes.warnings } : result;
}

/** `between 1 and 500 pages`, `at least 0.05`, … — from the field's own bounds. */
function boundsSentence(field: ToolField): string {
  const bounds = fieldBounds(field);
  if (!bounds) return '';
  const unit = bounds.unit ? ` ${bounds.unit}` : '';
  const hasMin = Number.isFinite(bounds.min);
  const hasMax = Number.isFinite(bounds.max);
  if (hasMin && hasMax) return `between ${bounds.min} and ${bounds.max}${unit}`;
  if (hasMin) return `at least ${bounds.min}${unit}`;
  if (hasMax) return `at most ${bounds.max}${unit}`;
  return '';
}

/**
 * Read a numeric field through the bounds it declares (E15).
 *
 * `runPdfTool` clamps before a tool starts, so this is the same rule applied a
 * second time for callers that reach `run()` directly — and the place where a
 * correction becomes a warning the user actually sees.
 */
function numberOf(values: ToolValues, field: ToolField, notes: Notes): number {
  const fallback = typeof field.default === 'number' ? field.default : 0;
  const raw = numberValue(values, field.key, fallback);
  const bounds = fieldBounds(field);
  if (!bounds) return raw;
  const fixed = clampNumber(raw, bounds.min, bounds.max, { integer: bounds.integer });
  if (fixed !== raw) {
    notes.add(`${field.label} must be ${boundsSentence(field)}: ${raw} became ${fixed}.`);
  }
  return fixed;
}

/**
 * Bound a page-number field against the document in hand (E6).
 *
 * The rail cannot know the page count when the field is drawn, so this is the
 * half of E15 that has to happen in the tool — and it names the real count.
 */
function clampToPage(label: string, value: number, total: number, notes: Notes): number {
  const fixed = clampNumber(value, 1, Math.max(1, total), { integer: true });
  if (fixed !== value) {
    notes.add(
      `${label} must be a page between 1 and ${total}: ${value} became ${fixed}.`,
    );
  }
  return fixed;
}

/** A number of pages, phrased the same way everywhere in this module. */
function pageCountLabel(n: number): string {
  return `${n} page${n === 1 ? '' : 's'}`;
}

/**
 * Resolve a "which pages" field into 0-based indices (E6, E13, E15, E18).
 *
 * Blank is *not* "all": a cleared field means the user did not choose, which is
 * refused before any work. `all`/`odd`/`even` and the `1,3,5-7` grammar still
 * work, and a repeated page is applied once — rotating page 2 twice by 90° is
 * never what a selection that lists it twice means.
 */
function selection(
  values: ToolValues,
  total: number,
  options: { key?: string; fallback?: string | null; verb?: string } = {},
): number[] {
  const key = options.key ?? 'pages';
  const verb = options.verb ?? 'run this on';
  const raw = values[key];
  const hint = `Pick pages between 1 and ${total}, or leave it as "all".`;

  if (Array.isArray(raw)) {
    const given = raw.filter((n): n is number => typeof n === 'number');
    if (given.length === 0) {
      throw new ToolInputError('NO_PAGES', `Nothing is selected — choose the pages to ${verb}.`, { hint });
    }
    const asText = given.join(',');
    const problem = pageRangeProblem(asText, total);
    if (problem) throw new ToolInputError("OUT_OF_RANGE", problem, { hint });
    return dedupe(resolvePages(given, total));
  }

  const text = typeof raw === 'string' ? raw.trim() : '';
  if (text === '') {
    if (options.fallback === undefined || options.fallback === null) {
      throw new ToolInputError(
        'NO_PAGES',
        `No pages chosen — the ${key === 'pages' ? 'page list' : key} is empty, so there is nothing to ${verb}.`,
        { hint },
      );
    }
    return dedupe(resolvePages(options.fallback, total));
  }
  const problem = pageRangeProblem(text, total);
  if (problem) throw new ToolInputError("OUT_OF_RANGE", problem, { hint });
  let pages: number[];
  try {
    pages = resolvePages(text, total);
  } catch (error) {
    throw new ToolInputError("OUT_OF_RANGE", error instanceof Error ? error.message : String(error), { hint });
  }
  const unique = dedupe(pages);
  if (unique.length === 0) {
    throw new ToolInputError('NO_PAGES', `"${text}" matched no page in this document.`, { hint });
  }
  return unique;
}

function dedupe(pages: number[]): number[] {
  const seen = new Set<number>();
  const out: number[] = [];
  for (const page of pages) {
    if (seen.has(page)) continue;
    seen.add(page);
    out.push(page);
  }
  return out;
}

/* ── geometry (E8, E9) ────────────────────────────────────────────────────── */

/** A page's own `/Rotate`, as a clockwise multiple of 90. */
function rotationOf(page: PDFPage): number {
  return ((page.getRotation().angle % 360) + 360) % 360;
}

/** The visible box in the page's own, pre-rotation coordinates. */
function sourceBox(page: PDFPage): { x: number; y: number; width: number; height: number } {
  return cropBox(page);
}

/** What a viewer shows: the visible box with `/Rotate` applied. */
function visibleBox(page: PDFPage): { width: number; height: number } {
  const box = sourceBox(page);
  return rotationOf(page) % 180 === 90
    ? { width: box.height, height: box.width }
    : { width: box.width, height: box.height };
}

/** How many different displayed sizes these pages have (E8). */
function distinctSizes(doc: PDFDocument, indices: number[]): number {
  const sizes = new Set<string>();
  for (const index of indices) {
    const page = doc.getPages()[index];
    if (!page) continue;
    const box = visibleBox(page);
    sizes.add(`${Math.round(box.width)}x${Math.round(box.height)}`);
  }
  return sizes.size;
}

function noteMixedSizes(subject: string, doc: PDFDocument, indices: number[], notes: Notes): void {
  const variants = distinctSizes(doc, indices);
  if (variants > 1) {
    notes.add(
      `${subject}: this selection holds ${variants} different page sizes, so each page is scaled to fit its own cell — the printed sizes will differ.`,
    );
  }
}

interface Box { x: number; y: number; width: number; height: number }

/**
 * Draw a region of `source` into `page`, centred in `dest`.
 *
 * `pdf-lib`'s `embedPage` captures the content stream in pre-rotation page
 * space and clips to the MediaBox, so a page that *displays* as portrait comes
 * out sideways and a page with an offset box comes out shifted unless the stamp
 * undoes both. `angle` is the caller's extra turn, clockwise, which is how
 * `/Rotate`, the UI and the help text describe rotation (E8, E9).
 */
async function stamp(
  target: PDFDocument,
  page: PDFPage,
  source: PDFPage,
  dest: Box,
  options: {
    region?: Box;
    /** Extra clockwise turn on top of the page's own `/Rotate`. */
    angle?: number;
    opacity?: number;
    /**
     * `contain` (default) shrinks to fit the destination; `exact` draws at
     * 1:1 so an oversized destination crops; `stretch` fills non-uniformly and
     * changes the aspect ratio.
     */
    fit?: 'contain' | 'exact' | 'stretch';
  } = {},
): Promise<boolean> {
  const region = options.region ?? sourceBox(source);
  if (region.width <= 0 || region.height <= 0 || dest.width <= 0 || dest.height <= 0) return false;
  // A page with no `/Contents` is **blank**, not damaged — `/Contents` is optional,
  // and this app's own `add-blank-page` writes pages without one. The fork's page
  // embedder refuses the absent key with `Can't embed page with missing Contents`,
  // and it refuses it at `save()` (the embed is only queued here), so no `try`/`catch`
  // around the call could have caught it: all seven imposition tools turned a legal
  // file away (`docs/TOOL-TRIAGE.md`, ERRORS 1). Giving the blank the empty content
  // array the embedder already accepts keeps it on the same path as an inked page —
  // right box, right rotation, right cell, nothing drawn. A `/Contents` that exists
  // but cannot be decoded is left alone, so it still fails loudly.
  ensurePageContents(source);
  const embedded = await target.embedPage(source, {
    left: region.x,
    bottom: region.y,
    right: region.x + region.width,
    top: region.y + region.height,
  });
  const clockwise = normalise360(rotationOf(source) + (options.angle ?? 0));
  // `/Rotate` turns the sheet clockwise; the content-matrix turns counter-clockwise.
  const radians = (-clockwise * Math.PI) / 180;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  const corners = [
    [0, 0],
    [region.width, 0],
    [0, region.height],
    [region.width, region.height],
  ].map(([x, y]) => [x * cos - y * sin, x * sin + y * cos] as const);
  const minX = Math.min(...corners.map((c) => c[0]));
  const maxX = Math.max(...corners.map((c) => c[0]));
  const minY = Math.min(...corners.map((c) => c[1]));
  const maxY = Math.max(...corners.map((c) => c[1]));
  const drawnWidth = maxX - minX;
  const drawnHeight = maxY - minY;
  if (drawnWidth <= 0 || drawnHeight <= 0) return false;
  const uniform = Math.min(dest.width / drawnWidth, dest.height / drawnHeight);
  const fit = options.fit ?? 'contain';
  const xScale = fit === 'stretch' ? dest.width / drawnWidth : fit === 'exact' ? 1 : uniform;
  const yScale = fit === 'stretch' ? dest.height / drawnHeight : fit === 'exact' ? 1 : uniform;
  page.drawPage(embedded, {
    x: dest.x + (dest.width - drawnWidth * xScale) / 2 - minX * xScale,
    y: dest.y + (dest.height - drawnHeight * yScale) / 2 - minY * yScale,
    xScale,
    yScale,
    rotate: degrees(-clockwise),
    opacity: options.opacity,
  });
  return true;
}

/** The bounding box a `width × height` sheet needs after a clockwise turn. */
function rotatedBoxSize(width: number, height: number, clockwise: number): {
  width: number;
  height: number;
} {
  const radians = (normalise360(clockwise) * Math.PI) / 180;
  const cos = Math.abs(Math.cos(radians));
  const sin = Math.abs(Math.sin(radians));
  return { width: width * cos + height * sin, height: width * sin + height * cos };
}

function normalise360(degrees: number): number {
  return ((degrees % 360) + 360) % 360;
}

/**
 * A tile of the page as a viewer shows it (origin top-left) converted to the
 * page's own pre-rotation coordinates, so cutting a `/Rotate 90` page in half
 * follows the line the user sees rather than the raw MediaBox (E9).
 */
function displayRegion(page: PDFPage, tile: { x: number; y: number; width: number; height: number }): Box {
  const box = sourceBox(page);
  const width = box.width;
  const height = box.height;
  const at = (x: number, y: number, w: number, h: number): Box => ({
    x: box.x + x,
    y: box.y + y,
    width: w,
    height: h,
  });
  const rotation = rotationOf(page);
  if (rotation === 90) return at(tile.y, tile.x, tile.height, tile.width);
  if (rotation === 180) return at(width - tile.x - tile.width, height - tile.y - tile.height, tile.width, tile.height);
  if (rotation === 270) return at(width - tile.y - tile.height, height - tile.x - tile.width, tile.height, tile.width);
  return at(tile.x, height - tile.y - tile.height, tile.width, tile.height);
}

/* ── document facts worth admitting ───────────────────────────────────────── */

function hasOutlines(doc: PDFDocument): boolean {
  return doc.catalog.get(PDFName.of('Outlines')) !== undefined;
}

/**
 * Count page-level annotations (links, form fields, stamps).
 *
 * `/Annots` is a `PDFArray` or a reference to one depending on the producer, so
 * it is read and narrowed rather than passed to `lookupMaybe` (E3).
 */
function annotationCount(doc: PDFDocument, indices: number[]): number {
  let total = 0;
  for (const index of indices) {
    const page = doc.getPages()[index];
    if (!page) continue;
    // SAFETY: `PDFPageLeaf.Annots()` returns the array (or throws when the
    // inherited value is not one); only `size` is used, so the narrow structural
    // view is sound.
    const node = page.node as unknown as { Annots?: () => { size(): number } | null };
    try {
      total += node.Annots?.()?.size() ?? 0;
    } catch {
      total += 0;
    }
  }
  return total;
}

/**
 * Say out loud what a form-XObject rebuild leaves behind (E13, E20).
 *
 * Imposition keeps the *ink* — text stays vector and selectable — but page
 * furniture lives on the page object, and a rebuilt page has new content with
 * none of it. That is a compromise, so it is a warning, not a log line.
 */
function noteRebuildLoss(subject: string, doc: PDFDocument, indices: number[], notes: Notes): void {
  const annots = annotationCount(doc, indices);
  if (annots > 0) {
    notes.add(
      `${subject} drew the pages into new ones, so ${annots} link${annots === 1 ? '' : 's'} or annotation${annots === 1 ? '' : 's'} could not come along.`,
    );
  }
  if (hasOutlines(doc)) {
    notes.add(
      `${subject} rebuilt the pages, so this document's bookmarks are not in the output — the optional CoherentPDF engine edits bookmarks without a rebuild.`,
    );
  }
  // Both of these are page-independent structures the rebuild has no handle on:
  // the embedded files hang off the catalog, and the field list off `/AcroForm`.
  const attached = listAttachments(doc).length;
  if (attached > 0) {
    notes.add(
      `${subject} rebuilt the pages, so this document's ${countLabel(attached, 'attached file')} ${attached === 1 ? 'is' : 'are'} not in the output.`,
    );
  }
  noteFormFields(listFormFields(doc).length, notes);
}

/** `1 bookmark` / `3 bookmarks`, for a sentence that has to read like English. */
function countLabel(count: number, noun: string): string {
  return `${count} ${noun}${count === 1 ? '' : 's'}`;
}

/** How many bookmarks a document's outline holds, grouping headings included. */
function outlineSize(doc: PDFDocument): number {
  return countOutlineNodes(readOutline(doc));
}

/**
 * Admit the bookmarks a page copy had to leave behind.
 *
 * The copy re-points every bookmark whose destination travelled; what remains is
 * a bookmark aimed at a page this output does not contain, which is dropped
 * rather than left on the wrong sheet (see `remapOutline`).
 */
function noteDroppedBookmarks(
  total: number,
  carried: number,
  dropped: number,
  notes: Notes,
): void {
  if (dropped <= 0 || total <= 0) return;
  notes.add(
    `${dropped} of this document's ${countLabel(total, 'bookmark')} pointed at ${dropped === 1 ? 'a page that is' : 'pages that are'} not in this output, so ${dropped === 1 ? 'it was' : 'they were'} dropped; ${carried > 0 ? `${carried} came with the pages` : 'none came with the pages'}.`,
  );
}

/** The field list is not a page object, so a copy can never carry it. */
function noteFormFields(count: number, notes: Notes): void {
  if (count <= 0) return;
  notes.add(
    `This document has ${countLabel(count, 'form field')}: the copied pages keep their boxes, but a page copy cannot carry the field list, so ${count === 1 ? 'it is' : 'they are'} no longer editable in the output. Flatten the form first if the values have to survive.`,
  );
}

/**
 * Say out loud whatever the page copy could not carry.
 *
 * `collectPages` keeps the outline and the embedded files; this is the remainder,
 * stated with a count instead of left silent. The copy used to drop the whole
 * table of contents and every attached file without a word.
 */
function notePageCopy(sources: PDFDocument[], fidelity: CopyFidelity, notes: Notes): void {
  noteDroppedBookmarks(
    fidelity.bookmarks + fidelity.bookmarksDropped,
    fidelity.bookmarks,
    fidelity.bookmarksDropped,
    notes,
  );
  if (fidelity.attachmentsCollided > 0) {
    notes.add(
      `${countLabel(fidelity.attachmentsCollided, 'attached file')} shared a name with one already carried, so only the first copy is in the output.`,
    );
  }
  noteFormFields(sources.reduce((sum, doc) => sum + listFormFields(doc).length, 0), notes);
}

/**
 * A document that is safe to save.
 *
 * `pdf-lib` writes the `/Encrypt` trailer entry back for a document that was
 * *loaded* with a password, so handing the input straight back gives the user a
 * file that still asks for one (E5). Copying the pages into a fresh document is
 * the only reliable way to drop the protection.
 *
 * What the saved file then *carries* is not this function's claim: the run re-seals
 * the copy with the source's own lock when it can (`tools/runner.ts:preserveProtection`)
 * and says which of the two happened in its own note. Measured on the deployed site
 * before that was noticed: a rotate of `aes-256-user.pdf` came back `/V 5 /R 6`
 * `/CFM /AESV3`, refusing the empty password and the wrong one alike, beside a note
 * promising "the output opens without a password" — a sentence the bytes contradicted
 * and the reader behind it confirmed.
 */
async function savable(input: OpenedInput, notes: Notes): Promise<PDFDocument> {
  if (!input.inspection?.encrypted) return input.doc;
  const rebuilt = await rebuildDocument(input.doc);
  notes.add(`"${input.name}" is password protected, so its pages were copied into a new document.`);
  // The copy re-points the bookmarks and carries the embedded files across, so
  // the field list is the only thing this rebuild can still lose.
  noteFormFields(listFormFields(input.doc).length, notes);
  return rebuilt;
}

/* ── names (E17) ──────────────────────────────────────────────────────────── */

/**
 * A stem that survives a download: the shared E17 rule from `helpers`, so the
 * split files, ZIP entries and per-page outputs of every tool are named the
 * same way the runner names a single output.
 */
const safeStem = downloadStem;

/**
 * What a split file's name says about its contents: one sheet is `page-5`,
 * several are `pages-2-7`. `pages-5-5` named a single sheet as if it were a
 * range, which reads like a mistake in a folder full of downloads (E17).
 */
function rangeName(first: number, last: number): string {
  return first === last ? `page-${first}` : `pages-${first}-${last}`;
}

/** Make `name` unique within `used` by suffixing `-2`, `-3`, … */
function uniqueName(used: Set<string>, name: string): string {
  if (!used.has(name)) {
    used.add(name);
    return name;
  }
  let n = 2;
  while (used.has(`${name.replace(/\.pdf$/i, '')}-${n}.pdf`)) n += 1;
  const candidate = `${name.replace(/\.pdf$/i, '')}-${n}.pdf`;
  used.add(candidate);
  return candidate;
}

const PAGE_SIZE_OPTIONS = [
  { value: 'same', label: "与源页面相同" },
  { value: 'a4', label: "A4(210×297毫米)" },
  { value: 'letter', label: "字母（8.5 × 11 英寸）" },
  { value: 'legal', label: "合法（8.5 × 14 英寸）" },
  { value: 'a3', label: "A3(297×420毫米)" },
  { value: 'tabloid', label: "小报（11 × 17 英寸）" },
];

/** The largest page edge a conforming PDF may carry. */
const PDF_MAX_EDGE = 14400;
const MAX_EDGE_TEXT = '14 400 pt';

/**
 * What a page-tree copy costs. The shared primitive re-points the bookmarks
 * whose pages travelled and carries the embedded files, so the standing loss is
 * the catalogue's form-field list: the widget boxes come along, the thing that
 * made them fields does not.
 *
 * The form-field half of this sentence is measured, not assumed: `copyPages`
 * carries a page's widget annotations but never the catalogue's `/AcroForm`, so
 * a reopened output reports zero fields (see the byte test in
 * `tests/pdf/edge-organize.test.ts`). Saying "form fields travel with the
 * pages" would be the overclaim this pass exists to remove.
 */
const PAGE_COPY_NOTE =
  'The pages are copied into a new file. The ink, the annotations, the bookmarks that point at pages you kept and any attached files travel with them. What never travels is the form-field list: a fillable form stops being fillable, so flatten it first if the values have to survive.';

const FLATTEN_NOTE =
  'Imposition draws each page as vector content inside a new page: text stays selectable, but links, form fields and bookmarks on those pages do not survive the rebuild. The optional CoherentPDF engine edits a file without rebuilding it.';

/* ── shared fields ────────────────────────────────────────────────────────── */

const ALL_PAGES: ToolField = pagesField();

const CHUNK_SIZE: ToolField = {
  key: 'chunkSize',
  label: "每个文件的页数",
  type: 'number',
  default: 2,
  min: 1,
  max: 500,
  step: 1,
  integer: true,
  group: "分割依据",
  help: "仅由固定块模式使用：页1-N进入第一个文件，并且允许短的最终文件。",
};

const ANCHOR: ToolField = {
  key: 'anchor',
  label: "页码",
  type: 'number',
  default: 1,
  min: 1,
  // A page number can only be bounded to the open document, so the rail gets a
  // generous ceiling and `clampToPage` names the real last page at run time (E6).
  max: 5000,
  step: 1,
  integer: true,
  group: "位置",
  help: "计入您放入的文档中。固定到最后一页。",
};

const BLANK_COUNT: ToolField = {
  key: 'count',
  label: "要添加的空白页",
  type: 'number',
  default: 1,
  min: 1,
  max: 200,
  step: 1,
  integer: true,
  unit: "pages",
  group: "位置",
  help: "作为一串插入到所选位置，而不是散布在整个文档中。",

};

const OFFSET: ToolField = {
  key: 'offset',
  label: "背面页面偏移",
  type: 'number',
  default: 0,
  min: 0,
  // The rail only knows the ceiling the field can carry; `duplex-collate` bounds
  // it to the scan in hand and says so (E6, E15).
  max: 500,
  step: 1,
  integer: true,
  unit: "pages",
  group: "扫描顺序",
  help: "当背面块开始比文档的一半晚一两页时——例如，封面是单独扫描的。两个块之间的页面不进行排序，并且运行会对它们进行命名。",
};

const OPACITY: ToolField = {
  key: 'opacity',
  label: "不透明度",
  type: 'slider',
  default: 1,
  min: 0.05,
  max: 1,
  step: 0.05,
  group: "放置",
  help: "低于1，两层都保持清晰；为 1 时，覆盖层会隐藏其下方的所有内容。",

};

const SCALE: ToolField = {
  key: 'scale',
  label: "邮票尺寸",
  type: 'slider',
  default: 1,
  min: 0.1,
  max: 3,
  step: 0.05,
  unit: '×',
  group: "放置",
  help: "1覆盖底页：邮票被缩放到其纸张，因此为相同纸张设计的信头准确地落在。高于 1 时，它会超出边缘；低于 1 时，它会向中间收缩。",

};

const GUTTER: ToolField = {
  key: 'gutter',
  label: "天沟",
  type: 'slider',
  default: 8,
  min: 0,
  max: 72,
  step: 1,
  unit: "pt",
  group: "间距",
  help: "相邻单元之间的空间：沿着两层片材的中间，折叠或活页夹所在的位置，并且沿着更密集的网格的每个连接处。",

};

const MARGIN: ToolField = {
  key: 'margin',
  label: "保证金",
  type: 'slider',
  default: 18,
  min: 0,
  max: 72,
  step: 1,
  unit: "pt",
  group: "间距",
  help: "在片材边缘处，在整个网格周围保留空间。",

};

const ANGLE: ToolField = {
  key: 'angle',
  label: "角度",
  type: 'slider',
  default: 2,
  min: -180,
  max: 180,
  step: 0.1,
  unit: '°',
  group: "旋转",
  help: "顺时针正转。任何非 90° 步长的角度都会将页面重新布局为矢量内容。",
};

const DPI: ToolField = {
  key: 'dpi',
  label: "分辨率",
  type: 'slider',
  default: 200,
  min: 72,
  max: 400,
  step: 1,
  integer: true,
  unit: "dpi",
  group: "图像",
  help: "越高意味着该选项卡中的档案越大并且内存越大。",
};

/**
 * The counting fields of the two cutting tools.
 *
 * E15 says a numeric field declares its bounds once, on the field itself. These
 * were written twice — once for the rail and again through `TILES` for the clamp
 * at the point of use — and the two spellings had drifted (1 to 9 for the rail,
 * 1 to 12 for the run), so the same value could be corrected two different ways.
 * One declaration each, read by both halves.
 */
const POSTER_ACROSS: ToolField = {
  key: 'columns',
  label: "瓷砖横跨",
  type: 'number',
  default: 2,
  min: 1,
  max: 12,
  step: 1,
  integer: true,
  half: true,
  group: "网格",
  help: "页面被水平切割成多少块；当瓷砖向下时，这设置了每块的尺寸。",
};

const POSTER_DOWN: ToolField = {
  key: 'rows',
  label: "平铺下来",
  type: 'number',
  default: 2,
  min: 1,
  max: 12,
  step: 1,
  integer: true,
  half: true,
  group: "网格",
  help: "页面被垂直切割成多少块；上面的瓷砖决定了每块的大小。",
};

const POSTER_BLEED: ToolField = {
  key: 'bleed',
  label: "用于修剪的重叠",
  type: 'slider',
  default: 10,
  min: 0,
  max: 100,
  step: 1,
  unit: "pt",
  group: "网格",
  help: "相邻瓷砖有多少重复，因此仍然会出现小的切割误差。",
};

const DIVIDE_PARTS: ToolField = {
  key: 'parts',
  label: "零件数量",
  type: 'number',
  default: 2,
  min: 2,
  max: 9,
  step: 1,
  integer: true,
  group: "切",
  when: (v) => v.axis !== 'grid',
  help: "沿着所选择的方向将页面切割成多少条。",
};

const DIVIDE_COLUMNS: ToolField = {
  key: 'columns',
  label: "列",
  type: 'number',
  default: 2,
  min: 1,
  max: 9,
  step: 1,
  integer: true,
  half: true,
  group: "切",
  when: (v) => v.axis === 'grid',
  help: "网格模式下页面上的单元格。",
};

const DIVIDE_ROWS: ToolField = {
  key: 'rows',
  label: "行",
  type: 'number',
  default: 2,
  min: 1,
  max: 9,
  step: 1,
  integer: true,
  half: true,
  group: "切",
  when: (v) => v.axis === 'grid',
  help: "网格模式下页面下方的单元格。",
};

/* ── tools ────────────────────────────────────────────────────────────────── */

export const organizeTools: PdfToolDefinition[] = [
  {
    id: 'merge',
    name: "合并PDF",
    description: "将多个PDF合并到一个文件中，每个源都带有书签",
    icon: '📑',
    category: 'organize',
    keywords: ['combine', 'join', 'append', 'stitch'],
    multiFile: true,
    minFiles: 1,
    outputSuffix: '_merged.pdf',
    actionLabel: "合并",
    promise: 'One PDF with every file’s pages in your order, and — while bookmarks are switched on — one entry per source file.',
    notes: [
      'Pages are copied rather than redrawn, so the source files are untouched and their link annotations and attached files come with them. The catalogue’s form field list does not, so a fillable form needs filling before it is merged.',
      'With “Add a bookmark for each file” on, one entry is written for the first page of each file and the bookmarks *inside* a source file are not carried over. Switch it off and the original trees are re-pointed at the merged pages instead — use the bookmark editor to combine the two.',
    ],
    fields: [
      {
        key: 'bookmarks',
        label: "为每个文件添加书签",
        type: 'toggle',
        default: true,
        group: "输出",
        help: "创建指向每个合并文件第一页的顶级大纲条目。将其关闭以进行除了页面之外不添加任何内容的合并。",
      },
      {
        key: 'blankBetween',
        label: "文件之间的空白页",
        type: 'toggle',
        default: false,
        group: "输出",
        help: "间隔物采用其前面的页面的尺寸和方向，因此混合尺寸的文件仍然可以正确打印。",
      },
    ],
    validate: (_values, { fileCount }) =>
      fileCount < 2 ? 'Add at least two PDF files to merge.' : null,
    async run(context) {
      const inputs = await openInputs(context);
      const notes = createNotes();
      noteRepeated(inputs, notes);
      const target = await newPDF();
      const marks: { title: string; page: number }[] = [];
      const copies: PageCopyMap[] = [];
      const sheetSizes = new Set<string>();
      for (let i = 0; i < inputs.length; i++) {
        throwIfAborted(context.signal);
        const input = inputs[i];
        const start = target.getPageCount();
        marks.push({ title: input.name, page: start });
        const copied = await target.copyPages(input.doc, resolvePages('all', input.pageCount));
        // Source page index → merged index. The blank spacer is appended after
        // this file's own pages, so the run of offsets stays contiguous.
        const mapping = new Map<number, number>();
        for (let page = 0; page < copied.length; page++) mapping.set(page, start + page);
        copies.push({ doc: input.doc, mapping });
        for (const page of copied) {
          target.addPage(page);
          const box = visibleBox(page);
          sheetSizes.add(`${Math.round(box.width)}x${Math.round(box.height)}`);
        }
        if (booleanValue(context.values, 'blankBetween') && i < inputs.length - 1) {
          const size = visibleBox(target.getPage(start));
          target.addPage([size.width, size.height]);
        }
        context.progress((i + 1) / inputs.length, `Added ${input.name}`);
      }
      if (target.getPageCount() === 0) {
        throw new ToolInputError('NO_PAGES', "您添加的文件都没有页面。", {
          hint: "检查队列 — 损坏的文件可能会丢失每一页。",
        });
      }
      if (sheetSizes.size > 1) {
        notes.add(
          `The merged file keeps ${sheetSizes.size} different page sizes, because each source page kept its own. Choose "Fix page size" afterwards if you need one size.`,
        );
      }
      const outlineSource = inputs.find((input) => hasOutlines(input.doc));
      // With the per-file entries switched off the source trees are re-pointed
      // and carried instead; with them on they are replaced, which is what the
      // tool advertises, so the note says how to get the other behaviour.
      const perFileBookmarks = booleanValue(context.values, 'bookmarks', true);
      if (outlineSource && perFileBookmarks) {
        notes.add(
          `"${outlineSource.name}" already had bookmarks: only the new per-file entries were written, and ${outlineSource.name}’s own tree was left behind. Switch "Add a bookmark for each file" off to bring the original bookmarks along instead.`,
        );
      }
      const fidelity = await carryPageFurniture(target, copies, { outlines: !perFileBookmarks });
      if (!perFileBookmarks) {
        notePageCopy(copies.map((copy) => copy.doc), fidelity, notes);
      }
      if (perFileBookmarks) {
        const written = writeFlatOutline(target, marks);
        if (written === 0) {
          notes.add('Bookmarks could not be written for these files, so the merge continued without them.');
        }
      }
      target.setProducer('BrowserSnip');
      return pdfOut(
        target,
        notes,
        `已合并 ${inputs.length} 个文件，共 ${target.getPageCount()} 页。`,
      );
    },
  },

  {
    id: 'split',
    name: "分割PDF",
    description: "分成范围、每页、奇数/偶数或固定大小的块",
    icon: '✂️',
    category: 'organize',
    keywords: ['divide', 'separate', 'extract', 'ranges'],
    outputSuffix: '_split',
    actionLabel: "分裂",
    promise: 'Separate PDFs — one per range, page, side or chunk — downloaded together.',
    notes: [PAGE_COPY_NOTE],
    fields: [
      {
        key: 'mode',
        label: "分割依据",
        type: 'segmented',
        default: 'ranges',
        group: "分割依据",
        options: [
          { value: 'ranges', label: "范围" },
          { value: 'every', label: "每一页" },
          { value: 'oddEven', label: "奇/偶" },
          { value: 'chunks', label: "固定块" },
        ],
      help: "选择文件的剪切方式。每种模式都会生成单独的 PDF；他们都没有编辑原始文件。",
    },
      {
        key: 'ranges',
        label: "页面范围",
        type: 'text',
        default: '',
        placeholder: '1-3, 5, 8-10',
        group: "分割依据",
        help: "每个范围成为其自己的PDF。页码根据本文档进行检查。",
        when: (v) => v.mode === 'ranges',
      },
      CHUNK_SIZE,
      {
        key: 'oddEven',
        label: "片材的哪一面",
        type: 'select',
        default: 'both',
        group: "分割依据",
        options: [
          { value: 'both', label: "两个文件（奇数和偶数）" },
          { value: 'odd', label: "仅限奇数页" },
          { value: 'even', label: "仅限偶数页" },
        ],
        when: (v) => v.mode === 'oddEven',
        help: "手动双面打印机需要两个文件；一个文件仅用于先打印一面。",
      },
    ],
    validate(values) {
      const mode = stringValue(values, 'mode', 'ranges');
      if (mode === 'ranges' && stringValue(values, 'ranges').trim() === '') {
        return 'Enter at least one page range, for example 1-3, or choose a different split mode.';
      }
      return null;
    },
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const mode = stringValue(context.values, 'mode', 'ranges');
      const total = input.pageCount;
      const groups: { name: string; pages: number[] }[] = [];

      if (mode === 'every') {
        for (let i = 0; i < total; i++) groups.push({ name: `page-${i + 1}`, pages: [i] });
      } else if (mode === 'oddEven') {
        const which = stringValue(context.values, 'oddEven', 'both');
        const sides = [
          { key: 'odd', file: 'odd-pages', pages: resolvePages('odd', total) },
          { key: 'even', file: 'even-pages', pages: resolvePages('even', total) },
        ];
        for (const side of sides) {
          if (which !== 'both' && which !== side.key) continue;
          if (side.pages.length === 0) {
            // E13: a one-page document has no even side. Say so instead of
            // shipping a PDF whose only content is pdf-lib's filler page.
            notes.add(`This document has no ${side.key} pages, so no ${side.file} file was made.`);
            continue;
          }
          groups.push({ name: side.file, pages: side.pages });
        }
      } else if (mode === 'chunks') {
        const size = numberOf(context.values, CHUNK_SIZE, notes);
        if (size >= total) {
          notes.add(`The chunk size (${size}) is at least the document's length, so all ${pageCountLabel(total)} land in one file.`);
        }
        for (let i = 0; i < total; i += size) {
          const pages: number[] = [];
          for (let p = i; p < Math.min(i + size, total); p++) pages.push(p);
          groups.push({
            name: rangeName(pages[0] + 1, pages[pages.length - 1] + 1),
            pages,
          });
        }
      } else {
        const spec = stringValue(context.values, 'ranges');
        for (const chunk of spec.split(/[,\n;]+/)) {
          const trimmed = chunk.trim();
          if (!trimmed) continue;
          // Per-chunk so the refusal names the range that is wrong *and* the
          // page count that makes it wrong (E6, E15).
          const pages = selection({ pages: trimmed }, total, { verb: 'split out' });
          groups.push({
            name: rangeName(pages[0] + 1, pages[pages.length - 1] + 1),
            pages,
          });
        }
        if (groups.length === 0) {
          throw new ToolInputError('NO_PAGES', `"${spec}" did not contain a usable page range.`, {
            hint: `Write ranges like 1-3, 5, ${total}- using page numbers up to ${total}.`,
          });
        }
        const covered = new Set(groups.flatMap((group) => group.pages));
        if (covered.size < total) {
          notes.add(
            `These ranges cover ${pageCountLabel(covered.size)} of the document's ${pageCountLabel(total)}; the pages not listed (${formatPages(resolvePages('all', total).filter((p) => !covered.has(p)))}) are not in any output file.`,
          );
        }
      }

      if (groups.length === 0) {
        throw new ToolInputError('NO_PAGES', "这种分割根本不会产生任何文件。", {
          hint: `Pick a range inside 1-${total}, or switch to "Every page".`,
        });
      }

      const files: { blob: Blob; name: string }[] = [];
      const used = new Set<string>();
      const stem = safeStem(input.name);
      // A bookmark belongs to exactly one output file, so counting what every
      // file carried says what the *job* lost — and the ranges are disjoint, so
      // no bookmark is counted twice.
      let carriedBookmarks = 0;
      for (let i = 0; i < groups.length; i++) {
        throwIfAborted(context.signal);
        const group = groups[i];
        const doc = await collectPages([{ doc: input.doc, pages: group.pages }]);
        carriedBookmarks += doc.fidelity.bookmarks;
        const bytes = await savePDF(doc.doc);
        files.push({
          blob: new Blob([bytes], { type: 'application/pdf' }),
          name: uniqueName(used, `${stem}_${group.name}.pdf`),
        });
        context.progress((i + 1) / groups.length, `Wrote ${group.name}`);
      }
      const splitOutline = outlineSize(input.doc);
      noteDroppedBookmarks(
        splitOutline,
        carriedBookmarks,
        Math.max(0, splitOutline - carriedBookmarks),
        notes,
      );
      noteFormFields(listFormFields(input.doc).length, notes);
      return filesOut(files, notes, `Created ${files.length} file${files.length === 1 ? '' : 's'} from ${pageCountLabel(total)}.`);
    },
  },

  {
    id: 'extract-pages',
    name: "提取页面",
    description: "将所选页面拉出作为新的 PDF，或每页一个 PDF",
    icon: '📤',
    category: 'organize',
    keywords: ['keep', 'separate', 'pull'],
    outputSuffix: '_extracted.pdf',
    surface: 'pages',
    actionLabel: "提取物",
    promise: 'A new PDF with only the pages you picked, in the order you typed them.',
    notes: [PAGE_COPY_NOTE],
    fields: [
      ALL_PAGES,
      {
        key: 'mergeIntoOne',
        label: "合并为单个PDF",
        type: 'toggle',
        default: true,
        group: "输出",
        help: "关闭此选项可为每个选定页面获取一个单独的文件。",
      },
    ],
    validate(values) {
      if (stringValue(values, 'pages', '').trim() === '') return 'Choose which pages to extract.';
      return null;
    },
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const pages = selection(context.values, input.pageCount, { verb: 'extract' });
      // Every sheet, in order: nothing was taken out of anything, so the sentence
      // says what happened rather than "Extracted 4 pages of 4 pages" beside its
      // own contradiction. The note keeps to the page order and page count, which
      // is what this run does hold — `notePageCopy` below names whatever else the
      // rebuild left behind.
      const whole = pages.length === input.pageCount && pages.every((entry, index) => entry === index);
      if (whole) {
        notes.add(`You selected every page, so the new file holds ${pageCountLabel(pages.length)} in the original order.`);
      }
      if (booleanValue(context.values, 'mergeIntoOne', true)) {
        const built = await collectPages([{ doc: input.doc, pages }]);
        notePageCopy([input.doc], built.fidelity, notes);
        return pdfOut(
          built.doc,
          notes,
          whole
            ? `Copied all ${pageCountLabel(pages.length)} into a new file.`
            : `Extracted ${pageCountLabel(pages.length)} of ${pageCountLabel(input.pageCount)}.`,
        );
      }
      const stem = safeStem(input.name);
      const used = new Set<string>();
      const files: { blob: Blob; name: string }[] = [];
      let carriedBookmarks = 0;
      for (let i = 0; i < pages.length; i++) {
        throwIfAborted(context.signal);
        const doc = await collectPages([{ doc: input.doc, pages: [pages[i]] }]);
        carriedBookmarks += doc.fidelity.bookmarks;
        const bytes = await savePDF(doc.doc);
        files.push({
          blob: new Blob([bytes], { type: 'application/pdf' }),
          name: uniqueName(used, `${stem}_page-${pages[i] + 1}.pdf`),
        });
        context.progress((i + 1) / pages.length, `Page ${pages[i] + 1}`);
      }
      const singleOutline = outlineSize(input.doc);
      noteDroppedBookmarks(
        singleOutline,
        carriedBookmarks,
        Math.max(0, singleOutline - carriedBookmarks),
        notes,
      );
      noteFormFields(listFormFields(input.doc).length, notes);
      return filesOut(files, notes, `Created ${files.length} single-page files.`);
    },
  },

  {
    id: 'remove-pages',
    name: "删除页面",
    description: "删除您选择的页面并保留其他所有内容",
    icon: '🗑️',
    category: 'organize',
    keywords: ['delete', 'drop', 'discard'],
    outputSuffix: '_trimmed.pdf',
    surface: 'pages',
    actionLabel: "删除页面",
    promise: 'Your PDF with the chosen pages taken out; every other page untouched.',
    notes: [PAGE_COPY_NOTE],
    fields: [ALL_PAGES],
    validate(values) {
      const spec = stringValue(values, 'pages', '').trim();
      if (spec === '') return 'Choose the pages to delete, or the whole document disappears.';
      if (spec.toLowerCase() === 'all') {
        return 'Choose the pages to delete — deleting every page would leave an empty PDF.';
      }
      return null;
    },
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const drop = new Set(selection(context.values, input.pageCount, { verb: 'delete' }));
      const keep = resolvePages('all', input.pageCount).filter((p) => !drop.has(p));
      if (keep.length === 0) {
        throw new ToolInputError(
          'NO_PAGES',
          `Deleting pages ${formatPages([...drop])} would remove all ${pageCountLabel(input.pageCount)}, leaving an empty PDF.`,
          { hint: "保留至少一页，或使用“提取页面”仅保存其他页面。" },
        );
      }
      const doc = await collectPages([{ doc: input.doc, pages: keep }]);
      notePageCopy([input.doc], doc.fidelity, notes);
      return pdfOut(
        doc.doc,
        notes,
        `Removed ${pageCountLabel(drop.size)}, kept ${pageCountLabel(keep.length)}.`,
      );
    },
  },

  {
    id: 'organize',
    name: "组织PDF",
    description: "拖动以重新排序，然后旋转、复制、删除或插入空白页",
    icon: '📋',
    category: 'organize',
    keywords: ['reorder', 'arrange', 'move', 'duplicate'],
    outputSuffix: '_organized.pdf',
    surface: 'custom',
    actionLabel: "申请订单",
    promise: 'A rebuilt PDF in the order, rotation and duplication you set. The original file is never modified.',
    notes: [
      'Pages are copied, so a page can appear more than once in the output.',
      'A page with no `r90`/`r180`/`r270` keeps the rotation it already had; `r0` straightens it.',
      'The page grid writes this plan for you. Type it only if you want to.',
    ],
    fields: [
      {
        key: 'pageOrder',
        label: "页面顺序",
        type: 'text',
        default: '',
        placeholder: "自动从页面网格",
        group: "计划",
        help: "逗号分隔的源页码，可选地以r90/r180/r270作为后缀来旋转，范围如2-5，或“空白”。",
      },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const raw = context.values.pageOrder;
      const plan = planFromValues(raw, input.pageCount, notes);
      const target = await newPDF();
      let planIndex = 0;
      let stamped = 0;
      // Source page → the sheet it landed on. A page used twice keeps its first
      // copy as the bookmark target, and a blank sheet claims no index.
      const mapping = new Map<number, number>();
      for (const item of plan) {
        throwIfAborted(context.signal);
        if (item.blank) {
          const neighbour =
            planIndex > 0
              ? target.getPage(planIndex - 1)
              : input.doc.getPage(Math.max(0, Math.min(input.pageCount - 1, plan.find((p) => !p.blank)?.page ?? 0)));
          const size = neighbour ? visibleBox(neighbour) : { width: 595.28, height: 841.89 };
          target.insertPage(planIndex, [size.width, size.height]);
        } else {
          const [page] = await target.copyPages(input.doc, [item.page]);
          if (!mapping.has(item.page)) mapping.set(item.page, planIndex);
          // Only re-set the rotation when the plan says so, so a `/Rotate 90`
          // page is not silently flattened to 0 by being reordered (E9).
          if (item.rotate !== null) page.setRotation(degrees(normaliseRotation(item.rotate)));
          target.insertPage(planIndex, page);
        }
        planIndex += 1;
        stamped += 1;
        context.progress(
          stamped / plan.length,
          item.blank ? 'Inserted a blank page' : `Placed source page ${item.page + 1}`,
        );
      }
      if (target.getPageCount() === 0) {
        throw new ToolInputError('NO_PAGES', "新的页序为空。", {
          hint: "添加至少一个页面标记（例如1）或将图块拖回到网格中。",
        });
      }
      const blanksOnly = plan.every((item) => item.blank);
      if (blanksOnly) {
        notes.add(`The output holds only the ${plan.length} blank sheets you asked for; none of this document’s pages are in it.`);
      }
      if (distinctSizes(input.doc, resolvePages('all', input.pageCount)) > 1) {
        notes.add('This document mixes page sizes; every page kept its own size and each blank matches the page beside it.');
      }
      const isIdentity =
        plan.length === input.pageCount &&
        plan.every((item, index) => !item.blank && item.page === index && (item.rotate === null || item.rotate === rotationOf(input.doc.getPage(index))));
      if (isIdentity) {
        notes.add('The order you set matches the document as it is, so the output is a copy rather than a rearrangement.');
      }
      const fidelity = await carryPageFurniture(target, [{ doc: input.doc, mapping }]);
      notePageCopy([input.doc], fidelity, notes);
      return pdfOut(target, notes, `Rebuilt the document with ${pageCountLabel(target.getPageCount())}.`);
    },
  },

  {
    id: 'rotate',
    name: "旋转PDF",
    description: "将页面翻页 90°、180° 或 270° — 整个文档或所选内容",
    icon: '🔄',
    category: 'organize',
    keywords: ['turn', 'landscape', 'portrait', 'orientation'],
    outputSuffix: '_rotated.pdf',
    surface: 'pages',
    actionLabel: "旋转",
    promise: 'The same PDF with the pages you chose turned by 90°, 180° or 270°. Only the orientation changes — nothing is redrawn.',
    notes: [
      'Rotation is stored on the page, so text, links and bookmarks stay exactly where they were.',
      'The turn is added to each page’s existing rotation: a page already at 90° ends at 180°.',
    ],
    fields: [
      {
        key: 'degrees',
        label: "旋转",
        type: 'segmented',
        default: 90,
        group: "旋转",
        options: [
          { value: 90, label: '90° →' },
          { value: 180, label: '180°' },
          { value: 270, label: '270° ←' },
        ],
      help: "添加到每个页面的现有旋转，因此四次 90° 将页面返回到其开始的位置。",
    },
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const asked = numberValue(context.values, 'degrees', 90);
      const delta = normaliseRotation(asked);
      // E15: announce a correction only when one happened. A stored `/Rotate` is
      // a multiple of 90, so the value to compare against is the request itself;
      // comparing it against that request rounded to the nearest half turn made
      // an ordinary 90° run warn “90° became 90°”.
      if (normalise360(asked) !== delta) {
        notes.add(`Rotation must be 90°, 180° or 270°: ${asked}° became ${delta}°.`);
      }
      if (delta === 0) {
        notes.add('A 0° or 360° turn leaves every page where it was, so the output is a copy.');
      }
      const pages = selection(context.values, input.pageCount, { verb: 'rotate' });
      const all = input.doc.getPages();
      let straightened = 0;
      for (let i = 0; i < pages.length; i++) {
        throwIfAborted(context.signal);
        const page = all[pages[i]];
        const before = rotationOf(page);
        page.setRotation(degrees(normaliseRotation(before + delta)));
        if (rotationOf(page) === 0 && before !== 0) straightened += 1;
        context.progress((i + 1) / pages.length, `Rotated page ${pages[i] + 1}`);
      }
      if (straightened > 0) {
        notes.add(`${straightened} of the selected ${pageCountLabel(pages.length)} were upside-down or sideways before this turn and are now upright.`);
      }
      const doc = await savable(input, notes);
      const untouched = input.pageCount - pages.length;
      return pdfOut(doc, notes, `Rotated ${pageCountLabel(pages.length)} by ${delta}°${untouched > 0 ? `, left ${pageCountLabel(untouched)} alone` : ''}.`);
    },
  },

  {
    id: 'rotate-custom',
    name: "按自定义度数旋转",
    description: "以任意角度旋转页面内容，而不仅仅是 90° 步长",
    icon: '↩️',
    category: 'organize',
    keywords: ['skew', 'straighten', 'angle', 'de-angle'],
    outputSuffix: '_rotated.pdf',
    actionLabel: "转动",
    promise: 'Pages turned by any angle as vector content — text stays selectable, nothing is rasterised.',
    notes: [
      'The page box is rewritten, so the stored /Rotate is set to 0 and the turn is baked into the content.',
      FLATTEN_NOTE,
    ],
    fields: [
      ANGLE,
      {
        key: 'fit',
        label: "页面尺寸",
        type: 'select',
        default: 'grow',
        group: "旋转",
        options: [
          { value: 'grow', label: "增大页面，这样就不会剪切任何内容" },
          { value: 'keep', label: "保持原始页面尺寸（可能会裁剪角）" },
        ],
      help: "非直角的角度将拐角转向原始片材之外。",
    },
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const angle = numberOf(context.values, ANGLE, notes);
      const grow = stringValue(context.values, 'fit', 'grow') === 'grow';
      const chosen = new Set(selection(context.values, input.pageCount, { verb: 'turn' }));
      // The turn is baked into a freshly sized page instead of added to the old
      // one, so a `/Rotate 90` sheet still displays the way it did before the
      // extra angle (E9) and the pages that were not chosen are copied verbatim.
      const target = await newPDF();
      let cut = 0;
      for (let index = 0; index < input.pageCount; index++) {
        throwIfAborted(context.signal);
        const source = input.doc.getPage(index);
        if (!chosen.has(index)) {
          const [copy] = await target.copyPages(input.doc, [index]);
          target.addPage(copy);
          continue;
        }
        const shown = visibleBox(source);
        const needed = rotatedBoxSize(shown.width, shown.height, angle);
        const size = grow ? needed : shown;
        const page = target.addPage([size.width, size.height]);
        await stamp(
          target,
          page,
          source,
          { x: 0, y: 0, width: size.width, height: size.height },
          { angle, fit: 'exact' },
        );
        if (needed.width > size.width + 0.5 || needed.height > size.height + 0.5) cut += 1;
        context.progress((index + 1) / input.pageCount, `Turned page ${index + 1}`);
      }
      if (cut > 0) {
        notes.add(`Keeping the original page size cut the corners off ${pageCountLabel(cut)} after the turn. Choose "Grow the page" to keep everything.`);
      }
      if (normalise360(angle) % 90 !== 0) {
        noteRebuildLoss('A custom-angle turn', input.doc, [...chosen], notes);
      }
      const left = input.pageCount - chosen.size;
      return pdfOut(
        target,
        notes,
        `Turned ${pageCountLabel(chosen.size)} by ${angle}° clockwise${left > 0 ? `, left ${pageCountLabel(left)} as they were` : ''}.`,
      );
    },
  },

  {
    id: 'reverse-pages',
    name: "反向页面",
    description: "翻转整个文档的页面顺序",
    icon: '🔃',
    category: 'organize',
    keywords: ['invert order', 'backwards', 'descending'],
    outputSuffix: '_reversed.pdf',
    notes: [PAGE_COPY_NOTE],
    actionLabel: "反向",
    promise: 'The same pages in the opposite order, as a new PDF.',
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const pages = resolvePages('all', input.pageCount);
      if (input.pageCount < 2) {
        notes.add(`This document has ${pageCountLabel(input.pageCount)}, so reversing changes nothing — the output is a copy.`);
      }
      // The copy re-points every bookmark at the sheet its page became, so the
      // reversed file keeps the outline — it just walks the document backwards.
      const doc = await collectPages([{ doc: input.doc, pages: [...pages].reverse() }]);
      notePageCopy([input.doc], doc.fidelity, notes);
      return pdfOut(doc.doc, notes, `Reversed ${pageCountLabel(pages.length)}.`);
    },
  },

  {
    id: 'add-blank-page',
    name: "添加空白页",
    description: "在任意页面的开头、结尾或后面插入空白页",
    icon: '📄',
    category: 'organize',
    keywords: ['insert', 'empty', 'spacer', 'sheet'],
    outputSuffix: '_with_blanks.pdf',
    actionLabel: "添加空白",
    promise: 'Your PDF with blank sheets inserted where you choose, sized to the page beside them or to the sheet size you pick.',
    notes: [PAGE_COPY_NOTE],
    fields: [
      {
        key: 'position',
        label: "位置",
        type: 'select',
        default: 'end',
        group: "位置",
        options: [
          { value: 'start', label: "第一页之前" },
          { value: 'end', label: "最后一页之后" },
          { value: 'after', label: "特定页面之后" },
          { value: 'before', label: "特定页面之前" },
        ],
      help: "第 3 页后的两个空白将它们插入到第 3 页和第 4 页之间，计入您放入的文档中。",
    },
      ANCHOR,
      BLANK_COUNT,
      { key: 'size', label: "空白纸张尺寸", type: 'select', default: 'same', options: PAGE_SIZE_OPTIONS, group: "尺寸", help: "与源相同匹配其旁边的页面，这使得混合尺寸文档打印保持方形。" },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const count = numberOf(context.values, BLANK_COUNT, notes);
      const position = stringValue(context.values, 'position', 'end');
      const total = input.pageCount;
      const usesAnchor = position === 'after' || position === 'before';
      const anchor = usesAnchor
        ? clampToPage('Page number', numberValue(context.values, 'anchor', 1), total, notes)
        : position === 'start'
          ? 1
          : total;
      const sizeSpec = stringValue(context.values, 'size', 'same');
      // A blank belongs with the sheet beside it, so mixed-size documents keep
      // making sense and the inserted page is not always page 1's size (E8).
      const neighbourIndex = Math.max(0, Math.min(total - 1, position === 'before' ? anchor - 2 : anchor - 1));
      const neighbour = visibleBox(input.doc.getPage(neighbourIndex));
      const size: [number, number] =
        sizeSpec === 'same' ? [neighbour.width, neighbour.height] : resolvePageSize(sizeSpec);
      const target = await newPDF();
      const all = await target.copyPages(input.doc, resolvePages('all', total));
      for (const page of all) target.addPage(page);
      const insertAt = insertPosition(position, target.getPageCount(), anchor);
      for (let i = 0; i < count; i++) {
        throwIfAborted(context.signal);
        target.insertPage(insertAt + i, size);
        context.progress((i + 1) / count, `Inserted blank page ${i + 1}`);
      }
      if (sizeSpec === 'same' && distinctSizes(input.doc, resolvePages('all', total)) > 1) {
        notes.add(`This document mixes page sizes, so the blank sheets match page ${neighbourIndex + 1} beside them.`);
      }
      // Every original page is present, shifted by the blanks that landed before
      // it, so no bookmark can be lost here — but the field list still is.
      const spacerMapping = new Map<number, number>();
      for (let page = 0; page < total; page++) {
        spacerMapping.set(page, page < insertAt ? page : page + count);
      }
      const fidelity = await carryPageFurniture(target, [
        { doc: input.doc, mapping: spacerMapping },
      ]);
      notePageCopy([input.doc], fidelity, notes);
      return pdfOut(
        target,
        notes,
        `Inserted ${pageCountLabel(count)} at position ${insertAt + 1} — the file now has ${pageCountLabel(target.getPageCount())}.`,
      );
    },
  },

  {
    id: 'alternate-merge',
    name: "交替和混合页面",
    description: "通过从每个文件中轮流获取页面来合并 PDF",
    icon: '🎲',
    category: 'organize',
    keywords: ['interleave', 'shuffle', 'zip', 'round robin'],
    multiFile: true,
    minFiles: 2,
    outputSuffix: '_alternated.pdf',
    actionLabel: "混合页面",
    promise: 'One PDF that takes pages from each file in turn until they run out.',
    notes: [PAGE_COPY_NOTE],
    fields: [
      {
        key: 'pattern',
        label: "图案",
        type: 'select',
        default: '1-1',
        group: "图案",
        options: [
          { value: '1-1', label: "每个文件依次一页" },
          { value: '2-2', label: "每个文件依次有两页" },
          { value: 'reverse-alternate', label: "备用的、后来的文件被逆转" },
        ],
        help: "按队列顺序混合。 “反转后的文件”将第一个文件从上到下保留，并将其余文件从后到前翻转 - 当背面从最后一页开始时，双面扫描需要的形状。",
      },
    ],
    validate: (_v, { fileCount }) =>
      fileCount < 2 ? 'Add at least two PDF files to alternate between.' : null,
    async run(context) {
      const inputs = await openInputs(context);
      const notes = createNotes();
      noteRepeated(inputs, notes);
      const pattern = stringValue(context.values, 'pattern', '1-1');
      const runLength = pattern === '2-2' ? 2 : 1;
      const queues = inputs.map((input, index) => {
        const pages = resolvePages('all', input.pageCount);
        // Only the files after the first are turned around: reversing the front
        // block as well would print the document backwards while the option says
        // it reverses the second file (E9's "do what the label says").
        const reversed = pattern === 'reverse-alternate' && index > 0;
        return reversed ? [...pages].reverse() : pages;
      });
      const plan: { source: number; page: number }[] = [];
      const cursors = queues.map(() => 0);
      const longest = Math.max(...queues.map((queue) => queue.length));
      while (cursors.some((cursor, index) => cursor < queues[index].length)) {
        queues.forEach((queue, index) => {
          for (let k = 0; k < runLength && cursors[index] < queue.length; k++) {
            plan.push({ source: index, page: queue[cursors[index]] });
            cursors[index] += 1;
          }
        });
      }
      if (plan.length === 0) {
        throw new ToolInputError('NO_PAGES', "您添加的文件都没有要混合的页面。", {
          hint: "检查队列 — 损坏的文件可能会丢失每一页。",
        });
      }
      if (queues.some((queue) => queue.length !== longest)) {
        const detail = inputs
          .map((input, index) => `"${input.name}" ${queues[index].length}`)
          .join(', ');
        notes.add(
          `The files are unequal (pages per file: ${detail}), so the tail of the mix comes from the longer file${longest === 1 ? '' : 's'} only.`,
        );
      }
      const target = await newPDF();
      const copies: PageCopyMap[] = inputs.map((item) => ({
        doc: item.doc,
        mapping: new Map<number, number>(),
      }));
      for (let i = 0; i < plan.length; i++) {
        if (i % 25 === 0) throwIfAborted(context.signal);
        const item = plan[i];
        // A copied PDFPage can only be attached once, so each output page is
        // copied fresh rather than reused from a cache.
        const [page] = await target.copyPages(inputs[item.source].doc, [item.page]);
        target.addPage(page);
        const mapping = copies[item.source].mapping;
        if (!mapping.has(item.page)) mapping.set(item.page, i);
        context.progress((i + 1) / plan.length, `Page ${i + 1}`);
      }
      if (distinctSizes(target, resolvePages('all', target.getPageCount())) > 1) {
        notes.add('Each page kept its own size, so the mixed file has mixed page sizes. "Fix page size" can even them out afterwards.');
      }
      const fidelity = await carryPageFurniture(target, copies);
      notePageCopy(copies.map((copy) => copy.doc), fidelity, notes);
      return pdfOut(target, notes, `Mixed ${pageCountLabel(plan.length)} from ${inputs.length} files.`);
    },
  },

  {
    id: 'duplex-collate',
    name: "双面整理",
    description: "将正面/背面扫描块重新排序为打印顺序",
    icon: '🗂️',
    category: 'organize',
    keywords: ['collate', 'scanner', 'simplex', 'back side'],
    outputSuffix: '_collated.pdf',
    actionLabel: "整理",
    promise: 'A re-ordered PDF where each front page is followed by its own back page.',
    notes: [PAGE_COPY_NOTE],
    fields: [
      {
        key: 'backReversed',
        label: "后半部分被反向扫描",
        type: 'toggle',
        default: true,
        group: "扫描顺序",
        help: "大多数单通道双面扫描仪输出背面颠倒且最后一页在前。",
      },
      OFFSET,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const total = input.pageCount;
      if (total < 2) {
        notes.add(`A ${pageCountLabel(total)} document cannot be collated — there is no back block to interleave, so the output is a copy.`);
      }
      const offsetField = { ...OFFSET, max: Math.max(1, Math.ceil(total / 2)) };
      const offset = numberOf(context.values, offsetField, notes);
      const half = Math.ceil(total / 2);
      const all = resolvePages('all', total);
      const front = all.slice(0, half);
      const back = all.slice(Math.min(total, half + offset));
      if (booleanValue(context.values, 'backReversed', true)) back.reverse();
      const interleaved: number[] = [];
      for (let i = 0; i < Math.max(front.length, back.length); i++) {
        if (i < front.length) interleaved.push(front[i]);
        if (i < back.length) interleaved.push(back[i]);
      }
      const seen = new Set<number>();
      const duplicates = new Set<number>();
      for (const page of interleaved) {
        if (seen.has(page)) duplicates.add(page);
        seen.add(page);
      }
      const missing = all.filter((page) => !seen.has(page));
      if (missing.length > 0) {
        notes.add(
          `This collation leaves ${pageCountLabel(missing.length)} out (${formatPages(missing)}): an offset of ${offset} drops the pages between the two blocks.`,
        );
      }
      if (duplicates.size > 0) {
        notes.add(`The plan repeats ${pageCountLabel(duplicates.size)} (${formatPages([...duplicates])}) — reduce the offset if that is not what you meant.`);
      }
      if (total % 2 === 1) {
        notes.add(`An odd ${pageCountLabel(total)} scan splits ${half} + ${total - half}, so the last sheet has no back page.`);
      }
      const doc = await collectPages([{ doc: input.doc, pages: interleaved }]);
      notePageCopy([input.doc], doc.fidelity, notes);
      return pdfOut(
        doc.doc,
        notes,
        `Collated ${pageCountLabel(interleaved.length)} from a ${front.length} + ${back.length} scan.`,
      );
    },
  },

  {
    id: 'overlay-pdf',
    name: "PDF覆盖",
    description: "将一个 PDF 压印或置于另一个 PDF 上",
    icon: '🎭',
    category: 'organize',
    keywords: ['stamp', 'letterhead', 'watermark file', 'underlay'],
    multiFile: true,
    minFiles: 2,
    maxFiles: 2,
    outputSuffix: '_overlaid.pdf',
    actionLabel: "覆盖",
    promise: 'The base PDF with a page from the second file stamped over — or behind — every sheet.',
    notes: [
      'The first file in the queue is the base; the second is the stamp.',
      FLATTEN_NOTE,
    ],
    fields: [
      {
        key: 'mode',
        label: "模式",
        type: 'segmented',
        default: 'overlay',
        group: "放置",
        options: [
          { value: 'overlay', label: "在顶部（覆盖）" },
          { value: 'underlay', label: "后面（垫层）" },
        ],
      help: "顶部覆盖其下方的页面。后面将印章置于现有墨水下方，只有透明区域显示它。",
    },
      {
        key: 'mapping',
        label: "每个基页为哪个邮票页",
        type: 'select',
        default: 'same',
        group: "放置",
        options: [
          { value: 'same', label: "相同页码" },
          { value: 'first', label: "始终是第一张邮票页" },
          { value: 'last', label: "始终是最后一张邮票页" },
        ],
        help: "当印记文件比基础文件短时，其最后一页被重新用于其余部分。当它更长时，多余的邮票页就不会被使用。",
      },
      OPACITY,
      SCALE,
    ],
    validate: (_v, { fileCount }) =>
      fileCount === 2 ? null : 'Add exactly two PDFs: the base document first, then the one to overlay.',
    async run(context) {
      const inputs = await openInputs(context);
      const notes = createNotes();
      const [base, stampDoc] = inputs;
      if (inputs.length > 2) {
        throw new ToolInputError("OUT_OF_RANGE", `Overlay takes exactly two files; ${inputs.length} were added.`, {
          hint: "删除多余的文件，或者首先将它们合并到基础文件中。",
        });
      }
      if (base.name === stampDoc.name && base.bytes.length === stampDoc.bytes.length) {
        notes.add(`"${base.name}" was added twice, so it is being stamped onto itself.`);
      }
      context.log(`Overlaying "${stampDoc.name}" onto "${base.name}" (${stringValue(context.values, 'mode', 'overlay')}).`);
      const target = await cloneForOutput(base.doc);
      const pages = target.getPages();
      const mode = stringValue(context.values, 'mode', 'overlay');
      const mapping = stringValue(context.values, 'mapping', 'same');
      const opacity = numberOf(context.values, OPACITY, notes);
      const scale = numberOf(context.values, SCALE, notes);
      const stampTotal = stampDoc.pageCount;
      let shortBy = 0;
      let skipped = 0;
      for (let i = 0; i < pages.length; i++) {
        throwIfAborted(context.signal);
        const page = pages[i];
        const stampIndex = stampPageIndex(mapping, i, stampTotal);
        if (mapping === 'same' && i >= stampTotal) shortBy += 1;
        const source = stampDoc.doc.getPage(stampIndex);
        // The box is in the base page's own space: a `/Rotate 90` sheet is
        // centred on what the viewer sees, not on the raw MediaBox (E9).
        const box = sourceBox(page);
        const width = box.width * scale;
        const height = box.height * scale;
        const dest: Box = {
          x: box.x + (box.width - width) / 2,
          y: box.y + (box.height - height) / 2,
          width,
          height,
        };
        const drew = mode === 'underlay'
          ? await stampBehind(target, page, () => stamp(target, page, source, dest, { opacity }))
          : await stamp(target, page, source, dest, { opacity });
        if (!drew) skipped += 1;
        context.progress((i + 1) / pages.length, `Page ${i + 1}`);
      }
      if (shortBy > 0) {
        notes.add(
          `The stamp has ${pageCountLabel(stampTotal)} and the base has ${pageCountLabel(pages.length)}, so the last ${pageCountLabel(shortBy)} reused stamp page ${stampTotal}. Choose "Always the first stamp page" to make that deliberate.`,
        );
      }
      if (mapping === 'same' && stampTotal > pages.length) {
        // The mirror of running short: pages 5+ of the stamp file are quietly
        // never drawn, and a letterhead whose back side lives on page 2 would
        // look applied while only page 1 ever was.
        notes.add(
          `The stamp has ${pageCountLabel(stampTotal)} but the base has ${pageCountLabel(pages.length)}, so stamp pages ${formatPages(resolvePages('all', stampTotal).slice(pages.length))} were never used. Choose "Always the last stamp page" to stamp with the final one.`,
        );
      }
      if (skipped === pages.length && pages.length > 0) {
        notes.add('None of the stamp pages had drawable content, so the output is the base document unchanged.');
      }
      if (opacity < 1) {
        notes.add(`The stamp was drawn at ${Math.round(opacity * 100)}% opacity — a viewer prints it lighter, it is not baked in.`);
      }
      noteMixedSizes('Overlay', base.doc, resolvePages('all', base.pageCount), notes);
      return pdfOut(target, notes, `${mode === 'underlay' ? 'Underlaid' : 'Overlaid'} ${pageCountLabel(pages.length)} with "${stampDoc.name}".`);
    },
  },

  {
    id: 'n-up',
    name: 'N-Up PDF',
    description: "将2、4、6或9页放在一张纸上",
    icon: '🗞️',
    category: 'organize',
    keywords: ['multiple pages per sheet', 'shrink', 'handout', 'imposition'],
    outputSuffix: '_nup.pdf',
    actionLabel: "布置",
    promise: 'A new PDF with 2, 4, 6 or 9 source pages scaled into cells on each sheet.',
    notes: [FLATTEN_NOTE],
    fields: [
      {
        key: 'perSheet',
        label: "每张页数",
        type: 'segmented',
        default: 2,
        group: "布局",
        options: [
          { value: 2, label: '2' },
          { value: 4, label: '4' },
          { value: 6, label: '6' },
          { value: 9, label: '9' },
        ],
      help: "页面按比例缩小以适合单元格，因此密集布局上的小字体确实变得更小。",
    },
      { key: 'sheetSize', label: "纸张尺寸", type: 'select', default: 'a4', options: PAGE_SIZE_OPTIONS.slice(1), group: "布局", help: "足够大以使得减少的页面保持可读：A4上的两页A4将字体尺寸减半。" },
      { key: 'landscape', label: "横向片材", type: 'toggle', default: true, group: "布局",
        help: "旋转纸张，这改变单元格的排列方式而不是页面的排序方式。",
      },
      {
        key: 'order',
        label: "填写订单",
        type: 'segmented',
        default: 'across',
        group: "布局",
        options: [
          { value: 'across', label: "横过然后向下" },
          { value: 'down', label: "向下然后穿过" },
        ],
      help: "沿着一行从左到右横向填充； down 首先填充每一列。选择与您切割纸张的方式相匹配的选项。",
    },
      GUTTER,
      MARGIN,
      { key: 'border', label: "每页周围的细线", type: 'toggle', default: false, group: "间距", help: "每个单元边缘处的细线，因此修剪后的布局仍然显示每个页面结束的位置。" },
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const source = selection(context.values, input.pageCount, { fallback: 'all', verb: 'lay out' });
      const perSheet = numberValue(context.values, 'perSheet', 2);
      const [columns, rows] = gridFor(perSheet);
      const sheet = resolvePageSize(stringValue(context.values, 'sheetSize', 'a4'), booleanValue(context.values, 'landscape', true));
      const across = stringValue(context.values, 'order', 'across') === 'across';
      const gutter = numberOf(context.values, GUTTER, notes);
      const margin = numberOf(context.values, MARGIN, notes);
      const border = booleanValue(context.values, 'border');
      const box = gridBox(sheet[0], sheet[1], columns, rows, gutter, margin);
      const first = box(0);
      if (first.width <= 0 || first.height <= 0) {
        throw new ToolInputError(
          "OUT_OF_RANGE",
          `A ${Math.round(margin)} pt margin and ${Math.round(gutter)} pt gutter leave no room for ${columns} × ${rows} cells on a ${Math.round(sheet[0])} × ${Math.round(sheet[1])} pt sheet.`,
          { hint: "降低边距或装订线，或者选择更大的纸张。" },
        );
      }
      const cells: { sheet: number; cell: number; page: number }[] = [];
      source.forEach((page, index) => {
        // Both numbers are relative to the **sheet this page lands on**: `gridBox`
        // derives `row = floor(cell / columns)` from a cell of that sheet's grid,
        // so counting from the start of the run drew every sheet after the first a
        // row below the paper — in the file, off the page (`n-up` of 8 at 4 per
        // sheet: sheet 2's cells 4…7 became rows 2 and 3 of a 2-row grid).
        const slot = index % perSheet;
        const cell = across ? slot : (slot % rows) * columns + Math.floor(slot / rows);
        cells.push({ sheet: Math.floor(index / perSheet), cell, page });
      });
      const target = await sheetDocument(input.doc, sheet, cells, perSheet, box, notes);
      if (border) {
        const grey = rgb(0.8, 0.8, 0.8);
        for (let i = 0; i < target.getPageCount(); i++) {
          const page = target.getPage(i);
          for (let c = 0; c < perSheet; c++) {
            const cell = box(c);
            page.drawRectangle({
              x: cell.x,
              y: cell.y,
              width: cell.width,
              height: cell.height,
              borderColor: grey,
              borderWidth: 0.5,
            });
          }
        }
      }
      noteMixedSizes('N-up', input.doc, source, notes);
      noteRebuildLoss('N-up', input.doc, source, notes);
      const sheets = target.getPageCount();
      const emptyCells = sheets * perSheet - source.length;
      return pdfOut(
        target,
        notes,
        `Placed ${pageCountLabel(source.length)} on ${sheets} sheet${sheets === 1 ? '' : 's'} (${perSheet} per sheet${emptyCells > 0 ? `, ${emptyCells} empty cell${emptyCells === 1 ? '' : 's'} on the last` : ''}).`,
      );
    },
  },

  {
    id: 'booklet',
    name: "PDF 小册子",
    description: "为双面骑马订打印重新排序和拼版页面",
    icon: '📖',
    category: 'organize',
    keywords: ['saddle stitch', 'fold', 'zine', 'imposition', 'print'],
    outputSuffix: '_booklet.pdf',
    actionLabel: "构建小册子",
    promise: 'Fold-ready sheets in saddle-stitch order, padded to a whole number of sheets.',
    notes: [
      'Print duplex, flip on the long edge, then fold in half.',
      FLATTEN_NOTE,
    ],
    fields: [
      { key: 'sheetSize', label: "纸张尺寸", type: 'select', default: 'a4', options: PAGE_SIZE_OPTIONS.slice(1), group: "片材", help: "您打印所用的纸张。每张纸的每一面都有两个小册子页面，因此 A4 纸可制作 A5 小册子 - 选择 A3 纸即可制作完成的 A4 小册子。" },
      { key: 'landscape', label: "横向片材", type: 'toggle', default: true, group: "片材", help: "骑马订纸张根据定义是横向的；此处的肖像打印了一本折叠方式错误的小册子。" },
      {
        key: 'gutter',
        label: "天沟",
        type: 'slider',
        default: 12,
        min: 0,
        max: 72,
        step: 1,
        unit: "pt",
        group: "片材",
      help: "折叠处有额外的空间，因此装订不会吞没文本。添加书脊厚度的一半。",
    },
      {
        key: 'margin',
        label: "保证金",
        type: 'slider',
        default: 12,
        min: 0,
        max: 72,
        step: 1,
        unit: "pt",
        group: "片材",
      help: "每张纸的外边缘处的空间，当您折叠时该空间成为裁切边缘。",
    },
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const source = selection(context.values, input.pageCount, { fallback: 'all', verb: 'make into a booklet' });
      const sheet = resolvePageSize(stringValue(context.values, 'sheetSize', 'a4'), booleanValue(context.values, 'landscape', true));
      const gutter = numberOf(context.values, { ...GUTTER, label: "天沟", default: 12 }, notes);
      const margin = numberOf(context.values, { ...MARGIN, label: "保证金", default: 12 }, notes);
      const pages = [...source];
      // A saddle-stitched sheet carries four pages, so a booklet that is short
      // of a multiple of four has to be padded. There is no option about it: the
      // alternative is dropping the odd pages from the print run, so the padding
      // is unconditional and the run says how much of the last sheet is blank.
      const padTo = Math.ceil(pages.length / 4) * 4;
      while (pages.length < padTo) pages.push(-1);
      const blanks = pages.length - source.length;
      if (blanks > 0) {
        notes.add(`A booklet is made of sheets of four, so ${pageCountLabel(blanks)} were padded in to complete the last sheet.`);
      }
      if (source.length < input.pageCount) {
        const left = resolvePages('all', input.pageCount).filter((page) => !source.includes(page));
        notes.add(
          `A booklet imposes whole sheets, so it carries ${pageCountLabel(source.length)} of this document's ${pageCountLabel(input.pageCount)} — pages ${formatPages(left)} are not in the print run.`,
        );
      }
      const box = (cell: number): Box => {
        const half = sheet[0] / 2;
        const inset = cell === 0 ? margin : gutter;
        const rightInset = cell === 0 ? gutter : margin;
        return {
          x: cell === 0 ? inset : half + rightInset,
          y: margin,
          width: half - inset - rightInset,
          height: sheet[1] - margin * 2,
        };
      };
      if (box(0).width <= 0 || box(0).height <= 0) {
        throw new ToolInputError(
          "OUT_OF_RANGE",
          `A ${Math.round(margin)} pt margin plus a ${Math.round(gutter)} pt fold allowance leaves no printable width on a ${Math.round(sheet[0])} pt sheet.`,
          { hint: "减少边距或折叠余量，或者选择更大的纸张。" },
        );
      }
      const total = pages.length;
      const cells: { sheet: number; cell: number; page: number }[] = [];
      // One loop turn is one physical sheet: the outer pair goes on the front
      // side, the inner pair on the back. They are separate PDF pages because a
      // duplex run prints page 1 on one side of a sheet and page 2 on the other
      // — four cells on one page would stack two booklet pages in each half and
      // leave the back of every sheet blank (E13: the file must match the
      // “printed sides” the sentence counts).
      for (let i = 0; i < total / 4; i++) {
        cells.push({ sheet: 2 * i, cell: 0, page: pages[total - 1 - 2 * i] });
        cells.push({ sheet: 2 * i, cell: 1, page: pages[2 * i] });
        cells.push({ sheet: 2 * i + 1, cell: 0, page: pages[2 * i + 1] });
        cells.push({ sheet: 2 * i + 1, cell: 1, page: pages[total - 2 - 2 * i] });
      }
      const target = await sheetDocument(input.doc, sheet, cells, 2, box, notes);
      noteMixedSizes('The booklet', input.doc, source, notes);
      noteRebuildLoss('The booklet', input.doc, source, notes);
      return pdfOut(
        target,
        notes,
        `Imposed ${pageCountLabel(source.length)} onto ${target.getPageCount()} printed sides on ${Math.ceil(target.getPageCount() / 2)} double-sided sheet${target.getPageCount() > 2 ? 's' : ''}${blanks > 0 ? ` with ${pageCountLabel(blanks)} added` : ''}. Print duplex, flip on long edge.`,
      );
    },
  },

  {
    id: 'combine-single-page',
    name: "合并为单页",
    description: "将每一页缝合成一个连续的卷轴",
    icon: '🧵',
    category: 'organize',
    keywords: ['long image', 'continuous', 'concatenate', 'scroll'],
    outputSuffix: '_combined.pdf',
    actionLabel: "缝合",
    promise: 'One long page (or a few, at the PDF height limit) with every page scaled to the same width.',
    notes: [FLATTEN_NOTE],
    fields: [
      { key: 'gap', label: "页面之间的间隙", type: 'slider', default: 12, min: 0, max: 120, step: 1, unit: "pt", group: "布局", help: "连接页面之间的空间，绘制为空白而不是细线。" },
      {
        key: 'width',
        label: "目标宽度",
        type: 'select',
        default: 'widest',
        group: "布局",
        options: [
          { value: 'widest', label: "最宽的源页面" },
          { value: 'a4', label: "A4宽度" },
          { value: 'letter', label: "字母宽度" },
        ],
      help: "每一页都精确地以这个宽度绘制——较窄的页面被放大以适应它，而不是在两侧留下裸露的边距，因此卷轴自始至终都有一个尺寸。",
    },
      {
        key: 'splitOverflow',
        label: "当达到PDF高度限制时开始新页面",
        type: 'toggle',
        default: true,
        group: "布局",
        help: "PDF页面边缘不能超过14400个单位。关闭此功能会让滚动条从底部开始滚动。",
      },
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const gap = numberOf(context.values, { ...GUTTER, key: 'gap', label: "页面之间的间隙", default: 12, max: 120 }, notes);
      const widthMode = stringValue(context.values, 'width', 'widest');
      const split = booleanValue(context.values, 'splitOverflow', true);
      const source = selection(context.values, input.pageCount, { fallback: 'all', verb: 'stitch' });
      const boxes = source.map((index) => visibleBox(input.doc.getPage(index)));
      const widest = Math.max(...boxes.map((box) => box.width));
      const width = widthMode === 'widest' ? widest : resolvePageSize(widthMode)[0];
      let enlarged = 0;
      let shrunk = 0;
      // A PDF page edge may not exceed 14 400 units, so a long scroll has to
      // overflow onto another sheet — or say plainly that it was cut.
      const maxHeight = split ? PDF_MAX_EDGE : Infinity;
      const target = await newPDF();
      let current: PDFPage | null = null;
      let yFromTop = 0;
      let sheets = 0;
      let blank = 0;
      let clipped = 0;
      for (let i = 0; i < source.length; i++) {
        throwIfAborted(context.signal);
        const box = boxes[i];
        const scale = width / box.width;
        // The sheet is one width, so a page reaches it from whichever side it
        // starts: a wider page is reduced, a narrower one is enlarged. Both are
        // worth saying, and "every page is scaled down" was only half true (E13).
        if (scale > 1.005) enlarged += 1;
        else if (scale < 0.995) shrunk += 1;
        const drawHeight = box.height * scale;
        if (!current || yFromTop + drawHeight > maxHeight) {
          // Each sheet is exactly as tall as the content it carries, capped at
          // the PDF limit; leaving it any taller would print blank paper.
          sheets += 1;
          current = target.addPage([width, Math.min(maxHeight, Math.max(drawHeight, yFromTop - gap))]);
          yFromTop = 0;
        }
        const page = current;
        page.setSize(width, Math.min(maxHeight, Math.max(page.getHeight(), yFromTop + drawHeight)));
        // `yFromTop` is measured down the sheet, and the sheet grows as the
        // scroll goes, so the box is recomputed on every stitch.
        const ok = await stamp(target, page, input.doc.getPage(source[i]), {
          x: 0,
          y: page.getHeight() - yFromTop - drawHeight,
          width,
          height: drawHeight,
        });
        if (!ok) blank += 1;
        if (page.getHeight() < yFromTop + drawHeight - 0.5) clipped += 1;
        yFromTop += drawHeight + gap;
        context.progress((i + 1) / source.length, `Stitched page ${source[i] + 1}`);
      }
      if (target.getPageCount() === 0) {
        throw new ToolInputError('NO_PAGES', "没有什么可以缝合在一起。", {
          hint: `Choose pages between 1 and ${input.pageCount}.`,
        });
      }
      if (blank > 0) {
        notes.add(`${pageCountLabel(blank)} of the stitched pages had no content to draw, so those strips are blank.`);
      }
      if (shrunk > 0) {
        notes.add(
          `${pageCountLabel(shrunk)} ${shrunk === 1 ? 'is' : 'are'} wider than the ${Math.round(width)} pt target and scaled down to it: the widest page measured ${Math.round(widest)} pt and now measures ${Math.round(width)} pt.`,
        );
      }
      if (enlarged > 0) {
        notes.add(
          `${pageCountLabel(enlarged)} ${enlarged === 1 ? 'is' : 'are'} narrower than ${Math.round(width)} pt and scaled up to it rather than left with bare margins at the sides, so ${enlarged === 1 ? 'its' : 'their'} type prints bigger than it did in the source.`,
        );
      }
      if (clipped > 0) {
        notes.add(
          `A PDF page edge cannot exceed ${MAX_EDGE_TEXT}: ${pageCountLabel(clipped)} ran past it and ${clipped === 1 ? 'is' : 'are'} cut off — a narrower target width would fit more on each sheet.`,
        );
      } else if (sheets > 1) {
        notes.add(`The scroll is ${sheets} sheets long because of the ${MAX_EDGE_TEXT} page limit; print them in order and trim the joins.`);
      } else if (!split && target.getPage(0).getHeight() > PDF_MAX_EDGE) {
        notes.add(
          `The sheet is ${Math.round(target.getPage(0).getHeight())} pt tall, past the ${MAX_EDGE_TEXT} limit some viewers enforce — switch on "start a new page" if part of it disappears.`,
        );
      }
      if (source.length === 1) {
        notes.add('One page cannot be stitched to anything, so the output is that page scaled to the chosen width.');
      }
      noteMixedSizes('Stitching', input.doc, source, notes);
      noteRebuildLoss('Stitching', input.doc, source, notes);
      return pdfOut(
        target,
        notes,
        `Combined ${pageCountLabel(source.length)} into ${target.getPageCount()} long page${target.getPageCount() === 1 ? '' : 's'}.`,
      );
    },
  },

  {
    id: 'posterize',
    name: "对 PDF 进行色调分离",
    description: "将每个页面分割成重叠图块的网格以用于大幅面打印",
    icon: '🖼️',
    category: 'organize',
    keywords: ['tiled', 'banner', 'large format', 'split pages'],
    outputSuffix: '_poster.pdf',
    actionLabel: "制作海报",
    promise: 'Tiles that print at one scale and overlap by the amount you set, ready to trim and paste.',
    notes: [FLATTEN_NOTE],
    fields: [
      POSTER_ACROSS,
      POSTER_DOWN,
      POSTER_BLEED,
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const columns = numberOf(context.values, POSTER_ACROSS, notes);
      const rows = numberOf(context.values, POSTER_DOWN, notes);
      const bleed = numberOf(context.values, POSTER_BLEED, notes);
      const source = selection(context.values, input.pageCount, { fallback: 'all', verb: 'posterize' });
      if (columns === 1 && rows === 1) {
        notes.add('One tile across and one down copies each page rather than splitting it — raise one of them to make a poster.');
      }
      const target = await newPDF();
      for (let p = 0; p < source.length; p++) {
        throwIfAborted(context.signal);
        const page = input.doc.getPage(source[p]);
        const size = visibleBox(page);
        if (bleed >= Math.min(size.width / columns, size.height / rows)) {
          notes.add(
            `A ${bleed} pt overlap is as wide as the tiles themselves at ${columns} × ${rows} on this page, so tiles repeat the same strip. Lower the overlap or use more tiles.`,
          );
        }
        const tileWidth = size.width / columns;
        const tileHeight = size.height / rows;
        // Every tile sheet is `tile + overlap` on both axes and its content is
        // drawn into it 1:1. The previous version let the default `contain` fit
        // magnify the tiles that lose an outer overlap to the page boundary, so
        // edge pieces printed bigger than inner ones and would not meet up (E8).
        const sheetWidth = tileWidth + bleed;
        const sheetHeight = tileHeight + bleed;
        for (let row = 0; row < rows; row++) {
          for (let col = 0; col < columns; col++) {
            const newPage = target.addPage([sheetWidth, sheetHeight]);
            // The window this sheet shows, in the frame a viewer displays, so a
            // rotated page splits along the line the user sees (E9).
            const windowX = col * tileWidth - (col > 0 ? bleed : 0);
            const windowY = row * tileHeight - (row > 0 ? bleed : 0);
            const left = Math.max(0, windowX);
            const top = Math.max(0, windowY);
            const content = {
              x: left,
              y: top,
              width: Math.min(sheetWidth - (left - windowX), size.width - left),
              height: Math.min(sheetHeight - (top - windowY), size.height - top),
            };
            if (content.width <= 0 || content.height <= 0) continue;
            await stamp(
              target,
              newPage,
              page,
              {
                x: left - windowX,
                // The sheet's own space has y growing upward; the window does not.
                y: sheetHeight - (top - windowY) - content.height,
                width: content.width,
                height: content.height,
              },
              { region: displayRegion(page, content), fit: 'exact' },
            );
          }
        }
        context.progress((p + 1) / source.length, `Tiled page ${source[p] + 1}`);
      }
      if (target.getPageCount() > 500) {
        notes.add(`${target.getPageCount()} tiles is a lot of sheets — check the grid before printing.`);
      }
      noteMixedSizes('Posterizing', input.doc, source, notes);
      noteRebuildLoss('Posterizing', input.doc, source, notes);
      return pdfOut(
        target,
        notes,
        `Split ${pageCountLabel(source.length)} into ${columns * rows} tiles each — ${pageCountLabel(target.getPageCount())} total.`,
      );
    },
  },

  {
    id: 'divide-pages',
    name: "划分页面",
    description: "将每页切成两半、三等份或切成网格",
    icon: '➗',
    category: 'organize',
    keywords: ['split page', 'halve', 'crop regions', 'cut'],
    outputSuffix: '_divided.pdf',
    actionLabel: "除法",
    promise: 'A new PDF where each page is cut into halves, thirds or a grid, one piece per page.',
    notes: [FLATTEN_NOTE],
    fields: [
      {
        key: 'axis',
        label: "方向",
        type: 'segmented',
        default: 'vertical',
        group: "切",
        options: [
          { value: 'vertical', label: "垂直（左/右）" },
          { value: 'horizontal', label: "水平（顶部/底部）" },
          { value: 'grid', label: "网格" },
        ],
        help: "随着页面显示而测量，因此旋转的页面沿着您看到的线被切割。",
      },
      DIVIDE_PARTS,
      DIVIDE_COLUMNS,
      DIVIDE_ROWS,
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const axis = stringValue(context.values, 'axis', 'vertical');
      const parts = numberOf(context.values, DIVIDE_PARTS, notes);
      const columns = axis === 'grid'
        ? numberOf(context.values, DIVIDE_COLUMNS, notes)
        : axisParts(axis, parts, 'vertical');
      const rows = axis === 'grid'
        ? numberOf(context.values, DIVIDE_ROWS, notes)
        : axisParts(axis, parts, 'horizontal');
      if (columns === 1 && rows === 1) {
        notes.add('One column and one row copies each page instead of dividing it — set at least two parts.');
      }
      const source = selection(context.values, input.pageCount, { fallback: 'all', verb: 'divide' });
      const target = await newPDF();
      const planned = source.length * columns * rows;
      let blank = 0;
      for (const index of source) {
        throwIfAborted(context.signal);
        const page = input.doc.getPage(index);
        // Cut in the displayed frame (E8/E9): the previous version used the raw
        // MediaBox, so a `/Rotate 90` page split along the wrong axis and a
        // cropped page lost its offset.
        const size = visibleBox(page);
        const tileWidth = size.width / columns;
        const tileHeight = size.height / rows;
        for (let row = 0; row < rows; row++) {
          for (let col = 0; col < columns; col++) {
            const newPage = target.addPage([tileWidth, tileHeight]);
            const region = displayRegion(page, { x: col * tileWidth, y: row * tileHeight, width: tileWidth, height: tileHeight });
            const ok = await stamp(target, newPage, page, { x: 0, y: 0, width: tileWidth, height: tileHeight }, { region });
            // The sheet is in the file whether or not it had ink to draw, so the
            // count the message reports is the page count of the bytes (E13).
            if (!ok) blank += 1;
          }
        }
        context.progress((index + 1) / source.length, `Page ${index + 1}`);
      }
      if (blank > 0) {
        notes.add(`A page had no drawable content, so ${pageCountLabel(blank)} of the ${pageCountLabel(planned)} pieces are blank sheets in the output.`);
      }
      if (blank === planned) {
        throw new ToolInputError('NO_PAGES', "划分这些页面只产生空白页。", {
          hint: "页面没有可见内容；尝试“提取页面”。",
        });
      }
      noteRebuildLoss('Dividing', input.doc, source, notes);
      return pdfOut(target, notes, `Divided ${pageCountLabel(source.length)} into ${pageCountLabel(planned)}.`);
    },
  },

  {
    id: 'fix-page-size',
    name: "固定页面尺寸",
    description: "将您选择的页面标准化为一种尺寸和方向",
    icon: '📐',
    category: 'organize',
    keywords: ['uniform', 'normalise', 'resize', 'same size', 'a4'],
    outputSuffix: '_resized.pdf',
    actionLabel: "调整页面大小",
    promise: 'The pages you chose redrawn onto one sheet size, every other page passed through untouched.',
    notes: [FLATTEN_NOTE],
    fields: [
      {
        key: 'size',
        label: "目标尺寸",
        type: 'select',
        default: 'most-common',
        group: "目标",
        options: [
          { value: 'most-common', label: "此文件中最常见的大小" },
          { value: 'largest', label: "该文件中最大的页面" },
          ...PAGE_SIZE_OPTIONS.slice(1),
        ],
      help: "最常见的是保持文件原样并修复奇数页；最大避免缩小任何东西。",
    },
      {
        key: 'orientation',
        label: "方向",
        type: 'select',
        default: 'keep',
        group: "目标",
        options: [
          { value: 'keep', label: "保留每个页面自己的" },
          { value: 'portrait', label: "强制肖像" },
          { value: 'landscape', label: "力景观" },
        ],
      help: "强制以相同的方式翻转每张纸，这会重新构造以相反方式扫描的页面。",
    },
      {
        key: 'fit',
        label: "缩放",
        type: 'select',
        default: 'contain',
        group: "缩放",
        options: [
          { value: 'contain', label: "适合内部（信箱）" },
          { value: 'cover', label: "填充页面（可能会裁剪）" },
          { value: 'stretch', label: "拉伸至完全贴合" },
        ],
      help: "适合内部留有边距并保留所有内容；填满不适合的作物；拉伸会改变比例。",
    },
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const sizeMode = stringValue(context.values, 'size', 'most-common');
      const orientation = stringValue(context.values, 'orientation', 'keep');
      const fit = stringValue(context.values, 'fit', 'contain');
      const source = selection(context.values, input.pageCount, { fallback: 'all', verb: 'resize' });
      const chosen = new Set(source);
      const boxes = source.map((index) => visibleBox(input.doc.getPage(index)));
      const boxOf = new Map(source.map((index, position) => [index, boxes[position]]));
      let base: [number, number];
      if (sizeMode === 'most-common') base = modalSize(boxes);
      else if (sizeMode === 'largest') base = [Math.max(...boxes.map((b) => b.width)), Math.max(...boxes.map((b) => b.height))];
      else base = resolvePageSize(sizeMode);
      // The orientation is folded into the sheet once, so the size the run
      // reports is the size the bytes carry.
      let [sheetWidth, sheetHeight] = base;
      if (orientation === 'portrait' && sheetWidth > sheetHeight) [sheetWidth, sheetHeight] = [sheetHeight, sheetWidth];
      if (orientation === 'landscape' && sheetHeight > sheetWidth) [sheetWidth, sheetHeight] = [sheetHeight, sheetWidth];
      const target = await newPDF();
      let cropped = 0;
      let stretched = 0;
      let worstLoss = 0;
      let carried = 0;
      for (let index = 0; index < input.pageCount; index++) {
        throwIfAborted(context.signal);
        if (!chosen.has(index)) {
          // A page the user did not select is not a page to delete. The first
          // build emitted only the selection, so "resize page 1" of a 4-page
          // file answered with a 1-page document (E13).
          const [copy] = await target.copyPages(input.doc, [index]);
          target.addPage(copy);
          carried += 1;
          continue;
        }
        const pageBox = boxOf.get(index) ?? boxes[0];
        const page = target.addPage([sheetWidth, sheetHeight]);
        const uniform =
          fit === 'cover'
            ? Math.max(sheetWidth / pageBox.width, sheetHeight / pageBox.height)
            : Math.min(sheetWidth / pageBox.width, sheetHeight / pageBox.height);
        const xScale = fit === 'stretch' ? sheetWidth / pageBox.width : uniform;
        const yScale = fit === 'stretch' ? sheetHeight / pageBox.height : uniform;
        // The source is drawn through `stamp`, which applies the page's own
        // /Rotate — scaling a `/Rotate 90` page by its stored box instead would
        // swap the axes and spill the content off the sheet (E9).
        const ok = await stamp(target, page, input.doc.getPage(index), {
          x: (sheetWidth - pageBox.width * xScale) / 2,
          y: (sheetHeight - pageBox.height * yScale) / 2,
          width: pageBox.width * xScale,
          height: pageBox.height * yScale,
        });
        if (!ok) notes.add('A page had no content to draw, so its new sheet is blank.');
        if (fit === 'cover') {
          const loss = 1 - (pageBox.width * pageBox.height) / (sheetWidth * sheetHeight);
          if (loss > 0.005) {
            cropped += 1;
            worstLoss = Math.max(worstLoss, loss);
          }
        }
        if (fit === 'stretch' && Math.abs(xScale - yScale) > 0.01) stretched += 1;
        context.progress((index + 1) / input.pageCount, `Page ${index + 1}`);
      }
      const already = boxes.filter(
        (b) => Math.abs(b.width - sheetWidth) <= 1 && Math.abs(b.height - sheetHeight) <= 1,
      ).length;
      if (already === source.length) {
        notes.add(`Every selected page is already ${Math.round(sheetWidth)} × ${Math.round(sheetHeight)} pt, so only the rebuild changed.`);
      }
      if (carried > 0) {
        notes.add(
          `${pageCountLabel(carried)} you did not select were copied through at their own size, so the file still mixes page sizes.`,
        );
      }
      if (cropped > 0) {
        notes.add(`"Fill the page" runs content off the edge on ${pageCountLabel(cropped)} — up to ${Math.round(worstLoss * 100)}% of the sheet. Choose "Fit inside" to keep all of it.`);
      }
      if (stretched > 0) {
        notes.add(`"Stretch to exactly fit" changed the aspect ratio of ${pageCountLabel(stretched)}; circles become ovals.`);
      }
      noteRebuildLoss('Resizing', input.doc, source, notes);
      return pdfOut(
        target,
        notes,
        `${already === source.length ? 'Every selected page already matched' : `Normalised ${pageCountLabel(source.length - already)} to`} ${Math.round(sheetWidth)} × ${Math.round(sheetHeight)} pt (${(sheetWidth * 25.4 / 72).toFixed(0)} × ${(sheetHeight * 25.4 / 72).toFixed(0)} mm)${carried > 0 ? `, carried ${pageCountLabel(carried)} over unchanged` : ''}.`,
      );
    },
  },

  {
    id: 'remove-blank-pages',
    name: "删除空白页",
    description: "检测并删除不包含墨水、文本或图像的页面",
    icon: '🧹',
    category: 'organize',
    keywords: ['empty', 'scrub', 'clean', 'detect'],
    outputSuffix: '_no_blanks.pdf',
    actionLabel: "删除空白",
    promise: 'Your PDF with the pages that paint nothing deleted, and a list of which ones went.',
    notes: [
      'Detection reads each page’s display list, so a scanned image or a signature counts as ink.',
    ],
    fields: [
      {
        key: 'keepAnnotated',
        label: "保留仅包含注释的页面",
        type: 'toggle',
        default: true,
        group: "检测",
        help: "即使当其上没有打印任何内容时，也保留带有链接、表单域或标记的页面。",
      },
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const { session } = await withRender(input, context);
      try {
        const found = await findBlankPages(
          session,
          input.doc,
          { keepAnnotated: booleanValue(context.values, 'keepAnnotated', true) },
          (done, total) => context.progress((done / total) * 0.8, `Scanning page ${done} of ${total}`),
          () => context.signal.aborted,
        );
        // A cancelled scan returns a partial list; deleting on the strength of
        // it would drop the wrong pages (E19).
        throwIfAborted(context.signal);
        const blank = found.blank;
        const blankSet = new Set(blank);
        // A `Set`, not `blank.includes()` per page: a 500-page scan would
        // otherwise re-scan the blank list for every sheet (E7).
        const keep = resolvePages('all', input.pageCount).filter((p) => !blankSet.has(p + 1));
        const ocrOnly = found.profiles.filter((profile) => profile.blankByAppearance && profile.invisibleTextItems > 0);
        if (ocrOnly.length > 0) {
          notes.add(
            `${pageCountLabel(ocrOnly.length)} (${formatPages(ocrOnly.map((profile) => profile.page - 1))}) hold only invisible OCR text — they look blank but are searchable, and were treated as blank.`,
          );
        }
        if (blank.length === 0) {
          const doc = await savable(input, notes);
          return pdfOut(
            doc,
            notes,
            `No blank pages were found in ${pageCountLabel(input.pageCount)} — nothing was removed.`,
          );
        }
        if (keep.length === 0) {
          throw new ToolInputError(
            'NO_PAGES',
            `All ${pageCountLabel(input.pageCount)} look blank, and deleting every one would leave an empty PDF.`,
            { hint: "保留页面，或使用“提取页面”来拉出具有内容的页面。" },
          );
        }
        const doc = await collectPages([{ doc: input.doc, pages: keep }]);
        notePageCopy([input.doc], doc.fidelity, notes);
        return pdfOut(
          doc.doc,
          notes,
          `Removed ${pageCountLabel(blank.length)} (${formatPages(blank.map((b) => b - 1))}), kept ${pageCountLabel(keep.length)}.`,
        );
      } finally {
        await session.destroy();
      }
    },
  },

  {
    id: 'pdfs-to-zip',
    name: "PDF 至 ZIP",
    description: "将多个PDF打包到一个档案中",
    icon: '🗜️',
    category: 'organize',
    keywords: ['archive', 'bundle', 'compress container'],
    multiFile: true,
    minFiles: 1,
    surface: 'none',
    outputSuffix: '.zip',
    // The archive holds each source file byte-for-byte: no page stream is copied,
    // so a locked file is still itself inside it (and still says so — see its note).
    readsOnly: true,
    actionLabel: "压缩包",
    promise: 'One ZIP archive holding every file byte-for-byte, with a text manifest of what is inside unless you switch it off.',
    notes: [
      'Files are stored byte-for-byte: this is a container, not a compressor, and a password-protected PDF stays protected inside it.',
    ],
    fields: [
      {
        key: 'includeReport',
        label: "添加内容的文本清单",
        type: 'toggle',
        default: true,
        group: "档案",
      help: "文件、它们的大小和页数的简短清单，因此可以在不打开存档的情况下检查它。",
    },
    ],
    validate: (_v, { fileCount }) => (fileCount < 1 ? 'Add at least one PDF.' : null),
    async run(context) {
      const inputs = await openInputs(context);
      const notes = createNotes();
      if (inputs.length === 1) {
        notes.add('You packed a single PDF — the archive is the same file plus a manifest.');
      }
      const protectedFiles = inputs.filter((input) => input.inspection?.encrypted);
      if (protectedFiles.length > 0) {
        const names = protectedFiles.map((input) => `"${input.name}"`).join(', ');
        notes.add(
          `Every file is stored byte-for-byte, so ${names} ${protectedFiles.length === 1 ? 'is' : 'are'} still password protected inside the archive. Unlock them first if the archive is for someone without the password.`,
        );
      }
      const used = new Set<string>();
      const entries = [];
      const stem = safeStem(inputs[0].name);
      for (const input of inputs) {
        throwIfAborted(context.signal);
        const leaf = (input.name.split(/[\\/]/).pop() ?? input.name).trim() || 'document.pdf';
        // Only a name this helper had to change is a clash: an extensionless file
        // is stored as `scan.pdf`, and that is a repair, not two files fighting
        // over one entry (E16, E17).
        const wanted = /\.pdf$/i.test(leaf) ? leaf : `${leaf}.pdf`;
        const name = uniqueNameIn(used, wanted);
        if (name !== wanted) {
          notes.add(`Two files share the name "${wanted}"; the second was stored as "${name}".`);
        }
        entries.push({ name, data: input.bytes.slice() });
      }
      const total = inputs.reduce((sum, input) => sum + input.bytes.length, 0);
      if (booleanValue(context.values, 'includeReport', true)) {
        const manifest = [
          'BrowserSnip archive',
          `Created ${new Date().toISOString()}`,
          '',
          ...inputs.map(
            (input, i) => `${i + 1}. ${input.name} — ${pageCountLabel(input.pageCount)} — ${describeSize(input.bytes)}`,
          ),
          '',
          `${pageCountLabel(inputs.reduce((sum, input) => sum + input.pageCount, 0))} in ${inputs.length} files, ${describeSize(total)} before compression.`,
        ].join('\n');
        entries.push({ name: "清单.txt", data: manifest });
      }
      const blob = await createZip(entries, {
        compression: 'DEFLATE',
        onProgress: (name, done, total2) => context.progress(done / total2, `Adding ${name}`),
      });
      if (blob.size >= total) {
        notes.add(`The archive (${describeSize(blob.size)}) is no smaller than the files (${describeSize(total)}): PDFs are already compressed.`);
      }
      return filesOut(
        [{ blob, name: `${stem}-bundle.zip` }],
        notes,
        `Packed ${inputs.length} PDFs (${describeSize(total)}) into one ZIP.`,
      );
    },
  },

  {
    id: 'pdf-to-cbz',
    name: "PDF 到 CBZ",
    description: "将漫画或扫描件转为 CBZ 存档以供漫画读者使用",
    icon: '📚',
    category: 'organize',
    keywords: ['comic', 'cbz', 'manga reader'],
    surface: 'none',
    outputSuffix: '.cbz',
    readsOnly: true,
    actionLabel: "制作CBZ",
    promise: 'A comic-book archive: the pages you pick rendered to images, numbered in reading order.',
    notes: [
      'A CBZ is a ZIP archive of page images: comic readers open it directly, and nothing in it is selectable or searchable.',
    ],
    fields: [
      {
        key: 'format',
        label: "文件格式",
        type: 'segmented',
        default: 'jpg',
        group: "图像",
        options: [
          { value: 'jpg', label: 'JPG' },
          { value: 'png', label: "巴布亚新几内亚" },
        ],
      help: "PNG 保持线条艺术和语音气泡清晰，但代价是档案更大； JPG 是大多数漫画读者所期望的。",
    },
      DPI,
      ALL_PAGES,
    ],
    async run(context) {
      const [input] = await openInputs(context);
      const notes = createNotes();
      const dpi = numberOf(context.values, DPI, notes);
      const pages = selection(context.values, input.pageCount, { fallback: 'all', verb: 'convert' });
      // A rough uncompressed pixel budget: this tab holds every rasterised page
      // in memory before the archive is written (E7, E12).
      const boxes = pages.map((index) => visibleBox(input.doc.getPage(index)));
      const pixels = boxes.reduce((sum, box) => sum + (box.width * dpi / 72) * (box.height * dpi / 72), 0);
      const estimate = pixels * 3;
      if (estimate > 400 * 1024 * 1024) {
        notes.add(
          `${pageCountLabel(pages.length)} at ${dpi} dpi is roughly ${describeSize(estimate)} of pixels in this tab. Lower the resolution, or convert in smaller page ranges.`,
        );
      }
      const { session } = await withRender(input, context);
      try {
        const { rasterizePages } = await import('../core/render');
        const format = stringValue(context.values, 'format', 'jpg') === 'png' ? 'png' : 'jpeg';
        const rendered = await rasterizePages(session, {
          format,
          scale: dpi / 72,
          // The selection, not the whole document: rendering every page while the
          // archive was described as the chosen pages produced a CBZ with the
          // pages the user had just switched off (E13, E18).
          pages: pages.map((index) => index + 1),
          onProgress: (done, total) => context.progress(done / total, `Rendered page ${done}`),
        });
        if (rendered.length === 0) {
          throw new ToolInputError('NO_PAGES', "无法呈现页面。", {
            hint: "尝试较低的分辨率，或使用修复工具检查文件。",
          });
        }
        const stem = safeStem(input.name);
        const width = String(rendered.length).length;
        const blob = await createZip(
          rendered.map((page, i) => ({
            // Flat names: `core/archive` replaces `/` in an entry name, so a
            // folder prefix would silently arrive as `comic-001.jpg` anyway.
            // Zero padding is what makes a comic reader sort them in reading order.
            name: `${stem}-${String(i + 1).padStart(Math.max(3, width), '0')}.${page.name.split('.').pop()}`,
            data: page.blob,
            store: format === 'png',
          })),
          { compression: format === 'png' ? 'STORE' : 'DEFLATE' },
        );
        if (rendered.length !== pages.length) {
          notes.add(`Only ${pageCountLabel(rendered.length)} of the ${pageCountLabel(pages.length)} pages you chose could be rendered.`);
        }
        const raw = rendered.reduce((sum, page) => sum + page.blob.size, 0);
        if (blob.size >= raw) {
          notes.add(`The archive (${describeSize(blob.size)}) is not smaller than the images (${describeSize(raw)}).`);
        }
        return filesOut(
          [{ blob, name: `${stem}.cbz` }],
          notes,
          `${pageCountLabel(rendered.length)} rendered at ${dpi} dpi into ${describeSize(blob.size)}.`,
        );
      } finally {
        await session.destroy();
      }
    },
  },
];

/* ── helpers shared by this group ─────────────────────────────────────────── */

/** Files added twice by accident (E16) — kept, because a repeat is work. */
function noteRepeated(inputs: OpenedInput[], notes: Notes): void {
  const seen = new Map<string, number>();
  for (const input of inputs) {
    const key = `${input.name}:${input.bytes.length}`;
    const count = (seen.get(key) ?? 0) + 1;
    seen.set(key, count);
    if (count === 2) {
      notes.add(
        `"${input.name}" appears twice in the queue, so its ${pageCountLabel(input.pageCount)} are used twice. Remove the repeat if that is not what you meant.`,
      );
    }
  }
}

/** `used` variant for arbitrary extensions (the ZIP entry names). */
function uniqueNameIn(used: Set<string>, name: string): string {
  if (!used.has(name)) {
    used.add(name);
    return name;
  }
  const dot = name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : '';
  let n = 2;
  while (used.has(`${stem}-${n}${ext}`)) n += 1;
  const candidate = `${stem}-${n}${ext}`;
  used.add(candidate);
  return candidate;
}

/**
 * Where a blank sheet goes for the chosen position, as a 0-based insert index.
 * `after` the last page appends; `before` page 1 prepends.
 */
function insertPosition(position: string, pageCount: number, anchor: number): number {
  if (position === 'start') return 0;
  if (position === 'end') return pageCount;
  if (position === 'after') return Math.min(pageCount, anchor);
  return Math.max(0, anchor - 1);
}

/** Which stamp page serves base page `index` (0-based, in both documents). */
function stampPageIndex(mapping: string, index: number, stampTotal: number): number {
  if (mapping === 'first') return 0;
  if (mapping === 'last') return Math.max(0, stampTotal - 1);
  return Math.min(index, Math.max(0, stampTotal - 1));
}

/** One axis of a cut becomes columns or rows depending on the direction. */
function axisParts(axis: string, parts: number, along: 'vertical' | 'horizontal'): number {
  return axis === along ? parts : 1;
}

/**
 * Rebuild a document as `count` blank sheets of `size`, then stamp sources.
 *
 * `cell` is a cell **of `item.sheet`'s own grid** (`0 … cellsPerSheet-1`, or of the
 * `columns × rows` the caller's `cellBox` closes over), never an index into the
 * whole run: `n-up` once fed it the run index and every sheet after the first was
 * placed below the media box.
 */
async function sheetDocument(
  source: PDFDocument,
  size: [number, number],
  cells: { sheet: number; cell: number; page: number }[],
  cellsPerSheet: number,
  cellBox: (cell: number) => Box,
  notes: Notes,
): Promise<PDFDocument> {
  const sheetCount = Math.max(1, Math.ceil(cells.length / cellsPerSheet));
  const target = await newPDF();
  const blank = new Array(sheetCount).fill(0).map(() => target.addPage(size));
  let missing = 0;
  for (const item of cells) {
    // A negative source index is a cell the caller *chose* to leave empty — the
    // booklet pads the last sheet that way and says so in its own words. Only a
    // cell that should have held a page, and did not, is worth a warning (E13).
    if (item.page < 0) continue;
    const page = blank[item.sheet];
    if (!page || item.page >= source.getPageCount()) {
      missing += 1;
      continue;
    }
    const ok = await stamp(target, page, source.getPage(item.page), cellBox(item.cell));
    if (!ok) missing += 1;
  }
  if (missing > 0) {
    notes.add(`${pageCountLabel(missing)} of the planned cells stayed blank: the source page had no content to draw.`);
  }
  return target;
}

function gridBox(
  sheetWidth: number,
  sheetHeight: number,
  columns: number,
  rows: number,
  gutter: number,
  margin: number,
) {
  const usableWidth = sheetWidth - margin * 2 - gutter * (columns - 1);
  const usableHeight = sheetHeight - margin * 2 - gutter * (rows - 1);
  const cellWidth = usableWidth / columns;
  const cellHeight = usableHeight / rows;
  return (cell: number) => {
    const col = cell % columns;
    const row = Math.floor(cell / columns);
    return {
      x: margin + col * (cellWidth + gutter),
      // Rows are laid out top-down in the UI, but PDF y grows upward.
      y: sheetHeight - margin - (row + 1) * cellHeight - row * gutter,
      width: cellWidth,
      height: cellHeight,
    };
  };
}

/**
 * Draw a stamp *behind* a page's own content.
 *
 * `pdf-lib` appends new operators into the page's last content stream, which is
 * the topmost thing drawn, so there is nothing to re-order afterwards. The page
 * is snapshotted as a form XObject, its content is cleared, the stamp is drawn,
 * and the snapshot goes back on top. The page object itself survives, so its
 * `/Rotate`, crop box and annotations keep working (E9).
 */
async function stampBehind(
  target: PDFDocument,
  page: PDFPage,
  draw: () => Promise<boolean>,
): Promise<boolean> {
  const media = mediaBox(page);
  let snapshot: PDFEmbeddedPage | null = null;
  try {
    snapshot = await target.embedPage(page, {
      left: media.x,
      bottom: media.y,
      right: media.x + media.width,
      top: media.y + media.height,
    });
  } catch {
    // A page with no content stream: an underlay on it is just the stamp.
    snapshot = null;
  }
  page.node.set(PDFName.of('Contents'), target.context.obj([]) as PDFArray);
  const drew = await draw();
  if (snapshot) page.drawPage(snapshot, { x: media.x, y: media.y, xScale: 1, yScale: 1 });
  return drew;
}

/**
 * Write a flat bookmark tree directly into `/Outlines`.
 *
 * The pdf-lib fork this app uses exposes no outline API, and merging only
 * needs top-level entries, so they are written here. Full outline editing
 * (nested trees, import/export, round-tripping foreign documents) lives in
 * `core/bookmarks`.
 */
function writeFlatOutline(
  doc: PDFDocument,
  marks: { title: string; page: number }[],
): number {
  if (marks.length === 0) return 0;
  const context = doc.context;
  const pages = doc.getPages();
  const outlines = context.obj({ Type: 'Outlines' }) as PDFDict;
  const outlinesRef = context.register(outlines);

  let firstRef: PDFRef | null = null;
  let previousRef: PDFRef | null = null;
  let written = 0;

  for (const mark of marks) {
    const page = pages[mark.page];
    if (!page) continue;
    // `/Title` must be a text string, not a name. `context.obj` turns a plain
    // JS string into a PDFName, so the hex string is built explicitly — that
    // also keeps non-ASCII filenames intact via a UTF-16BE byte-order mark.
    const item = context.obj({
      Title: PDFHexString.fromText(mark.title),
      Parent: outlinesRef,
      Dest: [page.ref, PDFName.of('Fit')],
    }) as PDFDict;
    const itemRef = context.register(item);
    if (previousRef) {
      item.set(PDFName.of('Prev'), previousRef);
      context.lookup(previousRef, PDFDict)?.set(PDFName.of('Next'), itemRef);
    } else {
      firstRef = itemRef;
    }
    previousRef = itemRef;
    written += 1;
  }
  if (!firstRef || !previousRef || written === 0) return 0;
  outlines.set(PDFName.of('First'), firstRef);
  outlines.set(PDFName.of('Last'), previousRef);
  outlines.set(PDFName.of('Count'), context.obj(written));
  doc.catalog.set(PDFName.of('Outlines'), outlinesRef);
  return written;
}

async function cloneForOutput(doc: PDFDocument): Promise<PDFDocument> {
  const bytes = await savePDF(doc, { useObjectStreams: false });
  // The round-trip is also what drops `/Encrypt`: a document loaded with a
  // password keeps its encryption dictionary on save (E5).
  return openPDF(bytes, { ignoreEncryption: true });
}

interface PlanItem { page: number; rotate: number | null; blank: boolean }

/**
 * The plan, whichever shape the surface handed over: the page grid's 0-based
 * index array, a typed `pageOrder` string, or nothing (the document as it is).
 */
function planFromValues(raw: unknown, total: number, notes: Notes): PlanItem[] {
  if (Array.isArray(raw)) return planFromIndices(raw, total);
  const spec = typeof raw === 'string' ? raw.trim() : '';
  return spec === '' ? defaultPlan(total) : parsePlan(spec, total, notes);
}

function defaultPlan(total: number): PlanItem[] {
  return Array.from({ length: total }, (_, i) => ({ page: i, rotate: null, blank: false }));
}

/**
 * The page grid's legacy value shape: 0-based source indices.
 *
 * `PageOrganizer` writes the string grammar below; the older `OrganizeMain`
 * pane writes an array. Both mean the same plan, and an array that is silently
 * ignored would reorder nothing.
 */
function planFromIndices(raw: unknown[], total: number): PlanItem[] {
  const plan: PlanItem[] = [];
  for (const value of raw) {
    if (value === -1) {
      plan.push({ page: -1, rotate: null, blank: true });
      continue;
    }
    const index = Number(value);
    if (!Number.isInteger(index) || index < 0 || index >= total) {
      throw new ToolInputError(
        "OUT_OF_RANGE",
        `Page index ${String(value)} is outside this document of ${pageCountLabel(total)}.`,
        { hint: `Valid positions are 0 to ${total - 1} for this grid.` },
      );
    }
    plan.push({ page: index, rotate: null, blank: false });
  }
  if (plan.length === 0) {
    throw new ToolInputError('NO_PAGES', "页序为空。", {
      hint: "将至少一页拖到网格中，或键入1、2、3。",
    });
  }
  return plan;
}

/**
 * Parse the plan grammar the page grid writes: `3`, `3r90`, `2-5`, `blank`.
 *
 * A page outside the document is refused with the real page count (E6), and an
 * inverted range says which way round it should be.
 */
function parsePlan(spec: string, total: number, notes: Notes): PlanItem[] {
  const out: PlanItem[] = [];
  // `2 - 5` is a range with the spaces a person types. Folding them away before
  // the split is the rule `core/pages.parseList` applies, and taking `;` as a
  // separator too means the plan and the page list answer the same input the
  // same way (E15) — this grammar used to read the spaced range as three tokens
  // and refuse the middle one.
  for (const raw of spec.replace(/\s*(-{1,2}|–|\.\.)\s*/g, '$1').split(/[,\s;]+/)) {
    const token = raw.trim();
    if (!token) continue;
    if (/^blank$/i.test(token)) {
      out.push({ page: -1, rotate: null, blank: true });
      continue;
    }
    const fromOtherFile = /^f(\d+):/i.exec(token);
    if (fromOtherFile) {
      throw new ToolInputError(
        "不支持",
        `"${token}" refers to page ${token.split(':')[1]} of file ${fromOtherFile[1]}, but organizing works on one document at a time.`,
        { hint: "首先合并文件，或者退回到单文档计划。" },
      );
    }
    const match = /^(\d+)(?:-(\d+))?(?:r(\d{1,3}))?$/i.exec(token);
    if (!match) {
      throw new ToolInputError("OUT_OF_RANGE", `"${token}" is not a page token.`, {
        hint: "使用3、3r90、2-5或空白。",
      });
    }
    const first = Number(match[1]);
    const last = match[2] === undefined ? first : Number(match[2]);
    for (const page of [first, last]) {
      if (page === 0) {
        throw new ToolInputError("OUT_OF_RANGE", "第 0 页不存在 — 页从 1 开始编号。", {
          hint: `This document has ${pageCountLabel(total)}.`,
        });
      }
      if (page > total) {
        throw new ToolInputError(
          "OUT_OF_RANGE",
          `"${token}" refers to page ${page}, but this document has ${pageCountLabel(total)}.`,
          { hint: `Re-order within 1-${total}, or remove the token.` },
        );
      }
    }
    if (last < first) {
      throw new ToolInputError("OUT_OF_RANGE", `"${token}" runs backwards — page ${first} comes after page ${last}.`, {
        hint: `Write ${last}-${first} to go forwards, or ${first}-${last}r0.`,
      });
    }
    const rotate = match[3] === undefined ? null : normaliseRotation(Number(match[3]));
    if (match[3] !== undefined && Number(match[3]) % 90 !== 0) {
      notes.add(`r${match[3]} is not a quarter turn: a stored /Rotate must be 0, 90, 180 or 270, so those pages were turned to ${rotate}° instead.`);
    }
    for (let page = first; page <= last; page++) {
      out.push({ page: page - 1, rotate, blank: false });
    }
  }
  if (out.length === 0) {
    throw new ToolInputError('NO_PAGES', "页序为空。", {
      hint: `List at least one page between 1 and ${total}, or "blank".`,
    });
  }
  return out;
}

function gridFor(perSheet: number): [number, number] {
  if (perSheet <= 1) return [1, 1];
  if (perSheet === 2) return [2, 1];
  if (perSheet === 4) return [2, 2];
  if (perSheet === 6) return [3, 2];
  if (perSheet === 9) return [3, 3];
  const columns = Math.ceil(Math.sqrt(perSheet));
  return [columns, Math.ceil(perSheet / columns)];
}

function modalSize(sizes: { width: number; height: number }[]): [number, number] {
  const counts = new Map<string, { size: [number, number]; n: number }>();
  for (const size of sizes) {
    const key = `${Math.round(size.width)}x${Math.round(size.height)}`;
    const found = counts.get(key);
    if (found) found.n += 1;
    else counts.set(key, { size: [size.width, size.height], n: 1 });
  }
  let best: [number, number] = [
    sizes[0]?.width ?? PAGE_SIZES.a4[0],
    sizes[0]?.height ?? PAGE_SIZES.a4[1],
  ];
  let bestCount = -1;
  for (const entry of counts.values()) {
    if (entry.n > bestCount) {
      bestCount = entry.n;
      best = entry.size;
    }
  }
  return best;
}
