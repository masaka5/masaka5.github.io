import { PDF_TOOLS, TOOL_CATALOGUE, PDF_CATEGORIES } from '@/lib/pdf/tools/registry';
import type { ToolCategoryDefinition, ToolDefinition } from '@/types';

/**
 * Video tools are declared here; the PDF catalogue lives in
 * `src/lib/pdf/tools/` and is derived below. Previously every PDF tool had to be
 * written twice — once in this file and once in `ToolWorkspace.tsx` — which is
 * how tools ended up registered with no component, or implemented with no card.
 */
const VIDEO_TOOLS: ToolDefinition[] = [
  {
    id: 'trim',
    name: "修剪和切割",
    description: "通过流复制进行即时修剪——无需重新编码，保留原始质量和比特率",
    icon: '✂',
    category: 'video',
  },
  {
    id: 'resize',
    name: "调整大小",
    description: "通过宽高比锁定将视频缩放至标准分辨率",
    icon: '↔',
    category: 'video',
  },
  {
    id: 'crop',
    name: "裁剪和重构",
    description: "作物与社交媒体的长宽比(9:16、1:1、21:9)",
    icon: '⊞',
    category: 'video',
  },
  {
    id: 'compress',
    name: "压缩",
    description: "Discord、Slack 或电子邮件限制的目标特定文件大小",
    icon: '↓',
    category: 'video',
  },
  {
    id: 'gif',
    name: "GIF转换器",
    description: "通过调色板优化将短剪辑转换为高质量循环GIF",
    icon: '◉',
    category: 'video',
  },
  {
    id: 'audio',
    name: "音频工具",
    description: "静音、提取MP3或调节音量（0%–300%）",
    icon: '♪',
    category: 'video',
  },
  {
    id: 'speed',
    name: "速度控制",
    description: "创建间隔拍摄或慢动作（0.25×至4.0×）",
    icon: '⏱',
    category: 'video',
  },
  {
    id: 'metadata',
    name: "隐私清除",
    description: "立即删除所有元数据、位置标签和创建标记",
    icon: '🛡',
    category: 'video',
  },
];

export const TOOL_CATEGORIES: ToolCategoryDefinition[] = [
  { id: 'video', label: "视频工具", icon: '🎬' },
  ...PDF_CATEGORIES.map((category) => ({
    id: category.id,
    label: category.label,
    icon: category.icon,
  })),
];

export const TOOLS: ToolDefinition[] = [
  ...VIDEO_TOOLS,
  ...PDF_TOOLS.map((tool) => ({
    id: tool.id,
    name: tool.name,
    description: tool.description,
    icon: tool.icon,
    category: tool.category,
    multiFile: tool.multiFile,
  })),
];

export const VIDEO_TOOL_COUNT = VIDEO_TOOLS.length;
/**
 * What the app advertises: one PDF tool per job. The registry keeps answering
 * the secondary ids (`redact`, `compare`) so old bookmarks and shared links
 * still open, but they are not two more tools — every "N tools" sentence in the
 * product reads this number or `TOOL_CATALOGUE.length`, never a literal.
 */
export const PDF_TOOL_COUNT = TOOL_CATALOGUE.length;
/** Everything the landing page counts: the video tools plus the PDF catalogue. */
export const TOOL_COUNT = VIDEO_TOOL_COUNT + PDF_TOOL_COUNT;

export function categoryBlurb(id: ToolCategoryDefinition['id']): string {
  return PDF_CATEGORIES.find((category) => category.id === id)?.blurb ?? 'Everything runs in this tab.';
}
