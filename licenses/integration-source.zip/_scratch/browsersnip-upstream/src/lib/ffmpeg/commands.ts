import type {
  TrimParams,
  ResizeParams,
  CropParams,
  CompressParams,
  GifParams,
  AudioParams,
  SpeedParams,
} from '@/types';
import { calculateBitrate } from '@/lib/utils/bitrate';
import { formatTime } from '@/lib/utils/time';

function threads(): string {
  // More than 4 threads in WASM causes OOM hangs, not speedups
  return Math.min(4, navigator.hardwareConcurrency || 2).toString();
}

export function trimCommand(
  inputName: string,
  outputName: string,
  params: TrimParams
): string[] {
  const start = formatTime(params.startTime);
  const duration = formatTime(params.endTime - params.startTime);

  return [
    '-ss', start,
    '-i', inputName,
    '-t', duration,
    '-c', 'copy',
    '-avoid_negative_ts', 'make_zero',
    '-movflags', '+faststart',
    outputName,
  ];
}

export function resizeCommand(
  inputName: string,
  outputName: string,
  params: ResizeParams
): string[] {
  return [
    '-i', inputName,
    '-vf', `scale=${params.width}:${params.height}`,
    '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
    '-threads', threads(),
    '-c:a', 'aac',
    '-movflags', '+faststart',
    outputName,
  ];
}

export function cropCommand(
  inputName: string,
  outputName: string,
  params: CropParams
): string[] {
  const [w, h] = params.aspectRatio.split(':').map(Number);
  // Crop the longer dimension to match the target ratio.
  // For landscape sources: 9:16/1:1 crop by height, 21:9 crop by width.
  const expr = w > h
    ? `iw:iw*${h}/${w}`   // target wider → crop height from width
    : `ih*${w}/${h}:ih`;  // target taller → crop width from height

  return [
    '-i', inputName,
    '-vf', `crop=${expr}`,
    '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
    '-threads', threads(),
    '-c:a', 'aac',
    '-movflags', '+faststart',
    outputName,
  ];
}

export function compressCommand(
  inputName: string,
  outputName: string,
  params: CompressParams,
  duration: number
): string[] {
  const bitrate = calculateBitrate(params.targetSizeMB, duration);
  const bufsize = bitrate * 2;

  return [
    '-i', inputName,
    '-c:v', 'libx264', '-preset', 'ultrafast',
    '-b:v', `${Math.round(bitrate)}k`,
    '-bufsize', `${Math.round(bufsize)}k`,
    '-threads', threads(),
    '-c:a', 'aac', '-b:a', '128k',
    '-movflags', '+faststart',
    outputName,
  ];
}

export function gifCommand(
  inputName: string,
  outputName: string,
  params: GifParams
): string[] {
  const start = formatTime(params.startTime);
  const dur = formatTime(params.duration);

  // -2 ensures even height (required by GIF palette). Input seeking
  // (-ss before -i) for fast segment extraction. Dual-pass palette
  // generation for smooth colors without banding.
  return [
    '-ss', start, '-t', dur,
    '-i', inputName,
    '-vf',
    `fps=${params.fps},scale=${params.width}:-2:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse`,
    '-f', 'gif',
    outputName,
  ];
}

export function audioCommand(
  inputName: string,
  outputName: string,
  params: AudioParams
): string[] {
  switch (params.mode) {
    case 'mute':
      return ['-i', inputName, '-an', '-c:v', 'copy', outputName];
    case 'extract':
      return ['-i', inputName, '-vn', '-acodec', 'libmp3lame', '-q:a', '2', outputName];
    case 'volume':
      return [
        '-i', inputName,
        '-af', `volume=${params.volume}`,
        '-c:v', 'libx264', '-crf', '18', '-preset', 'ultrafast',
        '-threads', threads(),
        '-c:a', 'aac',
        '-movflags', '+faststart',
        outputName,
      ];
  }
}

export function speedCommand(
  inputName: string,
  outputName: string,
  params: SpeedParams
): string[] {
  const ptsFactor = (1 / params.speed).toFixed(1);
  const atempo = params.speed.toFixed(1);

  return [
    '-i', inputName,
    '-vf', `setpts=${ptsFactor}*PTS`,
    '-af', `atempo=${atempo}`,
    '-c:v', 'libx264', '-crf', '18', '-preset', 'ultrafast',
    '-threads', threads(),
    '-c:a', 'aac',
    '-movflags', '+faststart',
    outputName,
  ];
}

export function metadataCommand(inputName: string, outputName: string): string[] {
  return ['-i', inputName, '-map_metadata', '-1', '-c', 'copy', outputName];
}

