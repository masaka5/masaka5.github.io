import { motion } from 'framer-motion';
import { fadeUp, floatLoop } from '@/lib/motion';

export function MemoryWarning() {
  return (
    <motion.div
      variants={fadeUp}
      initial="hidden"
      animate="visible"
      className="mt-3 rounded-doodle-md border border-warn/20 bg-warn/5 p-3"
    >
      <p className="flex items-center gap-1.5 text-[11px] font-semibold text-warn">
        <motion.span aria-hidden {...floatLoop}>⚠️</motion.span>
        {"大文件警告"}</p>
      <p className="mt-1 text-[11px] leading-relaxed text-warn/80">
        {"该文件超过 500 MB，并且可能由于 WebAssembly 内存限制而导致浏览器选项卡崩溃。考虑首先使用压缩或调整大小工具来减少处理负载。"}</p>
    </motion.div>
  );
}
