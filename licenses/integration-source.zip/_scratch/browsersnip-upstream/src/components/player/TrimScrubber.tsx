import { useCallback, useRef } from 'react';
import { formatDisplayTime } from '@/lib/utils/time';

interface Props {
  duration: number;
  startTime: number;
  endTime: number;
  onStartChange: (t: number) => void;
  onEndChange: (t: number) => void;
}

export function TrimScrubber({
  duration,
  startTime,
  endTime,
  onStartChange,
  onEndChange,
}: Props) {
  const trackRef = useRef<HTMLDivElement>(null);

  const getTimeFromPosition = useCallback(
    (clientX: number, _isStart: boolean): number => {
      const track = trackRef.current;
      if (!track) return 0;

      const rect = track.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      return ratio * duration;
    },
    [duration]
  );

  const handlePointerDown = useCallback(
    (e: React.PointerEvent, handle: 'start' | 'end') => {
      e.preventDefault();
      const el = e.currentTarget as HTMLElement;
      el.setPointerCapture(e.pointerId);

      const onMove = (ev: PointerEvent) => {
        const time = getTimeFromPosition(ev.clientX, handle === 'start');
        if (handle === 'start') {
          onStartChange(Math.min(time, endTime - 0.1));
        } else {
          onEndChange(Math.max(time, startTime + 0.1));
        }
      };

      const onUp = () => {
        el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp);
      };

      el.addEventListener('pointermove', onMove);
      el.addEventListener('pointerup', onUp);
    },
    [getTimeFromPosition, startTime, endTime, onStartChange, onEndChange]
  );

  const startPct = (startTime / duration) * 100;
  const endPct = (endTime / duration) * 100;

  return (
    <div className="mt-4 space-y-2 rounded-[12px] border border-cream-border bg-white px-3.5 py-3 shadow-doodle">
      <div className="flex justify-between font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted tabular-nums">
        <span>{formatDisplayTime(startTime)}</span>
        <span>{formatDisplayTime(endTime)}</span>
      </div>

      {/* trackRef is measured via getBoundingClientRect for pointer math — no motion wrappers */}
      <div
        ref={trackRef}
        className="relative h-8 w-full cursor-pointer select-none rounded"
      >
        <div className="absolute top-1/2 h-1.5 w-full -translate-y-1/2 rounded-full bg-cream-soft" />

        <div
          className="absolute top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-accent"
          style={{
            left: `${startPct}%`,
            width: `${endPct - startPct}%`,
          }}
        />

        <div
          onPointerDown={(e) => handlePointerDown(e, 'start')}
          className="absolute top-1/2 h-6 w-3.5 -translate-x-1/2 -translate-y-1/2 cursor-ew-resize rounded-md border-2 border-accent bg-white shadow-doodle hover:scale-125 hover:border-accent-hover transition-all touch-none"
          style={{ left: `${startPct}%` }}
        />

        <div
          onPointerDown={(e) => handlePointerDown(e, 'end')}
          className="absolute top-1/2 h-6 w-3.5 -translate-x-1/2 -translate-y-1/2 cursor-ew-resize rounded-sm border-2 border-accent bg-white shadow-doodle hover:scale-125 hover:border-accent-hover transition-all touch-none"
          style={{ left: `${endPct}%` }}
        />
      </div>
    </div>
  );
}
