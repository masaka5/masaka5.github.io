/**
 * The annotation palette: what each tool is called, how it gathers geometry,
 * which PDF annotation subtype it produces, and the appearance it starts with.
 *
 * The order of `TOOLS` is the order of the palette grid; `select` is rendered
 * apart from the creating tools but lives in the same table so a tool id always
 * resolves to exactly one description.
 */
import type { EditorToolId, ToolMeta, ToolStyle } from './types';
import { DEFAULT_FACE_STYLE, defaultFaceStyle, type FaceSurfaceId } from '@/lib/pdf/core/text-style';

/** Built-in stamp names. Written verbatim to `/S`, so no spaces (PDF names). */
export const BUILT_IN_STAMPS: { value: string; label: string }[] = [
  { value: 'Approved', label: "已批准" },
  { value: 'NotApproved', label: "未获批准" },
  { value: 'AsIs', label: "原样" },
  { value: 'Confidential', label: "机密" },
  { value: 'Draft', label: "草案" },
  { value: 'Experimental', label: "实验性的" },
  { value: 'Expired', label: "已过期" },
  { value: 'Final', label: "决赛" },
  { value: 'NotForPublicRelease', label: "不得公开发布" },
  { value: 'Sold', label: "已售出" },
  { value: 'TopSecret', label: "最高机密" },
  { value: 'Void', label: "无效" },
];

/** Quick colour choices, echoing the highlighter palette people expect. */
export const SWATCHES: string[] = [
  '#FFEB3B',
  '#FF9800',
  '#E91E63',
  '#DC2626',
  '#8B5CF6',
  '#2563EB',
  '#059669',
  '#1B1B18',
  '#FFFFFF',
];

const style = (over: Partial<ToolStyle> = {}): ToolStyle => ({
  color: '#FFEB3B',
  fillColor: '#FFFFFF',
  filled: false,
  strokeWidth: 1.5,
  opacity: 1,
  stampName: 'Approved',
  text: { ...DEFAULT_FACE_STYLE },
  ...over,
});

/**
 * The tools that set type, and the surface whose stored style they open with.
 *
 * A sticky note is deliberately absent: its body reaches the file as a plain
 * `/Contents` string and every reader paints the popup in its own UI font, so a
 * family or a size chosen here would be a control that changes no glyph. Its
 * colour and opacity are real because the format carries them (`/C`, `/CA`).
 */
export const TEXT_STYLE_SURFACE: Partial<Record<EditorToolId, FaceSurfaceId>> = {
  freetext: 'freetext',
  stamp: 'stamp',
};

/** Tools whose marks carry text the editor styles. */
export const TEXT_TOOLS: EditorToolId[] = Object.keys(TEXT_STYLE_SURFACE) as EditorToolId[];

/**
 * Default appearance per tool — the starting point of the per-style state.
 *
 * The text style comes from the shared model's per-surface default (a text box is
 * 12 pt ink, a stamp is 14 pt bold red), so switching tools preserves what each one
 * has always started with while the seven properties mean the same thing in every
 * rail.
 */
export function defaultStyleFor(tool: EditorToolId): ToolStyle {
  const surface = TEXT_STYLE_SURFACE[tool];
  const text = surface ? defaultFaceStyle(surface) : { ...DEFAULT_FACE_STYLE };
  switch (tool) {
    case 'highlight':
      return style({ color: '#FFEB3B', opacity: 0.4 });
    case 'underline':
      return style({ color: '#1B1B18', strokeWidth: 1 });
    case 'strike':
      return style({ color: '#DC2626', strokeWidth: 1 });
    case 'note':
      return style({ color: '#FFF3A3', opacity: 1 });
    case 'freetext':
      return style({
        color: text.color,
        fillColor: '#FFFFFF',
        filled: true,
        strokeWidth: 0.8,
        text: { ...text, color: text.color },
      });
    case 'ink':
      return style({ color: '#DC2626', strokeWidth: 2.25 });
    case 'square':
    case 'circle':
      return style({ color: '#2563EB', fillColor: '#2563EB', filled: false, strokeWidth: 2 });
    case 'line':
      return style({ color: '#1B1B18', strokeWidth: 1.5 });
    case 'arrow':
      return style({ color: '#DC2626', strokeWidth: 2 });
    case 'polygon':
    case 'polyline':
      return style({ color: '#059669', fillColor: '#059669', filled: false, strokeWidth: 2 });
    case 'stamp':
      return style({ color: text.color, opacity: 0.85, stampName: 'Approved', text });
    case 'image':
    case 'signature':
      return style({ color: '#1B1B18', opacity: 1 });
    case 'link':
      return style({ color: '#2563EB', strokeWidth: 1 });
    case 'redact':
      return style({ color: '#000000', filled: true, opacity: 1 });
    case 'select':
    default:
      return style({ color: '#1B1B18' });
  }
}

/** Every palette entry in display order. */
export const TOOLS: ToolMeta[] = [
  {
    id: 'select',
    label: "选择",
    icon: '🖱️',
    hint: "单击标记将其选中，拖动将其移动，删除将其移除。",
    gesture: 'none',
    kind: 'Popup',
  },
  {
    id: 'highlight',
    label: "亮点",
    icon: '🖍️',
    hint: "在单词上拖动——标记捕捉到它穿过的每个文本行。",
    gesture: 'markup',
    kind: 'Highlight',
  },
  {
    id: 'underline',
    label: "下划线",
    icon: 'U',
    hint: "跨文本拖动；下划线位于捕捉的文本行之后。",
    gesture: 'markup',
    kind: 'Underline',
  },
  {
    id: 'strike',
    label: "三振出局",
    icon: 'S',
    hint: "在文本上拖动以删除您触摸的行。",
    gesture: 'markup',
    kind: 'StrikeOut',
  },
  {
    id: 'note',
    label: "注意",
    icon: '📌',
    hint: "单击以放置便签，然后键入其评论。",
    gesture: 'box',
    kind: 'Text',
  },
  {
    id: 'freetext',
    label: "文本框",
    icon: 'T',
    hint: "拖动一个框（或单击默认框）并在其中键入。",
    gesture: 'box',
    kind: 'FreeText',
  },
  {
    id: 'ink',
    label: "笔",
    icon: '✏️',
    hint: "在页面上徒手绘制。",
    gesture: 'path',
    kind: 'Ink',
  },
  {
    id: 'square',
    label: "矩形",
    icon: '⬜',
    hint: "拖动矩形。切换填充以获得实体形状。",
    gesture: 'box',
    kind: 'Square',
  },
  {
    id: 'circle',
    label: "椭圆",
    icon: '⭕',
    hint: "拖动椭圆。切换填充以获得实体形状。",
    gesture: 'box',
    kind: 'Circle',
  },
  {
    id: 'line',
    label: "线",
    icon: '📏',
    hint: "从一个点拖动到另一点。",
    gesture: 'segment',
    kind: 'Line',
  },
  {
    id: 'arrow',
    label: "箭头",
    icon: '↗',
    hint: "沿箭头应指向的方向拖动。",
    gesture: 'segment',
    kind: 'Arrow',
  },
  {
    id: 'polygon',
    label: "形状",
    icon: '🔷',
    hint: "单击角点，然后按 Enter 键或双击以闭合形状。",
    gesture: 'vertices',
    kind: 'Polygon',
  },
  {
    id: 'polyline',
    label: "自由形式",
    icon: '〰️',
    hint: "单击点，然后按 Enter 或双击以完成线。",
    gesture: 'vertices',
    kind: 'PolyLine',
  },
  {
    id: 'stamp',
    label: "邮票",
    icon: '💮',
    hint: "选择下面的图章，然后单击或拖动它应该放置的位置。",
    gesture: 'place',
    kind: 'Stamp',
  },
  {
    id: 'image',
    label: "图像",
    icon: '🖼️',
    hint: "点击它应该去的地方，选择PNG或JPEG，然后它就落在那个位置。",
    gesture: 'place',
    kind: 'Stamp',
  },
  {
    id: 'signature',
    label: "签名",
    icon: '✍️',
    hint: "单击它应该去的地方，将其绘制在垫上，然后它落在该位置。",
    gesture: 'place',
    kind: 'Stamp',
  },
  {
    id: 'link',
    label: "链接",
    icon: '🔗',
    hint: "拖动可点击区域，然后选择页面或URL。",
    gesture: 'box',
    kind: 'Link',
  },
  {
    id: 'redact',
    label: "编辑",
    icon: '⬛',
    hint: "在文本上拖动以在导出时将其永久删除。",
    gesture: 'box',
    kind: 'Redact',
  },
];

/** Whether this tool puts something on the page, as opposed to editing it. */
export function isPlacementTool(tool: EditorToolId): boolean {
  return TOOL_BY_ID[tool]?.gesture !== 'none';
}

/**
 * The tool the palette holds when a gesture ends. One rule, no pin: a created
 * mark hands control back to Select, so the next click moves or edits the thing
 * the user just made; a gesture that created nothing leaves the pen in the
 * hand, because losing the tool after a failed drag reads as the app ignoring
 * them.
 *
 * The rule is a function rather than a line in a click handler so the palette,
 * the drag path and the tests cannot each have their own opinion about it.
 */
export function toolAfterGesture(tool: EditorToolId, created: boolean): EditorToolId {
  return created ? 'select' : tool;
}

/** The sentence the footer says about that rule, once, instead of per tool. */
export const AFTER_CREATE_NOTE = 'After one placement the tool hands control back to Select.';

/**
 * Inspector sections for the palette.
 *
 * Eighteen buttons in one grid is a wall; six named groups is a tool chest. The
 * ids are also what the quick-mode chips preselect (`panel: 'markup'`), so a
 * group name is a public-ish string, not a layout detail. `paletteIsGrouped`
 * keeps the promise that every tool appears in exactly one group.
 */
export interface ToolGroup {
  id: string;
  label: string;
  tools: EditorToolId[];
}

export const TOOL_GROUPS: ToolGroup[] = [
  { id: 'markup', label: "阅读并标记", tools: ['select', 'highlight', 'underline', 'strike'] },
  { id: 'words', label: "字", tools: ['note', 'freetext'] },
  { id: 'draw', label: "徒手画", tools: ['ink', 'line', 'arrow', 'polygon', 'polyline'] },
  { id: 'shapes', label: "形状", tools: ['square', 'circle'] },
  { id: 'place', label: "邮票、图像、签名", tools: ['stamp', 'image', 'signature'] },
  { id: 'page', label: "页面编辑", tools: ['link', 'redact'] },
];

export function toolGroupById(id: string | null | undefined): ToolGroup | undefined {
  if (!id) return undefined;
  return TOOL_GROUPS.find((group) => group.id === id);
}

export const TOOL_BY_ID: Record<EditorToolId, ToolMeta> = TOOLS.reduce(
  (acc, meta) => {
    acc[meta.id] = meta;
    return acc;
  },
  {} as Record<EditorToolId, ToolMeta>,
);

/** Which group a tool belongs to, for opening the right inspector section. */
export const GROUP_FOR_TOOL: Record<EditorToolId, string> = TOOL_GROUPS.reduce(
  (acc, group) => {
    for (const tool of group.tools) acc[tool] = group.id;
    return acc;
  },
  {} as Record<EditorToolId, string>,
);

export function toolsOfGroup(group: ToolGroup): ToolMeta[] {
  return group.tools.map((id) => TOOL_BY_ID[id]).filter(Boolean);
}

/** Every palette entry in exactly one group, and every group entry in the palette. */
export function paletteIsGrouped(): boolean {
  const seen = new Set<EditorToolId>();
  for (const group of TOOL_GROUPS) {
    for (const id of group.tools) {
      if (!TOOL_BY_ID[id] || seen.has(id)) return false;
      seen.add(id);
    }
  }
  return seen.size === TOOLS.length;
}

/** Tools whose geometry comes from snapping to real text. */
export const MARKUP_TOOLS: EditorToolId[] = ['highlight', 'underline', 'strike'];

/** Tools that take an interior colour from the Fill toggle. */
export const FILLABLE_TOOLS: EditorToolId[] = ['square', 'circle', 'polygon', 'freetext'];

/** Tools whose stroke width matters. */
export const STROKED_TOOLS: EditorToolId[] = [
  'underline',
  'strike',
  'ink',
  'square',
  'circle',
  'line',
  'arrow',
  'polygon',
  'polyline',
  'freetext',
];

/** Tools whose marks carry editable text and can be re-opened by double-click. */
export const EDITABLE_TEXT_TOOLS: EditorToolId[] = ['freetext', 'note'];
