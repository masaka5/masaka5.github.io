/**
 * RedactTool — Sidebar for Redact PDF.
 *
 * Drag on the preview to draw redaction rectangles, then apply: the boxes go to
 * the registry's `redact-pdf` tool as `regions`, so the guard pre-flight, the
 * warnings and the progress rail are the same ones every other tool uses. The
 * text under each box is deleted from the page's content stream — not painted
 * over — and a box that caught nothing is reported instead of counted as a win.
 *
 * The two options the tool declares are shown as the tool declares them:
 * `RedactMain` keeps the fill colour in its own mark state because the overlay
 * has to paint with it live, while the metadata switch is written straight into
 * the runner's value bag, which is where `redact-pdf` reads it from.
 */
import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { usePdfTool } from '@/hooks/usePdfTool';
import { useProcessStore } from '@/stores/process-store';
import { getPdfTool } from '@/lib/pdf/tools/registry';
import { fadeUp, scaleIn, staggerParent } from '@/lib/motion';
import { reportMarks } from '@/components/tools/pdf/editor/placement';
import { FieldControl } from '../shared/FieldControls';
import {
  getRedactState, setRedactColor,
  removeRedaction, selectRedaction, getRedactPageSize, subscribeRedact,
  redactionRegions,
} from './RedactMain';

/** The tool this panel belongs to, by id — the field list is its own, not a copy. */
const REDACT_TOOL = getPdfTool('redact-pdf');

/**
 * Turn a region from the frame the marks are stored in to the frame the tool wants.
 *
 * `redactionRegions` reports a box in the engine's own space: points from the
 * bottom of the displayed page, which is what the annotation editor speaks (and what
 * the retired `redact` definition took as typed `page:x,y,w,h` entries). `redact-pdf`
 * takes the mark as the user sees it — origin top-left — and turns it back through
 * `frameOf` itself, because a box drawn over the mirrored band redacts the wrong line.
 * The flip is the difference, and one page height of it: the words survive, the bar
 * lands.
 */
function displayedRegions(
  regions: { page: number; x: number; y: number; width: number; height: number }[],
  pageHeightPt: number,
) {
  return regions.map((region) => ({
    ...region,
    y: Math.max(0, Math.round(pageHeightPt - (region.y + region.height))),
  }));
}

export function RedactTool() {
  const { run, isRunning, values, setValue } = usePdfTool('redact-pdf');
  const warnings = useProcessStore((s) => s.warnings);
  const [st, setSt] = useState(getRedactState());

  useEffect(() => subscribeRedact(() => setSt(getRedactState())), []);

  const selected = st.redactions.find((r) => r.id === st.selectedId) ?? null;

  /**
   * The declared metadata switch, rendered from the definition that honours it.
   *
   * Reusing the rail's own control is what keeps the panel's wording, help line
   * and default tied to `redact-pdf.fields`; a bespoke checkbox here is a second
   * place to spell the same promise, and the first thing to drift from it.
   */
  const metadataField = (REDACT_TOOL?.fields ?? []).find((field) => field.key === 'alsoMetadata');

  /**
   * E13 and E19, before the click: a box the size of a stray mouse-twitch covers no
   * glyphs, so it would draw a speck and still report a redaction; a box on page 9
   * of a document that now has 3 pages belongs to the file that was open before.
   * Both are counted, named and left out of the run instead of smuggled through.
   */
  const report = useMemo(() => {
    const pageSize = getRedactPageSize();
    return reportMarks(st.redactions, {
      numPages: st.totalPages,
      page: { page: st.page, widthPt: pageSize.width, heightPt: pageSize.height },
      describe: (redaction) =>
        `${Math.round(redaction.w * 100)}% × ${Math.round(redaction.h * 100)}% on page ${redaction.page}`,
    });
  }, [st.page, st.redactions, st.totalPages]);

  const handleProcess = useCallback(() => {
    if (!report.valid) return;
    const pageSize = getRedactPageSize();
    // One region per snapped line, so the engine deletes the words and leaves the
    // leading between them alone. An area mark (Shift-drag) is its own one region.
    const regions = displayedRegions(
      report.usable.flatMap((r) => redactionRegions(r, pageSize)),
      pageSize.height,
    );
    // `alsoMetadata` rides in the runner's value bag, written by the switch below;
    // the fill comes from the overlay's live state, which is what the marks on
    // screen are painted with, so the file cannot disagree with the canvas.
    void run({ regions, fill: st.color });
  }, [report.usable, run, st.color]);

  /** How many separate areas the marks below actually cover. */
  const regionCount = st.redactions.reduce((total, r) => total + (r.lines?.length ?? 1), 0);

  const pageCounts = new Map<number, number>();
  for (const r of st.redactions) {
    pageCounts.set(r.page, (pageCounts.get(r.page) ?? 0) + 1);
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={staggerParent}
      className="doodle-section space-y-3"
    >
      <motion.p variants={fadeUp} className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"编辑 PDF"}</motion.p>

      {/* Warning */}
      <motion.div variants={scaleIn} className="rounded-[12px] border border-danger/25 bg-danger/[0.07] p-2.5 space-y-1">
        <p className="text-[10px] font-semibold text-danger">{"永久编辑"}</p>
        <p className="text-[10px] text-ink-soft leading-relaxed">
          {"每个标记区域被从页面中删除并被填充。即使选择结果中的文本，编辑后的数据也无法恢复。"}</p>
      </motion.div>

      {/* Color */}
      <motion.div variants={fadeUp}>
        <label className="block font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"密文颜色"}</label>
        <input type="color" value={st.color}
          onChange={(e) => setRedactColor(e.target.value)}
          className="w-full h-6 rounded-[10px] bg-cream border border-cream-border mt-1 cursor-pointer" />
      </motion.div>

      {/*
        The tool's other option, from the tool. Writing it through `setValue` is
        the point: `redact-pdf` reads `alsoMetadata` out of the value bag, and a
        panel that only *displayed* the switch is how it ended up inert.
      */}
      {metadataField && (
        <motion.div variants={fadeUp} data-redact-metadata-switch>
          <FieldControl
            field={metadataField}
            values={values}
            onChange={(key, value) => setValue(key, Boolean(value))}
          />
        </motion.div>
      )}

      {/* Instructions */}
      <motion.p variants={scaleIn} className="rounded-[12px] border border-cream-border bg-cream-soft px-3.5 py-2.5 text-[10px] text-ink-muted leading-relaxed">
        <strong>{"跨单词拖动"}</strong> {"在预览中：框捕捉到每个文本行并且创建一个标记来覆盖它们。在空纸上拖动不会留下任何痕迹。保持"}<strong>{"转变"}</strong> {"要覆盖没有文本的区域，单击标记将其选中，然后"}<strong>{"删除"}</strong> {"将其移除，箭头轻推它并且"}{' '}
        <strong>Ctrl/Cmd-D</strong> {"重复它。"}</motion.p>

      {/* Destroy, not cover: the claim the run has to be able to keep. */}
      <motion.p variants={scaleIn} className="text-[10px] leading-relaxed text-ink-muted" data-redact-proof>
        {regionCount} {"面积"}{regionCount === 1 ? '' : 's'} {"将从页面内容中删除并覆盖 - 下面的文本从文件中消失，而不是隐藏。选择结果中的文本进行检查。"}</motion.p>

      {/* Selected info */}
      {selected && (
        <motion.div variants={scaleIn} className="rounded-[12px] border border-cream-border bg-white p-3 space-y-1 shadow-doodle">
          <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"已选·页"}{selected.page}</p>
          <div className="grid grid-cols-2 gap-1 text-[10px] text-ink-muted font-mono tabular-nums">
            <span>X: {(selected.x * 100).toFixed(0)}%</span>
            <span>Y: {(selected.y * 100).toFixed(0)}%</span>
            <span>W: {(selected.w * 100).toFixed(0)}%</span>
            <span>H: {(selected.h * 100).toFixed(0)}%</span>
          </div>
          <button onClick={() => removeRedaction(selected.id)}
            className="doodle-chip text-[10px] text-danger w-full">
            {"移除选定的"}</button>
        </motion.div>
      )}

      {/* What the run had to admit: skipped boxes, raster fallback, clamped input. */}
      {warnings.length > 0 && (
        <motion.ul
          variants={scaleIn}
          role="status"
          data-redact-warnings={warnings.length}
          className="space-y-1 rounded-[12px] border border-warn/25 bg-warn/[0.07] p-2.5"
        >
          {warnings.map((warning) => (
            <li key={warning} className="text-[10px] leading-relaxed text-ink-soft">· {warning}</li>
          ))}
        </motion.ul>
      )}

      {/* Boxes that will not survive the run */}
      {report.empty.length + report.offPage.length > 0 && (
        <motion.div variants={scaleIn} className="rounded-[12px] border border-warn/25 bg-warn/[0.07] p-2.5 space-y-1">
          <p className="text-[10px] font-semibold text-warn">
            {report.empty.length + report.offPage.length} {"的"}{st.redactions.length} {"盒子"}{st.redactions.length === 1 ? '' : 'es'} {"不会被写入"}</p>
          <ul className="space-y-0.5">
            {report.notes.map((note) => (
              <li key={note} className="text-[10px] leading-relaxed text-ink-soft">· {note}</li>
            ))}
          </ul>
          <button
            onClick={() => {
              for (const r of [...report.empty, ...report.offPage]) removeRedaction(r.id);
            }}
            className="doodle-chip text-[10px] doodle-chip-inactive"
          >
            {"移除它们"}</button>
        </motion.div>
      )}

      {/* Redaction list */}
      {st.redactions.length > 0 && (
        <motion.div variants={fadeUp} className="border-t border-cream-border pt-2">
          <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted mb-1.5">
            {"编辑（"}{st.redactions.length})
          </p>
          <div className="space-y-1 max-h-36 overflow-y-auto">
            {st.redactions.map((r) => (
              <motion.div key={r.id}
                onClick={() => selectRedaction(r.id)}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.97 }}
                transition={{ duration: 0.2 }}
                className={`flex items-center gap-2 p-1.5 rounded-[10px] cursor-pointer text-[10px]
                  ${r.id === st.selectedId ? 'bg-accent/[0.06] border border-accent/60 shadow-glow' : 'bg-white border border-cream-border hover:border-[#D5D5CD]'}`}
              >
                <span className="w-3 h-3 rounded-sm shrink-0" style={{ background: st.color }} />
                <span className="flex-1">
                  p.{r.page} · {r.free ? "面积" : r.lines ? `${r.lines.length} line${r.lines.length === 1 ? '' : 's'}` : "盒子"}
                </span>
                <button
                  onClick={(e) => { e.stopPropagation(); removeRedaction(r.id); }}
                  aria-label={`Remove the redaction on page ${r.page}`}
                  title={`Remove the redaction on page ${r.page}`}
                  className="grid h-7 w-7 shrink-0 place-items-center rounded-[8px] text-danger transition-colors duration-150 hover:bg-danger/10 hover:text-danger/80"
                >✕</button>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Page summary */}
      {st.redactions.length > 0 && (
        <p className="text-[10px] text-ink-muted font-mono tabular-nums">
          {Array.from(pageCounts.entries()).sort(([a], [b]) => a - b).map(([p, n]) => `p.${p}: ${n}`).join(' · ')}
        </p>
      )}

      <button onClick={handleProcess} id="tool-process-btn" className="doodle-btn-danger"
        disabled={!report.valid || isRunning}
        title={
          st.redactions.length === 0
            ? "首先在预览上拖动一个矩形 - 还没有什么需要编辑的"
            : !report.valid
              ? "所有方框均未涵盖本文档的任何内容"
              : undefined
        }>
        {isRunning ? "正在编辑……" : `Apply ${report.usable.length} Redaction${report.usable.length !== 1 ? 's' : ''}`}
      </button>
    </motion.div>
  );
}
