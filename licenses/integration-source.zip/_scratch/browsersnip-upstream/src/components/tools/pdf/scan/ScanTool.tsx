import { Button } from 'antd';
import { useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useFileStore } from '@/stores/file-store';
import { useProcessStore } from '@/stores/process-store';
import { usePdfTool } from '@/hooks/usePdfTool';
import { fadeUp, scaleIn, staggerParent } from '@/lib/motion';
import { navigateToTool } from '@/components/tools/pdf/editor/quickModes';

type PageSize = 'a4' | 'letter' | 'original' | 'fit';
type Orientation = 'portrait' | 'landscape';

/** The slider's range; a typed value outside it is clamped, not rejected (E15). */
export const MARGIN_MIN = 0;
export const MARGIN_MAX = 40;

export function clampMargin(value: number): number {
  if (!Number.isFinite(value)) return MARGIN_MIN;
  return Math.min(MARGIN_MAX, Math.max(MARGIN_MIN, Math.round(value)));
}

/** True when this browser context can offer a camera at all (E20). */
export function cameraAvailable(): boolean {
  return typeof navigator !== 'undefined' && Boolean(navigator.mediaDevices?.getUserMedia);
}

export interface ScanPlanReport {
  pages: number;
  valid: boolean;
  notes: string[];
}

/**
 * What "Generate PDF" is about to do (E13, E18).
 *
 * Zero captures must never reach the engine, and a fixed paper size with a big
 * margin is worth stating before the download rather than after it.
 */
export function scanPlanReport(input: {
  pages: number;
  pageSize: PageSize;
  orientation: Orientation;
  margin: number;
}): ScanPlanReport {
  const notes: string[] = [];
  const pages = Math.max(0, Math.floor(input.pages));
  if (pages === 0) {
    return {
      pages: 0,
      valid: false,
      notes: ['Nothing has been captured yet, so there is no page to build. Capture a page, or add photos that are already on this device.'],
    };
  }
  notes.push(
    `${pages} page${pages === 1 ? '' : 's'} on ${
      input.pageSize === 'a4' ? 'A4' : input.pageSize === 'letter' ? 'US Letter' : input.pageSize
    } ${input.orientation}, ${input.margin} pt border.`,
  );
  if (input.pageSize === 'fit' && input.margin === 0) {
    notes.push('With “Fit to image” and no margin the page is exactly the picture, bleed included.');
  }
  if (input.pageSize === 'original' && input.margin > MARGIN_MAX / 2) {
    notes.push('“Original size” keeps the photo’s own pixel size, so the margin is added outside it and the page grows.');
  }
  if (input.margin === MARGIN_MAX) {
    notes.push('That is the largest margin this tool offers; on a small photo it eats most of the page.');
  }
  return { pages, valid: true, notes };
}

export function ScanTool() {
  const files = useFileStore((s) => s.files);
  const { run, isRunning } = usePdfTool('scan-to-pdf');
  const warnings = useProcessStore((s) => s.warnings);
  const [pageSize, setPageSize] = useState<PageSize>('a4');
  const [orientation, setOrientation] = useState<Orientation>('portrait');
  const [margin, setMargin] = useState(10);

  const imageCount = files.length;
  const hasCamera = useMemo(() => cameraAvailable(), []);
  const plan = useMemo(
    () => scanPlanReport({ pages: imageCount, pageSize, orientation, margin }),
    [imageCount, margin, orientation, pageSize],
  );

  const handleProcess = useCallback(() => {
    if (!plan.valid) return;
    void run({ pageSize, orientation, margin, fit: 'contain' });
  }, [margin, orientation, pageSize, plan.valid, run]);

  if (imageCount === 0) {
    return (
      <motion.div
        initial="hidden"
        animate="visible"
        variants={staggerParent}
        className="doodle-section space-y-2"
      >
        <motion.p variants={fadeUp} className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted mb-1">{"扫描为PDF"}</motion.p>
        <p className="text-[11px] text-ink-muted">
          {"使用相机扫描文档页面。捕获的图像将出现在此处。"}</p>
        {hasCamera ? (
          <div className="mt-3 flex items-center gap-2 text-[10px] text-ink-muted">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            {"相机就绪 — 点击预览下方的按钮进行拍摄"}</div>
        ) : (
          <motion.div variants={scaleIn} className="mt-2 space-y-2 rounded-[12px] border border-warn/25 bg-warn/[0.07] p-3">
            <p className="text-[10px] font-semibold text-warn">{"在此上下文中没有相机"}</p>
            <p className="text-[10px] leading-relaxed text-ink-soft">
              {"浏览器没有给该页面提供相机API：相机访问需要安全上下文（https或localhost），并且一些设备根本没有相机。此设备上已有的照片仍然有效。"}</p>
            <Button
              htmlType="button"
              onClick={() => navigateToTool('image-to-pdf')}
              className="doodle-chip text-[10px] doodle-chip-inactive"
            >
              {"添加照片 → 图像转 PDF"}</Button>
          </motion.div>
        )}
      </motion.div>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={staggerParent}
      className="doodle-section space-y-3"
    >
      <motion.div variants={fadeUp}>
        <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"扫描为PDF"}</p>
        <p className="text-[11px] text-ink-muted mt-0.5">
          {imageCount} {"页"}{imageCount !== 1 ? 's' : ''} {"捕获"}</p>
      </motion.div>

      {/* Page size */}
      <motion.div variants={fadeUp}>
        <label className="block font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"页面尺寸"}</label>
        <select
          value={pageSize}
          onChange={(e) => setPageSize(e.target.value as PageSize)}
          className="doodle-input mt-1 text-[11px]"
        >
          <option value="a4">A4</option>
          <option value="letter">{"信"}</option>
          <option value="fit">{"适合图像"}</option>
          <option value="original">{"原始尺寸"}</option>
        </select>
      </motion.div>

      {/* Orientation */}
      <motion.div variants={fadeUp}>
        <label className="block font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"方向"}</label>
        <select
          value={orientation}
          onChange={(e) => setOrientation(e.target.value as Orientation)}
          className="doodle-input mt-1 text-[11px]"
        >
          <option value="portrait">{"肖像"}</option>
          <option value="landscape">{"风景"}</option>
        </select>
      </motion.div>

      {/* Margin */}
      <motion.div variants={fadeUp}>
        <label className="block font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">
          {"保证金："}<span className="tabular-nums">{margin}{"点"}</span>
        </label>
        <div className="flex items-center gap-2">
          <input
            type="range"
            min={MARGIN_MIN}
            max={MARGIN_MAX}
            value={margin}
            onChange={(e) => setMargin(clampMargin(Number(e.target.value)))}
            className="w-full mt-1"
          />
          <input
            type="number"
            min={MARGIN_MIN}
            max={MARGIN_MAX}
            step={1}
            value={margin}
            onChange={(e) => setMargin(clampMargin(e.target.valueAsNumber))}
            className="doodle-input w-16 text-center text-[11px] tabular-nums"
            aria-label={"利润（以点数为单位）"}
          />
        </div>
      </motion.div>

      <motion.ul
        variants={scaleIn}
        data-scan-plan={plan.notes.length}
        className="space-y-1 rounded-[12px] border border-cream-border bg-cream-soft px-3 py-2 text-[10px] leading-relaxed text-ink-muted"
      >
        {plan.notes.map((note) => (
          <li key={note}>· {note}</li>
        ))}
      </motion.ul>

      <motion.div
        variants={scaleIn}
        className="flex items-center justify-between rounded-[12px] border border-cream-border bg-white px-3.5 py-2.5 shadow-doodle"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-ink-muted">{"页面"}</span>
        <span className="font-mono text-xs font-semibold tabular-nums text-accent">{imageCount}</span>
      </motion.div>

      {/* Captures the run could not decode are named, not swallowed. */}
      {warnings.length > 0 && (
        <motion.ul
          variants={scaleIn}
          role="status"
          data-scan-warnings={warnings.length}
          className="space-y-1 rounded-[12px] border border-warn/25 bg-warn/[0.07] px-3 py-2.5 text-[10px] leading-relaxed text-warn"
        >
          {warnings.map((warning) => (
            <li key={warning}>· {warning}</li>
          ))}
        </motion.ul>
      )}

      <Button
        onClick={handleProcess}
        id="tool-process-btn"
        className="doodle-btn w-full"
        disabled={!plan.valid || isRunning}
      >
        {isRunning
          ? "构建PDF……"
          : `Generate PDF${plan.valid ? ` (${plan.pages} page${plan.pages === 1 ? '' : 's'})` : ''}`}
      </Button>
    </motion.div>
  );
}
