import { Button } from 'antd';
import { useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { usePDFRenderer } from '@/hooks/usePDFRenderer';
import { useFileStore } from '@/stores/file-store';
import { scaleIn } from '@/lib/motion';

interface PDFViewerProps {
  scale?: number;
  showControls?: boolean;
  fileOverride?: File | null;
}

export function PDFViewer({ scale = 1.5, showControls = true, fileOverride }: PDFViewerProps) {
  const storeFile = useFileStore((s) => s.file);
  const file = fileOverride !== undefined ? fileOverride : storeFile;
  const {
    doc,
    pageCount,
    currentPage,
    loading,
    error,
    canvasRef,
    loadDoc,
    goToPage,
    nextPage,
    prevPage,
  } = usePDFRenderer({ scale });

  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (file) {
      file.arrayBuffer().then((buf) => loadDoc(buf));
    }
  }, [file, loadDoc]);

  // Keyboard navigation
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') nextPage();
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') prevPage();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [nextPage, prevPage]);

  if (!file) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-center opacity-40">
          <div className="mb-3 text-4xl">📄</div>
          <p className="text-xs font-medium text-ink-muted">
            {"导入PDF进行预览"}</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <motion.div
        variants={scaleIn}
        initial="hidden"
        animate="visible"
        className="flex h-full items-center justify-center"
      >
        <div className="text-center">
          <div className="mb-3 animate-spin text-3xl">⏳</div>
          <p className="text-xs text-ink-muted">{"正在加载 PDF..."}</p>
        </div>
      </motion.div>
    );
  }

  if (error) {
    return (
      <div className="flex h-full items-center justify-center">
        <motion.div
          variants={scaleIn}
          initial="hidden"
          animate="visible"
          className="mx-4 max-w-md rounded-[12px] border border-danger/25 bg-danger/[0.07] px-4 py-3 text-center"
        >
          <div className="mb-3 text-3xl">⚠️</div>
          <p className="text-xs font-semibold text-danger">{"无法加载PDF"}</p>
          <p className="mt-1 text-[11px] text-ink-soft">{error}</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full" ref={containerRef}>
      {/* Canvas */}
      <div className="flex-1 flex items-center justify-center overflow-auto bg-cream-soft p-4 min-h-0">
        <canvas
          ref={canvasRef}
          className="max-w-full max-h-full rounded-[14px] border border-cream-border shadow-doodle-card"
          style={{ display: doc ? 'block' : 'none' }}
        />
      </div>

      {/* Controls */}
      {showControls && doc && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="flex items-center justify-center gap-3 border-t border-cream-border bg-white px-4 py-2 shrink-0"
        >
          <Button
            onClick={prevPage}
            disabled={currentPage <= 1}
            className="text-[11px] font-medium text-ink-soft hover:text-ink disabled:opacity-30 transition-colors px-2 py-1"
          >
            {"← 上一页"}</Button>

          <span className="text-[11px] font-mono text-ink-muted tabular-nums min-w-[60px] text-center">
            {currentPage} / {pageCount}
          </span>

          <Button
            onClick={nextPage}
            disabled={currentPage >= pageCount}
            className="text-[11px] font-medium text-ink-soft hover:text-ink disabled:opacity-30 transition-colors px-2 py-1"
          >
            {"下一步 →"}</Button>

          <div className="w-px h-4 bg-cream-border mx-1" />

          <input
            type="number"
            min={1}
            max={pageCount}
            value={currentPage}
            onChange={(e) => {
              const v = parseInt(e.target.value);
              if (v >= 1 && v <= pageCount) goToPage(v);
            }}
            className="doodle-input w-16 text-center text-[11px] px-2 py-1"
            aria-label={"转到页面"}
          />
        </motion.div>
      )}
    </div>
  );
}
