from pathlib import Path
import subprocess,shutil,json,sys
root=Path('../..').resolve();build=Path('.ant-build');site=root/'toolbox-site';deploy=Path('../masaka5-toolbox-upstream').resolve()
targets=[site] if '--site-only' in sys.argv else [site,deploy]
# Same sole HTML postprocess as finalize-toolbox-vendors.cjs; no shared script edits.
p=build/'index.html';s=p.read_text(encoding='utf-8');s=s.replace('</head>','<link rel="stylesheet" href="../../assets/integrated-tools.css"></head>');p.write_text(s,encoding='utf-8')
current=['tools/documents/'+p.relative_to(build).as_posix() for p in build.rglob('*') if p.is_file()]
tracked=subprocess.check_output(['git','-C',str(deploy),'ls-files','tools/documents/assets'],text=True).splitlines();removed=[]
for rel in tracked:
 if rel not in current:
  removed.append(rel)
  for target in [base/rel for base in targets]:
   if target.exists():target.unlink()
for src in build.rglob('*'):
 if src.is_file():
  rel=src.relative_to(build)
  for target in [base/'tools/documents'/rel for base in targets]:
   target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
(root/('.superpowers/'+(sys.argv[1] if len(sys.argv)>1 else 'task-3-artifacts.json'))).write_text(json.dumps({'current':current,'removed':removed},indent=2))
print('build',len(current),'removed tracked assets',len(removed),'targets',len(targets))
