from pathlib import Path
import json,hashlib,zipfile,subprocess,re,sys
root=Path('../..').resolve();site=root/'toolbox-site/licenses';deploy=Path('../masaka5-toolbox-upstream/licenses').resolve();site.mkdir(exist_ok=True)
excluded={'.git','node_modules','dist','.ant-build','.github','.od-skills'}
files=[]
for p in Path('.').rglob('*'):
 if not p.is_file() or any(x in excluded for x in p.parts):continue
 if p.suffix in ['.log','.zip'] or p.name.startswith('.env') or re.search(r'(secret|credential)',p.name,re.I):continue
 if p.parts[0]=='docs' and (p.suffix.lower() in ['.png','.jpg','.jpeg','.webp','.gif','.pdf'] or 'shots' in p.parts):continue
 if p.parts[0]=='reports' and p.suffix.lower() not in ['.json']:continue
 files.append(p)
archive=site/'browsersnip-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.as_posix())
manifest={'project':'BrowserSnip','upstream_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'modified':True,'antd':'5.29.3','build':'npm ci; npx vite build --config toolbox.vite.config.ts','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'exclusions':['node_modules','.git','dist','.ant-build','.env/secrets','docs research screenshots/nonbuild binary images','generated browser screenshots'],'files':[{'path':p.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]}
(site/'browsersnip-source-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
notices=['BrowserSnip: upstream README declares MIT. Original README retained in source archive.','Modified source uses Ant Design 5.29.3 (MIT). Dependency declarations and original license texts follow.']
for p in sorted(Path('node_modules').glob('**/package.json')):
 try:pkg=json.loads(p.read_text(encoding='utf-8'))
 except:continue
 if not pkg.get('name'):continue
 notices.append('\n--- '+pkg['name']+' '+str(pkg.get('version',''))+' | '+str(pkg.get('license','see original notices'))+' ---')
 for lp in p.parent.iterdir():
  if lp.is_file() and re.match(r'^(licen[cs]e|copying|notice)(\.|$)',lp.name,re.I):
   try:notices.append(lp.read_text(encoding='utf-8'))
   except:pass
(site/'browsersnip-third-party.txt').write_text('\n'.join(notices),encoding='utf-8')
# Preserve all other registration entries verbatim semantically.
p=site/'sources.json';sources=json.loads(p.read_text(encoding='utf-8'));row=next(x for x in sources if x['project']=='browsersnip-upstream');row.update({'source_archive':'browsersnip-source.zip','source_manifest':'browsersnip-source-manifest.json','third_party_notices':'browsersnip-third-party.txt'});p.write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
import shutil
if '--site-only' not in sys.argv:
 for name in ['browsersnip-source.zip','browsersnip-source-manifest.json','browsersnip-third-party.txt']:shutil.copyfile(site/name,deploy/name)
print('archive bytes',archive.stat().st_size,'files',len(files),'notices bytes',(site/'browsersnip-third-party.txt').stat().st_size)
