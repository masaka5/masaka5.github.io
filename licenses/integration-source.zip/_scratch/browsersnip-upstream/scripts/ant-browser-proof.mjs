import {createRequire} from 'node:module';import fs from 'node:fs';import path from 'node:path';
const require=createRequire(import.meta.url);const {chromium}=require('playwright-core');const {PDFDocument,StandardFonts}=require('pdf-lib');
const base=process.env.BASE||'http://127.0.0.1:5197/';const out=path.resolve('reports/ant-browser');fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROME||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});const page=await browser.newPage({acceptDownloads:true,viewport:{width:1440,height:900}});let errors=[];page.on('pageerror',e=>errors.push(String(e)));const results=[];
async function goto(id){await page.goto(`${base}#/tool/${id}`);await page.reload();await page.locator('input[type=file]').first().waitFor({state:'attached'});}
async function fixture(label){const d=await PDFDocument.create();const p=d.addPage([300,400]);p.drawText(label,{x:30,y:350,font:await d.embedFont(StandardFonts.Helvetica)});return Buffer.from(await d.save());}
const a=await fixture('ALPHA 123'),b=await fixture('BETA 456');
async function run(id,files){await goto(id);const another=page.getByRole('button',{name:'再做一次',exact:true});if(await another.count())await another.click();await page.locator('input[type=file]').first().setInputFiles(files);const run=page.locator('[data-run=true]');await run.waitFor();await run.click();const dl=page.getByRole('button',{name:'下载',exact:true});await dl.waitFor({timeout:60000});const [download]=await Promise.all([page.waitForEvent('download'),dl.click()]);const file=path.join(out,`${id}-${download.suggestedFilename()}`);await download.saveAs(file);return file;}
try{
 const merged=await run('merge',[{name:'alpha.pdf',mimeType:'application/pdf',buffer:a},{name:'beta.pdf',mimeType:'application/pdf',buffer:b}]);const md=await PDFDocument.load(fs.readFileSync(merged));if(md.getPageCount()!==2)throw Error('merge page count');results.push({tool:'merge',pages:2,export:merged});await page.screenshot({path:path.join(out,'desktop.png')});
 await goto('rotate');await page.locator('input[type=file]').first().setInputFiles(merged);await page.locator('[data-run=true]').waitFor();results.push({tool:'rotate',reimport:'merged PDF accepted'});
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6nQAAAABJRU5ErkJggg==','base64');
 const imagePdf=await run('image-to-pdf',[{name:'pixel.png',mimeType:'image/png',buffer:png}]);const ip=await PDFDocument.load(fs.readFileSync(imagePdf));if(ip.getPageCount()!==1)throw Error('image page count');results.push({tool:'image-to-pdf',pages:1});
 const textPdf=await run('txt-to-pdf',[{name:'known.txt',mimeType:'text/plain',buffer:Buffer.from('KNOWN TEXT 314159\nSecond line')}]);const tp=await PDFDocument.load(fs.readFileSync(textPdf));if(tp.getPageCount()!==1)throw Error('text page count');results.push({tool:'txt-to-pdf',pages:1});
 const roundtrip=await run('merge',[imagePdf,textPdf]);if((await PDFDocument.load(fs.readFileSync(roundtrip))).getPageCount()!==2)throw Error('converted file reimport');results.push({tool:'merge',reimport:'image/text outputs',pages:2});
 await page.setViewportSize({width:390,height:844});await goto('txt-to-pdf');await page.locator('input[type=file]').first().setInputFiles({name:'long.txt',mimeType:'text/plain',buffer:Buffer.from(Array.from({length:500},(_,i)=>`Line ${i+1} known long text`).join('\n'))});await page.locator('[data-run=true]').click();await page.getByRole('button',{name:'下载',exact:true}).waitFor({timeout:60000});await page.screenshot({path:path.join(out,'mobile-long.png')});const sizing=await page.evaluate(()=>({window:innerHeight,document:document.documentElement.scrollHeight,scrollable:[...document.querySelectorAll('*')].filter(e=>e.scrollHeight>e.clientHeight+2&&['auto','scroll'].includes(getComputedStyle(e).overflowY)).length}));if(sizing.document>sizing.window+1)throw Error('mobile overflow '+JSON.stringify(sizing));results.push({tool:'txt-to-pdf',mobileLong:sizing});
}catch(e){results.push({failure:String(e),body:(await page.locator('body').innerText()).slice(-2000)});process.exitCode=1;}
fs.writeFileSync(path.join(out,'functional.json'),JSON.stringify({results,errors},null,2));console.log(JSON.stringify({results,errors}));await browser.close();





