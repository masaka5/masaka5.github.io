from pathlib import Path
import re,json
sites=[]
for p in Path('src/components').rglob('*.tsx'):
 for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
  for m in re.finditer(r'<(Button|Select|Slider|Input(?:\.TextArea)?|Upload|Tabs|Progress|input|select|textarea|motion\.button)\b',line):
   native=m[1] in ['input','select','textarea','motion.button']
   sites.append({'path':p.as_posix(),'line':i,'control':m[1],'mode':'native-themed' if native else 'Ant Design','reason':'Retains canvas/editor field event, raw numeric editing, browser color/file APIs or scrubber lifecycle' if native else 'Actual component import; original React callback preserved'})
Path('reports').mkdir(exist_ok=True)
Path('reports/ant-control-inventory.json').write_text(json.dumps({'sites':sites,'counts':{c:sum(x['control']==c for x in sites) for c in sorted(set(x['control'] for x in sites))}},ensure_ascii=False,indent=2),encoding='utf-8')
