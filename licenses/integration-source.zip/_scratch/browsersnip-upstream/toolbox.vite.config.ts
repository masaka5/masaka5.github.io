import {defineConfig,mergeConfig} from 'vite';import original from './vite.config';
export default mergeConfig(original,defineConfig({build:{outDir:'../../toolbox-site/tools/documents',emptyOutDir:false,reportCompressedSize:false},publicDir:'public'}));
