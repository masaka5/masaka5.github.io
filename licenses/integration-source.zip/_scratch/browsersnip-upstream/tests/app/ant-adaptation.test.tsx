import {afterEach, expect, it, vi} from 'vitest';
import {cleanup, fireEvent, render, screen} from '@testing-library/react';
import {FieldControl} from '@/components/tools/pdf/shared/FieldControls';
import {FileIntake, intakeCopy} from '@/components/tools/pdf/shared/FileIntake';
afterEach(cleanup);
it('uses Ant intake action without changing picker behavior',()=>{
 const open=vi.fn();render(<FileIntake title="合并 PDF" promise="" copy={intakeCopy()} controls={{open,dragging:false,inputProps:{} as any}}/>);
 const button=screen.getByRole('button',{name:'选择PDF文件'});expect(button).toHaveClass('ant-btn');fireEvent.click(button);expect(open).toHaveBeenCalledOnce();
});
it('retains numeric raw value for downstream clamping',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'dpi',label:'分辨率',type:'number',min:72,max:300,default:150}} values={{dpi:150}} onChange={change}/>);
 fireEvent.change(screen.getByLabelText('分辨率'),{target:{value:'400'}});expect(change).toHaveBeenCalledWith('dpi',400);
});
it('Ant select preserves numeric options rather than stringifying tool values',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'rotation',label:'旋转',type:'select',options:[{value:90,label:'90°'},{value:180,label:'180°'}]}} values={{rotation:90}} onChange={change}/>);
 const box=screen.getByRole('combobox');expect(box.closest('.ant-select')).toBeTruthy();fireEvent.mouseDown(box);fireEvent.click(screen.getAllByText('180°').at(-1)!);expect(change).toHaveBeenCalledWith('rotation',180);
});
it('attachment upload reads real bytes and keeps multiple selection order',async()=>{
 const change=vi.fn();const {container}=render(<FieldControl field={{key:'attachments',label:'附件',type:'file',multiple:true}} values={{attachments:[]}} onChange={change}/>);
 expect(container.querySelector('.ant-upload')).toBeTruthy();
 const a=new File(['alpha'],'a.txt',{type:'text/plain'});Object.defineProperty(a,'arrayBuffer',{value:async()=>new TextEncoder().encode('alpha').buffer});
 const b=new File(['beta'],'b.txt',{type:'text/plain'});Object.defineProperty(b,'arrayBuffer',{value:async()=>new TextEncoder().encode('beta').buffer});
 fireEvent.change(container.querySelector('input[type=file]')!,{target:{files:[a,b]}});
 await vi.waitFor(()=>expect(change).toHaveBeenCalledOnce());
 const outputs=change.mock.calls[0][1];expect(outputs.map((x:any)=>x.name)).toEqual(['a.txt','b.txt']);expect(new TextDecoder().decode(outputs[1].bytes)).toBe('beta');
});
it('slider keyboard forwards bounded numeric values',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'quality',label:'质量',type:'slider',min:0,max:100,step:5}} values={{quality:50}} onChange={change}/>);
 fireEvent.keyDown(screen.getByRole('slider',{name:'质量'}),{key:'ArrowRight',code:'ArrowRight',keyCode:39});expect(change).toHaveBeenCalledWith('quality',55);
});
import { ProgressBar } from '@/components/tools/pdf/shared/ProgressBar';
it('determinate progress exposes exactly one labelled progressbar',()=>{
 render(<ProgressBar percent={40} label="处理进度" message="读取第二页"/>);
 const bars=screen.getAllByRole('progressbar');expect(bars).toHaveLength(1);expect(bars[0]).toHaveAccessibleName('处理进度');expect(bars[0]).toHaveAttribute('aria-valuenow','40');expect(bars[0]).toHaveAttribute('aria-valuetext','40% — 读取第二页');
});
it('unknown progress never exposes a fabricated percentage',()=>{
 const {container}=render(<ProgressBar percent={0} indeterminate label="处理进度" message="正在读取"/>);
 const bars=screen.getAllByRole('progressbar');expect(bars).toHaveLength(1);expect(bars[0]).not.toHaveAttribute('aria-valuenow');expect(bars[0]).toHaveAttribute('aria-valuetext','正在读取');expect(container.querySelectorAll('[aria-valuenow]')).toHaveLength(0);
});
it('slider labels and descriptions belong to the keyboard-operable handle',()=>{
 const change=vi.fn();render(<FieldControl field={{key:'dpiSlider',label:'输出质量',type:'slider',min:0,max:100,step:5}} values={{dpiSlider:50}} onChange={change} notice="最大100"/>);
 const slider=screen.getByRole('slider',{name:'输出质量'});expect(slider).toHaveAccessibleDescription('最大100');fireEvent.change(slider,{target:{value:'55'}});expect(change).toHaveBeenCalledWith('dpiSlider',55);
});
import { SignTool } from '@/components/tools/pdf/security/SignTool';
it('signature tabs connect their keyboard-selected panel to real controls',async()=>{
 render(<SignTool/>);const textTab=screen.getByRole('tab',{name:'文本'});const panel=document.getElementById(textTab.getAttribute('aria-controls')!)!;expect(panel).toHaveAttribute('role','tabpanel');expect(panel.querySelector('input[type=text]')).toBeTruthy();expect(screen.getAllByRole('tabpanel')).toHaveLength(1);
 textTab.focus();fireEvent.keyDown(textTab,{key:'ArrowRight',code:'ArrowRight',keyCode:39});fireEvent.keyDown(screen.getByRole('tab',{name:/图像/,hidden:true}),{key:'Enter',code:'Enter',keyCode:13});
 await vi.waitFor(()=>expect(screen.getByRole('tab',{name:/图像/,hidden:true})).toHaveAttribute('aria-selected','true'));
 const image=screen.getByRole('tab',{name:/图像/,hidden:true});expect(document.getElementById(image.getAttribute('aria-controls')!)!.querySelector('input[type=file]')).toBeTruthy();expect(document.getElementById(textTab.getAttribute('aria-controls')!)?.querySelector('input[type=text]')).toBeFalsy();
});

