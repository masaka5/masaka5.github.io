import {afterEach,beforeEach,expect,it,vi} from 'vitest';
import {File as RealFile,Blob as RealBlob} from 'node:buffer';
import {useFileStore as files} from '@/stores/file-store';
import {useProcessStore as process} from '@/stores/process-store';
import {createSessionRecovery} from '@/stores/session-recovery';
const blankFiles=()=>files.setState({activeTool:null,sessions:{},file:null,files:[],params:{},metadata:null,previewFileIndex:0,probing:false});
const blankProcess=()=>{process.getState().reset();process.setState({activeTool:null,sessions:{}})};
beforeEach(()=>{vi.stubGlobal('File',RealFile);vi.stubGlobal('Blob',RealBlob);vi.stubGlobal('URL',{createObjectURL:vi.fn(()=>`blob:new-${Math.random()}`),revokeObjectURL:vi.fn()});blankFiles();blankProcess()});afterEach(()=>{vi.restoreAllMocks();vi.unstubAllGlobals()});
const memory=()=>{let value:any;return {read:async()=>structuredClone(value),write:async(next:any)=>{value=structuredClone(next)},value:()=>value}};
it('refresh restores real file bytes, safe params, preview and downloadable output with new URLs',async()=>{
 const db=memory();const first=createSessionRecovery(db);await first.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');
 const input=new File(['%PDF-known bytes'],'known.pdf',{type:'application/pdf',lastModified:123});files.getState().setFiles([input,new File(['second'],'second.pdf')]);files.getState().setParams({rotation:180,nested:{scale:1.5}});files.getState().setPreviewFileIndex(1);
 const out=new Blob(['%PDF-output exact'],{type:'application/pdf'});process.getState().setOutput(out,'blob:old','known_merged.pdf');await first.flush();first.dispose();blankFiles();blankProcess();
 const second=createSessionRecovery(db);await second.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');expect(await files.getState().file!.text()).toBe('%PDF-known bytes');expect(files.getState().file!.name).toBe('known.pdf');expect(files.getState().params).toEqual({rotation:180,nested:{scale:1.5}});expect(files.getState().previewFileIndex).toBe(1);expect(await process.getState().outputBlob!.text()).toBe('%PDF-output exact');expect(process.getState().outputNames).toEqual(['known_merged.pdf']);expect(process.getState().outputUrl).not.toBe('blob:old');expect(process.getState().isProcessing).toBe(false);second.dispose();
});
it('back navigation retains preview and clear then refresh cannot resurrect artifacts',async()=>{
 const db=memory();const r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');files.getState().setFile(new File(['x'],'x.pdf'));files.getState().setPreviewFileIndex(3);files.getState().setActiveTool('rotate');process.getState().setActiveTool('rotate');files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');expect(files.getState().previewFileIndex).toBe(3);
 files.getState().clearCurrent();process.getState().reset();await r.flush();r.dispose();blankFiles();blankProcess();const again=createSessionRecovery(db);await again.hydrate();files.getState().setActiveTool('merge');expect(files.getState().files).toEqual([]);again.dispose();
});
it('startup storage read cannot overwrite newer edits; unavailable storage stays usable',async()=>{
 let finish!:(value:any)=>void;const r=createSessionRecovery({read:()=>new Promise(resolve=>finish=resolve),write:async()=>{throw Error('quota')}});const pending=r.hydrate();files.getState().setActiveTool('merge');files.getState().setFile(new File(['new'],'new.pdf'));finish({version:1,entries:{merge:{}}});await pending;expect(files.getState().file!.name).toBe('new.pdf');await r.flush();r.dispose();const bad=createSessionRecovery({read:async()=>{throw Error('unavailable')},write:async()=>{throw Error('quota')}});await expect(bad.hydrate()).resolves.toBeUndefined();bad.dispose();
});
it('never restores interrupted work or unlocked encrypted authority; revokes all replaced URLs',async()=>{
 const db=memory(),r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('rotate');process.getState().setActiveTool('rotate');files.getState().setFile(new File(['%PDF-1.7 /Encrypt 2 0 R'],'locked.pdf',{type:'application/pdf'}));process.getState().setFileState('locked.pdf',{lock:'opened',pages:2});process.getState().setOutput(new Blob(['decrypted']),'blob:decrypted','clear.pdf');process.getState().addOutput(new Blob(['second']),'blob:second','second.pdf');process.getState().startProcessing('rotate','');expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:decrypted');expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:second');await r.flush();r.dispose();blankFiles();blankProcess();const again=createSessionRecovery(db);await again.hydrate();files.getState().setActiveTool('rotate');process.getState().setActiveTool('rotate');expect(process.getState().isProcessing).toBe(false);expect(process.getState().outputBlob).toBeNull();expect(process.getState().fileStates).toEqual({});again.dispose();
});

it('credential params are recursively omitted and their derived output is not cached',async()=>{
 const db=memory(),r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('protect');process.getState().setActiveTool('protect');files.getState().setFile(new File(['plain'],'plain.txt'));files.getState().setParams({password:'secret',nested:{cookie:'cookie',scale:2},token:'token'});process.getState().setOutput(new Blob(['derived']),'blob:derived','protected.pdf');await r.flush();expect(db.value().entries.protect.params).toEqual({nested:{scale:2}});expect(db.value().entries.protect.outputs).toEqual([]);r.dispose();
});
import {IDBFactory, IDBObjectStore} from 'fake-indexeddb';
import {indexedDbStorage} from '@/stores/session-recovery';
it('real IndexedDB adapter roundtrips original binary data and corrupt cache is ignored',async()=>{
 vi.stubGlobal('indexedDB',new IDBFactory());const db=indexedDbStorage();const r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');files.getState().setFile(new File(['binary\0\xff'],'real.pdf',{type:'application/pdf'}));await r.flush();r.dispose();blankFiles();blankProcess();const restored=createSessionRecovery(db);await restored.hydrate();files.getState().setActiveTool('merge');expect(await files.getState().file!.text()).toBe('binary\0\xff');restored.dispose();await db.write({version:1,entries:{broken:null}});const corrupt=createSessionRecovery(db);await expect(corrupt.hydrate()).resolves.toBeUndefined();corrupt.dispose();
});
it.each(['clear','remove'])('failed replacement puts invalidate prior durable files/results after %s',async(action)=>{
 vi.stubGlobal('indexedDB',new IDBFactory());const db=indexedDbStorage(),r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');files.getState().setFile(new File(['old'],'old.pdf'));process.getState().setOutput(new Blob(['old result']),'blob:old','old-result.pdf');await r.flush();expect((await db.read() as any).entries.merge.outputs).toHaveLength(1);
 const put=vi.spyOn(IDBObjectStore.prototype,'put').mockImplementation(()=>{throw new DOMException('full','QuotaExceededError')});
 if(action==='clear')files.getState().clearCurrent();else files.getState().removeFile(0);await r.flush();put.mockRestore();r.dispose();blankFiles();blankProcess();const restored=createSessionRecovery(db);await restored.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');expect(files.getState().files).toEqual([]);expect(files.getState().file).toBeNull();expect(process.getState().outputBlob).toBeNull();restored.dispose();
});
it('failed old replacement cleanup finishes before a newer successful durable write',async()=>{
 vi.stubGlobal('indexedDB',new IDBFactory());const db=indexedDbStorage();let failures=0,attempts=0,release!:()=>void;const wrapped={...db,write:async(value:unknown)=>{if(failures){failures--;attempts++;await new Promise<void>(resolve=>release=resolve);throw Error('quota')}await db.write(value)}};const r=createSessionRecovery(wrapped);await r.hydrate();files.getState().setActiveTool('merge');files.getState().setFile(new File(['old'],'old.pdf'));await r.flush();failures=2;files.getState().clearCurrent();const saving=r.flush();await vi.waitFor(()=>expect(attempts).toBe(1));files.getState().setFile(new File(['new'],'new.pdf'));release();await vi.waitFor(()=>expect(attempts).toBe(2));release();await saving;expect((await db.read() as any).entries.merge.files[0].name).toBe('new.pdf');r.dispose();
});
it('serializes async writes and flush waits for the newest snapshot',async()=>{
 let stored:any;let release!:(value?:unknown)=>void;let block=true;const db={read:async()=>undefined,write:async(v:any)=>{if(block){block=false;await new Promise(r=>release=r)}stored=v}};const r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('merge');files.getState().setFile(new File(['old'],'old.pdf'));const saving=r.flush();await vi.waitFor(()=>expect(release).toBeTypeOf('function'));files.getState().setFile(new File(['new'],'new.pdf'));release();await saving;expect(stored.entries.merge.files[0].name).toBe('new.pdf');r.dispose();
});
it('bounded cache evicts beyond ten tools and oversized entry without throwing',async()=>{
 const db=memory(),r=createSessionRecovery(db);await r.hydrate();for(let i=0;i<12;i++){files.getState().setActiveTool(`tool-${i}`);files.getState().setFile(new File(['x'],`file-${i}.txt`));}await r.flush();expect(Object.keys(db.value().entries).length).toBe(10);expect(db.value().entries['tool-11']).toBeTruthy();r.dispose();
});
it('removing an input invalidates the completed result and revokes its URL',async()=>{
 const db=memory(),r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('merge');process.getState().setActiveTool('merge');files.getState().setFiles([new File(['a'],'a.pdf'),new File(['b'],'b.pdf')]);process.getState().setOutput(new Blob(['combined']),'blob:combined','combined.pdf');files.getState().removeFile(1);expect(process.getState().outputBlob).toBeNull();expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:combined');await r.flush();expect(db.value().entries.merge.outputs).toEqual([]);r.dispose();
});
it('leaving an interrupted tool never revives a busy session on back navigation',()=>{
 files.getState().setActiveTool('rotate');process.getState().setActiveTool('rotate');files.getState().setFile(new File(['x'],'x.pdf'));process.getState().startProcessing('rotate','');process.getState().setActiveTool('merge');process.getState().setActiveTool('rotate');expect(process.getState().isProcessing).toBe(false);expect(process.getState().phase).not.toBe('running');
});
it('completed decrypted outputs are excluded even when the run is already done',async()=>{
 const db=memory(),r=createSessionRecovery(db);await r.hydrate();files.getState().setActiveTool('rotate');process.getState().setActiveTool('rotate');files.getState().setFile(new File(['%PDF-1.7\n/Encrypt 4 0 R'],'locked.pdf',{type:'application/pdf'}));process.getState().setFileState('locked.pdf',{lock:'opened'});process.getState().setOutput(new Blob(['cleartext']),'blob:clear','clear.pdf');await r.flush();expect(db.value().entries.rotate.outputs).toEqual([]);expect(db.value().entries.rotate.fileStates).toBeUndefined();r.dispose();
});
it('clear/remove during an outstanding write is the final durable snapshot',async()=>{
 let stored:any,release!:()=>void,hold=true;const r=createSessionRecovery({read:async()=>undefined,write:async(v:any)=>{if(hold){hold=false;await new Promise<void>(resolve=>release=resolve)}stored=v}});await r.hydrate();files.getState().setActiveTool('merge');files.getState().setFile(new File(['old'],'old.pdf'));const pending=r.flush();await vi.waitFor(()=>expect(release).toBeTypeOf('function'));files.getState().clearCurrent();process.getState().reset();release();await pending;expect(stored.entries.merge).toBeUndefined();r.dispose();
});
import {renderHook,act,cleanup} from '@testing-library/react';
import {useFFmpeg} from '@/hooks/useFFmpeg';
const media=vi.hoisted(()=>({get:vi.fn(),terminate:vi.fn(async()=>{})}));
vi.mock('@/lib/ffmpeg/core',()=>({getFFmpeg:media.get,terminateFFmpeg:media.terminate}));
it('navigation during awaited failure cleanup cannot set the destination error',async()=>{
 let release!:()=>void;media.get.mockRejectedValueOnce(Error('old run failed'));media.terminate.mockImplementationOnce(()=>new Promise<void>(resolve=>release=resolve));const error=vi.spyOn(console,'error').mockImplementation(()=>{});
 process.getState().setActiveTool('trim');const {result,unmount}=renderHook(()=>useFFmpeg());let work!:Promise<Blob|null>;act(()=>{work=result.current.process([],new File(['video'],'input.mp4'),'out.mp4',{duration:1} as any,'Trim','trim')});await vi.waitFor(()=>expect(release).toBeTypeOf('function'));process.getState().setActiveTool('rotate');release();await work;expect(process.getState().error).toBeNull();unmount();error.mockRestore();cleanup();
});
it('a media run unmounted during navigation cannot publish output into another tool',async()=>{
 let release!:()=>void;media.get.mockResolvedValue({on(){},off(){},writeFile:async()=>{},exec:()=>new Promise<void>(r=>release=r),readFile:async()=>new Uint8Array([1,2]),deleteFile:async()=>{}});
 files.getState().setActiveTool('trim');process.getState().setActiveTool('trim');const {result,unmount}=renderHook(()=>useFFmpeg());let work!:Promise<Blob|null>;act(()=>{work=result.current.process([],new File(['video'],'input.mp4'),'out.mp4',{duration:1} as any,'Trim','trim')});await vi.waitFor(()=>expect(release).toBeTypeOf('function'));unmount();process.getState().setActiveTool('rotate');release();await work;expect(process.getState().outputBlob).toBeNull();cleanup();
});
