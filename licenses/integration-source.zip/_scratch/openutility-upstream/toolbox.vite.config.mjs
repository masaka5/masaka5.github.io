import {viewStatePlugin} from './scripts/view-state-transform.mjs';
import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';import tailwindcss from '@tailwindcss/vite';import {resolve} from 'node:path';
export default defineConfig({base:'./',plugins:[viewStatePlugin(),react(),tailwindcss()],resolve:{alias:{'@':resolve('.') }},worker:{format:'es'},build:{outDir:'../../toolbox-site/tools/utilities',emptyOutDir:false,target:'es2022',chunkSizeWarningLimit:2000,rollupOptions:{input:resolve('toolbox.html')}},publicDir:'public'});
