import {useEffect,useState,type Dispatch,type SetStateAction} from 'react';
import {readViewState,writeViewState} from './view-state-storage.mjs';
import {restorableTools} from './view-state-tools';
function storage():Storage|undefined{try{return typeof window==='undefined'?undefined:window.sessionStorage;}catch{return undefined;}}
export function purgeDeniedViewState():void{try{const store=storage();if(!store)return;for(const key of Object.keys(store)){if(key.startsWith('openutility:view:')&&!restorableTools.has(key.split(':')[3]??''))store.removeItem(key);}}catch{/* disabled storage */}}
export function useViewState<S>(binding:string,initial:S|(()=>S),allowed?:readonly unknown[]):[S,Dispatch<SetStateAction<S>>]{
 const slug=typeof location==='undefined'?'':new URLSearchParams(location.search).get('tool')||'json-formatter';
 const enabled=restorableTools.has(slug);
 const key='openutility:view:v1:'+slug+':'+binding;
 const [value,setValue]=useState<S>(()=>{const fallback=typeof initial==='function'?(initial as ()=>S)():initial;return enabled?readViewState(storage(),key,fallback,allowed):fallback;});
 useEffect(()=>{purgeDeniedViewState();if(enabled)writeViewState(storage(),key,value);},[enabled,key,value]);
 return [value,setValue];
}
