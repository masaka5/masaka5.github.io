import React,{Suspense,lazy,useMemo} from 'react';
import {createRoot} from 'react-dom/client';
import {getToolMeta,getToolComponent} from './lib/registry';
import {TooltipProvider} from './components/ui/tooltip';
import {Toaster} from './components/ui/sonner';
import './app/globals.css';import './toolbox.css';
class Boundary extends React.Component<React.PropsWithChildren,{error:string}>{state={error:''};static getDerivedStateFromError(e:Error){return {error:e.message};}render(){return this.state.error?<div className="load-error"><p>工具加载失败：{this.state.error}</p><button onClick={()=>location.reload()}>重新加载</button></div>:this.props.children;}}
function App(){const slug=new URLSearchParams(location.search).get('tool')||'json-formatter';const tool=getToolMeta(slug);const loader=getToolComponent(slug);const Tool=useMemo(()=>loader?lazy(loader):null,[loader]);document.title=(tool?.name||'工具')+' · 工具箱';
 return <TooltipProvider><div className="toolbox-shell"><header className="toolbox-header"><a href="../../">← 工具箱</a><h1>{tool?.name||'未找到工具'}</h1><span>{tool?.category==='pdf'?'PDF':{image:'图片处理',data:'数据处理',text:'文本处理',crypto:'加密与校验',encoding:'编码转换',generators:'生成工具',web:'开发工具',time:'时间日期',math:'计算换算',color:'颜色设计',convert:'格式转换'}[tool?.category||'']}</span></header><main className="toolbox-workspace"><Boundary><Suspense fallback={<p className="load-note">正在加载…</p>}>{Tool?<Tool/>:<p className="load-note">未找到工具，请返回工具箱重新选择。</p>}</Suspense></Boundary></main><footer className="toolbox-footer"><span id="tool-status"/><a href="../../licenses/">开源许可</a></footer></div><Toaster/></TooltipProvider>;
}createRoot(document.getElementById('root')!).render(<App/>);
