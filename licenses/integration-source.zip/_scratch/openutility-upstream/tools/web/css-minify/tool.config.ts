import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-css-minify-v1',
  name: "CSS缩小/美化",
  slug: 'css-minify',
  description: "将CSS缩小为一行或用一致的缩进来美化它。",
  category: 'web',
  tags: ['css', 'minify', 'beautify', 'format', 'compress'],
  keywords: ['css minify', 'css beautify', 'format css', 'compress css', 'prettify'],
  icon: 'FileCode',
  relatedTools: ['json-formatter', 'html-to-text', 'markdown-to-html'],
};

export default meta;
