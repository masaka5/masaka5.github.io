import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-avro-schema-evolution-checker-v1",
  name: "Avro 架构演变检查器",
  slug: "avro-schema-evolution-checker",
  description: "比较已添加、已删除、已更改和无默认字段的 Avro 记录模式。",
  category: "web",
  tags: ["avro","schema","compatibility","diff"],
  keywords: ["avro","schema","compatibility","diff"],
  icon: "GitCompare",
  relatedTools: [],
};

export default meta;
