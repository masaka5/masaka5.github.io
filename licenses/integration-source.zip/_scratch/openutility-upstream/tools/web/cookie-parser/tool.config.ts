import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-cookie-parser-v1',
  name: "Cookie解析器",
  slug: 'cookie-parser',
  description: "将Cookie或Set-Cookie标头解析成可读的属性表。",
  category: 'web',
  tags: ['cookie', 'header', 'parse', 'set-cookie'],
  keywords: ['cookie parser', 'set-cookie', 'http cookie', 'attributes', 'samesite'],
  icon: 'FileSearch',
  relatedTools: ['url-parser', 'jwt-decoder', 'http-status-codes'],
};

export default meta;
