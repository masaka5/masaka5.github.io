import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-bimi-record-checker-v1",
  name: "BIMI记录检查器",
  slug: "bimi-record-checker",
  description: "检查 BIMI TXT 记录的版本、徽标 URL、权限 URL 和部署清单。",
  category: "web",
  tags: ["bimi","dns","email","brand"],
  keywords: ["bimi","dns","email","brand"],
  icon: "FileBadge",
  relatedTools: [],
};

export default meta;
