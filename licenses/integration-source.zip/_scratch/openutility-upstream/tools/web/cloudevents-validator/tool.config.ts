import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-cloudevents-validator-v1",
  name: "CloudEvents验证器",
  slug: "cloudevents-validator",
  description: "验证 CloudEvents JSON 事件的所需属性和常见内容类型问题。",
  category: "web",
  tags: ["cloudevents","events","json","api"],
  keywords: ["cloudevents","events","json","api"],
  icon: "Webhook",
  relatedTools: [],
};

export default meta;
