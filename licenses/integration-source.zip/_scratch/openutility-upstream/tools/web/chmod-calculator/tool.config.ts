import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-chmod-v1',
  name: "Chmod 计算器",
  slug: 'chmod-calculator',
  description: "切换Unix权限位并获取八进制+符号chmod值。",
  category: 'web',
  tags: ['chmod', 'permissions', 'unix', 'octal', 'file'],
  keywords: ['chmod', 'file permissions', 'octal', 'rwx', 'unix permissions', '755'],
  icon: 'Lock',
  relatedTools: ['number-base-converter', 'gitignore-generator', 'mime-types'],
};

export default meta;
