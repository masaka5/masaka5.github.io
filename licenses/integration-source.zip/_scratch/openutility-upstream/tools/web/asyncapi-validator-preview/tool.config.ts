import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-asyncapi-validator-preview-v1",
  name: "AsyncAPI 验证器预览",
  slug: "asyncapi-validator-preview",
  description: "验证通用AsyncAPI结构并总结通道、操作、消息和服务器。",
  category: "web",
  tags: ["asyncapi","events","api","yaml"],
  keywords: ["asyncapi","events","api","yaml"],
  icon: "Radio",
  relatedTools: [],
};

export default meta;
