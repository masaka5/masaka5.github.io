import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: 'web-basic-auth-v1',
  name: "基本验证生成器",
  slug: 'basic-auth-generator',
  description: "根据用户名和密码构建HTTP基本授权标头。",
  category: 'web',
  tags: ['basic auth', 'authorization', 'header', 'base64'],
  keywords: ['basic auth', 'authorization header', 'http auth', 'credentials', 'base64'],
  icon: 'Lock',
  relatedTools: ['base64-text', 'jwt-decoder', 'http-status-codes'],
};

export default meta;
