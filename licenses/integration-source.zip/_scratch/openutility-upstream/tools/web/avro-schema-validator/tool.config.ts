import type { ToolMetaStatic } from '@/lib/registry/types';

const meta: ToolMetaStatic = {
  id: "web-avro-schema-validator-v1",
  name: "Avro 模式验证器",
  slug: "avro-schema-validator",
  description: "验证通用Avro模式结构并总结记录、字段、枚举和联合。",
  category: "web",
  tags: ["avro","schema","json","events"],
  keywords: ["avro","schema","json","events"],
  icon: "FileJson",
  relatedTools: [],
};

export default meta;
