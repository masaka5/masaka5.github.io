"""Build corresponding first-party sources, original licenses, byte manifests."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site';PROJECT=ROOT/'_scratch/yt-dlp-integration'
licenses=SITE/'licenses/yt-dlp';licenses.mkdir(exist_ok=True)
wheel=SITE/'tools/yt-dlp/runtime/yt_dlp-2026.10.26.whl'
with zipfile.ZipFile(wheel)as z:
 (licenses/'yt-dlp-LICENSE.txt').write_bytes(z.read('yt_dlp-2026.10.26.dist-info/licenses/LICENSE'))
notices=[]
for package in sorted((PROJECT/'node_modules').rglob('package.json')):
 try:info=json.loads(package.read_text(encoding='utf8'))
 except (ValueError,OSError):continue
 if not info.get('name')or not info.get('version'):continue
 texts=[]
 for item in sorted(package.parent.iterdir()):
  if item.is_file()and item.name.lower().startswith(('license','licence','notice','copying')):texts.append(item.read_text(encoding='utf8',errors='replace'))
 if texts:notices.append(info['name']+'@'+info['version']+'\n'+'\n'.join(texts))
(licenses/'THIRD-PARTY-NOTICES.txt').write_text('\n\n'.join(notices),encoding='utf8')
archive=SITE/'licenses/yt-dlp-source.zip';files=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(PROJECT.rglob('*')):
  rel=p.relative_to(PROJECT)
  if not p.is_file()or 'node_modules'in rel.parts or p.name=='ffmpeg-test.mjs':continue
  z.write(p,'_scratch/yt-dlp-integration/'+rel.as_posix())
 for p in sorted((ROOT/'_scratch/ops-tests').glob('yt-dlp-*.py')):z.write(p,'_scratch/ops-tests/'+p.name)
 z.write(Path(__file__),'_scratch/package-yt-dlp.py')
 for p in sorted(licenses.glob('*.txt')):z.write(p,'toolbox-site/licenses/yt-dlp/'+p.name)
with zipfile.ZipFile(archive)as z:
 for name in z.namelist():
  data=z.read(name);files.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'sourceArchive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files}
(SITE/'licenses/yt-dlp-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
runtime=SITE/'tools/yt-dlp';entries=[]
for p in sorted(runtime.rglob('*')):
 if p.is_file()and p.name!='manifest.json':entries.append({'file':p.relative_to(runtime).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(runtime/'manifest.json').write_text(json.dumps({'yt_dlp':'2026.10.26','files':entries},indent=2)+'\n',encoding='utf8')
sources_path=SITE/'licenses/sources.json';sources=json.loads(sources_path.read_text(encoding='utf8'))
sources=[s for s in sources if s.get('project')!='yt-dlp-browser']
sources.append({'project':'yt-dlp-browser','url':'https://github.com/yt-dlp/yt-dlp','version':'2026.10.26','license':'Unlicense and source component notices; original LICENSE retained','modified':False,'integration_modified':True,'source_archive':'yt-dlp-source.zip','source_manifest':'yt-dlp-source-manifest.json','original_python_source':'tools/yt-dlp/runtime/yt_dlp-2026.10.26.whl','reuses':['vendor/pyodide','tools/studio/runtime/ffmpeg']})
sources_path.write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'sourceBytes':archive.stat().st_size,'sourceSHA256':manifest['archiveSha256'],'runtimeFiles':len(entries)}))
