import {build} from 'esbuild';
import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
const site=path.resolve('../../toolbox-site/tools/yt-dlp');
await mkdir(site+'/assets',{recursive:true});await mkdir(site+'/runtime',{recursive:true});
await build({entryPoints:['src/main.jsx'],bundle:true,minify:true,target:['es2022'],format:'esm',outfile:site+'/assets/app.js',define:{'process.env.NODE_ENV':'"production"'},legalComments:'eof'});
await build({entryPoints:['node_modules/@ffmpeg/ffmpeg/dist/esm/worker.js'],bundle:true,minify:true,target:['es2022'],format:'esm',outfile:site+'/assets/ffmpeg-worker.js',legalComments:'eof'});
await copyFile('index.html',site+'/index.html');await copyFile('src/worker.js',site+'/worker.js');await copyFile('src/network.py',site+'/network.py');
await copyFile('src/browser-network.mjs',site+'/browser-network.mjs');
await copyFile('src/transport.mjs',site+'/transport.mjs');
let wheel;
try{wheel=await readFile('../yt_dlp-2026.10.26-py3-none-any.whl');}catch(error){if(error.code!=='ENOENT')throw error;const response=await fetch('https://files.pythonhosted.org/packages/7f/3d/16ea7d5638cf585991f2c5705e8083688dde633d32d0871f2404e0f4d827/yt_dlp-2026.10.26-py3-none-any.whl');if(!response.ok)throw Error('yt-dlp wheel download failed');wheel=new Uint8Array(await response.arrayBuffer());}
if(createHash('sha256').update(wheel).digest('hex')!=='a05c5b5d8562f7e8a62f5334348b406af4930d56d3a65f8021d14af0e22339ae')throw Error('yt-dlp wheel checksum mismatch');
await writeFile(site+'/runtime/yt_dlp-2026.10.26.whl',wheel);
console.log('Built yt-dlp browser application');
