let pending;
function open(){
 if(!pending)pending=new Promise((resolve,reject)=>{
  const request=indexedDB.open('pocket-media-downloads-v1',1);
  request.onupgradeneeded=()=>{const db=request.result;db.createObjectStore('jobs',{keyPath:'id'});const parts=db.createObjectStore('parts',{keyPath:'key'});parts.createIndex('job','job');};
  request.onsuccess=()=>resolve(request.result);request.onerror=()=>{pending=null;reject(request.error);};
 });return pending;
}
export async function transaction(stores,callback){
 const db=await open();return new Promise((resolve,reject)=>{
  const tx=db.transaction(stores,'readwrite');let result;
  tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||Error('浏览器缓存写入失败'));tx.onabort=()=>reject(tx.error||Error('浏览器缓存已取消'));
  result=callback(tx);
 });
}
async function read(store,key){const db=await open();return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export async function listJobs(){const db=await open();return new Promise((resolve,reject)=>{const r=db.transaction('jobs').objectStore('jobs').getAll();r.onsuccess=()=>resolve(r.result.sort((a,b)=>b.created-a.created));r.onerror=()=>reject(r.error);});}
export async function saveJob(job){await transaction(['jobs'],tx=>tx.objectStore('jobs').put({...job}));return job;}
export async function appendPart(job,bytes,patch={}){
 const blob=new Blob([bytes]),start=job.received,next={...job,...patch,received:start+blob.size};
 await transaction(['jobs','parts'],tx=>{tx.objectStore('parts').put({key:job.id+':'+String(start).padStart(16,'0'),job:job.id,start,blob});tx.objectStore('jobs').put(next);});
 Object.assign(job,next);
}
export async function removeJob(id){
 await transaction(['jobs','parts'],tx=>{tx.objectStore('jobs').delete(id);const parts=tx.objectStore('parts'),cursor=parts.index('job').openCursor(IDBKeyRange.only(id));cursor.onsuccess=()=>{const c=cursor.result;if(c){c.delete();c.continue();}};});
}
export async function getDownload(id){
 const job=await read('jobs',id);if(!job||job.state!=='complete')throw Error('文件尚未下载完成');
 const db=await open();const parts=await new Promise((resolve,reject)=>{const r=db.transaction('parts').objectStore('parts').index('job').getAll(IDBKeyRange.only(id));r.onsuccess=()=>resolve(r.result.sort((a,b)=>a.start-b.start));r.onerror=()=>reject(r.error);});
 let offset=0;for(const part of parts){if(part.start!==offset)throw Error('暂存文件缺少分段，请重新下载');offset+=part.blob.size;}
 if(offset!==job.received)throw Error('暂存文件大小不一致');
 return{job,blob:new Blob(parts.map(p=>p.blob),{type:job.mime||'application/octet-stream'})};
}
