import {FFmpeg} from '@ffmpeg/ffmpeg';
let ffmpeg,loading,working=false;
export function stopEncoding(){ffmpeg?.terminate();ffmpeg=null;loading=null;}
export async function encode(files,{format='mp4',audio=false,onProgress=()=>{},signal}={}){
 signal?.throwIfAborted();
 if(!files.length||files.length>2)throw Error('请选择一个文件重新封装，或两个音视频文件合并');
 if(audio&&files.length!==1)throw Error('提取音频请选择一个文件');
 if(files.reduce((total,file)=>total+file.blob.size,0)>512*1024*1024)throw Error('WASM 后处理单次最多 512 MB；可直接保存原始下载文件');
 if(working)throw Error('请等待当前后处理完成');working=true;
 const progress=event=>onProgress(Math.min(99,Math.max(0,Math.round(event.progress*100))));
 try{
 if(!ffmpeg){const engine=new FFmpeg();ffmpeg=engine;loading=engine.load({classWorkerURL:new URL('./assets/ffmpeg-worker.js',location.href).href,coreURL:new URL('../studio/runtime/ffmpeg/ffmpeg-core.js',location.href).href,wasmURL:new URL('../studio/runtime/ffmpeg/ffmpeg-core.wasm',location.href).href});}
 await loading;signal?.throwIfAborted();
 const engine=ffmpeg,names=files.map((file,index)=>`part-${index}.${/^[a-z0-9]+$/i.test(file.ext)?file.ext:'bin'}`),out=`result.${audio?'mp3':format}`;
 try{
  engine.on('progress',progress);
  for(let i=0;i<files.length;i++){const data=new Uint8Array(await files[i].blob.arrayBuffer());signal?.throwIfAborted();await engine.writeFile(names[i],data);signal?.throwIfAborted();}
  const input=names.flatMap(name=>['-i',name]);
  const args=audio?[...input,'-vn','-codec:a','libmp3lame','-q:a','2',out]:[...input,...(files.length>1?['-map','0:v:0?','-map','1:v:0?','-map','0:a:0?','-map','1:a:0?']:[]),'-c','copy',out];
  if(await engine.exec(args)!==0)throw Error('合并失败，可分别保存原始文件');
  signal?.throwIfAborted();const bytes=await engine.readFile(out);signal?.throwIfAborted();return new Blob([bytes],{type:audio?'audio/mpeg':format==='mp4'?'video/mp4':'video/x-matroska'});
 }finally{engine.off('progress',progress);for(const path of [...names,out])try{await engine.deleteFile(path);}catch{}}
 }catch(error){if(!ffmpeg?.loaded)stopEncoding();throw error;}finally{working=false;}
}
