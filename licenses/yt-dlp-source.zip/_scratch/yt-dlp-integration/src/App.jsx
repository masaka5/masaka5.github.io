import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  App as AntApp,
  Button,
  Card,
  Checkbox,
  ConfigProvider,
  Descriptions,
  Drawer,
  Empty,
  Input,
  InputNumber,
  Layout,
  Modal,
  Progress,
  Select,
  Space,
  Table,
  Tabs,
  Tag,
  Tooltip,
  Typography,
} from "antd";
import {
  ArrowLeftOutlined,
  CloudDownloadOutlined,
  DeleteOutlined,
  DownloadOutlined,
  PauseOutlined,
  PlayCircleOutlined,
  SettingOutlined,
  StopOutlined,
} from "@ant-design/icons";
import zhCN from "antd/locale/zh_CN";
import {
  parseURLs,
  flattenMedia,
  selectFormats,
  safeFilename,
  capabilityFor,
} from "./core.mjs";
import { createJob, transfer } from "./download.mjs";
import { getDownload, listJobs, removeJob, saveJob } from "./storage.mjs";
import { encode, stopEncoding } from "./ffmpeg.mjs";
import { prepareFormat,downloadExtension } from "./segments.mjs";
import Settings, { defaults, engineOptions } from "./Settings.jsx";
import {readView,writeView} from './view-state.mjs';
import {runPostprocess} from './postprocess.mjs';
import {friendlyError} from './transport.mjs';
import {groupJobs} from './job-group.mjs';
import "./style.css";

const theme = {
  token: {
    colorPrimary: "#315fc9",
    colorText: "#242d3a",
    colorTextSecondary: "#687588",
    colorBgLayout: "#f5f6f8",
    colorBorder: "#e3e7ed",
    borderRadius: 7,
    fontSize: 14,
    controlHeight: 36,
    fontFamily: "'Segoe UI','Microsoft YaHei',system-ui,sans-serif",
    motion: false,
  },
  components: {
    Card: { borderRadiusLG: 10 },
    Button: { primaryShadow: "none" },
  },
};
const states = {
  running: "下载中",
  paused: "已暂停",
  complete: "已完成",
  error: "下载失败",
};
const size = (n) =>
  n
    ? n > 1073741824
      ? (n / 1073741824).toFixed(2) + " GB"
      : n > 1048576
        ? (n / 1048576).toFixed(1) + " MB"
        : (n / 1024).toFixed(1) + " KB"
    : "—";
function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob),
    link = document.createElement("a");
  link.href = url;
  link.download = safeFilename(name);
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
function initialFormat(item) {
  const requested = item.requested_formats;
  if (requested?.length) return requested.map((f) => f.format_id).join("+");
  return item.format_id || item.formats.at(-1)?.format_id;
}
function Workspace() {
  const initial=useRef(readView()).current;
  const { message } = AntApp.useApp(),
    [urls, setURLs] = useState(initial.urls),
    [playlist, setPlaylist] = useState(initial.playlist),
    [items, setItems] = useState([]),
    [choices, setChoices] = useState({}),
    [jobs, setJobs] = useState([]),
    [busy, setBusy] = useState(false),
    [status, setStatus] = useState(""),
    [error, setError] = useState(""),
    [advanced, setAdvanced] = useState(false),
    [options, setOptions] = useState("{}"),
    [timeout, setTimeoutValue] = useState(initial.timeout),
    [tab, setTab] = useState(initial.tab),
    [catalog, setCatalog] = useState(null),
    [catalogQuery, setCatalogQuery] = useState(""),
    [catalogKind, setCatalogKind] = useState("options"),
    [mergeOpen, setMergeOpen] = useState(false),
    [mergeIds, setMergeIds] = useState([]),
    [encoding, setEncoding] = useState(null),
    [audio, setAudio] = useState(false),
    [output, setOutput] = useState("mp4");
  const worker = useRef(),
    active = useRef(new Map()),
    mergeRun=useRef(null),
    mounted = useRef(true);
  const [config, setConfig] = useState({...defaults,...initial.config}),
    [cli, setCLI] = useState("");
  useEffect(()=>writeView({urls,playlist,timeout,tab,config}),[urls,playlist,timeout,tab,config]);
  const notify = (error) => {
    setError(friendlyError(error));
    message.error("操作未完成");
  };
  async function refresh() {
    try {
      const saved = await listJobs();
      for(const job of saved)if(job.state==='running'&&!active.current.has(job.id)){job.state='paused';await saveJob(job);}
      if (mounted.current) setJobs(saved);
    } catch (error) {
      notify(error);
    }
  }
  useEffect(() => {
    refresh();
    return () => {
      mounted.current = false;
      worker.current?.terminate();
      for (const controller of active.current.values()) controller.abort();
      mergeRun.current?.abort();
      stopEncoding();
    };
  }, []);
  useEffect(()=>{if(tab==='capabilities'&&!catalog&&!busy)loadCatalog();},[]);
  function update(job) {
    if (mounted.current)
      setJobs((previous) => {
        const next = previous.filter((j) => j.id !== job.id);
        return [{ ...job }, ...next].sort((a, b) => b.created - a.created);
      });
  }
  function getWorker() {
    if (!worker.current) {
      const instance = new Worker(new URL("./worker.js", location.href), {
        type: "module",
      });
      worker.current = instance;
      instance.onmessage = ({ data }) => {
        if (data.type === "status") setStatus(data.text);
        if (data.type === "log")
          setStatus(data.text.replace(/\x1b\[[0-9;]*m/g, "").slice(-500));
        if (data.type === "catalog") {
          setCatalog(data.data);
          setBusy(false);
          setStatus("");
        }
        if (data.type === "result") {
          const media = data.data
            .flatMap(flattenMedia)
            .map((item, index) => ({ ...item, key: String(index) }));
          setItems(media);
          setChoices(
            Object.fromEntries(
              media.map((item) => [item.key, initialFormat(item)]),
            ),
          );
          setBusy(false);
          setStatus("");
          setTab("media");
        }
        if (data.type === "error") {
          setError(friendlyError(data.text));
          setBusy(false);
          setStatus("");
        }
      };
      instance.onerror = (event) => {
        setError(event.message || "下载引擎异常");
        setBusy(false);
        worker.current = null;
        instance.terminate();
      };
    }
    return worker.current;
  }
  function inspect() {
    try {
      const values = parseURLs(urls),
        parsed = JSON.parse(options);
      if (!parsed || Array.isArray(parsed) || typeof parsed !== "object")
        throw Error("高级参数需填写 JSON 对象");
      for (const key of [
        "proxy",
        "geo_verification_proxy",
        "cookiesfrombrowser",
        "exec_cmd",
        "external_downloader",
        "postprocessors",
        "paths",
      ])
        if (parsed[key])
          throw Error(
            "浏览器模式不能直接使用参数 " + key + "，请使用对应的页面操作",
          );
      setBusy(true);
      setError("");
      getWorker().postMessage({
        type: "inspect",
        urls: values,
        playlist,
        timeout,
        options: { ...engineOptions(config), ...parsed },
        cli,
        cookies: config.cookieText,
        network: {mode:config.networkMode},
      });
    } catch (error) {
      notify(error);
    }
  }
  function stop() {
    worker.current?.terminate();
    worker.current = null;
    setBusy(false);
    setStatus("已停止");
  }
  async function run(job) {
    if (active.current.has(job.id)) return;
    const controller = new AbortController();
    active.current.set(job.id, controller);
    try {
      await transfer(job, { signal: controller.signal, onProgress: update });
    } catch (error) {
      setError(friendlyError(error));
    } finally {
      active.current.delete(job.id);
    }
  }
  async function downloadItem(item) {
    try {
      const selected = selectFormats(item, choices[item.key]).sort((a,b)=>Number(a.vcodec==='none')-Number(b.vcodec==='none'));
      const pending=[];
      for (const format of selected) {
        const headers = Object.fromEntries(
          Object.entries({
            ...item.http_headers,
            ...format.http_headers,
          }).filter(
            ([key]) =>
              !/^(cookie|host|origin|accept-encoding|connection|content-length|sec-.*|proxy-.*)$/i.test(
                key,
              ),
          ),
        );
        const fragments = await prepareFormat(format, {
          headers,
          signal: AbortSignal.timeout(timeout * 1000),
          network:{mode:config.networkMode},
        });
        const extension = downloadExtension(format,fragments),
          suffix = selected.length > 1 ? "." + format.format_id : "";
        const filename = item._browser_filename
          ? item._browser_filename.replace(/\.[^.]+$/, suffix + "." + extension)
          : (item.title || item.id || "下载文件") + suffix + "." + extension;
        const job = createJob(format.url, filename, {
          ext: extension,
          formatId: format.format_id,
          kind:format.vcodec==='none'?'audio':'video',
          mediaId: item.id,
          fragments,
          headers,
          retries: config.retries,
          network:{mode:config.networkMode},
        });
        pending.push(job);
      }
      if(pending.length>1){
        const first=pending[0],container=selected[0].ext==='mp4'?'mp4':'mkv';
        first.recipe={ids:pending.map(j=>j.id),format:container,name:safeFilename((item.title||item.id||'媒体')+'.'+container)};
        for(const part of pending.slice(1))part.parentId=first.id;
      }
      for(const job of pending){await saveJob(job);update(job);}
      for(const job of pending)run(job);
      setTab("downloads");
    } catch (error) {
      notify(error);
    }
  }
  async function auxiliary(item, url, extension) {
    try {
      const job = createJob(url, (item.title || item.id) + "." + extension, {
        ext: extension,
        network:{mode:config.networkMode},
      });
      await saveJob(job);
      update(job);
      run(job);
      setTab("downloads");
    } catch (error) {
      notify(error);
    }
  }
  function details(item) {
    const subtitles = { ...item.automatic_captions, ...item.subtitles };
    return (
      <Space direction="vertical" style={{ width: "100%" }}>
        <Space wrap>
          {Object.entries(subtitles).map(([language, allFormats]) => {const formats=allFormats.filter(f=>f.url);return (
            <Select
              key={language}
              aria-label={"字幕 " + language}
              placeholder={"字幕 " + language}
              style={{ minWidth: 160 }}
              value={null}
              onChange={(index) =>
                auxiliary(
                  item,
                  formats[index].url,
                  language + "." + (formats[index].ext || "vtt"),
                )
              }
              options={formats.map((f, index) => ({
                  value: index,
                  label: language + " · " + (f.ext || "字幕"),
                }))}
            />
          );})}
          {item.thumbnail && (
            <Button onClick={() => auxiliary(item, item.thumbnail, "jpg")}>
              下载封面
            </Button>
          )}
        </Space>
        {!Object.keys(subtitles).length && !item.thumbnail && (
          <Typography.Text type="secondary">无字幕或封面</Typography.Text>
        )}
      </Space>
    );
  }
  async function save(id) {
    try {
      const job=jobs.find(j=>j.id===id);
      if(job?.recipe){
        if(mergeRun.current)throw Error('请等待当前媒体处理完成');
        const controller=new AbortController();mergeRun.current=controller;setEncoding(0);
        try{
          const result=await runPostprocess(job.recipe.ids,{load:getDownload,encode,signal:controller.signal,format:job.recipe.format,onProgress:setEncoding});
          saveBlob(result,job.recipe.name);
        }finally{mergeRun.current=null;setEncoding(null);}
      }else{
        const { job, blob } = await getDownload(id);
        saveBlob(blob, job.name);
      }
    } catch (error) {
      if(error.name!=='AbortError')notify(error);
    }
  }
  async function saveSource(id){
    try{const{job,blob}=await getDownload(id);saveBlob(blob,job.name);}catch(error){notify(error);}
  }
  async function erase(job) {
    const ids=job.recipe?.ids||[job.id];
    for(const id of ids)active.current.get(id)?.abort();
    if (ids.some(id=>active.current.has(id))) return message.info("请先暂停再移除");
    try {
      for(const id of ids)await removeJob(id);
      await refresh();
    } catch (error) {
      notify(error);
    }
  }
  async function merge() {
    if(mergeRun.current)return;
    const controller=new AbortController();mergeRun.current=controller;
    try {
      if (!mergeIds.length) throw Error("请选择已完成的文件");
      setEncoding(0);
      setError("");
      const result = await runPostprocess(mergeIds, {load:getDownload,encode,signal:controller.signal,
        format: output,
        audio,
        onProgress: setEncoding,
      });
      saveBlob(result, audio ? "音频.mp3" : "合并结果." + output);
      setMergeOpen(false);
    } catch (error) {
      if(!controller.signal.aborted&&mounted.current)notify(error);
    } finally {
      if(mergeRun.current===controller){mergeRun.current=null;if(mounted.current)setEncoding(null);}
    }
  }
  async function loadCatalog() {
    try {
      setTab("capabilities");
      if (!catalog && !busy) {
        setBusy(true);
        getWorker().postMessage({ type: "catalog" });
      }
    } catch (error) {
      notify(error);
    }
  }
  const columns = [
    {
      title: "媒体",
      dataIndex: "title",
      ellipsis: true,
      render: (text, item) => (
        <div className="media-title">
          <Typography.Text strong>{text || item.id}</Typography.Text>
          <Typography.Text type="secondary">
            {item.extractor || item.extractor_key}
            {item.duration ? " · " + Math.round(item.duration) + " 秒" : ""}
          </Typography.Text>
        </div>
      ),
    },
    {
      title: "格式",
      width: 340,
      render: (_, item) => {
        const formats = item.formats.filter((f) => f.url),
          defaults = initialFormat(item),
          list = formats.map((f) => ({
            value: String(f.format_id),
            label: [
              f.format_id,
              f.ext,
              f.resolution || (f.height ? f.height + "p" : ""),
              f.vcodec === "none"
                ? "音频"
                : f.acodec === "none"
                  ? "无音轨"
                  : "",
              size(f.filesize || f.filesize_approx),
            ]
              .filter(Boolean)
              .join(" · "),
          }));
        if (defaults?.includes("+"))
          list.unshift({
            value: defaults,
            label: "推荐音视频组合 · " + defaults,
          });
        return (
          <Select
            aria-label={"格式 " + (item.title || item.id)}
            value={choices[item.key]}
            options={list}
            onChange={(value) => setChoices({ ...choices, [item.key]: value })}
            style={{ width: "100%" }}
            popupMatchSelectWidth={false}
          />
        );
      },
    },
    {
      title: "",
      width: 150,
      render: (_, item) => (
        <Space>
          <Button
            type="primary"
            icon={<DownloadOutlined />}
            onClick={() => downloadItem(item)}
          >
            下载
          </Button>
          <Tooltip title="导出解析信息">
            <Button
              aria-label="导出解析信息"
              icon={<CloudDownloadOutlined />}
              onClick={() =>
                saveBlob(
                  new Blob([JSON.stringify(item, null, 2)], {
                    type: "application/json",
                  }),
                  (item.title || item.id) + ".info.json",
                )
              }
            />
          </Tooltip>
        </Space>
      ),
    },
  ];
  const jobColumns = [
    { title: "文件", dataIndex: "name", ellipsis: true },
    {
      title: "进度",
      width: 230,
      render: (_, job) => (
        <div>
          <Progress
            percent={
              job.total ? Math.floor((job.received / job.total) * 100) : job.fragments?.length ? Math.floor(((job.nextFragment||0)/job.fragments.length)*100) : 0
            }
            size="small"
            status={
              job.state === "error"
                ? "exception"
                : job.state === "complete"
                  ? "success"
                  : "normal"
            }
          />
          <Typography.Text type="secondary">
            {size(job.received)} / {size(job.total)} ·{" "}
            {states[job.state] || "已暂停"}
          </Typography.Text>
          {job.error&&<Typography.Text type="danger">{job.error}</Typography.Text>}
        </div>
      ),
    },
    {
      title: "",
      width: 155,
      render: (_, job) => (
        <Space>
          {job.state === "complete" ? (
            <Button
              aria-label={"保存 " + job.name}
              icon={<DownloadOutlined />}
              onClick={() => save(job.id)}
            />
          ) : job.state === "running" && (job.recipe?.ids||[job.id]).some(id=>active.current.has(id)) ? (
            <Button
              aria-label={"暂停 " + job.name}
              icon={<PauseOutlined />}
              onClick={() => (job.recipe?.ids||[job.id]).forEach(id=>active.current.get(id)?.abort())}
            />
          ) : (
            <Button
              aria-label={"继续 " + job.name}
              icon={<PlayCircleOutlined />}
              onClick={() => (job.recipe?.ids||[job.id]).forEach(id=>{const part=jobs.find(j=>j.id===id);if(part&&part.state!=='complete')run(part);})}
            />
          )}
          <Button
            aria-label={"移除 " + job.name}
            icon={<DeleteOutlined />}
            onClick={() =>
              Modal.confirm({
                title: "移除此暂存文件？",
                content: job.name,
                okText: "移除",
                cancelText: "取消",
                onOk: () => erase(job),
              })
            }
          />
        </Space>
      ),
    },
  ];
  const catalogRows =
    catalogKind === "extractors"
      ? (catalog?.extractors || []).map((e, i) => ({ ...e, key: i }))
      : (catalog?.options || []).map((o, i) => ({
          ...o,
          key: i,
          name: o.names.join(", "),
          ...capabilityFor(o.names.find((n) => n.startsWith("--")) || ""),
        }));
  const catalogColumns =
    catalogKind === "extractors"
      ? [
          { title: "解析器", dataIndex: "name", width: 260 },
          { title: "状态", render:()=>"已包含解析器，在线访问仍取决于站点权限" },
        ]
      : [
          { title: "参数", dataIndex: "name", width: 280 },
          {
            title: "状态",
            dataIndex: "support",
            width: 100,
            render: (value) => (
              <Tag
                color={
                  value === "supported"
                    ? "blue"
                    : value === "adapted"
                      ? "cyan"
                      : "default"
                }
              >
                {
                  {
                    supported: "引擎支持",
                    adapted: "网页适配",
                    unsupported: "不可用",
                    unverified: "未验证",
                  }[value]
                }
              </Tag>
            ),
          },
          { title: "网页能力", dataIndex: "reason" },
        ];
  return (
    <Layout className="download-app">
      <Layout.Header className="app-header">
        <Button type="text" href="../../" icon={<ArrowLeftOutlined />}>
          工具箱
        </Button>
        <h1>媒体下载</h1>
        <Tag>yt-dlp</Tag>
        <Space className="header-actions">
          <Button onClick={loadCatalog}>支持能力</Button>
          <Button icon={<SettingOutlined />} onClick={() => setAdvanced(true)}>
            设置
          </Button>
        </Space>
      </Layout.Header>
      <Layout.Content className="download-workspace">
        <Card className="download-input" size="small">
          <Input.TextArea
            aria-label="媒体链接"
            placeholder="粘贴链接，每行一个"
            autoSize={false}
            value={urls}
            onChange={(e) => setURLs(e.target.value)}
            disabled={busy}
          />
          <Space wrap>
            <Checkbox
              checked={playlist}
              onChange={(e) => setPlaylist(e.target.checked)}
            >
              播放列表
            </Checkbox>
            {busy ? (
              <Button icon={<StopOutlined />} onClick={stop}>
                停止
              </Button>
            ) : (
              <Button type="primary" onClick={inspect}>
                解析
              </Button>
            )}
          </Space>
          <Select aria-label="连接方式" className="network-mode" value={config.networkMode} disabled={busy} onChange={value=>setConfig({...config,networkMode:value})} options={[{value:'auto',label:'自动连接'},{value:'direct',label:'浏览器直连'},{value:'relay',label:'跨域转发'}]}/>
        </Card>
        <div className="download-content">
          {error && (
            <Alert
              closable
              type="error"
              showIcon
              title="操作未完成"
          description={<span className="error-text">{error}</span>}
              onClose={() => setError("")}
            />
          )}
          <Tabs
            activeKey={tab}
            onChange={(value) =>
              value === "capabilities" ? loadCatalog() : setTab(value)
            }
            items={[
              {
                key: "media",
                label: "解析结果",
                children: items.length ? (
                  <Table
                    rowKey="key"
                    size="middle"
                    columns={columns}
                    dataSource={items}
                    expandable={{expandedRowRender:details,columnTitle:'附件'}}
                    pagination={{ pageSize: 12, showSizeChanger: false }}
                    scroll={{ x: 760 }}
                  />
                ) : (
                  <Empty description={busy ? "正在解析…" : "暂无媒体"} />
                ),
              },
              {
                key: "downloads",
                label: "下载任务",
                children: (
                  <>
                    <Space className="download-toolbar">
                      <Button
                        onClick={() => setMergeOpen(true)}
                        disabled={!jobs.some((j) => j.state === "complete")}
                      >
                        合并 / 提取音频
                      </Button>
                      <Button onClick={refresh}>刷新</Button>
                    </Space>
                    <Table
                      rowKey="id"
                      size="middle"
                      columns={jobColumns}
                      dataSource={groupJobs(jobs)}
                      expandable={{rowExpandable:job=>!!job.recipe,expandedRowRender:job=><Space direction="vertical" style={{width:'100%'}}>{job.recipe.ids.map(id=>{const part=jobs.find(j=>j.id===id);return part&&<Space key={id} wrap><Typography.Text>{part.name}</Typography.Text><Typography.Text type="secondary">{states[part.state]} · {size(part.received)}</Typography.Text><Button size="small" disabled={part.state!=='complete'} onClick={()=>saveSource(id)}>保存源文件</Button></Space>;})}</Space>}}
                      pagination={{ pageSize: 12, showSizeChanger: false }}
                      scroll={{ x: 650 }}
                      locale={{ emptyText: <Empty description="暂无任务" /> }}
                    />
                  </>
                ),
              },
              {
                key: "capabilities",
                label: "能力与解析器",
                children: (
                  <>
                    <Space wrap className="download-toolbar">
                      <Select
                        aria-label="能力类型"
                        value={catalogKind}
                        onChange={setCatalogKind}
                        options={[
                          { value: "options", label: "命令参数" },
                          { value: "extractors", label: "站点解析器" },
                        ]}
                      />
                      <Input.Search
                        aria-label="搜索能力"
                        placeholder="搜索"
                        value={catalogQuery}
                        onChange={(e) => setCatalogQuery(e.target.value)}
                      />
                    </Space>
                    <Table
                      size="small"
                      rowKey="key"
                      columns={catalogColumns}
                      dataSource={catalogRows.filter((row) =>
                        (
                          row.name +
                          " " +
                          (row.help || "") +
                          " " +
                          (row.description || "")
                        )
                          .toLowerCase()
                          .includes(catalogQuery.toLowerCase()),
                      )}
                      pagination={{ pageSize: 20, showSizeChanger: false }}
                      scroll={{ x: 900 }}
                    />
                  </>
                ),
              },
            ]}
          />
        </div>
      </Layout.Content>
      <footer role="status">{encoding!==null?`正在处理媒体 · ${encoding}%`:status||' '}{encoding!==null&&<Button size="small" type="text" onClick={()=>{mergeRun.current?.abort();stopEncoding();}}>停止处理</Button>}</footer>
      <Drawer
        title="下载设置"
        open={advanced}
        onClose={() => setAdvanced(false)}
        width={480}
      >
        <Settings config={config} onChange={setConfig} timeout={timeout} onTimeout={setTimeoutValue} options={options} onOptions={setOptions} cli={cli} onCLI={setCLI}/>
      </Drawer>
      <Modal
        title="合并 / 提取音频"
        open={mergeOpen}
        onCancel={() => {
          mergeRun.current?.abort();
          if (encoding !== null) stopEncoding();
          setEncoding(null);
          setMergeOpen(false);
        }}
        footer={
          encoding !== null ? (
            <Button
              onClick={() => {
                mergeRun.current?.abort();
                stopEncoding();
                setEncoding(null);
              }}
            >
              停止
            </Button>
          ) : (
            <Button type="primary" onClick={merge}>
              导出
            </Button>
          )
        }
      >
        <Space direction="vertical" size={16} style={{ width: "100%" }}>
          <Select
            aria-label="待处理文件"
            mode="multiple"
            value={mergeIds}
            onChange={setMergeIds}
            options={jobs
              .filter((j) => j.state === "complete")
              .map((j) => ({ value: j.id, label: j.name }))}
            style={{ width: "100%" }}
          />
          <Checkbox
            checked={audio}
            onChange={(e) => setAudio(e.target.checked)}
          >
            提取 MP3 音频
          </Checkbox>
          {!audio && (
            <Select
              aria-label="输出容器"
              value={output}
              onChange={setOutput}
              options={[
                { value: "mp4", label: "MP4" },
                { value: "mkv", label: "MKV" },
              ]}
            />
          )}
          {encoding !== null && <Progress percent={encoding} />}
        </Space>
      </Modal>
    </Layout>
  );
}
export default function Application() {
  return (
    <ConfigProvider
      locale={zhCN}
      theme={theme}
      button={{ autoInsertSpace: false }}
    >
      <AntApp>
        <Workspace />
      </AntApp>
    </ConfigProvider>
  );
}
