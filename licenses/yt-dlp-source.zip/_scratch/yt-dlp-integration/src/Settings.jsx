import React from 'react';
import {Alert,Form,Input,InputNumber,Select,Switch,Tabs} from 'antd';

export const defaults={playlistItems:'',format:'bestvideo*+bestaudio/best',outtmpl:'%(title)s.%(ext)s',subtitles:false,autoSubtitles:false,subtitleLanguages:'zh.*,en.*',username:'',password:'',cookieText:'',retries:3};
export function engineOptions(config){
 const options={format:config.format,outtmpl:config.outtmpl,retries:config.retries,
  writesubtitles:config.subtitles,writeautomaticsub:config.autoSubtitles,subtitleslangs:config.subtitleLanguages.split(',').map(s=>s.trim()).filter(Boolean)};
 if(config.playlistItems)options.playlist_items=config.playlistItems;
 if(config.username)options.username=config.username;
 if(config.password)options.password=config.password;
 return options;
}
export default function Settings({config,onChange,timeout,onTimeout,options,onOptions,cli,onCLI}){
 const set=(key,value)=>onChange({...config,[key]:value});
 return <Tabs items={[{key:'general',label:'常规',children:<Form layout="vertical">
  <Form.Item label="优先格式"><Select aria-label="优先格式" value={config.format} onChange={value=>set('format',value)} options={[{value:'bestvideo*+bestaudio/best',label:'最佳画质'},{value:'best[height<=1080]/best',label:'1080p 以内'},{value:'best[height<=720]/best',label:'720p 以内'},{value:'bestaudio/best',label:'仅音频'},{value:'worst',label:'最小体积'}]}/></Form.Item>
  <Form.Item label="文件名模板"><Input aria-label="文件名模板" value={config.outtmpl} onChange={e=>set('outtmpl',e.target.value)}/></Form.Item>
  <Form.Item label="列表序号"><Input aria-label="列表序号" placeholder="1:10 或 1,3,5" value={config.playlistItems} onChange={e=>set('playlistItems',e.target.value)}/></Form.Item>
  <Form.Item label="人工字幕"><Switch aria-label="人工字幕" checked={config.subtitles} onChange={v=>set('subtitles',v)}/></Form.Item>
  <Form.Item label="自动字幕"><Switch aria-label="自动字幕" checked={config.autoSubtitles} onChange={v=>set('autoSubtitles',v)}/></Form.Item>
  <Form.Item label="字幕语言"><Input aria-label="字幕语言" value={config.subtitleLanguages} onChange={e=>set('subtitleLanguages',e.target.value)}/></Form.Item>
  <Form.Item label="请求超时（秒）"><InputNumber aria-label="请求超时" min={5} max={600} value={timeout} onChange={onTimeout}/></Form.Item>
  <Form.Item label="重试次数"><InputNumber aria-label="重试次数" min={0} max={20} value={config.retries} onChange={v=>set('retries',v)}/></Form.Item>
 </Form>},{key:'account',label:'账户',children:<Form layout="vertical">
  <Form.Item label="用户名"><Input aria-label="用户名" autoComplete="off" value={config.username} onChange={e=>set('username',e.target.value)}/></Form.Item>
  <Form.Item label="密码"><Input.Password aria-label="密码" autoComplete="new-password" value={config.password} onChange={e=>set('password',e.target.value)}/></Form.Item>
  <Form.Item label="Cookie 文件"><input aria-label="Cookie 文件" type="file" accept=".txt" onChange={async e=>{const file=e.target.files[0];if(!file)return;if(file.size>1048576)return;set('cookieText',await file.text());e.target.value='';}}/></Form.Item>
  <Alert type="info" title="浏览器禁止注入跨域 Cookie；文件仅供解析器读取，不等同于网站登录。账户信息仅保留在本次页面中。"/>
 </Form>},{key:'advanced',label:'高级',children:<Form layout="vertical">
  <Form.Item label="命令参数"><Input.TextArea aria-label="命令参数" rows={5} placeholder="--playlist-items 1:10 --format best" spellCheck={false} value={cli} onChange={e=>onCLI(e.target.value)}/></Form.Item>
  <Form.Item label="Python 参数（JSON）"><Input.TextArea aria-label="yt-dlp 高级参数" rows={9} spellCheck={false} value={options} onChange={e=>onOptions(e.target.value)}/></Form.Item>
  <Alert type="info" title="站点需开放跨域访问。系统代理、外部进程和跨域请求头不可用；解析参数交给原引擎执行。"/>
 </Form>}]} />;
}
