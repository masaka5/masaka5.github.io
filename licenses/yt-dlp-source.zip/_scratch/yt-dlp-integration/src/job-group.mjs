export function groupJobs(jobs){
 const byId=new Map(jobs.map(j=>[j.id,j]));
 return jobs.filter(j=>!j.parentId).map(job=>{
  if(!job.recipe)return job;
  const parts=job.recipe.ids.map(id=>byId.get(id));
  const missing=parts.some(p=>!p),present=parts.filter(Boolean);
  const failed=present.find(p=>p.state==='error');
  const state=missing||failed?'error':present.every(p=>p.state==='complete')?'complete':present.some(p=>p.state==='running')?'running':'paused';
  return{...job,name:job.recipe.name,state,error:missing?'源文件缺失，请重新下载':failed?.error||'',received:present.reduce((n,p)=>n+p.received,0),total:present.every(p=>p.total)?present.reduce((n,p)=>n+p.total,0):0};
 });
}
