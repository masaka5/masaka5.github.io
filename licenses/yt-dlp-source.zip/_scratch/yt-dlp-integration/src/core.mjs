export function parseURLs(text){
 const urls=[...new Set(String(text).split(/\r?\n/).map(s=>s.trim()).filter(Boolean))];
 if(!urls.length)throw Error('请输入链接');
 return urls.map(value=>{
  if(/^(?:ytsearch|ytsearchdate|gvsearch|scsearch)\d*:/i.test(value))return value;
  let url;try{url=new URL(value);}catch{throw Error('链接无效：'+value);}
  if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error('仅支持 HTTP(S) 链接，不能包含账户密码');
  return url.href;
 });
}
export function flattenMedia(info){
 const output=[];
 function visit(item){if(!item)return;if(Array.isArray(item.entries)){for(const entry of item.entries)visit(entry);return;}
  output.push({...item,formats:Array.isArray(item.formats)?item.formats:item.url?[{format_id:'direct',url:item.url,ext:item.ext,vcodec:item.vcodec,acodec:item.acodec,filesize:item.filesize}]:[]});}
 visit(info);return output;
}
export function selectFormats(info,value){
 const ids=String(value||'').split('+'),formats=info.formats||[];
 return ids.map(id=>{const format=formats.find(f=>String(f.format_id)===id);if(!format)throw Error('所选格式已不可用，请重新解析');return format;});
}
export function safeFilename(value){
 let name=String(value||'').split(/[\\/]/).filter(Boolean).at(-1)||'下载文件';
 name=name.replace(/[<>:"|?*\u0000-\u001f]/g,'_').replace(/^[.\s]+|[.\s]+$/g,'').slice(0,220);
 return name||'下载文件';
}
export function validateRangeResponse({status,start=0,contentRange,received,expectedTotal}){
 if(start===0&&status===200)return expectedTotal||received;
 const match=/^bytes (\d+)-(\d+)\/(\d+)$/.exec(contentRange||'');
 if(status!==206||!match||Number(match[1])!==start||Number(match[2])-start+1!==received)throw Error('服务器未按断点返回数据，请重新下载');
 const total=Number(match[3]);if(expectedTotal&&expectedTotal!==total)throw Error('源文件大小已变化，请重新下载');
 return total;
}
const unsupported=new Map([
 ['--proxy','浏览器不能设置 HTTP/SOCKS 代理'],['--geo-verification-proxy','浏览器不能设置请求代理'],['--cookies-from-browser','网页不能读取其他站点的浏览器 Cookie'],['--exec','网页不能启动系统进程'],['--exec-before-download','网页不能启动系统进程'],['--external-downloader','网页不能启动外部下载程序'],['--downloader','网页不能启动外部下载程序'],['--impersonate','TLS 指纹由浏览器管理'],['--source-address','源 IP 由浏览器管理'],['--client-certificate','客户端证书由浏览器管理'],['--no-check-certificates','网页不能忽略 TLS 校验'],['--xattrs','网页不能设置系统扩展属性'],['--sponsorblock-mark','需额外 SponsorBlock 服务，当前未接入'],['--sponsorblock-remove','需额外 SponsorBlock 服务，当前未接入'],['--update','运行版本由工具箱发布'],['--update-to','运行版本由工具箱发布']
]);
const adapted=new Map([
 ['--merge-output-format','通过后处理操作使用 FFmpeg WASM 合并'],['--remux-video','通过后处理操作使用 FFmpeg WASM 重新封装'],['--extract-audio','通过后处理操作使用 FFmpeg WASM 提取 MP3'],['--output','下载名称；不直接写入未授权系统路径'],['--cookies','可解析上传的 Cookie 文件；浏览器禁止设置跨域 Cookie 请求头'],['--continue','浏览器缓存 + HTTP Range 续传'],['--add-headers','仅浏览器允许的请求头生效'],['--write-subs','附件中下载已解析的字幕文件'],['--write-thumbnail','附件中下载已解析的缩略图'],['--write-info-json','导出解析信息 JSON']
]);
export function capabilityFor(option){
 if(unsupported.has(option))return{support:'unsupported',reason:unsupported.get(option)};
 if(adapted.has(option))return{support:'adapted',reason:adapted.get(option)};
 if(['--format','--format-sort','--playlist-start','--playlist-end','--playlist-items','--yes-playlist','--no-playlist','--match-filter','--extractor-args','--username','--password','--video-password','--socket-timeout','--retries','--list-formats','--list-subs','--skip-download','--dump-json','--flat-playlist'].includes(option))return{support:'supported',reason:'由 yt-dlp WASM 解析引擎执行'};
 return{support:'unverified',reason:'原项目参数；此网页尚未验证，不能保证可用'};
}
