import {appendPart,saveJob} from './storage.mjs';
import {safeFilename,validateRangeResponse} from './core.mjs';
import {mediaFetch} from './transport.mjs';

export function createJob(url,name,extra={}){
 const parsed=new URL(url);if(!['https:','http:'].includes(parsed.protocol)||parsed.username||parsed.password)throw Error('下载链接无效');
 return{id:crypto.randomUUID(),url:parsed.href,name:safeFilename(name),received:0,total:0,state:'paused',created:Date.now(),...extra};
}
export async function transfer(job,{signal,onProgress=()=>{}}={}){
 const retries=Math.min(20,Math.max(0,Number(job.retries)||0));
 for(let attempt=0;;attempt++){
  try{return await transferOnce(job,{signal,onProgress});}
  catch(error){if(attempt>=retries||!error.retryable||signal?.aborted)throw error;await new Promise((resolve,reject)=>{const abort=()=>{clearTimeout(timer);reject(signal.reason||new DOMException('Paused','AbortError'));};const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},Math.min(4000,500*(attempt+1)));signal?.addEventListener('abort',abort,{once:true});});}
 }
}
async function transferOnce(job,{signal,onProgress}){
 if(job.fragments?.length)return transferFragments(job,{signal,onProgress});
 if(job.total&&job.received===job.total){job.state='complete';await saveJob(job);onProgress({...job});return job;}
 let response;
 try{
  const headers={...job.headers};if(job.received){headers.Range=`bytes=${job.received}-`;if(job.etag&&!job.etag.startsWith('W/'))headers['If-Range']=job.etag;}
  response=await mediaFetch(job.url,{headers,signal},job.network);
  if(!response.ok){const error=Error('下载返回 HTTP '+response.status);error.retryable=response.status===429||response.status>=500;throw error;}
  if(!response.body)throw Error('浏览器未提供下载流');
  const offset=job.received,range=response.headers.get('content-range'),length=Number(response.headers.get('content-length'))||0;
  if(offset){validateRangeResponse({status:response.status,start:offset,contentRange:range,received:length||Number(/^bytes \d+-(\d+)\//.exec(range||'')?.[1])-offset+1,expectedTotal:job.total});}
  const etag=response.headers.get('etag');if(offset&&job.etag&&etag&&etag!==job.etag)throw Error('源文件已变化，请重新下载');
  job.etag=etag||job.etag;job.total=Number(range?.split('/')[1])||(length?offset+length:job.total);job.mime=response.headers.get('content-type')||job.mime;job.state='running';job.error='';
  await saveJob(job);onProgress({...job});
  const reader=response.body.getReader();let last=0;
  try{
   while(true){
    const {done,value}=await reader.read();if(done)break;
    if(signal?.aborted)throw new DOMException('Paused','AbortError');
    await appendPart(job,value);
    if(performance.now()-last>120){last=performance.now();onProgress({...job});}
   }
  }finally{reader.releaseLock();}
  if(job.total&&job.received!==job.total){const error=Error('下载未完整结束，可继续下载');error.retryable=true;throw error;}
  job.state='complete';job.total=job.received;await saveJob(job);onProgress({...job});return job;
 }catch(error){
  if(error instanceof TypeError)error.retryable=true;
  if(response?.body&&!response.body.locked)try{await response.body.cancel();}catch{}
  job.state=error.name==='AbortError'?'paused':'error';job.error=job.state==='paused'?'':(error.message||'下载失败；站点可能未开放跨域访问');
  await saveJob(job);onProgress({...job});if(job.state==='error')throw error;return job;
 }
}

async function fragmentBytes(part,signal,headers,network){
 const requestHeaders={...headers};if(part.start!==undefined)requestHeaders.Range=`bytes=${part.start}-${part.end}`;
 const response=await mediaFetch(part.url,{signal,headers:requestHeaders},network);
 if(!response.ok){const error=Error('分段返回 HTTP '+response.status);error.retryable=response.status===429||response.status>=500;throw error;}
 const length=Number(response.headers.get('content-length'));
 if(length>64*1024*1024){await response.body?.cancel();throw Error('单个分段超过 64 MB，不能安全处理');}
 const reader=response.body.getReader(),chunks=[];let total=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>64*1024*1024){await reader.cancel();throw Error('单个分段超过 64 MB，不能安全处理');}chunks.push(value);}}finally{reader.releaseLock();}
 let bytes=new Uint8Array(total),offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 if(part.start!==undefined){const range=response.headers.get('content-range');if(response.status!==206||!range?.startsWith(`bytes ${part.start}-${part.end}/`)||total!==part.end-part.start+1)throw Error('服务器未正确返回分段范围');}
 return bytes;
}
async function transferFragments(job,{signal,onProgress}){
 try{
  job.state='running';job.error='';await saveJob(job);onProgress({...job});
  const keys=new Map();
  for(let index=job.nextFragment||0;index<job.fragments.length;index++){
   const part=job.fragments[index];let bytes=await fragmentBytes(part,signal,job.headers,job.network);
   if(part.key){
    let key=keys.get(part.key.url);
    if(!key){const data=await fragmentBytes({url:part.key.url},signal,job.headers,job.network);if(data.length!==16)throw Error('AES 密钥长度无效');key=await crypto.subtle.importKey('raw',data,'AES-CBC',false,['decrypt']);keys.set(part.key.url,key);}
    const iv=new Uint8Array(part.key.iv.match(/../g).map(s=>parseInt(s,16)));
    bytes=new Uint8Array(await crypto.subtle.decrypt({name:'AES-CBC',iv},key,bytes));
   }
   signal?.throwIfAborted();await appendPart(job,bytes,{nextFragment:index+1});onProgress({...job});
  }
  job.state='complete';job.total=job.received;await saveJob(job);onProgress({...job});return job;
 }catch(error){if(error instanceof TypeError)error.retryable=true;job.state=error.name==='AbortError'?'paused':'error';job.error=job.state==='paused'?'':error.message;await saveJob(job);onProgress({...job});if(job.state==='error')throw error;return job;}
}
