export function encodePlan(names,{format='mp4',audio=false}={}){
 if(!names.length||names.length>2)throw Error('请选择一个文件，或一组音视频文件');
 if(audio&&names.length!==1)throw Error('提取音频请选择一个文件');
 if(!['mp4','mkv'].includes(format))throw Error('输出容器无效');
 const extension=audio?'mp3':format,args=['-y',...names.flatMap(name=>['-i',name])];
 if(audio)args.push('-map','0:a:0','-vn','-c:a','libmp3lame','-q:a','2');
 else{
  args.push('-map','0:v:0','-map',names.length>1?'1:a:0':'0:a:0?','-c:v','copy','-c:a',format==='mp4'?'aac':'copy');
  if(format==='mp4')args.push('-movflags','+faststart');
 }
 args.push('result.'+extension);
 return{args,extension,type:audio?'audio/mpeg':format==='mp4'?'video/mp4':'video/x-matroska'};
}
