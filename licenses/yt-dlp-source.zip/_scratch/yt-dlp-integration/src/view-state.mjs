const key='pocket-yt-dlp-view-v1';
const sensitive=/(?:token|key|signature|auth|credential|password|secret|cookie|policy)/i;
export function safeLinks(text){
 if(typeof text!=='string'||text.length>20000)return '';
 return text.split(/\r?\n/).filter(line=>{
  if(!line.trim())return true;
  try{const url=new URL(line);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password&&![...url.searchParams.keys()].some(k=>sensitive.test(k))&&!sensitive.test(url.hash);}catch{return false;}
 }).join('\n');
}
export function cleanView(value){
 const state=value&&typeof value==='object'?value:{};
 const source=state.config&&typeof state.config==='object'?state.config:{};
 const config={};
 for(const name of ['playlistItems','format','outtmpl','subtitleLanguages'])if(typeof source[name]==='string')config[name]=source[name].slice(0,1000);
 for(const name of ['subtitles','autoSubtitles'])if(typeof source[name]==='boolean')config[name]=source[name];
 if(Number.isInteger(source.retries)&&source.retries>=0&&source.retries<=20)config.retries=source.retries;
 if(['auto','direct','relay'].includes(source.networkMode))config.networkMode=source.networkMode;
 return {schema:1,urls:safeLinks(state.urls),playlist:state.playlist===true,tab:['media','downloads','capabilities'].includes(state.tab)?state.tab:'media',timeout:Number.isFinite(state.timeout)&&state.timeout>=5&&state.timeout<=600?state.timeout:30,config};
}
export function readView(){try{return cleanView(JSON.parse(sessionStorage.getItem(key)||'{}'));}catch{return cleanView({});}}
export function writeView(value){try{sessionStorage.setItem(key,JSON.stringify(cleanView(value)));}catch{}}
