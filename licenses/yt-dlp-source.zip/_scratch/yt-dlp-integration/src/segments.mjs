function mediaURL(value,base){const url=new URL(value,base);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw Error('分段链接无效');return url.href;}
function attrs(text){const result={};for(const m of text.matchAll(/(?:^|,)([\w-]+)=(?:"([^"]*)"|([^,]*))/g))result[m[1]]=m[2]??m[3];return result;}
function range(value,url,previous){const match=/^(\d+)(?:@(\d+))?$/.exec(value||'');if(!match||Number(match[1])<1)throw Error('分段范围无效');const start=match[2]===undefined?(previous?.url===url?previous.end+1:NaN):Number(match[2]);if(!Number.isSafeInteger(start))throw Error('分段范围缺少起点');return{start,end:start+Number(match[1])-1};}
export function hlsPlan(text,base){
 if(!text.trimStart().startsWith('#EXTM3U'))throw Error('HLS 清单无效');
 if(!text.includes('#EXT-X-ENDLIST'))throw Error('当前仅下载点播；直播流请使用录制工具');
 if(text.includes('#EXT-X-STREAM-INF'))throw Error('请先选择清晰度对应的媒体清单');
 const plan=[];let key=null,sequence=0,byteRange=null,previous;
 for(const raw of text.split(/\r?\n/)){
  const line=raw.trim();if(!line)continue;
  if(line.startsWith('#EXT-X-MEDIA-SEQUENCE:'))sequence=Number(line.split(':')[1]);
  else if(line.startsWith('#EXT-X-KEY:')){
   const a=attrs(line.slice(11));
   if(a.METHOD==='NONE')key=null;
   else{if(a.METHOD!=='AES-128'||(a.KEYFORMAT&&a.KEYFORMAT!=='identity'))throw Error('此加密协议不受支持');key={url:mediaURL(a.URI,base),iv:a.IV?.replace(/^0x/i,'').padStart(32,'0')};if(key.iv&&!/^[a-f\d]{32}$/i.test(key.iv))throw Error('加密 IV 无效');}
  }else if(line.startsWith('#EXT-X-MAP:')){
   const a=attrs(line.slice(11)),url=mediaURL(a.URI,base);if(key&&!key.iv)throw Error('加密初始化分段缺少 IV');
   plan.push({url,...(a.BYTERANGE?range(a.BYTERANGE,url,previous):{}),key:key?{...key}:null});
  }else if(line.startsWith('#EXT-X-BYTERANGE:'))byteRange=line.slice(17);
  else if(!line.startsWith('#')){
   const url=mediaURL(line,base),part={url,...(byteRange?range(byteRange,url,previous):{}),key:key?{...key,iv:key.iv||BigInt(sequence).toString(16).padStart(32,'0')}:null};
   plan.push(part);previous=part;byteRange=null;sequence++;
  }
 }
 if(!plan.length)throw Error('清单没有媒体分段');return plan;
}
export function fragmentPlan(format){
 return format.fragments.map(fragment=>{
  const url=mediaURL(fragment.url||fragment.path,format.fragment_base_url||format.url);
  return {url,...(fragment.range?{start:fragment.range.start,end:fragment.range.end}:{}),key:null};
 });
}
export async function prepareFormat(format,{signal,headers={}}={}){
 if(format.has_drm)throw Error('不能下载受 DRM 保护的媒体');
 if(/rtmp|mhtml|rtsp/.test(format.protocol||''))throw Error('浏览器无法使用此媒体协议');
 if(/m3u8/.test(format.protocol||'')||/\.m3u8(?:\?|$)/i.test(format.url)){
  const response=await fetch(format.url,{signal,headers,credentials:'omit'});if(!response.ok)throw Error('清单返回 HTTP '+response.status);
  return hlsPlan(await response.text(),response.url||format.url);
 }
 if(format.fragments?.length)return fragmentPlan(format);
 if(/dash/.test(format.protocol||''))throw Error('DASH 格式缺少可下载分段，请重新解析');
 return null;
}
export function downloadExtension(format,fragments){
 if(/m3u8/.test(format.protocol||'')&&fragments?.length){
  return fragments.some(part=>/\.(?:mp4|m4s|m4a)(?:\?|$)/i.test(part.url))?(format.ext||'mp4'):'ts';
 }
 return format.ext||'bin';
}
