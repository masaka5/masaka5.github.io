export async function runPostprocess(ids,{load,encode,signal,...options}){
 signal?.throwIfAborted();
 const files=await Promise.all(ids.map(async id=>{const{job,blob}=await load(id);return{ext:job.ext,blob};}));
 signal?.throwIfAborted();const result=await encode(files,{...options,signal});signal?.throwIfAborted();return result;
}
