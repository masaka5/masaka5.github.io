export async function runPostprocess(ids,{load,encode,signal,...options}){
 signal?.throwIfAborted();
 const files=await Promise.all(ids.map(async id=>{const{job,blob}=await load(id);return{ext:job.ext,kind:job.kind||(/^audio\//.test(job.mime||'')||/^(m4a|mp3|aac|opus|ogg|wav|flac)$/.test(job.ext)?'audio':'video'),blob};}));
 if(!options.audio&&files.length===2)files.sort((a,b)=>Number(a.kind==='audio')-Number(b.kind==='audio'));
 signal?.throwIfAborted();const result=await encode(files,{...options,signal});signal?.throwIfAborted();return result;
}
