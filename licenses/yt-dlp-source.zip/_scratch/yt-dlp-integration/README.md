# 媒体下载

React / Ant Design 视图，完整未修改 yt-dlp 2026.10.26 Python 包在共享 Pyodide CPython/WASM Worker 中执行。源码不使用 you-get。纯静态 HTTPS 部署，无媒体存储或转发服务。

```sh
npm ci
npm test
npm run build
```

产物写入 `../../toolbox-site/tools/yt-dlp`。部署包已有的 `/vendor/pyodide` 和 `/tools/studio/runtime/ffmpeg` 是共享依赖，勿重复下载/打包。构建缺少 wheel 时从固定 PyPI 地址下载并校验 SHA256。浏览器支持 JSPI 时解析网络使用异步流与原生同步 Python 桥接；旧浏览器降级为 Worker 同步 XHR，单响应限制32MiB。解析器从未跳过浏览器CORS/TLS限制。

功能：批量/列表解析、原始格式与组合选择、命令参数与Python JSON参数、列表序号、文件命名、字幕/缩略图/解析JSON导出、账户与Cookie文件解析（不注入跨域Cookie）、HTTP流、VOD HLS（含AES128）、extractor DASH分段、IndexedDB 暂存和 Range/分段续传、FFmpeg MP3提取与音视频重封装。所有解析器随原包分发；能力表来自原包真实参数/解析器列表。

这不是原生桌面yt-dlp的完整等价实现。未开放跨域的站点、系统代理/进程、系统Cookie读取、TLS指纹伪装、DRM、直播下载、任意原生后处理插件和JS外部运行时不可等价执行。YouTube当前在浏览器CORS下不可用。未验证参数不标成可用。暂停/缓存不能保证浏览器不会按自身存储策略回收数据；链接有效期也由媒体站点控制。多个格式分别下载后通过后处理合并，最多一个视频流和一个音频流；仅MP4/MKV重新封装、MP3编码已验证，不承诺所有格式/编解码。

测试脚本位于源码包 `_scratch/ops-tests/yt-dlp-*.py`，需从部署包根启动本地静态HTTP测试服务器8765，Playwright Chromium。传输测试仅本次测试临时启动8779端口，生产不包含服务。外部验证使用MDN公开音频，CORS阻断样本使用YouTube；报告区分网络真实样本和fixture。

原始yt-dlp源码及许可位于部署目录 `runtime/*.whl`（标准ZIP，所有Python源码完整保留）。本集成修改源码和依赖锁文件在本包；依赖许可证与来源清单位于站点licenses。
