# 媒体下载

React / Ant Design 视图，完整未修改 yt-dlp 2026.10.26 Python 包在共享 Pyodide CPython/WASM Worker 中执行。静态界面通过 Cloudflare Pages 流式转发已接入的媒体域名，不使用媒体存储服务。

```sh
npm ci
npm test
npm run build
```

产物写入 `../../toolbox-site/tools/yt-dlp`。部署包已有的 `/vendor/pyodide` 和 `/tools/studio/runtime/ffmpeg` 是共享依赖，勿重复下载/打包。构建缺少 wheel 时从固定 PyPI 地址下载并校验 SHA256。浏览器支持 JSPI 时解析网络使用异步流与原生同步 Python 桥接；旧浏览器降级为 Worker 同步 XHR，单响应限制32MiB。解析器从未跳过浏览器CORS/TLS限制。

功能：批量/列表解析、原始格式与组合选择、命令参数与Python JSON参数、列表序号、文件命名、字幕/缩略图/解析JSON导出、账户与Cookie文件解析（不注入跨域Cookie）、HTTP流、VOD HLS（含AES128）、extractor DASH分段、IndexedDB 暂存和 Range/分段续传、FFmpeg MP3提取与音视频重封装。所有解析器随原包分发；能力表来自原包真实参数/解析器列表。

这不是原生桌面 yt-dlp 的完整等价实现。系统代理/进程、系统 Cookie 读取、TLS 指纹伪装、DRM、直播下载、任意原生后处理插件和 JS 外部运行时不可等价执行。域名列表由浏览器和转发服务共享：YouTube、B站、Vimeo、SoundCloud、Dailymotion、Internet Archive 等。接入转发不代表原站必然允许访问；登录、人机验证、地区和云端出口风控仍可能拒绝。未接入的域名仍依赖原站 CORS。未验证参数不标成可用。

音视频组合作为一个任务显示，所有流完成后才提供保存；保存时使用 FFmpeg WASM 合并，MP4 音频转 AAC 以改善播放兼容性。下载源文件和组合信息均保存在 IndexedDB，刷新后可恢复再合并。大于 512 MiB 的合并仍受 WASM 内存限制，可在「合并 / 提取音频」中选择较小源文件；下载链接过期或浏览器回收缓存后需重新解析。仅 MP4/MKV 与 MP3 后处理经过测试，不承诺所有编解码。

2026-11-13 实测：SoundCloud、Internet Archive 和 MDN 公开媒体完整下载、独立解码及刷新恢复通过。YouTube 曾成功解析下载源流，随后两条有效公开链接在 Cloudflare 出口返回人机验证；当前不能承诺稳定可用。B站返回 412；Vimeo 样本的 DRM 被明确拒绝；Dailymotion API 后续要求指纹校验。页面按具体原因显示中文错误，不将这些结果标记为下载成功。

测试脚本位于源码包 `_scratch/ops-tests/yt-dlp-*.py`，需本地静态 HTTP 测试服务器 8765 和 Playwright Chromium。`yt-dlp-sites-live.py` 使用真实公开链接，不拦截站点响应；`yt-dlp-combination.py` 使用已知 MPD 和源文件 fixture，真实执行 yt-dlp 解析、缓存、WASM 合并、独立解码与浏览器播放。fixture 与外部样本的结论分开记录。传输测试临时启动 8779，生产不包含本地服务。

转发部署：`cd relay && node pages-build.mjs`，使用 Wrangler Pages 部署 `pocket-toolbox-media` 的 `main` 分支。逐跳检查媒体域名白名单，仅允许配置的站点 Origin，不传 Cookie；Dailymotion GraphQL 的公开 bearer 限定单一端点且重定向即清除。保留解析器的客户端 User-Agent，Origin 由服务端按目标平台固定，不接受任意目标与任意 Origin 转发。令牌通过环境变量注入，不包含在源码或构建物中。

原始yt-dlp源码及许可位于部署目录 `runtime/*.whl`（标准ZIP，所有Python源码完整保留）。本集成修改源码和依赖锁文件在本包；依赖许可证与来源清单位于站点licenses。
