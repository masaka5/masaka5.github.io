import test from 'node:test';import assert from 'node:assert/strict';
import {safeLinks,cleanView} from '../src/view-state.mjs';
test('page state excludes credentials, cookies, arbitrary advanced data and signed links',()=>{
 const state=cleanView({urls:'https://m.test/v\nhttps://m.test/v?token=private\nhttps://user:pass@m.test/v',config:{username:'private',password:'private',cookieText:'private',outtmpl:'%(title)s.%(ext)s',subtitles:true},options:'private',cli:'private',items:[{url:'private'}],tab:'downloads'});
 assert.equal(state.urls,'https://m.test/v');assert.equal(state.tab,'downloads');assert.equal(JSON.stringify(state).includes('private'),false);
 assert.equal(state.config.subtitles,true);assert.equal(safeLinks('javascript:alert(1)'),'');
});
test('malformed and expired view fields fall back without executing any task',()=>{
 assert.deepEqual(cleanView(null),{schema:1,urls:'',playlist:false,tab:'media',timeout:30,config:{}});
 assert.equal(cleanView({timeout:Infinity,tab:'run',config:{retries:99}}).tab,'media');
});
