import test from 'node:test';
import assert from 'node:assert/strict';
import {parseURLs,flattenMedia,selectFormats,safeFilename,validateRangeResponse,capabilityFor} from '../src/core.mjs';

test('batch URL validation preserves extractor prefixes but rejects scripts and embedded credentials',()=>{
 assert.deepEqual(parseURLs('https://example.com/a\nhttps://example.com/a\nytsearch2:小猫'),['https://example.com/a','ytsearch2:小猫']);
 for(const value of ['javascript:alert(1)','https://user:pass@example.com/','file:///etc/passwd'])assert.throws(()=>parseURLs(value));
});
test('nested playlists flatten once with entry metadata and exact formats',()=>{
 const result=flattenMedia({_type:'playlist',entries:[{_type:'playlist',entries:[{id:'v',title:'测试',formats:[{format_id:'137',url:'https://media.test/v.mp4',vcodec:'avc1',acodec:'none',height:1080},{format_id:'140',url:'https://media.test/a.m4a',vcodec:'none',acodec:'aac'}]}]},null]});
 assert.equal(result.length,1);assert.equal(result[0].formats.length,2);
 assert.deepEqual(selectFormats(result[0],'137+140').map(f=>f.format_id),['137','140']);
 assert.throws(()=>selectFormats(result[0],'missing'));
});
test('unsafe filenames are confined to flat browser downloads and extension retained',()=>{
 assert.equal(safeFilename('../../CON:片名?.mp4'),'CON_片名_.mp4');
 assert.equal(safeFilename('..'),'下载文件');
});
test('resume requires an exact Content-Range and detects servers ignoring or changing ranges',()=>{
 assert.equal(validateRangeResponse({status:206,start:100,contentRange:'bytes 100-199/300',received:100,expectedTotal:300}),300);
 assert.throws(()=>validateRangeResponse({status:200,start:100,received:300}));
 assert.throws(()=>validateRangeResponse({status:206,start:100,contentRange:'bytes 0-99/300',received:100}));
 assert.throws(()=>validateRangeResponse({status:206,start:100,contentRange:'bytes 100-199/301',received:100,expectedTotal:300}));
});
test('capabilities distinguish browser equivalents and unavailable native APIs',()=>{
 assert.equal(capabilityFor('--cookies-from-browser').support,'unsupported');
 assert.equal(capabilityFor('--proxy').support,'unsupported');
 assert.equal(capabilityFor('--format').support,'supported');
 assert.equal(capabilityFor('--embed-subs').support,'unverified');
});
