import test from 'node:test';import assert from 'node:assert/strict';
import {requestPlan} from '../src/transport.mjs';
import {handle} from '../relay/worker.mjs';
const hosts=['www.youtube.com','youtu.be','rr1---sn-test.googlevideo.com','i.ytimg.com','youtubei.googleapis.com','vimeo.com','player.vimeo.com','vod-adaptive-ak.vimeocdn.com','soundcloud.com','api-v2.soundcloud.com','cf-hls-media.sndcdn.com','playback.media-streaming.soundcloud.cloud','archive.org','ia800001.us.archive.org','www.dailymotion.com','graphql.api.dailymotion.com','proxy-01.dmcdn.net'];
test('platform extraction and CDN requests use one consistent relay policy',async()=>{
 for(const host of hosts){
  const url='https://'+host+'/media';assert.equal(requestPlan(url,{},{}).url,'https://pocket-toolbox-media.pages.dev/fetch',host);
  let called=false;const response=await handle(new Request('https://relay.test/fetch',{method:'POST',headers:{Origin:'https://tools.manshii.asia','X-Media-URL':url}}),{},async()=>{called=true;return new Response('media');});
  assert.equal(response.status,200,host);assert.ok(called,host);
 }
});

test('Dailymotion public API bearer only reaches its GraphQL endpoint and never redirects',async()=>{
 const execute=async(url,expected,redirect)=>{
  let count=0;
  const response=await handle(new Request('https://relay.test/fetch',{method:'POST',headers:{Origin:'https://tools.manshii.asia','X-Media-URL':url,'X-Media-Headers':JSON.stringify({Authorization:'Bearer public-token',Cookie:'private'})}}),{},async(target,init)=>{
   assert.equal(init.headers.get('Authorization'),count===0?expected:null);assert.equal(init.headers.get('Cookie'),null);count++;
   return redirect&&count===1?new Response(null,{status:302,headers:{Location:redirect}}):new Response('{}');
  });assert.equal(response.status,200);
 };
 await execute('https://graphql.api.dailymotion.com/','Bearer public-token','https://www.dailymotion.com/');
 await execute('https://www.youtube.com/',null);
 await execute('https://graphql.api.dailymotion.com/not-graphql',null);
});
test('platform relay preserves required API headers and site referer without leaking credentials',async()=>{
 let seen;
 await handle(new Request('https://relay.test/fetch',{method:'POST',headers:{Origin:'https://tools.manshii.asia','X-Media-URL':'https://www.youtube.com/youtubei/v1/player','X-Media-Method':'POST','X-Media-Headers':JSON.stringify({'Content-Type':'application/json','X-Youtube-Client-Name':'1','X-Youtube-Client-Version':'2.1',Referer:'https://www.youtube.com/',Cookie:'private',Authorization:'private'})},body:'{"videoId":"x"}'}),{},async(url,init)=>{seen=init;return new Response('{}');});
 assert.ok(seen);assert.equal(seen.headers.get('X-Youtube-Client-Name'),'1');assert.equal(seen.headers.get('Referer'),'https://www.youtube.com/');assert.equal(seen.headers.get('Cookie'),null);assert.equal(seen.headers.get('Authorization'),null);assert.equal(new TextDecoder().decode(seen.body),'{"videoId":"x"}');
});

test('extractor client User-Agent is preserved and API Origin cannot be spoofed',async()=>{
 let seen;
 await handle(new Request('https://relay.test/fetch',{method:'POST',headers:{Origin:'https://tools.manshii.asia','X-Media-URL':'https://www.youtube.com/youtubei/v1/player','X-Media-Headers':JSON.stringify({'User-Agent':'visionOS-client',Origin:'https://evil.test'})}}),{},async(url,init)=>{seen=init.headers;return new Response('{}');});
 assert.equal(seen.get('User-Agent'),'visionOS-client');assert.equal(seen.get('Origin'),'https://www.youtube.com');
});
