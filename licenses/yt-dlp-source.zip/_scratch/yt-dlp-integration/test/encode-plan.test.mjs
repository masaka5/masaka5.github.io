import test from 'node:test';import assert from 'node:assert/strict';
const module=await import('../src/encode-plan.mjs').catch(()=>({}));
test('MP3 extracts an audio stream and rejects ambiguous multi-file inputs',()=>{
 assert.equal(typeof module.encodePlan,'function');
 const p=module.encodePlan(['in.mp4'],{audio:true});assert.ok(p.args.includes('libmp3lame'));assert.equal(p.extension,'mp3');assert.ok(p.args.includes('-vn'));
 assert.throws(()=>module.encodePlan(['a','b'],{audio:true}),/一个/);
});
test('mux maps the correct streams and MP4 gets compatible AAC audio',()=>{
 assert.equal(typeof module.encodePlan,'function');
 const merge=module.encodePlan(['v.mp4','a.webm'],{format:'mp4'});assert.ok(merge.args.includes('aac'));assert.ok(merge.args.includes('0:v:0'));assert.ok(merge.args.includes('1:a:0'));
 assert.deepEqual(module.encodePlan(['v.mp4','a.webm'],{format:'mkv'}).args.slice(-5),['-c:v','copy','-c:a','copy','result.mkv']);
});
