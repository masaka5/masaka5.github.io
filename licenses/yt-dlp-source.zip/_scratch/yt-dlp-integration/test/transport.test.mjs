import test from 'node:test';
import {friendlyError} from '../src/transport.mjs';
test('login challenges, unavailable videos and encrypted media receive specific Chinese errors',()=>{
 assert.match(friendlyError('Sign in to confirm you’re not a bot'),/验证|登录/);
 assert.match(friendlyError('ログインして bot ではないことを確認してください'),/验证|登录/);
 assert.match(friendlyError('HTTP Error 401: Unauthorized'),/认证/);
 assert.match(friendlyError('Video unavailable'),/不可用/);
 assert.match(friendlyError('此加密协议不受支持'),/DRM|加密/);
 assert.match(friendlyError('The extractor is attempting impersonation, but none of these impersonate targets are available: firefox'),/指纹/);
});
import assert from 'node:assert/strict';
const transport=await import('../src/transport.mjs').catch(()=>({}));
test('relay streams bytes and preserves source URL, status and range headers',async()=>{
 assert.equal(typeof transport.mediaFetch,'function');
 let request;
 const response=await transport.mediaFetch('https://cn.test.bilivideo.com/video.m4s',{headers:{Range:'bytes=9-',Referer:'https://www.bilibili.com/'}},{mode:'relay'},async(url,init)=>{
  request={url,init};return new Response(new Uint8Array([9,10]),{status:206,headers:{'Content-Range':'bytes 9-10/11','X-Media-URL':'https://cn.test.bilivideo.com/video.m4s'}});
 });
 assert.equal(request.init.method,'POST');assert.equal(new Headers(request.init.headers).get('X-Media-URL'),'https://cn.test.bilivideo.com/video.m4s');
 assert.equal(new Headers(JSON.parse(new Headers(request.init.headers).get('X-Media-Headers'))).get('Range'),'bytes=9-');
 assert.equal(response.url,'https://cn.test.bilivideo.com/video.m4s');assert.equal(response.status,206);
 assert.equal(response.headers.get('Content-Range'),'bytes 9-10/11');assert.deepEqual([...new Uint8Array(await response.arrayBuffer())],[9,10]);
});
test('auto relays supported hosts, direct strips forbidden headers and never retries cancellation',async()=>{
 assert.equal(typeof transport.mediaFetch,'function');
 const calls=[];const fetcher=async(url,init)=>{calls.push({url,init});return new Response('ok');};
 await transport.mediaFetch('https://www.bilibili.com/video/BV1',{headers:{Cookie:'secret',Referer:'x'}},{mode:'auto'},fetcher);
 assert.equal(calls[0].init.method,'POST');assert.equal(JSON.parse(new Headers(calls[0].init.headers).get('X-Media-Headers')).Cookie,undefined);
 await transport.mediaFetch('https://example.com/file',{headers:{Referer:'x',Authorization:'live'}},{mode:'auto'},fetcher);
 assert.equal(new Headers(calls[1].init.headers).has('Referer'),false);assert.equal(new Headers(calls[1].init.headers).get('Authorization'),'live');
 const controller=new AbortController();controller.abort();let count=0;
 await assert.rejects(()=>transport.mediaFetch('https://www.bilibili.com/',{signal:controller.signal},{},async()=>{count++;}),{name:'AbortError'});assert.equal(count,0);
});
test('upstream 412 is reported as site refusal rather than a CORS error',()=>{
 assert.equal(typeof transport.friendlyError,'function');
 assert.match(transport.friendlyError('ERROR: HTTP Error 412: Precondition Failed'),/站点拒绝/);
 assert.doesNotMatch(transport.friendlyError('ERROR: HTTP Error 412: Precondition Failed'),/跨域失败/);
});
