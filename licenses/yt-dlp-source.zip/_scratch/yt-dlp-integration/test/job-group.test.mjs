import test from 'node:test';import assert from 'node:assert/strict';
const module=await import('../src/job-group.mjs').catch(()=>({}));
test('a media combination is saveable only after every stream is complete',()=>{
 assert.equal(typeof module.groupJobs,'function');
 const a={id:'v',name:'v.mp4',received:10,total:10,state:'complete',recipe:{ids:['v','a'],name:'成片.mp4',format:'mp4'}};
 const b={id:'a',parentId:'v',received:2,total:8,state:'running'};
 let rows=module.groupJobs([a,b]);assert.equal(rows.length,1);assert.equal(rows[0].state,'running');assert.equal(rows[0].received,12);assert.equal(rows[0].total,18);assert.equal(rows[0].name,'成片.mp4');
 b.state='complete';b.received=8;rows=module.groupJobs([a,b]);assert.equal(rows[0].state,'complete');
 b.state='error';b.error='源连接过期';assert.equal(module.groupJobs([a,b])[0].error,'源连接过期');
 assert.equal(module.groupJobs([a])[0].state,'error');
});
