import test from 'node:test';
import assert from 'node:assert/strict';
import {runPostprocess} from '../src/postprocess.mjs';
test('cancellation while loading cached files never starts encoding or publishes output',async()=>{
 let release,calls=0;const gate=new Promise(resolve=>release=resolve),controller=new AbortController();
 const task=runPostprocess(['a'],{signal:controller.signal,load:async()=>{await gate;return{job:{ext:'wav'},blob:new Blob(['audio'])};},encode:async()=>{calls++;return new Blob(['encoded']);}});
 controller.abort();release();await assert.rejects(task,{name:'AbortError'});assert.equal(calls,0);
});
test('cancellation during encoding suppresses its completed output',async()=>{
 let release;const gate=new Promise(resolve=>release=resolve),controller=new AbortController();
 const task=runPostprocess(['a'],{signal:controller.signal,load:async()=>({job:{ext:'wav'},blob:new Blob(['audio'])}),encode:async()=>{await gate;return new Blob(['encoded']);}});
 await Promise.resolve();await Promise.resolve();controller.abort();release();await assert.rejects(task,{name:'AbortError'});
});

test('manual merge orders video before audio regardless of selection order',async()=>{
 let files;
 await runPostprocess(['audio','video'],{load:async id=>({job:{ext:id==='audio'?'webm':'mp4',kind:id},blob:new Blob([id])}),encode:async value=>{files=value;return new Blob();}});
 assert.equal(await files[0].blob.text(),'video');assert.equal(await files[1].blob.text(),'audio');
});
