import test from 'node:test';
import assert from 'node:assert/strict';
import {hlsPlan,fragmentPlan,downloadExtension} from '../src/segments.mjs';

test('HLS VOD resolves initialization, relative paths, explicit and implicit byte ranges',()=>{
 const plan=hlsPlan('#EXTM3U\n#EXT-X-MAP:URI="init.mp4",BYTERANGE="100@0"\n#EXTINF:1,\n#EXT-X-BYTERANGE:200@100\nfile.mp4\n#EXTINF:1,\n#EXT-X-BYTERANGE:300\nfile.mp4\n#EXT-X-ENDLIST','https://media.test/path/stream.m3u8');
 assert.deepEqual(plan.map(p=>[p.url,p.start,p.end]),[['https://media.test/path/init.mp4',0,99],['https://media.test/path/file.mp4',100,299],['https://media.test/path/file.mp4',300,599]]);
});
test('HLS raw TS is not mislabeled MP4 before remuxing',()=>{
 assert.equal(downloadExtension({ext:'mp4',protocol:'m3u8_native'},[{url:'https://m.test/a.ts'}]),'ts');
 assert.equal(downloadExtension({ext:'mp4',protocol:'m3u8_native'},[{url:'https://m.test/init.mp4'}]),'mp4');
});
test('AES128 keys and sequence IVs preserved, DRM and live manifests rejected',()=>{
 const p=hlsPlan('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:257\n#EXT-X-KEY:METHOD=AES-128,URI="key.bin"\n#EXTINF:2,\na.ts\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:2,\nb.ts\n#EXT-X-ENDLIST','https://m.test/x.m3u8');
 assert.equal(p[0].key.url,'https://m.test/key.bin');assert.equal(p[0].key.iv,'00000000000000000000000000000101');assert.equal(p[1].key,null);
 assert.throws(()=>hlsPlan('#EXTM3U\n#EXTINF:1,\na.ts','https://m.test/a.m3u8'),/直播/);
 assert.throws(()=>hlsPlan('#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI="k"\na.ts\n#EXT-X-ENDLIST','https://m.test/a.m3u8'),/加密/);
});
test('DASH extractor fragments resolve base and exact byte ranges; unsafe media URLs rejected',()=>{
 assert.deepEqual(fragmentPlan({fragment_base_url:'https://m.test/path/',fragments:[{path:'init.mp4'},{url:'https://m.test/data.mp4',range:{start:10,end:19}}]}),[{url:'https://m.test/path/init.mp4',key:null},{url:'https://m.test/data.mp4',start:10,end:19,key:null}]);
 assert.throws(()=>fragmentPlan({fragments:[{url:'file:///root/passwd'}]}));
});
