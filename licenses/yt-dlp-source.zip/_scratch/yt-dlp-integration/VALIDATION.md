# 下载验证 · 2026-11-13

真实站点测试使用 Chromium、真实 Pyodide yt-dlp 和已部署的 Cloudflare 转发；未模拟站点响应。站点结果会随出口、地区、风控与媒体权限变化。

| 样本 | 实际结果 |
| --- | --- |
| SoundCloud / forss/flickermood | 解析、完整下载 4,320,403 字节、AAC 解码、刷新恢复通过 |
| Internet Archive / ElephantsDream（最小格式） | 完整下载 47,065,346 字节，H.264 + AAC、解码、刷新恢复通过 |
| MDN / flower.mp4 | 完整下载 1,128,375 字节，H.264 + AAC、解码、刷新恢复通过 |
| YouTube / jNQXAC9IVRw | 最初解析和下载源流通过；后续请求在云端出口被要求人机验证，不能保证可用 |
| YouTube / aqz-KE-bpKQ | 当前云端出口被要求人机验证；原生本机 yt-dlp 对照可解析 53 格式 |
| Bilibili / BV1bH4B6dEnW | 原站返回 412，页面说明站点拒绝访问 |
| Vimeo / 76979871 | 可解析；下载样本为 DRM / SAMPLE-AES，按设计拒绝 |
| Dailymotion / x84sh87 | 修正 GraphQL 公开 bearer 与固定 Origin 后，后续链路要求 Firefox TLS 指纹，浏览器运行时无法提供 |

转发使用平台/CDN 白名单，禁止私网、任意地址、Cookie 与跨平台认证泄漏。新站点应先检查具体 CDN，再扩展共享列表。不能用开放代理或随机公开接口掩盖认证/风控失败。

独立组合回归以 MPD fixture 和公开 MDN 媒体生成 H.264 无声视频 + Opus 音频，真实执行解析、双流传输、组合任务刷新恢复和 WASM MP4 合并。最终 970,647 字节，FFprobe 确认 H.264 + AAC，FFmpeg 完整解码通过，浏览器播放得到 960×540 并推进时间。该 fixture 证明合并链路，不代表 YouTube 的原站权限通过。

回归命令：

```sh
node --test test/*.test.mjs relay/test/*.test.mjs
npm run build
python ../ops-tests/yt-dlp-browser.py
python ../ops-tests/yt-dlp-combination.py
python ../ops-tests/yt-dlp-layout.py
python ../ops-tests/yt-dlp-cache-headers.py
python ../ops-tests/yt-dlp-transfers.py
```

`yt-dlp-sites-live.py` 输出测试 JSON，支持 `YTDLP_TEST_BASE`、`YTDLP_TEST_SITES`、`YTDLP_TEST_TAG`。测试媒体与含临时签名的请求日志留在本地，不加入发布包。
