const domains=['bilibili.com','biliapi.net','biliapi.com','bilivideo.com','bilivideo.cn','hdslb.com','b23.tv'];
function target(value){const url=new URL(value);if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.port&&!['80','443'].includes(url.port)||!domains.some(d=>url.hostname===d||url.hostname.endsWith('.'+d)))throw Error('不支持此转发地址');url.protocol='https:';url.port='';return url;}
export async function handle(request,env,fetcher=fetch){
 const origin=request.headers.get('Origin'),allowed=(env.ALLOWED_ORIGINS||'https://tools.manshii.asia,https://masaka5.github.io,http://127.0.0.1:8765').split(',');
 if(!allowed.includes(origin))return new Response('Forbidden',{status:403});
 const cors={'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'X-Media-URL, X-Media-Method, X-Media-Headers, Content-Type','Access-Control-Expose-Headers':'Content-Length, Content-Type, Content-Range, Accept-Ranges, ETag, Last-Modified, X-Media-URL, X-Media-Error','Access-Control-Max-Age':'86400','Vary':'Origin','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
 const fail=(message,status=403)=>new Response(message,{status,headers:{...cors,'X-Media-Error':encodeURIComponent(message)}});
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(new URL(request.url).pathname!=='/fetch'||request.method!=='POST')return fail('转发接口不存在',404);
 try{
  let url=target(request.headers.get('X-Media-URL'));
  let method=request.headers.get('X-Media-Method')||'GET';if(!['GET','HEAD','POST'].includes(method))return fail('不支持此请求方法',405);
  const raw=request.headers.get('X-Media-Headers')||'{}';if(raw.length>16384)return fail('请求头过大',431);
  const headers=new Headers();
  for(const [name,value]of Object.entries(JSON.parse(raw)))if(/^(accept|accept-language|content-type|range|if-range|if-none-match|if-modified-since)$/i.test(name)&&typeof value==='string')headers.set(name,value);
  headers.set('Referer','https://www.bilibili.com/');headers.set('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36');
  headers.set('Accept-Encoding','identity');
  let body;
  if(method==='POST'&&request.body){
   const reader=request.body.getReader(),chunks=[];let length=0;
   while(true){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>1048576){await reader.cancel();return fail('请求内容过大',413);}chunks.push(value);}
   body=new Uint8Array(length);let offset=0;for(const chunk of chunks){body.set(chunk,offset);offset+=chunk.length;}
  }
  for(let hop=0;hop<6;hop++){
   const upstream=await fetcher(url.href,{method,headers,body,redirect:'manual',signal:request.signal});
   if([301,302,303,307,308].includes(upstream.status)){
    const location=upstream.headers.get('Location');await upstream.body?.cancel();if(!location)return fail('站点重定向缺少地址',502);url=target(new URL(location,url).href);
    if(upstream.status===303&&method!=='HEAD'||[301,302].includes(upstream.status)&&method==='POST'){method='GET';body=undefined;headers.delete('Content-Type');}continue;
   }
   const output=new Headers(cors);
   for(const name of ['Content-Type','Content-Length','Content-Range','Accept-Ranges','ETag','Last-Modified'])if(upstream.headers.has(name))output.set(name,upstream.headers.get(name));
   if(upstream.headers.has('Content-Encoding')){output.delete('Content-Length');output.set('Content-Encoding',upstream.headers.get('Content-Encoding'));}
   output.set('X-Media-URL',url.href);
   return new Response(method==='HEAD'?null:upstream.body,{status:upstream.status,headers:output});
  }
  return fail('站点重定向次数过多',502);
 }catch(error){return fail(error.message==='不支持此转发地址'?error.message:'转发连接失败，请稍后重试',error.message==='不支持此转发地址'?403:502);}
}
export default {fetch:(request,env)=>handle(request,env)};
