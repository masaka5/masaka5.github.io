import {build} from 'esbuild';
import {mkdir,writeFile} from 'node:fs/promises';
await mkdir('pages',{recursive:true});
await build({entryPoints:['worker.mjs'],bundle:true,minify:true,format:'esm',outfile:'pages/_worker.js',target:'es2022'});
await writeFile('pages/_routes.json',JSON.stringify({version:1,include:['/*'],exclude:[]}));
