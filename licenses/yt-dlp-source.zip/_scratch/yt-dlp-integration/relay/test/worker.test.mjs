import test from 'node:test';import assert from 'node:assert/strict';
const module=await import('../worker.mjs').catch(()=>({}));
const env={ALLOWED_ORIGINS:'https://tools.manshii.asia'};
function request(url,extra={}){return new Request('https://relay.test/fetch',{method:'POST',headers:{Origin:'https://tools.manshii.asia','X-Media-URL':url,...extra}});}
test('relay rejects private hosts, spoofed suffixes and disallowed origins',async()=>{
 assert.equal(typeof module.handle,'function');
 for(const url of ['http://127.0.0.1/','https://bilibili.com.evil.test/','https://user:pass@www.bilibili.com/','https://10.0.0.1/'])assert.equal((await module.handle(request(url),env)).status,403);
 assert.equal((await module.handle(request('https://www.bilibili.com/',{Origin:'https://evil.test'}),env)).status,403);
});
test('relay preserves ranges, strips cookies and stops unsafe redirects',async()=>{
 assert.equal(typeof module.handle,'function');let seen;
 const response=await module.handle(request('https://www.bilibili.com/a',{'X-Media-Headers':JSON.stringify({Range:'bytes=2-',Cookie:'secret'})}),env,async(url,init)=>{seen=init;return new Response(new Uint8Array([2,3]),{status:206,headers:{'Content-Range':'bytes 2-3/4','Set-Cookie':'never=forward'}});});
 assert.equal(response.status,206);assert.equal(response.headers.get('Access-Control-Allow-Origin'),'https://tools.manshii.asia');assert.equal(response.headers.get('Content-Range'),'bytes 2-3/4');assert.equal(response.headers.get('Set-Cookie'),null);
 assert.equal(seen.headers.get('Range'),'bytes=2-');assert.equal(seen.headers.get('Cookie'),null);assert.equal(seen.headers.get('Referer'),'https://www.bilibili.com/');assert.equal(await response.text(),'\u0002\u0003');
 const redirected=await module.handle(request('https://www.bilibili.com/'),env,async()=>new Response(null,{status:302,headers:{Location:'http://169.254.169.254/'}}));assert.equal(redirected.status,403);
});
test('relay follows browser redirect method semantics and avoids compressed length corruption',async()=>{
 assert.equal(typeof module.handle,'function');let calls=0;
 const req=new Request('https://relay.test/fetch',{method:'POST',headers:{Origin:'https://tools.manshii.asia','X-Media-URL':'https://www.bilibili.com/a','X-Media-Method':'POST'},body:'payload'});
 const response=await module.handle(req,env,async(url,init)=>{calls++;if(calls===1)return new Response(null,{status:303,headers:{Location:'/b'}});assert.equal(init.method,'GET');assert.equal(init.body,undefined);return new Response('uncompressed',{headers:{'Content-Encoding':'gzip','Content-Length':'6'}});});
 assert.equal(response.status,200);assert.equal(response.headers.get('Content-Length'),null);assert.equal(await response.text(),'uncompressed');
});
