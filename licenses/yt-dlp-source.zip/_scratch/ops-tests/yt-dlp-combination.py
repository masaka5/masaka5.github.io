"""Real generic MPD extraction -> two streams -> grouped save -> WASM mux -> independent decode."""
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import subprocess,json
root=Path(__file__).parents[2];output=root/'.superpowers/yt-dlp-downloads';output.mkdir(exist_ok=True)
ffmpeg='C:/Users/happyelements/AppData/Local/Programs/Open Design/resources/app/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
ffprobe='C:/Users/happyelements/AppData/Local/Programs/TRAE SOLO CN/resources/app/bin/ffprobe.exe'
source=output/'MDN-flower.mp4'
for args in [['-an','-c:v','copy','split-video.mp4'],['-vn','-c:a','libopus','split-audio.webm']]:
 subprocess.run([ffmpeg,'-v','error','-y','-i',str(source),*args[:-1],str(output/args[-1])],check=True)
manifest='''<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT5.055S" minBufferTime="PT1S"><Period><AdaptationSet mimeType="video/mp4" codecs="avc1.4d401f"><Representation id="video" bandwidth="2000000" width="960" height="540"><BaseURL>split-video.mp4</BaseURL></Representation></AdaptationSet><AdaptationSet mimeType="audio/webm" codecs="opus"><Representation id="audio" bandwidth="128000" audioSamplingRate="48000"><BaseURL>split-audio.webm</BaseURL></Representation></AdaptationSet></Period></MPD>'''
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page(accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/split-fixture.mpd',lambda r:r.fulfill(body=manifest,content_type='application/dash+xml'))
 for name,content_type in [('split-video.mp4','video/mp4'),('split-audio.webm','audio/webm')]:
  page.route('**/'+name,lambda r,request,n=name,t=content_type:r.fulfill(body=(output/n).read_bytes(),content_type=t))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 page.get_by_role('textbox',name='媒体链接',exact=True).fill('http://127.0.0.1:8765/split-fixture.mpd')
 page.get_by_role('button',name='解析',exact=True).click()
 expect(page.get_by_role('button',name='download 下载',exact=True)).to_be_visible(timeout=60000)
 assert '推荐音视频组合'in page.locator('.ant-table-row').inner_text(),page.locator('body').inner_text()
 page.get_by_role('button',name='download 下载',exact=True).click()
 save=page.locator('button[aria-label^="保存 "]');expect(save).to_be_visible(timeout=30000)
 assert page.locator('.ant-tabs-tabpane-active .ant-table-row').count()==1
 # Restoring a group must retain both stream references and download bytes.
 page.reload();expect(save).to_be_visible(timeout=30000)
 with page.expect_download(timeout=90000)as d:save.click()
 final=output/'split-merged.mp4';d.value.save_as(final)
 probe=json.loads(subprocess.check_output([ffprobe,'-v','error','-show_entries','stream=codec_type,codec_name','-of','json',str(final)]))
 assert {s['codec_type']for s in probe['streams']}=={'audio','video'},probe
 assert next(s for s in probe['streams']if s['codec_type']=='audio')['codec_name']=='aac'
 subprocess.run([ffmpeg,'-v','error','-i',str(final),'-f','null','-'],check=True)
 # Manual postprocessing must accept audio/video selected in either order.
 page.get_by_role('button',name='合并 / 提取音频',exact=True).click()
 combo=page.get_by_role('combobox',name='待处理文件',exact=True);combo.click()
 for needle in ['audio','video']:
  option=page.locator('.ant-select-item-option').filter(has_text=needle).first;option.click()
 page.keyboard.press('Escape')
 with page.expect_download(timeout=90000)as d:page.get_by_role('button',name='导出',exact=True).click()
 reverse=output/'reverse-merged.mp4';d.value.save_as(reverse)
 subprocess.run([ffmpeg,'-v','error','-i',str(reverse),'-f','null','-'],check=True)
 # Browser playback also checks container compatibility.
 played=page.evaluate('''async bytes=>{const url=URL.createObjectURL(new Blob([new Uint8Array(bytes)],{type:'video/mp4'}));const v=document.createElement('video');v.muted=true;v.src=url;document.body.append(v);await v.play();await new Promise((ok,fail)=>{const end=setTimeout(()=>fail(Error('play timeout')),10000);v.ontimeupdate=()=>{if(v.currentTime>.2){clearTimeout(end);ok()}};v.onerror=()=>fail(Error('video error'))});const result={width:v.videoWidth,height:v.videoHeight,time:v.currentTime};v.pause();v.remove();URL.revokeObjectURL(url);return result;}''',list(final.read_bytes()))
 assert not errors,errors;b.close();print(json.dumps({'group_restored':True,'bytes':final.stat().st_size,'streams':probe['streams'],'browser_playback':played,'decoded':True,'page_errors':errors}))
