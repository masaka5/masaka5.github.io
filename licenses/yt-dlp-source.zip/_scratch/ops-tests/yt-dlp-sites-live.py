"""Real public site extraction/download audit; no intercepted site responses."""
import asyncio,json,hashlib,time,os,subprocess
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
CASES=[
 ('YouTube','https://www.youtube.com/watch?v=jNQXAC9IVRw'),
 ('YouTube2','https://www.youtube.com/watch?v=aqz-KE-bpKQ'),
 ('Vimeo','https://player.vimeo.com/video/76979871'),
 ('Dailymotion','https://www.dailymotion.com/video/x84sh87'),
 ('SoundCloud','https://soundcloud.com/forss/flickermood'),
 ('Bilibili','https://www.bilibili.com/video/BV1bH4B6dEnW/'),
 ('Archive','https://archive.org/details/ElephantsDream'),
 ('MDN','https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'),
]
async def main():
 results=[];sem=asyncio.Semaphore(2)
 async with async_playwright()as p:
  browser=await p.chromium.launch()
  async def check(name,url):
   async with sem:
    context=await browser.new_context(accept_downloads=True);page=await context.new_page();requests=[];failures=[];responses=[];errors=[];began=time.monotonic()
    page.on('request',lambda r:requests.append({'host':urlsplit(r.url).hostname,'method':r.method,'target':r.headers.get('x-media-url','').split('?')[0]})if '/vendor/' not in r.url else None)
    page.on('requestfailed',lambda r:failures.append({'url':r.url.split('?')[0],'error':r.failure}))
    page.on('response',lambda r:responses.append({'url':r.url.split('?')[0],'status':r.status})if r.status>=400 else None)
    page.on('pageerror',lambda e:errors.append(str(e)))
    row={'site':name,'url':url,'parsed':False,'downloaded':False}
    try:
     await page.goto(os.getenv('YTDLP_TEST_BASE','https://tools.manshii.asia')+'/tools/yt-dlp/',timeout=45000)
     await page.get_by_role('textbox',name='媒体链接',exact=True).fill(url)
     if name in ['YouTube2','Archive']:
      await page.get_by_role('button',name='setting 设置',exact=True).click()
      await page.get_by_role('tab',name='高级',exact=True).click()
      await page.get_by_role('textbox',name='命令参数',exact=True).fill('--format "bestvideo[height<=360]+bestaudio/best"'if name=='YouTube2'else'--format worst')
      await page.get_by_role('button',name='Close',exact=True).click()
     await page.get_by_role('button',name='解析',exact=True).click()
     await page.wait_for_function('document.querySelector(".ant-alert-error")||document.querySelector(".ant-table-row")',timeout=60000)
     if await page.locator('.ant-alert-error').count():row['error']=await page.locator('.ant-alert-error').inner_text()
     else:
      row['parsed']=True;row['result']=(await page.locator('.ant-table-row').first.inner_text())[:500]
      buttons=page.get_by_role('button',name='download 下载',exact=True)
      if await buttons.count():
       await buttons.first.click()
       await page.wait_for_function('Array.from(document.querySelectorAll("button")).some(e=>(e.getAttribute("aria-label")||"").startsWith("保存 "))||document.querySelector(".ant-alert-error")||document.body.innerText.includes("下载失败")',timeout=150000)
       save=page.locator('button[aria-label^="保存 "]')
       if await save.count():
        async with page.expect_download(timeout=150000)as ev:await save.first.click()
        dl=await ev.value;data=Path(await dl.path()).read_bytes();row.update(downloaded=True,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),filename=dl.suggested_filename)
        output=Path(__file__).parents[2]/'.superpowers/yt-dlp-downloads';output.mkdir(exist_ok=True)
        artifact=output/(name+'-'+dl.suggested_filename);await dl.save_as(artifact)
        ffdir=Path('C:/Users/happyelements/AppData/Local/Programs/TRAE SOLO CN/resources/app/bin')
        probe=subprocess.run([str(ffdir/'ffprobe.exe'),'-v','error','-show_entries','stream=codec_type,codec_name,width,height:format=duration','-of','json',str(artifact)],capture_output=True,text=True,timeout=30)
        row['probe']=json.loads(probe.stdout)if probe.returncode==0 else{'error':probe.stderr[:300]}
        decoder=Path('C:/Users/happyelements/AppData/Local/Programs/Open Design/resources/app/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe')
        decode=subprocess.run([str(decoder),'-v','error','-i',str(artifact),'-t','3','-f','null','-'],capture_output=True,text=True,timeout=60)
        row['decoded']=decode.returncode==0;row['decode_error']=decode.stderr[:500]
        if name.startswith('YouTube'):
         assert {s['codec_type']for s in row['probe'].get('streams',[])}>={'video','audio'},row['probe']
         assert row['decoded'],row['decode_error']
        await page.reload();await page.locator('button[aria-label^="保存 "]').first.wait_for(timeout=15000);row['cache_after_reload']=True
       else:row['error']=(await page.locator('body').inner_text())[-2000:]
    except Exception as e:row['error']=str(e)[:600];row['body']=(await page.locator('body').inner_text())[-2000:]
    row.update(seconds=round(time.monotonic()-began,1),requests=requests,failures=failures,responses=responses,page_errors=errors)
    results.append(row);print(json.dumps({k:v for k,v in row.items()if k not in ['requests','failures','responses']},ensure_ascii=False),flush=True);await context.close()
  selection=os.getenv('YTDLP_TEST_SITES','').split(',')
  await asyncio.gather(*(check(n,u)for n,u in CASES if selection==['']or n in selection))
  await browser.close()
 output=Path(__file__).parent/('yt-dlp-sites-'+os.getenv('YTDLP_TEST_TAG','baseline')+'.json');output.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
asyncio.run(main())
