import requests,json,sys,zipfile,re
from pathlib import Path
wheel=next((Path(__file__).parents[2]/'toolbox-site/tools/yt-dlp/runtime').glob('*.whl'))
with zipfile.ZipFile(wheel)as z:source=z.read('yt_dlp/extractor/dailymotion.py').decode()
params={'grant_type':'client_credentials',**dict(re.findall(r"'(client_(?:id|secret))': '([^']+)'",source))}
target='https://graphql.api.dailymotion.com/'
def relay(url,headers,body):
 return requests.post('https://pocket-toolbox-media.pages.dev/fetch',headers={'Origin':'http://127.0.0.1:8765','X-Media-URL':url,'X-Media-Method':'POST','X-Media-Headers':json.dumps(headers)},data=body,timeout=30)
token=relay(target+'oauth/token',{'Content-Type':'application/x-www-form-urlencoded'},requests.models.RequestEncodingMixin._encode_params(params))
print('token',token.status_code,flush=True)
value=token.json().get('access_token','')
print(json.dumps({'token_length':len(value),'bearer_syntax':bool(re.fullmatch(r'[A-Za-z0-9._~+/\-]+=*',value)),'extra_chars':list(set(re.sub(r'[A-Za-z0-9._~+/=\-]','',value)))}),flush=True)
r=relay(target,{'Content-Type':'application/json','Authorization':'Bearer '+value,'Origin':'https://www.dailymotion.com'},json.dumps({'query':'{video(xid: "x84sh87") { xid title }}'}))
print(json.dumps({'graphql':r.status_code,'body':r.text[:1000].replace(value,'<token>')},ensure_ascii=False),flush=True)
