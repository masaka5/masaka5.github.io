"""External CORS-enabled real media and blocked-site behavior; no network mocks."""
from playwright.sync_api import sync_playwright,expect
import json,hashlib
with sync_playwright()as p:
 browser=p.chromium.launch();page=browser.new_page(accept_downloads=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 url='https://interactive-examples.mdn.mozilla.net/media/cc0-audio/t-rex-roar.mp3'
 page.get_by_role('textbox',name='媒体链接',exact=True).fill(url)
 page.get_by_role('button',name='解析',exact=True).click()
 button=page.get_by_role('button',name='download 下载',exact=True)
 expect(button).to_be_visible(timeout=60000);button.click()
 save=page.get_by_role('button',name='保存 t-rex-roar.mp3',exact=True)
 expect(save).to_be_visible(timeout=60000)
 with page.expect_download()as d:save.click()
 content=d.value.path().read_bytes();assert len(content)>10000
 page.get_by_role('textbox',name='媒体链接',exact=True).fill('https://www.youtube.com/watch?v=BaW_jenozKc')
 page.get_by_role('button',name='解析',exact=True).click()
 expect(page.get_by_role('alert')).to_be_visible(timeout=90000)
 blocked=page.get_by_role('alert').inner_text()
 assert '跨域'in blocked or '网络'in blocked,blocked
 assert not errors,errors
 print(json.dumps({'public_media_bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'blocked_site':blocked},ensure_ascii=False))
 browser.close()
