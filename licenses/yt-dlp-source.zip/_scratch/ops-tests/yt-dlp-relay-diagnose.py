from pathlib import Path
import json,requests
rows=json.loads((Path(__file__).parent/'yt-dlp-sites-relay-main.json').read_text(encoding='utf8'))
for row in rows:
 if row['site']!='Vimeo':continue
 urls=list(dict.fromkeys(r['target'] for r in row['requests']if 'vimeocdn.com/' in r['target']))
 for url in urls[:5]:
  try:
   r=requests.get(url,headers={'Referer':'https://vimeo.com/'},allow_redirects=False,timeout=15,stream=True)
   print(json.dumps({'host':requests.utils.urlparse(url).hostname,'status':r.status_code,'location':r.headers.get('Location','').split('?')[0]},ensure_ascii=False),flush=True);r.close()
  except Exception as e:print(type(e).__name__,flush=True)
