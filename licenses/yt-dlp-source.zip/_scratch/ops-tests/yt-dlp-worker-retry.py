"""Real WASM worker retries a failed initialization without a broken half-instance."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import io,wave,json
root=Path(__file__).resolve().parents[2];buf=io.BytesIO()
with wave.open(buf,'wb')as a:a.setnchannels(1);a.setsampwidth(2);a.setframerate(8000);a.writeframes(b'\0\0'*8000)
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page();attempts=[]
 def wheel(route):
  attempts.append(1)
  if len(attempts)==1:route.fulfill(status=503,body='temporary failure')
  else:route.fulfill(body=(root/'toolbox-site/tools/yt-dlp/runtime/yt_dlp-2026.10.26.whl').read_bytes(),content_type='application/zip')
 page.route('**/yt_dlp-2026.10.26.whl',wheel)
 page.route('**/retry-init.wav',lambda r:r.fulfill(body=buf.getvalue(),content_type='audio/wav'))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 result=page.evaluate('''async()=>{
 const worker=new Worker('./worker.js',{type:'module'});
 const messages=[];let waiting;
 worker.onmessage=e=>{if(['error','result','catalog'].includes(e.data.type))waiting?.(e.data)};
 const send=data=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('worker timeout')),120000);waiting=m=>{clearTimeout(timer);resolve(m)};worker.postMessage(data)});
 const first=await send({type:'extract',urls:[location.origin+'/retry-init.wav']});
 const second=await send({type:'extract',urls:[location.origin+'/retry-init.wav']});
 worker.terminate();return {first:first.type,second:second.type,error:second.text};}''')
 assert result['first']=='error',result
 assert result['second']=='result',result
 assert len(attempts)==2,attempts
 print(json.dumps(result));b.close()
