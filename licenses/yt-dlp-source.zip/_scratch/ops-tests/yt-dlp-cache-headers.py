from playwright.sync_api import sync_playwright
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page()
 page.route('**/storage-test.mjs',lambda r:r.fulfill(body=(ROOT/'_scratch/yt-dlp-integration/src/storage.mjs').read_bytes(),content_type='text/javascript'))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 result=page.evaluate('''async()=>{
  const store=await import('./storage-test.mjs');const job={id:'header-security-test',received:0,created:Date.now(),headers:{Authorization:'Bearer private-header-secret','X-API-Key':'private-custom-secret',Accept:'video/*','User-Agent':'visionOS-client',Referer:'https://www.youtube.com/watch?v=public'}};
  await store.saveJob(job);await store.appendPart(job,new Uint8Array([1,2]));
  const db=await new Promise((ok,fail)=>{const r=indexedDB.open('pocket-media-downloads-v1');r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error)});
  const read=()=>new Promise(ok=>{const r=db.transaction('jobs').objectStore('jobs').get(job.id);r.onsuccess=()=>ok(r.result)});
  const first=await read();if(JSON.stringify(first).includes('private-'))throw Error('credential header persisted');
  if(first.headers['User-Agent']!=='visionOS-client'||first.headers.Referer!==job.headers.Referer)throw Error('required media headers lost on refresh');
  await new Promise(ok=>{const tx=db.transaction('jobs','readwrite');tx.objectStore('jobs').put({...job,headers:{Authorization:'Bearer legacy-secret'}});tx.oncomplete=ok});
  const originals=Object.fromEntries(['getAll','openCursor'].map(name=>[name,IDBObjectStore.prototype[name]]));let queued=false;
  for(const name of Object.keys(originals))IDBObjectStore.prototype[name]=function(...args){const request=originals[name].apply(this,args);if(this.name==='jobs'&&!queued){queued=true;request.addEventListener('success',()=>{const tx=db.transaction('jobs','readwrite');tx.objectStore('jobs').put({...job,received:77,headers:{Accept:'video/*'}});},{once:true});}return request;};
  await store.listJobs();Object.assign(IDBObjectStore.prototype,originals);const legacy=await read();if(JSON.stringify(legacy).includes('legacy-secret'))throw Error('legacy credential retained');if(!queued||legacy.received!==77)throw Error('migration overwrote newer progress');
  await store.removeJob(job.id);db.close();return{safe: first.headers.Accept,credentials_live:job.headers.Authorization,legacy_purged:true};}''')
 assert result['safe']=='video/*';assert result['credentials_live']=='Bearer private-header-secret'
 print(json.dumps(result));b.close()
