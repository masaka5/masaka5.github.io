from pathlib import Path
from playwright.sync_api import sync_playwright
import io,wave,json
ROOT=Path(__file__).resolve().parents[2]
buffer=io.BytesIO()
with wave.open(buffer,'wb')as a:
 a.setnchannels(1);a.setsampwidth(2);a.setframerate(8000);a.writeframes(b'\0\0'*8000)
with sync_playwright()as p:
 browser=p.chromium.launch();page=browser.new_page();errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/ffmpeg-test.mjs',lambda r:r.fulfill(body=(ROOT/'_scratch/yt-dlp-integration/ffmpeg-test.mjs').read_bytes(),content_type='text/javascript'))
 page.route('**/ffmpeg-wave.wav',lambda r:r.fulfill(body=buffer.getvalue(),content_type='audio/wav'))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 result=page.evaluate('''async()=>{
  const {encode,stopEncoding}=await import('./ffmpeg-test.mjs');const blob=await(await fetch('./ffmpeg-wave.wav')).blob();
  const values=[];for(let i=0;i<2;i++){
   const result=await encode([{blob,ext:'wav'}],{audio:true,onProgress:v=>values.push([i,v])});
   const audio=new AudioContext();const decoded=await audio.decodeAudioData(await result.arrayBuffer());await audio.close();
   if(decoded.duration<.9)throw Error('音频编码内容无效');
  }stopEncoding();return {progress:values,verifiedConversions:2};}''')
 assert not errors,errors
 assert any(i==1 for i,v in result['progress']),result
 print(json.dumps(result));browser.close()
