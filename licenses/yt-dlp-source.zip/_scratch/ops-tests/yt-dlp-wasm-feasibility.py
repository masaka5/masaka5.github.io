"""Prove the real pinned yt-dlp package can extract and download inside CPython WASM.

The HTTP handler uses synchronous XMLHttpRequest in a Worker. This is a feasibility
probe, not a production downloader; its small response body is intentionally buffered.
Only package/known media fixtures are intercepted, never extractor results.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import io,json,wave,math,struct

ROOT=Path(__file__).resolve().parents[2]
wheel=ROOT/'_scratch/yt_dlp-2026.10.26-py3-none-any.whl'
buffer=io.BytesIO()
with wave.open(buffer,'wb') as audio:
 audio.setnchannels(1);audio.setsampwidth(2);audio.setframerate(8000)
 audio.writeframes(b''.join(struct.pack('<h',int(8000*math.sin(2*math.pi*440*i/8000)))for i in range(8000)))
media=buffer.getvalue()
worker=r'''
import {loadPyodide} from 'http://127.0.0.1:8765/vendor/pyodide/pyodide.mjs';
try{
 const py=await loadPyodide({indexURL:'http://127.0.0.1:8765/vendor/pyodide/',stdout:s=>postMessage({log:s}),stderr:s=>postMessage({log:s})});
 const wheel=new Uint8Array(await(await fetch('http://127.0.0.1:8765/yt-dlp-feasibility.whl')).arrayBuffer());
 py.FS.writeFile('/tmp/yt_dlp.zip',wheel);
 const result=py.runPython(`
import sys, io, json
sys.path.insert(0, '/tmp/yt_dlp.zip')
import yt_dlp
from yt_dlp.version import __version__
from yt_dlp.networking.common import RequestHandler, Response
from yt_dlp.networking.exceptions import TransportError, HTTPError
from js import XMLHttpRequest, Uint8Array

class BrowserRH(RequestHandler):
    _SUPPORTED_URL_SCHEMES = ('http', 'https')
    _SUPPORTED_PROXY_SCHEMES = ()
    def _send(self, request):
        xhr = XMLHttpRequest.new()
        xhr.open(request.method, request.url, False)
        xhr.responseType = 'arraybuffer'
        for key, value in request.headers.items():
            if key.lower() not in ('user-agent', 'referer', 'cookie', 'host', 'accept-encoding', 'connection', 'content-length'):
                xhr.setRequestHeader(key, value)
        try:
            xhr.send(None if request.data is None else Uint8Array.new(request.data))
        except Exception as error:
            raise TransportError('Browser request blocked: ' + str(error)) from error
        headers = dict(line.split(': ', 1) for line in xhr.getAllResponseHeaders().splitlines() if ': ' in line)
        body = bytes(Uint8Array.new(xhr.response).to_py()) if xhr.response is not None else b''
        response = Response(io.BytesIO(body), xhr.responseURL or request.url, headers, xhr.status)
        if xhr.status >= 400:
            raise HTTPError(response)
        return response

with yt_dlp.YoutubeDL({'quiet': True, 'no_warnings': True, 'noplaylist': True, 'outtmpl': '/tmp/result.%(ext)s', 'js_runtimes': {}}) as ydl:
    ydl._request_director.close()
    ydl._request_director.add_handler(BrowserRH(logger=ydl._request_director.logger))
    info=ydl.extract_info('http://127.0.0.1:8765/wave-fixture.wav', download=True)
    result={'version':__version__, 'extractor':info['extractor'], 'ext':info['ext'], 'title':info['title'], 'bytes':len(open('/tmp/result.wav','rb').read())}
json.dumps(result)
`);
 postMessage({result:JSON.parse(result)});
}catch(error){postMessage({error:String(error)});}
'''
with sync_playwright() as p:
 browser=p.chromium.launch();page=browser.new_page();logs=[]
 page.route('**/yt-dlp-feasibility.whl',lambda route:route.fulfill(body=wheel.read_bytes(),content_type='application/octet-stream'))
 page.route('**/wave-fixture.wav',lambda route:route.fulfill(body=media,content_type='audio/wav',headers={'Content-Length':str(len(media))}))
 page.goto('http://127.0.0.1:8765/')
 result=page.evaluate('''code=>new Promise(resolve=>{let worker=new Worker(URL.createObjectURL(new Blob([code],{type:'text/javascript'})),{type:'module'});let logs=[];worker.onmessage=({data})=>{if(data.log)logs.push(data.log);if(data.result||data.error){worker.terminate();resolve({...data,logs});}};worker.onerror=e=>resolve({error:e.message,logs});})''',worker)
 print(json.dumps(result,ensure_ascii=False));assert 'error'not in result,result.get('error')
 assert result['result']['bytes']==len(media)
 assert result['result']['version']=='2026.10.26'
 browser.close()
