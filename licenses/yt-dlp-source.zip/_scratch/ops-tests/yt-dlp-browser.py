"""Actual UI -> yt-dlp WASM -> download bytes -> IndexedDB reload.

Only the known input media resource is intercepted; extraction is never mocked.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
import io, wave, json, hashlib

ROOT = Path(__file__).resolve().parents[2]
buffer = io.BytesIO()
with wave.open(buffer, 'wb') as audio:
    audio.setnchannels(1); audio.setsampwidth(2); audio.setframerate(8000)
    audio.writeframes(b'\0\0' * 8000)
media = buffer.getvalue()
with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(accept_downloads=True)
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.route('**/wave-fixture.wav', lambda route: route.fulfill(
        body=media, content_type='audio/wav', headers={'Content-Length': str(len(media))}))
    page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
    page.get_by_role('textbox', name='媒体链接', exact=True).fill('http://127.0.0.1:8765/wave-fixture.wav')
    page.get_by_role('button', name='解析', exact=True).click(timeout=3000)
    download = page.get_by_role('button', name='download 下载', exact=True)
    expect(download).to_be_visible(timeout=120000)
    download.click()
    save = page.get_by_role('button', name='保存 wave-fixture.wav', exact=True)
    expect(save).to_be_visible(timeout=30000)
    page.reload()
    expect(page.get_by_role('textbox', name='媒体链接', exact=True)).to_have_value('http://127.0.0.1:8765/wave-fixture.wav')
    expect(page.get_by_role('tab', name='下载任务', exact=True)).to_have_attribute('aria-selected','true')
    page.get_by_role('tab', name='下载任务').click()
    expect(save).to_be_visible()
    with page.expect_download() as info:
        save.click()
    data = info.value.path().read_bytes()
    assert data == media
    page.get_by_role('button', name='支持能力', exact=True).click()
    expect(page.get_by_role('searchbox', name='搜索能力', exact=True)).to_be_visible()
    expect(page.get_by_role('tabpanel', name='能力与解析器').locator('.ant-table-row:visible').first).to_be_visible(timeout=120000)
    assert not errors, errors
    page.get_by_role('tab', name='解析结果', exact=True).click()
    large = media[:44] + b'\0' * (34 * 1024 * 1024)
    page.route('**/large-fixture.wav', lambda route: route.fulfill(body=large, content_type='audio/wav'))
    page.get_by_role('textbox', name='媒体链接', exact=True).fill('http://127.0.0.1:8765/large-fixture.wav')
    page.get_by_role('button', name='解析', exact=True).click()
    expect(page.get_by_text('large-fixture', exact=True)).to_be_visible(timeout=30000)
    page.get_by_role('button', name='setting 设置', exact=True).click()
    page.get_by_role('tab', name='高级', exact=True).click()
    page.get_by_role('textbox', name='命令参数', exact=True).fill('--format best --output "%(title)s-命令.%(ext)s"')
    page.get_by_role('button', name='Close', exact=True).click()
    page.get_by_role('textbox', name='媒体链接', exact=True).fill('http://127.0.0.1:8765/wave-fixture.wav')
    page.get_by_role('button', name='解析', exact=True).click()
    expect(page.get_by_text('wave-fixture', exact=True)).to_be_visible(timeout=30000)
    assert page.get_by_role('alert').count()==0, page.locator('body').inner_text()
    page.get_by_role('button', name='setting 设置', exact=True).click()
    page.get_by_role('tab', name='账户', exact=True).click()
    page.get_by_role('textbox', name='用户名', exact=True).fill('private-username')
    page.get_by_role('textbox', name='密码', exact=True).fill('private-password')
    page.get_by_role('button', name='Close', exact=True).click()
    assert 'private-'not in page.evaluate('sessionStorage.getItem("pocket-yt-dlp-view-v1")')
    page.reload()
    page.get_by_role('button', name='setting 设置', exact=True).click()
    page.get_by_role('tab', name='账户', exact=True).click()
    expect(page.get_by_role('textbox', name='用户名', exact=True)).to_have_value('')
    print(json.dumps({'wasm_extraction': True, 'cached_reload_download': len(data),
                      'sha256': hashlib.sha256(data).hexdigest(), 'errors': errors}))
    browser.close()
