from playwright.sync_api import sync_playwright,expect
import json
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 for w,h in [(1920,1080),(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
  page.set_viewport_size({'width':w,'height':h})
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h)
  page.get_by_role('button',name='setting 设置',exact=True).click()
  expect(page.get_by_role('combobox',name='优先格式',exact=True)).to_be_visible()
  for name in ['账户','高级','常规']:page.get_by_role('tab',name=name,exact=True).click()
  page.get_by_role('button',name='Close',exact=True).click()
  page.get_by_role('textbox',name='媒体链接',exact=True).fill('javascript:alert(1)')
  page.get_by_role('button',name='解析',exact=True).click()
  expect(page.get_by_role('alert')).to_be_visible()
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h,'error')
  page.get_by_role('alert').get_by_role('button',name='close',exact=True).click()
 assert not errors,errors
 page.set_viewport_size({'width':1440,'height':900});page.screenshot(path='.superpowers/yt-dlp-desktop.png')
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='.superpowers/yt-dlp-mobile.png')
 print(json.dumps({'viewports':6,'settings_and_error_states':True,'errors':errors}));b.close()
