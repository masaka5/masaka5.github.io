"""Compare native engine reachability with actual browser failures."""
from pathlib import Path
import sys,concurrent.futures,json,time,os
wheel=next((Path(__file__).resolve().parents[2]/'toolbox-site/tools/yt-dlp/runtime').glob('*.whl'));sys.path.insert(0,str(wheel))
import yt_dlp
cases=[('YouTube','https://www.youtube.com/watch?v=jNQXAC9IVRw'),('YouTube2','https://www.youtube.com/watch?v=aqz-KE-bpKQ'),('Dailymotion','https://www.dailymotion.com/video/x84sh87'),('Vimeo','https://player.vimeo.com/video/76979871')]
def run(pair):
 name,url=pair;logs=[];began=time.monotonic()
 class Logger:
  def debug(self,s):pass
  def warning(self,s):logs.append(s)
  def error(self,s):logs.append(s)
 try:
  with yt_dlp.YoutubeDL({'skip_download':True,'noplaylist':True,'socket_timeout':12,'retries':0,'extractor_retries':0,'logger':Logger(),'cachedir':False})as y:
   info=y.extract_info(url,download=False)
   return{'site':name,'parsed':True,'title':info.get('title'),'formats':len(info.get('formats',[])),'logs':logs,'seconds':round(time.monotonic()-began,1)}
 except Exception as e:return{'site':name,'parsed':False,'error':str(e),'logs':logs,'seconds':round(time.monotonic()-began,1)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for row in pool.map(run,cases):print(json.dumps(row,ensure_ascii=False),flush=True)
