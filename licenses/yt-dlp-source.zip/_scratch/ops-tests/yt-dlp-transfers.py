"""Real HTTP Range, interrupted/reloaded IDB, fragment/AES and corruption checks."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import threading,time,json

ROOT=Path(__file__).resolve().parents[2]
data=bytes(range(256))*8192
requests=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  start=int((self.headers.get('Range')or'bytes=0-').split('=')[1].split('-')[0])
  requests.append([self.path,start]);ignored=self.path=='/ignore'
  if self.path=='/retry'and sum(path=='/retry'for path,_ in requests)==1:
   self.send_response(503);self.send_header('Access-Control-Allow-Origin','*');self.send_header('Content-Length','0');self.end_headers();return
  if ignored:start=0
  body=data[start:];self.send_response(206 if start else 200)
  self.send_header('Access-Control-Allow-Origin','*');self.send_header('Access-Control-Expose-Headers','Content-Range, ETag');self.send_header('Content-Length',str(len(body)));self.send_header('ETag','"fixture-v1"')
  if start:self.send_header('Content-Range',f'bytes {start}-{len(data)-1}/{len(data)}')
  self.end_headers()
  try:
   for offset in range(0,len(body),65536):self.wfile.write(body[offset:offset+65536]);self.wfile.flush();time.sleep(.015)
  except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):pass
 def do_OPTIONS(self):
  self.send_response(204);self.send_header('Access-Control-Allow-Origin','*');self.send_header('Access-Control-Allow-Headers','Range, If-Range');self.end_headers()

server=ThreadingHTTPServer(('127.0.0.1',8779),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright()as p:
  browser=p.chromium.launch();page=browser.new_page()
  def module(route):
   filename=route.request.url.rsplit('/',1)[-1]
   route.fulfill(body=(ROOT/'_scratch/yt-dlp-integration/src'/filename).read_bytes(),content_type='text/javascript')
  page.route('**/transfer-test/*.mjs',module)
  page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
  first=page.evaluate('''async()=>{
   const {createJob,transfer}=await import('/transfer-test/download.mjs');const {saveJob}=await import('/transfer-test/storage.mjs');
   const job=createJob('http://127.0.0.1:8779/data','resume.bin');await saveJob(job);const controller=new AbortController();
   await transfer(job,{signal:controller.signal,onProgress:j=>{if(j.received>0)controller.abort();}});
   return {id:job.id,state:job.state,received:job.received};}''')
  assert first['state']=='paused' and 0<first['received']<len(data),first
  page.reload()
  result=page.evaluate('''async id=>{
   const {transfer}=await import('/transfer-test/download.mjs');const {listJobs,getDownload}=await import('/transfer-test/storage.mjs');
   const job=(await listJobs()).find(j=>j.id===id);await transfer(job);
   const {blob}=await getDownload(id),bytes=new Uint8Array(await blob.arrayBuffer());
   return {state:job.state,length:bytes.length,valid:bytes.every((b,i)=>b===i%256)};}''',first['id'])
  assert result=={'state':'complete','length':len(data),'valid':True},result
  assert any(offset==first['received']for path,offset in requests if path=='/data'),requests
  invalid=page.evaluate('''async id=>{
   const {transfer}=await import('/transfer-test/download.mjs');const {listJobs}=await import('/transfer-test/storage.mjs');
   const job=(await listJobs()).find(j=>j.id===id);job.url='http://127.0.0.1:8779/ignore';job.state='paused';job.total=0;
   try{await transfer(job);return null;}catch(error){return {error:error.message,received:job.received};}}''',first['id'])
  assert '断点' in invalid['error']and invalid['received']==len(data),invalid
  fragments=page.evaluate('''async()=>{
   const {createJob,transfer}=await import('/transfer-test/download.mjs');const {getDownload}=await import('/transfer-test/storage.mjs');
   const job=createJob('http://127.0.0.1:8779/data','fragments.bin',{fragments:[{url:'http://127.0.0.1:8779/data'},{url:'http://127.0.0.1:8779/data'}]});
   const c=new AbortController();await transfer(job,{signal:c.signal,onProgress:j=>{if(j.nextFragment===1)c.abort();}});
   const paused={state:job.state,next:job.nextFragment,received:job.received};await transfer(job);
   const {blob}=await getDownload(job.id),b=new Uint8Array(await blob.arrayBuffer());
   return {paused,state:job.state,length:b.length,valid:b.every((v,i)=>v===i%256)};}''')
  assert fragments['paused']=={'state':'paused','next':1,'received':len(data)},fragments
  assert fragments['state']=='complete'and fragments['length']==2*len(data)and fragments['valid'],fragments
  encrypted=page.evaluate('''async()=>{
   const {createJob,transfer}=await import('/transfer-test/download.mjs');const {getDownload}=await import('/transfer-test/storage.mjs');
   const raw=new Uint8Array(16).fill(7),iv=new Uint8Array(16);iv[15]=1;
   const key=await crypto.subtle.importKey('raw',raw,'AES-CBC',false,['encrypt']);
   const plain=new TextEncoder().encode('中文 AES HLS segment verified');const cipher=new Uint8Array(await crypto.subtle.encrypt({name:'AES-CBC',iv},key,plain));
   window._encryptedTest={key:Array.from(raw),data:Array.from(cipher)};return Array.from(plain);
  }''')
  fixture=page.evaluate('window._encryptedTest')
  page.route('**/encrypted-key',lambda r:r.fulfill(body=bytes(fixture['key'])))
  page.route('**/encrypted-data',lambda r:r.fulfill(body=bytes(fixture['data'])))
  decrypted=page.evaluate('''async()=>{
   const {createJob,transfer}=await import('/transfer-test/download.mjs');const {getDownload}=await import('/transfer-test/storage.mjs');
   const base=location.origin,job=createJob(base+'/encrypted-data','encrypted.ts',{fragments:[{url:base+'/encrypted-data',key:{url:base+'/encrypted-key',iv:'00000000000000000000000000000001'}}]});
   await transfer(job);return Array.from(new Uint8Array(await(await getDownload(job.id)).blob.arrayBuffer()));}''')
  assert decrypted==encrypted
  retry=page.evaluate('''async()=>{
   const {createJob,transfer}=await import('/transfer-test/download.mjs');
   const job=createJob('http://127.0.0.1:8779/retry','retry.bin',{retries:2});await transfer(job);return {state:job.state,bytes:job.received};}''')
  assert retry=={'state':'complete','bytes':len(data)},retry
  print(json.dumps({'resume':result,'range_rejection':invalid,'fragments':fragments,'request_count':len(requests)}))
  browser.close()
finally:server.shutdown();server.server_close()
