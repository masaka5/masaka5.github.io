"""Real browser CORS request -> deployed relay -> upstream response, no network mocks."""
from playwright.sync_api import sync_playwright,expect
import json
with sync_playwright() as p:
 b=p.chromium.launch();page=b.new_page(viewport={'width':390,'height':844});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/tools/yt-dlp/')
 requests=[];page.on('request',lambda r:requests.append(r.url) if 'pocket-toolbox-media.pages.dev/fetch' in r.url else None)
 page.get_by_role('textbox',name='媒体链接',exact=True).fill('https://www.bilibili.com/video/BV1bH4B6dEnW/')
 page.get_by_role('button',name='解析',exact=True).click()
 page.wait_for_function("document.querySelector('.ant-alert-error') || document.querySelector('.ant-table-row')",timeout=120000)
 text=page.locator('body').inner_text()
 assert requests,'extractor did not use relay'
 assert '站点拒绝了访问' in text or page.locator('.ant-table-row').count(),text
 assert '站点未开放跨域访问' not in text,text
 mode=page.get_by_role('combobox',name='连接方式',exact=True)
 assert mode.is_visible()
 boxes=page.locator('.download-input,.download-content').evaluate_all('(els)=>els.map(e=>e.getBoundingClientRect().toJSON())')
 assert boxes[0]['bottom']<=boxes[1]['top'],boxes
 assert not errors,errors
 print(json.dumps({'relay_requests':len(requests),'parsed':bool(page.locator('.ant-table-row').count()),'upstream_412_reported':'站点拒绝了访问' in text,'errors':errors}));b.close()
