"""Rebuild unique source/runtime manifests; never mutates shared sources.json."""
from pathlib import Path
import hashlib,json,zipfile,os
PROJECT=Path(__file__).resolve().parent;ROOT=PROJECT.parents[1];SITE=ROOT/'toolbox-site';LICENSES=SITE/'licenses/media-player';LICENSES.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
notices=[];dependencies=[]
for package in sorted((PROJECT/'node_modules').glob('*/package.json'))+sorted((PROJECT/'node_modules').glob('@*/*/package.json')):
 info=json.loads(package.read_text(encoding='utf8'));texts=[]
 for item in sorted(package.parent.iterdir()):
  if item.is_file()and item.name.lower().startswith(('license','licence','notice','copying')):texts.append((item.name,item.read_bytes()))
 dependencies.append({'name':info.get('name'),'version':info.get('version'),'license':info.get('license'),'notices':[{'file':name,'sha256':sha(data)}for name,data in texts]})
 for name,data in texts:notices.append('\n===== '+str(info.get('name'))+'@'+str(info.get('version'))+' / '+name+' =====\n'+data.decode('utf8',errors='replace'))
(LICENSES/'THIRD-PARTY-NOTICES.txt').write_text('\n'.join(notices),encoding='utf8')
(LICENSES/'dependencies.json').write_text(json.dumps(dependencies,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(LICENSES/'integration-MIT.txt').write_bytes((PROJECT/'LICENSE').read_bytes())
runtime=SITE/'tools/media-player';entries=[]
for p in sorted(runtime.rglob('*')):
 if p.is_file()and p.name!='manifest.json':entries.append({'file':p.relative_to(runtime).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
shared=[]
for name in ['ffmpeg-core.js','ffmpeg-core.wasm']:
 p=SITE/'tools/studio/runtime/ffmpeg'/name;shared.append({'file':'../studio/runtime/ffmpeg/'+name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'package':'@ffmpeg/core@0.12.9'})
(runtime/'manifest.json').write_text(json.dumps({'product':'媒体播放器','engine':'native HTMLMediaElement + shared FFmpeg WASM (not libVLC)','files':entries,'shared':shared},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
source_entry={'project':'media-player-browser','version':'1.0.0','license':'MIT integration; dependency licenses retained; shared @ffmpeg/core 0.12.9 GPL-2.0-or-later','modified':True,'source_archive':'media-player-source.zip','source_manifest':'media-player-source-manifest.json','runtime_manifest':'tools/media-player/manifest.json','notices':'media-player/THIRD-PARTY-NOTICES.txt','reuses':['tools/studio/runtime/ffmpeg'],'engine':'Native HTMLMediaElement and FFmpeg WASM; no libVLC binary','upstreams':['https://github.com/ffmpegwasm/ffmpeg.wasm/tree/v0.12.15','https://www.npmjs.com/package/@ffmpeg/core/v/0.12.9','https://github.com/facebook/react','https://github.com/ant-design/ant-design']}
(LICENSES/'source-entry.json').write_text(json.dumps(source_entry,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
archive=SITE/'licenses/media-player-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for directory,dirs,files in os.walk(PROJECT):
  dirs[:]=[d for d in dirs if d not in {'node_modules','__pycache__'}]
  for name in sorted(files):
   p=Path(directory)/name;rel=p.relative_to(PROJECT)
   if name.endswith('.bundle.mjs')or name in {'engine.bundle.mjs'}:continue
   if rel.parts[:2]==('test','artifacts')and name!='results.json':continue
   z.write(p,'_scratch/media-player-integration/'+rel.as_posix())
 for p in sorted(LICENSES.iterdir()):
  if p.is_file():z.write(p,'toolbox-site/licenses/media-player/'+p.name)
 z.write(runtime/'manifest.json','toolbox-site/tools/media-player/manifest.json')
with zipfile.ZipFile(archive)as z:files=[{'path':name,'bytes':len(z.read(name)),'sha256':sha(z.read(name))}for name in sorted(z.namelist())]
manifest={'sourceArchive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'files':files,'sharedRuntime':shared}
(SITE/'licenses/media-player-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'sourceBytes':manifest['archiveBytes'],'sourceSHA256':manifest['archiveSha256'],'runtimeBytes':sum(e['bytes']for e in entries),'runtimeFiles':len(entries),'dependencies':len(dependencies)}))
