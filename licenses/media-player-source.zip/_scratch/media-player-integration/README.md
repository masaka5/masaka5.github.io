# 媒体播放器

静态、中文 React 19.3.1 / Ant Design 5.29.3 本地媒体播放器。浏览器支持的格式通过 HTMLVideoElement 原生播放。无法原生播放时，用户可显式启动共享 FFmpeg WASM 兼容转换。此项目是浏览器播放器适配，不是 libVLC 或完整桌面 VLC；未分发来源不可确认的 VLC.js 演示二进制。

## 构建与测试

Node.js 22+、Python 3（浏览器测试需 Playwright Chromium）。在项目目录执行 `npm ci --no-audit --no-fund`、`npm test`、`npm run build`。构建输出至 `../../toolbox-site/tools/media-player`。保留同站点的 `tools/studio/runtime/ffmpeg/ffmpeg-core.js`、`ffmpeg-core.wasm`；不复制第二份 WASM。

实际浏览器验证：工作区根目录运行 `python -m http.server 8777 --bind 127.0.0.1`，项目目录运行 `node test/build-harness.mjs` 后 `python test/browser.py`。测试通过同一个实际 FFmpeg WASM 生成 MPEG-4/PCM AVI，再经播放器转换 H.264/AAC MP4、原生播放及独立重新解码，测试 WAV、SRT、缓存、取消重试、六个视口。

## 功能和边界

本地多文件/文件夹列表、移除/排序/前后切换、进度/跳转/倍速/音量/静音/循环/随机、SRT/VTT 外部字幕、浏览器暴露的音轨接口、截图、媒体信息、受支持浏览器的全屏及画中画。键盘：空格播放暂停、左右跳转 5 秒、上下调整音量、M 静音、F 全屏；输入控件内不触发。

输出 MP4（H.264/AAC）、WebM（VP8/Opus）、MP3、WAV。转换单文件最多 192 MiB，已知媒体时长超过 600 秒拒绝转换，未知时长最多处理前 600 秒；输入视频最大边长 4096、最多 8,388,608 像素，最大输出尺寸 1280×720，单任务 180 秒超时。长宽按比例缩放（小视频也可能上采样）。原生播放不受转换文件上限限制。Worker 串行，取消会终止 Worker；下一任务重新创建。任务结束清理虚拟文件，替换/移除/清空释放媒体及字幕 URL，页面销毁释放 Worker/监听器。浏览器内存、编解码器、硬件、系统版本仍会限制支持；未承诺所有格式或桌面 VLC 的网络协议、DRM、直播与插件。

IndexedDB 保存真实 File/Blob 字节、列表、选择、设置、播放位置、字幕和完成的转换结果。最多 200 个项目、累计 64 MiB（媒体、字幕和结果共享）、7 天有效；超限条目不缓存，当前仍可播放。仅保留最新会话，写入串行，清空写入空会话；水合前的新操作有修订防护。恢复默认暂停，不自动播放或重新转换。存储禁用/配额失败不阻止当前操作。关闭页面时由浏览器处理已提交的 IndexedDB 写入；立即关闭浏览器可能中止尚未提交的最后一次写入。

## 引擎与许可

前端适配代码 MIT；各依赖保留原许可。`@ffmpeg/ffmpeg` 0.12.15（MIT）仅为 Worker 包装层。共享 `@ffmpeg/core` 0.12.9（GPL-2.0-or-later，依赖编解码器也各自授权）由现有 toolbox studio 提供，来源为 BrowserSnip 锁定 npm 包；其源码材料/许可由站点共享依赖包提供，不重复打包 32 MB 二进制。本项目独立依赖原许可、依赖锁、运行时哈希及复现源码包在 `licenses/media-player/`、`licenses/media-player-source.zip`。详见实际 source entry / SHA manifest。

所有用户文件仅在本浏览器内处理，不上传服务器。
