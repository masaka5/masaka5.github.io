import {build} from 'esbuild';
await build({entryPoints:['test/harness.mjs'],bundle:true,format:'esm',outfile:'test/harness.bundle.mjs'});
