from pathlib import Path
from playwright.sync_api import sync_playwright,expect
import json,io
from PIL import Image
root=Path(__file__).resolve().parents[3]
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8777/toolbox-site/tools/media-player/')
 page.evaluate("async()=>{window.harness=await import('/_scratch/media-player-integration/test/harness.bundle.mjs')}")
 matrix={}
 for extension in ['mov','webm','m4v','avi','mkv']:
  raw=bytes(page.evaluate('(extension)=>harness.containerFixture(extension)',extension))
  page.locator('input[type=file]').first.set_input_files({'name':'sample.'+extension,'mimeType':'application/octet-stream','buffer':raw})
  page.locator('.playlist-select').last.click()
  page.get_by_role('button',name='兼容预览',exact=True).click()
  expect(page.get_by_role('status')).to_contain_text('已转换为兼容预览',timeout=120000)
  page.get_by_role('button',name='播放',exact=True).click();page.wait_for_function('document.querySelector("video").currentTime>.2',timeout=20000)
  page.get_by_role('button',name='暂停',exact=True).click()
  with page.expect_download()as shot:page.get_by_role('button',name='截图',exact=True).click()
  im=Image.open(io.BytesIO(shot.value.path().read_bytes()));assert im.size==(1280,720)
  with page.expect_download()as download:page.get_by_role('button').filter(has_text='保存结果').click()
  data=download.value.path().read_bytes();result=page.evaluate('(bytes)=>harness.redecode(bytes)',list(data));assert result['code']==0,result
  matrix[extension]={'input_bytes':len(raw),'mp4_bytes':len(data),'played':True,'screenshot':im.size}
 page.reload();page.wait_for_function('document.querySelector("video").videoWidth===1280');assert page.evaluate('document.querySelector("video").paused')
 assert not errors,errors
 print(json.dumps({'containers':matrix,'cached_preview':True,'errors':errors}));b.close()
