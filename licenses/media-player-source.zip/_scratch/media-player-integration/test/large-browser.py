"""Real file beyond both old conversion limits, plus durable >64 MiB cache."""
from pathlib import Path
import json,wave
from playwright.sync_api import sync_playwright
HERE=Path(__file__).resolve().parent
fixture=HERE/'artifacts/large.wav';fixture.parent.mkdir(exist_ok=True)
with wave.open(str(fixture),'wb')as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000)
 for _ in range(201):w.writeframesraw(bytes(1024*1024))
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page()
 page.goto('http://127.0.0.1:8777/toolbox-site/tools/media-player/')
 page.evaluate('''async()=>{window.h=await import('/_scratch/media-player-integration/test/harness.bundle.mjs');window.actualFile=await(await fetch('/_scratch/media-player-integration/test/artifacts/large.wav')).blob();window.done=null;h.transform(actualFile,'mp3').then(async result=>{window.done={size:result.size,decode:await h.redecode(Array.from(new Uint8Array(await result.arrayBuffer())))}},e=>{done={error:String(e)}})}''')
 page.wait_for_function('done!==null',timeout=180000)
 converted=page.evaluate('done');assert 'error'not in converted,converted;assert converted['decode']['code']==0,converted
 saved=page.evaluate('''async()=>{const c=await import('/_scratch/media-player-integration/src/cache.mjs'),k=await import('/_scratch/media-player-integration/src/core.mjs');const file=new Blob(Array(80).fill(new Uint8Array(1048576)));await c.writeSession(k.cacheSnapshot([{id:'large',name:'large.bin',file}],'large',{}));return(await c.readSession()).items[0].file.size;}''')
 assert saved==80*1024*1024
 page.reload();assert page.evaluate('''async()=>{const c=await import('/_scratch/media-player-integration/src/cache.mjs');const s=await c.readSession();return s.items[0].file.size}''')==saved
 b.close()
 print(json.dumps({'inputBytes':fixture.stat().st_size,'inputSeconds':201*1024*1024/192000,'convertedBytes':converted['size'],'independentlyDecoded':True,'cacheBytesRestored':saved}))
