from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page();page.goto('http://127.0.0.1:8777/toolbox-site/tools/media-player/');print(page.evaluate("async bytes=>{let h=await import('/_scratch/media-player-integration/test/harness.bundle.mjs');return h.probeDebug(bytes)}",list((Path(__file__).parent/'artifacts/fixture.avi').read_bytes())));b.close()
