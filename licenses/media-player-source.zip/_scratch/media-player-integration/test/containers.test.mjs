import test from 'node:test';import assert from 'node:assert/strict';
const core=await import('../src/core.mjs');
test('common video containers have explicit browser MIME hints',()=>{
 assert.equal(typeof core.mediaSource,'function');
 for(const [extension,type]of Object.entries({mov:'video/quicktime',webm:'video/webm',m4v:'video/mp4',avi:'video/x-msvideo',mkv:'video/x-matroska'})){
  const file=new File(['real bytes'],'sample.'+extension,{type:'application/octet-stream'}),source=core.mediaSource(file);
  assert.equal(source.type,type);assert.equal(source.size,file.size);
 }
});
test('compatible video output uses even 4:2:0 frames for browser playback',()=>{
 const args=core.conversionArgs('camera.mov','mp4',3);
 assert.equal(args[args.indexOf('-pix_fmt')+1],'yuv420p');
 assert.ok(args[args.indexOf('-vf')+1].includes('force_divisible_by=2'));
});
