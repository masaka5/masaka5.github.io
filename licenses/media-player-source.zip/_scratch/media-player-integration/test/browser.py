from pathlib import Path
from playwright.sync_api import sync_playwright, expect
import json, hashlib, io, wave, math, struct
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent/'artifacts';OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8777/toolbox-site/tools/media-player/'
with sync_playwright() as p:
 browser=p.chromium.launch()
 context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':900})
 page=context.new_page(); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('''window.__urls=new Set();const c=URL.createObjectURL.bind(URL),r=URL.revokeObjectURL.bind(URL);URL.createObjectURL=b=>{const u=c(b);__urls.add(u);return u};URL.revokeObjectURL=u=>{__urls.delete(u);r(u)};''')
 page.goto(URL)
 page.evaluate("async()=>{window.harness=await import('/_scratch/media-player-integration/test/harness.bundle.mjs')}")
 raw=bytes(page.evaluate('()=>harness.fixture()'));(OUT/'fixture.avi').write_bytes(raw)
 buf=io.BytesIO()
 with wave.open(buf,'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(b''.join(struct.pack('<h',int(math.sin(i*2*math.pi*440/16000)*12000))for i in range(64000)))
 wav=buf.getvalue();(OUT/'fixture.wav').write_bytes(wav)
 page.locator('input[type=file]').nth(0).set_input_files([{'name':'声音.wav','mimeType':'audio/wav','buffer':wav},{'name':'测试.avi','mimeType':'video/x-msvideo','buffer':raw}])
 page.wait_for_function('document.querySelector("video").duration===4')
 page.get_by_role('button',name='播放',exact=True).click();page.wait_for_function('document.querySelector("video").currentTime>0.3')
 page.get_by_role('button',name='暂停',exact=True).click()
 page.get_by_role('slider',name='播放进度',exact=True).focus();page.keyboard.press('End');page.keyboard.press('ArrowLeft')
 page.evaluate('document.querySelector("video").currentTime=1.3')
 page.get_by_role('combobox',name='播放速度',exact=True).locator('xpath=ancestor::div[contains(@class,"ant-select")][last()]').click();page.get_by_text('1.5 倍',exact=True).click()
 assert page.evaluate('document.querySelector("video").playbackRate')==1.5
 page.locator('input[type=file]').nth(2).set_input_files({'name':'测试.srt','mimeType':'text/plain','buffer':'1\n00:00:01,000 --> 00:00:03,000\n字幕验证\n'.encode()})
 page.wait_for_function('document.querySelector("video").textTracks[0]?.cues?.length===1')
 page.evaluate('document.querySelector("video").currentTime=1.4')
 page.wait_for_function('document.querySelector("video").textTracks[0]?.activeCues?.length===1')
 page.wait_for_timeout(850);page.reload();page.wait_for_function('document.querySelector("video").currentTime>1')
 assert page.evaluate('document.querySelector("video").paused')
 assert page.evaluate('document.querySelector("video").playbackRate')==1.5
 page.get_by_role('button',name='下一个',exact=True).click()
 expect(page.get_by_role('alert')).to_contain_text('无法直接播放',timeout=15000)
 page.get_by_role('button',name='兼容预览',exact=True).click();page.locator('.task button').click(force=True,timeout=3000)
 expect(page.get_by_role('status')).to_contain_text('已取消')
 page.get_by_role('button',name='兼容预览',exact=True).click()
 expect(page.get_by_role('status')).to_contain_text('已转换为兼容预览',timeout=120000)
 page.wait_for_function('document.querySelector("video").videoWidth===1280')
 page.get_by_role('button',name='播放',exact=True).click();page.wait_for_function('document.querySelector("video").currentTime>0.5')
 page.get_by_role('button',name='暂停',exact=True).click()
 pixel=page.evaluate('''()=>{let v=document.querySelector('video'),c=document.createElement('canvas');c.width=160;c.height=90;let x=c.getContext('2d');x.drawImage(v,0,0,160,90);let d=x.getImageData(0,0,160,90).data;return Array.from(d).filter((x,i)=>i%4!==3&&x>50).length}''');assert pixel>10000,pixel
 with page.expect_download()as shot:page.get_by_role('button',name='截图',exact=True).click()
 assert shot.value.path().read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
 page.get_by_role('button',name='媒体信息',exact=True).click();expect(page.locator('.ant-modal')).to_contain_text('原始媒体信息');page.locator('.ant-modal-footer button').click();expect(page.locator('.ant-modal-wrap')).not_to_be_visible()
 with page.expect_download() as download:page.get_by_role('button').filter(has_text='保存结果').click()
 output=download.value.path().read_bytes();(OUT/'converted.mp4').write_bytes(output)
 page.evaluate("async()=>{window.harness=await import('/_scratch/media-player-integration/test/harness.bundle.mjs')}")
 redecode=page.evaluate('(bytes)=>harness.redecode(bytes)',list(output));assert redecode['code']==0,redecode
 formats={}
 for fmt,data in [('mp3',wav),('wav',wav),('webm',raw)]:
  encoded=bytes(page.evaluate('''async({bytes,format})=>Array.from(new Uint8Array(await(await harness.transform(new File([new Uint8Array(bytes)],'source.bin'),format,{duration:4})).arrayBuffer()))''',{'bytes':list(data),'format':fmt}))
  decoded=page.evaluate('(bytes)=>harness.redecode(bytes)',list(encoded));assert decoded['code']==0,decoded
  formats[fmt]={'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'decode':decoded};(OUT/('converted.'+fmt)).write_bytes(encoded)
 page.wait_for_timeout(1000);page.reload();page.wait_for_function('document.querySelector("video").videoWidth===1280');assert page.evaluate('document.querySelector("video").paused')
 with page.expect_download() as download:page.get_by_role('button').filter(has_text='保存结果').click()
 assert download.value.path().read_bytes()==output
 page.goto('http://127.0.0.1:8777/toolbox-site/index.html');page.go_back();page.wait_for_function('document.querySelector("video").videoWidth===1280');assert page.evaluate('document.querySelector("video").paused')
 page.get_by_role('button',name='上移 测试.avi',exact=True).click();assert page.locator('.playlist-select').first.inner_text().startswith('1\n测试.avi')
 page.get_by_role('button',name='移除 声音.wav',exact=True).click();assert page.locator('.playlist-item').count()==1
 viewports=[(1440,900),(1280,720),(1024,768),(768,1024),(390,844),(390,400)];layout=[]
 for width,height in viewports:
  page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(200)
  result=page.evaluate('''()=>({w:innerWidth,h:innerHeight,scrollW:document.documentElement.scrollWidth,scrollH:document.documentElement.scrollHeight,controls:Array.from(document.querySelectorAll('.play-controls button')).map(x=>({x:x.getBoundingClientRect().x,r:x.getBoundingClientRect().right,b:x.getBoundingClientRect().bottom}))})''')
  assert result['scrollW']<=width and result['scrollH']<=height,result
  assert all(x['x']>=0 and x['r']<=width and x['b']<=height for x in result['controls']),result
  layout.append(result);page.screenshot(path=str(OUT/f'player-{width}-{height}.png'))
 page.evaluate('document.querySelector("video").currentTime=0');page.get_by_role('button',name='播放',exact=True).click();page.wait_for_function('document.querySelector("video").currentTime>0.2');page.get_by_role('button',name='暂停',exact=True).click();page.get_by_role('button',name='静音',exact=True).click();assert page.evaluate('document.querySelector("video").muted')
 page.get_by_role('button',name='清空列表',exact=True).click();page.wait_for_timeout(850)
 assert page.evaluate('__urls.size')==0,page.evaluate('Array.from(__urls)')
 page.reload();expect(page.get_by_text('列表为空',exact=True)).to_be_visible();assert page.get_by_role('button',name='保存结果',exact=True).count()==0
 # Disabled IndexedDB is usable, hydration cannot erase a newly selected file.
 disabled=context.new_page();disabled.add_init_script('indexedDB.open=()=>{throw Error("storage disabled")}');disabled.goto(URL);disabled.locator('input[type=file]').nth(0).set_input_files({'name':'无缓存.wav','mimeType':'audio/wav','buffer':wav});disabled.wait_for_function('document.querySelector("video").duration===4');disabled.get_by_role('button',name='播放',exact=True).click();disabled.wait_for_function('document.querySelector("video").currentTime>0.1');disabled.close()
 delayed=context.new_page();delayed.add_init_script('''const open=indexedDB.open.bind(indexedDB);indexedDB.open=(...args)=>{let actual=open(...args),fake={result:null,error:null,onupgradeneeded:null,onsuccess:null,onerror:null};actual.onupgradeneeded=e=>{fake.result=actual.result;fake.onupgradeneeded?.(e)};actual.onsuccess=e=>{fake.result=actual.result;setTimeout(()=>fake.onsuccess?.(e),1000)};actual.onerror=e=>{fake.error=actual.error;fake.onerror?.(e)};return fake};''');delayed.goto(URL);delayed.locator('input[type=file]').nth(0).set_input_files({'name':'新的声音.wav','mimeType':'audio/wav','buffer':wav});delayed.wait_for_timeout(1500);assert delayed.locator('.playlist-item').count()==1;assert '新的声音.wav' in delayed.locator('.playlist-select').inner_text();delayed.close()
 large=context.new_page();large.goto(URL);large.evaluate('''()=>{const f=new File([new Uint8Array(65*1024*1024)],'large-local.bin');const d=new DataTransfer();d.items.add(f);const input=document.querySelector('input[type=file]');input.files=d.files;input.dispatchEvent(new Event('change',{bubbles:true}))}''');expect(large.get_by_text('部分大文件未缓存 · 当前仍可播放',exact=True)).to_be_visible(timeout=15000);large.reload();expect(large.get_by_text('列表为空',exact=True)).to_be_visible();large.close()
 assert not errors,errors
 result={'nativeWavBytes':len(wav),'unsupportedAviBytes':len(raw),'aviSHA256':hashlib.sha256(raw).hexdigest(),'mp4Bytes':len(output),'mp4SHA256':hashlib.sha256(output).hexdigest(),'redecode':redecode,'otherFormats':formats,'videoNonblackComponents':pixel,'viewports':layout,'pageErrors':errors}
 (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result,ensure_ascii=False));browser.close()
