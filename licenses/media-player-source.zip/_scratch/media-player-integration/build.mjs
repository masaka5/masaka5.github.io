import {build} from 'esbuild';
import {mkdir,copyFile} from 'node:fs/promises';
import path from 'node:path';
const site=path.resolve('../../toolbox-site/tools/media-player');
await mkdir(site+'/assets',{recursive:true});
await build({entryPoints:['src/main.jsx'],bundle:true,minify:true,target:['es2022'],format:'esm',outfile:site+'/assets/app.js',define:{'process.env.NODE_ENV':'"production"'},legalComments:'eof'});
await build({entryPoints:['node_modules/@ffmpeg/ffmpeg/dist/esm/worker.js'],bundle:true,minify:true,target:['es2022'],format:'esm',outfile:site+'/assets/ffmpeg-worker.js',legalComments:'eof'});
await copyFile('index.html',site+'/index.html');
console.log('Built media player (shared FFmpeg core, no duplicate WASM)');
