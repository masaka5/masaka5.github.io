// Uses the site's audited @ffmpeg/core 0.12.9; never substitutes FFmpeg for libVLC.
import {FFmpeg} from '@ffmpeg/ffmpeg';
import {conversionArgs,MAX_INPUT_BYTES} from './core.mjs';
let engine,loading,busy=false,generation=0;
export function cancel(){generation++;engine?.terminate();engine=null;loading=null;busy=false;}
export async function transform(file,format,{duration=0,onProgress=()=>{},onLog=()=>{}}={}){
 if(busy)throw Error('请等待当前任务完成');if(file.size>MAX_INPUT_BYTES)throw Error('浏览器转换单个文件最多 192 MB');
 const args=conversionArgs('input.bin',format,duration),token=generation;busy=true;let f;
 const progress=({progress})=>onProgress(Math.min(99,Math.max(0,Math.round(progress*100))));const log=({message})=>onLog(message);
 try{if(!engine){engine=new FFmpeg();loading=engine.load({classWorkerURL:new URL('./assets/ffmpeg-worker.js',location.href).href,coreURL:new URL('../studio/runtime/ffmpeg/ffmpeg-core.js',location.href).href,wasmURL:new URL('../studio/runtime/ffmpeg/ffmpeg-core.wasm',location.href).href});}f=engine;f.on('progress',progress);f.on('log',log);await loading;if(token!==generation)throw Error('任务已取消');await f.writeFile('input.bin',new Uint8Array(await file.arrayBuffer()));if(token!==generation)throw Error('任务已取消');await f.ffprobe(['-v','error','-show_entries','format=duration:stream=codec_name,codec_type,width,height','-of','json','input.bin','-o','probe.json'],15000);const probe=JSON.parse(await f.readFile('probe.json','utf8'));if(!probe.streams?.length)throw Error('无法识别媒体信息');onLog('原始媒体信息：'+JSON.stringify(probe));if(Number(probe.format?.duration)>600)throw Error('浏览器转换最多 10 分钟');if(probe.streams?.some(s=>s.width>4096||s.height>4096||s.width*s.height>8388608))throw Error('输入视频分辨率超过浏览器处理上限（4096 边长 / 800 万像素）');if(await f.exec(args,180000)!==0)throw Error('无法转换此媒体或任务超过 3 分钟，请换一种输出格式');const data=await f.readFile('output.'+format);return new Blob([data],{type:{mp4:'video/mp4',webm:'video/webm',mp3:'audio/mpeg',wav:'audio/wav'}[format]});}
 catch(e){if(token!==generation)throw Error('任务已取消');if(!engine?.loaded)cancel();throw e instanceof Error?e:new Error(String(e));}
 finally{f?.off('progress',progress);f?.off('log',log);if(token===generation&&f?.loaded)for(const name of ['input.bin','probe.json','output.'+format])try{await f.deleteFile(name);}catch{}if(token===generation)busy=false;}
}
