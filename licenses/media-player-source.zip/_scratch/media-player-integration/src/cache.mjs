import {validateSnapshot} from './core.mjs';
const TIMEOUT=1500,TOMBSTONE='pocket-media-player-invalid-v2';
let dbPromise,active=false,pending=null,invalid=false;
function markInvalid(value){invalid=value;try{if(value)localStorage.setItem(TOMBSTONE,'1');else localStorage.removeItem(TOMBSTONE);}catch{}}
function isInvalid(){try{return invalid||localStorage.getItem(TOMBSTONE)==='1';}catch{return invalid;}}
function database(){
 if(dbPromise)return dbPromise;
 const promise=new Promise((resolve,reject)=>{let settled=false,request;const timer=setTimeout(()=>{settled=true;reject(Error('本地缓存打开超时'));},TIMEOUT);
 try{request=indexedDB.open('pocket-media-player-v1',1);}catch(e){clearTimeout(timer);reject(e);return;}
 request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('session'))request.result.createObjectStore('session');};
 request.onsuccess=()=>{if(settled){request.result.close();return;}settled=true;clearTimeout(timer);const db=request.result;db.onversionchange=()=>{db.close();dbPromise=null;};resolve(db);};request.onerror=()=>{if(settled)return;settled=true;clearTimeout(timer);reject(request.error||Error('本地缓存无法打开'));};
 });dbPromise=promise;promise.catch(()=>{if(dbPromise===promise)dbPromise=null;});return promise;
}
async function transaction(mode,operation){const db=await database();return new Promise((resolve,reject)=>{let tx,done=false,result;const finish=(error)=>{if(done)return;done=true;clearTimeout(timer);error?reject(error):resolve(result);};const timer=setTimeout(()=>{try{tx?.abort();}catch{}finish(Error('本地缓存事务超时'));},TIMEOUT);
 try{tx=db.transaction('session',mode);tx.oncomplete=()=>finish();tx.onerror=()=>finish(tx.error||Error('本地缓存事务失败'));tx.onabort=()=>finish(tx.error||Error('本地缓存事务中断'));const req=operation(tx.objectStore('session'));if(req)req.onsuccess=()=>{result=req.result;};}catch(e){try{tx?.abort();}catch{}finish(e);}
 });}
export async function readSession(){if(isInvalid())return null;try{const raw=await transaction('readonly',s=>s.get('latest'));if(isInvalid())return null;const value=validateSnapshot(raw);if(raw&&!value){markInvalid(true);try{await transaction('readwrite',s=>s.delete('latest'));}catch{}return null;}return value;}catch{return null;}}
async function replace(value){
 // Serial worker guarantees this invalidation cannot delete a newer successful write.
 try{if(!value.items?.length&&!value.output)await transaction('readwrite',s=>s.delete('latest'));else await transaction('readwrite',s=>s.put(value,'latest'));markInvalid(false);return true;}
 catch(error){markInvalid(true);try{await transaction('readwrite',s=>s.delete('latest'));}catch{}throw error;}
}
async function drain(){if(active)return;active=true;try{while(pending){const task=pending;pending=null;try{task.resolve(await replace(task.value));}catch(e){task.reject(e);}}}finally{active=false;}}
export function writeSession(value){return new Promise((resolve,reject)=>{if(pending)pending.resolve(false);pending={value,resolve,reject};void drain();});}
