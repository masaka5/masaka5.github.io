import {MAX_AGE} from './core.mjs';
let dbPromise,queue=Promise.resolve();
function database(){return dbPromise??=new Promise((resolve,reject)=>{const r=indexedDB.open('pocket-media-player-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('session');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export async function readSession(){try{const db=await database();return await new Promise(resolve=>{const r=db.transaction('session').objectStore('session').get('latest');r.onsuccess=()=>resolve(r.result&&Date.now()-r.result.savedAt<MAX_AGE?r.result:null);r.onerror=()=>resolve(null);});}catch{return null;}}
export function writeSession(value){queue=queue.catch(()=>{}).then(async()=>{const db=await database();await new Promise((resolve,reject)=>{const tx=db.transaction('session','readwrite');tx.objectStore('session').put(value,'latest');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});});return queue;}
