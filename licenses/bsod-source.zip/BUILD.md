# 蓝屏分析源码

纯静态网页，无文件上传、无符号请求。使用 LLVM clang 22.1.7（wasm32 目标），执行 `powershell -File _scratch/build-dump-wasm.ps1` 可重建 WASM；其他平台使用相同 clang 参数。无需 npm 依赖。将 toolbox-site 用静态 HTTP 服务运行，工具位于 tools/bsod/。Node.js 22+ 执行 `node --test _scratch/ops-tests/bsod-core.test.cjs`。浏览器测试需 Python3 + Playwright，使用 TOOLBOX_TEST_BASE 指定静态站地址。

测试转储未随包分发：rizin-testbins 仓库未声明 dmp/* 许可。自行按 REPORT 内固定链接取得 triage_x64.dmp，放入 _scratch/bsod-fixtures/；SHA256 必须为 6875e8ff013eddb9d562165067be24e2a231a8851690bb101f6597ca9534cd28。此包只包含引用的格式定义及许可，不包含用户转储。

支持 x86/x64 PAGE 文件头、已验证的 x64 type4 小型转储模块和栈内地址扫描、标准 MDMP 系统/异常/模块数据。其他内核布局仅头信息。不加载符号、不展开调用栈、不判定故障驱动。每份报告均明确是部分基础分析。64 位值保留十六进制原值；分块读取最多4MiB，累计64MiB，模块10000，地址8192。完整实现与来源限制见 _scratch/bsod-parser-report.md。
