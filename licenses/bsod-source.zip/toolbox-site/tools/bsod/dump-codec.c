/* Independent bounded decoder. Format references and licenses: _scratch/bsod-parser-report.md. */
typedef unsigned int u32; typedef unsigned long long u64; typedef unsigned char u8;
static u8 input[4194304]; static u64 out[512];
u32 buffer(void){return (u32)input;} u32 output(void){return (u32)out;}
static u32 d(u32 o){return (u32)input[o]|((u32)input[o+1]<<8)|((u32)input[o+2]<<16)|((u32)input[o+3]<<24);}
static u64 q(u32 o){return (u64)d(o)|((u64)d(o+4)<<32);}
/* 1 header; 2 triage; 3 driver64; 4 directory; 5 MDMP module; 6 exception; 7 system; 8 uint32; 9 pointer array */
u32 decode(u32 op,u32 n){for(u32 i=0;i<40;i++)out[i]=0;
 if(op==1){if(n<8)return 1;if(d(0)==0x504d444d){if(n<32)return 1;out[0]=3;out[1]=d(8);out[2]=d(12);out[3]=d(20);out[4]=d(4);return 0;}if(d(0)!=0x45474150)return 2;u32 w=d(4)==0x34365544?64:d(4)==0x504d5544?32:0;if(!w)return 2;if(n<(w==64?8192:4096))return 1;out[0]=w==64?2:1;out[1]=d(w==64?0x30:0x20);out[2]=d(8);out[3]=d(12);out[4]=d(w==64?0x38:0x28);for(u32 i=0;i<4;i++)out[5+i]=w==64?q(0x40+i*8):d(0x2c+i*4);out[9]=d(w==64?0xf98:0xf88);out[10]=q(w==64?0xfa8:0xfc0);return 0;}
 if(op==2){if(n<136)return 1;out[0]=d(4);out[1]=d(0x28);out[2]=d(0x2c);out[3]=d(0x30);out[4]=d(0x34);out[5]=d(0x38);out[6]=d(0x3c);out[7]=q(0x48);return 0;}
 if(op==3){if(n<144)return 1;out[0]=d(0);out[1]=q(0x38);out[2]=d(0x48);out[3]=d(0x88);return 0;}
 if(op==4){if(n<12)return 1;out[0]=d(0);out[1]=d(4);out[2]=d(8);return 0;}
 if(op==5){if(n<108)return 1;out[0]=q(0);out[1]=d(8);out[2]=d(16);out[3]=d(20);out[4]=d(24);out[5]=d(32);out[6]=d(36);return 0;}
 if(op==6){if(n<168)return 1;out[0]=d(8);out[1]=q(24);out[2]=d(32);if(out[2]>15)return 1;for(u32 i=0;i<out[2];i++)out[3+i]=q(40+i*8);return 0;}
 if(op==7){if(n<56)return 1;out[0]=input[0]|((u32)input[1]<<8);out[1]=d(8);out[2]=d(12);out[3]=d(16);return 0;}
 if(op==8){if(n<4)return 1;out[0]=d(0);return 0;}
 if(op==9){if(n<8||n>4096)return 1;for(u32 i=0;i<n/8;i++)out[i]=q(i*8);return 0;}return 2;
}

