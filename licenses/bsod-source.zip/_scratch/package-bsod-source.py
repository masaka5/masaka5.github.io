"""Package the reproducible decoder and only references actually used."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site';folder=SITE/'tools/bsod'
files=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(folder.iterdir())if p.is_file()and p.name!='manifest.json'and p.suffix!='.c']
(folder/'manifest.json').write_text(json.dumps({'version':'1.0.0','files':files},indent=2)+'\n',encoding='utf8')
references=[
 {'project':'kdmp-parser-format-reference','source':'https://github.com/0vercl0k/kdmp-parser/tree/fdbb9efa28ee86b050d0641140df085d48990072','revision':'fdbb9efa28ee86b050d0641140df085d48990072','license':'MIT'},
 {'project':'rizin-format-reference','source':'https://github.com/rizinorg/rizin/tree/bf509ef2df2493f11dc35becd38a0b92e295cfcc','revision':'bf509ef2df2493f11dc35becd38a0b92e295cfcc','license':'LGPL-3.0-only'},
 {'project':'windows-rs-format-reference','source':'https://github.com/microsoft/windows-rs/blob/0.58.0/crates/libs/windows/src/Windows/Win32/System/Diagnostics/Debug/mod.rs','version':'0.58.0','license':'MIT'}]
sources=SITE/'licenses/sources.json';records=json.loads(sources.read_text('utf8'))
projects={r['project']for r in references}|{'bsod-toolbox'}
records=[r for r in records if r.get('project')not in projects]
records.append({'project':'bsod-toolbox','version':'1.0.0','sourceArchive':'licenses/bsod-source.zip','changes':'Independent bounded C/WASM decoder and Chinese local-only UI; header metadata, verified x64 triage and user-mode MDMP. Reference definitions and their licenses supplied in source archive.'})
records.extend([{**r,'sourceArchive':'licenses/bsod-source.zip','changes':'Format reference only; independent parser implementation, no upstream binary bundled.'}for r in references])
sources.write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(SITE/'licenses/bsod-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(folder.iterdir()):
  if p.is_file():z.write(p,'toolbox-site/tools/bsod/'+p.name)
 for name in ['build-dump-wasm.ps1','package-bsod-source.py','bsod-parser-report.md']:
  z.write(ROOT/'_scratch'/name,'_scratch/'+name)
 for name in ['toolbox-taxonomy.cjs','tool-icon-rules.cjs','build-toolbox-catalog.cjs','build-toolbox-icons.cjs']:
  z.write(ROOT/'_scratch'/name,'_scratch/'+name)
 for name in ['catalog.test.cjs','taxonomy.test.cjs','tool-icons.test.cjs','home-categories.py']:
  z.write(ROOT/'_scratch/ops-tests'/name,'_scratch/ops-tests/'+name)
 z.write(SITE/'assets/catalog-base.js','toolbox-site/assets/catalog-base.js')
 for p in sorted((ROOT/'_scratch/ops-tests').glob('bsod*')):
  if p.is_file():z.write(p,'_scratch/ops-tests/'+p.name)
 for name in ['kdmp-parser-structs.h','LICENSE-kdmp-parser','dmp_specs.h','dmp64.c','LICENSE-rizin','LICENSE-GPL-3','windows-debug.rs','LICENSE-windows-rs']:
  z.write(ROOT/'_scratch/bsod-fixtures/source'/name,'_scratch/bsod-fixtures/source/'+name)
 z.writestr('REFERENCES.json',json.dumps(references,indent=2)+'\n')
 z.writestr('BUILD.md','''# 蓝屏分析源码

纯静态网页，无文件上传、无符号请求。使用 LLVM clang 22.1.7（wasm32 目标），执行 `powershell -File _scratch/build-dump-wasm.ps1` 可重建 WASM；其他平台使用相同 clang 参数。无需 npm 依赖。将 toolbox-site 用静态 HTTP 服务运行，工具位于 tools/bsod/。Node.js 22+ 执行 `node --test _scratch/ops-tests/bsod-core.test.cjs`。浏览器测试需 Python3 + Playwright，使用 TOOLBOX_TEST_BASE 指定静态站地址。

测试转储未随包分发：rizin-testbins 仓库未声明 dmp/* 许可。自行按 REPORT 内固定链接取得 triage_x64.dmp，放入 _scratch/bsod-fixtures/；SHA256 必须为 6875e8ff013eddb9d562165067be24e2a231a8851690bb101f6597ca9534cd28。此包只包含引用的格式定义及许可，不包含用户转储。

支持 x86/x64 PAGE 文件头、已验证的 x64 type4 小型转储模块和栈内地址扫描、标准 MDMP 系统/异常/模块数据。其他内核布局仅头信息。不加载符号、不展开调用栈、不判定故障驱动。每份报告均明确是部分基础分析。64 位值保留十六进制原值；分块读取最多4MiB，累计64MiB，模块10000，地址8192。完整实现与来源限制见 _scratch/bsod-parser-report.md。
''')
print(json.dumps({'runtime_files':len(files),'source_kb':round((SITE/'licenses/bsod-source.zip').stat().st_size/1024,1)}))
