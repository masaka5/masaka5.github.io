# BSOD parser implementer report

Status: DONE. No commits (shared dirty workspace, instructed not to commit).

## Delivered

- Real freestanding C/WASM binary decoder: parses PAGE/DUMP, PAGE/DU64, MDMP headers, MDMP directory/exception/system/module records, x64 triage descriptors and driver records. WASM is not a decorative hash. JS handles sparse Blob I/O and output formatting. No network dump upload or symbols.
- Exports async parseDump(blob,{signal,onProgress}). BigInt used end-to-end for 64-bit parameters/addresses. Returned fields follow the brief. All results explicitly complete=false because this is partial base analysis.
- PAGE/DUMP x86 and PAGE/DU64 x64/ARM64 headers yield build/machine, bugcheck+four parameters, actual FILETIME crash time. Non-x64/type4 payload layouts remain header-only with Chinese warning.
- Verified PAGE/DU64 x64 type4 triage: 0x2000 main header, 136-byte triage descriptor, driver records 0x90 bytes; base at +0x38,size+0x48,timestamp+0x88; counted UTF16 DriverNameOffset strings constrained to the descriptor string pool. Saves 151 drivers on public real fixture. Kernel module version unavailable, returns null. Saved stack scanned for aligned values matching driver ranges, source=stack-scan, never described as unwound frames. Parameter matches are source=bugcheck-parameter; no module is labeled faulty.
- Standard MDMP is explicitly kind=user; exception is never bugcheck. Decodes architecture/system, header timestamp, exception, loaded modules with version when VS_FIXEDFILEINFO signature is present, exception module address match. Other streams omitted with warning.
- Sparse reads each <=4MiB, total<=64MiB, module aggregate<=10000, directory<=4096, output addresses<=8192, string<=32KiB, fixed 4.125MiB WASM memory. File-size arithmetic checked as safe integers; uint64 module end overflow rejected. Cancellation before/after awaited reads and scanning. Worker ready handshake is posted only after handler is installed; error message payload uses message.
- Human-facing warnings/errors/formats in Chinese. Stable source/evidence enums retained.

## Validation and TDD

RED: node --test _scratch/ops-tests/bsod-core.test.cjs, before implementation: 0/5 pass, missing dump-core.js ERR_MODULE_NOT_FOUND (expected missing subsystem).

GREEN first implementation: 5/5 after fixing test's independently checked FILETIME expectation and real-fixture driver stride arithmetic. FILETIME checked in Python: 2021-02-21 01:38:22.987765; output ms precision .987Z. Initial stride guess 160 was disproved by fixture; verified correct stride 144 and timestamp+0x88.

Additional regression RED: repeated module streams test failed Missing expected rejection (aggregate could exceed per-stream count). Added aggregate bound in module creation. GREEN final: node --test _scratch/ops-tests/bsod-core.test.cjs => 9 tests,9 pass,0 fail; duration ~497ms.

Coverage: x86/x64 high-bit bugcheck parameters, real timestamp, real public 151-driver triage, stack evidence; MDMP high-bit exception/module preservation; unsupported signature versus malformed truncated input; already-aborted and mid-read cancellation; fake sparse 6GiB Blob reads under 32KiB; truncated lengths at 0,4,8,64,4096,8191,8200,10000; enormous counts/directory offsets; uint64 module overflow; 48 deterministic byte/bit mutations with bounded result/error; repeated-stream aggregate count bound. WASM compiled successfully with _scratch/build-dump-wasm.ps1, clang wasm32 -O2 -nostdlib, fixed initial=max memory 4325376.

## Sources / provenance / packaging manifest

Implementation is independently written, using format facts from these staged references. Archive ONLY these source files + corresponding licenses, not the research directory wholesale:

1. kdmp-parser revision fdbb9efa28ee86b050d0641140df085d48990072. https://github.com/0vercl0k/kdmp-parser/tree/fdbb9efa28ee86b050d0641140df085d48990072 . Staged source/kdmp-parser-structs.h + source/LICENSE-kdmp-parser. MIT (not BSD; early progress note was mistaken). Used x64 DUMP_HEADER offsets.
2. Rizin revision bf509ef2df2493f11dc35becd38a0b92e295cfcc. https://github.com/rizinorg/rizin/tree/bf509ef2df2493f11dc35becd38a0b92e295cfcc . Staged source/dmp_specs.h, source/dmp64.c + source/LICENSE-rizin. Source headers state LGPL-3.0-only. Used triage descriptor/driver/count-string layouts and cross-check parser. source/rizin-test.txt is ancillary test output reference, not needed in packaged source archive.
3. Microsoft windows-rs tag 0.58.0, https://github.com/microsoft/windows-rs/blob/0.58.0/crates/libs/windows/src/Windows/Win32/System/Diagnostics/Debug/mod.rs . Staged source/windows-debug.rs + source/LICENSE-windows-rs (MIT). Used DUMP_HEADER32 and MINIDUMP structure definitions. Archive source file and license together.

Public real sample, TEST ONLY, DO NOT DISTRIBUTE with site/source archive: _scratch/bsod-fixtures/triage_x64.dmp from https://github.com/rizinorg/rizin-testbins/blob/cf370d44492b581baad5e6864aab478868d94ab5/dmp/triage_x64.dmp . Public repo revision cf370d44492b581baad5e6864aab478868d94ab5, git blob baa17b8696682799de77763cd94bc3d744c3a374, SHA256 6875e8ff013eddb9d562165067be24e2a231a8851690bb101f6597ca9534cd28, length1444532. Repository has no declared license for dmp/*; staged source/testbins-dep5 and source/testbins-README record that limitation. Expected values independently extracted via Python struct, before implementation: bugcheck0x1000007e, params ffffffffc0000005 / fffff8048b58334c / ffff850429891ee8 / ffff850429891720; 151 drivers; first ntoskrnl.exe basefffff8047ba00000,size0x1046000.

## Files

toolbox-site/tools/bsod/dump-core.js, dump-codec.c, dump-codec.wasm, dump-worker.js
_scratch/build-dump-wasm.ps1
_scratch/ops-tests/bsod-core.test.cjs
_scratch/bsod-fixtures/triage_x64.dmp (test only)
_scratch/bsod-fixtures/source/* (explicit package manifest above)
_scratch/bsod-parser-report.md

## Limits / self-review

No full/kernel memory traversal, symbols, unwind, root-cause verdict, unloaded drivers, version-independent undocumented structure guessing. Type4 x86 and ARM64 payloads are header-only. MDMP can contain application-defined streams (including kernel-related streams); parser does not infer a blue screen from those. Triage timestamp is module build timestamp, never crash time. Bounded partial analysis can omit evidence; complete is always false. Header-only files with exactly8192bytes are accepted as partial type4 intentionally for damaged/truncated payload usability. Other truncated binary records are malformed. No known failing focused tests remain. Root owns browser integration, packaging and deployment.

## Review amendment: bounded stack performance (final)

Independent reviewer identified linear module lookup multiplied by each stack pointer, potentially 5.24 billion range checks at admitted limits. Added a focused subprocess regression: 10000 nonoverlapping driver records and a full4MiB stack of nonzero out-of-range pointers must complete within6seconds. RED before fix: subprocess killed with ETIMEDOUT at6047ms. GREEN after fix: 483ms (repeat735ms), including all module Blob reads and WASM decoding. Entire final suite11/11 passing,0fail (~1.6sec); command node --test _scratch/ops-tests/bsod-core.test.cjs. C/WASM rebuilt successfully after changing pointer operation to batch decoding.

Lookup now precomputes BigInt module endpoints once, sorts boundary events and sweeps into disjoint unambiguous intervals. Build O(M log M), at most2M intervals; each pointer binary-searches O(log M). Stack WASM operation decodes up to512 pointers from each4096-byte chunk, removing per-pointer40-slot output allocation and JS-to-WASM transfer. Cancellation checks retained for every chunk; existing already-aborted and mid-read cancellation tests remain passing.

Overlap semantics intentionally conservative: addresses covered by2+ module ranges are omitted from module attribution, with a Chinese warning. Unique tails of overlapping modules remain attributable. A public-fixture-derived overlap regression confirms both behaviors; real unmodified151-module sample and stack evidence remain green. No additional files or external dependencies.

## Review amendment: final fixed-structure and uint64 boundary checks

Added two focused tests first; RED: node --test --test-name-pattern='exclusive module end|SystemInfoStream' _scratch/ops-tests/bsod-core.test.cjs =>0/2 pass, both Missing expected rejection. Fixed module exclusive end validation to reject >=2^64 (so all emitted addresses including end remain <=16hex digits), and required MDMP SystemInfoStream fixed56-byte body in both JS stream validation and C decode operation7. Truncated24-byte and55-byte system records are now malformed. Rebuilt WASM via _scratch/build-dump-wasm.ps1 successfully. Final GREEN: node --test _scratch/ops-tests/bsod-core.test.cjs =>13/13 pass,0fail,~805ms. Worst-case performance regression still green~298ms. Files stable for root packaging.
