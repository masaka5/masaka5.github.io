const { test } = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../../toolbox-site/assets/catalog.js');

test('toolbox catalog has stable categories and every tool is reachable', () => {
  const ids = new Set(catalog.categories.map(item => item.id));
  for(const id of ['hardware','network','windows','workspace','meetings','files','security','frontend','text','ai','pdf','image','media','data'])assert.ok(ids.has(id));
  assert.equal(ids.size,catalog.categories.length);
  assert.equal(new Set(catalog.tools.map(t=>t.id)).size,catalog.tools.length);
  assert.equal(new Set(catalog.tools.map(t=>t.href)).size,catalog.tools.length);
  assert.ok(catalog.tools.every(item => ids.has(item.category)));
  assert.ok(catalog.tools.some(item => item.href === 'tools/system-commands/'));
});
test('every integrated implementation maps to exactly one real local workspace',()=>{
 const fs=require('fs'),path=require('path');const manifest=require('../../toolbox-site/assets/integration-manifest.json');
 for(const s of manifest.sources){const tool=catalog.tools.find(t=>t.id===s.tool);assert.ok(tool,s.sourceId);assert.ok(tool.variants.some(v=>v.source===s.source&&v.sourceId===s.sourceId||v.origins?.some(o=>o.source===s.source&&o.sourceId===s.sourceId)),s.sourceId);}
 for(const tool of catalog.tools){assert.ok(tool.name.trim());if(!tool.href.startsWith('tools/tool/'))continue;for(const v of tool.variants||[]){const target=new URL(v.href,'http://toolbox.local/tools/tool/');assert.equal(target.origin,'http://toolbox.local');assert.ok(fs.existsSync(path.join('toolbox-site',target.pathname,'index.html')),target.pathname);}}
});
