import asyncio,os,json
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
ROOT=Path(__file__).resolve().parents[2]
def header(code=0xd1):
 b=bytearray(8192);b[:8]=b'PAGEDU64'
 def u32(p,n):b[p:p+4]=n.to_bytes(4,'little')
 def u64(p,n):b[p:p+8]=n.to_bytes(8,'little')
 u32(8,15);u32(12,22621);u32(0x30,0x8664);u32(0x34,8);u32(0x38,code)
 for i,v in enumerate([0xfffff80312345678,2,1,0xfffff80312456789]):u64(0x40+8*i,v)
 u32(0xf98,4);u64(0xfa8,133700000000000000)
 return bytes(b)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch();context=await browser.new_context(viewport={'width':1440,'height':900});page=await context.new_page();errors=[];uploads=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:uploads.append(r.url)if r.method not in ['GET','HEAD']else None)
  r=await page.goto(BASE+'/tools/bsod/');assert r.status==200
  await page.wait_for_function("document.querySelector('#dumpFiles').onchange!==null")
  await page.locator('#dumpFiles').set_input_files([{'name':'蓝屏1.dmp','buffer':header(),'mimeType':'application/octet-stream'},{'name':'蓝屏2.dmp','buffer':header(0x116),'mimeType':'application/octet-stream'},{'name':'bad.dmp','buffer':b'broken','mimeType':'application/octet-stream'}])
  await page.wait_for_function("document.querySelectorAll('#dumpRows tr').length===3&&!document.querySelector('#addFiles').disabled",timeout=60000)
  assert '0x000000d1' in (await page.locator('#dumpRows').inner_text()).lower()
  await page.locator('#dumpRows [data-open]').first.click();assert '0xfffff80312345678' in (await page.locator('#detailBody').inner_text()).lower()
  assert '程序异常' not in await page.locator('#detailBody').inner_text()
  await page.locator('#dumpRows input[type=checkbox]').nth(0).check();await page.locator('#dumpRows input[type=checkbox]').nth(1).check()
  await page.locator('[data-tab=compare]').click();assert '0x000000d1' in (await page.locator('#detailBody').inner_text()).lower()and '0x00000116' in (await page.locator('#detailBody').inner_text()).lower()
  async with page.expect_download() as d:await page.locator('#exportJSON').click()
  download=await d.value;data=json.loads(Path(await download.path()).read_text(encoding='utf8'));assert len(data['records'])==3
  await page.locator('#search').fill('bad');assert await page.locator('#dumpRows tr').count()==1
  await page.locator('#search').fill('');await page.locator('[data-tab=overview]').click()
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(100)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   for selector in ['#addFiles','#search','.detail-tabs']:
    box=await page.locator(selector).bounding_box();assert box and box['y']>=0 and box['y']+box['height']<=h,(selector,w,h,box)
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/bsod-desktop.png')
  await page.locator('#clear').click();assert await page.locator('#dumpRows tr').count()==0
  assert not errors,errors;assert not uploads,uploads
  print(json.dumps({'base':BASE,'batch':3,'uint64':True,'compare':True,'export':True,'layouts':5,'no_upload':True,'errors':errors}));await browser.close()
asyncio.run(main())
