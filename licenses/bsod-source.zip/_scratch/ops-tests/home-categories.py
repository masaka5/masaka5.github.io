import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
groups={'hardware':['stress','monitor','devices','serial','scan','nfc'],'workspace':['code','webvm'],'windows':['windows-errors','system-commands','folder-analysis','bsod'],'meetings':['meeting']}
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE);await page.wait_for_function("document.querySelectorAll('.tool-card').length>1000")
  for width,height in [(1440,900),(390,844),(390,400)]:
   await page.set_viewport_size({'width':width,'height':height})
   nav='#categoryNav'if width>800 else '#mobileCategoryNav'
   for group,ids in groups.items():
    await page.locator(f'{nav} [data-category={group}]').click()
    expected=await page.evaluate('(g)=>ToolboxCatalog.tools.filter(t=>t.category===g).length',group)
    assert expected>0
    for tool in ids:
     assert await page.locator(f'.tool-card[data-tool="{tool}"]').get_attribute('data-group')==group
    assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight')
   await page.locator(f'{nav} [data-category=workspace]').click()
   assert await page.locator('.tool-card:not([hidden])').count()==2
   await page.screenshot(path=f'_scratch/home-groups-{width}-{height}.png')
  assert not errors,errors
  print(json.dumps({'groups':groups,'layouts':3,'errors':errors}));await b.close()
asyncio.run(main())
