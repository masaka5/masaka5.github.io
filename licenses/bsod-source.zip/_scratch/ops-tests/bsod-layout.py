import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto(BASE+'/tools/bsod/')
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(100)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   for selector in ['#addFiles','#search','.detail-tabs']:
    box=await page.locator(selector).bounding_box();assert box and box['y']>=0 and box['y']+box['height']<=h,(selector,w,h,box)
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/bsod-empty.png');await page.set_viewport_size({'width':390,'height':400});await page.screenshot(path='_scratch/bsod-empty-mobile.png')
  print(json.dumps({'layouts':5}));await b.close()
asyncio.run(main())
