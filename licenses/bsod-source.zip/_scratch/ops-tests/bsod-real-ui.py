import asyncio,os,json
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
ROOT=Path(__file__).resolve().parents[2]
def userdump():
 b=bytearray(512);b[:4]=b'MDMP'
 def u32(o,n):b[o:o+4]=n.to_bytes(4,'little')
 def u64(o,n):b[o:o+8]=n.to_bytes(8,'little')
 u32(4,0xa793);u32(8,2);u32(12,32);u32(20,1600000000)
 for i,(kind,size,off)in enumerate([(7,56,64),(6,168,128)]):
  for j,n in enumerate([kind,size,off]):u32(32+i*12+j*4,n)
 b[64:66]=(9).to_bytes(2,'little');u32(72,10);u32(136,0xc0000005);u64(152,0xfedcba9876543210);u32(160,15)
 for i in range(15):u64(168+8*i,i+1)
 return bytes(b)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/bsod/');await page.wait_for_function("document.querySelector('#dumpFiles').onchange!==null")
  await page.locator('#dumpFiles').set_input_files(str(ROOT/'_scratch/bsod-fixtures/triage_x64.dmp'))
  await page.wait_for_function("document.querySelector('#counts').textContent==='1 / 1'",timeout=60000)
  assert '0x1000007e' in (await page.locator('#dumpRows').inner_text()).lower()
  assert '151' in await page.locator('#detailBody').inner_text()
  await page.locator('[data-tab=modules]').click()
  assert 'ntoskrnl.exe' in await page.locator('#detailBody').inner_text()
  assert '转储驱动列表' in await page.locator('#detailBody').inner_text()
  await page.locator('.module-filter').fill('ntoskrnl');assert await page.locator('.detail-table tbody tr').count()==1
  await page.locator('[data-tab=addresses]').click();assert await page.locator('.detail-table tbody tr').count()>0
  assert '栈内地址扫描' in await page.locator('#detailBody').inner_text()
  async with page.expect_download() as d:await page.locator('#exportJSON').click()
  report=json.loads(Path(await (await d.value).path()).read_text('utf8'))
  r=report['records'][0];assert 'file' not in r and len(r['result']['modules'])==151
  assert r['result']['modules'][0]['base']=='0xfffff8047ba00000'
  async with page.expect_download() as d:await page.locator('#exportText').click()
  text=Path(await (await d.value).path()).read_text('utf-8-sig')
  assert all(str(v) in text for v in ['ntoskrnl.exe',r['result']['crashTime'],r['result']['architecture'],r['result']['system'],r['result']['addresses'][0]['address'],r['result']['addresses'][0]['offset']])
  assert report['parserVersion']=='1.0.0'
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h})
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.screenshot(path='_scratch/bsod-real-mobile.png')
  await page.locator('#clear').click()
  await page.locator('#dumpFiles').set_input_files([{'name':n,'buffer':userdump(),'mimeType':'application/octet-stream'}for n in ['user1.dmp','user2.dmp']])
  await page.wait_for_function("document.querySelector('#counts').textContent==='2 / 2'")
  await page.locator('[data-tab=overview]').click();assert '程序异常' in await page.locator('#detailBody').inner_text()
  assert '0xfedcba9876543210' in await page.locator('#detailBody').inner_text()
  for box in await page.locator('#dumpRows input[type=checkbox]').all():await box.check()
  await page.locator('[data-tab=compare]').click();assert '参数 15' in await page.locator('#detailBody').inner_text()
  async with page.expect_download() as d:await page.locator('#exportText').click()
  assert '0xfedcba9876543210' in Path(await (await d.value).path()).read_text('utf-8-sig')
  await page.locator('#clear').click()
  # Delay worker startup to exercise actual UI cancellation and worker disposal.
  await page.route('**/dump-worker.js',lambda route: asyncio.create_task(delayed(route)))
  await page.locator('#dumpFiles').set_input_files(str(ROOT/'_scratch/bsod-fixtures/triage_x64.dmp'))
  await page.locator('#cancel').click()
  await page.wait_for_function("!document.querySelector('#addFiles').disabled")
  assert '已取消' in await page.locator('#dumpRows').inner_text()
  await page.unroute('**/dump-worker.js')
  await page.locator('#clear').click()
  files=[{'name':f'{i}.dmp','mimeType':'application/octet-stream','buffer':b'bad'}for i in range(33)]
  await page.locator('#dumpFiles').set_input_files(files)
  assert await page.locator('#dumpRows tr').count()==0
  assert '32' in await page.locator('#status').inner_text()
  assert not errors,errors
  print(json.dumps({'base':BASE,'real_modules':151,'addresses':True,'search':True,'exports':2,'cancel':True,'batch_cap':True,'errors':errors}));await b.close()
async def delayed(route):
 await asyncio.sleep(.5)
 try:await route.continue_()
 except Exception:pass
asyncio.run(main())
