const {test}=require('node:test');
const assert=require('node:assert/strict');
const catalog=require('../../toolbox-site/assets/catalog.js');

test('common operations have distinct meaningful icons, including network tools',()=>{
 for(const ids of [['subnet','ip-batch','mac','network','dns','ip-location','switch-commands','domain-info'],['pdf-merge','pdf-split','pdf-protect','pdf-crop','pdf-sign']]){
  const names=ids.map(id=>catalog.tools.find(t=>t.id===id).icon);
  assert.equal(new Set(names).size,ids.length,ids.join(', '));
 }
});
test('the catalog uses a varied local icon vocabulary rather than generic arrows',()=>{
 assert.ok(new Set(catalog.tools.map(t=>t.icon)).size>=100);
 assert.ok(catalog.tools.every(t=>t.icon!=='convert'));
 assert.equal(new Set(catalog.categories.map(c=>c.icon)).size,catalog.categories.length);
 const paths=require('../../toolbox-site/assets/tool-icon-paths.js');
 for(const item of [...catalog.tools,...catalog.categories])assert.ok(paths[item.icon],item.id+': '+item.icon);
 assert.equal(catalog.tools.find(t=>t.id==='json-to-yaml').iconBadge,'YAML');
 assert.equal(catalog.tools.find(t=>t.id==='pdf-merge').iconBadge,'PDF');
});
