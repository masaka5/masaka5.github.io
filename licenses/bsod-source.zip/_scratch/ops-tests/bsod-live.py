"""Verify HTTPS deployment bytes, catalog entry and source archive provenance."""
from pathlib import Path
import urllib.request,json,hashlib,zipfile,io
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[2];BASE='https://tools.manshii.asia/'
paths=['tools/bsod/'+p.name for p in (ROOT/'toolbox-site/tools/bsod').iterdir()if p.is_file()and p.suffix!='.c']
paths+=['assets/catalog.js','assets/catalog-base.js','assets/tool-icon-paths.js','licenses/bsod-source.zip','licenses/sources.json']
def check(path):
 with urllib.request.urlopen(BASE+path+'?release=bsod-20261112',timeout=30)as r:
  assert r.status==200;data=r.read()
 assert hashlib.sha256(data).digest()==hashlib.sha256((ROOT/'toolbox-site'/path).read_bytes()).digest(),path
 return path
with ThreadPoolExecutor(max_workers=6)as pool:verified=list(pool.map(check,paths))
with urllib.request.urlopen(BASE+'licenses/bsod-source.zip',timeout=30)as r:
 with zipfile.ZipFile(io.BytesIO(r.read()))as z:
  assert not any(n.endswith('.dmp')for n in z.namelist())
  assert '_scratch/bsod-fixtures/source/LICENSE-GPL-3' in z.namelist()
print(json.dumps({'https_resources_match':len(verified),'no_dump_distributed':True,'source_licenses':True}))
