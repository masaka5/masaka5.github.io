$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
& 'C:/Program Files/LLVM/bin/clang.exe' --target=wasm32 -O2 -nostdlib '-Wl,--no-entry' '-Wl,--export=buffer' '-Wl,--export=output' '-Wl,--export=decode' '-Wl,--export-memory' '-Wl,--initial-memory=4325376' '-Wl,--max-memory=4325376' -o "$root/toolbox-site/tools/bsod/dump-codec.wasm" "$root/toolbox-site/tools/bsod/dump-codec.c"
if($LASTEXITCODE -ne 0){throw 'WASM compilation failed'}
