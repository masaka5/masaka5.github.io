# Transfer core / engine / local durable store report

Owned files only: transfer-core.js, transfer-engine.js, transfer-store.js, store-worker.js and designated two test scripts/report. No commits or other files edited.

## Integration API

- deriveConnection(password) => {room:32 lowercase hex chars,key:64 lowercase hex chars}. PBKDF2 SHA-256, fixed versioned salt, 200,000 iterations, 384 derived bits. Password 12–128 JS characters. randomPassword() is 24 URL-safe hex characters (96 cryptographic random bits).
- TransferEngine extends EventTarget; constructor {store,sendControl,sendChunk}; offer(file), receiveControl(data), receiveChunk(bytes,meta), accept(id), reject(id), pause(), resume(), disconnected(), setConnected(boolean), close(). setConnected(false) also pauses. close does not close supplied store.
- outgoing/incoming contain id/hash/name/size/type/offset/state/token; outgoing also file and hashProgress (0..1). current is latest task, retained after complete/rejection. Events change(detail=current), offer(detail=incoming), notice(detail=Chinese string). Task hashing initially has no id until stream SHA-256 completes.
- All operational receive errors become paused + notice; invalid/stale envelopes ignored. offer throws for disconnected/busy/invalid Blob; internal hash/send failures become paused notice. Offer before accept does not create receiver cache. Simultaneous offers reject both with no cache writes. One operation total.
- Resume sending creates fresh token and reoffers original selected File. Resume receiving recalculates durable prefix and sends accept. Reconnection offer requires explicit accept again. Sender refresh must select original file again. Reaccepting an already complete file verifies prefix and full hash; no payload resend.

## Wire v1

Control object max4096 UTF-8 JSON bytes; fields {v:1,type,id,token}. id contentSHA25664lowerhex. token24lowerhex nonce per attempt.
- offer: +hash (=id),name,size,mime. Receiver sanitizes name separators/control chars. name<=255, MIME<=127, safe integer size 0..1TiB.
- accept: +offset,prefixHash. Offset 0..size, chunk aligned unless final size. Sender hashes its own prefix and compares before sending any byte.
- ack: +offset exact current pending chunk end. Unexpected ACK pauses; cannot skip data.
- finish: sender requests full receiver hash when all bytes durably acknowledged (also zero bytes).
- complete: receiver full hash and metadata complete committed, sender completes.
- pause/error/reject: preserve committed data; reject may include reason:'busy'. No peer-provided errors rendered.
Chunk metadata {v:1,id,token,offset,hash}; raw Uint8Array exactly min(256KiB,remaining). SHA-256 mismatch / unexpected offset pauses. No ACK until write flush+metadata commit resolved. Exactly one in-flight payload. 30sec chunk ACK wait timeout pauses; offers wait indefinitely for user consent/receiver prefix hash. Local resume prefix hashing and final hash have no wall-clock timeout (a large file can take minutes); disconnect/manual pause still invalidates generation. Old async operations cannot acknowledge or complete UI state after pause/token replacement.

## Persistence

TransferStore async init()=>this; mode='opfs'|'idb', fallbackLimit=268435456. Methods per agreed brief. read limited16MiB per call (UI streaming loop should choose1MiB). blob only complete files<=256MiB. Worker incremental SHA256 uses vendored createSHA256 over1MiB slices; file hashes never buffer full Blob. hashFile progress callback ratio0..1.

Module dedicated worker serializes all storage RPC. Origin-wide Web Lock held until close() excludes a second tab/instance rather than racing same content file. Requires Web Locks, IndexedDB, workers; missing Web Locks fails safely. OPFS directory toolbox-file-transfer-v1 with validated SHA256 file names. SyncAccessHandle closed in finally every operation; flush then close before strict-durability IndexedDB offset transaction resolves. Unsupported strict durability option retries ordinary transaction (older browser actual power-loss durability is browser-dependent).

Fallback IDB limit256MiB/file; chunks+offset same transaction. Quota estimate guarded before prepare/write; actual QuotaExceededError also pauses without advancing commit. Record includes public fields plus internal storage field. prepare/get/list reconcile committed offset against physical data: OPFS uncommitted tails truncated; missing committed bytes resets offset0+partial; incomplete IDB chunk sequence resets offset0 and clears chunks. No received data intentionally deleted on reject/pause/disconnect. Browser eviction/private browsing clearing can lose it. OPFS blob is file-backed but same256MiB UI memory fallback limit enforced; larger download must stream read() to FileSystemAccess target.

## Verification / RED-GREEN

- Initial Node test-first run: six expected failures missing CHUNK_SIZE/API/TransferEngine. Implementation then6/6 green.
- Latest-current regression and requested key string: observed2 failing assertions, fixed, green.
- Browser storage script first failed missing transfer-store.js; subsequent worker import failed because vendored hash-wasm is ESM, switched module Worker, green.
- `node --test _scratch/ops-tests/transfer-core.test.cjs`:25/25 PASS. Core deterministic derivation/bounds; explicit accept;600KB/3chunks+fullhash; zero bytes; quota no ACK; corrupt chunk; malicious ACK; wrong resume prefix; disconnect reoffer;262144byte nonzero resume; stale async commit pause; old token ignored; latest current reverse transfer; ACK blocked until commit; simultaneous offers; reject no cache.
- `python _scratch/ops-tests/transfer-storage.py`: PASS Chromium actual OPFS worker hash, durable write/get/read/hash, noncontiguous write reject, exclusive second instance, close/reopen metadata+Blob, delete, uncommitted physical tail truncate, missing physical bytes resets; forced browser-IDB fallback600KB multichunk/hash/range/read/reopen/delete and>256MiB refusal. Fallback forced only by test network route replacing OPFS probe condition; production unchanged.

Not claimed by these tests: real cross-ISP/NAT transport/public signaling, multi-TiB disk capacity/power-failure hardware durability, other browsers. Root owns transport/browser integration and download UI tests.

- Additional regression: pending local resume-prefix hash retained the initial offer timer; observed assertion failure, cleared timer before local hashing,15/15 green.


- Symmetric receiver regression: do not time out while sender hashes resume prefix before first chunk. Observed RED then fixed; latest16/16 green. Receiver remains transferable while sender verifies; explicit pause/disconnect still works.


- Frame-byte regression: UTF8 Chinese padding exceeded4096bytes but below4096JS units. Observed RED reject-state mutation then enforced byte counts on control/chunk metadata; latest17/17 green.


- Reviewer offer-timer fix: initial and resumed offer no longer arm30sec timer, allowing user confirmation and receiver prefix hashing. Regression observed RED then GREEN18/18.


- Reviewer task-generation fixes: resume exclusively targets current paused task; receiveControl captures origin task+generation and only fails that still-current generation. Three regressions observed RED (old paused send vs new incoming, stale sender prefix failure, malformed unrelated offer), fixed; stale final stored hash failure also covered. Latest22/22 green.


- Final delayed-old-accept regression: obsolete paused outgoing had matching historicaltoken and could restart alongside currentincoming. Observed RED then require task===current for all matched controls and incomingchunks. Latest23/23 green.


- Final deferred-busy rejection regression observed RED: reject control backpressure allowed newoutgoing before old busy handler resumed. Busy handler now captures original outgoing and requires original generation+current before failure. Latest24/24 green.


- Last offer-success race: deferred obsolete sendControl(offer) resolution cleared newer pending ACK timer. Regression observed RED; after await, require fresh task/current/offered before timer+change. Latest25/25 green.

