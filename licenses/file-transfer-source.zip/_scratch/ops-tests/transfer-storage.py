import asyncio, functools, http.server, threading,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]
async def main():
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(ROOT/'toolbox-site')))
 threading.Thread(target=server.serve_forever,daemon=True).start()
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True)
  page=await browser.new_page();await page.goto(f'http://127.0.0.1:{server.server_port}/')
  result=await page.evaluate('''async()=>{
   const {TransferStore}=await import('/tools/file-transfer/transfer-store.js');
   const a=await new TransferStore().init(); const h=await a.hashFile(new Blob(['abc']));
   if(h!=='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')throw Error('worker hash');
   const meta={id:h,hash:h,name:'a.txt',size:3,type:'text/plain'};await a.prepare(meta);
   await a.write(h,0,new Uint8Array([97,98,99]));
   if((await a.get(h)).offset!==3)throw Error('committed offset');
   if(await a.hashPrefix(h,3)!==h)throw Error('stored hash');
   let rejected=false;try{await a.write(h,0,new Uint8Array([1]));}catch{rejected=true;}if(!rejected)throw Error('noncontiguous write');
   let locked=false;const b=new TransferStore();try{await b.init();}catch{locked=true;}b.close();if(!locked)throw Error('second instance lock');
      const mode=a.mode;await a.complete(h);
   const dir=await (await navigator.storage.getDirectory()).getDirectoryHandle('toolbox-file-transfer-v1');const handle=await dir.getFileHandle(h);let writer=await handle.createWritable({keepExistingData:true});await writer.write({type:'write',position:3,data:new Uint8Array([9,9])});await writer.close();
   if((await a.get(h)).offset!==3||(await handle.getFile()).size!==3)throw Error('uncommitted tail not truncated');
   a.close();await new Promise(r=>setTimeout(r,100));
   const c=await new TransferStore().init();if((await c.get(h)).state!=='complete')throw Error('refresh metadata');
   if(await (await c.blob(h)).text()!=='abc')throw Error('download');   let corrupt=await handle.createWritable();await corrupt.write(new Uint8Array([97]));await corrupt.close();
   if((await c.get(h)).offset!==0||(await c.get(h)).state!=='partial')throw Error('missing bytes cannot resume');
   await c.remove(h);if(await c.get(h))throw Error('delete');c.close();
   return {mode,hash:h,checks:8};
  }''')
  print(result)
  await page.route('**/store-worker.js',lambda route:route.fulfill(status=200,content_type='text/javascript',body=re.sub(r'if\s*\(navigator\.storage\?\.getDirectory\)', 'if(false)',(ROOT/'toolbox-site/tools/file-transfer/store-worker.js').read_text(encoding='utf-8-sig'))))
  fallback=await page.evaluate('''async()=>{
   const {TransferStore}=await import('/tools/file-transfer/transfer-store.js');const s=await new TransferStore().init();
   if(s.mode!=='idb')throw Error('fallback mode');const bytes=new Uint8Array(600000);bytes.fill(71);const h=await s.hashFile(new Blob([bytes]));const meta={id:h,hash:h,name:'fallback.bin',size:bytes.length,type:''};
   await s.prepare(meta);for(let n=0;n<bytes.length;n+=262144)await s.write(h,n,bytes.slice(n,n+262144));
   if(await s.hashPrefix(h,bytes.length)!==h)throw Error('fallback stored hash');await s.complete(h);s.close();await new Promise(r=>setTimeout(r,100));
   const t=await new TransferStore().init();if((await t.get(h)).offset!==600000)throw Error('fallback reload');if((await t.read(h,200000,400000)).some(b=>b!==71))throw Error('range read');
   let limited=false;try{const id='f'.repeat(64);await t.prepare({id,hash:id,name:'large',size:268435457,type:''});}catch{limited=true;}if(!limited)throw Error('fallback limit');
   await t.remove(h);t.close();return {mode:'idb',checks:5};
  }''')
  print(fallback);await browser.close()
 server.shutdown()
asyncio.run(main())



