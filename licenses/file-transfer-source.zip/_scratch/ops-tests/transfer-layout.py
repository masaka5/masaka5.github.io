import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  response=await page.goto(BASE+'/tools/file-transfer/');assert response.status==200,'file transfer tool missing'
  await page.wait_for_function("document.body.dataset.ready==='true'")
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h})
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   for s in ['#password','#connect','#chooseFile']:
    box=await page.locator(s).bounding_box();assert box and box['y']>=0 and box['y']+box['height']<=h and box['x']+box['width']<=w,(s,w,h,box)
  # Persist a real cache record, render a long active task, and verify clipped content remains reachable.
  await page.evaluate('''async()=>{
   const s=transferApp.store,id=await s.hashFile(new Blob(['abc']));
   await s.prepare({id,hash:id,name:'测'.repeat(250)+'.bin',size:3,type:''});
   await s.write(id,0,new Uint8Array([97,98,99]));
   transferApp.engine.incoming={id,name:'测'.repeat(250)+'.bin',size:3,offset:3,state:'paused'};
   transferApp.engine.latest=transferApp.engine.incoming;
   transferApp.engine.dispatchEvent(new Event('change'));
  }''')
  await page.wait_for_selector('[data-delete]')
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h})
   for s in ['#resumeTransfer','[data-delete]']:
    await page.locator(s).scroll_into_view_if_needed();box=await page.locator(s).bounding_box()
    assert box and box['y']>=0 and box['y']+box['height']<=h,(s,w,h,box)
    assert await page.locator(s).evaluate('(el)=>{const b=el.getBoundingClientRect();return el.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2))}'),(s,w,h,'clipped')
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  await page.locator('[data-delete]').click()
  await page.evaluate("()=>{transferApp.engine.incoming.state='transferring';transferApp.engine.dispatchEvent(new Event('change'))}")
  assert await page.locator('[data-delete]').is_disabled()
  await page.locator('#confirmDelete').click()
  assert await page.evaluate('(async()=>!!await transferApp.store.get(transferApp.engine.incoming.id))()'),'active cache was deleted'
  await page.screenshot(path='_scratch/transfer-mobile.png')
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/transfer-desktop.png')
  assert not errors,errors;print(json.dumps({'base':BASE,'layouts':10,'active_cache_delete_guard':True,'errors':errors}));await b.close()
asyncio.run(main())
