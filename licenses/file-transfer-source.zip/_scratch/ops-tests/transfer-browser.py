"""Independent browser contexts: public signaling and real WebRTC bytes, no mock transport."""
import asyncio,os,json,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
STRATEGY=os.getenv('TRANSFER_TEST_STRATEGY','mqtt')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();contexts=[await b.new_context(accept_downloads=True)for _ in range(2)];pages=[await c.new_page()for c in contexts];errors=[]
  for page in pages:page.on('pageerror',lambda e:errors.append(str(e)))
  for page in pages:await page.goto(BASE+'/tools/file-transfer/');await page.wait_for_function("document.body.dataset.ready==='true'")
  password=await pages[0].locator('#password').input_value();await pages[1].locator('#password').fill(password)
  for page in pages:await page.locator('#strategy').select_option(STRATEGY)
  await pages[0].locator('#connect').click();await pages[1].locator('#connect').click()
  await asyncio.gather(*[page.wait_for_function('transferApp.transport?.peer!==null&&transferApp.transport?.peer!==undefined',timeout=75000)for page in pages])
  data=bytes((i*73+19)%256 for i in range(2300000));digest=hashlib.sha256(data).hexdigest()
  await pages[0].locator('#files').set_input_files({'name':'测试文件.bin','mimeType':'application/octet-stream','buffer':data})
  await pages[1].locator('#receiveDialog').wait_for(state='visible',timeout=30000)
  assert await pages[1].evaluate('transferApp.records.length')==0
  # Use real persistence but delay writes so a mid-transfer disconnect is deterministic.
  await pages[1].evaluate("()=>{const write=transferApp.store.write.bind(transferApp.store);transferApp.store.write=async(...args)=>{await new Promise(r=>setTimeout(r,120));return write(...args)}}")
  await pages[1].locator('#acceptFile').click()
  await pages[0].wait_for_function('transferApp.engine.outgoing.offset>=262144',timeout=30000)
  await pages[0].locator('#disconnect').click()
  await pages[1].wait_for_function("transferApp.engine.incoming.state==='paused'",timeout=15000)
  record=await pages[1].evaluate('transferApp.store.get(transferApp.engine.incoming.id)');assert 0<record['offset']<len(data),record
  offset=record['offset']
  # Receiver refresh really destroys its JS state; OPFS+IDB must survive.
  await pages[1].reload();await pages[1].wait_for_function("document.body.dataset.ready==='true'")
  saved=await pages[1].evaluate('transferApp.records');assert saved[0]['offset']>=offset,saved
  await pages[1].locator('#password').fill(password)
  await pages[1].locator('#strategy').select_option(STRATEGY)
  await pages[0].locator('#connect').click();await pages[1].locator('#connect').click()
  await asyncio.gather(*[page.wait_for_function('!!transferApp.transport?.peer',timeout=75000)for page in pages])
  await pages[0].locator('#files').set_input_files({'name':'测试文件.bin','mimeType':'application/octet-stream','buffer':data})
  await pages[1].locator('#receiveDialog').wait_for(state='visible',timeout=30000);await pages[1].locator('#acceptFile').click()
  await asyncio.gather(*[page.wait_for_function("transferApp.engine.current?.state==='complete'",timeout=60000)for page in pages])
  got=await pages[1].evaluate('async()=>{const r=transferApp.records.find(r=>r.state==="complete")||await transferApp.store.get(transferApp.engine.incoming.id);return {record:r,hash:await transferApp.store.hashPrefix(r.id,r.size)}}')
  assert got['hash']==digest and got['record']['offset']==len(data),got
  stats=await pages[0].evaluate('transferApp.transport.stats()');assert stats['bytesSent']>0 and stats['local']!='relay',stats
  await pages[1].wait_for_function("document.querySelector('[data-download]')!==null")
  await pages[1].evaluate('()=>{window.showSaveFilePicker=undefined}')
  async with pages[1].expect_download()as d:await pages[1].locator('[data-download]').click()
  downloaded=Path(await (await d.value).path()).read_bytes();assert downloaded==data
  # Repeat in the opposite direction, then a rejected offer never creates a record.
  await pages[1].locator('#files').set_input_files({'name':'空文件.txt','mimeType':'text/plain','buffer':b''})
  await pages[0].locator('#receiveDialog').wait_for(state='visible');await pages[0].locator('#acceptFile').click()
  await pages[0].wait_for_function("transferApp.engine.incoming?.state==='complete'",timeout=30000)
  await pages[1].wait_for_function("transferApp.engine.outgoing?.state==='complete'",timeout=30000)
  await pages[0].locator('#files').set_input_files({'name':'拒绝.txt','mimeType':'text/plain','buffer':b'rejected'})
  await pages[1].locator('#receiveDialog').wait_for(state='visible');await pages[1].locator('#rejectFile').click()
  await pages[0].wait_for_function("transferApp.engine.outgoing.state==='rejected'")
  assert len(await pages[1].evaluate('transferApp.store.list()'))==1
  assert not errors,errors
  result={'base':BASE,'public_signaling':STRATEGY,'webrtc_stats':stats,'bytes':len(data),'resume_offset':offset,'receiver_refresh':True,'download_identical':True,'reverse_zero_file':True,'reject':True,'errors':errors}
  print(json.dumps(result));Path('_scratch/transfer-browser-result.json').write_text(json.dumps(result,indent=2));await b.close()
asyncio.run(main())
