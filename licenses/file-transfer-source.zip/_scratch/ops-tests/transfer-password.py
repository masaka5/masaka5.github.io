import asyncio,os,json
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch();contexts=[await browser.new_context()for _ in range(3)];pages=[await c.new_page()for c in contexts]
  for page in pages:await page.goto(BASE+'/tools/file-transfer/');await page.wait_for_function("document.body.dataset.ready==='true'")
  password=await pages[0].locator('#password').input_value()
  await pages[1].locator('#password').fill('wrong-password-'+password);await pages[2].locator('#password').fill(password)
  for page in pages:await page.locator('#connect').click()
  for page in [pages[0],pages[2]]:await page.wait_for_function('!!transferApp.transport?.peer',timeout=75000)
  await pages[1].wait_for_timeout(3500);assert not await pages[1].evaluate('!!transferApp.transport?.peer')
  # Wrong-password device changes to the correct password, but the pair is already full.
  await pages[1].locator('#disconnect').click();await pages[1].locator('#password').fill(password);await pages[1].locator('#connect').click()
  await pages[1].wait_for_timeout(5000);assert not await pages[1].evaluate('!!transferApp.transport?.peer')
  assert await pages[0].evaluate('!!transferApp.transport?.peer')and await pages[2].evaluate('!!transferApp.transport?.peer')
  print(json.dumps({'base':BASE,'wrong_password_isolated':True,'third_device_not_admitted':True}));await browser.close()
asyncio.run(main())
