from pathlib import Path
import subprocess,json
ROOT=Path(__file__).resolve().parents[1];REPO=ROOT/'_scratch/masaka5-toolbox-upstream'
allowed={'licenses/integration-source.zip','licenses/sources.json','licenses/file-transfer-source.zip','assets/catalog-base.js','assets/catalog.js','assets/integration-manifest.json','assets/tool-icon-paths.js'}
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
tracked=[p.decode()for p in git('diff','--name-only','-z').split(b'\0')if p]
untracked=[p.decode()for p in git('ls-files','--others','--exclude-standard','-z').split(b'\0')if p]
valid=lambda p:p in allowed or p.startswith('tools/file-transfer/')
assert all(valid(p)for p in tracked),tracked
files=tracked+[p for p in untracked if valid(p)];assert files
subprocess.run(['git','-c','core.autocrlf=false','add','--',*files],cwd=REPO,check=True)
staged=[p.decode()for p in git('diff','--cached','--name-only','-z').split(b'\0')if p];assert set(files)==set(staged)
for name in staged:assert git('show',':'+name)==(ROOT/'toolbox-site'/name).read_bytes(),name
print(json.dumps({'staged':len(staged),'bytes_match':True,'preserved_untracked':[p for p in untracked if p not in files]}))
