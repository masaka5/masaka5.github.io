# 文件直传

纯静态 HTTPS 网页，无需文件存储服务器。两端使用同一连接方式和12–128字符密码，默认生成96位随机密码；公共 MQTT/Nostr 服务只交换加密信令，文件走 WebRTC 数据通道。没有配置 TURN，无法穿透部分企业网络/NAT时需切换网络。

接收前明确确认；每块256KiB，SHA-256 校验，落盘提交后 ACK，最终全文件校验。刷新后重新连接、发送方重选原文件，双方校验已有前缀后续传。OPFS 优先，IDB 回退单文件256MiB；容量受浏览器配额影响。大文件保存使用 Chrome/Edge 原生文件选择器流式写入，其他浏览器保存上限256MiB。清理网站数据、浏览器主动回收存储会丢失缓存。同一浏览器同源只允许一个传输缓存实例。

运行时复用 vendor/meeting/{mqtt,nostr}.js 和 vendor/hash-wasm/hash-wasm.js；版本、许可证及对应源码见 licenses/sources.json、meeting-source.zip、hash-wasm-source.zip。无需重新构建，直接静态部署。测试：Node.js22+ node --test _scratch/ops-tests/transfer-core.test.cjs；Python3 + Playwright 运行 transfer-storage.py、transfer-layout.py、transfer-browser.py、transfer-password.py。后3项使用 TOOLBOX_TEST_BASE 指定站点（默认 http://127.0.0.1:8765）；TRANSFER_TEST_STRATEGY=nostr 验证备用信令。

自动化使用独立浏览器上下文与真实公共信令/WebRTC；不代表所有跨运营商网络均可直连，也不模拟设备断电耐久性。
