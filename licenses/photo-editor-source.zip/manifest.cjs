const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const site = path.resolve(__dirname, '../../toolbox-site');
function files(dir) { return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry => entry.isDirectory() ? files(path.join(dir,entry.name)) : [path.join(dir,entry.name)]); }
const paths = [...files(path.join(site,'tools/photo-editor')), ...fs.readdirSync(path.join(site,'licenses')).filter(name=>name.startsWith('photo-editor') && !name.endsWith('manifest.json')).map(name=>path.join(site,'licenses',name))];
const manifest = {name:'toolbox-photo-editor',upstream:'https://github.com/viliusle/miniPaint',version:'4.14.3',commit:'c9192c15918eb61f7dd89e362cf8065a276b89e9',entry:'tools/photo-editor/',license:'MIT; third-party MIT/BSD/ISC notices included',supports:['layers','selection','crop','transforms','filters','brush','text','image import/export','JSON editable projects','IndexedDB local draft'],unsupported:['Photoshop PSD import/export'],files:paths.map(file=>({path:path.relative(site,file).replaceAll('\\','/'),bytes:fs.statSync(file).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}))};
fs.writeFileSync(path.join(site,'licenses/photo-editor-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(manifest.files.length+' files, '+manifest.files.reduce((sum,file)=>sum+file.bytes,0)+' bytes');
