import FileNew from './modules/file/new.js';

// The project lives in this browser's IndexedDB; no upload or account is involved.
export default async function initToolbox(app) {
	const status = document.getElementById('save-status');
	const say = text => { status.textContent = text; };
	document.getElementById('new-document').onclick = () => new FileNew().new();
	document.getElementById('open-document').onclick = () => app.FileOpen.open_file();
	document.getElementById('save-project').onclick = () => app.FileSave.save();
	document.getElementById('export-image').onclick = () => app.FileSave.export();
	let db, timer, last = '', restoring = true, saving = false, draftBlocked = false, saveRequested = false;
	const open = indexedDB.open('toolbox-photo-editor', 1);
	open.onupgradeneeded = () => open.result.createObjectStore('projects');
	try {
		db = await new Promise((resolve, reject) => { open.onsuccess = () => resolve(open.result); open.onerror = () => reject(open.error); });
		const project = await new Promise((resolve, reject) => {
			const request = db.transaction('projects').objectStore('projects').get('current');
			request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
		});
		if (project) {
			const result = await app.FileOpen.load_json(project);
			if (result?.status !== 'completed') throw new Error('草稿恢复已中止');
			last = project; app.GUI.GUI_preview.zoom_auto(true); say('已恢复本机草稿');
		}
		else say('草稿自动保存在此浏览器');
	} catch (error) { draftBlocked = true; say('草稿恢复失败，原草稿已保留；新建或导入后可重新保存'); }
	finally { restoring = false; }
	document.addEventListener('photo-project-load-failed', () => {
		if (!draftBlocked) say('项目载入失败，当前文档保持不变');
	});
	const doAction = app.State.do_action.bind(app.State);
	app.State.do_action = async function(action, options) {
		const result = await doAction(action, options);
		if (!restoring && result?.status === 'completed' && /^(new_file|open_json_file|open_image|open_file_data_url)$/.test(action.action_id)) {
			draftBlocked = false; schedule();
		}
		return result;
	};
	async function saveDraft() {
		if (!db || restoring || draftBlocked || !app.Config.layer) return;
		if (saving) { saveRequested = true; return; }
		saving = true;
		try {
			const data = app.FileSave.export_as_json();
			if (data === last) { say('草稿已保存到本机'); return; }
			await new Promise((resolve, reject) => {
				const transaction = db.transaction('projects', 'readwrite');
				transaction.objectStore('projects').put(data, 'current');
				transaction.oncomplete = resolve; transaction.onerror = () => reject(transaction.error);
			});
			last = data; say('草稿已保存到本机');
		} catch (error) { say('草稿保存失败，请使用「保存项目」'); }
		finally { saving = false; if (saveRequested) { saveRequested = false; saveDraft(); } }
	}
	function schedule() { if (draftBlocked) return; say('草稿正在保存…'); clearTimeout(timer); timer = setTimeout(saveDraft, 350); }
	for (const event of ['pointerup', 'keyup', 'change']) document.addEventListener(event, schedule, true);
	document.addEventListener('visibilitychange', () => { if (document.hidden) saveDraft(); });
	window.addEventListener('pagehide', saveDraft);
	document.getElementById('help-dialog').addEventListener('click', event => { if (event.target === event.currentTarget) event.currentTarget.close(); });
	document.getElementById('editor-help').onclick = () => document.getElementById('help-dialog').showModal();
}
