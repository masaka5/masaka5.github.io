$ErrorActionPreference = 'Stop'
$sourceRoot = $PSScriptRoot
$siteRoot = Join-Path (Split-Path (Split-Path $sourceRoot)) 'toolbox-site'
$runtimeRoot = Join-Path $sourceRoot 'runtime'
New-Item -ItemType Directory -Force $runtimeRoot | Out-Null
Copy-Item (Join-Path $siteRoot 'tools/photo-editor/*') $runtimeRoot -Recurse -Force
Copy-Item (Join-Path $sourceRoot 'MIT-LICENSE.txt') (Join-Path $siteRoot 'licenses/photo-editor-MIT.txt') -Force
$archiveTarget = Join-Path $siteRoot 'licenses/photo-editor-source.zip'
$sourceEntries = @('src','runtime','package.json','package-lock.json','webpack.config.js','.babelrc','MIT-LICENSE.txt','TOOLBOX-EDITION.md','package-source.ps1','collect-licenses.cjs','manifest.cjs') | ForEach-Object { Join-Path $sourceRoot $_ }
Compress-Archive -LiteralPath $sourceEntries -DestinationPath $archiveTarget -Force
