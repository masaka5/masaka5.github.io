const fs = require('fs');
const path = require('path');
const root = __dirname;
const target = path.resolve(root, '../../toolbox-site/licenses/photo-editor-third-party.txt');
const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
let text = 'Toolbox photo editor / miniPaint 4.14.3 third party notices\n\n';
text += fs.readFileSync(path.join(root, 'MIT-LICENSE.txt'), 'utf8') + '\n\n';
for (const [key, entry] of Object.entries(lock.packages)) {
  if (!key || entry.dev || !key.startsWith('node_modules/')) continue;
  const dir = path.join(root, key);
  const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
  text += '\n============================================================\n' + key + ' ' + entry.version + '\nLicense: ' + (entry.license || pkg.license || JSON.stringify(pkg.licenses) || 'See included source') + '\n';
  for (const name of fs.readdirSync(dir).filter(name => /^(licen[sc]e|copying|notice)(\.|$)/i.test(name))) {
    const file = path.join(dir, name);
    if (fs.statSync(file).isFile()) text += '\n' + name + '\n' + fs.readFileSync(file, 'utf8') + '\n';
  }
  for (const name of fs.readdirSync(dir).filter(name => /^readme/i.test(name))) {
    const readme = fs.readFileSync(path.join(dir,name),'utf8');
    const license = readme.match(/(?:^|\n)#+\s*License[^]*$/i);
    if (license) text += '\n' + name + ' / license section\n' + license[0] + '\n';
  }
}
// Preserve additional license-bearing blocks inside the upstream Color Thief source.
const thief = fs.readFileSync(path.join(root, 'src/js/libs/color-thief.js'), 'utf8');
for (const match of thief.matchAll(/\/\*[^]*?\*\//g)) if (/copyright|license|redistribution/i.test(match[0])) text += '\nColor Thief / quantize.js embedded notice\n'+match[0]+'\n';
text += '\n============================================================\nBundled upstream library source headers and notices\n';
for (const name of fs.readdirSync(path.join(root, 'src/js/libs')).filter(name => name.endsWith('.js'))) {
  const contents = fs.readFileSync(path.join(root, 'src/js/libs', name), 'utf8');
  const header = contents.match(/^(?:import[^\n]*\n)*\s*(\/\*[\s\S]*?\*\/|(?:\/\/[^\n]*\n)+)/);
  if (header && /license|copyright|author|credit|https?:/i.test(header[1])) text += '\n' + name + '\n' + header[1] + '\n';
}
fs.writeFileSync(target, text);
console.log(target, text.length);
