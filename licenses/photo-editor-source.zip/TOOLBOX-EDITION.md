# Toolbox photo editor

Based on miniPaint 4.14.3, upstream commit c9192c15918eb61f7dd89e362cf8065a276b89e9.
Upstream: https://github.com/viliusle/miniPaint (MIT, see MIT-LICENSE.txt).

This edition keeps local image editing, Chinese interface, layers, text, filters,
selection, crop and transforms. It removes hosted image search, remote font
loading, third party links, URL startup import, service worker registration and
unrelated menus. It adds the Toolbox shell and IndexedDB draft recovery.
AlertifyJS is replaced with an original MIT local notification adapter so no
GPL or proprietary notification dependency is included. Remote fonts are removed.
Corrupted drafts are retained without automatic overwrite until a successful
new document or import; pagehide and visibilitychange attempt an immediate flush.
Imports validate document dimensions, layers, identifiers, image payloads, text
and filter metadata before changing the canvas. Aborted undoable imports are
reported as failures and restore the existing document. Filter markup is escaped.
Draft writes queue a second save when edits arrive while IndexedDB is still busy.
PSD is not supported. JSON preserves editable layers; exported PNG/JPG/WebP are
flattened image formats. All processing takes place in the browser.
BMP uses an original local 24-bit encoder with white alpha compositing and row
padding, shared by export and file size preview; it does not rely on the browser's
unsupported image/bmp encoder. PNG, JPG, WebP, GIF, BMP and TIFF exports were each
downloaded in Chromium and decoded with Pillow during verification.

## Build

Node.js 24 / npm 11 were used for the verified production build.

    npm ci --ignore-scripts
    npm run build

The build writes dist/bundle.js. To build directly into a running site, set the
PHOTO_EDITOR_OUTPUT environment variable to its absolute tools/photo-editor/dist
directory before npm run build. Copy src/js/libs/gifjs/gif.worker.js to
dist/gif.worker.js. Runtime shell files and images are included under runtime/.
Serve runtime/ via any static HTTP server; no application server is required.
Copy generated dist/ inside runtime/ before serving.

The source archive excludes node_modules, which can be reproducibly installed
with the included package-lock.json. Runtime dependency audit was clear with
npm audit --omit=dev on 2026-11-12. Upstream development tooling still has npm
audit advisories and must not be deployed as a development server.
