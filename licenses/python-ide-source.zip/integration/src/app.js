import {EditorState,Compartment} from '@codemirror/state';
import {EditorView,keymap,lineNumbers,drawSelection,highlightActiveLine} from '@codemirror/view';
import {defaultKeymap,history,historyKeymap,indentWithTab} from '@codemirror/commands';
import {syntaxHighlighting,defaultHighlightStyle} from '@codemirror/language';
import {python} from '@codemirror/lang-python';
import './style.css';

const $=s=>document.querySelector(s);
const MAX_BYTES=8*1024*1024,MAX_FILES=128,MAX_FILE=4*1024*1024;
const encoder=new TextEncoder(),decoder=new TextDecoder('utf-8',{fatal:true});
const initial='# Python 代码在当前浏览器中真实运行\nimport math\n\nfor i in range(1, 6):\n    print(f"{i} 的平方 = {i ** 2}")\n\nprint("你好，Python！", math.sqrt(81))\n';
let files=[{name:'main.py',text:initial}],active='main.py',db,view,worker,busy=false,saveTimer,dirty=false,blocked=false,revision=0,rawDraft,runStarted=0,saving,runningCompile=false,generation=0;
const syntax=new Compartment(),editable=new Compartment();
function status(text){$('#status').textContent=text;}
function draftStatus(text){$('#draft-status').textContent=text;}
function validName(name){return typeof name==='string'&&name.length<=240&&!name.startsWith('/')&&!name.includes('\\')&&!name.split('/').some(s=>!s||s==='.'||s==='..'||/[\u0000-\u001f]/.test(s))&&name.split('/').length<=8;}
function validPaths(projectFiles){const names=new Set(projectFiles.map(file=>file.name));return names.size===projectFiles.length&&projectFiles.every(file=>validName(file.name)&&file.name.split('/').slice(0,-1).every((_,index,parts)=>!names.has(parts.slice(0,index+1).join('/'))));}
function bytes(file){return file.binary?Uint8Array.from(atob(file.binary),c=>c.charCodeAt(0)):encoder.encode(file.text);}
function encodeFile(name,data){try{return{name,text:decoder.decode(data)}}catch{let result='';for(let i=0;i<data.length;i+=16384)result+=String.fromCharCode(...data.subarray(i,i+16384));return{name,binary:btoa(result)};}}
function validProject(value){
 if(!value||value.version!==1||!Array.isArray(value.files)||!value.files.length||value.files.length>MAX_FILES)return false;
 let size=0;const names=new Set();
 for(const file of value.files){
  if(!file||!validName(file.name)||names.has(file.name)||(typeof file.text!=='string'&&typeof file.binary!=='string'))return false;
  try{const length=bytes(file).length;if(length>MAX_FILE)return false;size+=length;}catch{return false;}
  names.add(file.name);
 }
 return size<=MAX_BYTES&&names.has(value.active)&&validPaths(value.files);
}
function current(){return files.find(f=>f.name===active);}
function sync(){if(view&&current()&&!current().binary)current().text=view.state.doc.toString();}
function snapshot(){sync();return{version:1,files:structuredClone(files),active,stdin:$('#stdin').value,revision:revision+1,updated:Date.now()};}
function request(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async function openDatabase(){const req=indexedDB.open('toolbox-python-ide',1);req.onupgradeneeded=()=>req.result.createObjectStore('drafts');return request(req);}
function read(key='current'){return request(db.transaction('drafts','readonly').objectStore('drafts').get(key));}
function write(record,key='current'){
 return new Promise((resolve,reject)=>{const tx=db.transaction('drafts','readwrite');tx.objectStore('drafts').put(record,key);tx.oncomplete=()=>resolve();tx.onerror=tx.onabort=()=>reject(tx.error||new Error('保存被中断'));});
}
function recovery(text){blocked=true;$('#recovery').hidden=false;$('#recovery-text').textContent=text;$('#recover-download').disabled=rawDraft===undefined;$('#recover-new').disabled=!db;draftStatus('自动保存已暂停');}
async function persist(){
 if(saving){try{await saving;}catch{return;}if(dirty&&!blocked)return persist();return;}
 clearTimeout(saveTimer);if(!dirty||blocked||!db)return;
 const record=snapshot();
 try{
  // Compare and save in one transaction: another tab must not silently replace this draft.
  saving=new Promise((resolve,reject)=>{
   const tx=db.transaction('drafts','readwrite'),store=tx.objectStore('drafts'),get=store.get('current');
   get.onsuccess=()=>{
    const saved=get.result;
    if((saved?.revision||0)!==revision){rawDraft=saved;tx.abort();reject(new Error('另一页面已更新草稿。请导出当前项目，或保留旧数据并另存。'));return;}
    store.put(record,'current');
   };
   tx.oncomplete=()=>resolve();tx.onerror=tx.onabort=()=>reject(tx.error||new Error('本地草稿保存失败，请导出项目保留代码。'));
  });
  await saving;revision=record.revision;dirty=JSON.stringify(record.files)!==JSON.stringify(files)||record.stdin!==$('#stdin').value||record.active!==active;draftStatus(dirty?'正在保存…':'草稿已保存');
 }catch(error){recovery(error.message);}finally{saving=undefined;}
}
function changed(){dirty=true;draftStatus(blocked?'自动保存已暂停':'正在保存…');clearTimeout(saveTimer);if(!blocked)saveTimer=setTimeout(persist,350);}
function setActive(name){
 active=name;const file=current();
 view.setState(EditorState.create({doc:file.binary?'[二进制文件：请下载查看，运行时可直接读取]':file.text,extensions:extensions(file)}));
 $('#filename').textContent=name;$('#file-info').textContent=file.binary?'二进制文件':name.endsWith('.py')?'Python':'文本文件';renderFiles();
 $('#run').disabled=busy||!name.endsWith('.py')||!!file.binary;$('#compile').disabled=$('#run').disabled;
}
function renderFiles(){
 $('#files').replaceChildren();
 for(const file of files){const button=document.createElement('button');button.className='file';button.textContent=file.name;button.title=file.name;button.setAttribute('aria-current',String(file.name===active));button.onclick=()=>{if(busy)return status('运行期间请先停止，再切换文件。');sync();setActive(file.name);changed();};$('#files').append(button);}
}
function extensions(file){return[lineNumbers(),drawSelection(),highlightActiveLine(),history(),keymap.of([{key:'Mod-Enter',run:()=>{run(false);return true;}},{key:'Mod-s',run:()=>{exportFile();return true;}},...defaultKeymap,...historyKeymap,indentWithTab]),syntaxHighlighting(defaultHighlightStyle),syntax.of(file.name.endsWith('.py')?python():[]),editable.of(EditorState.readOnly.of(!!file.binary)),EditorView.contentAttributes.of({'aria-label':'代码编辑器',spellcheck:'false'}),EditorView.updateListener.of(update=>{if(update.docChanged){sync();changed();}})];}
function download(data,name,type='application/octet-stream'){const url=URL.createObjectURL(new Blob([data],{type}));const link=document.createElement('a');link.href=url;link.download=name.replace(/[<>:"/\\|?*\u0000-\u001f]/g,'_');link.click();setTimeout(()=>URL.revokeObjectURL(url),3000);}
function exportFile(){sync();download(bytes(current()),active.split('/').at(-1));}
function append(text,kind='stdout'){const span=document.createElement('span');span.className=kind;span.textContent=text;$('#output').append(span);$('#output').scrollTop=$('#output').scrollHeight;}
function controls(){for(const id of ['import','import-project','new-file','rename','delete'])$('#'+id).disabled=busy;$('#stop').disabled=!busy;$('#run').disabled=busy||!active.endsWith('.py')||!!current()?.binary;$('#compile').disabled=$('#run').disabled;}
function discardWorker(){generation++;worker?.terminate();worker=undefined;busy=false;controls();}
async function run(compile){
 if(busy||!active.endsWith('.py')||current().binary)return;
 sync();const runGeneration=++generation;busy=true;runningCompile=compile;controls();view.dispatch({effects:editable.reconfigure(EditorState.readOnly.of(true))});await persist();if(runGeneration!==generation||!busy)return;$('#output').replaceChildren();runStarted=performance.now();status(compile?'正在检查语法…':'正在准备 Python…');
 if(!worker){
  worker=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});
 }
 const instance=worker;
 worker.onmessage=({data})=>{
   if(instance!==worker||runGeneration!==generation||!busy)return;
   if(data.type==='status')status(data.text);
   if(data.type==='output')for(const chunk of data.chunks)append(chunk.text,chunk.kind);
   if(data.type==='done'){
    let syncRejected=!!data.skipped||data.prepared===false;
    if(!syncRejected&&data.files?.length){
     // Preserve in-flight edits; code edits are disabled while running by readonly extension below.
     const returned=data.files.filter(f=>validName(f.name)&&f.data.length<=MAX_FILE).map(f=>encodeFile(f.name,f.data));
     const nextActive=returned.some(f=>f.name===active)?active:returned[0]?.name;
     if(validProject({version:1,files:returned,active:nextActive})){files=returned;active=nextActive;setActive(active);changed();}else syncRejected=true;
    }
    busy=false;controls();view.dispatch({effects:editable.reconfigure(EditorState.readOnly.of(!!current().binary))});
    if(syncRejected){append('\n[项目文件未同步：运行结果超限或准备失败，原项目和草稿完整保留；下次运行使用保留的项目。]\n','system');worker?.terminate();worker=undefined;}
    status(`${data.failed?'执行失败':runningCompile?'语法检查完成':'运行完成'} · ${((performance.now()-runStarted)/1000).toFixed(2)} 秒`);
    if(!$('#output').textContent)append('执行完成，没有标准输出。\n','system');
   }
  };
  worker.onerror=event=>{if(instance!==worker||runGeneration!==generation)return;append('Python 引擎载入失败：'+event.message+'\n','stderr');discardWorker();view.dispatch({effects:editable.reconfigure(EditorState.readOnly.of(false))});status('加载失败，可重新运行。');};
 view.dispatch({effects:editable.reconfigure(EditorState.readOnly.of(true))});
 worker.postMessage({type:'run',files:files.map(f=>({name:f.name,data:bytes(f)})),code:current().text,name:active,stdin:$('#stdin').value,compile});
}
$('#run').onclick=()=>run(false);$('#compile').onclick=()=>run(true);
$('#stop').onclick=()=>{discardWorker();view.dispatch({effects:editable.reconfigure(EditorState.readOnly.of(!!current().binary))});append('\n[已停止，当前执行产生的未同步文件已丢弃]\n','system');status('已停止；可再次运行，代码草稿已保留。');};
$('#reset').onclick=()=>{discardWorker();view.dispatch({effects:editable.reconfigure(EditorState.readOnly.of(!!current().binary))});append('\n[运行环境已重置，项目文件保留]\n','system');status('运行环境已重置；下次运行自动重新载入 Python。');};
$('#clear-output').onclick=()=>$('#output').replaceChildren();$('#download-output').onclick=()=>download($('#output').textContent,'python-output.txt','text/plain;charset=utf-8');
$('#export-file').onclick=exportFile;$('#export-project').onclick=()=>download(JSON.stringify(snapshot(),null,2),'python-project.json','application/json');
$('#new-file').onclick=()=>{if(files.length>=MAX_FILES)return status('项目最多支持 128 个文件。');const name=prompt('文件名，可包含子目录，例如 utils/helper.py','script.py');if(name===null)return;if(!validPaths([...files,{name,text:''}]))return status('文件名无效、重复或与目录冲突。');files.push({name,text:''});setActive(name);changed();};
$('#rename').onclick=()=>{const name=prompt('新的文件名',active);if(name===null||name===active)return;if(!validPaths(files.map(file=>({name:file.name===active?name:file.name}))))return status('文件名无效、重复或与目录冲突。');sync();current().name=name;active=name;setActive(name);changed();};
$('#delete').onclick=()=>{if(files.length===1)return status('请至少保留一个文件。');if(!confirm(`删除 ${active}？此操作会更新本地草稿。`))return;files=files.filter(f=>f.name!==active);active=files[0].name;setActive(active);changed();};
$('#import').onclick=()=>$('#file-input').click();
$('#file-input').onchange=async event=>{
 try{
  const selected=[...event.target.files];if(!selected.length)return;
  if(selected.some(f=>f.size>MAX_FILE)||selected.reduce((n,f)=>n+f.size,0)>MAX_BYTES)throw new Error('导入文件过大：单文件最多 4 MB，项目最多 8 MB。');
  sync();const imported=await Promise.all(selected.map(async f=>encodeFile(f.name,new Uint8Array(await f.arrayBuffer()))));
  const duplicates=imported.filter(f=>files.some(existing=>existing.name===f.name));
  if(duplicates.length&&!confirm(`覆盖 ${duplicates.map(f=>f.name).join('、')}？建议先导出当前项目。`))return;
  const candidate=files.filter(f=>!imported.some(i=>i.name===f.name)).concat(imported);
  if(!validProject({version:1,files:candidate,active:imported[0].name}))throw new Error('导入失败：文件名、数量或项目大小超过限制。');
  files=candidate;active=imported[0].name;setActive(active);changed();status(`已导入 ${imported.length} 个文件。`);
 }catch(error){status(error.message);}finally{event.target.value='';}
};
$('#import-project').onclick=()=>$('#project-input').click();
$('#project-input').onchange=async event=>{
 try{const f=event.target.files[0];if(!f)return;if(f.size>12*1024*1024)throw new Error('项目文件过大。');const data=JSON.parse(await f.text());if(!validProject(data))throw new Error('项目格式无效，当前草稿保持原样。');if(!confirm('打开项目将替换当前编辑区。请确认已导出需要保留的代码。'))return;files=data.files;active=data.active;$('#stdin').value=typeof data.stdin==='string'?data.stdin:'';setActive(active);changed();status('项目已导入。');}catch(error){status('无法导入：'+error.message);}finally{event.target.value='';}
};
$('#stdin').oninput=changed;
$('#recover-download').onclick=()=>download(JSON.stringify(rawDraft,null,2),'python-draft-recovery.json','application/json');
$('#recover-new').onclick=async()=>{
 try{const record=snapshot();record.revision=1;await new Promise((resolve,reject)=>{const tx=db.transaction('drafts','readwrite'),store=tx.objectStore('drafts'),get=store.get('current');get.onsuccess=()=>{if(get.result!==undefined)store.put(get.result,'backup-'+Date.now());store.put(record,'current');};tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(tx.error);});revision=1;blocked=false;dirty=false;$('#recovery').hidden=true;draftStatus('新草稿已保存，旧数据已备份');}catch{status('另存失败，请导出项目。');}
};
window.addEventListener('beforeunload',event=>{if(dirty||busy){event.preventDefault();event.returnValue='';}});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')persist();});
try{db=await openDatabase();rawDraft=await read();if(rawDraft!==undefined){if(!validProject(rawDraft))recovery('本地草稿格式异常，自动保存已暂停；原始数据已保留。');else{files=rawDraft.files;active=rawDraft.active;revision=rawDraft.revision||0;$('#stdin').value=typeof rawDraft.stdin==='string'?rawDraft.stdin:'';}}}catch{recovery('浏览器无法读取本地草稿。请导出项目保留代码。');}
view=new EditorView({parent:$('#editor'),state:EditorState.create({doc:'',extensions:[]})});setActive(active);controls();status('就绪 · Ctrl / ⌘ Enter 运行');draftStatus(blocked?'自动保存已暂停':'草稿已就绪');
