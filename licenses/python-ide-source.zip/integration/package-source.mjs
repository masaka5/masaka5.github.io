import {readFile,writeFile,readdir,stat,mkdir,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {zipSync} from 'fflate';
const root=path.dirname(fileURLToPath(import.meta.url)),site=path.resolve(root,'../../toolbox-site'),licenses=path.join(site,'licenses');
const lock=JSON.parse(await readFile(path.join(root,'package-lock.json'),'utf8')),archive={},deps=[],notice=['Python 在线 IDE — 完整第三方版权与许可\n\n共享 Pyodide/CPython 见 vendor/pyodide/LICENSE 及 licenses/jupyter* 清单。此文件收录编辑器与构建依赖许可。\n'];
async function collect(folder,prefix){for(const entry of (await readdir(folder,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){if(entry.name==='node_modules'||entry.name==='.git'||entry.name.startsWith('.env'))continue;const file=path.join(folder,entry.name);if(entry.isDirectory())await collect(file,prefix+'/'+entry.name);else if(entry.isFile())archive[prefix+'/'+entry.name]=[new Uint8Array(await readFile(file)),{mtime:new Date('2026-01-01T00:00:00Z')}];}}
await collect(root,'integration');
for(const [key,entry] of Object.entries(lock.packages)){
 if(!key)continue;const folder=path.join(root,key);let pkg;try{pkg=JSON.parse(await readFile(path.join(folder,'package.json'),'utf8'));}catch{continue;}
 const files=(await readdir(folder)).filter(f=>/^(licen[sc]e|copying|notice)([.-]|$)/i.test(f)&&(f.indexOf('/')<0));
 if(!files.length&&pkg.name.startsWith('@esbuild/'))files.push('../esbuild/LICENSE.md');
 if(!files.length)throw new Error('Missing license: '+pkg.name);
 deps.push({name:pkg.name,version:pkg.version,license:pkg.license||entry.license,developmentOnly:!!entry.dev,source:entry.resolved,integrity:entry.integrity});
 notice.push(`\n${'='.repeat(72)}\n${pkg.name} ${pkg.version} (${pkg.license||entry.license})\nSource: ${entry.resolved}\n`);
 for(const file of files){const location=file==='../esbuild/LICENSE.md'?path.join(root,'node_modules/esbuild/LICENSE.md'):path.join(folder,file);if((await stat(location)).isFile())notice.push('\n'+await readFile(location,'utf8')+'\n');}
 if(!entry.dev)await collect(folder,'upstream/'+pkg.name);
}
archive['THIRD-PARTY-NOTICES.txt']=[new TextEncoder().encode(notice.join('')),{mtime:new Date('2026-01-01T00:00:00Z')}];
await mkdir(licenses,{recursive:true});await writeFile(path.join(licenses,'python-ide-third-party.txt'),notice.join(''));await copyFile(path.join(root,'LICENSE'),path.join(licenses,'python-ide-MIT.txt'));
await writeFile(path.join(licenses,'python-ide-source.zip'),zipSync(archive,{level:6}));
const files=[];async function manifest(folder){for(const entry of (await readdir(folder,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){const file=path.join(folder,entry.name);if(entry.isDirectory())await manifest(file);else{const data=await readFile(file);files.push({path:path.relative(site,file).split(path.sep).join('/'),bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});}}}
await manifest(path.join(site,'tools/python-ide'));
for(const file of ['python-ide.html','python-ide-MIT.txt','python-ide-third-party.txt','python-ide-source.zip']){const data=await readFile(path.join(licenses,file));files.push({path:'licenses/'+file,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});}
await writeFile(path.join(licenses,'python-ide-manifest.json'),JSON.stringify({name:'toolbox-python-ide',version:'1.0.0',entry:'tools/python-ide/',license:'MIT; third-party original licenses retained',runtime:{engine:'Pyodide',version:'314.0.6',python:'3.14',sharedPath:'vendor/pyodide/',source:'https://github.com/pyodide/pyodide',license:'vendor/pyodide/LICENSE',manifest:'licenses/jupyter-manifest.json'},build:'npm ci && npm run build && npm run package-source',test:'npm test (Playwright real Chrome; static site at http://127.0.0.1:8765)',features:['real CPython WASM','CodeMirror Python editing','compile/run stdout/stderr','pre-filled linewise stdin','Worker terminate stop/reset','UTF-8 and binary file import/export','JSON project import/export','IndexedDB corruption/conflict protection','responsive no root scrolling'],limits:{projectBytes:8388608,fileBytes:4194304,fileCount:128,stdoutCharacters:100000},dependencies:deps,files},null,2)+'\n');
console.log(`Packaged ${Object.keys(archive).length} source files, ${deps.length} dependencies, ${files.reduce((n,f)=>n+f.bytes,0)} bytes (shared engine excluded).`);
