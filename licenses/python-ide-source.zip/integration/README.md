# Python 在线 IDE

真实 Pyodide 314.0.6 / CPython 3.14 WebAssembly，与同站 Jupyter 共享 `vendor/pyodide/`。编辑器为 CodeMirror 6，依赖全部自托管，无遥测、无解释器模拟或后端服务。

## 构建与验证

Node.js 22+：`npm ci && npm run build && npm run package-source`。`build.mjs` 生成同级站点 `../../toolbox-site/tools/python-ide/`，需同站已部署的共享 Pyodide 引擎（详见站点 `licenses/jupyter*` 的引擎来源、校验、完整许可证）。引擎不重复收录在本源码 ZIP，可按共享清单获取原版文件。

测试：站点用静态 HTTP 服务监听 `127.0.0.1:8765`，`npm test` 运行真实 Chrome/Playwright。可通过环境变量 `TOOLBOX_TEST_BASE` 指定站点基址。Playwright 1.58.2 已锁定为开发依赖，需已安装 Chrome (`channel: 'chrome'`)。实际验证包括 Python 计算、标准库、Unicode、异常、编译、input/EOF、模块和二进制导入、文件生成下载、输出注入/截断、无限循环停止恢复、真实 IndexedDB 事务等待中取消、草稿重载/冲突/损坏/备份、项目恢复与五种视口（包括 844×390 横屏）。

## 行为与限制

- 当前 `.py` 文件作为 `__main__` 执行；各次运行重建顶层全局字典、失效项目模块导入缓存，运行环境可手动重置。
- Worker 内使用实际 CPython `compile()` / `exec()`，stdout/stderr 分批传回 UI，以 `textContent` 显示，最多 100,000 字符。浏览器 CSP 限制脚本连接到同源。
- 输入框每行对应一次 `input()`，用尽抛出 EOFError。此版本无交互式阻塞输入和 pip 安装界面，未预装的 Pyodide 原生包可能不可用。支持浏览器中的 Python 标准库，不提供桌面 GUI、系统 shell、原生进程和服务器端网络能力。
- 停止与重置使用 `Worker.terminate()`，可结束任意死循环；编辑文件与本地草稿保留，运行中尚未同步的生成文件被丢弃。运行期间文件操作和编辑锁定。
- 项目虚拟文件系统映射 `/home/pyodide/project`。运行完成同步常规文件（跳过 `__pycache__`）。项目最多 128 文件 / 8 MiB，单文件 4 MiB，最多 8 层目录。任何运行结果超过这些限制或含不可同步路径时，本次整个文件同步取消，原项目与草稿完整保留，运行环境销毁；下次运行恢复保留的项目。文件准备失败也禁止同步部分项目。UTF-8 文本可编辑，其余保留 base64 原字节用于运行与下载。文件名与目录前缀冲突（例如 `a.py` 与 `a.py/helper.py`）在导入、新建、重命名、草稿恢复及 Worker 准备时统一拒绝。
- IndexedDB `toolbox-python-ide/drafts/current` 保存项目、当前文件、输入。350ms 去抖；事务内比较版本防止多页面静默覆盖。读取损坏/存储失败会暂停自动保存并保留原数据，可下载恢复数据、导出编辑区或另存新草稿（旧数据备份为 backup 时间戳）。未保存/运行中关闭页面有浏览器确认。
- 导入同名文件、打开项目或删除文件均需浏览器原生确认。无账号或云同步。浏览器可能清除本地存储，须定期导出项目。清空运行输出不改变项目。
- Python 是浏览器 WebAssembly 代码执行环境，不是针对恶意代码的独立安全沙箱；不要运行不可信代码。输出按文本处理；所有资源无外部遥测请求。

源码与生产依赖原版分发源码收录在 `python-ide-source.zip`；锁文件可复现构建。ZIP 文件名排序、时间固定为 2026-01-01，不含 node_modules、.git、凭据、环境文件或构建缓存。
