# 直播工作台验证

2026-11-12，静态目录 `tools/broadcast/`。独立实现，协议参考固定版本的 MediaMTX 与 api.video-browser-to-rtmp，来源与源码包见 `licenses/sources.json`。

验证环境：Chromium + Playwright，摄像头和麦克风采用浏览器提供的测试设备；测试用 WHIP 接收端与 Socket.IO 转发协议接收端只在本机测试进程中存在，不进入部署包。

- `broadcast-engine-core.mjs`、`broadcast-engine-pacing.mjs`、`broadcast-publisher.test.mjs`：17 项通过。包括参数边界、旋转命中、倒计时、30/25/24/15fps 调度上限、静态输出免重绘、WHIP 会话创建/删除、认证失败、重试和取消、RTMP 媒体 ACK。
- `broadcast-ui.py`：文本编辑、旋转、场景切换；1440×900、1024×768、390×844、320×568、844×390、390×400 均无页面外层溢出，页面错误为零。
- `broadcast-engine-browser.py`：实际 GPU 抠像像素、稳定输出轨道、混音音量、场景音轨门控、录制视频解码、采集释放、暂停保持、损坏素材回滚、长字幕实际后缀像素和素材清理通过。
- `broadcast-workflow.py`：真实录制播放、刷新后图片与录像恢复、设备显式重连、工程导入导出、无效工程保留、缺少 RTMP 网关不能开始推流，页面错误为零。
- `broadcast-review-fixed.py`：独立复审验证导入失败保持同一摄像头轨道、自动录制停止保存及刷新恢复、空白工程不导出旧素材、暂停视频不被布局编辑恢复、长字幕两种后缀 GPU 像素不同，页面错误为零。
- `broadcast-publisher-real.py`：真实 WHIP peer 接收 82 帧、81,346 字节，320×180；会话删除且源轨道保持。转发协议测试接收真实 WebM 首部及 5 个媒体块、8,269 字节，停止事件正常。
- 目录和图标 4 项验证通过，首页分类与图标布局回归通过。
- `broadcast-screen.py`：浏览器真实 getDisplayMedia 路径取得有效屏幕视频轨道，删除素材后轨道 ended；`broadcast-permissions.py`：四种采集拒绝授权时原工程保持不变且无残留运行时。
- `broadcast-review-fallback.py`：启动遇损坏素材时保留原草稿与全部素材；失败导入、pagehide 和刷新均不覆盖原数据；原草稿可完整导出，显式新建后恢复自动保存。

边界：没有外部直播平台地址和密钥，未声称已向实际平台 RTMP 开播。RTMP 要求已有兼容 WSS 网关；“转发已连接”仅确认网关收到媒体。WHIP 端点须允许浏览器跨域请求。屏幕、窗口、系统声音采集由浏览器与操作系统权限决定。录像结束时保存至 IndexedDB；录制过程中刷新无法保全尚未完成的录像。

已发布：`34cc0341be1901fb59a6c1128528c1fa3b4f0e71`，GitHub Pages 工作流 `43213536279` 成功。正式 HTTPS 14 个资源与本地校验一致；线上重跑 workflow、ui、engine-browser、screen、permissions、draft-recovery 均通过。入口 https://tools.manshii.asia/tools/broadcast/ 。此发布只包含直播工作台及目录/来源更新，Ubuntu 仍保持此前的线上版本，待其完整测试后单独发布。
