# 浏览器直播工作台实现计划

执行沿用用户实现及部署授权。独立子系统按dispatching-parallel-agents分工，root负责集成、回归与发布。

1. 几何与场景：broadcast-core.js建立项目模型与clamp/旋转命中；先测试场景隔离、删除保护、锁定、层序和坐标变换，再实现。引擎API以spec和代理消息约定为准。
2. 真实媒体：engine.js/compositor.js接入getUserMedia/getDisplayMedia/本地图片视频，WebAudio destination混音和canvas captureStream，shader绿幕。实际录制、渲染像素与媒体轨道测试验证，所有关闭路径stop tracks/revoke URLs/disconnect nodes。
3. 推流：publisher.js标准WHIP，真实SDP POST/DELETE/ICE和getStats。RTMP转发通道只在握手确认后启动数据流；单元测试退避取消，端到端本地测试服务模拟接收端（不随产品部署）。
4. 工作台：index.html/style.css/app.js固定视口、预览、素材选区、变换手柄、场景素材混音列表及分页、面板标签、属性、录制预览与推流设置dialog。store.js IndexedDB保存项目资产录像；密钥不写存储。先运行缺少UI入口的RED，再实现运行真实浏览器操作。
5. 项目集成：catalog-base.js添加media分类直播卡片，更新语义图标、来源许可和manifest；不更改其他工具分类。根维护脚本生成源码包和部署包。执行单元+浏览器测试、release-check以及必要的会议和办公回归，限定路径提交部署。
