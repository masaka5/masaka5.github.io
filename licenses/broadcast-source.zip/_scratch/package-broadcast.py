"""Package browser studio source, tests and protocol provenance."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'toolbox-site';FOLDER=SITE/'tools/broadcast'
references=[
 {'project':'toolbox-broadcast','source':'first-party browser studio','sourceArchive':'licenses/broadcast-source.zip','changes':'Independent WebGL compositor, Web Audio mixer, MediaRecorder capture, IndexedDB projects and recordings; no backend shipped.'},
 {'project':'broadcast-whip-reference','source':'https://github.com/bluenviron/mediamtx','revision':'7e656029154b86ceb778401870fc9bb91e60ba70','license':'MIT','changes':'Protocol reference only; independent WHIP implementation, no copied code.'},
 {'project':'broadcast-rtmp-relay-reference','source':'https://github.com/apivideo/api.video-browser-to-rtmp','revision':'e7d4227b025258d41132168157d89c2100facd70','license':'MIT','changes':'Protocol reference only; independent Socket.IO/Engine.IO client for an existing user-provided relay. No relay server shipped.'}
]
manifest={'references':references,'files':[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(FOLDER.iterdir())if p.is_file()and p.name!='manifest.json']}
(FOLDER/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(SITE/'licenses/broadcast-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
 for p in sorted(FOLDER.iterdir()):
  if p.is_file():archive.write(p,'toolbox-site/tools/broadcast/'+p.name)
 for p in (ROOT/'_scratch/ops-tests').glob('broadcast-*'):
  if p.is_file()and p.suffix in {'.py','.mjs','.cjs'}:archive.write(p,'_scratch/ops-tests/'+p.name)
 for p in (SITE/'docs/superpowers').rglob('*broadcast*.md'):archive.write(p,'toolbox-site/'+p.relative_to(SITE).as_posix())
 archive.write(Path(__file__),'_scratch/package-broadcast.py')
 archive.writestr('BUILD.md','''# 直播工作台

纯静态 ES modules，无需构建或后端。放入工具箱部署目录，使用 HTTPS 或 localhost 访问 tools/broadcast/。
WebGL 合成、Web Audio 混音、MediaRecorder 录像；场景与录像存储于当前浏览器 IndexedDB。
摄像头、麦克风和共享屏幕需要用户授权；窗口及系统声音取决于浏览器支持。
WHIP 需要允许浏览器跨域访问的外部端点。RTMP 需要用户已有的 api.video-browser-to-rtmp 兼容 WSS 网关；网页本身不提供该服务。“转发已连接”仅确认网关收到媒体，直播平台是否接收需在平台确认。
真实浏览器测试使用 Python Playwright；推流传输测试的临时接收器只用于测试，不属于部署内容。
核心协议测试：node --test _scratch/ops-tests/broadcast-engine-core.mjs _scratch/ops-tests/broadcast-engine-pacing.mjs _scratch/ops-tests/broadcast-publisher.test.mjs。
浏览器测试：broadcast-ui.py、broadcast-workflow.py、broadcast-engine-browser.py、broadcast-publisher-real.py。
参考开源项目与固定版本记录在 manifest.json；协议独立实现，没有复制参考项目代码。图标使用工具箱现有 Lucide，保留原 ISC 许可。
''')
path=SITE/'licenses/sources.json';items=json.loads(path.read_text());names={r['project']for r in references}
path.write_text(json.dumps([r for r in items if r.get('project')not in names]+references,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'broadcast_files':len(manifest['files']),'source_bytes':(SITE/'licenses/broadcast-source.zip').stat().st_size}))
