"""Verify deployed runtime bytes, module imports and archived source availability."""
from pathlib import Path
import urllib.request,json,hashlib,re,concurrent.futures
ROOT=Path(__file__).resolve().parents[2];FOLDER=ROOT/'_scratch/masaka5-toolbox-upstream/tools/broadcast'
BASE='https://tools.manshii.asia/tools/broadcast/'
def read(name):
 request=urllib.request.Request(BASE+name+'?v=20261113-whip-http1',headers={'User-Agent':'toolbox-release-check','Cache-Control':'no-cache'})
 with urllib.request.urlopen(request,timeout=40)as response:return name,response.read()
names=[p.name for p in FOLDER.iterdir()if p.is_file()]
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 data=dict(pool.map(read,names))
for name,content in data.items():assert content==(FOLDER/name).read_bytes(),'stale deployed asset: '+name
manifest=json.loads(data['manifest.json'])
for row in manifest['files']:
 assert hashlib.sha256(data[row['file']]).hexdigest()==row['sha256'],row['file']
for name,content in data.items():
 if name.endswith('.js'):
  for module in re.findall(r"from\s*['\"]\./([^'\"]+)",content.decode()):assert module.split('?')[0]in data,(name,module)
with urllib.request.urlopen(manifest['references'][0]['sourceArchive'],timeout=40)as response:
 archive=response.read();assert archive[:2]==b'PK'
print(json.dumps({'httpsStatus':200,'runtimeFiles':len(data),'allHashesMatch':True,'allModuleImportsExist':True,'sourceArchiveBytes':len(archive)}))
