"""Real browser display-media pipeline (test display supplied by Chromium)."""
import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--auto-select-desktop-capture-source=Entire screen','--autoplay-policy=no-user-gesture-required'])
  page=await browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/broadcast/');await page.wait_for_function('broadcastApp.engine?.compositor')
  await page.locator('#addSource').click();await page.locator('#addScreen').click()
  await page.wait_for_function("broadcastApp.engine.activeScene.sources.some(s=>s.type==='screen')",timeout=15000)
  await page.wait_for_timeout(500)
  result=await page.evaluate('''()=>{const e=broadcastApp.engine,s=e.activeScene.sources.find(s=>s.type==='screen'),r=e.runtimes.get(s.id);const t=r.stream.getVideoTracks()[0];const out={status:e.getSourceStatus(s.id).status,videoTracks:r.stream.getVideoTracks().length,state:t.readyState,settings:t.getSettings(),frames:e.stats.frames};e.deleteSource(s.id);out.released=t.readyState;return out}''')
  assert result['state']=='live'and result['videoTracks']==1 and result['frames']>0 and result['released']=='ended',result
  assert not errors,errors;print(json.dumps(result));await browser.close()
asyncio.run(main())
