"""Real pointer resize, keyboard editing, GPU filter pixels and fade output."""
from pathlib import Path
import os,json,math
from playwright.sync_api import sync_playwright,expect
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
OUT=Path(__file__).resolve().parents[1]/'broadcast-editor-tests';OUT.mkdir(exist_ok=True)
with sync_playwright()as p:
 engine=os.getenv('BROADCAST_BROWSER','chromium');browser=p.firefox.launch()if engine=='firefox'else p.chromium.launch(**({'channel':'msedge'}if engine=='edge'else{}));page=browser.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:errors.append(m.text)if m.type=='error'else None);page.goto(BASE+'/tools/broadcast/');page.wait_for_function('broadcastApp.engine?.compositor')
 page.locator('#addSource').click();page.locator('#addText').click();page.locator('[data-property-tab=basic]').click()
 def source():return page.evaluate('broadcastApp.engine.activeScene.sources[0]')
 def change(patch):page.evaluate('patch=>broadcastApp.engine.updateSource(broadcastApp.engine.activeScene.sources[0].id,patch)',patch)
 change({'x':400,'y':350,'width':900,'height':500,'rotation':0})
 assert page.locator('.resize-point:visible').count()==8
 def drag(handle,dx,dy,shift=False):
  box=page.locator('button[data-handle="'+handle+'"]').bounding_box();x=box['x']+box['width']/2;y=box['y']+box['height']/2;page.mouse.move(x,y)
  if shift:page.keyboard.down('Shift')
  page.mouse.down();page.mouse.move(x+dx,y+dy,steps=4)
  now=source();assert str(round(now['width']))in page.locator('#transformMetrics').inner_text();page.mouse.up()
  if shift:page.keyboard.up('Shift')
  return now
 before=source();after=drag('e',35,0);assert after['width']>before['width'];assert abs(after['width']/after['height']-1.8)<.001;assert abs(after['x']-before['x'])<1
 before=source();after=drag('s',0,15,True);assert abs(after['width']-before['width'])<1;assert after['height']>before['height']
 # A rotated top-left drag keeps the opposite corner fixed.
 change({'x':500,'y':400,'width':700,'height':380,'rotation':30});before=source()
 def corner(s):
  a=math.radians(s['rotation']);return(s['x']+s['width']/2+math.cos(a)*s['width']/2-math.sin(a)*s['height']/2,s['y']+s['height']/2+math.sin(a)*s['width']/2+math.cos(a)*s['height']/2)
 anchor=corner(before);after=drag('nw',-20,-12);assert max(abs(a-b)for a,b in zip(anchor,corner(after)))<.01
 # Escape aborts a pending pointer edit, including stored dimensions.
 before=source();box=page.locator('button[data-handle=e]').bounding_box();page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);page.mouse.down();page.mouse.move(box['x']+30,box['y']+15);page.keyboard.press('Escape');page.mouse.up();assert source()['width']==before['width']
 # Keyboard operations use output pixel coordinates, independent of preview zoom.
 page.locator('#canvasWrap').click(position={'x':page.locator('#canvasWrap').bounding_box()['width']/2,'y':page.locator('#canvasWrap').bounding_box()['height']/2})
 page.locator('#sourceList .item-row').first.click();before=source();page.keyboard.press('ArrowRight');assert source()['x']==before['x']+1;page.keyboard.press('Shift+ArrowDown');assert source()['y']==before['y']+10
 page.keyboard.press('Alt+ArrowRight');assert source()['width']==before['width']+1
 page.keyboard.press('l');before=source();page.keyboard.press('ArrowLeft');assert source()['x']==before['x'];assert page.locator('.resize-point:visible').count()==0;page.keyboard.press('l')
 page.locator('#sourceName').fill('键盘输入');page.keyboard.press('ArrowLeft');assert source()['x']==before['x'];page.locator('#sourceName').press('Tab')
 page.locator('#sourceList .item-row').first.click();page.keyboard.press('Control+d');page.wait_for_function('broadcastApp.engine.activeScene.sources.length===2');page.keyboard.press('Control+ArrowDown');page.keyboard.press('Delete');assert len(page.evaluate('broadcastApp.engine.activeScene.sources'))==1
 page.keyboard.press('Alt+Shift+d');page.wait_for_function('broadcastApp.engine.project.scenes.length===2');assert len(page.evaluate('broadcastApp.engine.activeScene.sources'))==1;page.keyboard.press('Alt+1');assert page.evaluate('broadcastApp.engine.project.activeSceneId===broadcastApp.engine.project.scenes[0].id')
 page.keyboard.press('?');expect(page.locator('#shortcutsDialog')).to_be_visible();page.keyboard.press('ArrowRight');page.locator('#shortcutsDialog button').click()
 page.locator('#sourceList .item-row').first.click();page.locator('[data-property-tab=filters]').click();page.locator('#filterPreset').select_option('mono');assert source()['filters']['grayscale']==1;page.locator('#filter-brightness').fill('130');page.locator('#filter-brightness').dispatch_event('input');assert source()['filters']['brightness']==1.3
 page.locator('[data-property-tab=animation]').click();page.locator('#sourceAnimation').select_option('fade');page.locator('#animationDuration').fill('600');page.locator('#animationDuration').dispatch_event('change');page.locator('#previewFadeOut').click();assert source()['visible']is False;page.wait_for_function('broadcastApp.engine.fades.size===0');page.locator('#previewFadeIn').click();page.wait_for_function('broadcastApp.engine.fades.size===0');assert source()['visible']is True
 page.wait_for_timeout(800);page.reload();page.wait_for_function('broadcastApp.engine?.compositor');assert source()['filters']['brightness']==1.3 and source()['animation']['duration']==600
 # Verify the actual output pixels and a recorded filtered video, not DOM styles.
 pixels=page.evaluate('''async()=>{
 const e=broadcastApp.engine;await e.loadProject({width:320,height:180,scenes:[]});const c=document.createElement('canvas');c.width=320;c.height=180;const ctx=c.getContext('2d');ctx.fillStyle='#e02010';ctx.fillRect(0,0,320,180);const blob=await new Promise(r=>c.toBlob(r));const s=await e.addSource('image',{file:new File([blob],'red.png'),width:320,height:180,x:0,y:0});
 window.sample=()=>{e.renderNow();const o=document.createElement('canvas');o.width=320;o.height=180;const x=o.getContext('2d');x.drawImage(e.canvas,0,0);return [...x.getImageData(160,90,1,1).data]};
 const original=sample();e.updateSource(s.id,{filters:{grayscale:1}});const mono=sample();e.updateSource(s.id,{filters:{invert:1}});const inverse=sample();e.updateSource(s.id,{filters:{brightness:0}});const black=sample();e.updateSource(s.id,{filters:{brightness:1},animation:{type:'fade',duration:1000}});
 e.updateSource(s.id,{visible:false});const fade=e.fades.get(s.id);e.compositor.render(e.activeScene,e.runtimes,fade.start+fade.duration/2,e.fades);const output=document.createElement('canvas');output.width=320;output.height=180;const ox=output.getContext('2d');ox.drawImage(e.canvas,0,0);const half=[...ox.getImageData(160,90,1,1).data];
 e.updateSource(s.id,{visible:true,filters:{grayscale:1},animation:{type:'none'}});const beforeRecording=sample();await e.startRecording();await new Promise(r=>setTimeout(r,600));const recorded=await e.stopRecording();const v=document.createElement('video');const url=URL.createObjectURL(recorded);v.src=url;v.muted=true;await new Promise((r,j)=>{v.onloadeddata=r;v.onerror=j});const decoded={width:v.videoWidth,height:v.videoHeight,ready:v.readyState,time:v.currentTime,duration:v.duration};ox.clearRect(0,0,320,180);ox.drawImage(v,0,0);const video=[...ox.getImageData(160,90,1,1).data];await v.play();await new Promise(r=>setTimeout(r,100));ox.clearRect(0,0,320,180);ox.drawImage(v,0,0);const played=[...ox.getImageData(160,90,1,1).data];v.pause();URL.revokeObjectURL(url);return{original,mono,inverse,black,half,beforeRecording,video,played,decoded,recordedBytes:recorded.size};
 }''')
 print(json.dumps({'pixelProbe':pixels}),flush=True)
 assert pixels['original'][0]>210 and pixels['original'][1]<40,pixels
 assert max(pixels['mono'][:3])-min(pixels['mono'][:3])<3,pixels
 assert pixels['inverse'][0]<45 and pixels['inverse'][1]>200,pixels
 assert max(pixels['black'][:3])<3,pixels
 assert 100<pixels['half'][0]<130,pixels
 assert pixels['beforeRecording'][3]==255 and pixels['played'][3]==255,pixels
 assert 70<pixels['played'][0]<110 and max(pixels['played'][:3])-min(pixels['played'][:3])<12 and pixels['recordedBytes']>200,pixels
 for width,height in [(1440,900),(1024,768),(390,844),(320,568),(844,390),(390,400)]:
  page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(100);assert page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(width,height)
 page.set_viewport_size({'width':1440,'height':900});page.screenshot(path=str(OUT/'desktop.png'));assert not errors,errors
 print(json.dumps({'browser':engine,'edgeAndCornerDragging':True,'rotationAnchor':True,'escapeRollback':True,'keyboardSceneSourceEditing':True,'filtersAndAnimationPersisted':True,'gpuOutputAndRecordedPixels':pixels,'layouts':6,'errors':errors}));browser.close()
