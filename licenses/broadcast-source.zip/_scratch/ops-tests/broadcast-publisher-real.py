"""Ephemeral test-only HTTP WHIP receiver and real Chromium RTP transport proof."""
import asyncio
import json
import os
from pathlib import Path
from playwright.async_api import async_playwright
from websockets.asyncio.server import serve

ROOT = Path(__file__).resolve().parents[2] / 'toolbox-site'

async def main():
    receiver = None
    requests = []
    relay = {'bytes':0,'chunks':0,'start':None,'stop':False}
    async def relay_handle(socket):
        await socket.send('0{"sid":"real-test","upgrades":[],"pingInterval":25000,"pingTimeout":20000,"maxPayload":10000000}')
        binary_id = None
        async for packet in socket:
            if isinstance(packet,bytes):
                assert binary_id is not None
                if relay['chunks']==0:assert packet[:4]==b'\x1aE\xdf\xa3', 'real MediaRecorder WebM EBML header missing'
                relay['chunks']+=1
                relay['bytes']+=len(packet)
                await socket.send('43'+binary_id+'[]')
                binary_id=None
            elif packet=='40':await socket.send('40{"sid":"real-test"}')
            elif packet.startswith('42'):
                index=packet.index('[')
                event=json.loads(packet[index:])
                if event[0]=='start':
                    relay['start']=event[1]
                    await socket.send('43'+packet[2:index]+'[]')
                elif event[0]=='stop':relay['stop']=True
            elif packet.startswith('451-'):
                index=packet.index('[')
                binary_id=packet[4:index]
                event=json.loads(packet[index:])
                assert event==['binarystream',{'_placeholder':True,'num':0}]
    async def handle(reader, writer):
        try:
            header = await reader.readuntil(b'\r\n\r\n')
            lines = header.decode().split('\r\n')
            method, path, _ = lines[0].split(' ')
            headers = dict(line.split(': ', 1) for line in lines[1:] if ': ' in line)
            body = await reader.readexactly(int(headers.get('Content-Length', '0')))
            requests.append((method, path))
            status = '200 OK'
            extra = ''
            content_type = 'text/html'
            data = b'<!doctype html><html><body>Transport test</body></html>'
            if method == 'OPTIONS':
                status = '204 No Content'
                data = b''
            elif method == 'POST' and path == '/whip':
                answer = await receiver.evaluate('''async sdp => {
                    window.pc = new RTCPeerConnection({iceServers:[]});
                    window.video = document.createElement('video'); video.autoplay=true; video.muted=true;
                    document.body.append(video);
                    pc.ontrack=e=>{video.srcObject=e.streams[0] || new MediaStream([e.track]);};
                    await pc.setRemoteDescription({type:'offer',sdp});
                    for(const t of pc.getTransceivers()) t.direction='recvonly';
                    await pc.setLocalDescription(await pc.createAnswer());
                    if(pc.iceGatheringState!=='complete') await new Promise(resolve=>{
                        pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete')resolve();});
                    });
                    return pc.localDescription.sdp;
                }''', body.decode())
                status = '201 Created'
                content_type = 'application/sdp'
                extra = 'Location: /session/1\r\n'
                data = answer.encode()
            elif method == 'DELETE' and path == '/session/1':
                await receiver.evaluate('pc.close()')
                status = '204 No Content'
                data = b''
            elif path == '/publisher.js':
                content_type = 'text/javascript'
                data = (ROOT / 'tools/broadcast/publisher.js').read_bytes()
            cors='Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: OPTIONS, POST, DELETE\r\nAccess-Control-Allow-Headers: Content-Type, Authorization\r\nAccess-Control-Expose-Headers: Location, Link\r\nAccess-Control-Allow-Private-Network: true\r\n'
            writer.write(f'HTTP/1.1 {status}\r\nContent-Type: {content_type}\r\nContent-Length: {len(data)}\r\n{cors}{extra}Connection: close\r\n\r\n'.encode()+data)
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()

    server = await asyncio.start_server(handle, '127.0.0.1', 0)
    relay_server = await serve(relay_handle,'127.0.0.1',0)
    origin = f'http://127.0.0.1:{server.sockets[0].getsockname()[1]}'
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            receiver = await browser.new_page()
            await receiver.goto(origin)
            publisher = await browser.new_page()
            publisher.on('console',lambda message:print('browser:',message.text,flush=True)if message.type=='error'else None)
            publisher_origin=os.getenv('BROADCAST_PUBLISHER_ORIGIN',origin)
            if publisher_origin.startswith('https:'):
                await publisher.context.grant_permissions(['local-network-access'],origin=publisher_origin)
                await publisher.route('**/tools/broadcast/publisher.js*',lambda route:route.fulfill(content_type='text/javascript',body=(ROOT/'tools/broadcast/publisher.js').read_text(encoding='utf8')))
            await publisher.goto(publisher_origin)
            await asyncio.wait_for(publisher.evaluate('''async ({origin,module})=>{
                const {BroadcastPublisher}=await import(module);
                const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;
                const ctx=canvas.getContext('2d');let frame=0;
                window.paint=setInterval(()=>{ctx.fillStyle=`hsl(${frame++%360} 80% 50%)`;ctx.fillRect(0,0,640,360);ctx.fillStyle='white';ctx.font='40px sans-serif';ctx.fillText('Real RTP '+frame,40,100);},33);
                window.stream=canvas.captureStream(30);
                window.pub=new BroadcastPublisher();
                await pub.start(stream,{mode:'whip',endpoint:origin+'/whip',fps:30,videoBitsPerSecond:700000});
            }''', {'origin':origin,'module':'/tools/broadcast/publisher.js?http-test'if publisher_origin.startswith('https:')else'/publisher.js'}),timeout=35)
            await publisher.wait_for_timeout(2800)
            published = await publisher.evaluate('pub.getStats()')
            received = await receiver.evaluate('''async()=>{
                const stats=await pc.getStats();let bytes=0,frames=0;
                stats.forEach(s=>{if(s.type==='inbound-rtp'&&s.kind==='video'){bytes+=s.bytesReceived||0;frames+=s.framesDecoded||0;}});
                return {bytes,frames,state:pc.connectionState,width:video.videoWidth,height:video.videoHeight};
            }''')
            assert published['state']=='live', published
            assert published['bitrateKbps']>0, published
            assert received['bytes']>0 and received['frames']>10 and received['width']>=160, received
            await publisher.evaluate('pub.stop()')
            assert ('DELETE','/session/1') in requests, requests
            assert await publisher.evaluate('stream.getVideoTracks()[0].readyState')=='live'
            await publisher.evaluate('clearInterval(paint);stream.getTracks().forEach(t=>t.stop())')
            if publisher_origin.startswith('https:'):
                print(json.dumps({'httpsPage':publisher_origin,'httpEndpoint':origin+'/whip','published':published,'received':received,'deleteSession':True,'sourcePreserved':True},ensure_ascii=False,indent=2))
                await browser.close()
                return
            await publisher.evaluate('''async relayURL=>{
                const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;
                const ctx=canvas.getContext('2d');let n=0;
                window.paint=setInterval(()=>{ctx.fillStyle=`hsl(${n++%360} 80% 50%)`;ctx.fillRect(0,0,640,360)},33);
                window.stream=canvas.captureStream(30);
                await pub.start(stream,{mode:'rtmp',relayURL,address:'rtmp://test.invalid/live',key:'test-only',fps:30});
            }''',f'ws://127.0.0.1:{relay_server.sockets[0].getsockname()[1]}')
            await publisher.wait_for_timeout(1200)
            relay_stats=await publisher.evaluate('pub.getStats()')
            assert relay_stats['state']=='live' and relay_stats['delivery']=='relay'
            assert relay['bytes']>2000 and relay['chunks']>2, relay
            assert relay['start']['rtmp']=='rtmp://test.invalid/live/test-only'
            await publisher.evaluate('pub.stop();clearInterval(paint);stream.getTracks().forEach(t=>t.stop())')
            await publisher.wait_for_timeout(100)
            assert relay['stop'], relay
            print(json.dumps({'published':published,'received':received,'deleteSession':True,'sourcePreserved':True,'relayMedia':{'bytes':relay['bytes'],'chunks':relay['chunks'],'webmHeader':True,'stop':True,'stats':relay_stats}},ensure_ascii=False,indent=2))
            await browser.close()
    finally:
        server.close()
        await server.wait_closed()
        relay_server.close()
        await relay_server.wait_closed()

if __name__ == '__main__':
    asyncio.run(main())
