"""Real Edge -> SRS WHIP bitrate characterization; isolated test streams only."""
import asyncio,json,os,time,urllib.request,statistics,subprocess
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 rows=[];errors=[]
 async with async_playwright() as p:
  browser=await p.chromium.launch(channel='msedge',headless=False,args=['--window-position=-32000,-32000'])
  context=await browser.new_context()
  if BASE.startswith('https:'):await context.grant_permissions(['local-network-access'],origin=BASE)
  try:
   for variant in os.getenv('BITRATE_VARIANTS','baseline,motion,start').split(','):
    page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
    if variant=='old':
     baseline=subprocess.check_output(['git','show','6aa3067fa9325e9a0a7821a8e470b82f74e6fb52:tools/broadcast/low-latency.js'],cwd=ROOT/'_scratch/masaka5-toolbox-upstream')
     await page.route('**/low-latency.js*',lambda route:route.fulfill(body=baseline,content_type='text/javascript'))
    await page.goto(BASE+'/tools/broadcast/');await page.wait_for_function('broadcastApp.engine?.compositor')
    name='codex-bitrate-'+str(int(time.time()))
    await page.evaluate('''async ({variant,name,pipeline,target,block})=>{
     const Native=RTCPeerConnection;window.RTCPeerConnection=class extends Native{constructor(c){super(c);window.peer=this;}};
     const realFetch=fetch;window.signals={};window.fetch=async(u,o)=>{if(o?.method==='POST'&&o.headers?.['Content-Type']==='application/sdp'){
      if(variant==='start')o={...o,body:o.body.replace(/a=fmtp:(\\d+) ([^\\r\\n]+)/g,(line,id,fmt)=>/profile-level-id/.test(fmt)?line+';x-google-start-bitrate=4000;x-google-max-bitrate=8000':line)};
      signals.offer=o.body;const r=await realFetch(u,o);signals.answer=await r.clone().text();return r;
     }return realFetch(u,o);};
     const c=document.createElement('canvas');c.width=1920;c.height=1080;document.body.append(c);c.style.width='480px';const x=c.getContext('2d');
     const tile=document.createElement('canvas');tile.width=512;tile.height=512;const tx=tile.getContext('2d'),d=tx.createImageData(512,512);let seed=7;
     for(let i=0;i<d.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;d.data[i]=seed&255;d.data[i+1]=(seed>>>8)&255;d.data[i+2]=(seed>>>16)&255;d.data[i+3]=255;}tx.putImageData(d,0,0);
     if(block>1){const small=document.createElement('canvas');small.width=small.height=512/block;small.getContext('2d').drawImage(tile,0,0,small.width,small.height);tx.imageSmoothingEnabled=false;tx.drawImage(small,0,0,512,512);}
     const pattern=x.createPattern(tile,'repeat');window.phase='static';let n=0,last=0;
     const paint=t=>{if(t-last>=15){last=t;if(phase==='static'){x.fillStyle='#223549';x.fillRect(0,0,c.width,c.height);x.fillStyle='white';x.font='64px sans-serif';x.fillText('Static test',80,100);}else{x.save();x.translate((n*17)%512,(n*11)%512);x.fillStyle=pattern;x.fillRect(-512,-512,c.width+1024,c.height+1024);x.restore();n++;} }window.paint=requestAnimationFrame(paint);};paint(0);
     window.stream=c.captureStream(60);if(variant==='motion')stream.getVideoTracks()[0].contentHint='motion';
     window.out=stream;if(pipeline==='engine'){window.e=broadcastApp.engine;await e.loadProject({width:2560,height:1440,fps:60});await e.addSource('camera',{stream,width:2560,height:1440});await e.resumeAudio();out=e.getPublishStream();}
     const {BroadcastPublisher}=await import('/tools/broadcast/publisher.js');window.pub=new BroadcastPublisher();
     await pub.start(out,{mode:'whip',endpoint:'http://127.0.0.1:1985/rtc/v1/whip/?app=live&stream='+name,fps:60,width:1920,height:1080,videoBitsPerSecond:target});
    }''',{'variant':variant,'name':name,'pipeline':os.getenv('BITRATE_PIPELINE','direct'),'target':int(os.getenv('BITRATE_TARGET','8000000')),'block':int(os.getenv('BITRATE_BLOCK','1'))})
    receiver=await context.new_page();await receiver.goto('http://127.0.0.1:1985/api/v1/versions')
    await receiver.evaluate('''async name=>{window.pc=new RTCPeerConnection({iceServers:[]});window.video=document.createElement('video');video.autoplay=true;video.muted=true;video.srcObject=new MediaStream();document.body.append(video);pc.ontrack=e=>video.srcObject.addTrack(e.track);pc.addTransceiver('video',{direction:'recvonly'});pc.addTransceiver('audio',{direction:'recvonly'});await pc.setLocalDescription(await pc.createOffer());if(pc.iceGatheringState!=='complete')await new Promise(r=>pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete')r()}));const response=await fetch('/rtc/v1/whep/?app=live&stream='+name,{method:'POST',headers:{'Content-Type':'application/sdp'},body:pc.localDescription.sdp});if(response.status!==201)throw Error('WHEP HTTP '+response.status);window.session=response.headers.get('Location');await pc.setRemoteDescription({type:'answer',sdp:await response.text()});await video.play();}''',name)
    started=time.monotonic();samples=[];previous=None
    duration=int(os.getenv('BITRATE_SECONDS','28'))
    while time.monotonic()-started<duration:
     await asyncio.sleep(2);elapsed=time.monotonic()-started
     if elapsed>=8:await page.evaluate("phase='motion'")
     sent=await page.evaluate('''async()=>{const r=await peer.getStats();let v={},pair={};r.forEach(s=>{if(s.type==='outbound-rtp'&&s.kind==='video')v={target:s.targetBitrate,bytes:s.bytesSent,frames:s.framesEncoded,fps:s.framesPerSecond,qp:s.qpSum,quality:s.qualityLimitationReason,encoder:s.encoderImplementation};if(s.type==='candidate-pair'&&s.nominated)pair={available:s.availableOutgoingBitrate,rtt:s.currentRoundTripTime};});return{pub:pub.getStats(),v,pair,parameters:peer.getSenders().find(s=>s.track?.kind==='video').getParameters()};}''')
     with urllib.request.urlopen('http://127.0.0.1:1985/api/v1/streams/',timeout=5) as response:server=next((s for s in json.load(response)['streams'] if s['name']==name),{})
     now=time.monotonic();recv=server.get('recv_bytes',0);server_kbps=None if previous is None else round((recv-previous[1])*8/(now-previous[0])/1000);previous=(now,recv)
     received=await receiver.evaluate('''async()=>{let v={};(await pc.getStats()).forEach(s=>{if(s.type==='inbound-rtp'&&s.kind==='video')v={frames:s.framesDecoded,fps:s.framesPerSecond,dropped:s.framesDropped,lost:s.packetsLost,freeze:s.freezeCount,freezeDuration:s.totalFreezesDuration,width:s.frameWidth,height:s.frameHeight};});return{state:pc.connectionState,video:v};}''')
     sample={'seconds':round(elapsed,1),'phase':'motion' if elapsed>10 else 'static','sender':sent,'receiver':received,'serverKbps':server_kbps,'serverFrames':server.get('video_frames')};samples.append(sample)
     print(json.dumps({'variant':variant,'sec':sample['seconds'],'phase':sample['phase'],'kbps':sent['pub']['bitrateKbps'],'target':sent['v'].get('target'),'available':sent['pair'].get('available'),'quality':sent['v'].get('quality'),'fps':sent['v'].get('fps'),'serverKbps':server_kbps}),flush=True)
    signals=await page.evaluate('signals');rows.append({'variant':variant,'samples':samples,'signals':signals})
    assert all(s['receiver']['video'].get('frames',0)>0 for s in samples if s['seconds']>5),samples[-1]
    assert all(z['receiver']['video']['frames']>a['receiver']['video']['frames'] for a,z in zip(samples,samples[1:])),samples
    await page.evaluate('async()=>{await pub.stop();cancelAnimationFrame(paint);stream.getTracks().forEach(t=>t.stop());if(window.e)e.releasePublishStream();}');await receiver.evaluate("pc.close();if(session)fetch(session,{method:'DELETE'})");await receiver.close();await page.close()
  finally:await browser.close()
 report=ROOT/'_scratch'/os.getenv('BITRATE_REPORT','broadcast-bitrate-before.json');report.write_text(json.dumps({'errors':errors,'runs':rows},indent=2),encoding='utf8')
 assert not errors,errors
 print(json.dumps({'report':str(report),'medians':{r['variant']:statistics.median(s['sender']['pub']['bitrateKbps'] for s in r['samples'] if s['seconds']>14) for r in rows}}))
asyncio.run(main())
