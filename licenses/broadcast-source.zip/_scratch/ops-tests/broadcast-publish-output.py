import json,os
from playwright.sync_api import sync_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
with sync_playwright()as p:
 name=os.getenv('BROADCAST_BROWSER','chromium');b=p.firefox.launch()if name=='firefox'else p.chromium.launch(**({'channel':'msedge'}if name=='edge'else{}));page=b.new_page();page.goto(BASE+'/tools/broadcast/');page.wait_for_function('broadcastApp.engine?.compositor')
 result=page.evaluate('''async()=>{
 const e=broadcastApp.engine;await e.loadProject({width:2560,height:1440,fps:60});
 if(typeof e.getPublishStream!=='function')throw Error('Missing dedicated publishing output');
 const source=await e.addSource('text',{text:'实时推流',width:1000,height:200});
 const publish=e.getPublishStream({realtime:true}),video=publish.getVideoTracks()[0];
 if(e.publishCompositor.gpu)throw Error('Plain text overlay must not force GPU readback for the full scene');
 const recording=e.getOutputStream(),original=recording.getVideoTracks()[0];
 if(video.id===original.id)throw Error('Publishing and recording outputs must be independent');
 if(video.getSettings().width!==1920||video.getSettings().height!==1080)throw Error('Realtime output is not 1080p');
 if(original.getSettings().width!==2560||e.canvas.width!==2560)throw Error('Canvas or recording dimensions changed');
 e.createScene('second');if(e.getPublishStream().getVideoTracks()[0].id!==video.id)throw Error('Publishing track changed with scene');
 await e.startRecording();await new Promise(r=>setTimeout(r,500));const blob=await e.stopRecording();
 e.releasePublishStream();if(video.readyState!=='ended'||original.readyState!=='live')throw Error('Track ownership violation');
 return{recordedBytes:blob.size,canvas:[e.canvas.width,e.canvas.height],publishEnded:video.readyState,recordingTrack:original.readyState};
 }''');assert result['recordedBytes']>200,result;print(json.dumps(result));b.close()
