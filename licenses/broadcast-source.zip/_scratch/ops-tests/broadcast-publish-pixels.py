"""Compare dedicated publishing pixels with original GPU output, including effects."""
import json,os
from playwright.sync_api import sync_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'/tools/broadcast/');page.wait_for_function('broadcastApp.engine?.compositor')
 result=page.evaluate('''async()=>{
 const e=broadcastApp.engine;await e.loadProject({width:640,height:360,fps:30});
 const asset=document.createElement('canvas');asset.width=320;asset.height=180;const a=asset.getContext('2d');a.fillStyle='#00ff00';a.fillRect(0,0,160,180);a.fillStyle='#ff0000';a.fillRect(160,0,160,180);
 const blob=await new Promise(r=>asset.toBlob(r)),s=await e.addSource('image',{file:new File([blob],'pixels.png'),width:400,height:280,x:80,y:30});e.getPublishStream();
 const read=c=>{const out=document.createElement('canvas');out.width=c.width;out.height=c.height;const x=out.getContext('2d');x.drawImage(c,0,0);return x.getImageData(0,0,out.width,out.height).data;},rows=[];
 for(const[name,patch]of [['contain',{}],['cover',{fit:'cover'}],['rotate',{rotation:23,opacity:.6}],['filter',{filters:{invert:.5,brightness:1.1}}],['chroma',{filters:{},chromaKey:true,rotation:0,opacity:1}]]){
  e.updateSource(s.id,patch);e.renderNow();const main=read(e.canvas),publish=read(e.publishCanvas);let bad=0,total=0;for(let i=0;i<main.length;i+=4){let diff=0;for(let j=0;j<3;j++){diff+=Math.abs(main[i+j]-publish[i+j]);total+=Math.abs(main[i+j]-publish[i+j]);}if(diff>45)bad++;}const fraction=bad/(main.length/4);if(fraction>.025)throw Error(name+' output mismatch '+fraction);rows.push({name,badFraction:fraction,averageError:total/(main.length/4*3)});
 }
 e.updateSource(s.id,{chromaKey:false,visible:false});const title=await e.addSource('text',{text:'中文直播测试',x:40,y:80,width:500,height:100,background:'#223344'});e.renderNow();const main=read(e.canvas),publish=read(e.publishCanvas);let bad=0;for(let i=0;i<main.length;i+=4)if(Math.abs(main[i]-publish[i])+Math.abs(main[i+1]-publish[i+1])+Math.abs(main[i+2]-publish[i+2])>60)bad++;if(bad/(main.length/4)>.02)throw Error('Text differs');
 e.updateSource(title.id,{animation:{type:'fade',duration:1000}});e.previewFade(title.id,'out');e.renderNow();if(!e.fades.has(title.id))throw Error('Fade missing');
 e.releasePublishStream();return{pixels:rows,text:true,fade:true};
 }''');assert not errors,errors;print(json.dumps(result));b.close()
