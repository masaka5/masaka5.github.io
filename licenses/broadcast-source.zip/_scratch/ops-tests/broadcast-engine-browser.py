"""Native browser capture, GPU chroma, layer ordering, stable tracks and recording."""
import asyncio, json, os
from playwright.async_api import async_playwright

BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--autoplay-policy=no-user-gesture-required'])
  page=await browser.new_page(); errors=[]
  page.on('pageerror',lambda error:errors.append(str(error)))
  await page.goto(BASE+'/tools/broadcast/broadcast-core.js')
  await page.evaluate('''async()=>{
    const {BroadcastEngine}=await import('/tools/broadcast/engine.js');
    const canvas=document.createElement('canvas');document.body.replaceChildren(canvas);
    window.completed=[];
    window.engine=new BroadcastEngine({canvas,onRecordingReady:(blob,meta)=>completed.push({blob,meta}),onError:error=>{window.engineErrors ||= [];window.engineErrors.push(error.message)}});
    await engine.initialize();engine.setOutput({width:640,height:360,fps:30});
    const asset=document.createElement('canvas');asset.width=640;asset.height=360;
    const ctx=asset.getContext('2d');ctx.fillStyle='#00ff00';ctx.fillRect(0,0,320,360);ctx.fillStyle='#ff0000';ctx.fillRect(320,0,320,360);
    const blob=await new Promise(r=>asset.toBlob(r));
    window.image=await engine.addSource('image',{file:new File([blob],'key-test.png'),chromaKey:true});engine.renderNow();
    window.pixel=(x,y)=>{const c=document.createElement('canvas');c.width=640;c.height=360;const c2=c.getContext('2d');c2.drawImage(canvas,0,0);return [...c2.getImageData(x,y,1,1).data]};
  }''')
  pixels=await page.evaluate('({green:pixel(100,180),red:pixel(500,180)})')
  assert pixels['green'][1]<30,pixels
  assert pixels['red'][0]>240 and pixels['red'][1]<20,pixels
  output=await page.evaluate('''async()=>{
    const stream=engine.getOutputStream();window.videoId=stream.getVideoTracks()[0].id;
    const main=engine.activeScene.id;const other=engine.createScene('另一场景');engine.switchScene(main);
    const camera=await engine.addSource('camera',{width:320,height:180,x:0,y:0});window.cameraId=camera.id;
    const mic=await engine.addSource('microphone');window.micId=mic.id;
    const cameraTrack=engine.runtimes.get(camera.id).stream.getVideoTracks()[0];window.captureId=cameraTrack.id;
    engine.switchScene(other.id);window.inactiveGain=engine.runtimes.get(mic.id).gainNode.gain.value;
    engine.switchScene(main);engine.updateSource(mic.id,{muted:true});window.mutedTarget=engine.getSource(mic.id).muted;
    engine.updateSource(mic.id,{muted:false,gain:.6});
    const stable=engine.getOutputStream().getVideoTracks()[0].id===videoId && engine.runtimes.get(camera.id).stream.getVideoTracks()[0].id===captureId;
    await engine.startRecording();return {stable,video:stream.getVideoTracks().length,audio:stream.getAudioTracks().length};
  }''')
  assert output=={'stable':True,'video':1,'audio':1},output
  await page.wait_for_timeout(1800)
  result=await page.evaluate('''async()=>{
    const stats={...engine.stats};const blob=await engine.stopRecording();
    const preview=document.createElement('video');preview.muted=true;preview.src=URL.createObjectURL(blob);
    await new Promise((resolve,reject)=>{preview.onloadeddata=resolve;preview.onerror=reject;});
    const decoded={width:preview.videoWidth,height:preview.videoHeight};await preview.play();
    await new Promise((resolve,reject)=>{preview.onended=resolve;setTimeout(()=>reject(new Error('Recorded WebM did not play to its end')),6000)});
    URL.revokeObjectURL(preview.src);
    const clip=await engine.addSource('video',{file:new File([blob],'recorded.webm',{type:blob.type})});
    engine.setSourcePaused(clip.id,true);engine.updateSource(clip.id,{x:12,width:300});await engine.resumeAudio();
    const pausePersisted=engine.getSource(clip.id).paused && engine.runtimes.get(clip.id).element.paused;
    engine.deleteSource(clip.id);
    const cameraTrack=engine.runtimes.get(cameraId).stream.getVideoTracks()[0];
    engine.deleteSource(cameraId);const released=cameraTrack.readyState==='ended';
    const count=engine.exportAssets().length;const snapshot=engine.snapshot();await engine.loadProject(snapshot);
    const restored=engine.getSourceStatus(image.id).status;const recorded={bytes:blob.size,type:blob.type};
    const callbacks={count:completed.length,sameBlob:completed[0]?.blob===blob,bytes:completed[0]?.meta.bytes};
    const beforeInvalid=engine.snapshot();let invalidRejected=false;
    const corrupt=engine.snapshot();corrupt.scenes[0].sources[0].assetId='corrupt';engine.setAsset('corrupt',new Blob(['bad'],{type:'image/png'}));
    try{await engine.loadProject(corrupt)}catch{invalidRejected=true}
    const invalidPreserved=JSON.stringify(beforeInvalid)===JSON.stringify(engine.snapshot()) && engine.getSourceStatus(image.id).status==='ready';
    const marquee=await engine.addSource('text',{text:'ABCDEFGHIJKLMNOPQRSTUVWXYZ THE END',x:0,y:0,width:100,height:70,fontSize:32,scrollSpeed:80});
    engine.renderNow();const cached=engine.compositor.cache.get(marquee.id);const marqueeSpan=cached.textCanvas.width;
    engine.updateSource(image.id,{visible:false});engine.updateSource(marquee.id,{text:' '.repeat(2500)+'END'});
    const measure=document.createElement('canvas').getContext('2d');measure.font='bold 32px sans-serif';
    engine.compositor.render(engine.activeScene,engine.runtimes,(measure.measureText(' '.repeat(2500)).width-4)/80*1000);
    let visibleSuffixPixels=0;for(let x=0;x<100;x+=2)for(let y=12;y<60;y+=2){const p=pixel(x,y);if(p[0]>200&&p[1]>200&&p[2]>200)visibleSuffixPixels++;}
    await engine.loadProject({});const resetAssets=engine.exportAssets().length;
    await engine.startRecording();await new Promise(resolve=>setTimeout(resolve,1400));const trackStates=engine.outputStream.getTracks().map(t=>({kind:t.kind,state:t.readyState,settings:t.getSettings()}));engine.recorder.stop();const automaticBlob=await engine.stopRecording();
    const automaticCallback={count:completed.length,sameBlob:completed[1]?.blob===automaticBlob,bytes:automaticBlob.size,trackStates};
    preview.src=URL.createObjectURL(automaticBlob);await new Promise((resolve,reject)=>{preview.onloadeddata=resolve;preview.onerror=reject});await preview.play();
    await new Promise((resolve,reject)=>{preview.onended=resolve;setTimeout(()=>reject(new Error('Static recording did not play to its end')),6000)});URL.revokeObjectURL(preview.src);
    const idleFrames=engine.stats.frames;await new Promise(resolve=>setTimeout(resolve,500));const idleExtraFrames=engine.stats.frames-idleFrames;
    engine.renderNow();await engine.dispose();return {stats,recorded,decoded,released,assetCount:count,restored,callbacks,automaticCallback,idleExtraFrames,pausePersisted,invalidRejected,invalidPreserved,marqueeSpan,visibleSuffixPixels,resetAssets,mutedTarget:window.mutedTarget,errors:window.engineErrors||[]};
  }''')
  assert result['recorded']['bytes']>1000,result
  assert result['recorded']['type'].startswith('video/'),result
  assert result['released'] and result['restored']=='ready',result
  assert result['decoded']=={'width':640,'height':360} and result['mutedTarget'],result
  assert result['callbacks']=={'count':1,'sameBlob':True,'bytes':result['recorded']['bytes']},result
  assert result['resetAssets']==0 and result['invalidRejected'] and result['invalidPreserved'],result
  assert result['marqueeSpan']>500,result
  assert result['visibleSuffixPixels']>10,result
  assert result['pausePersisted'] and result['automaticCallback']['count']==2 and result['automaticCallback']['sameBlob'] and result['automaticCallback']['bytes']>0,result
  assert result['idleExtraFrames']==0,result
  assert result['stats']['fps']>=15,result
  assert result['stats']['audioLevels'][await page.evaluate('micId')]>0,result
  assert not result['errors'] and not errors,(result,errors)
  print(json.dumps({'gpuChromaPixels':pixels,'output':output,'result':result},ensure_ascii=False))
  await browser.close()

asyncio.run(main())
