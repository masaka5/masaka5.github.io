"""Optical sender-to-decoded-video age; no receiver latency hints or browser flags."""
import asyncio,json,os,time
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]
SOURCE=Path(os.getenv('BROADCAST_SOURCE_DIR',str(ROOT/'toolbox-site/tools/broadcast')))
async def main():
 receiver=None;requests=[]
 async def handle(reader,writer):
  try:
   raw=await reader.readuntil(b'\r\n\r\n');lines=raw.decode().split('\r\n');method,path,_=lines[0].split(' ');headers=dict(line.lower().split(': ',1)for line in lines[1:]if': 'in line)
   body=await reader.readexactly(int(headers.get('content-length','0')));path=urlsplit(path).path
   status='200 OK';extra='';kind='text/html';data=b'<!doctype html><body></body>'
   if method=='OPTIONS':status='204 No Content';data=b''
   elif method=='POST':
    answer=await receiver.evaluate('''async sdp=>{
     window.peer=new RTCPeerConnection({iceServers:[]});window.video=document.createElement('video');video.autoplay=true;video.muted=true;video.playsInline=true;document.body.append(video);window.ages=[];
     const c=document.createElement('canvas');c.width=32;c.height=2;const x=c.getContext('2d',{willReadFrequently:true});
     const frame=()=>{if(video.videoWidth){x.drawImage(video,0,0,video.videoWidth,video.videoHeight/8,0,0,32,2);const d=x.getImageData(0,0,32,2).data;let stamp=0,valid=true;for(let i=0;i<32;i++){const bit=d[i*4]>128?1:0;if(bit===(d[(i+32)*4]>128?1:0))valid=false;stamp=(stamp*2+bit)>>>0;}const age=((Date.now()>>>0)-stamp)>>>0;if(valid&&age<10000)ages.push(age);}video.requestVideoFrameCallback(frame);};video.requestVideoFrameCallback(frame);
     peer.ontrack=e=>{video.srcObject=e.streams[0]||new MediaStream([e.track]);};await peer.setRemoteDescription({type:'offer',sdp});for(const t of peer.getTransceivers())t.direction='recvonly';await peer.setLocalDescription(await peer.createAnswer());if(peer.iceGatheringState!=='complete')await new Promise(r=>peer.addEventListener('icegatheringstatechange',()=>{if(peer.iceGatheringState==='complete')r()}));return peer.localDescription.sdp;
    }''',body.decode());data=answer.encode();status='201 Created';kind='application/sdp';extra='Location: /session\r\n'
   elif method=='DELETE':await receiver.evaluate('peer.close();video.remove()');status='204 No Content';data=b''
   elif path.endswith('.js'):
    file=SOURCE/Path(path).name;data=file.read_bytes();kind='text/javascript'
   writer.write(f'HTTP/1.1 {status}\r\nContent-Type: {kind}\r\nContent-Length: {len(data)}\r\n{extra}Connection: close\r\n\r\n'.encode()+data);await writer.drain()
  finally:writer.close();await writer.wait_closed()
 server=await asyncio.start_server(handle,'127.0.0.1',0);origin=f'http://127.0.0.1:{server.sockets[0].getsockname()[1]}'
 try:
  async with async_playwright()as p:
   name=os.getenv('BROADCAST_BROWSER','chromium');browser=await(p.firefox.launch()if name=='firefox'else p.chromium.launch(**({'channel':'msedge'}if name=='edge'else{})))
   receiver=await browser.new_page();await receiver.goto(origin);sender=await browser.new_page();await sender.goto(origin);results=[]
   scenarios=json.loads(os.getenv('BROADCAST_SCENARIOS','[["engine",1280,720,30],["engine",2560,1440,60]]'))
   for mode,width,height,fps in scenarios:
    await sender.evaluate('''async({mode,width,height,fps})=>{
     const Native=window.NativePeer||RTCPeerConnection;window.NativePeer=Native;window.RTCPeerConnection=class extends Native{constructor(c){super(c);window.sendingPeer=this;}};
     const {BroadcastPublisher}=await import('/publisher.js');window.pub=new BroadcastPublisher();
     const c=document.createElement('canvas');c.width=width;c.height=height;const x=c.getContext('2d');let n=0;
     const paint=()=>{x.fillStyle='#223549';x.fillRect(0,0,width,height);x.fillStyle='#389aff';x.fillRect((n++*11)%(width-180),100,180,height/2);const stamp=Date.now()>>>0;for(let i=0;i<32;i++){const bit=(stamp>>>(31-i))&1;x.fillStyle=bit?'white':'black';x.fillRect(i*width/32,0,width/32,height/16);x.fillStyle=bit?'black':'white';x.fillRect(i*width/32,height/16,width/32,height/16);}window.paintId=requestAnimationFrame(paint);};paint();window.input=c.captureStream(fps);window.out=input;
     if(mode.startsWith('engine')){const {BroadcastEngine}=await import('/engine.js');window.e=new BroadcastEngine({canvas:document.createElement('canvas')});document.body.append(e.canvas);e.canvas.style.width='640px';await e.initialize();e.setOutput({width,height,fps});const source=await e.addSource('camera',{stream:input,width,height});if(mode.includes('text'))await e.addSource('text',{text:'低延迟直播测试',x:50,y:height/2,width:800,height:100});if(mode.includes('effect'))e.updateSource(source.id,{filters:{brightness:1.05}});out=e.getPublishStream?e.getPublishStream():e.getOutputStream();if(mode.includes('record'))await e.startRecording();}
     await pub.start(out,{mode:'whip',endpoint:location.origin+'/whip',fps,width,height,videoBitsPerSecond:12000000});
    }''',{'mode':mode,'width':width,'height':height,'fps':fps})
    await asyncio.sleep(float(os.getenv('BROADCAST_TEST_SECONDS','7')))
    decoded=await receiver.evaluate('''async()=>{const ages=window.ages.slice(Math.floor(window.ages.length/4)).sort((a,b)=>a-b),stats=await peer.getStats();let inbound={};stats.forEach(s=>{if(s.type==='inbound-rtp'&&s.kind==='video')inbound={frames:s.framesDecoded,dropped:s.framesDropped,jitterMs:s.jitter*1000,jitterBufferMs:s.jitterBufferDelay/Math.max(1,s.jitterBufferEmittedCount)*1000,processingMs:s.totalProcessingDelay/Math.max(1,s.framesDecoded)*1000};});return{samples:ages.length,p50:ages[Math.floor(ages.length*.5)],p95:ages[Math.floor(ages.length*.95)],max:ages.at(-1),inbound};}''')
    sent=await sender.evaluate('''async()=>{const stats=await sendingPeer.getStats();let out={};stats.forEach(s=>{if(s.type==='outbound-rtp'&&s.kind==='video')out={frames:s.framesEncoded,fps:s.framesPerSecond,width:s.frameWidth,height:s.frameHeight,encodeMs:s.totalEncodeTime/Math.max(1,s.framesEncoded)*1000,packetQueueMs:s.totalPacketSendDelay/Math.max(1,s.packetsSent)*1000,quality:s.qualityLimitationReason,encoder:s.encoderImplementation,codec:stats.get(s.codecId)?.mimeType};});return{rtp:out,publisher:pub.getStats(),parameters:sendingPeer.getSenders().filter(s=>s.track?.kind==='video').map(s=>{const p=s.getParameters();return{encodings:p.encodings,degradationPreference:p.degradationPreference}}),renderMs:window.e?.stats.renderMs};}''')
    row={'browser':name,'mode':mode,'output':[width,height,fps],'decoded':decoded,'sender':sent};results.append(row);print(json.dumps(row),flush=True)
    assert decoded['samples']>10,row
    await sender.evaluate('''async()=>{await pub.stop();cancelAnimationFrame(paintId);input.getTracks().forEach(t=>t.stop());if(window.e){await e.dispose();e.canvas.remove();window.e=null;}}''')
   output=ROOT/'_scratch'/os.getenv('BROADCAST_REPORT','broadcast-latency-current.json');output.write_text(json.dumps(results,indent=2),encoding='utf8');await browser.close()
 finally:server.close();await server.wait_closed()
asyncio.run(main())
