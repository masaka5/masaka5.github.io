"""SRS WHIP -> WHEP soak, separate test stream. Real browser and no background-throttling flags."""
import asyncio,json,os,time,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2];BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765');NAME='codex-stability-'+str(int(time.time()))
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(channel='msedge',headless=False,args=['--window-position=-32000,-32000'],ignore_default_args=['--disable-background-timer-throttling','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows']);context=await b.new_context()
  if BASE.startswith('https:'):await context.grant_permissions(['local-network-access'],origin=BASE)
  sender=await context.new_page();errors=[];sender.on('pageerror',lambda e:errors.append(str(e)));await sender.goto(BASE+'/tools/broadcast/');await sender.wait_for_function('broadcastApp.engine?.compositor');rows=[]
  await sender.evaluate('''async name=>{const Native=RTCPeerConnection;window.RTCPeerConnection=class extends Native{constructor(c){super(c);window.sendingPeer=this;}};window.e=broadcastApp.engine;await e.loadProject({width:2560,height:1440,fps:60});window.title=await e.addSource('text',{text:'SRS 实时稳定性测试',width:1600,height:200});window.counter=await e.addSource('countdown',{duration:3600,x:100,y:600,width:800,height:200});window.events=[];const {BroadcastPublisher}=await import('/tools/broadcast/publisher.js');window.pub=new BroadcastPublisher({onState:s=>events.push(s),onRecoverVideo:()=>{e.renderNow();e._syncFrameClock();if(window.injectedSender){injectedSender.replaceTrack(e.publishStream.getVideoTracks()[0]);window.injectedSender=null;}}});await e.resumeAudio();await pub.start(e.getPublishStream({realtime:true}),{mode:'whip',endpoint:'http://127.0.0.1:1985/rtc/v1/whip/?app=live&stream='+name,width:2560,height:1440,fps:60,videoBitsPerSecond:8000000});}''',NAME)
  receiver=await context.new_page();await receiver.goto('http://127.0.0.1:1985/api/v1/versions')
  await receiver.evaluate('''async name=>{window.pc=new RTCPeerConnection({iceServers:[]});window.video=document.createElement('video');video.autoplay=true;video.muted=true;const stream=new MediaStream();video.srcObject=stream;document.body.append(video);pc.ontrack=e=>stream.addTrack(e.track);pc.addTransceiver('video',{direction:'recvonly'});pc.addTransceiver('audio',{direction:'recvonly'});await pc.setLocalDescription(await pc.createOffer());if(pc.iceGatheringState!=='complete')await new Promise(r=>pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete')r()}));const response=await fetch('/rtc/v1/whep/?app=live&stream='+name,{method:'POST',headers:{'Content-Type':'application/sdp'},body:pc.localDescription.sdp});if(response.status!==201)throw Error('WHEP HTTP '+response.status);window.session=response.headers.get('Location');await pc.setRemoteDescription({type:'answer',sdp:await response.text()});await video.play();}''',NAME)
  cdp=await b.new_browser_cdp_session();target=(await context.new_cdp_session(sender)).send;info=await target('Target.getTargetInfo');win=await cdp.send('Browser.getWindowForTarget',{'targetId':info['targetInfo']['targetId']});duration=int(os.getenv('BROADCAST_SOAK_SECONDS','120'));started=time.monotonic();minimized=False;restored=False;paused=False;recovered=False;injected=False
  ffmpeg='C:/Users/happyelements/AppData/Local/Programs/Open Design/resources/app/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
  decoder=await asyncio.create_subprocess_exec(ffmpeg,'-v','error','-nostats','-i','http://127.0.0.1:8080/live/'+NAME+'.flv','-t',str(duration-5),'-progress','pipe:1','-f','null','-',stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  try:
   while time.monotonic()-started<duration:
    elapsed=time.monotonic()-started
    if elapsed>10 and not minimized:await cdp.send('Browser.setWindowBounds',{'windowId':win['windowId'],'bounds':{'windowState':'minimized'}});minimized=True
    if elapsed>35 and not restored:await cdp.send('Browser.setWindowBounds',{'windowId':win['windowId'],'bounds':{'windowState':'normal'}});restored=True
    if elapsed>45 and not paused:await sender.evaluate("e.updateSource(counter.id,{visible:false});e.updateSource(title.id,{text:'静态画面心跳验证'})");paused=True
    if elapsed>65 and not recovered:await sender.evaluate("e.updateSource(counter.id,{visible:true});e.updateSource(title.id,{text:'恢复动态场景'})");recovered=True
    if os.getenv('BROADCAST_INJECT_STALL')=='1' and elapsed>85 and not injected:await sender.evaluate("window.injectedSender=sendingPeer.getSenders().find(s=>s.track?.kind==='video');injectedSender.replaceTrack(null)");injected=True
    await asyncio.sleep(2)
    send=await sender.evaluate('({stats:pub.getStats(),render:e.stats.renderMs,frames:e.stats.frames,events,heap:performance.memory?.usedJSHeapSize,clock:!!e._frameClock})')
    receive=await receiver.evaluate('''async()=>{let v={};(await pc.getStats()).forEach(s=>{if(s.type==='inbound-rtp'&&s.kind==='video')v={frames:s.framesDecoded,received:s.framesReceived,fps:s.framesPerSecond,freezeCount:s.freezeCount,freezeDuration:s.totalFreezesDuration,dropped:s.framesDropped,lost:s.packetsLost,keyframes:s.keyFramesDecoded,width:s.frameWidth,height:s.frameHeight,pli:s.pliCount};});return{state:pc.connectionState,time:video.currentTime,video:v};}''')
    with urllib.request.urlopen('http://127.0.0.1:1985/api/v1/streams/',timeout=5)as r:streams=json.load(r)['streams']
    server=next((s for s in streams if s['name']==NAME),{});row={'elapsed':round(elapsed,1),'sender':send,'receiver':receive,'server':{k:server.get(k)for k in ['video_frames','audio_frames','recv_bytes','publish']}};rows.append(row)
    if len(rows)%5==0:print(json.dumps(row),flush=True)
  finally:
   await sender.evaluate('pub.stop()');await sender.evaluate('e.releasePublishStream()');await receiver.evaluate("pc.close();if(window.session)fetch(session,{method:'DELETE'})");await b.close()
   try:decode_out,decode_err=await asyncio.wait_for(decoder.communicate(),timeout=8)
   except asyncio.TimeoutError:decoder.kill();decode_out,decode_err=await decoder.communicate()
  output=ROOT/'_scratch'/os.getenv('BROADCAST_SOAK_REPORT','broadcast-srs-stability.json');output.write_text(json.dumps({'stream':NAME,'errors':errors,'flvDecode':{'exit':decoder.returncode,'progress':decode_out.decode(errors='replace')[-1200:],'errors':decode_err.decode(errors='replace')},'samples':rows},indent=2),encoding='utf8');assert not errors,errors
  valid=[r for r in rows if r['elapsed']>5];assert all(r['receiver']['video'].get('frames',0)>0 for r in valid),valid[:3]
  stalls=[(a['elapsed'],z['elapsed'])for a,z in zip(valid,valid[1:])if z['receiver']['video'].get('frames',0)<=a['receiver']['video'].get('frames',0)and not(injected and 84<a['elapsed']<105)];assert not stalls,stalls
  assert not any(r['sender']['stats']['state']!='live'for r in valid if not(injected and 84<r['elapsed']<105)),[r['sender']['stats']for r in valid]
  if injected:assert 'stalled'in rows[-1]['sender']['events']and rows[-1]['sender']['stats']['state']=='live',rows[-1]
  assert decoder.returncode==0,(decoder.returncode,decode_err.decode(errors='replace'))
  print(json.dumps({'seconds':duration,'samples':len(rows),'noVideoStalls':True,'finalDecoded':rows[-1]['receiver']['video'],'errors':errors,'report':str(output)}))
asyncio.run(main())
