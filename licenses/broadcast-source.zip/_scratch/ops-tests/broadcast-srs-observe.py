"""Observe existing SRS stream without replacing its publisher; isolate WHEP/FLV receive metrics."""
import asyncio,json,os,time,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]
BASE='http://127.0.0.1:1985'
def request(path,data=None,method=None):
 req=urllib.request.Request(BASE+path,data=data,method=method,headers={'Content-Type':'application/sdp'}if data else{})
 with urllib.request.urlopen(req,timeout=12)as r:return r.status,dict(r.headers),r.read()
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(channel='msedge');page=await b.new_page();await page.goto(BASE+'/api/v1/versions')
  offer=await page.evaluate('''async()=>{window.pc=new RTCPeerConnection({iceServers:[]});window.video=document.createElement('video');video.autoplay=true;video.muted=true;document.body.append(video);const media=new MediaStream();video.srcObject=media;pc.ontrack=e=>media.addTrack(e.track);pc.addTransceiver('video',{direction:'recvonly'});pc.addTransceiver('audio',{direction:'recvonly'});await pc.setLocalDescription(await pc.createOffer());if(pc.iceGatheringState!=='complete')await new Promise(r=>pc.addEventListener('icegatheringstatechange',()=>{if(pc.iceGatheringState==='complete')r()}));return pc.localDescription.sdp;}''')
  status,headers,sdp=await asyncio.to_thread(request,'/rtc/v1/whep/?app=live&stream=livestream',offer.encode(),'POST');assert status==201,(status,sdp)
  location=headers.get('Location')or headers.get('location')
  await page.evaluate('sdp=>pc.setRemoteDescription({type:"answer",sdp})',sdp.decode());rows=[]
  try:
   for i in range(int(os.getenv('BROADCAST_OBSERVE_SECONDS','60'))//2):
    await asyncio.sleep(2)
    row=await page.evaluate('''async()=>{const report=await pc.getStats();let inbound;report.forEach(s=>{if(s.type==='inbound-rtp'&&s.kind==='video')inbound={framesReceived:s.framesReceived,framesDecoded:s.framesDecoded,framesDropped:s.framesDropped,freezeCount:s.freezeCount,totalFreezesDuration:s.totalFreezesDuration,bytesReceived:s.bytesReceived,packetsLost:s.packetsLost,nackCount:s.nackCount,pliCount:s.pliCount,keyFramesDecoded:s.keyFramesDecoded,frameWidth:s.frameWidth,frameHeight:s.frameHeight,framesPerSecond:s.framesPerSecond,jitterMs:s.jitter*1000};});return{state:pc.connectionState,time:video.currentTime,ready:video.readyState,inbound};}''')
    _,_,raw=await asyncio.to_thread(request,'/api/v1/streams/');streams=json.loads(raw)['streams'];s=next((s for s in streams if s['name']=='livestream'),{})
    row.update(at=time.time(),server={k:s.get(k)for k in ['id','video_frames','audio_frames','recv_bytes','clients','publish']});rows.append(row);print(json.dumps(row),flush=True)
  finally:
   await page.evaluate('pc.close()')
   if location:
    try:await asyncio.to_thread(request,location.replace(BASE,''),None,'DELETE')
    except Exception:pass
   await b.close()
  (ROOT/'_scratch/broadcast-srs-observe.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
asyncio.run(main())
