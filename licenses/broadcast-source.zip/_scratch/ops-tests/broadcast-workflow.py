import asyncio,json,os,base64
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--autoplay-policy=no-user-gesture-required']);page=await b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/broadcast/');await page.wait_for_function('broadcastApp.engine?.compositor')
  async def add(kind):await page.locator('#addSource').click();await page.locator('#add'+kind).click()
  png=await page.evaluate("()=>{const c=document.createElement('canvas');c.width=1280;c.height=720;const x=c.getContext('2d');x.fillStyle='#234f79';x.fillRect(0,0,1280,720);x.fillStyle='#88bbaa';x.fillRect(500,100,600,500);return c.toDataURL().split(',')[1]}")
  await page.locator('#imageFile').set_input_files({'name':'图片水印.png','mimeType':'image/png','buffer':base64.b64decode(png)})
  await page.wait_for_function("broadcastApp.engine.activeScene.sources.some(s=>s.type==='image')")
  await add('Text');await page.locator('#sourceText').fill('在线直播 · 中文测试');await page.locator('#sourceText').dispatch_event('change')
  await page.locator('[data-property-tab=effects]').click();await page.locator('#sourceScroll').fill('30');await page.locator('#sourceScroll').dispatch_event('change')
  await add('Mic');await page.wait_for_function("broadcastApp.engine.activeScene.sources.some(s=>s.type==='microphone')")
  await page.locator('#toggleRecording').click();await page.wait_for_function('broadcastApp.engine.recording');await page.wait_for_timeout(1800);await page.locator('#toggleRecording').click();await page.wait_for_function("document.querySelector('#notice').textContent==='录像已保存'")
  await page.locator('#openLibrary').click();await page.locator('.record-row').wait_for();assert await page.locator('.record-row').count()==1;await page.get_by_role('button',name='预览',exact=True).click();await page.wait_for_function("document.querySelector('#recordPreview').readyState>=2");assert await page.locator('#recordPreview').evaluate('e=>e.videoWidth')==1280
  await page.locator('#libraryDialog [data-close]').click()
  await page.wait_for_timeout(800);await page.reload();await page.wait_for_function("broadcastApp.engine?.activeScene.sources.length===3")
  assert await page.evaluate("broadcastApp.engine.activeScene.sources.filter(s=>s.type==='image').every(s=>broadcastApp.engine.getSourceStatus(s.id).status==='ready')")
  assert await page.evaluate("broadcastApp.engine.activeScene.sources.filter(s=>s.type==='microphone').every(s=>broadcastApp.engine.getSourceStatus(s.id).status==='idle')")
  await page.locator('#openLibrary').click();await page.locator('.record-row').wait_for();assert await page.locator('.record-row').count()==1;await page.locator('#libraryDialog [data-close]').click()
  await page.locator('#openProject').click()
  async with page.expect_download()as dl:await page.locator('#exportProject').click()
  project=Path(await(await dl.value).path()).read_bytes();assert b'toolbox-broadcast'in project
  await page.locator('#projectDialog [data-close]').click()
  await page.locator('#projectFile').set_input_files({'name':'直播.json','mimeType':'application/json','buffer':project});await page.wait_for_function("document.querySelector('#notice').textContent==='工程已导入'")
  await page.locator('#projectFile').set_input_files({'name':'坏.json','mimeType':'application/json','buffer':b'broken'});await page.wait_for_function("document.querySelector('#notice').dataset.error==='true'");assert await page.evaluate('broadcastApp.engine.activeScene.sources.length')==3
  await page.locator('#openStream').click();await page.locator('#streamMode').select_option('rtmp');await page.locator('#rtmpAddress').fill('rtmp://example.com/live');await page.locator('#rtmpKey').fill('SAMPLE-NOT-SAVED-SECRET');await page.locator('#startStreaming').click();await page.wait_for_function("document.querySelector('#notice').dataset.error==='true'");assert await page.evaluate("broadcastApp.publisher.getStats().state")=='idle'
  assert b'SAMPLE-NOT-SAVED-SECRET'not in project
  await page.locator('#streamDialog [data-close]').click();await page.screenshot(path='_scratch/broadcast-desktop.png')
  await page.set_viewport_size({'width':390,'height':844});await page.locator('[data-panel-tab=sources]').click();await page.screenshot(path='_scratch/broadcast-mobile.png')
  assert not errors,errors;print(json.dumps({'real_recording_playback':True,'asset_restore':True,'recording_restore':True,'permission_restore_explicit':True,'project_roundtrip':True,'invalid_preserves':True,'rtmp_requires_relay':True,'errors':errors}));await b.close()
asyncio.run(main())
