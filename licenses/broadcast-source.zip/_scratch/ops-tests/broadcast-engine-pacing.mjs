import test from 'node:test';
import assert from 'node:assert/strict';
import { BroadcastEngine } from '../../toolbox-site/tools/broadcast/engine.js';

for (const fps of [60,59.94,48,30,29.97,25,24,15]) {
  test(`${fps} fps cap consumes each 60 Hz presentation interval only once`,()=>{
    const engine=new BroadcastEngine({canvas:{}});
    engine.project.fps=fps;engine._sampleStart=0;engine._emit=()=>{};
    engine.activeScene.sources.push({type:'countdown',visible:true});
    engine.compositor={render:()=>true};
    let previous=0;
    for(let frame=1;frame<=600;frame++){
      // Rounded timestamps include the just-before-deadline cases seen on real 60 Hz displays.
      engine._tick(Math.round(frame*1000/60*10)/10);
      const count=engine.stats.frames;
      assert.ok(count-previous<=1,'one rAF must not render more than once');previous=count;
    }
    assert.ok(Math.abs(engine.stats.frames-fps*10)<=1,`expected ${fps*10} frames, got ${engine.stats.frames}`);
  });
}
test('a retained output track does not keep compositing an unchanged scene',()=>{
  const engine=new BroadcastEngine({canvas:{}});engine.project.fps=30;engine._emit=()=>{};
  let renders=0,captures=0;
  engine.compositor={render:()=>{renders++;return true}};
  engine.outputStream={};engine._canvasStream={getVideoTracks:()=>[{requestFrame:()=>captures++}]};
  for(let frame=1;frame<=120;frame++)engine._tick(frame*1000/60);
  assert.equal(renders,1);assert.ok(captures>=59&&captures<=61,`capture requests ${captures}`);
});

for(const [fps,hz]of [[60,144],[120,120],[48,120]]){
  test(`${fps} fps output on a ${hz} Hz display stays within its configured rate`,()=>{
    const engine=new BroadcastEngine({canvas:{}});engine.project.fps=fps;engine._sampleStart=0;engine._emit=()=>{};
    engine.activeScene.sources.push({type:'countdown',visible:true});engine.compositor={render:()=>true};
    for(let frame=1;frame<=hz*10;frame++)engine._tick(frame*1000/hz);
    assert.ok(Math.abs(engine.stats.frames-fps*10)<=1,`got ${engine.stats.frames}`);
  });
}
