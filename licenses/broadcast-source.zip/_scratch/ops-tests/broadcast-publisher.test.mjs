import test from 'node:test';
import assert from 'node:assert/strict';

const { BroadcastPublisher } = await import('../../toolbox-site/tools/broadcast/publisher.js').catch(() => ({}));
const stream = () => ({getTracks:()=>[{kind:'video',readyState:'live',getSettings:()=>({width:640,height:360,frameRate:30})}]});
const tick = () => new Promise(resolve=>setTimeout(resolve,0));
function browserGlobal(t,name,value){const old=Object.getOwnPropertyDescriptor(globalThis,name);Object.defineProperty(globalThis,name,{value,writable:true,configurable:true});t.after(()=>old?Object.defineProperty(globalThis,name,old):delete globalThis[name]);}

test('publisher is an importable browser transport',()=>assert.equal(typeof BroadcastPublisher,'function'));

test('connected audio cannot conceal a stalled video; recovery is attempted then transport reconnects',async t=>{
 let sample,now=0,frames=30,videoBytes=1000;const states=[],errors=[];let recoveries=0;
 class Peer extends EventTarget{constructor(){super();this.connectionState='new';this.iceGatheringState='complete';}addTrack(){return{getParameters:()=>({encodings:[{}]}),setParameters:async()=>{}};}async createOffer(){return{type:'offer',sdp:'v=0'};}async setLocalDescription(d){this.localDescription=d;}async setRemoteDescription(){this.connectionState='connected';}async getStats(){return new Map([['v',{type:'outbound-rtp',kind:'video',timestamp:now+1,bytesSent:videoBytes,framesEncoded:frames,framesPerSecond:0}],['a',{type:'outbound-rtp',kind:'audio',timestamp:now+1,bytesSent:now*100}]]);}close(){this.connectionState='closed';}}
 browserGlobal(t,'RTCPeerConnection',Peer);t.mock.method(Date,'now',()=>now);t.mock.method(globalThis,'setInterval',fn=>{sample=fn;return 1;});t.mock.method(globalThis,'clearInterval',()=>{});
 t.mock.method(globalThis,'fetch',async(u,o)=>o.method==='POST'?new Response('v=0',{status:201,headers:{Location:'/session','Content-Type':'application/sdp'}}):new Response(null,{status:204}));
 const p=new BroadcastPublisher({onState:s=>states.push(s),onError:e=>errors.push(e.message),onRecoverVideo:()=>recoveries++});t.after(()=>p.stop());await p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'});
 now=5500;await sample();assert.equal(p.getStats().state,'stalled');assert.equal(recoveries,1);assert.ok(p.getStats().bitrateKbps>0,'advancing audio must not count as video health');
 now=6000;frames++;videoBytes+=100;await sample();assert.equal(p.getStats().state,'live');
 now=17001;await sample();await tick();assert.ok(states.includes('reconnecting'));assert.ok(errors.some(s=>/视频/.test(s)));await p.stop();
});

test('WHIP negotiates sendonly realtime hints, falls back on unsupported parameters and reports a real stall as zero',async t=>{
 let peer,sample,time=1000,stalled=false;const accepted=[],offered=[];
 class Peer extends EventTarget{
  constructor(config){super();peer=this;this.config=config;this.connectionState='new';this.iceGatheringState='complete';}
  addTransceiver(track,options){offered.push(options);return{sender:{getParameters:()=>({encodings:[{}]}),setParameters:async p=>{if(p.encodings[0].priority)throw Error('optional hint unsupported');accepted.push(p);}},setCodecPreferences:codecs=>{this.codecs=codecs;}};}
  async createOffer(){return{type:'offer',sdp:'v=0\r\n'};}async setLocalDescription(d){this.localDescription=d;}async setRemoteDescription(){this.connectionState='connected';}
  async getStats(){return new Map([['v',{type:'outbound-rtp',kind:'video',timestamp:time,bytesSent:1000,framesPerSecond:stalled?0:30,frameWidth:640,frameHeight:360}]]);}close(){this.connectionState='closed';}
 }
 browserGlobal(t,'RTCPeerConnection',Peer);browserGlobal(t,'RTCRtpSender',{getCapabilities:()=>({codecs:[{mimeType:'video/VP9'},{mimeType:'video/VP8'},{mimeType:'video/H264',sdpFmtpLine:'packetization-mode=1'}]})});
 t.mock.method(globalThis,'setInterval',fn=>{sample=fn;return 123;});t.mock.method(globalThis,'clearInterval',()=>{});
 t.mock.method(globalThis,'fetch',async(url,o)=>o.method==='POST'?new Response('v=0\r\n',{status:201,headers:{Location:'/session','Content-Type':'application/sdp'}}):new Response(null,{status:204}));
 const p=new BroadcastPublisher();t.after(()=>p.stop());await p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip',fps:120,videoBitsPerSecond:12000000});
 assert.equal(peer.config.bundlePolicy,'max-bundle');assert.equal(offered[0].direction,'sendonly');assert.equal(peer.codecs[0].mimeType,'video/H264');assert.ok(accepted.length);assert.equal(accepted[0].encodings[0].maxFramerate,60);assert.equal(accepted[0].encodings[0].maxBitrate,8000000);
 assert.equal(p.getStats().fps,30);time=2000;stalled=true;await sample();assert.equal(p.getStats().fps,0);assert.equal(p.getStats().bitrateKbps,0);await p.stop();
});

test('relay pipelines ordered chunks before ACK and stops all capture work',async t=>{
 let socket,recorder;const sent=[];
 class Socket{constructor(){socket=this;this.readyState=1;this.bufferedAmount=0;queueMicrotask(()=>this.onmessage({data:'0{}'}));}send(data){sent.push(data);if(data==='40')queueMicrotask(()=>this.onmessage({data:'40{}'}));if(typeof data==='string'&&data.startsWith('420'))queueMicrotask(()=>this.onmessage({data:'430[]'}));}close(){this.readyState=3;}}
 class Recorder{static isTypeSupported(){return true;}constructor(){recorder=this;this.state='inactive';}start(ms){this.timeslice=ms;this.state='recording';}stop(){this.state='inactive';}}
 browserGlobal(t,'WebSocket',Socket);browserGlobal(t,'MediaRecorder',Recorder);const errors=[];const p=new BroadcastPublisher({onError:e=>errors.push(e.message)});
 const pending=p.start(stream(),{mode:'rtmp',relayURL:'https://relay.test',address:'rtmp://dest.test/live',key:'k'}).catch(e=>e);await tick();
 assert.equal(recorder.timeslice,50);
 for(let i=0;i<3;i++)recorder.ondataavailable({data:new Blob(['chunk'+i])});await tick();
 const chunks=sent.filter(s=>s instanceof Blob);assert.equal(chunks.length,3);assert.deepEqual(await Promise.all(chunks.map(c=>c.text())),['chunk0','chunk1','chunk2']);assert.notEqual(p.getStats().state,'live');
 const id=sent.find(s=>typeof s==='string'&&s.startsWith('451-')).match(/^451-(\d+)/)[1];socket.onmessage({data:`43${id}[]`});await pending;assert.equal(p.getStats().state,'live');
 await p.stop();assert.equal(recorder.state,'inactive');assert.equal(socket.readyState,3);
});

test('relay backlog older than 800 ms fails promptly instead of accumulating seconds of delay',async t=>{
 let socket,recorder;const sent=[],errors=[];class Socket{constructor(){socket=this;this.readyState=1;this.bufferedAmount=0;queueMicrotask(()=>this.onmessage({data:'0{}'}));}send(v){sent.push(v);if(v==='40')queueMicrotask(()=>this.onmessage({data:'40{}'}));if(typeof v==='string'&&v.startsWith('420'))queueMicrotask(()=>this.onmessage({data:'430[]'}));}close(){this.readyState=3;}}
 class Recorder{static isTypeSupported(){return true;}constructor(){recorder=this;this.state='inactive';}start(){this.state='recording';}stop(){this.state='inactive';}}
 browserGlobal(t,'WebSocket',Socket);browserGlobal(t,'MediaRecorder',Recorder);let now=1000;t.mock.method(Date,'now',()=>now);
 const p=new BroadcastPublisher({onError:e=>errors.push(e.message)}),pending=p.start(stream(),{mode:'rtmp',relayURL:'https://relay.test',address:'rtmp://dest.test/live',key:'k'}).catch(e=>e);await tick();recorder.ondataavailable({data:new Blob(['header'])});now+=900;recorder.ondataavailable({data:new Blob(['next'])});await tick();assert.ok(errors.some(e=>/积压/.test(e)));await p.stop();assert.equal((await pending).name,'AbortError');
});

test('raw RTMP cannot report success without an existing relay',async()=>{
  const p=new BroadcastPublisher();
  await assert.rejects(p.start(stream(),{mode:'rtmp',address:'rtmp://example.test/live',key:'secret'}),/relay|转发/i);
  assert.notEqual(p.getStats().state,'live');
});

for(const endpoint of ['https://media.test/live/whip','http://media.test:8889/live/whip','http://127.0.0.1:8889/live/whip'])test(`WHIP ${endpoint} from HTTPS sends SDP, resolves Location and deletes the session`,async t=>{
  const calls=[];
  browserGlobal(t,'location',{protocol:'https:'});
  class Peer extends EventTarget {
    constructor(){super();this.connectionState='new';this.iceGatheringState='complete';this.senders=[];}
    addTrack(track){const s={track,getParameters:()=>({encodings:[{}]}),setParameters:async()=>{}};this.senders.push(s);return s;}
    async createOffer(){return {type:'offer',sdp:'v=0\r\n'};}
    async setLocalDescription(d){this.localDescription=d;}
    async setRemoteDescription(){this.connectionState='connected';this.dispatchEvent(new Event('connectionstatechange'));}
    async getStats(){return new Map([['video',{type:'outbound-rtp',kind:'video',bytesSent:1500,timestamp:1000,framesPerSecond:27,frameWidth:640,frameHeight:360}]]);}
    close(){this.connectionState='closed';}
  }
  t.mock.method(globalThis,'fetch',async(url,options)=>{
    calls.push([String(url),options]);
    return options.method==='POST'?new Response('v=0\r\n',{status:201,headers:{Location:'whip/session-1','Content-Type':'application/sdp'}}):new Response(null,{status:204});
  });
  browserGlobal(t,'RTCPeerConnection',Peer);
  const states=[];const p=new BroadcastPublisher({onState:s=>states.push(s)});
  await p.start(stream(),{mode:'whip',endpoint,token:'private',videoBitsPerSecond:2000000});
  assert.equal(p.getStats().state,'live');assert.equal(p.getStats().delivery,'peer');
  const post=calls.find(c=>c[1].method==='POST');assert.equal(post[1].body,'v=0\r\n');assert.equal(post[1].headers.Authorization,'Bearer private');
  assert.equal(post[1].credentials,'omit');
  await p.stop();
  assert.ok(calls.some(c=>c[0]===endpoint+'/session-1'&&c[1].method==='DELETE'));
  assert.equal(p.getStats().state,'idle');assert.ok(states.includes('live'));
});

test('an HTTP WHIP fetch failure on HTTPS explains browser permissions without leaking endpoint or token',async t=>{
 browserGlobal(t,'location',{protocol:'https:'});browserGlobal(t,'RTCPeerConnection',class{});
 const errors=[];t.mock.method(globalThis,'fetch',async()=>{throw new TypeError('Failed to fetch private-token')});
 const p=new BroadcastPublisher({onError:e=>errors.push(e.message)});
 const pending=p.start(stream(),{mode:'whip',endpoint:'http://private.test/whip',token:'private-token'}).catch(e=>e);
 await tick();assert.match(errors[0],/HTTP WHIP.*不安全内容.*跨域/);assert.ok(!errors[0].includes('private-token')&&!errors[0].includes('private.test'));
 await p.stop();assert.equal((await pending).name,'AbortError');
});

test('stop aborts in-flight SDP, clears retry work and never enters live',async t=>{
  class Peer extends EventTarget {
    constructor(){super();this.iceGatheringState='complete';this.connectionState='new';}
    addTrack(){return {getParameters:()=>({encodings:[{}]}),setParameters:async()=>{}};}
    async createOffer(){return {type:'offer',sdp:'v=0\r\n'};}async setLocalDescription(d){this.localDescription=d;}close(){}
  }
  browserGlobal(t,'RTCPeerConnection',Peer);
  t.mock.method(globalThis,'fetch',async(url,o)=>{if(o.method==='OPTIONS')return new Response(null,{status:204});return new Promise((r,j)=>o.signal.addEventListener('abort',()=>j(new DOMException('aborted','AbortError')),{once:true}));});
  const p=new BroadcastPublisher();const pending=p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'});
  const result=pending.catch(e=>e);await tick();await p.stop();
  assert.equal((await result).name,'AbortError');assert.equal(p.getStats().state,'idle');
});

test('RTMP speaks api.video Socket.IO binary ACK protocol and only reports live after media acknowledgement',async t=>{
  const sent=[];let socket;
  class Socket extends EventTarget {
    constructor(url){super();this.url=url;this.readyState=1;socket=this;queueMicrotask(()=>this.receive('0{"sid":"test","pingInterval":25000,"pingTimeout":20000}'));}
    receive(data){this.onmessage?.({data});}
    send(data){sent.push(data);if(data==='40')queueMicrotask(()=>this.receive('40{"sid":"test"}'));if(typeof data==='string'&&data.startsWith('420'))queueMicrotask(()=>this.receive('430[]'));}
    close(){this.readyState=3;}
  }
  class Recorder extends EventTarget {
    static isTypeSupported(){return true;}
    constructor(){super();this.state='inactive';}
    start(){this.state='recording';queueMicrotask(()=>this.ondataavailable({data:new Blob(['actual media'])}));}
    stop(){this.state='inactive';}
  }
  browserGlobal(t,'WebSocket',Socket);browserGlobal(t,'MediaRecorder',Recorder);
  const p=new BroadcastPublisher();const pending=p.start(stream(),{mode:'rtmp',relayURL:'https://relay.test/proxy',address:'rtmps://destination.test/live/',key:'secret',fps:30,width:640,height:360});
  await tick();assert.notEqual(p.getStats().state,'live');
  assert.match(socket.url,/wss:\/\/relay.test\/proxy\/socket.io\/\?EIO=4&transport=websocket/);
  const config=JSON.parse(sent.find(s=>typeof s==='string'&&s.startsWith('420')).slice(3))[1];
  assert.equal(config.rtmp,'rtmps://destination.test/live/secret');
  assert.ok(sent.some(s=>s instanceof Blob));
  const binary=sent.find(s=>typeof s==='string'&&s.startsWith('451-'));
  const id=binary.match(/^451-(\d+)/)[1];socket.receive(`43${id}[]`);await pending;
  assert.equal(p.getStats().state,'live');assert.equal(p.getStats().delivery,'relay');
  socket.receive('2');assert.ok(sent.includes('3'));await p.stop();
});

test('WHIP auth rejection is terminal and never exposes the server response or secrets',async t=>{
  let count=0;const errors=[];
  browserGlobal(t,'RTCPeerConnection',class {});
  t.mock.method(globalThis,'fetch',async()=>{count++;return new Response('private-secret-token',{status:401});});
  const p=new BroadcastPublisher({onError:e=>errors.push(e.message)});
  await assert.rejects(p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip',token:'private-secret-token'}),/鉴权/);
  assert.equal(count,1);assert.equal(p.getStats().state,'error');
  assert.ok(!JSON.stringify([errors,p.getStats()]).includes('private-secret-token'));await p.stop();
});

test('network failures reconnect with bounded attempts and stop cancels pending backoff',async t=>{
  let count=0;const states=[];
  browserGlobal(t,'RTCPeerConnection',class {});
  t.mock.method(globalThis,'fetch',async()=>{count++;throw new TypeError('network');});
  const p=new BroadcastPublisher({onState:s=>states.push(s)});
  const pending=p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'}).catch(e=>e);
  await new Promise(resolve=>setTimeout(resolve,1100));
  assert.equal(count,2);assert.equal(p.getStats().attempts,2);assert.equal(p.getStats().state,'reconnecting');
  await p.stop();assert.equal((await pending).name,'AbortError');assert.equal(p.getStats().state,'idle');
  assert.ok(states.includes('reconnecting'));
});

test('a timed-out WHIP request is aborted before a replacement attempt starts',async t=>{
  browserGlobal(t,'RTCPeerConnection',class {});
  let requestSignal;
  t.mock.timers.enable({apis:['setTimeout']});
  t.mock.method(globalThis,'fetch',async(url,options)=>{requestSignal=options.signal;return new Promise(()=>{});});
  const p=new BroadcastPublisher();const pending=p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'}).catch(e=>e);
  for(let i=0;i<6;i++)await Promise.resolve();
  t.mock.timers.tick(20001);
  for(let i=0;i<12;i++)await Promise.resolve();
  assert.equal(requestSignal.aborted,true);
  await p.stop();await pending;
});
