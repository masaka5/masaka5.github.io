import test from 'node:test';
import assert from 'node:assert/strict';

const { BroadcastPublisher } = await import('../../toolbox-site/tools/broadcast/publisher.js').catch(() => ({}));
const stream = () => ({getTracks:()=>[{kind:'video',readyState:'live',getSettings:()=>({width:640,height:360,frameRate:30})}]});
const tick = () => new Promise(resolve=>setTimeout(resolve,0));
function browserGlobal(t,name,value){const old=Object.getOwnPropertyDescriptor(globalThis,name);Object.defineProperty(globalThis,name,{value,writable:true,configurable:true});t.after(()=>old?Object.defineProperty(globalThis,name,old):delete globalThis[name]);}

test('publisher is an importable browser transport',()=>assert.equal(typeof BroadcastPublisher,'function'));

test('raw RTMP cannot report success without an existing relay',async()=>{
  const p=new BroadcastPublisher();
  await assert.rejects(p.start(stream(),{mode:'rtmp',address:'rtmp://example.test/live',key:'secret'}),/relay|转发/i);
  assert.notEqual(p.getStats().state,'live');
});

test('WHIP requires 201, sends SDP and bearer, resolves relative Location and DELETEs without stopping source',async t=>{
  const calls=[];
  class Peer extends EventTarget {
    constructor(){super();this.connectionState='new';this.iceGatheringState='complete';this.senders=[];}
    addTrack(track){const s={track,getParameters:()=>({encodings:[{}]}),setParameters:async()=>{}};this.senders.push(s);return s;}
    async createOffer(){return {type:'offer',sdp:'v=0\r\n'};}
    async setLocalDescription(d){this.localDescription=d;}
    async setRemoteDescription(){this.connectionState='connected';this.dispatchEvent(new Event('connectionstatechange'));}
    async getStats(){return new Map([['video',{type:'outbound-rtp',kind:'video',bytesSent:1500,timestamp:1000,framesPerSecond:27,frameWidth:640,frameHeight:360}]]);}
    close(){this.connectionState='closed';}
  }
  t.mock.method(globalThis,'fetch',async(url,options)=>{
    calls.push([String(url),options]);
    return options.method==='POST'?new Response('v=0\r\n',{status:201,headers:{Location:'whip/session-1','Content-Type':'application/sdp'}}):new Response(null,{status:204});
  });
  browserGlobal(t,'RTCPeerConnection',Peer);
  const states=[];const p=new BroadcastPublisher({onState:s=>states.push(s)});
  await p.start(stream(),{mode:'whip',endpoint:'https://media.test/live/whip',token:'private',videoBitsPerSecond:2000000});
  assert.equal(p.getStats().state,'live');assert.equal(p.getStats().delivery,'peer');
  const post=calls.find(c=>c[1].method==='POST');assert.equal(post[1].body,'v=0\r\n');assert.equal(post[1].headers.Authorization,'Bearer private');
  assert.equal(post[1].credentials,'omit');
  await p.stop();
  assert.ok(calls.some(c=>c[0]==='https://media.test/live/whip/session-1'&&c[1].method==='DELETE'));
  assert.equal(p.getStats().state,'idle');assert.ok(states.includes('live'));
});

test('stop aborts in-flight SDP, clears retry work and never enters live',async t=>{
  class Peer extends EventTarget {
    constructor(){super();this.iceGatheringState='complete';this.connectionState='new';}
    addTrack(){return {getParameters:()=>({encodings:[{}]}),setParameters:async()=>{}};}
    async createOffer(){return {type:'offer',sdp:'v=0\r\n'};}async setLocalDescription(d){this.localDescription=d;}close(){}
  }
  browserGlobal(t,'RTCPeerConnection',Peer);
  t.mock.method(globalThis,'fetch',async(url,o)=>{if(o.method==='OPTIONS')return new Response(null,{status:204});return new Promise((r,j)=>o.signal.addEventListener('abort',()=>j(new DOMException('aborted','AbortError')),{once:true}));});
  const p=new BroadcastPublisher();const pending=p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'});
  const result=pending.catch(e=>e);await tick();await p.stop();
  assert.equal((await result).name,'AbortError');assert.equal(p.getStats().state,'idle');
});

test('RTMP speaks api.video Socket.IO binary ACK protocol and only reports live after media acknowledgement',async t=>{
  const sent=[];let socket;
  class Socket extends EventTarget {
    constructor(url){super();this.url=url;this.readyState=1;socket=this;queueMicrotask(()=>this.receive('0{"sid":"test","pingInterval":25000,"pingTimeout":20000}'));}
    receive(data){this.onmessage?.({data});}
    send(data){sent.push(data);if(data==='40')queueMicrotask(()=>this.receive('40{"sid":"test"}'));if(typeof data==='string'&&data.startsWith('420'))queueMicrotask(()=>this.receive('430[]'));}
    close(){this.readyState=3;}
  }
  class Recorder extends EventTarget {
    static isTypeSupported(){return true;}
    constructor(){super();this.state='inactive';}
    start(){this.state='recording';queueMicrotask(()=>this.ondataavailable({data:new Blob(['actual media'])}));}
    stop(){this.state='inactive';}
  }
  browserGlobal(t,'WebSocket',Socket);browserGlobal(t,'MediaRecorder',Recorder);
  const p=new BroadcastPublisher();const pending=p.start(stream(),{mode:'rtmp',relayURL:'https://relay.test/proxy',address:'rtmps://destination.test/live/',key:'secret',fps:30,width:640,height:360});
  await tick();assert.notEqual(p.getStats().state,'live');
  assert.match(socket.url,/wss:\/\/relay.test\/proxy\/socket.io\/\?EIO=4&transport=websocket/);
  const config=JSON.parse(sent.find(s=>typeof s==='string'&&s.startsWith('420')).slice(3))[1];
  assert.equal(config.rtmp,'rtmps://destination.test/live/secret');
  assert.ok(sent.some(s=>s instanceof Blob));
  const binary=sent.find(s=>typeof s==='string'&&s.startsWith('451-'));
  const id=binary.match(/^451-(\d+)/)[1];socket.receive(`43${id}[]`);await pending;
  assert.equal(p.getStats().state,'live');assert.equal(p.getStats().delivery,'relay');
  socket.receive('2');assert.ok(sent.includes('3'));await p.stop();
});

test('WHIP auth rejection is terminal and never exposes the server response or secrets',async t=>{
  let count=0;const errors=[];
  browserGlobal(t,'RTCPeerConnection',class {});
  t.mock.method(globalThis,'fetch',async()=>{count++;return new Response('private-secret-token',{status:401});});
  const p=new BroadcastPublisher({onError:e=>errors.push(e.message)});
  await assert.rejects(p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip',token:'private-secret-token'}),/鉴权/);
  assert.equal(count,1);assert.equal(p.getStats().state,'error');
  assert.ok(!JSON.stringify([errors,p.getStats()]).includes('private-secret-token'));await p.stop();
});

test('network failures reconnect with bounded attempts and stop cancels pending backoff',async t=>{
  let count=0;const states=[];
  browserGlobal(t,'RTCPeerConnection',class {});
  t.mock.method(globalThis,'fetch',async()=>{count++;throw new TypeError('network');});
  const p=new BroadcastPublisher({onState:s=>states.push(s)});
  const pending=p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'}).catch(e=>e);
  await new Promise(resolve=>setTimeout(resolve,1100));
  assert.equal(count,2);assert.equal(p.getStats().attempts,2);assert.equal(p.getStats().state,'reconnecting');
  await p.stop();assert.equal((await pending).name,'AbortError');assert.equal(p.getStats().state,'idle');
  assert.ok(states.includes('reconnecting'));
});

test('a timed-out WHIP request is aborted before a replacement attempt starts',async t=>{
  browserGlobal(t,'RTCPeerConnection',class {});
  let requestSignal;
  t.mock.timers.enable({apis:['setTimeout']});
  t.mock.method(globalThis,'fetch',async(url,options)=>{requestSignal=options.signal;return new Promise(()=>{});});
  const p=new BroadcastPublisher();const pending=p.start(stream(),{mode:'whip',endpoint:'https://media.test/whip'}).catch(e=>e);
  for(let i=0;i<6;i++)await Promise.resolve();
  t.mock.timers.tick(20001);
  for(let i=0;i<12;i++)await Promise.resolve();
  assert.equal(requestSignal.aborted,true);
  await p.stop();await pending;
});
