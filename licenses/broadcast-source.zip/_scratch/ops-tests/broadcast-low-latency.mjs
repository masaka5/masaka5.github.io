import test from 'node:test';import assert from 'node:assert/strict';
const m=await import('../../toolbox-site/tools/broadcast/low-latency.js').catch(()=>({}));
test('realtime profile bounds encoder work independently of a 2K/60 canvas',()=>{
 assert.equal(typeof m.streamPolicy,'function');
 const p=m.streamPolicy({width:2560,height:1440,fps:60,videoBitsPerSecond:12000000});
 assert.equal(p.mode,'realtime');assert.equal(p.scaleResolutionDownBy,4/3);assert.equal(p.maxFramerate,60);assert.equal(p.maxBitrate,12000000);
 const full=m.streamPolicy({width:2560,height:1440,fps:60,videoBitsPerSecond:12000000,latencyMode:'quality'});
 assert.equal(full.scaleResolutionDownBy,1);assert.equal(full.maxBitrate,12000000);
 assert.ok(Number.isFinite(m.streamPolicy({width:NaN,height:Infinity,fps:0,videoBitsPerSecond:-1}).maxBitrate));
 assert.equal(m.streamPolicy({fps:120}).maxFramerate,60);assert.equal(m.streamPolicy({fps:120,latencyMode:'quality'}).maxFramerate,120);
});
test('bandwidth label cannot permanently trap a reduced budget when measured headroom returns',()=>{
 const p=m.streamPolicy({fps:60,videoBitsPerSecond:12000000});
 let state=m.nextStreamBudget(p,null,{encodeMs:3,sendQueueMs:100,availableKbps:2000,qualityLimitationReason:'bandwidth'});
 const reduced=state.maxBitrate;
 for(let i=0;i<10;i++)state=m.nextStreamBudget(p,state,{encodeMs:7,sendQueueMs:1,availableKbps:15000,qualityLimitationReason:'bandwidth'});
 assert.ok(state.maxBitrate>reduced,'ample measured bandwidth must permit cautious recovery');
 for(let i=0;i<300;i++)state=m.nextStreamBudget(p,state,{encodeMs:3,sendQueueMs:1,availableKbps:20000,qualityLimitationReason:'bandwidth'});
 assert.equal(state.maxBitrate,12000000);
});
test('insufficient headroom cannot raise the budget, and low configured caps remain respected under pressure',()=>{
 const p=m.streamPolicy({fps:60,videoBitsPerSecond:500000});let state=null;
 for(let i=0;i<30;i++)state=m.nextStreamBudget(p,state,{encodeMs:40,sendQueueMs:100,availableKbps:300,qualityLimitationReason:'bandwidth'});
 assert.ok(state.maxBitrate<=500000);
 const reduced={maxBitrate:1600000,scaleResolutionDownBy:1};
 for(const availableKbps of [null,0,1700]){
  let s=reduced;for(let i=0;i<30;i++)s=m.nextStreamBudget(m.streamPolicy({fps:60}),s,{encodeMs:3,sendQueueMs:1,availableKbps,qualityLimitationReason:'bandwidth'});
  assert.equal(s.maxBitrate,1600000);
 }
});
test('stats use deltas and selected ICE pair; RTT is not end-to-end delay',()=>{
 assert.equal(typeof m.readStreamStats,'function');
 const report=(bytes,frames,encode,delay,timestamp)=>new Map([
 ['v',{id:'v',type:'outbound-rtp',kind:'video',bytesSent:bytes,framesEncoded:frames,totalEncodeTime:encode,totalPacketSendDelay:delay,packetsSent:frames*4,timestamp,framesPerSecond:30,frameWidth:1280,frameHeight:720,codecId:'codec',transportId:'transport',qualityLimitationReason:'cpu'}],
 ['codec',{type:'codec',mimeType:'video/H264'}],['transport',{type:'transport',selectedCandidatePairId:'selected'}],
 ['other',{type:'candidate-pair',state:'succeeded',currentRoundTripTime:9}],
 ['selected',{type:'candidate-pair',state:'succeeded',currentRoundTripTime:.025,availableOutgoingBitrate:1500000,localCandidateId:'local'}],['local',{type:'local-candidate',protocol:'udp',candidateType:'host'}]]);
 const a=m.readStreamStats(report(10000,10,.1,.02,1000));const b=m.readStreamStats(report(35000,20,.3,.1,2000),a.snapshot);
 assert.equal(b.metrics.bitrateKbps,200);assert.equal(b.metrics.encodeMs,20);assert.equal(b.metrics.sendQueueMs,2);assert.equal(b.metrics.rttMs,25);assert.equal(b.metrics.transport,'udp');assert.equal(b.metrics.codec,'H264');assert.equal(b.metrics.availableKbps,1500);
 assert.equal(m.readStreamStats(new Map()).metrics.rttMs,null);
 assert.equal(a.snapshot.videoFrames,10);assert.equal(a.snapshot.videoBytes,10000);
});
test('video payload bitrate is separate from audio and encoder target is reported without inventing missing values',()=>{
 const report=(time,bytes,audio)=>new Map([
  ['v',{type:'outbound-rtp',kind:'video',timestamp:time,bytesSent:bytes,framesEncoded:30,targetBitrate:4000000}],
  ['a',{type:'outbound-rtp',kind:'audio',timestamp:time,bytesSent:audio}]
 ]);
 const a=m.readStreamStats(report(1000,100000,10000));const b=m.readStreamStats(report(2000,600000,26000),a.snapshot);
 assert.equal(b.metrics.videoBitrateKbps,4000);assert.equal(b.metrics.bitrateKbps,4128);assert.equal(b.metrics.encoderTargetKbps,4000);
 assert.equal(m.readStreamStats(new Map()).metrics.encoderTargetKbps,null);
 assert.equal(m.readStreamStats(report(3000,100,0),b.snapshot).metrics.videoBitrateKbps,0);
});
test('persistent encoder/network pressure backs off, recovery requires sustained headroom',()=>{
 assert.equal(typeof m.nextStreamBudget,'function');const p=m.streamPolicy({width:2560,height:1440,fps:60,videoBitsPerSecond:12000000});
 let state=null;for(let i=0;i<3;i++)state=m.nextStreamBudget(p,state,{encodeMs:40,sendQueueMs:0,qualityLimitationReason:'cpu',availableKbps:10000});
 assert.ok(state.scaleResolutionDownBy>p.scaleResolutionDownBy);assert.ok(state.maxBitrate<=p.maxBitrate);
 const stressed=state.scaleResolutionDownBy;for(let i=0;i<4;i++)state=m.nextStreamBudget(p,state,{encodeMs:2,sendQueueMs:0,qualityLimitationReason:'none',availableKbps:20000});
 assert.equal(state.scaleResolutionDownBy,stressed);for(let i=0;i<12;i++)state=m.nextStreamBudget(p,state,{encodeMs:2,sendQueueMs:0,qualityLimitationReason:'none',availableKbps:20000});assert.ok(state.scaleResolutionDownBy<stressed);
 const net=m.nextStreamBudget(p,null,{encodeMs:2,sendQueueMs:120,availableKbps:2000,qualityLimitationReason:'bandwidth'});assert.ok(net.maxBitrate<2000000);assert.ok(net.maxBitrate>=600000);
 const ramp=m.nextStreamBudget(p,null,{encodeMs:2,sendQueueMs:0,availableKbps:300,qualityLimitationReason:'bandwidth'});assert.equal(ramp.scaleResolutionDownBy,p.scaleResolutionDownBy);assert.equal(ramp.maxBitrate,p.maxBitrate);
 const q=m.streamPolicy({width:2560,height:1440,latencyMode:'quality'});assert.equal(m.nextStreamBudget(q,null,{encodeMs:100,sendQueueMs:300,availableKbps:200}).scaleResolutionDownBy,1);
});
test('sustained browser bandwidth pressure backs off before queues grow, then recovers with hysteresis',()=>{
 const p=m.streamPolicy({width:1920,height:1080,fps:60,videoBitsPerSecond:12000000});let state=null;
 for(let i=0;i<2;i++)state=m.nextStreamBudget(p,state,{encodeMs:3,sendQueueMs:1,availableKbps:7000,qualityLimitationReason:'bandwidth'});
 assert.equal(state.maxBitrate,p.maxBitrate,'one or two noisy reports must not lower quality');
 state=m.nextStreamBudget(p,state,{encodeMs:3,sendQueueMs:1,availableKbps:7000,qualityLimitationReason:'bandwidth'});
 assert.ok(state.maxBitrate< p.maxBitrate,'sustained bandwidth pressure should lower the sender target');
 const reduced=state.maxBitrate;
 for(let i=0;i<5;i++)state=m.nextStreamBudget(p,state,{encodeMs:3,sendQueueMs:1,availableKbps:15000,qualityLimitationReason:'bandwidth'});
 assert.equal(state.maxBitrate,reduced,'recovery should wait for the full hysteresis window');
 for(let i=0;i<6;i++)state=m.nextStreamBudget(p,state,{encodeMs:3,sendQueueMs:1,availableKbps:15000,qualityLimitationReason:'bandwidth'});
 assert.ok(state.maxBitrate>reduced);
});
