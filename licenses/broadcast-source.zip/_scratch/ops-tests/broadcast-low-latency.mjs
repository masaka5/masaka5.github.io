import test from 'node:test';import assert from 'node:assert/strict';
const m=await import('../../toolbox-site/tools/broadcast/low-latency.js').catch(()=>({}));
test('realtime profile bounds encoder work independently of a 2K/60 canvas',()=>{
 assert.equal(typeof m.streamPolicy,'function');
 const p=m.streamPolicy({width:2560,height:1440,fps:60,videoBitsPerSecond:12000000});
 assert.equal(p.mode,'realtime');assert.equal(p.scaleResolutionDownBy,4/3);assert.equal(p.maxFramerate,60);assert.ok(p.maxBitrate<=8000000);
 const full=m.streamPolicy({width:2560,height:1440,fps:60,videoBitsPerSecond:12000000,latencyMode:'quality'});
 assert.equal(full.scaleResolutionDownBy,1);assert.equal(full.maxBitrate,12000000);
 assert.ok(Number.isFinite(m.streamPolicy({width:NaN,height:Infinity,fps:0,videoBitsPerSecond:-1}).maxBitrate));
 assert.equal(m.streamPolicy({fps:120}).maxFramerate,60);assert.equal(m.streamPolicy({fps:120,latencyMode:'quality'}).maxFramerate,120);
});
test('stats use deltas and selected ICE pair; RTT is not end-to-end delay',()=>{
 assert.equal(typeof m.readStreamStats,'function');
 const report=(bytes,frames,encode,delay,timestamp)=>new Map([
 ['v',{id:'v',type:'outbound-rtp',kind:'video',bytesSent:bytes,framesEncoded:frames,totalEncodeTime:encode,totalPacketSendDelay:delay,packetsSent:frames*4,timestamp,framesPerSecond:30,frameWidth:1280,frameHeight:720,codecId:'codec',transportId:'transport',qualityLimitationReason:'cpu'}],
 ['codec',{type:'codec',mimeType:'video/H264'}],['transport',{type:'transport',selectedCandidatePairId:'selected'}],
 ['other',{type:'candidate-pair',state:'succeeded',currentRoundTripTime:9}],
 ['selected',{type:'candidate-pair',state:'succeeded',currentRoundTripTime:.025,availableOutgoingBitrate:1500000,localCandidateId:'local'}],['local',{type:'local-candidate',protocol:'udp',candidateType:'host'}]]);
 const a=m.readStreamStats(report(10000,10,.1,.02,1000));const b=m.readStreamStats(report(35000,20,.3,.1,2000),a.snapshot);
 assert.equal(b.metrics.bitrateKbps,200);assert.equal(b.metrics.encodeMs,20);assert.equal(b.metrics.sendQueueMs,2);assert.equal(b.metrics.rttMs,25);assert.equal(b.metrics.transport,'udp');assert.equal(b.metrics.codec,'H264');assert.equal(b.metrics.availableKbps,1500);
 assert.equal(m.readStreamStats(new Map()).metrics.rttMs,null);
 assert.equal(a.snapshot.videoFrames,10);assert.equal(a.snapshot.videoBytes,10000);
});
test('persistent encoder/network pressure backs off, recovery requires sustained headroom',()=>{
 assert.equal(typeof m.nextStreamBudget,'function');const p=m.streamPolicy({width:2560,height:1440,fps:60,videoBitsPerSecond:12000000});
 let state=null;for(let i=0;i<3;i++)state=m.nextStreamBudget(p,state,{encodeMs:40,sendQueueMs:0,qualityLimitationReason:'cpu',availableKbps:10000});
 assert.ok(state.scaleResolutionDownBy>p.scaleResolutionDownBy);assert.ok(state.maxBitrate<=p.maxBitrate);
 const stressed=state.scaleResolutionDownBy;for(let i=0;i<4;i++)state=m.nextStreamBudget(p,state,{encodeMs:2,sendQueueMs:0,qualityLimitationReason:'none',availableKbps:20000});
 assert.equal(state.scaleResolutionDownBy,stressed);for(let i=0;i<12;i++)state=m.nextStreamBudget(p,state,{encodeMs:2,sendQueueMs:0,qualityLimitationReason:'none',availableKbps:20000});assert.ok(state.scaleResolutionDownBy<stressed);
 const net=m.nextStreamBudget(p,null,{encodeMs:2,sendQueueMs:120,availableKbps:2000,qualityLimitationReason:'bandwidth'});assert.ok(net.maxBitrate<2000000);assert.ok(net.maxBitrate>=600000);
 const ramp=m.nextStreamBudget(p,null,{encodeMs:2,sendQueueMs:0,availableKbps:300,qualityLimitationReason:'bandwidth'});assert.equal(ramp.scaleResolutionDownBy,p.scaleResolutionDownBy);assert.equal(ramp.maxBitrate,p.maxBitrate);
 const q=m.streamPolicy({width:2560,height:1440,latencyMode:'quality'});assert.equal(m.nextStreamBudget(q,null,{encodeMs:100,sendQueueMs:300,availableKbps:200}).scaleResolutionDownBy,1);
});
