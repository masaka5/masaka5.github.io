import test from 'node:test';
import assert from 'node:assert/strict';
import {BroadcastEngine} from '../../toolbox-site/tools/broadcast/engine.js';
import {normalizeSource} from '../../toolbox-site/tools/broadcast/broadcast-core.js';
globalThis.HTMLVideoElement=class{};

test('failed source duplication retains the original shared asset',async()=>{
 const e=new BroadcastEngine({canvas:{}});e.compositor={remove(){}};e._emit=()=>{};
 const asset=new Blob(['image']),s=normalizeSource({type:'image',assetId:'original'});
 e.assets.set('original',asset);e.activeScene.sources.push(s);
 e._prepare=async()=>{throw Error('decoder failure')};
 await assert.rejects(e.duplicateSource(s.id),/decoder failure/);
 assert.equal(e.assets.get('original'),asset);assert.equal(e.activeScene.sources.length,1);
});
test('scene duplication rolls back prepared sources if a later asset fails',async()=>{
 const e=new BroadcastEngine({canvas:{}});e.compositor={remove(){}};e._emit=()=>{};
 const a=normalizeSource({type:'image',assetId:'a'}),b=normalizeSource({type:'image',assetId:'b'});
 e.activeScene.sources.push(a,b);e.assets.set('a',new Blob(['a']));e.assets.set('b',new Blob(['b']));
 let released=0;e._prepare=async(s,options,staged)=>{if(s.assetId==='b')throw Error('bad image');staged.set(s.id,{stream:{getTracks:()=>[{stop(){released++}}]}})};
 await assert.rejects(e.duplicateScene(),/bad image/);
 assert.equal(released,1);assert.equal(e.project.scenes.length,1);assert.equal(e.runtimes.size,0);assert.equal(e.assets.size,2);
});
