import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeProject, normalizeSource, hitTestSource, formatCountdown, OUTPUT_LIMITS } from '../../toolbox-site/tools/broadcast/broadcast-core.js';

test('untrusted project is bounded and scene ids remain unique', () => {
  const p = normalizeProject({width:99999,height:1,fps:999,activeSceneId:'missing',scenes:[{id:'same',sources:[]},{id:'same',sources:[]}]});
  assert.equal(p.width,OUTPUT_LIMITS.maxDimension); assert.equal(p.height,OUTPUT_LIMITS.minDimension); assert.equal(p.fps,OUTPUT_LIMITS.maxFPS);
  assert.equal(new Set(p.scenes.map(s=>s.id)).size,2);
  assert.equal(p.activeSceneId,p.scenes[0].id);
});
test('custom and portrait output retain their exact dimensions inside the pixel budget',()=>{
  const portrait=normalizeProject({width:1080,height:1920});
  assert.equal(portrait.width,1080);assert.equal(portrait.height,1920);
  for(const [width,height]of [[2560,1440],[1440,2560],[1280,720],[1920,1080],[2048,1536],[3840,2160]]){
    const output=normalizeProject({width,height,fps:24});assert.equal(output.width,width);assert.equal(output.height,height);assert.equal(output.fps,24);
  }
  const bounded=normalizeProject({width:8192,height:8192,scenes:Array.from({length:20},()=>({sources:Array.from({length:40},()=>({type:'text'}))}))});
  assert.ok(bounded.width*bounded.height<=OUTPUT_LIMITS.maxPixels);assert.equal(bounded.scenes.length,16);assert.equal(bounded.scenes[0].sources.length,32);
  assert.equal(normalizeProject({fps:29.97}).fps,29.97);
  assert.equal(normalizeProject({fps:59.94}).fps,59.94);
});
test('rotated source hit testing follows its local rectangle', () => {
  const s = normalizeSource({type:'image',x:100,y:100,width:200,height:50,rotation:90});
  assert.equal(hitTestSource(s,200,200),true);
  assert.equal(hitTestSource(s,110,110),false);
  assert.equal(hitTestSource({...s,visible:false},200,200),false);
});
test('countdown never becomes negative and supports durations over an hour', () => {
  assert.equal(formatCountdown(-3),'00:00');
  assert.equal(formatCountdown(3661),'01:01:01');
});
