import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeProject, normalizeSource, hitTestSource, formatCountdown } from '../../toolbox-site/tools/broadcast/broadcast-core.js';

test('untrusted project is bounded and scene ids remain unique', () => {
  const p = normalizeProject({width:99999,height:1,fps:120,activeSceneId:'missing',scenes:[{id:'same',sources:[]},{id:'same',sources:[]}]});
  assert.equal(p.width,1920); assert.equal(p.height,180); assert.equal(p.fps,60);
  assert.equal(new Set(p.scenes.map(s=>s.id)).size,2);
  assert.equal(p.activeSceneId,p.scenes[0].id);
});
test('portrait output fits the same 1080p pixel budget',()=>{
  const portrait=normalizeProject({width:1080,height:1920});
  assert.equal(portrait.width,1080);assert.equal(portrait.height,1920);
  const bounded=normalizeProject({width:1920,height:1920,scenes:Array.from({length:20},()=>({sources:Array.from({length:40},()=>({type:'text'}))}))});
  assert.ok(bounded.width*bounded.height<=1920*1080);assert.equal(bounded.scenes.length,16);assert.equal(bounded.scenes[0].sources.length,32);
});
test('rotated source hit testing follows its local rectangle', () => {
  const s = normalizeSource({type:'image',x:100,y:100,width:200,height:50,rotation:90});
  assert.equal(hitTestSource(s,200,200),true);
  assert.equal(hitTestSource(s,110,110),false);
  assert.equal(hitTestSource({...s,visible:false},200,200),false);
});
test('countdown never becomes negative and supports durations over an hour', () => {
  assert.equal(formatCountdown(-3),'00:00');
  assert.equal(formatCountdown(3661),'01:01:01');
});
