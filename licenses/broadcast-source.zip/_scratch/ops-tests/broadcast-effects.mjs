import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const effects=await import('data:text/javascript;base64,'+Buffer.from(await readFile(new URL('../../toolbox-site/tools/broadcast/effects.js',import.meta.url))).toString('base64'));
test('old projects receive neutral filters and disabled animation',()=>{
 const defaults=effects.normalizeEffects();assert.equal(defaults.brightness,1);assert.equal(defaults.contrast,1);assert.equal(defaults.saturation,1);assert.equal(defaults.blur,0);assert.equal(effects.normalizeAnimation().type,'none');
});
test('filter and transition inputs are finite and bounded',()=>{
 const value=effects.normalizeEffects({brightness:NaN,contrast:Infinity,saturation:-10,hue:9999,blur:999,grayscale:99,invert:-3});
 assert.equal(value.brightness,1);assert.equal(value.contrast,1);assert.equal(value.saturation,0);assert.equal(value.blur,16);assert.equal(value.hue,180);assert.equal(value.grayscale,1);assert.equal(value.invert,0);
 assert.deepEqual(effects.normalizeAnimation({type:'invalid',duration:-1}),{type:'none',duration:100});
 assert.equal(effects.normalizeAnimation({type:'fade',duration:99999}).duration,5000);
});
test('opacity transition can reverse continuously, stops exactly at its target',()=>{
 const animation=effects.makeFade(0,1,100,1000);
 assert.equal(effects.fadeValue(animation,100),0);assert.equal(effects.fadeValue(animation,600),.5);assert.equal(effects.fadeValue(animation,1100),1);
 const reverse=effects.makeFade(effects.fadeValue(animation,600),0,600,1000);
 assert.equal(effects.fadeValue(reverse,600),.5);assert.equal(effects.fadeValue(reverse,850),.25);assert.equal(effects.fadeValue(reverse,1100),0);
});
test('every named preset is normalized and includes an actual image operation',()=>{
 assert.ok(Object.keys(effects.FILTER_PRESETS).length>=6);
 for(const [name,preset]of Object.entries(effects.FILTER_PRESETS)){assert.deepEqual(effects.normalizeEffects(preset),preset);if(name!=='original')assert.notDeepEqual(preset,effects.normalizeEffects());}
});
