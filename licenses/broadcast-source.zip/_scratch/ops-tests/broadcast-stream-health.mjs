import test from 'node:test';import assert from 'node:assert/strict';
import * as m from '../../toolbox-site/tools/broadcast/low-latency.js';
test('video watchdog ignores advancing audio and detects a connected encoder stall',()=>{
 assert.equal(typeof m.videoProgress,'function');let state;
 state=m.videoProgress(state,{videoFrames:30,videoBytes:1000},0);assert.equal(state.status,'healthy');
 state=m.videoProgress(state,{videoFrames:30,videoBytes:1000,bytes:90000},5001);assert.equal(state.status,'stalled');assert.equal(state.reconnect,false);
 state=m.videoProgress(state,{videoFrames:30,videoBytes:1000,bytes:190000},10001);assert.equal(state.reconnect,true);
 state=m.videoProgress(state,{videoFrames:31,videoBytes:1200},10100);assert.equal(state.status,'healthy');assert.equal(state.reconnect,false);
});
test('video transport stall is detected even if encoder continues producing frames',()=>{
 assert.equal(typeof m.videoProgress,'function');let state=m.videoProgress(null,{videoFrames:20,videoBytes:2000},0);
 state=m.videoProgress(state,{videoFrames:200,videoBytes:2000},11000);assert.equal(state.reconnect,true);assert.equal(state.reason,'transport');
});
test('missing counters, counter resets and low fps do not trigger spurious reconnections',()=>{
 assert.equal(typeof m.videoProgress,'function');let state=m.videoProgress(null,{},0);state=m.videoProgress(state,{},20000);assert.equal(state.reconnect,false);
 state=m.videoProgress(null,{videoFrames:5,videoBytes:500},0);state=m.videoProgress(state,{videoFrames:6,videoBytes:550},4500);assert.equal(state.status,'healthy');
 state=m.videoProgress(state,{videoFrames:0,videoBytes:0},5000);assert.equal(state.status,'healthy');
});
