import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const url=new URL('../../toolbox-site/tools/broadcast/transform.js',import.meta.url);
const geometry=await import('data:text/javascript;base64,'+Buffer.from(await readFile(url)).toString('base64'));
const {resizeSource,sourceHandlePoint}=geometry;
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} != ${b}`);
const base={x:200,y:180,width:400,height:200,rotation:0};
test('all eight handles preserve the opposite anchor at every rotation',()=>{
 const opposite={n:'s',ne:'sw',e:'w',se:'nw',s:'n',sw:'ne',w:'e',nw:'se'};
 for(const rotation of [0,30,90,135,-45,270])for(const handle of Object.keys(opposite)){
  const s={...base,rotation},a=sourceHandlePoint(s,opposite[handle]);
  for(const preserve of [true,false]){
   const result={...s,...resizeSource(s,handle,{x:65,y:40},preserve)},b=sourceHandlePoint(result,opposite[handle]);
   close(a.x,b.x);close(a.y,b.y);if(preserve)close(result.width/result.height,2);
  }
 }
});
test('right edge can be stretched freely or keep source aspect',()=>{
 assert.deepEqual(resizeSource(base,'e',{x:80,y:0},false),{x:200,y:180,width:480,height:200});
 assert.deepEqual(resizeSource(base,'e',{x:80,y:0},true),{x:200,y:160,width:480,height:240});
});
test('shrinking past opposite anchor never inverts or exceeds source limits',()=>{
 for(const handle of ['n','ne','e','se','s','sw','w','nw'])for(const keep of [true,false])for(const x of [-1e8,1e8]){
  const p=resizeSource(base,handle,{x,y:x},keep);assert.ok(p.width>=8&&p.width<=7680&&p.height>=8&&p.height<=4320);for(const n of Object.values(p))assert.ok(Number.isFinite(n));
 }
});
