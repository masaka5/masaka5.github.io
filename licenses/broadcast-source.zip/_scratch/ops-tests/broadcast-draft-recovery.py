"""A damaged persisted media draft still opens a usable studio."""
import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch();page=await browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/broadcast/');await page.wait_for_function('broadcastApp.engine?.compositor')
  await page.evaluate('''async()=>{const store=await import('./store.js');await store.saveProject({version:1,width:1280,height:720,fps:30,scenes:[{id:'damaged',name:'旧草稿',sources:[{id:'broken',type:'image',assetId:'broken',name:'损坏图片'}]}]},[{id:'broken',blob:new Blob(['not a PNG'],{type:'image/png'})}]);}''')
  await page.reload();await page.wait_for_function("document.querySelector('#notice').textContent.includes('草稿素材无法恢复')")
  await page.locator('#addSource').click();await page.locator('#addText').click()
  result=await page.evaluate("({sources:broadcastApp.engine.activeScene.sources.map(s=>s.type),assets:broadcastApp.engine.assets.size})")
  assert result=={'sources':['text'],'assets':0},result;assert not errors,errors
  print(json.dumps({'usable_after_damaged_draft':True,'page_errors':errors}));await browser.close()
asyncio.run(main())
