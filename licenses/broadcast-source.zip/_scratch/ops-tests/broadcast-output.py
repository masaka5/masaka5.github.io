"""Actual 2K recording, custom output, project recovery and input validation."""
from pathlib import Path
import json,os,subprocess
from playwright.sync_api import sync_playwright,expect

BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
ROOT=Path(__file__).resolve().parents[2]
with sync_playwright() as p:
    browser=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    page=browser.new_page(viewport={'width':1440,'height':900},accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto(BASE+'/tools/broadcast/')
    page.wait_for_function('broadcastApp.engine?.compositor')
    def output():
        return page.evaluate('({width:broadcastApp.engine.project.width,height:broadcastApp.engine.project.height,fps:broadcastApp.engine.project.fps})')
    default={'width':2560,'height':1440,'fps':60}
    assert output()==default,output()
    expect(page.locator('#outputLabel')).to_have_text('2560 × 1440')
    page.locator('#openOutput').click()
    expect(page.locator('#outputSize')).to_have_value('2560x1440')
    expect(page.locator('#outputFPS')).to_have_value('60')
    expect(page.locator('#outputBitrate')).to_have_value('12000')
    page.locator('#outputSize').select_option('custom')
    page.locator('#outputWidth').fill('2048')
    page.locator('#outputHeight').fill('1536')
    page.locator('#outputFPS').fill('48')
    page.locator('#outputForm button[type=submit]').click()
    assert output()=={'width':2048,'height':1536,'fps':48}
    page.wait_for_timeout(900)
    page.reload();page.wait_for_function('broadcastApp.engine?.project.width===2048')
    assert output()=={'width':2048,'height':1536,'fps':48}
    page.locator('#openOutput').click()
    expect(page.locator('#outputSize')).to_have_value('custom')
    expect(page.locator('#outputWidth')).to_have_value('2048')
    expect(page.locator('#outputFPS')).to_have_value('48')
    page.locator('#outputDialog [data-close]').click()
    custom_recording=page.evaluate('''async()=>{
      const e=broadcastApp.engine;await e.startRecording();await new Promise(r=>setTimeout(r,600));
      const blob=await e.stopRecording(),video=document.createElement('video'),url=URL.createObjectURL(blob);
      video.src=url;await new Promise((resolve,reject)=>{video.onloadeddata=resolve;video.onerror=reject;});
      const result={width:video.videoWidth,height:video.videoHeight,bytes:blob.size};URL.revokeObjectURL(url);return result;
    }''')
    assert custom_recording['width']==2048 and custom_recording['height']==1536,custom_recording
    page.locator('#openOutput').click()
    page.locator('#outputWidth').fill('8192')
    page.locator('#outputHeight').fill('8192')
    # Set individual limits for this test so total-pixel validation is exercised on smaller GPUs too.
    page.locator('#outputWidth').evaluate("el=>el.max='8192'")
    page.locator('#outputHeight').evaluate("el=>el.max='8192'")
    page.locator('#outputForm button[type=submit]').click()
    expect(page.locator('#outputError')).to_be_visible()
    assert output()['width']==2048
    page.locator('#outputFPS').fill('121')
    assert not page.locator('#outputFPS').evaluate('el=>el.checkValidity()')
    page.locator('#outputFPS').fill('50')
    page.locator('#outputSize').select_option('1920x1080')
    page.locator('#outputForm button[type=submit]').click()
    assert output()=={'width':1920,'height':1080,'fps':50}
    page.locator('#openOutput').click()
    page.locator('#outputFPS').fill('29.97')
    page.locator('#outputForm button[type=submit]').click()
    assert output()['fps']==29.97
    page.locator('#openProject').click()
    page.once('dialog',lambda dialog:dialog.accept())
    page.locator('#resetProject').click()
    assert output()==default
    page.evaluate("async()=>{await broadcastApp.engine.addSource('text',{text:'2K 60 FPS 中文画布',scrollSpeed:120,width:1500,height:180,fontSize:80});}")
    with page.expect_download(timeout=30000) as event:
        page.evaluate('''async()=>{
          const e=broadcastApp.engine;await e.startRecording();
          window.outputRecordingBitrate=e.recorder.videoBitsPerSecond;
          await new Promise(r=>setTimeout(r,2200));const blob=await e.stopRecording();
          const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='2k-output.webm';a.click();
        }''')
    target=ROOT/'.superpowers/broadcast-2k-output.webm'
    event.value.save_as(target)
    probe='C:/Users/happyelements/AppData/Local/Programs/TRAE SOLO CN/resources/app/bin/ffprobe.exe'
    result=json.loads(subprocess.check_output([probe,'-v','error','-show_entries','stream=width,height,codec_name,codec_type,avg_frame_rate','-of','json',str(target)]))
    video=next(s for s in result['streams'] if s['codec_type']=='video')
    assert (video['width'],video['height'])==(2560,1440),video
    assert page.evaluate('outputRecordingBitrate')==12000000
    decode='C:/Users/happyelements/AppData/Local/Programs/Open Design/resources/app/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
    subprocess.run([decode,'-v','error','-i',str(target),'-f','null','-'],check=True,timeout=30)
    for width,height in [(1440,900),(390,844),(390,400)]:
        page.set_viewport_size({'width':width,'height':height})
        page.locator('#openOutput').click()
        page.locator('#outputSize').select_option('custom')
        box=page.locator('#outputDialog').bounding_box()
        assert box['x']>=0 and box['y']>=0 and box['x']+box['width']<=width+1 and box['y']+box['height']<=height+1,box
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight')
        page.screenshot(path=str(ROOT/f'.superpowers/broadcast-output-{width}-{height}.png'))
        page.locator('#outputDialog [data-close]').click()
    assert not errors,errors
    browser.close()
print(json.dumps({'default':default,'custom_restored':{'width':2048,'height':1536,'fps':48},'custom_recording':custom_recording,'fractional_fps':29.97,'invalid_rejected':True,'reset_default':True,'actual_recording':video,'bytes':target.stat().st_size,'decoded':True,'settings_layouts':3,'page_errors':errors}))
