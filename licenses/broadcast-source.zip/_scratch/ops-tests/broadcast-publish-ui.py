"""Exercise actual publish controls with transport-only mocks; RTP is tested separately."""
import json,os
from playwright.sync_api import sync_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('''window.RTCPeerConnection=class extends EventTarget{
 constructor(){super();this.connectionState='new';this.iceGatheringState='complete';}
 addTransceiver(track){return{sender:{track,getParameters:()=>({encodings:[{}]}),setParameters:async()=>{}}};}
 async createOffer(){return{type:'offer',sdp:'v=0'};}async setLocalDescription(d){this.localDescription=d;}async setRemoteDescription(){this.connectionState='connected';}
 async getStats(){return new Map([['v',{type:'outbound-rtp',kind:'video',timestamp:performance.now(),bytesSent:performance.now()*1000,framesPerSecond:60,frameWidth:1920,frameHeight:1080}],['p',{type:'candidate-pair',state:'succeeded',selected:true,currentRoundTripTime:.042}]]);}close(){this.connectionState='closed';}
 };''')
 cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST, OPTIONS, DELETE','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Expose-Headers':'Location'}
 page.route('https://whip.test/**',lambda r:r.fulfill(status=201,content_type='application/sdp',headers={**cors,'Location':'https://whip.test/session'},body='v=0')if r.request.method=='POST'else r.fulfill(status=204,headers=cors))
 page.goto(BASE+'/tools/broadcast/');page.wait_for_function('broadcastApp.engine?.compositor')
 page.locator('#addSource').click();page.locator('#addText').click()
 page.locator('#openStream').click();assert page.locator('#latencyMode').input_value()=='realtime'
 for w,h in [(1440,900),(1024,768),(390,844),(320,568),(844,390),(390,400)]:
  page.set_viewport_size({'width':w,'height':h});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),('dialog',w,h)
 page.set_viewport_size({'width':1440,'height':900});page.locator('#whipEndpoint').fill('https://whip.test/whip');page.locator('#startStreaming').click()
 try:page.wait_for_function("document.querySelector('#sessionState').dataset.state==='live'",timeout=5000)
 except Exception:
  print(json.dumps({'notice':page.locator('#notice').inner_text(),'streamError':page.locator('#streamError').inner_text(),'errors':errors}));raise
 assert page.locator('.publish-preview').count()==1
 page.locator('[data-property-tab=basic]').click();page.evaluate("broadcastApp.engine.updateSource(broadcastApp.engine.activeScene.sources[0].id,{x:400,y:350,width:900,height:500})")
 before=page.evaluate('broadcastApp.engine.activeScene.sources[0].width');handle=page.locator('button[data-handle=e]').bounding_box();page.mouse.move(handle['x']+handle['width']/2,handle['y']+handle['height']/2);page.mouse.down();page.mouse.move(handle['x']+30,handle['y'],steps=3);page.mouse.up();assert page.evaluate('broadcastApp.engine.activeScene.sources[0].width')>before
 for w,h in [(1440,900),(1024,768),(390,844),(320,568),(844,390),(390,400)]:
  page.set_viewport_size({'width':w,'height':h});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),('live',w,h)
 page.set_viewport_size({'width':1440,'height':900});page.locator('#openStream').click();page.wait_for_function("document.querySelector('#sessionState').dataset.state==='idle'");assert page.locator('.publish-preview').count()==0
 page.locator('#openStream').click();page.locator('#latencyMode').select_option('quality');page.locator('#cancelStreaming').click();page.reload();page.wait_for_function('broadcastApp.engine?.compositor');assert page.locator('#latencyMode').input_value()=='quality'
 assert not errors,errors;print(json.dumps({'publishControls':True,'previewCleanup':True,'modePersists':True,'layouts':12,'errors':errors}));b.close()
