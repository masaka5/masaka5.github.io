import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page()
  await page.goto('http://127.0.0.1:8765/tools/broadcast/')
  await page.wait_for_function('broadcastApp.engine?.compositor')
  await page.wait_for_timeout(800)
  await page.evaluate('''async()=>{
   const store=await import('./store.js');
   await store.saveProject({version:1,width:1280,height:720,fps:30,activeSceneId:'main',scenes:[{id:'main',name:'Saved draft',sources:[{id:'text',type:'text',name:'Important text',text:'keep me'},{id:'broken',type:'image',assetId:'broken-asset',name:'Broken image'}]}]},[{id:'broken-asset',blob:new Blob(['bad'],{type:'image/png'})}]);
  }''')
  await page.reload();await page.wait_for_function('broadcastApp.engine?.compositor')
  await page.wait_for_timeout(1200)
  r=await page.evaluate('''async()=>{const s=await import('./store.js');return {notice:document.querySelector('#notice').textContent,project:await s.readProject(),assets:(await s.readAssets()).length}}''')
  assert len(r['project']['scenes'][0]['sources'])==2 and r['assets']==1,r
  await page.locator('#openProject').click()
  assert await page.locator('#exportRecovery').is_visible()
  async with page.expect_download() as d:await page.locator('#exportRecovery').click()
  raw=Path(await(await d.value).path()).read_bytes();recovery=json.loads(raw)
  assert recovery['project']['scenes'][0]['sources'][0]['text']=='keep me' and len(recovery['assets'])==1,recovery
  assert recovery['assets'][0]['data']=='data:image/png;base64,YmFk',recovery
  await page.locator('#projectDialog [data-close]').click()
  await page.locator('#projectFile').set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':b'{}'})
  await page.wait_for_timeout(800)
  await page.evaluate("window.dispatchEvent(new PageTransitionEvent('pagehide'))")
  await page.reload();await page.wait_for_function('broadcastApp.engine?.compositor');await page.wait_for_timeout(1200)
  afterFailure=await page.evaluate("async()=>{const s=await import('./store.js');return {sources:(await s.readProject()).scenes[0].sources.length,assets:(await s.readAssets()).length,recovery:!document.querySelector('#exportRecovery').hidden}}")
  assert afterFailure=={'sources':2,'assets':1,'recovery':True},afterFailure
  await page.locator('#openProject').click();page.once('dialog',lambda d:d.accept());await page.locator('#resetProject').click();await page.wait_for_timeout(900)
  afterReset=await page.evaluate("async()=>{const s=await import('./store.js');return {sources:(await s.readProject()).scenes[0].sources.length,assets:(await s.readAssets()).length,recovery:!document.querySelector('#exportRecovery').hidden}}")
  assert afterReset=={'sources':0,'assets':0,'recovery':False},afterReset
  await page.locator('#addSource').click();await page.locator('#addText').click();await page.wait_for_timeout(900)
  final=await page.evaluate("async()=>(await(await import('./store.js')).readProject()).scenes[0].sources.length")
  assert final==1,final
  print(json.dumps({'protectedAfterStartup':True,'exportRecovery':True,'failedImportAndPagehide':afterFailure,'explicitReset':afterReset,'newEditsAutosave':final},ensure_ascii=False));await b.close()
asyncio.run(main())
