import {test} from 'node:test';import assert from 'node:assert/strict';
import {shortcutAction} from '../../toolbox-site/tools/broadcast/shortcuts.js';
const key=(name,more={})=>shortcutAction({key:name,target:{closest:()=>null},...more});
test('precise and accelerated movement, resizing, layering and scene hotkeys',()=>{
 assert.deepEqual(key('ArrowRight'),{type:'move',x:1,y:0,step:1});assert.equal(key('ArrowDown',{shiftKey:true}).step,10);assert.equal(key('ArrowLeft',{altKey:true}).type,'resize');assert.deepEqual(key('ArrowUp',{ctrlKey:true}),{type:'layer',step:1});assert.deepEqual(key('3',{altKey:true}),{type:'scene',index:2});
 assert.equal(key('d',{ctrlKey:true}).type,'duplicate');
 for(const[name,type]of [['l','lock'],['h','visible'],['f','fit']]){assert.equal(key(name).type,type);assert.equal(key(name,{ctrlKey:true}),null);}
 assert.equal(key('d',{altKey:true,shiftKey:true}).type,'duplicateScene');assert.equal(key('n',{altKey:true,shiftKey:true}).type,'newScene');assert.equal(key('Delete').type,'delete');assert.equal(key('?').type,'help');
 assert.equal(key('n',{ctrlKey:true,shiftKey:true}),null);assert.equal(key('d',{ctrlKey:true,shiftKey:true}),null);
});
test('IME, handled events and text editing never trigger studio commands',()=>{
 assert.equal(key('d',{ctrlKey:true,isComposing:true}),null);assert.equal(key('Delete',{defaultPrevented:true}),null);assert.equal(key('ArrowRight',{target:{closest:()=>({})}}),null);assert.equal(key('d',{ctrlKey:true,target:{isContentEditable:true}}),null);
});
