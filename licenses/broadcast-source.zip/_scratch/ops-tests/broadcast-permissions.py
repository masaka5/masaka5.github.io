"""Permission failure must preserve the current scene and permit retry."""
import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  browser=await p.chromium.launch();page=await browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/broadcast/');await page.wait_for_function('broadcastApp.engine?.compositor')
  result=await page.evaluate('''async()=>{
   const engine=broadcastApp.engine;const text=await engine.addSource('text',{text:'保留现有场景'});const before=JSON.stringify(engine.snapshot());
   const user=navigator.mediaDevices.getUserMedia,display=navigator.mediaDevices.getDisplayMedia;
   navigator.mediaDevices.getUserMedia=async()=>{throw new DOMException('Denied','NotAllowedError')};
   navigator.mediaDevices.getDisplayMedia=async()=>{throw new DOMException('Denied','NotAllowedError')};
   const denied=[];for(const type of ['camera','microphone','screen','window']){try{await engine.addSource(type)}catch(error){denied.push(error.name)}}
   navigator.mediaDevices.getUserMedia=user;navigator.mediaDevices.getDisplayMedia=display;
   return {denied,preserved:JSON.stringify(engine.snapshot())===before,runtimes:engine.runtimes.size,text:engine.getSource(text.id).text};
  }''')
  assert result['denied']==['NotAllowedError']*4 and result['preserved']and result['runtimes']==0,result
  assert not errors,errors;print(json.dumps(result,ensure_ascii=False));await browser.close()
asyncio.run(main())
