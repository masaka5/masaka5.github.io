"""Native touch resizing and capture track ownership after keyboard duplication."""
import json,os
from playwright.sync_api import sync_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
with sync_playwright()as p:
 b=p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream'])
 page=b.new_page(viewport={'width':1440,'height':900},has_touch=True);errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'/tools/broadcast/');page.wait_for_function('broadcastApp.engine?.compositor')
 page.locator('#addSource').click();page.locator('#addText').click()
 page.evaluate('broadcastApp.engine.updateSource(broadcastApp.engine.activeScene.sources[0].id,{x:400,y:350,width:800,height:400})')
 page.locator('[data-property-tab=basic]').click()
 before=page.evaluate('broadcastApp.engine.activeScene.sources[0].width')
 box=page.locator('[data-handle=se]').bounding_box();x=box['x']+box['width']/2;y=box['y']+box['height']/2
 cdp=page.context.new_cdp_session(page)
 cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
 cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+40,'y':y+20}]})
 cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
 assert page.evaluate('broadcastApp.engine.activeScene.sources[0].width')>before
 assert not page.evaluate('document.getElementById("selectionOverlay").classList.contains("transforming")')
 # Arrow keys work on a focused resize handle; editing a text field does not move it.
 before=page.evaluate('broadcastApp.engine.activeScene.sources[0].width');page.locator('button[data-handle=e]').focus();page.keyboard.press('ArrowRight')
 assert page.evaluate('broadcastApp.engine.activeScene.sources[0].width')>before
 page.locator('#sourceName').fill('移动与缩放');page.keyboard.press('Delete')
 assert page.evaluate('broadcastApp.engine.activeScene.sources.length')==1
 captures=page.evaluate('''async()=>{
 const e=broadcastApp.engine;await e.loadProject({width:640,height:360});
 const camera=await e.addSource('camera'),mic=await e.addSource('microphone');
 const cameraTrack=e.runtimes.get(camera.id).stream.getVideoTracks()[0],micTrack=e.runtimes.get(mic.id).stream.getAudioTracks()[0];
 const copy=await e.duplicateSource(camera.id),copyTrack=e.runtimes.get(copy.id).stream.getVideoTracks()[0];e.deleteSource(copy.id);
 if(copyTrack.readyState!=='ended'||cameraTrack.readyState!=='live')throw Error('source track ownership');
 const originalScene=e.activeScene.id,clone=await e.duplicateScene();
 const cloneCamera=clone.sources.find(s=>s.type==='camera'),cloneMic=clone.sources.find(s=>s.type==='microphone');
 const newVideo=e.runtimes.get(cloneCamera.id).stream.getVideoTracks()[0],newAudio=e.runtimes.get(cloneMic.id).stream.getAudioTracks()[0];
 if(newVideo.id===cameraTrack.id||newAudio.id===micTrack.id)throw Error('capture was not cloned');
 e.deleteScene(clone.id);e.switchScene(originalScene);
 return{camera:cameraTrack.readyState,mic:micTrack.readyState,deletedVideo:newVideo.readyState,deletedAudio:newAudio.readyState};
 }''')
 assert captures=={'camera':'live','mic':'live','deletedVideo':'ended','deletedAudio':'ended'},captures
 page.locator('#sourceList .item-row').last.click();page.locator('[data-property-tab=filters]').click()
 page.screenshot(path='_scratch/broadcast-editor-tests/filters.png')
 assert not errors,errors
 print(json.dumps({'touchResize':True,'focusedHandleKeys':True,'captureOwnership':captures,'errors':errors}));b.close()
