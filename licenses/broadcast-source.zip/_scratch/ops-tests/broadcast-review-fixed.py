import asyncio, json, base64
from playwright.async_api import async_playwright

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--autoplay-policy=no-user-gesture-required'])
  page=await b.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto('http://127.0.0.1:8765/tools/broadcast/')
  await page.wait_for_function('broadcastApp.engine?.compositor')
  await page.locator('#addSource').click();await page.locator('#addCamera').click()
  await page.wait_for_function("broadcastApp.engine.activeScene.sources.some(s=>s.type==='camera')")
  await page.evaluate("window.original=broadcastApp.engine.snapshot();window.cameraTrack=broadcastApp.engine.runtimes.get(original.scenes[0].sources[0].id).stream.getVideoTracks()[0]")
  bad={'kind':'toolbox-broadcast','version':1,'project':{'version':1,'width':1280,'height':720,'fps':30,'activeSceneId':'new','scenes':[{'id':'new','name':'broken-import','sources':[{'id':'bad','type':'image','name':'bad image','assetId':'bad-asset'}]}]},'assets':[{'id':'bad-asset','data':'data:image/png;base64,YmFk'}]}
  await page.locator('#projectFile').set_input_files({'name':'bad-asset.json','mimeType':'application/json','buffer':json.dumps(bad).encode()})
  await page.wait_for_function("document.querySelector('#notice').dataset.error==='true'")
  result=await page.evaluate('''()=>({projectUnchanged:JSON.stringify(original)===JSON.stringify(broadcastApp.engine.snapshot()),sameTrack:cameraTrack===broadcastApp.engine.runtimes.get(original.scenes[0].sources[0].id).stream.getVideoTracks()[0],trackState:cameraTrack.readyState,badRuntimeExists:broadcastApp.engine.runtimes.has('bad'),badAssetExists:broadcastApp.engine.assets.has('bad-asset')})''')
  assert result=={'projectUnchanged':True,'sameTrack':True,'trackState':'live','badRuntimeExists':False,'badAssetExists':False},result
  await page.locator('#toggleRecording').click();await page.wait_for_function('broadcastApp.engine.recording')
  await page.evaluate('broadcastApp.engine._recordBytes=2000000001')
  await page.wait_for_function('!broadcastApp.engine.recording')
  await page.wait_for_function("document.querySelector('#notice').textContent.includes('已保存')")
  rec=await page.evaluate('''async()=>{const all=await(await import('./store.js')).listRecordings();return {count:all.length,bytes:all[0]?.blob.size}}''')
  assert rec['count']==1 and rec['bytes']>1000,rec
  png=await page.evaluate("()=>{const c=document.createElement('canvas');c.width=20;c.height=20;const x=c.getContext('2d');x.fillStyle='red';x.fillRect(0,0,20,20);return c.toDataURL().split(',')[1]}")
  await page.locator('#imageFile').set_input_files({'name':'private.png','mimeType':'image/png','buffer':base64.b64decode(png)})
  await page.wait_for_function('broadcastApp.engine.assets.size===1')
  page.once('dialog',lambda d:d.accept())
  await page.locator('#openProject').click();await page.locator('#resetProject').click()
  await page.wait_for_function('broadcastApp.engine.activeScene.sources.length===0')
  reset=await page.evaluate('''async()=>{const e=broadcastApp.engine,s=await import('./store.js'),data=JSON.parse(await(await s.exportProject(e.snapshot(),e.exportAssets())).text());return {assets:e.assets.size,exported:data.assets.length,track:cameraTrack.readyState}}''')
  assert reset=={'assets':0,'exported':0,'track':'ended'},reset
  video=await page.evaluate('''async()=>{const c=document.createElement('canvas');c.width=160;c.height=90;const x=c.getContext('2d'),s=c.captureStream(15),parts=[],r=new MediaRecorder(s,{mimeType:'video/webm'});let n=0;const t=setInterval(()=>{x.fillStyle=`hsl(${n++*20} 80% 50%)`;x.fillRect(0,0,160,90)},60);const done=new Promise(resolve=>{r.ondataavailable=e=>parts.push(e.data);r.onstop=()=>resolve(new Blob(parts,{type:'video/webm'}))});r.start();await new Promise(resolve=>setTimeout(resolve,1000));r.stop();const blob=await done;clearInterval(t);s.getTracks().forEach(t=>t.stop());return await new Promise(resolve=>{const f=new FileReader();f.onload=()=>resolve(f.result.split(',')[1]);f.readAsDataURL(blob)})}''')
  await page.locator('#videoFile').set_input_files({'name':'local.webm','mimeType':'video/webm','buffer':base64.b64decode(video)})
  await page.wait_for_function("broadcastApp.engine.activeScene.sources.some(s=>s.type==='video')")
  await page.locator('[data-property-tab=content]').click();await page.locator('#toggleVideo').click()
  await page.locator('[data-property-tab=basic]').click();await page.locator('#sourceX').fill('100');await page.locator('#sourceX').dispatch_event('change')
  pause=await page.evaluate('''async()=>{const e=broadcastApp.engine,v=e.activeScene.sources.find(s=>s.type==='video');await e.resumeAudio();return {flag:v.paused,element:e.runtimes.get(v.id).element.paused}}''')
  assert pause=={'flag':True,'element':True},pause
  marquee=await page.evaluate('''async()=>{
    const e=broadcastApp.engine;await e.loadProject({});e.setOutput({width:640,height:360,fps:30});
    const a=await e.addSource('text',{width:100,height:100,x:0,y:0,text:'MMMMMMMMMM-SECRET-A',fontSize:48,scrollSpeed:30});
    const first=e.compositor.textImage(a,1000).toDataURL();e.updateSource(a.id,{text:'MMMMMMMMMM-SECRET-B'});const second=e.compositor.textImage(a,1000).toDataURL();
    const get=()=>{const gl=e.compositor.gl,p=new Uint8Array(640*360*4);gl.readPixels(0,0,640,360,gl.RGBA,gl.UNSIGNED_BYTE,p);let sum=0;for(const n of p)sum=(sum+n)%1000000007;return sum};
    const ctx=e.compositor.cache.get(a.id).textCanvas.getContext('2d');ctx.font='bold 48px sans-serif';const tail=ctx.measureText('MMMMMMMMMM-SECRET-').width;const time=tail/30*1000;
    e.compositor.render(e.activeScene,e.runtimes,time);const suffixB=get();e.updateSource(a.id,{text:'MMMMMMMMMM-SECRET-A'});e.compositor.render(e.activeScene,e.runtimes,time);const suffixA=get();
    return {rasterDiff:first!==second,frameTailDiff:suffixA!==suffixB,suffixA,suffixB};
  }''')
  assert marquee['rasterDiff'] and marquee['frameTailDiff'],marquee
  await page.reload();await page.wait_for_function('broadcastApp.engine?.compositor')
  persisted=await page.evaluate("async()=>({recordings:(await(await import('./store.js')).listRecordings()).length})")
  assert persisted['recordings']==1,persisted
  assert not errors,errors
  print(json.dumps({'invalidImport':result,'automaticRecordingSaved':rec,'resetPrivacy':reset,'pauseUI':pause,'marqueeTail':marquee,'refreshPersisted':persisted,'pageErrors':errors},ensure_ascii=False))
  await b.close()

asyncio.run(main())
