import asyncio, json
from playwright.async_api import async_playwright

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream','--autoplay-policy=no-user-gesture-required'])
  page=await b.new_page(viewport={'width':1440,'height':900})
  await page.goto('http://127.0.0.1:8765/tools/broadcast/')
  await page.wait_for_function('broadcastApp.engine?.compositor')
  print(json.dumps(await page.evaluate('''async()=>{
    const e=broadcastApp.engine;
    const a=await e.addSource('text',{width:100,height:100,text:'MMMMMMMMMM-SECRET-A',fontSize:48,scrollSpeed:30});
    const aCanvas=e.compositor.textImage(a,1000).toDataURL();
    e.updateSource(a.id,{text:'MMMMMMMMMM-SECRET-B'});
    const bCanvas=e.compositor.textImage(a,1000).toDataURL();
    e.deleteSource(a.id);
    const c=document.createElement('canvas');c.width=160;c.height=90;const x=c.getContext('2d');x.fillStyle='red';x.fillRect(0,0,160,90);
    const chunks=[],s=c.captureStream(15),r=new MediaRecorder(s,{mimeType:'video/webm'});
    const result=new Promise(resolve=>{r.ondataavailable=ev=>chunks.push(ev.data);r.onstop=()=>resolve(new Blob(chunks,{type:'video/webm'}));});r.start();await new Promise(r=>setTimeout(r,300));r.stop();const blob=await result;s.getTracks().forEach(t=>t.stop());
    const v=await e.addSource('video',{file:new File([blob],'test.webm',{type:'video/webm'})});const video=e.runtimes.get(v.id).element;
    video.pause();const before=video.paused;e.updateSource(v.id,{x:100});const after=video.paused;e.deleteSource(v.id);
    return {marqueeDifferentSuffixRasterIdentical:aCanvas===bCanvas,videoPauseBefore:before,videoPauseAfterLayoutEdit:after};
  }'''),ensure_ascii=False))
  await page.locator('#addSource').click();await page.locator('#addText').click()
  before=await page.evaluate('broadcastApp.engine.activeScene.sources[0].id')
  bad={'kind':'toolbox-broadcast','version':1,'project':{'version':1,'width':1280,'height':720,'fps':30,'activeSceneId':'new','scenes':[{'id':'new','name':'broken-import','sources':[{'id':'bad','type':'image','name':'bad image','assetId':'bad-asset'}]}]},'assets':[{'id':'bad-asset','data':'data:image/png;base64,YmFk'}]}
  await page.locator('#projectFile').set_input_files({'name':'bad-asset.json','mimeType':'application/json','buffer':json.dumps(bad).encode()})
  await page.wait_for_timeout(1000)
  result=await page.evaluate('''()=>({notice:document.querySelector('#notice').textContent,scene:broadcastApp.engine.activeScene.name,sources:broadcastApp.engine.activeScene.sources.map(s=>s.id),status:broadcastApp.engine.getSourceStatus('bad')})''')
  print(json.dumps({'beforeSource':before,'badImport':result},ensure_ascii=False))
  await page.locator('#toggleRecording').click();await page.wait_for_function('broadcastApp.engine.recording')
  await page.evaluate('broadcastApp.engine._recordBytes=2000000001')
  await page.wait_for_function('!broadcastApp.engine.recording')
  await page.wait_for_timeout(300)
  print(json.dumps(await page.evaluate('''async()=>({automaticStop:{recording:broadcastApp.engine.recording,blobSize:broadcastApp.engine.recordingBlob?.size,stored:(await (await import('./store.js')).listRecordings()).length,notice:document.querySelector('#notice').textContent}})'''),ensure_ascii=False))
  await b.close()

asyncio.run(main())
