import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import{readFileSync}from'node:fs';
test('worker clock has one outstanding notification and never builds an unbounded main-thread backlog',()=>{
 let time=0,next,sent=0;const context={performance:{now:()=>time},postMessage:()=>sent++,setTimeout:fn=>(next=fn,1),clearTimeout:()=>{},onmessage:null};vm.createContext(context);vm.runInContext(readFileSync(new URL('../../toolbox-site/tools/broadcast/frame-clock.js',import.meta.url),'utf8'),context);
 context.onmessage({data:60});for(let i=0;i<100;i++){time+=17;next();}assert.equal(sent,1);context.onmessage({data:{ack:true}});time+=17;next();assert.equal(sent,2);
});
