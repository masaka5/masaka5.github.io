import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch(args=['--use-fake-device-for-media-stream','--use-fake-ui-for-media-stream']);page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(BASE+'/tools/broadcast/');assert await page.locator('#outputCanvas').count()==1,'缺少直播画布'
  await page.wait_for_function('window.broadcastApp?.engine')
  await page.locator('#addSource').click();await page.locator('#addText').click();await page.locator('#sourceText').fill('中文直播标题');await page.locator('#sourceText').dispatch_event('change')
  assert await page.evaluate("broadcastApp.engine.snapshot().scenes[0].sources.some(s=>s.text==='中文直播标题')")
  await page.locator('[data-property-tab=basic]').click();await page.locator('#sourceRotation').fill('25');await page.locator('#sourceRotation').dispatch_event('change')
  assert await page.evaluate('broadcastApp.engine.snapshot().scenes[0].sources[0].rotation')==25
  await page.locator('#newScene').click();assert len(await page.evaluate('broadcastApp.engine.snapshot().scenes'))==2
  for w,h in [(1440,900),(1024,768),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
  assert not errors,errors;print(json.dumps({'text_transform_scene':True,'layouts':6,'errors':errors}));await b.close()
asyncio.run(main())
