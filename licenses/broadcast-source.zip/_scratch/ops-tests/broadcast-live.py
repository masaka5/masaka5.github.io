"""Check the deployed studio, catalog and engine assets against this release."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,json,subprocess,os
ROOT=Path(__file__).resolve().parents[2];SITE=ROOT/'toolbox-site';REPO=ROOT/'_scratch/masaka5-toolbox-upstream'
tag=subprocess.check_output(['git','rev-parse','--short','HEAD'],cwd=REPO,text=True).strip()
paths=['assets/catalog-base.js','assets/catalog.js','assets/tool-icon-paths.js','licenses/sources.json','licenses/broadcast-source.zip','tools/broadcast/manifest.json']
if not os.getenv('BROADCAST_ONLY'):paths+=['vendor/qemu/manifest.json','vendor/qemu/network.js','vendor/qemu/fetch-request.js','tools/webvm/vm-core.js','tools/webvm/images/ubuntu-manifest.json']
manifest=json.loads((SITE/'tools/broadcast/manifest.json').read_text());paths+=['tools/broadcast/'+e['file']for e in manifest['files']]
def check(path):
 with urllib.request.urlopen('https://tools.manshii.asia/'+path+'?release='+tag,timeout=60)as response:data=response.read();assert response.status==200
 assert hashlib.sha256(data).digest()==hashlib.sha256((SITE/path).read_bytes()).digest(),path
 return path
with ThreadPoolExecutor(max_workers=6)as pool:verified=list(pool.map(check,paths))
print(json.dumps({'release':tag,'https_files_match':len(verified)}))
