# 直播工作台

纯静态 ES modules，无需构建或后端。放入工具箱部署目录，使用 HTTPS 或 localhost 访问 tools/broadcast/。
WebGL 合成、Web Audio 混音、MediaRecorder 录像；场景与录像存储于当前浏览器 IndexedDB。
摄像头、麦克风和共享屏幕需要用户授权；窗口及系统声音取决于浏览器支持。
WHIP 需要允许浏览器跨域访问的外部端点。RTMP 需要用户已有的 api.video-browser-to-rtmp 兼容 WSS 网关；网页本身不提供该服务。“转发已连接”仅确认网关收到媒体，直播平台是否接收需在平台确认。
真实浏览器测试使用 Python Playwright；推流传输测试的临时接收器只用于测试，不属于部署内容。
核心协议测试：node --test _scratch/ops-tests/broadcast-engine-core.mjs _scratch/ops-tests/broadcast-engine-pacing.mjs _scratch/ops-tests/broadcast-publisher.test.mjs。
浏览器测试：broadcast-ui.py、broadcast-workflow.py、broadcast-engine-browser.py、broadcast-publisher-real.py。
参考开源项目与固定版本记录在 manifest.json；协议独立实现，没有复制参考项目代码。图标使用工具箱现有 Lucide，保留原 ISC 许可。
