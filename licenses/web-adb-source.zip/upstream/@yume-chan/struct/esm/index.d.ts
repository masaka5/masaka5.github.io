declare global {
    interface ArrayBuffer {
        __brand: never;
    }
    interface SharedArrayBuffer {
        __brand: never;
    }
}
export * from "./bipedal.js";
export * from "./buffer.js";
export * from "./concat.js";
export * from "./extend.js";
export * from "./field/index.js";
export * from "./number.js";
export * from "./readable.js";
export * from "./string.js";
export * from "./struct.js";
export * from "./types.js";
export * from "./utils.js";
//# sourceMappingURL=index.d.ts.map