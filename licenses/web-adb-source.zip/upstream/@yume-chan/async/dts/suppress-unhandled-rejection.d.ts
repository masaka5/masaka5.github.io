/**
 * Suppress Node.js unhandled rejection warning for a Promise
 * @param promise The Promise to suppress unhandled rejection warnings for
 */
export declare function suppressUnhandledRejection(promise: Promise<unknown>): void;
//# sourceMappingURL=suppress-unhandled-rejection.d.ts.map