import { noop } from "./no-op.ts";

/**
 * Suppress Node.js unhandled rejection warning for a Promise
 * @param promise The Promise to suppress unhandled rejection warnings for
 */
export function suppressUnhandledRejection(promise: Promise<unknown>): void {
    promise.catch(noop);
}
