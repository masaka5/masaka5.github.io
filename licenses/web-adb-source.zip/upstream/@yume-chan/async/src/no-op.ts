/* #__NO_SIDE_EFFECTS__ */
export function noop(): void {}
