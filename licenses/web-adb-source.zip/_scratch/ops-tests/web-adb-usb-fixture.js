// Test-only WebUSB ADB daemon emulator. Never shipped in production.
// Runs real official WebUSB/auth/packet multiplexing, shell v2 and sync code.
(() => {
  const enc=new TextEncoder(),dec=new TextDecoder();
  const text=v=>enc.encode(v),u32=n=>{const b=new Uint8Array(4);new DataView(b.buffer).setUint32(0,n,true);return b;};
  const join=(...items)=>{const b=new Uint8Array(items.reduce((n,a)=>n+a.length,0));let p=0;for(const a of items){b.set(a,p);p+=a.length;}return b;};
  const integer=(b,p=0)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p,true);
  const shellPacket=(id,data)=>join(new Uint8Array([id]),u32(data.length),data);
  const cmd=s=>integer(text(s));
  const log=[];window.usbLog=log;
  const sockets=new Map(),files=new Map([['/sdcard/中文.txt',text('你好 USB\n')]]);
  let nextId=30,queue=[],waiters=[],pendingHeader,closed=false;
  const enqueue=bytes=>{if(waiters.length)waiters.shift().resolve({status:'ok',data:new DataView(bytes.buffer)});else queue.push(bytes);};
  const packet=(name,arg0=0,arg1=0,payload=new Uint8Array())=>{
    const n=cmd(name);enqueue(join(u32(n),u32(arg0),u32(arg1),u32(payload.length),u32(payload.reduce((a,b)=>a+b,0)),u32((n^0xffffffff)>>>0)));
    if(payload.length)enqueue(payload.slice());
  };
  function send(socket,data,finish=false){socket.outgoing.push({data,finish});setTimeout(()=>flush(socket),0);}
  function flush(socket){if(socket.awaiting||!socket.outgoing.length)return;const next=socket.outgoing.shift();socket.awaiting=true;socket.finish=next.finish;packet('WRTE',socket.id,socket.client,next.data);}
  function finish(socket){packet('CLSE',socket.id,socket.client);}
  function commandOutput(service){
    if(service.startsWith('exec:getprop '))return text(({'ro.product.model':'Protocol Test Android','ro.product.manufacturer':'Fixture','ro.build.version.release':'14','ro.build.version.sdk':'34','ro.product.cpu.abi':'arm64-v8a'})[service.split(' ').at(-1)]+'\n');
    if(service==='exec:screencap -p')return Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jB9kAAAAASUVORK5CYII='),c=>c.charCodeAt(0));
    return text('');
  }
  function open(client,payload){
    const service=dec.decode(payload).replace(/\0$/,'');log.push({type:'open',service});
    const socket={id:nextId++,client,service,outgoing:[],buffer:new Uint8Array()};sockets.set(socket.id,socket);packet('OKAY',socket.id,client);
    if(service==='sync:')return;
    if(service.startsWith('shell,v2,pty')){send(socket,shellPacket(1,text('fixture:/ $ ')));return;}
    if(service.startsWith('shell,v2,raw:')){
      const command=service.slice('shell,v2,raw:'.length);let output='';
      if(command==='dumpsys battery')output='level: 88\nstatus: 2\n';
      if(command.startsWith('pm install'))output='Success\n';
      send(socket,join(shellPacket(1,text(output)),shellPacket(3,new Uint8Array([0]))),true);return;
    }
    const output=commandOutput(service);if(output.length)send(socket,output,true);else finish(socket);
  }
  function sync(socket,data){
    socket.buffer=join(socket.buffer,data);
    while(socket.buffer.length>=8){
      const id=dec.decode(socket.buffer.slice(0,4)),length=integer(socket.buffer,4),needed=id==='DONE'?8:8+length;
      if(socket.buffer.length<needed)return;
      const payload=socket.buffer.slice(8,needed);socket.buffer=socket.buffer.slice(needed);
      log.push({type:'sync',id,path:id==='DATA'?'':dec.decode(payload)});
      if(id==='LIST'){
        const path=dec.decode(payload);const entries=path==='/sdcard'?[['下载',0o40755,0],['中文.txt',0o100644,files.get('/sdcard/中文.txt').length]]:[];
        const responses=entries.map(([name,mode,size])=>join(text('DENT'),u32(mode),u32(size),u32(1700000000),u32(text(name).length),text(name)));
        send(socket,join(...responses,text('DONE'),new Uint8Array(16)));
      } else if(id==='RECV'){
        const data=files.get(dec.decode(payload))||text('download');send(socket,join(text('DATA'),u32(data.length),data,text('DONE'),u32(0)));
      } else if(id==='SEND'){socket.filename=dec.decode(payload).replace(/,\d+$/,'');socket.upload=[];}
      else if(id==='DATA'){socket.upload.push(payload);}
      else if(id==='DONE'){files.set(socket.filename,join(...socket.upload));send(socket,join(text('OKAY'),u32(0)));}
      else if(id==='STAT'){send(socket,join(text('STAT'),u32(0o40755),u32(0),u32(0)));}
      else if(id==='QUIT'){finish(socket);}
    }
  }
  function receive(header,payload){
    const name=dec.decode(header.slice(0,4)),a=integer(header,4),b=integer(header,8);
    log.push({type:'packet',name,a,b});
    if(name==='CNXN'){
      if(window.usbMode==='auth-pending')return;
      packet('CNXN',0x1000001,1024*1024,text('device::ro.product.name=fixture;ro.product.model=Protocol Test Android;features=shell_v2,fixed_push_mkdir;'));return;
    }
    if(name==='OPEN'){open(a,payload);return;}
    const socket=sockets.get(b);if(!socket)return;
    if(name==='OKAY'){socket.awaiting=false;if(socket.finish){finish(socket);socket.finish=false;}else flush(socket);}
    if(name==='WRTE'){
      packet('OKAY',socket.id,a);
      if(socket.service==='sync:')sync(socket,payload);
      else if(socket.service.startsWith('shell,v2,pty')){
        const id=payload[0],data=payload.slice(5);log.push({type:'pty',id,text:dec.decode(data)});
        if(id===0)send(socket,shellPacket(1,data));
      }
    }
    if(name==='CLSE'){packet('CLSE',socket.id,a);sockets.delete(socket.id);}
  }
  const alt={alternateSetting:0,interfaceClass:255,interfaceSubclass:66,interfaceProtocol:1,endpoints:[{endpointNumber:1,direction:'in',packetSize:512},{endpointNumber:1,direction:'out',packetSize:512}]};
  const intf={interfaceNumber:0,claimed:false,alternate:alt,alternates:[alt]};
  const configuration={configurationValue:1,interfaces:[intf]};
  const raw={serialNumber:'test-usb-123',productName:'Protocol Test Android',vendorId:0x18d1,productId:4,opened:false,configurations:[configuration],configuration,
    async open(){closed=false;this.opened=true;},async selectConfiguration(){},async claimInterface(){if(window.usbMode==='busy')throw new DOMException('Unable to claim interface','NetworkError');intf.claimed=true;},
    async close(){this.opened=false;closed=true;intf.claimed=false;for(const waiter of waiters.splice(0))waiter.reject(new Error('USB closed'));queue=[];log.push({type:'close'});},
    async transferOut(endpoint,buffer){const data=new Uint8Array(buffer.buffer||buffer,buffer.byteOffset||0,buffer.byteLength).slice();if(!data.length)return {status:'ok'};
      if(pendingHeader){const header=pendingHeader;pendingHeader=undefined;receive(header,data);}else if(integer(data,12)){pendingHeader=data;}else receive(data,new Uint8Array());return {status:'ok'};},
    async transferIn(){if(closed)throw Error('USB closed');if(queue.length){const bytes=queue.shift();return {status:'ok',data:new DataView(bytes.buffer)};}return new Promise((resolve,reject)=>waiters.push({resolve,reject}));}
  };
  const usb=new EventTarget();usb.getDevices=async()=>[raw];usb.requestDevice=async()=>{
    log.push({type:'request'});if(window.usbMode==='cancel')throw new DOMException('No device selected','NotFoundError');return raw;
  };
  Object.defineProperty(navigator,'usb',{value:usb,configurable:true});
  window.usbUnplug=()=>{const e=new Event('disconnect');Object.defineProperty(e,'device',{value:raw});usb.dispatchEvent(e);raw.close();};
  window.usbFiles=files;
  // Native constructor checks USBDevice brand; this fixture supplies the equivalent event.
  window.USBConnectionEvent=class extends Event{constructor(type,options){super(type);this.device=options.device;}};
})();
