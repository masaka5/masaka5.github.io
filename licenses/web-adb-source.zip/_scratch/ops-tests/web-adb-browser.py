"""Real Chromium UI with test-only raw WebUSB ADB daemon emulation, not a phone test."""
import asyncio,json,os,sys
from pathlib import Path
from playwright.async_api import async_playwright
BASE=os.environ.get('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
sys.stdout.reconfigure(encoding='utf8')
HERE=Path(__file__).resolve().parent
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch()
  page=await browser.new_page(viewport={'width':1440,'height':900},accept_downloads=True)
  errors=[];external=[];failed=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:external.append(r.url) if r.url.startswith('http') and not r.url.startswith(BASE) else None)
  page.on('response',lambda r:failed.append((r.status,r.url)) if r.status>=400 else None)
  await page.add_init_script(path=str(HERE/'web-adb-usb-fixture.js'))
  await page.goto(BASE+'/tools/web-adb/')
  await page.get_by_role('button',name='连接设备',exact=True).click()
  await page.wait_for_function("() => document.querySelector('#connection-state').textContent==='已连接'")
  try:
   await page.get_by_text('arm64-v8a',exact=True).wait_for(timeout=6000)
  except:
   print('DEBUG',await page.locator('#operation-message').inner_text(),await page.evaluate('usbLog'),errors)
   raise
  assert '88%' in await page.locator('#device-info').inner_text()
  await page.screenshot(path=str(HERE/'web-adb-desktop.png'))
  await page.get_by_role('button',name='终端',exact=True).click()
  await page.get_by_role('button',name='打开终端',exact=True).click()
  await page.wait_for_function("() => window.usbLog.some(x=>x.type==='pty'&&x.id===5)")
  await page.locator('.xterm-helper-textarea').focus()
  await page.keyboard.insert_text('echo 你好')
  await page.get_by_role('button',name='Ctrl+C',exact=True).click()
  await page.wait_for_function("() => window.usbLog.some(x=>x.type==='pty'&&x.text.includes('你好'))")
  await page.wait_for_function("() => window.usbLog.some(x=>x.type==='pty'&&x.text==='\\x03')")
  await page.screenshot(path=str(HERE/'web-adb-terminal.png'))
  await page.get_by_role('button',name='文件',exact=True).click()
  await page.get_by_role('button',name='文件 中文.txt').wait_for()
  async with page.expect_download() as info:
   await page.get_by_role('button',name='文件 中文.txt').click()
  download=await info.value
  assert Path(await download.path()).read_bytes()=='你好 USB\n'.encode()
  await page.locator('#upload-input').set_input_files({'name':'upload 测试.txt','mimeType':'text/plain','buffer':b'file-data-123'})
  await page.wait_for_function("() => window.usbFiles.has('/sdcard/upload 测试.txt')")
  assert await page.evaluate("new TextDecoder().decode(window.usbFiles.get('/sdcard/upload 测试.txt'))")=='file-data-123'
  await page.wait_for_function("() => document.querySelector('#cancel-operation').hidden")
  await page.get_by_role('button',name='目录 下载').click()
  await page.wait_for_function("() => document.querySelector('#path').value==='/sdcard/下载'")
  await page.get_by_role('button',name='上级目录',exact=True).click()
  await page.wait_for_function("() => document.querySelector('#path').value==='/sdcard'")
  await page.get_by_role('button',name='安装 APK',exact=True).click()
  await page.locator('#apk-input').set_input_files({'name':'应用.apk','mimeType':'application/vnd.android.package-archive','buffer':b'APK-fixture-bytes'})
  page.once('dialog',lambda d:d.accept())
  await page.get_by_role('button',name='安装到设备',exact=True).click()
  await page.get_by_text('APK 安装成功。',exact=True).wait_for()
  assert await page.evaluate("window.usbLog.some(x=>x.type==='open'&&x.service.startsWith('shell,v2,raw:pm install -r'))")
  assert await page.evaluate("window.usbLog.some(x=>x.type==='open'&&x.service.startsWith('shell,v2,raw:rm -f'))")
  await page.get_by_role('button',name='截图',exact=True).click()
  await page.get_by_role('button',name='获取截图',exact=True).click()
  await page.locator('#screenshot').wait_for(state='visible')
  async with page.expect_download() as info:await page.get_by_role('button',name='保存 PNG',exact=True).click()
  assert Path(await(await info.value).path()).read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
  await page.evaluate('window.usbUnplug()')
  await page.wait_for_function("() => document.querySelector('#connection-state').textContent==='未连接'")
  await page.evaluate("window.usbMode='cancel'")
  await page.get_by_role('button',name='连接设备',exact=True).click()
  await page.get_by_text('已取消选择设备。',exact=True).wait_for()
  await page.evaluate("window.usbMode='busy'")
  await page.get_by_role('button',name='连接设备',exact=True).click()
  await page.get_by_text('USB 接口正被占用。请先退出桌面 adb 或其他调试工具，再连接。',exact=True).wait_for()
  await page.evaluate("window.usbMode='auth-pending'")
  await page.get_by_role('button',name='连接设备',exact=True).click()
  await page.get_by_role('button',name='取消连接',exact=True).wait_for()
  await page.get_by_role('button',name='取消连接',exact=True).click()
  await page.get_by_text('已断开连接。',exact=True).wait_for()
  await page.evaluate("window.usbMode='cancel'")
  for width,height in [(1440,900),(1024,768),(390,844),(360,640),(844,390)]:
   await page.set_viewport_size({'width':width,'height':height})
   for tab in ['设备信息','终端','文件','安装 APK','截图']:
    await page.get_by_role('button',name=tab,exact=True).click()
    metrics=await page.evaluate('({w:innerWidth,h:innerHeight,sw:document.documentElement.scrollWidth,sh:document.documentElement.scrollHeight})')
    assert metrics['sw']<=metrics['w'] and metrics['sh']<=metrics['h'],(width,height,tab,metrics,await page.locator('#apk-input').bounding_box())
   if width==390:
    await page.get_by_role('button',name='设备信息',exact=True).click()
    await page.screenshot(path=str(HERE/'web-adb-mobile.png'))
  await page.get_by_role('button',name='连接指南',exact=True).click()
  await page.get_by_role('button',name='知道了',exact=True).click()
  unsupported=await browser.new_page()
  await unsupported.add_init_script("Object.defineProperty(navigator,'usb',{value:undefined,configurable:true})")
  await unsupported.goto(BASE+'/tools/web-adb/')
  assert await unsupported.get_by_role('button',name='连接设备',exact=True).is_disabled()
  assert '当前浏览器不支持 WebUSB' in await unsupported.locator('#connection-message').inner_text()
  assert errors==[],errors
  assert external==[],external
  assert failed==[],failed
  report={'result':'passed','hardware':'test-only raw WebUSB ADB daemon; no real phone WebUSB tested','checks':['official WebUSB handshake/multiplexing','getprop/battery','shell v2 PTY input/resize/Ctrl+C','sync LIST/RECV/SEND Unicode','APK install Success + cleanup','raw exec PNG download','USB unplug','chooser cancellation','interface busy','pending authentication cancel','unsupported browser','5 responsive viewports','no document overflow','zero external requests','zero page errors'],'usbEvents':await page.evaluate('usbLog')}
  (HERE/'web-adb-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
  await browser.close()
  print(json.dumps({k:v for k,v in report.items() if k!='usbEvents'},ensure_ascii=False))
asyncio.run(main())
