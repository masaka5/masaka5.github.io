import test from 'node:test';
import assert from 'node:assert/strict';
import { AdbSession, deviceError, normalizePath, joinPath, collectBytes, shellQuote, DeviceActions } from '../web-adb-integration/src/core.mjs';

const deferred = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a; reject=b;}); return {promise,resolve,reject}; };
function rig(overrides={}) {
  const disconnected=deferred(); const events=[]; let closed=0;
  const raw={close:async()=>{closed++;}};
  const device={raw,serial:'test',connect:async()=>({})};
  const adb={serial:'test',close:async()=>{closed++;},disconnected:disconnected.promise};
  const session=new AdbSession({request:async()=>device,authenticate:async()=>adb,onChange:s=>events.push(s),...overrides});
  return {session,events,device,adb,disconnected,get closed(){return closed;}};
}
test('chooser cancellation is idle and recoverable',async()=>{
  const r=rig({request:async()=>undefined}); await r.session.connect();
  assert.equal(r.session.state,'idle'); assert.match(r.events.at(-1).message,/取消/);
});
test('connection authenticates and USB disconnect clears session',async()=>{
  const r=rig(); await r.session.connect(); assert.equal(r.session.adb,r.adb);
  r.disconnected.resolve(); await new Promise(r=>setTimeout(r,0));
  assert.equal(r.session.state,'idle'); assert.equal(r.session.adb,undefined);
});
test('cancel while authentication is pending cannot resurrect a session',async()=>{
  const pending=deferred(); const r=rig({authenticate:()=>pending.promise});
  const work=r.session.connect(); await new Promise(r=>setTimeout(r,0));
  await r.session.disconnect(); pending.resolve(r.adb); await work;
  assert.equal(r.session.state,'idle'); assert.equal(r.session.adb,undefined); assert.ok(r.closed>=2);
});
test('late chooser selection is ignored and does not claim USB',async()=>{
  const pending=deferred(); let claimed=0; const r=rig({request:()=>pending.promise});
  const work=r.session.connect(); await r.session.disconnect();
  pending.resolve({connect:async()=>{claimed++;}}); await work; assert.equal(claimed,0);
});
test('busy error gives a short recovery instruction',async()=>{
  const r=rig({request:async()=>{throw new Error('Unable to claim interface');}});
  await r.session.connect(); assert.equal(r.session.state,'idle'); assert.match(r.events.at(-1).message,/桌面 adb/);
  assert.match(deviceError({name:'NotFoundError'}),/取消/);
});
test('path handling preserves Unicode and never crosses root',()=>{
  assert.equal(normalizePath('/sdcard/下载/../a'),'/sdcard/a');
  assert.equal(normalizePath('/../../'),'/'); assert.equal(joinPath('/sdcard','x y.apk'),'/sdcard/x y.apk');
  assert.throws(()=>joinPath('/sdcard','../x')); assert.throws(()=>normalizePath('relative'));
  assert.equal(shellQuote("a'b"),"'a'\\''b'");
});
test('byte collection preserves binary and rejects oversized files',async()=>{
  const stream=()=>new ReadableStream({start(c){c.enqueue(new Uint8Array([0,255,13,10]));c.close();}});
  assert.deepEqual(await collectBytes(stream(),10),new Uint8Array([0,255,13,10]));
  await assert.rejects(()=>collectBytes(stream(),3),/过大/);
});
test('device actions use sync for Unicode paths and dispose after failure',async()=>{
  let disposed=0,path; const sync={readdir:async p=>{path=p;return [{name:'a',type:8,size:2n}];},dispose:async()=>disposed++};
  const actions=new DeviceActions({sync:async()=>sync});
  assert.equal((await actions.list('/sdcard/中文'))[0].name,'a'); assert.equal(path,'/sdcard/中文'); assert.equal(disposed,1);
  sync.readdir=async()=>{throw Error('denied');}; await assert.rejects(()=>actions.list('/'),/denied/); assert.equal(disposed,2);
});
test('screenshot uses raw exec service and closes the socket',async()=>{
  let service,closed=0; const png=new Uint8Array([137,80,78,71,13,10,26,10]);
  const actions=new DeviceActions({createSocket:async s=>{service=s;return {readable:new ReadableStream({start(c){c.enqueue(png);c.close();}}),close:async()=>closed++};}});
  assert.deepEqual(await actions.screenshot(),png); assert.equal(service,'exec:screencap -p'); assert.equal(closed,1);
});
test('APK installation uses random own temp path, checks success and cleans up',async()=>{
  const commands=[];let uploaded;
  const actions=new DeviceActions({subprocess:{shellProtocol:{spawnWaitText:async c=>{commands.push(c);return {exitCode:0,stdout:'Success\n',stderr:''};}}},sync:async()=>({write:async o=>{uploaded=o;assert.deepEqual(await collectBytes(o.file),new Uint8Array([1,2,3]));},dispose:async()=>{}})});
  assert.equal(await actions.install(new Blob([new Uint8Array([1,2,3])])),'Success');
  assert.match(uploaded.filename,/^\/data\/local\/tmp\/pocket-toolbox-[a-f0-9-]+\.apk$/);
  assert.equal(commands[0],`pm install -r '${uploaded.filename}'`);assert.equal(commands[1],`rm -f '${uploaded.filename}'`);
});
test('APK failure is reported even with zero process exit and temp file is cleaned',async()=>{
  const commands=[];
  const actions=new DeviceActions({subprocess:{shellProtocol:{spawnWaitText:async c=>{commands.push(c);return {exitCode:0,stdout:'Failure [INSTALL_FAILED_TEST]',stderr:''};}}},sync:async()=>({write:async()=>{},dispose:async()=>{}})});
  await assert.rejects(()=>actions.install(new Blob(['apk'])),/INSTALL_FAILED_TEST/);assert.equal(commands.length,2);assert.match(commands[1],/^rm -f /);
});
