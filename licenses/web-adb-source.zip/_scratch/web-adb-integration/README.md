# 口袋工具箱 Web ADB

纯静态、自托管 Android USB 调试工具。生产运行时无需 Node、后端、登录或第三方服务。使用官方 MIT `@yume-chan/adb`、`adb-daemon-webusb`、`adb-credential-web` 与 xterm.js；锁定版本见 package-lock.json。原创集成代码 MIT。

## 构建

需要 Node.js 22+ 与 npm。此目录应位于仓库 `_scratch/web-adb-integration`。

```sh
npm ci --ignore-scripts
npm test
npm audit --omit=dev
npm run build
```

build.mjs 将运行文件写入 `../../toolbox-site/tools/web-adb/`，许可与依赖清单写入 `../../toolbox-site/licenses/web-adb*`。在任意 HTTPS 静态服务器部署 toolbox-site 即可；所有资源采用相对路径，兼容 GitHub Pages 子路径。开发可在 toolbox-site 目录用 `python -m http.server 8765`，然后打开 localhost:8765/tools/web-adb/。完整源码 ZIP 同时包含依赖发布源码和所有许可；可通过 `npm ci` 按锁文件重新获取依赖。归档不含平台 esbuild 可执行文件。

## 功能与协议

- 用户点击后调用原生 WebUSB 设备选择器，ADB RSA 授权密钥仅保存在此浏览器 IndexedDB。不会自动连接、切换 USB 模式或启动桌面 adb。
- WebUSB transport 直连 Android ADB daemon，连接、取消、断开由独立 generation 状态机管理。认证取消会关闭原始 USB，迟到的选择/认证不能重新激活会话。
- 设备信息通过 getprop / dumpsys battery 只读获取。
- xterm.js 连接真实 ADB PTY，支持输入、ANSI、方向键、Tab、Ctrl+C；shell v2 支持动态窗口尺寸，旧设备回退传统 PTY。
- 文件浏览/上传/下载使用 ADB sync 协议；安全使用 DOM textContent 渲染设备文件名。目录和文件限于设备 shell 权限，不能绕过 Android 存储权限。上传覆盖会确认；下载暂存浏览器内存，上限 256 MiB。
- 单 APK 先 sync 到随机 `/data/local/tmp/pocket-toolbox-UUID.apk`，再 `pm install -r` 并检查退出码与 Success，结束后仅清理自己的临时 APK。不支持 split APK / APKs / XAPK。断开操作无法撤销已写入文件或已完成安装；USB 中断时可能留下本次临时 APK。
- 截图使用 `exec:screencap -p` 原始二进制流并验证 PNG 标识，避免 PTY 换行损坏。无法截取受保护画面。
- 不提供重启、刷机、root、解锁、卸载应用等快捷操作。终端由用户自行输入命令。
- CSP 禁止远程脚本/连接；没有遥测、广告、外部字体、CDN 或运行时第三方请求。

## 兼容与连接问题

需要桌面 Chrome / Edge 等 WebUSB 浏览器及 HTTPS / localhost。Firefox / Safari 不支持。Windows 需要兼容 USB 驱动；同一 ADB 接口不可同时由桌面 adb 与网页占用。工具只显示简短退出其他调试工具的提示，不会自动停止 adb、改驱动或干扰现有连接。手机需启用 USB 调试、解锁并接受授权。

## 验证

`../ops-tests/web-adb-core.test.mjs` 验证取消/迟到认证/拔线、路径、二进制、sync释放、APK/截图逻辑。`../ops-tests/web-adb-browser.py` 用真实 Chromium 验证 UI、unsupported、取消、忙碌提示、响应式、离线自托管与零外部请求。浏览器中测试 WebUSB API 时只模拟硬件 transport，产品无测试入口；此测试不等于真实手机端到端连接验证。

本机只读 `adb devices -l` 检查发现 OnePlus 6T 在线。桌面 adb 正在持有 USB；未停止它、未修改驱动、未通过 CLI 运行安装或写入来替代网页实机验证。实机 WebUSB 连接/文件/终端/安装/截图仍需用户在兼容浏览器中手工确认。
