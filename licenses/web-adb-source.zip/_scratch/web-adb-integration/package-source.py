"""Package the reproducible integration tree and published dependency sources."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[2]
INTEGRATION=ROOT/'_scratch/web-adb-integration'
LICENSES=ROOT/'toolbox-site/licenses'
OUTPUT=LICENSES/'web-adb-source.zip'
files=[]
for p in INTEGRATION.rglob('*'):
 if not p.is_file():continue
 if any(part in {'@esbuild','.bin','.git','__pycache__'} for part in p.relative_to(INTEGRATION).parts):continue
 if p.suffix in {'.tsbuildinfo','.pyc'}:continue
 files.append(p)
for pattern in ['web-adb-core.test.mjs','web-adb-browser.py','web-adb-usb-fixture.js']:
 files.append(ROOT/'_scratch/ops-tests'/pattern)
files.extend((ROOT/'toolbox-site/tools/web-adb').glob('*'))
files.extend((LICENSES/'web-adb').glob('*'))
files.extend([LICENSES/'web-adb-dependencies.json',LICENSES/'web-adb.html'])
with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(files):
  name=p.relative_to(ROOT).as_posix()
  if 'node_modules' in p.parts:
   dependency_path=p.relative_to(INTEGRATION/'node_modules').as_posix()
   name='upstream/'+dependency_path.replace('/node_modules/','/dependencies/')
  archive.write(p,name)
data=OUTPUT.read_bytes()
report={'file':'web-adb-source.zip','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'entries':len(files),'layout':'Repository-relative integration, tests and runtime; published dependency sources in upstream/. Excludes platform binaries; npm ci restores dependencies.'}
(LICENSES/'web-adb-source-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
