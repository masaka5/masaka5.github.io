export function deviceError(error) {
  if (error?.name === 'NotFoundError' || error?.name === 'AbortError') return '已取消选择设备。';
  const text = String(error?.message || error || '未知错误');
  if (/busy|claim|in use|in used|access denied|protected interface/i.test(text)) return 'USB 接口正被占用。请先退出桌面 adb 或其他调试工具，再连接。';
  if (/closed|disconnected|device unavailable|transfer.*failed|networkerror/i.test(text)) return 'USB 连接已中断，请检查数据线、解锁手机并重新连接。';
  if (/security|permission|denied/i.test(text)) return '无法访问设备，请检查浏览器 USB 权限、USB 调试授权和系统驱动。';
  return text.slice(0, 320);
}

// A generation invalidates asynchronous work, including an uncancellable native chooser.
export class AdbSession {
  constructor({request, authenticate, onChange}) { Object.assign(this,{request,authenticate,onChange}); this.state='idle'; this.generation=0; }
  emit(state,message) { this.state=state; this.onChange?.({state,message}); }
  async connect() {
    if (this.state!=='idle') return;
    const id=++this.generation;
    this.emit('choosing','请选择已启用 USB 调试的 Android 设备。');
    let device, client;
    try {
      device=await this.request();
      if(id!==this.generation) return;
      if(!device) {this.emit('idle','已取消选择设备。');return;}
      this.device=device;
      this.emit('authenticating','正在连接，请解锁手机并允许 USB 调试。');
      const connection=await device.connect();
      if(id!==this.generation) {await device.raw?.close().catch(()=>{});return;}
      client=await this.authenticate(device,connection);
      if(id!==this.generation) {await client.close().catch(()=>{});return;}
      this.adb=client;
      this.emit('connected','设备已连接。');
      client.disconnected.then(()=>this.lost(id),()=>this.lost(id));
    } catch(error) {
      if(id!==this.generation) return;
      this.device=undefined; this.adb=undefined;
      await device?.raw?.close().catch(()=>{});
      this.emit('idle',deviceError(error));
    }
  }
  lost(id) {if(id!==this.generation)return; this.generation++;this.adb=undefined;this.device=undefined;this.emit('idle','设备连接已断开。');}
  async disconnect() {
    ++this.generation;
    const adb=this.adb,device=this.device;
    this.adb=undefined;this.device=undefined;
    this.emit('idle','已断开连接。');
    // Close raw USB too: authentication may still hold the stream locks.
    await Promise.allSettled([adb?.close(),device?.raw?.close()]);
  }
}

export function normalizePath(value) {
  if(!value.startsWith('/') || value.includes('\0'))throw Error('请输入以 / 开头的有效设备路径。');
  const parts=[];
  for(const p of value.split('/')) {if(!p||p==='.')continue;if(p==='..')parts.pop();else parts.push(p);}
  return '/'+parts.join('/');
}
export function joinPath(base,name) {if(!name||name==='.'||name==='..'||/[\/\0]/.test(name))throw Error('文件名无效。');return normalizePath(base+'/'+name);}
export function shellQuote(value) {return "'"+value.replaceAll("'","'\\''")+"'";}
export async function collectBytes(stream,limit=256*1024*1024,onProgress=()=>{}) {
  const reader=stream.getReader();const chunks=[];let length=0;
  try {while(true){const {value,done}=await reader.read();if(done)break;length+=value.byteLength;if(length>limit)throw Error('文件过大，请使用桌面 adb 传输（浏览器下载上限 256 MB）。');chunks.push(value);onProgress(length);}}
  catch(e){await reader.cancel(e).catch(()=>{});throw e;}
  finally{reader.releaseLock();}
  const out=new Uint8Array(length);let offset=0;for(const chunk of chunks){out.set(chunk,offset);offset+=chunk.length;}return out;
}
export class DeviceActions {
  constructor(adb) {this.adb=adb;}
  async usingSync(work) {const sync=await this.adb.sync();try{return await work(sync);}finally{await sync.dispose();}}
  list(path) {return this.usingSync(s=>s.readdir(normalizePath(path)));}
  download(path,progress) {return this.usingSync(s=>collectBytes(s.read(normalizePath(path)),undefined,progress));}
  upload(path,stream) {return this.usingSync(s=>s.write({filename:normalizePath(path),file:stream,permission:0o644}));}
  async command(command) {
    const shell=this.adb.subprocess.shellProtocol;
    if(!shell)throw Error('此操作需要支持 shell v2 的 Android 设备。');
    const result=await shell.spawnWaitText(command);
    if(result.exitCode!==0)throw Error(result.stderr||result.stdout||`命令失败 (${result.exitCode})`);
    return result.stdout;
  }
  async screenshot() {
    const socket=await this.adb.createSocket('exec:screencap -p');
    try {const bytes=await collectBytes(socket.readable,32*1024*1024);if(bytes[0]!==137||bytes[1]!==80||bytes[2]!==78||bytes[3]!==71)throw Error('设备未返回 PNG 截图，当前画面可能受系统保护。');return bytes;}
    finally {await socket.close();}
  }
  async install(file,progress=()=>{}) {
    if(!this.adb.subprocess.shellProtocol)throw Error('APK 安装需要支持 shell v2 的 Android 设备。');
    const target=`/data/local/tmp/pocket-toolbox-${crypto.randomUUID()}.apk`;
    try {
      progress('正在传输 APK…');await this.upload(target,file.stream());
      progress('正在安装，请留意手机确认提示…');
      const output=await this.command(`pm install -r ${shellQuote(target)}`);
      if(!/^Success\s*$/m.test(output))throw Error(output||'安装未返回成功状态。');
      return output.trim();
    } finally {await this.command(`rm -f ${shellQuote(target)}`).catch(()=>{});}
  }
}
