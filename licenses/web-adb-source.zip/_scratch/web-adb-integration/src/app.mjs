import { Adb, AdbDaemonTransport } from '@yume-chan/adb';
import { AdbDaemonWebUsbDeviceManager } from '@yume-chan/adb-daemon-webusb';
import AdbWebCredentialStore from '@yume-chan/adb-credential-web';
import { Terminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { AdbSession, DeviceActions, deviceError, normalizePath, joinPath } from './core.mjs';
import './app.css';

const $=id=>document.getElementById(id);
const manager=AdbDaemonWebUsbDeviceManager.BROWSER;
let actions,busy=false,operationId=0,entries=[],currentPath='/sdcard',apk,terminalProcess,terminalWriter,terminalOpening=false,screenshotBlob,screenshotUrl;
const terminal=new Terminal({fontFamily:'Consolas, "Cascadia Mono", monospace',fontSize:13,cursorBlink:true,scrollback:3000,theme:{background:'#192333',foreground:'#e6edf6',cursor:'#82a8ff',selectionBackground:'#416196'}});
const fit=new FitAddon();terminal.loadAddon(fit);terminal.open($('terminal-host'));
terminal.write('连接 Android 设备后，点击「打开终端」。\r\n');
terminal.onData(data=>writeTerminal(data));
terminal.onResize(({rows,cols})=>{terminalProcess?.resize?.(rows,cols).catch(()=>{});});
new ResizeObserver(()=>{if(!$('terminal').hidden)try{fit.fit();}catch{}}).observe($('terminal-host'));

const session=new AdbSession({
  request:()=>manager.requestDevice(),
  authenticate:async(device,connection)=>new Adb(await AdbDaemonTransport.authenticate({serial:device.serial,connection,credentialStore:new AdbWebCredentialStore('口袋工具箱 Web ADB')})),
  onChange:({state,message})=>{
    const connected=state==='connected',pending=state==='choosing'||state==='authenticating';
    $('connection-message').textContent=message;
    $('connection-state').textContent=connected?'已连接':pending?'连接中':'未连接';
    $('status-dot').className='dot '+(connected?'connected':pending?'pending':'');
    $('connect').hidden=state!=='idle';$('disconnect').hidden=state==='idle';
    $('disconnect').textContent=connected?'断开连接':'取消连接';
    if(connected){actions=new DeviceActions(session.adb);$('device-name').textContent=session.device?.name||session.adb.serial;void refreshInfo();}
    else if(state==='idle'){
      operationId++;busy=false;actions=undefined;entries=[];
      $('device-name').textContent='尚未连接设备';
      $('device-info').replaceChildren(empty('连接设备后显示型号、系统和电池信息。'));
      $('file-list').replaceChildren(empty('连接设备后浏览文件。'));
      closeTerminal();operation('数据仅在浏览器与 USB 设备之间传输。');
    }
    controls();
  }
});
function controls(){
  const connected=!!session.adb;
  document.querySelectorAll('[data-device]').forEach(el=>el.disabled=!connected||busy);
  $('install-apk').disabled=!connected||busy||!apk;
  $('apk-input').disabled=!connected||busy;
  $('start-terminal').disabled=!connected||busy||terminalOpening||!!terminalProcess;
  $('cancel-operation').hidden=!busy;
}
function empty(text){const el=document.createElement('div');el.className='empty';el.textContent=text;return el;}
function operation(message){$('operation-message').textContent=message;}
async function run(label,work){
  if(!session.adb||busy)return;
  const id=++operationId,generation=session.generation,device=actions;
  busy=true;controls();operation(label);
  try{const message=await work(device,()=>id===operationId&&generation===session.generation);if(id===operationId&&generation===session.generation)operation(message||'操作完成。');}
  catch(e){if(id===operationId&&generation===session.generation)operation('操作失败：'+deviceError(e));}
  finally{if(id===operationId){busy=false;controls();}}
}
$('connect').onclick=()=>session.connect();
$('disconnect').onclick=()=>session.disconnect();
$('cancel-operation').onclick=()=>session.disconnect();
$('help-button').onclick=()=>$('help-dialog').showModal();
window.addEventListener('pagehide',()=>{void session.disconnect();if(screenshotUrl)URL.revokeObjectURL(screenshotUrl);});
if(!manager||!window.isSecureContext){
  $('connect').disabled=true;
  $('connection-message').textContent=!window.isSecureContext?'请通过 HTTPS 或 localhost 打开此页面，才能访问 USB。':'当前浏览器不支持 WebUSB。请使用桌面 Chrome 或 Edge 打开此工具。';
}
controls();
document.querySelectorAll('.tab').forEach(tab=>tab.onclick=()=>{
  document.querySelectorAll('.tab').forEach(t=>{t.classList.toggle('active',t===tab);if(t===tab)t.setAttribute('aria-current','page');else t.removeAttribute('aria-current');});
  document.querySelectorAll('.panel').forEach(p=>{const active=p.id===tab.dataset.tab;p.hidden=!active;p.classList.toggle('active',active);});
  if(tab.dataset.tab==='terminal'){requestAnimationFrame(()=>{fit.fit();terminal.focus();});}
  if(tab.dataset.tab==='files'&&session.adb&&!entries.length)void refreshFiles();
});

function infoCell(label,value){const el=document.createElement('div');el.className='info-cell';const title=document.createElement('span');title.textContent=label;const content=document.createElement('strong');content.textContent=value||'未知';el.append(title,content);return el;}
async function refreshInfo(){return run('正在读取设备信息…',async(device,active)=>{
  const adb=device.adb;
  const props=await Promise.all(['ro.product.model','ro.product.manufacturer','ro.build.version.release','ro.build.version.sdk','ro.product.cpu.abi'].map(key=>adb.getProp(key)));
  let battery='不可用';
  try{const output=await device.command('dumpsys battery');const level=output.match(/level:\s*(\d+)/)?.[1];const status=output.match(/status:\s*(\d+)/)?.[1];if(level)battery=level+'%'+(status==='2'?' · 充电中':'');}catch{}
  if(!active())return;
  $('device-info').replaceChildren(...[['型号',props[0]],['制造商',props[1]],['Android 版本',props[2]],['API 级别',props[3]],['CPU 架构',props[4]],['电池',battery],['序列号',adb.serial]].map(([k,v])=>infoCell(k,v)));
  return '设备信息已更新。';
});}
$('refresh-info').onclick=refreshInfo;

async function openTerminal(){
  if(!session.adb||terminalProcess||terminalOpening)return;
  terminalOpening=true;controls();const id=session.generation,adb=session.adb;
  try{
    const process=adb.subprocess.shellProtocol?await adb.subprocess.shellProtocol.pty({terminalType:'xterm-256color'}):await adb.subprocess.noneProtocol.pty();
    if(id!==session.generation){await process.kill();return;}
    terminalProcess=process;terminalWriter=process.input.getWriter();terminal.clear();fit.fit();await process.resize?.(terminal.rows,terminal.cols);terminal.focus();
    process.exited.then(code=>{if(terminalProcess===process){terminalProcess=undefined;releaseTerminalWriter();terminal.write(`\r\n[终端已退出${code===undefined?'':'：'+code}]\r\n`);controls();}},()=>{if(terminalProcess===process){terminalProcess=undefined;releaseTerminalWriter();controls();}});
    const reader=process.output.getReader();
    try{while(true){const {done,value}=await reader.read();if(done)break;if(id!==session.generation)break;await new Promise(resolve=>terminal.write(value,resolve));}}
    finally{reader.releaseLock();}
  }catch(e){if(id===session.generation)operation('终端错误：'+deviceError(e));}
  finally{terminalOpening=false;controls();}
}
function releaseTerminalWriter(){const writer=terminalWriter;terminalWriter=undefined;try{writer?.releaseLock();}catch{}}
function closeTerminal(){const process=terminalProcess;terminalProcess=undefined;releaseTerminalWriter();if(process)Promise.resolve(process.kill()).catch(()=>{});terminal.write('\r\n[设备已断开]\r\n');}
async function writeTerminal(data){if(!terminalWriter)return;const writer=terminalWriter;try{await writer.write(new TextEncoder().encode(data));}catch(e){if(writer===terminalWriter)operation('终端输入失败：'+deviceError(e));}}
$('start-terminal').onclick=openTerminal;$('clear-terminal').onclick=()=>terminal.clear();
document.querySelectorAll('[data-key]').forEach(button=>button.onclick=()=>{writeTerminal(JSON.parse('"'+button.dataset.key+'"'));terminal.focus();});

const bytes=n=>{n=Number(n);return n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB';};
async function refreshFiles(path=$('path').value){
  return run('正在读取目录…',async(device,active)=>{
    path=normalizePath(path);const result=await device.list(path);if(!active())return;
    currentPath=path;$('path').value=path;
    entries=result.filter(e=>e.name!=='.'&&e.name!=='..').sort((a,b)=>(b.type===4)-(a.type===4)||a.name.localeCompare(b.name,'zh'));
    renderFiles();return `已读取 ${entries.length} 个项目。`;
  });
}
function renderFiles(){
  const rows=entries.map(entry=>{
    const button=document.createElement('button');button.className='file-row';button.dataset.device='';button.disabled=busy;
    const type=document.createElement('span');type.className='file-type';type.textContent=entry.type===4?'目录':entry.type===10?'链接':'文件';
    const name=document.createElement('span');name.className='file-name';name.textContent=entry.name;
    const size=document.createElement('span');size.className='file-size';size.textContent=entry.type===4?'进入 →':bytes(entry.size)+' ↓';
    button.append(type,name,size);
    button.onclick=()=>{const path=joinPath(currentPath,entry.name);if(entry.type===4)refreshFiles(path);else downloadFile(path,entry.name);};
    return button;
  });$('file-list').replaceChildren(...(rows.length?rows:[empty('此目录为空。')]));
}
$('path-form').onsubmit=e=>{e.preventDefault();refreshFiles();};$('refresh-files').onclick=()=>refreshFiles();
$('parent-folder').onclick=()=>refreshFiles(currentPath+'/..');
function save(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
function downloadFile(path,name){return run('正在下载文件…',async(device,active)=>{const data=await device.download(path,n=>{if(active())operation('已读取 '+bytes(n)+'…');});if(active())save(new Blob([data]),name);return '文件已交给浏览器保存。';});}
$('upload').onclick=()=>$('upload-input').click();
$('upload-input').onchange=async e=>{
  const file=e.target.files?.[0];e.target.value='';if(!file||!session.adb||busy)return;
  const path=joinPath(currentPath,file.name);
  if(entries.some(item=>item.name===file.name)&&!window.confirm(`“${file.name}” 已存在。覆盖设备上的同名文件？`))return;
  await run('正在上传文件…',async(device,active)=>{
    let sent=0;const stream=file.stream().pipeThrough(new TransformStream({transform(chunk,controller){sent+=chunk.length;if(active())operation(`正在上传 ${bytes(sent)} / ${bytes(file.size)}…`);controller.enqueue(chunk);}}));
    await device.upload(path,stream);return '上传完成。';
  });
  if(session.adb&&!busy)await refreshFiles(currentPath);
};
$('apk-input').onchange=e=>{apk=e.target.files?.[0];if(apk&&!apk.name.toLowerCase().endsWith('.apk')){apk=undefined;operation('请选择单个 .apk 文件。');e.target.value='';}$('apk-name').textContent=apk?apk.name+' · '+bytes(apk.size):'尚未选择文件';controls();};
$('install-apk').onclick=()=>{
  if(!apk||!window.confirm(`将“${apk.name}”安装到当前设备？同包名应用会被更新。`))return;
  const file=apk;return run('准备安装 APK…',async(device,active)=>{await device.install(file,message=>{if(active())operation(message);});return 'APK 安装成功。';});
};
$('take-screenshot').onclick=()=>run('正在获取设备截图…',async(device,active)=>{
  const data=await device.screenshot();if(!active())return;
  screenshotBlob=new Blob([data],{type:'image/png'});if(screenshotUrl)URL.revokeObjectURL(screenshotUrl);screenshotUrl=URL.createObjectURL(screenshotBlob);
  $('screenshot').src=screenshotUrl;$('screenshot').hidden=false;$('capture-preview').querySelector('.empty')?.remove();$('save-screenshot').disabled=false;return '截图已获取，可保存为 PNG。';
});
$('save-screenshot').onclick=()=>{if(screenshotBlob)save(screenshotBlob,`android-${new Date().toISOString().replace(/[:.]/g,'-')}.png`);};
