import {build} from 'esbuild';
import {readFile,writeFile,mkdir,copyFile,readdir,stat,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const site=path.resolve(root,'../../toolbox-site');
const out=path.join(site,'tools/web-adb');
const licenses=path.join(site,'licenses');
await mkdir(out,{recursive:true});await mkdir(path.join(licenses,'web-adb'),{recursive:true});
await build({entryPoints:[path.join(root,'src/app.mjs')],bundle:true,format:'esm',target:'es2022',outdir:out,entryNames:'app',minify:true,legalComments:'linked',metafile:true});
await copyFile(path.join(root,'index.html'),path.join(out,'index.html'));
await writeFile(path.join(out,'index.html'),(await readFile(path.join(out,'index.html'),'utf8')).replace('</head>','<link rel="stylesheet" href="../../assets/tool-shell.css"></head>'));
const lock=JSON.parse(await readFile(path.join(root,'package-lock.json'),'utf8'));
const dependencyEntries=Object.entries(lock.packages).filter(([key])=>key.startsWith('node_modules/')&&!key.startsWith('node_modules/@esbuild/'));
const manifest=[];const notices=[];
for(const [key,metadata] of dependencyEntries){
  const name=key.replace('node_modules/','');
  const packagePath=path.join(root,key);let license='';
  for(const candidate of ['LICENSE','LICENSE.txt','LICENSE.md'])try{license=await readFile(path.join(packagePath,candidate),'utf8');break;}catch{}
  if(!license)throw Error(`Missing license: ${name}`);
  const filename=name.replaceAll('/','-').replaceAll('@','')+'-LICENSE.txt';
  await writeFile(path.join(licenses,'web-adb',filename),license);
  manifest.push({name,version:metadata.version,license:metadata.license,integrity:metadata.integrity,source:metadata.resolved,notice:`web-adb/${filename}`,buildOnly:!!metadata.dev});
  notices.push(`<details><summary>${name} ${metadata.version} · ${metadata.license}</summary><pre>${escapeHtml(license)}</pre></details>`);
}
function escapeHtml(s){return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');}
await writeFile(path.join(licenses,'web-adb-dependencies.json'),JSON.stringify({project:'口袋工具箱 Web ADB',upstream:'https://github.com/yume-chan/ya-webadb',dependencies:manifest},null,2)+'\n');
await writeFile(path.join(licenses,'web-adb.html'),`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Web ADB · 开源许可</title><style>body{font:14px/1.8 system-ui,'Microsoft YaHei',sans-serif;max-width:900px;margin:30px auto;padding:0 22px;color:#26354c;background:#f5f7fa}a{color:#285de5}h1{font-size:24px}details{background:white;padding:14px 18px;margin:12px 0;border:1px solid #e1e7ef;border-radius:7px}summary{cursor:pointer;font-weight:600}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.8 monospace}</style></head><body><a href="../tools/web-adb/">← 返回 Web ADB</a><h1>Web ADB 开源许可与源码</h1><p>本工具基于 <a href="https://github.com/yume-chan/ya-webadb" rel="noreferrer">Yume-chan / ya-webadb</a> 官方开源包与 xterm.js 构建。依赖全部自托管，无广告、登录或遥测。</p><p><a href="./web-adb-source.zip">下载完整集成源码与依赖源码 ZIP</a> · <a href="./web-adb-dependencies.json">依赖版本与完整性清单</a></p><p>ZIP 包含界面源码、锁文件、构建脚本、测试和依赖发布源码。具体构建方法见 README.md。</p>${notices.join('')}<p>本工具的原创集成代码以 MIT 许可发布。</p></body></html>`);
// Stable production file hashes, separate from the dependency provenance.
const files=[];
for(const name of (await readdir(out)).sort()){const p=path.join(out,name);if((await stat(p)).isFile()&&name!=='manifest.json'){const bytes=await readFile(p);files.push({path:name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}}
await writeFile(path.join(out,'manifest.json'),JSON.stringify({name:'Web ADB',files},null,2)+'\n');
console.log(`Built ${files.length} runtime files and ${manifest.length} dependency notices.`);
