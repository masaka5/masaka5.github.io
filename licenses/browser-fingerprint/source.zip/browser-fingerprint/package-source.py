"""Package editable integration; update only catalog-related archive entries."""
from pathlib import Path
import zipfile,hashlib,json,os
ROOT=Path(__file__).resolve().parents[2];PROJECT=Path(__file__).resolve().parent;SITE=ROOT/'toolbox-site'
sha=lambda data:hashlib.sha256(data).hexdigest()
license_dir=SITE/'licenses/browser-fingerprint';license_dir.mkdir(exist_ok=True)
archive=license_dir/'source.zip';rows=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for path in sorted(PROJECT.rglob('*')):
  rel=path.relative_to(PROJECT)
  if not path.is_file()or any(part in {'dist','node_modules','__pycache__','.local'}for part in rel.parts):continue
  name='browser-fingerprint/'+rel.as_posix();data=path.read_bytes();z.writestr(name,data);rows.append({'path':name,'bytes':len(data),'sha256':sha(data)})
 for name in ['THIRD-PARTY-NOTICES.txt','dependencies.json']:
  data=(license_dir/name).read_bytes();rel='browser-fingerprint/notices/'+name;z.writestr(rel,data);rows.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
(license_dir/'source-manifest.json').write_text(json.dumps({'sourceArchive':'source.zip','upstream':'https://github.com/neoprintjs/neoprint','commit':'36c84b2aa377961f5eb28c5749f79df49c5fa824','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'files':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
changed=['_scratch/build-toolbox-icons.cjs','_scratch/toolbox-taxonomy.cjs','_scratch/build-toolbox-seo.cjs','toolbox-site/assets/catalog.js','toolbox-site/assets/catalog-base.js','toolbox-site/assets/tool-icon-paths.js','toolbox-site/index.html','toolbox-site/sitemap.xml','toolbox-cloud/src/tool-ids.json']
target=SITE/'licenses/integration-source.zip';temp=target.with_suffix('.fingerprint.zip')
with zipfile.ZipFile(target)as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for info in old.infolist():
  if info.filename not in changed:z.writestr(info,old.read(info.filename))
 for name in changed:z.write(ROOT/name,name)
os.replace(temp,target)
print(json.dumps({'fingerprintSourceFiles':len(rows),'fingerprintSourceBytes':archive.stat().st_size,'catalogSourceUpdated':len(changed)}))
