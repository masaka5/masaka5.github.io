"""Real-browser checks; reports remain local and are never published."""
from pathlib import Path
import json,os
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3]
OUTPUT=ROOT/'_scratch/fingerprint-tests';OUTPUT.mkdir(exist_ok=True)
BASE=os.environ.get('FINGERPRINT_TEST_ORIGIN','http://127.0.0.1:8765').rstrip('/')
URL=BASE+'/tools/browser-fingerprint/'
results=[]
with sync_playwright()as p:
 for name,browser_type,options in [('chromium',p.chromium,{}),('edge',p.chromium,{'channel':'msedge'}),('firefox',p.firefox,{})]:
  browser=browser_type.launch(**options,args=['--enable-gpu','--use-angle=d3d11'] if name!='firefox'else [])
  print('Testing '+name,flush=True)
  context=browser.new_context(viewport={'width':1440,'height':900},locale='zh-CN',timezone_id='Asia/Shanghai',accept_downloads=True)
  page=context.new_page();errors=[];external=[]
  page.on('pageerror',lambda error:errors.append(str(error)))
  page.on('request',lambda request:external.append(request.url)if not request.url.startswith(BASE)else None)
  page.goto(URL,wait_until='networkidle')
  expect(page.get_by_role('heading',name='浏览器指纹',exact=True)).to_be_visible()
  export=page.get_by_role('button',name='导出指纹',exact=True)
  expect(export).to_be_enabled(timeout=15000)
  def report():
   with page.expect_download()as event:export.click()
   path=OUTPUT/(name+'.json');event.value.save_as(path)
   return json.loads(path.read_text(encoding='utf8'))
  first=report()
  (OUTPUT/(name+'-first.json')).write_text(json.dumps(first),encoding='utf8')
  assert len(first['fingerprint']['components'])==18
  assert first['fingerprint']['id'] and first['fingerprint']['stableId']
  page.get_by_role('button',name='重新检测',exact=True).click()
  expect(export).to_be_enabled(timeout=15000)
  second=report()
  if first['fingerprint']['stableId']!=second['fingerprint']['stableId']:
   print('Stable changed: '+str([key for key in first['fingerprint']['components']if first['fingerprint']['components'][key]['value']!=second['fingerprint']['components'][key]['value']]),flush=True)
  assert first['fingerprint']['stableId']==second['fingerprint']['stableId'],(name,'unstable stableID')
  assert first['device']['id']==second['device']['id'],(name,'unstable device ID')
  page.reload(wait_until='networkidle');expect(export).to_be_enabled(timeout=15000)
  third=report()
  assert second['device']['id']==third['device']['id']
  if second['fingerprint']['stableId']!=third['fingerprint']['stableId']:
   print('Reload stable changed: '+str([key for key in second['fingerprint']['components']if second['fingerprint']['components'][key]['value']!=third['fingerprint']['components'][key]['value']]),flush=True)
  assert second['fingerprint']['stableId']==third['fingerprint']['stableId']
  # Export/import round trip and same-feature result.
  page.locator('input[type=file]').set_input_files(OUTPUT/(name+'.json'))
  expect(page.get_by_role('tab',name='指纹对比',exact=True)).to_have_attribute('aria-selected','true')
  expect(page.locator('.comparison-info')).to_contain_text('18 相同 / 0 不同')
  page.get_by_role('button',name='清除对比').click()
  expect(page.get_by_text('导入另一浏览器导出的指纹',exact=True)).to_be_visible()
  page.get_by_role('tab',name='特征明细',exact=True).click()
  page.get_by_label('筛选特征',exact=True).fill('图形设备')
  expect(page.locator('.ant-table-tbody tr')).to_have_count(1)
  page.get_by_role('button',name='查看图形设备',exact=True).click()
  expect(page.get_by_role('dialog')).to_be_visible()
  expect(page.get_by_role('button',name='原始数据',exact=True)).to_be_visible()
  page.get_by_role('button',name='原始数据',exact=True).click()
  expect(page.locator('.raw-data')).to_contain_text('renderer')
  page.get_by_role('dialog').get_by_role('button',name='关闭').click()
  expect(page.get_by_role('dialog')).not_to_be_visible()
  page.get_by_label('筛选特征',exact=True).fill('')
  for width,height in [(1440,900),(1920,1080),(1280,720),(390,844),(375,667),(320,568),(844,390)]:
   page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(200)
   metrics=page.evaluate('''()=>({w:innerWidth,h:innerHeight,sw:document.documentElement.scrollWidth,sh:document.documentElement.scrollHeight,table:document.querySelector('.feature-table').getBoundingClientRect().toJSON(),pagination:document.querySelector('.table-pagination').getBoundingClientRect().toJSON(),rows:[...document.querySelectorAll('.ant-table-tbody tr')].map(e=>e.getBoundingClientRect().toJSON())})''')
   assert metrics['sw']<=width and metrics['sh']<=height,(name,width,height,metrics)
   assert all(row['bottom']<=metrics['table']['bottom']+1 for row in metrics['rows']),(name,width,height,'clipped rows',metrics)
   assert metrics['pagination']['bottom']<=height,(name,width,height,'pagination clipped')
   if name=='chromium'and width in [1440,390,320]:page.screenshot(path=str(OUTPUT/f'{name}-{width}.png'))
  page.set_viewport_size({'width':1440,'height':900})
  page.get_by_role('tab',name='浏览器信息',exact=True).click()
  expect(page.get_by_text('查看计算依据',exact=True)).to_be_visible()
  page.get_by_text('查看计算依据',exact=True).click();expect(page.get_by_role('dialog')).to_be_visible()
  assert not errors,errors
  assert not external,external
  results.append({'browser':name,'groups':18,'layouts':7,'stableOnReload':True,'localOnly':True,'deviceAvailable':bool(third['device']['id']),'deviceID':third['device']['id'],'originalCrossBrowserID':third['fingerprint']['crossBrowserId'],'errors':errors})
  browser.close()
 # Compare actual exported reports from independently executed engines.
 chromium=json.loads((OUTPUT/'chromium.json').read_text())
 for name in ['edge','firefox']:
  other=json.loads((OUTPUT/(name+'.json')).read_text())
  print(json.dumps({'compare':name,'deviceEqual':chromium['device']['id'] is not None and chromium['device']['id']==other['device']['id'],'rawCrossBrowserEqual':chromium['fingerprint']['crossBrowserId']==other['fingerprint']['crossBrowserId'],'graphics':other['device']['signals']['graphics']},ensure_ascii=False),flush=True)
 (OUTPUT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(results,ensure_ascii=False),flush=True)
