import test from 'node:test';
import assert from 'node:assert/strict';
let model;try{model=await import('../src/model.mjs');}catch{}
test('manual pairing only uses explicitly imported, validated device codes',()=>{
 assert.equal(typeof model?.pairingCode,'function','manual pairing is not implemented');
 const report={schema:'pocket-fingerprint/v1',fingerprint:{timestamp:1,components:{canvas:{value:'png'}}},pairing:{version:1,id:'123e4567-e89b-42d3-a456-426614174000'}};
 const parsed=model.parseReport(JSON.stringify(report));
 assert.equal(model.pairingCode(parsed),'123e4567-e89b-42d3-a456-426614174000');
 report.pairing.id='<script>';
 assert.throws(()=>model.parseReport(JSON.stringify(report)));
 assert.equal(model.pairingCode({schema:report.schema,fingerprint:report.fingerprint}),null);
});
