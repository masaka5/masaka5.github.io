import test from 'node:test';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const {build}=await import('esbuild').catch(()=>import('../../home-react-integration/node_modules/esbuild/lib/main.js'));
const result=await build({entryPoints:[fileURLToPath(new URL('../vendor/neoprint/src/core/hash.ts',import.meta.url))],bundle:true,write:false,format:'esm',platform:'node'});
const {hashComponents}=await import('data:text/javascript;base64,'+Buffer.from(result.outputFiles[0].text).toString('base64'));
test('nested GPU and browser values must influence a fingerprint',()=>{
 assert.notEqual(hashComponents({webgl:{renderer:'Intel'}}),hashComponents({webgl:{renderer:'NVIDIA'}}));
});
test('key ordering must not change a fingerprint',()=>{
 assert.equal(hashComponents({navigator:{platform:'Win32',languages:['zh','en']},webgl:{vendor:'Intel'}}),hashComponents({webgl:{vendor:'Intel'},navigator:{languages:['zh','en'],platform:'Win32'}}));
});
test('array order must remain significant',()=>{
 assert.notEqual(hashComponents({fonts:['Arial','Calibri']}),hashComponents({fonts:['Calibri','Arial']}));
});
