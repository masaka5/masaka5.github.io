import test from 'node:test';
import assert from 'node:assert/strict';
// Import after the feature exists; missing implementation is an explicit failure.
let model;
try { model=await import('../src/model.mjs'); } catch {}
test('cross-browser normalization removes ANGLE wrappers, API suffixes and UA brand',()=>{
 assert.ok(model,'fingerprint model is not implemented');
 const base={navigator:{value:{userAgent:'Windows NT 10.0 Chrome/140',platform:'Win32',maxTouchPoints:0}},timing:{value:{timezone:'Asia/Shanghai'}},webgl:{value:{vendor:'Google Inc. (NVIDIA)',renderer:'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002504) Direct3D11 vs_5_0 ps_5_0, D3D11)'}}};
 const firefox=structuredClone(base);firefox.navigator.value.userAgent='Windows NT 10.0 Firefox/140';firefox.webgl.value={vendor:'NVIDIA Corporation',renderer:'NVIDIA GeForce RTX 3060/PCIe/SSE2'};
 assert.equal(model.deviceIdentity(base).id,model.deviceIdentity(firefox).id);
 const other=structuredClone(base);other.webgl.value.renderer='NVIDIA GeForce RTX 4090';
 assert.notEqual(model.deviceIdentity(base).id,model.deviceIdentity(other).id);
});
test('missing graphics must not invent a supposedly unique device identifier',()=>{
 assert.ok(model,'fingerprint model is not implemented');
 assert.equal(model.deviceIdentity({}).id,null);
});
test('imports require a bounded, valid local report; missing features are not a match',()=>{
 assert.ok(model,'fingerprint model is not implemented');
 for(const input of ['{}','[]','null','{"components":{"x":{"value":{"__proto__":1}}}}','x'.repeat(1048577)])assert.throws(()=>model.parseReport(input));
 const report={schema:'pocket-fingerprint/v1',fingerprint:{components:{canvas:{value:{hash:'abc'}}},timestamp:1}};
 assert.equal(model.parseReport(JSON.stringify(report)).fingerprint.components.canvas.value.hash,'abc');
 assert.deepEqual(model.compareComponents({a:{value:null},b:{value:1}},{a:{value:null},b:{value:1}}),{same:['b'],different:[],unavailable:['a']});
});
