import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'_scratch/fingerprint-tests';OUT.mkdir(exist_ok=True)
BASE=os.environ.get('FINGERPRINT_TEST_ORIGIN','http://127.0.0.1:8765').rstrip('/')
URL=BASE+'/tools/browser-fingerprint/'
with sync_playwright()as p:
 chromium=p.chromium.launch(args=['--enable-gpu','--use-angle=d3d11']);ctx=chromium.new_context(permissions=['clipboard-read','clipboard-write']);page=ctx.new_page();page.goto(URL)
 expect(page.get_by_role('button',name='导出指纹')).to_be_enabled(timeout=15000)
 page.get_by_role('tab',name='浏览器信息',exact=True).click();page.get_by_role('button',name='创建配对码',exact=True).click()
 expect(page.get_by_text('配对设备码',exact=True)).to_be_visible()
 code=page.locator('code[data-id-kind=device]').inner_text()
 with page.expect_download()as event:page.get_by_role('button',name='导出指纹',exact=True).click()
 event.value.save_as(OUT/'paired.json')
 assert json.loads((OUT/'paired.json').read_text(encoding='utf8'))['pairing']['id']==code
 page.get_by_role('button',name='复制配对设备码',exact=True).click()
 assert page.evaluate('navigator.clipboard.readText()')==code
 firefox=p.firefox.launch();other=firefox.new_page(viewport={'width':390,'height':844});other.goto(URL)
 expect(other.get_by_role('button',name='导出指纹')).to_be_enabled(timeout=15000)
 other.locator('input[type=file]').set_input_files(OUT/'paired.json')
 expect(other.get_by_role('button',name='关联此设备',exact=True)).to_be_visible()
 # Import alone must not persist the identity.
 assert other.evaluate("localStorage.getItem('pocket-fingerprint-pair-v1')")is None
 other.get_by_role('button',name='关联此设备',exact=True).click()
 expect(other.get_by_role('dialog')).to_be_visible()
 other.get_by_role('button',name='确认关联',exact=True).click()
 expect(other.locator('code[data-id-kind=device]')).to_have_text(code)
 assert other.evaluate("localStorage.getItem('pocket-fingerprint-pair-v1')")==code
 other.reload();expect(other.get_by_role('button',name='导出指纹')).to_be_enabled(timeout=15000)
 expect(other.locator('code[data-id-kind=device]')).to_have_text(code)
 other.get_by_role('tab',name='浏览器信息',exact=True).click()
 other.get_by_role('button',name='解除配对',exact=True).click()
 assert other.evaluate("localStorage.getItem('pocket-fingerprint-pair-v1')")is None
 # Invalid reports must not crash the page or create content elements.
 other.locator('input[type=file]').set_input_files({'name':'bad.json','mimeType':'application/json','buffer':b'{"schema":"pocket-fingerprint/v1","fingerprint":{}}'})
 expect(other.get_by_text('请选择本工具导出的指纹文件',exact=True)).to_be_visible()
 # Denied WebGL, canvas, audio and storage degrade without throwing.
 restricted=chromium.new_context();restricted.add_init_script('''
 HTMLCanvasElement.prototype.getContext=()=>null;
 Object.defineProperty(window,'OfflineAudioContext',{value:undefined});
 Object.defineProperty(window,'localStorage',{get(){throw Error('denied')}});
 Object.defineProperty(window,'sessionStorage',{get(){throw Error('denied')}});
 ''')
 limited=restricted.new_page();errors=[];limited.on('pageerror',lambda e:errors.append(str(e)));limited.goto(URL)
 expect(limited.get_by_role('button',name='导出指纹')).to_be_enabled(timeout=15000)
 expect(limited.locator('code[data-id-kind=device]')).to_have_text('特征不足')
 limited.get_by_role('tab',name='浏览器信息',exact=True).click();limited.get_by_role('button',name='创建配对码').click()
 expect(limited.get_by_text('浏览器禁止本地保存，请允许本地存储后重试',exact=True)).to_be_visible()
 assert not errors,errors
 chromium.close();firefox.close()
 print(json.dumps({'crossEngineManualPairing':True,'importRequiresConfirmation':True,'persistedOnReload':True,'unpair':True,'clipboard':True,'badImportHandled':True,'deniedAPIsHandled':True}))
