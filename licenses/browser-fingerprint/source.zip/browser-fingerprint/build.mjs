import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {mkdir,readFile,writeFile,copyFile,access,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
let modules=path.join(root,'node_modules');try{await access(path.join(modules,'esbuild'));}catch{modules=path.resolve(root,'../home-react-integration/node_modules');}
const {build}=await import(pathToFileURL(path.join(modules,'esbuild/lib/main.js')).href);
const output=path.resolve(process.env.FINGERPRINT_OUTPUT||path.join(root,'dist'));
await mkdir(path.join(output,'assets'),{recursive:true});
const result=await build({entryPoints:[path.join(root,'src/main.jsx')],nodePaths:[modules],bundle:true,minify:true,legalComments:'eof',outfile:path.join(output,'assets/app.js'),target:['es2022'],define:{'process.env.NODE_ENV':'"production"'},metafile:true});
await copyFile(path.join(root,'index.html'),path.join(output,'index.html'));
const files=[];for(const file of ['index.html','assets/app.js','assets/app.css']){const bytes=await readFile(path.join(output,file));files.push({file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
await writeFile(path.join(output,'manifest.json'),JSON.stringify({name:'浏览器指纹',version:'1.0.0',engine:'NeoPrint 0.3.2',upstream:'36c84b2aa377961f5eb28c5749f79df49c5fa824',files},null,2)+'\n');
const noticesDir=path.join(root,'notices');await mkdir(noticesDir,{recursive:true});
const dependencies=new Map();
for(const input of Object.keys(result.metafile.inputs)){
 const match=input.replaceAll('\\','/').match(/node_modules\/((?:@[^/]+\/)?[^/]+)/);if(!match||dependencies.has(match[1]))continue;
 const name=match[1],dir=path.join(modules,name),pkg=JSON.parse(await readFile(path.join(dir,'package.json'),'utf8'));
 const names=(await readdir(dir)).filter(n=>/^(licen[sc]e|copying|notice)([.\-_]|$)/i.test(n));let text='';
 for(const file of names)try{text+=`\n${file}\n`+await readFile(path.join(dir,file),'utf8');}catch{}
 if(!text){
  const cache=path.join(noticesDir,name.replaceAll('/','_')+'.txt');
  try{text=await readFile(cache,'utf8');}catch{
   const existing=path.resolve(root,'../home-react-integration/notices',name.replaceAll('/','_')+'.txt');
   text=await readFile(existing,'utf8');await writeFile(cache,text);
  }
 }
 if(!text.trim())throw Error('Missing license: '+name);
 dependencies.set(name,{name,version:pkg.version,license:pkg.license,text});
}
dependencies.set('@neoprintjs/core',{name:'@neoprintjs/core',version:'0.3.2+pocket.1',license:'MIT',text:await readFile(path.join(root,'vendor/neoprint/LICENSE'),'utf8')});
const licenses=process.env.FINGERPRINT_OUTPUT?path.resolve(output,'../../licenses/browser-fingerprint'):path.join(output,'licenses');await mkdir(licenses,{recursive:true});
await writeFile(path.join(licenses,'THIRD-PARTY-NOTICES.txt'),[...dependencies.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(p=>`===== ${p.name}@${p.version} (${p.license}) =====\n${p.text}`).join('\n\n'));
await writeFile(path.join(licenses,'dependencies.json'),JSON.stringify([...dependencies.values()].map(({text,...p})=>p),null,2)+'\n');
console.log(JSON.stringify({output,files}));
