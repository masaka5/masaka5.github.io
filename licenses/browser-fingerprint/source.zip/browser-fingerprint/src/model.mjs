import {hashComponents} from '../vendor/neoprint/src/core/hash.ts';

export const MAX_REPORT_BYTES=1048576;
export const isPairingId=id=>typeof id==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id);
export const pairingCode=report=>report?.pairing?.version===1&&isPairingId(report.pairing.id)?report.pairing.id:null;
export const labels={canvas:'画布渲染',webgl:'图形设备',audio:'音频渲染',fonts:'已安装字体',screen:'屏幕与显示',navigator:'浏览器与硬件',timing:'时区与计时',storage:'本地存储',network:'网络状态',gpu:'图形计算',math:'数学运算',intl:'语言与区域',cssFeatures:'样式支持',permissions:'权限状态',domRect:'布局测量',svg:'矢量渲染',webglRender:'三维渲染',shaderPrecision:'着色器精度'};
export const canonical=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);

export function systemName(ua='',platform='',touch=0){
 if(/Android/i.test(ua))return 'Android';
 if(/iPhone|iPod|iPad/i.test(ua)||(/Mac/i.test(platform)&&touch>1))return 'iOS / iPadOS';
 if(/Win/i.test(platform+ua))return 'Windows';
 if(/CrOS/i.test(ua))return 'ChromeOS';
 if(/Mac/i.test(platform+ua))return 'macOS';
 if(/Linux/i.test(platform+ua))return 'Linux';
 return '未知';
}
export function browserName(ua=''){
 for(const [pattern,name]of [[/Edg(?:A|iOS)?\/([\d.]+)/,'Edge'],[/OPR\/([\d.]+)/,'Opera'],[/(?:Firefox|FxiOS)\/([\d.]+)/,'Firefox'],[/(?:Chrome|CriOS|HeadlessChrome)\/([\d.]+)/,'Chrome'],[/Version\/([\d.]+).*Safari/,'Safari']]){const m=ua.match(pattern);if(m)return name+' '+m[1];}
 return '未知浏览器';
}
function normalizeGraphics(renderer=''){
 let value=renderer.replace(/^ANGLE\s*\([^,]+,\s*/i,'').replace(/^ANGLE\s+\w+\s+Renderer:\s*/i,'');
 value=value.replace(/\s*\(0x[0-9a-f]+\)/gi,'').replace(/\s*Direct3D[\s\S]*$/i,'').replace(/,?\s*D3D\d+\)?$/i,'').replace(/\/PCIe.*$/i,'').replace(/,?\s*or similar$/i,'').replace(/,\s*Unspecified Version\)?$/i,'').replace(/\s*OpenGL(?: ES)?[\s\S]*$/i,'').replace(/\((?:R|TM)\)/gi,'');
 // Safari exposes only "Apple GPU"; keep its entire family consistent.
 if(/^Apple\b/i.test(value))return 'apple';
 return value.replace(/\)\s*$/,'').replace(/\s+/g,' ').trim().toLowerCase();
}
export function deviceIdentity(components){
 const nav=components.navigator?.value,gl=components.webgl?.value,time=components.timing?.value;
 const graphics=normalizeGraphics(gl?.renderer||'');
 const system=systemName(nav?.userAgent,nav?.platform,nav?.maxTouchPoints);
 // Do not turn a missing/masked renderer or a software renderer into a device ID.
 if(!nav||!time?.timezone||!graphics||/swiftshader|llvmpipe|software|basic render|^webgl$|^angle$/i.test(graphics)||system==='未知')return {id:null,signals:{system,graphics:graphics||null,timezone:time?.timezone??null,touch:nav?.maxTouchPoints??null},status:'insufficient'};
 const signals={version:1,system,graphics,timezone:time.timezone,touch:nav.maxTouchPoints??0};
 return {id:hashComponents(signals),signals,status:'available'};
}
export function compareComponents(current,reference){
 const result={same:[],different:[],unavailable:[]};
 for(const name of new Set([...Object.keys(current),...Object.keys(reference)])){
  const a=current[name]?.value,b=reference[name]?.value;
  if(a==null||b==null)result.unavailable.push(name);
  else if(canonical(a)===canonical(b))result.same.push(name);
  else result.different.push(name);
 }
 return result;
}
export function parseReport(text){
 if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_REPORT_BYTES)throw Error('文件不能超过 1 MB');
 let data;try{data=JSON.parse(text);}catch{throw Error('请选择有效的指纹 JSON 文件');}
 function check(value,depth=0){
  if(depth>16)throw Error('文件层级过深');
  if(typeof value==='number'&&!Number.isFinite(value))throw Error('文件数据无效');
  if(value&&typeof value==='object')for(const [key,item]of Object.entries(value)){
   if(['__proto__','constructor','prototype'].includes(key))throw Error('文件含有无效字段');
   check(item,depth+1);
  }
 }
 check(data);
 const fp=data?.fingerprint,c=fp?.components;
 if(data?.schema!=='pocket-fingerprint/v1'||!c||Array.isArray(c)||typeof c!=='object'||!Object.keys(c).length||Object.keys(c).length>32||!Number.isFinite(fp.timestamp)||fp.timestamp<=0)throw Error('请选择本工具导出的指纹文件');
 const components={};
 for(const [name,component]of Object.entries(c)){
  if(!Object.hasOwn(labels,name)||!component||Array.isArray(component)||typeof component!=='object'||!Object.hasOwn(component,'value'))throw Error('文件中的特征格式无效');
  components[name]={value:component.value};
 }
 // Recompute identifiers from features; never trust imported labels or IDs.
 if(Object.hasOwn(data,'pairing')&&!pairingCode(data))throw Error('文件中的配对码无效');
 return {schema:data.schema,fingerprint:{timestamp:fp.timestamp,components},...(pairingCode(data)?{pairing:{version:1,id:pairingCode(data)}}:{})};
}
export function makeReport(fp){
 return {schema:'pocket-fingerprint/v1',engine:'NeoPrint 0.3.2 + Pocket fixes',algorithm:'pocket-device/v1',device:deviceIdentity(fp.components),fingerprint:fp};
}
export const available=component=>component?.value!=null&&!(component?.value?.supported===false);
export function summary(name,value){
 if(value==null)return '不可用';
 switch(name){
  case 'canvas':return '图像采样 · '+String(value).length+' 字符';
  case 'navigator':return browserName(value.userAgent);
  case 'webgl':return value.renderer||'渲染器信息受限';
  case 'gpu':return value.supported?([value.vendor,value.architecture].filter(Boolean).join(' · ')||'支持 WebGPU'):'不支持或访问受限';
  case 'screen':return `${value.width} × ${value.height} · ${value.devicePixelRatio} 倍像素`;
  case 'fonts':return `${value.length} 种字体`;
  case 'audio':return `${value.sampleRate} Hz · ${Number(value.sum).toFixed(5)}`;
  case 'timing':return value.timezone||'未知时区';
  case 'network':return value.onLine?(value.effectiveType||'在线'):'离线';
  case 'permissions':return `${Object.values(value).filter(v=>v==='granted').length} 项已授权`;
  case 'storage':return ['localStorage','sessionStorage','indexedDB'].filter(k=>value[k]).join(' · ')||'访问受限';
  case 'webglRender':return value.hash;
  case 'intl':return [value.dateTimeFormat?.locale,value.dateTimeFormat?.timeZone].filter(Boolean).join(' · ');
  default:return typeof value==='string'?value:`${Object.keys(value).length} 项特征`;
 }
}
