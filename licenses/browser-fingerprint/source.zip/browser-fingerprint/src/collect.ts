import {Engine} from '../vendor/neoprint/src/core/engine.ts';
import {allCollectors} from '../vendor/neoprint/src/collectors/index.ts';
import {makeReport} from './model.mjs';

const engine=new Engine();
// No IP probes, device enumeration, voice enumeration, environment/ad-block
// requests, behavior listeners, storage identity or server-side fingerprinting.
const excluded=new Set(['webrtc','media','speech','hardwarePerf','audio']);
for(const collector of allCollectors)if(!excluded.has(collector.name))engine.register(collector);
// Render offline only: no microphone access, sound output or suspended live context.
engine.register({name:'audio',async collect(){
 const start=performance.now();
 const Ctx=window.OfflineAudioContext||(window as any).webkitOfflineAudioContext;
 if(!Ctx)return {value:null,duration:0,entropy:0,stability:0};
 const ctx=new Ctx(1,5000,44100),osc=ctx.createOscillator(),compressor=ctx.createDynamicsCompressor();
 osc.type='triangle';osc.frequency.value=10000;
 compressor.threshold.value=-50;compressor.knee.value=40;compressor.ratio.value=12;compressor.attack.value=0;compressor.release.value=.25;
 osc.connect(compressor);compressor.connect(ctx.destination);osc.start();
 try{
  const buffer=await ctx.startRendering(),samples=buffer.getChannelData(0);let sum=0;
  for(let i=4500;i<5000;i++)sum+=Math.abs(samples[i]);
  return {value:{sum,sampleRate:buffer.sampleRate,length:buffer.length},duration:performance.now()-start,entropy:8,stability:.8};
 }finally{osc.disconnect();compressor.disconnect();}
}});
export async function collect(){
 const fingerprint=await engine.collect({timeout:3500,worker:false});
 return makeReport(fingerprint);
}
