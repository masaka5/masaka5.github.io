import React,{useEffect,useRef,useState,useMemo} from 'react';
import {createRoot} from 'react-dom/client';
import {App,Button,Card,ConfigProvider,Descriptions,Drawer,Empty,Input,Pagination,Space,Spin,Table,Tabs,Tag,Tooltip,Typography} from 'antd';
import zhCN from 'antd/locale/zh_CN';
import {ArrowLeftOutlined,ReloadOutlined,ImportOutlined,ExportOutlined,CopyOutlined,CheckOutlined,SearchOutlined,InfoCircleOutlined,CloseOutlined} from '@ant-design/icons';
import {collect} from './collect.ts';
import {available,browserName,compareComponents,deviceIdentity,isPairingId,labels,MAX_REPORT_BYTES,pairingCode,parseReport,summary,systemName} from './model.mjs';
import './style.css';

const fields={userAgent:'用户代理',platform:'系统平台',language:'首选语言',languages:'语言列表',hardwareConcurrency:'逻辑处理器',maxTouchPoints:'触控点数',deviceMemory:'内存参考（GB）',cookieEnabled:'Cookie',doNotTrack:'禁止跟踪',pdfViewerEnabled:'PDF 查看器',webdriver:'自动化环境',vendor:'厂商',renderer:'渲染器',version:'版本',shadingLanguageVersion:'着色语言',extensions:'扩展',params:'参数',maxTextureSize:'最大纹理尺寸',maxViewportDims:'最大视口',maxAnisotropy:'各向异性过滤',antialias:'抗锯齿',supported:'支持状态',architecture:'架构',device:'设备',description:'设备描述',features:'功能',limits:'上限',width:'宽度',height:'高度',colorDepth:'色彩深度',pixelDepth:'像素深度',devicePixelRatio:'像素比例',orientation:'方向',hdr:'高动态范围',colorGamut:'色域',prefersColorScheme:'颜色模式',prefersReducedMotion:'减少动态效果',prefersContrast:'对比度偏好',touchPoints:'触控点数',sum:'音频采样摘要',sampleRate:'采样率',length:'长度',hash:'哈希',checksum:'校验和',timezone:'时区',timezoneOffset:'时区偏移（分钟）',timerResolution:'计时精度',dateResolution:'日期精度',performanceTimeline:'性能时间线',onLine:'联网状态',effectiveType:'网络类型',downlink:'下行参考（Mbps）',rtt:'延迟参考（ms）',saveData:'节省流量',type:'类型',localStorage:'本地存储',sessionStorage:'会话存储',indexedDB:'索引数据库',storageEstimate:'存储估算',quota:'配额（字节）',usage:'已用（字节）',privateBrowsing:'小配额提示（非隐私模式结论）',dateTimeFormat:'日期格式',numberFormat:'数字格式',collator:'排序规则',locale:'区域语言',timeZone:'时区',numberingSystem:'数字系统',calendar:'历法',system:'系统',graphics:'图形设备',touch:'触控点数',crossBrowserId:'NeoPrint 跨浏览器 ID',weightedId:'NeoPrint 加权 ID',vertex:'顶点着色器',fragment:'片元着色器',geolocation:'定位',notifications:'通知',push:'推送',camera:'摄像头',microphone:'麦克风',accelerometer:'加速度计',gyroscope:'陀螺仪',magnetometer:'磁力计','clipboard-read':'读取剪贴板','clipboard-write':'写入剪贴板',midi:'MIDI','background-sync':'后台同步','persistent-storage':'持久存储','screen-wake-lock':'屏幕唤醒锁'};
const valueLabels={true:'是',false:'否',granted:'已授权',denied:'已拒绝',prompt:'询问',unsupported:'不支持',dark:'深色',light:'浅色','no-preference':'默认','landscape-primary':'横向','portrait-primary':'纵向'};
const show=value=>value==null?'不可用':typeof value==='object'?JSON.stringify(value):valueLabels[String(value)]??String(value);
const fingerprintIcon=<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" aria-hidden="true"><path d="M12 11a2 2 0 0 0-2 2c0 3.6-.5 5.8-1.5 8M14 13c0 4-.2 6.4-1 9M8 16c-.2 2.1-.8 4-1.5 5M6 13a6 6 0 1 1 12 0c0 3.5-.2 6-1 8M3 15v-2a9 9 0 0 1 18 0v2M6 5a10 10 0 0 1 12 0M4 18l-.5 1M20 18l-.5 2"/></svg>;

function KeyCard({title,id,primary,note}){
 const {message}=App.useApp();
 const copy=async()=>{try{await navigator.clipboard.writeText(id);message.success('已复制');}catch{message.error('复制失败，请长按或选择编号复制');}};
 return <Card className={'key-card'+(primary?' primary-key':'')}><div className="key-title"><span>{title}</span><Tooltip title={note}><InfoCircleOutlined tabIndex={0}/></Tooltip></div><div className="key-value"><code data-id-kind={primary?'device':title}>{id||'特征不足'}</code><Button type="text" aria-label={'复制'+title} icon={<CopyOutlined/>} onClick={copy} disabled={!id}/></div></Card>;
}
function FeatureDetails({value}){
 const [raw,setRaw]=useState(false);
 return <><div className="drawer-actions"><Button size="small" onClick={()=>setRaw(!raw)}>{raw?'字段视图':'原始数据'}</Button></div>{raw?<pre className="raw-data">{JSON.stringify(value,null,2)}</pre>:<Descriptions column={1} bordered size="small" items={(value&&typeof value==='object'&&!Array.isArray(value)?Object.entries(value):[['value',value]]).map(([key,item])=>({key,label:fields[key]||key,children:<span className="detail-value">{show(item)}</span>}))}/>}</>;
}
function FingerprintPage(){
 const {message,modal}=App.useApp(),[report,setReport]=useState(null),[busy,setBusy]=useState(true),[error,setError]=useState(''),[reference,setReference]=useState(null),[tab,setTab]=useState('features'),[query,setQuery]=useState(''),[page,setPage]=useState(1),[capacity,setCapacity]=useState(5),[detail,setDetail]=useState(null);
 const [paired,setPaired]=useState(()=>{try{const id=localStorage.getItem('pocket-fingerprint-pair-v1');return isPairingId(id)?id:null;}catch{return null;}});
 const file=useRef(null),panel=useRef(null),running=useRef(false),urlRef=useRef(null);
 async function detect(){
  if(running.current)return;running.current=true;setBusy(true);setError('');
  try{const next=await collect();setReport(next);}
  catch{setError('检测失败，请重新检测或检查浏览器隐私设置');}
  finally{setBusy(false);running.current=false;}
 }
 useEffect(()=>{detect();return()=>{if(urlRef.current)URL.revokeObjectURL(urlRef.current);};},[]);
 useEffect(()=>{
  if(!panel.current)return;
  const observer=new ResizeObserver(([entry])=>setCapacity(Math.max(1,Math.floor((entry.contentRect.height-145)/52))));
  observer.observe(panel.current);return()=>observer.disconnect();
 },[]);
 const fp=report?.fingerprint,components=fp?.components||{},device=report?.device;
 const comparison=useMemo(()=>reference&&fp?compareComponents(components,reference.fingerprint.components):null,[fp,reference]);
 const rows=Object.keys(labels).filter(name=>Object.hasOwn(components,name)&&(!query||`${labels[name]} ${name} ${summary(name,components[name].value)}`.toLowerCase().includes(query.toLowerCase()))).map(name=>({key:name,name:labels[name],value:components[name].value,summary:summary(name,components[name].value)}));
 const count=rows.length,activePage=Math.min(page,Math.max(1,Math.ceil(count/capacity)));
 const nav=components.navigator?.value||{},screen=components.screen?.value||{};
 async function importReport(event){
  const input=event.target,item=input.files?.[0];input.value='';if(!item)return;
  try{if(item.size>MAX_REPORT_BYTES)throw Error('文件不能超过 1 MB');const next=parseReport(await item.text());setReference(next);setTab('compare');setQuery('');setPage(1);message.success('已载入对比');}
  catch(e){message.error(e.message||'无法读取文件');}
 }
 function download(){
  if(!report)return;if(urlRef.current)URL.revokeObjectURL(urlRef.current);
  const payload={...report,...(paired?{pairing:{version:1,id:paired}}:{})};
  const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));urlRef.current=url;
  const a=document.createElement('a');a.href=url;a.download='浏览器指纹-'+new Date(fp.timestamp).toISOString().slice(0,10)+'.json';a.click();
 }
 function savePairing(id){
  try{if(id)localStorage.setItem('pocket-fingerprint-pair-v1',id);else localStorage.removeItem('pocket-fingerprint-pair-v1');setPaired(id);message.success(id?'配对码已保存':'已解除配对');}
  catch{message.error('浏览器禁止本地保存，请允许本地存储后重试');}
 }
 function associate(){const code=pairingCode(reference);if(!code)return;modal.confirm({title:'关联配对设备码',content:'当前浏览器将保存报告中的配对码。自动检测的指纹不变。',okText:'确认关联',cancelText:'取消',onOk:()=>savePairing(code)});}
 const details=(row)=>setDetail({title:row.name,value:row.value});
 const columns=[{title:'特征',dataIndex:'name',width:132,render:(name,row)=><span className="feature-name"><span className={'status-dot'+(available(components[row.key])?' valid':'')}/>{name}</span>},{title:'检测结果',dataIndex:'summary',ellipsis:true,render:text=><span title={text}>{text}</span>},{title:'',key:'action',width:54,render:(_,row)=><Button type="text" size="small" aria-label={'查看'+row.name} onClick={()=>details(row)} icon={<SearchOutlined/>}/>}];
 const compareCols=[{title:'特征',dataIndex:'name',width:132},{title:'对比结果',key:'match',render:(_,row)=>comparison.same.includes(row.key)?<Tag color="success">相同</Tag>:comparison.different.includes(row.key)?<Tag color="warning">不同</Tag>:<Tag>不可比较</Tag>},{title:'',key:'action',width:54,render:(_,row)=><Button size="small" type="text" aria-label={'对比'+row.name} icon={<SearchOutlined/>} onClick={()=>setDetail({title:row.name+' · 对比',current:components[row.key]?.value,reference:reference.fingerprint.components[row.key]?.value})}/> }];
 return <div className="fingerprint-shell"><header className="tool-header"><div className="header-title"><Button type="text" href="../../" aria-label="返回工具箱" icon={<ArrowLeftOutlined/>}/><span className="fingerprint-icon">{fingerprintIcon}</span><h1>浏览器指纹</h1></div><Space size={6}><Tooltip title="重新检测"><Button aria-label="重新检测" loading={busy} icon={<ReloadOutlined/>} onClick={detect}/></Tooltip><Tooltip title="导入对比"><Button aria-label="导入对比" disabled={!report||busy} icon={<ImportOutlined/>} onClick={()=>file.current?.click()}/></Tooltip><Tooltip title="导出指纹"><Button aria-label="导出指纹" disabled={!report||busy} icon={<ExportOutlined/>} onClick={download}/></Tooltip><input ref={file} type="file" accept=".json,application/json" onChange={importReport} hidden/></Space></header>
 <main className="tool-main"><section className="key-grid" aria-label="指纹标识"><KeyCard primary title={paired?'配对设备码':'设备特征码'} id={paired||device?.id} note={paired?'由你手动关联并保存在此浏览器的共享编号，不是自动生成的浏览器指纹。清除站点数据后需重新导入关联。':'规范化系统、图形设备、时区与触控特征，尽量跨浏览器保持一致。相同配置可能重号，隐私保护或环境变化可能导致不同。'}/><KeyCard title="浏览器指纹" id={fp?.id} note="包含浏览器、屏幕、渲染、权限与网络等特征，环境变化时会改变。"/><KeyCard title="稳定指纹" id={fp?.stableId} note="NeoPrint 筛选出的较稳定特征，侧重同一浏览器内的重复检测，不保证跨浏览器相同。"/></section>
 <div className="summary-line"><span>{busy?'正在检测…':error||(paired?'已手动配对 · 自动指纹保留在明细中':!device?.id?'设备信息受限，可查看各项浏览器指纹':'同设备跨浏览器参考，相同配置可能重号')}</span><span className="local-label">本地检测 · 不上传</span></div>
 <Card className="workspace-card"><div className="workspace-top"><Tabs activeKey={tab} onChange={key=>{setTab(key);setPage(1);setQuery('');}} items={[{key:'features',label:'特征明细'},{key:'browser',label:'浏览器信息'},{key:'compare',label:'指纹对比'}]}/><span className="collect-count">{Object.values(components).filter(available).length} / {Object.keys(labels).length}</span></div>
 {tab==='compare'&&pairingCode(reference)&&<div className="pair-toolbar"><span>{paired===pairingCode(reference)?'配对设备码已关联':'报告包含跨浏览器配对码'}</span>{paired!==pairingCode(reference)&&<Button size="small" type="primary" onClick={associate}>关联此设备</Button>}</div>}
 <div className="workspace-body" ref={panel} aria-busy={busy}>
 {busy&&!report?<div className="center-state"><Spin tip="正在检测"><div className="spin-space"/></Spin></div>:!report?<div className="center-state"><Empty description={error||'暂时无法检测'}/><Button onClick={detect}>重新检测</Button></div>:tab==='browser'?<div className="browser-details"><Descriptions column={{xs:1,sm:2,md:2}} bordered size="small" items={[
 {key:'browser',label:'浏览器',children:browserName(nav.userAgent)},
 {key:'os',label:'操作系统',children:systemName(nav.userAgent,nav.platform,nav.maxTouchPoints)},
 {key:'cores',label:'逻辑处理器',children:nav.hardwareConcurrency?`${nav.hardwareConcurrency} 线程`:'不可用'},
 {key:'memory',label:'内存参考',children:nav.deviceMemory?`${nav.deviceMemory} GB（浏览器取整值）`:'浏览器未提供'},
 {key:'screen',label:'屏幕',children:summary('screen',screen)},
 {key:'zone',label:'时区',children:components.timing?.value?.timezone||'不可用'},
 {key:'language',label:'语言',children:nav.languages?.join('、')||'不可用'},
 {key:'time',label:'检测时间',children:new Date(fp.timestamp).toLocaleTimeString('zh-CN')},
 {key:'cross',label:'NeoPrint 跨浏览器 ID',span:2,children:<code>{fp.crossBrowserId}</code>},
 {key:'auto',label:'自动设备特征码',span:2,children:<code>{device.id||'特征不足'}</code>},
 {key:'pair',label:'跨浏览器配对',span:2,children:<Space wrap>{paired?<><code className="pair-code">{paired}</code><Button size="small" onClick={()=>savePairing(null)}>解除配对</Button></>:<><Button size="small" onClick={()=>{if(!crypto.randomUUID){message.error('请使用 HTTPS 打开页面');return;}savePairing(crypto.randomUUID());}}>创建配对码</Button><span className="pair-hint">创建后导出，在另一浏览器导入并关联</span></>}</Space>},
 {key:'device',label:'设备特征',span:2,children:<Button type="link" onClick={()=>setDetail({title:'设备特征码依据',value:device.signals})}>查看计算依据</Button>},
 {key:'ua',label:'用户代理',span:2,children:<span className="ua-text">{nav.userAgent}</span>}
 ]}/></div>:tab==='compare'&&!reference?<div className="center-state"><Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="导入另一浏览器导出的指纹"/><Button type="primary" icon={<ImportOutlined/>} onClick={()=>file.current?.click()}>选择指纹文件</Button></div>:<><div className="table-toolbar">{tab==='compare'?<><span className="comparison-info"><Tag color={device?.id&&device.id===deviceIdentity(reference.fingerprint.components).id?'success':'default'}>{device?.id&&device.id===deviceIdentity(reference.fingerprint.components).id?'设备特征码相同':'设备特征码不同或不足'}</Tag><span>{comparison.same.length} 相同 / {comparison.different.length} 不同</span></span><Tooltip title="清除对比"><Button type="text" aria-label="清除对比" icon={<CloseOutlined/>} onClick={()=>setReference(null)}/></Tooltip></>:<Input prefix={<SearchOutlined/>} placeholder="筛选特征" aria-label="筛选特征" value={query} allowClear onChange={e=>{setQuery(e.target.value);setPage(1);}}/>}</div><div className="feature-table"><Table columns={tab==='compare'?compareCols:columns} dataSource={rows.slice((activePage-1)*capacity,activePage*capacity)} pagination={false} size="small" tableLayout="fixed" locale={{emptyText:<Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="无匹配特征"/>}}/></div><div className="table-pagination"><span>{count} 项特征{tab==='compare'&&comparison.unavailable.length?` · ${comparison.unavailable.length} 项不可比较`:''}</span><Pagination size="small" simple current={activePage} pageSize={capacity} total={count} showSizeChanger={false} onChange={setPage}/></div></>}
 </div></Card></main>
 <Drawer title={detail?.title} open={!!detail} onClose={()=>setDetail(null)} closable={false} extra={<Button type="text" aria-label="关闭" icon={<CloseOutlined/>} onClick={()=>setDetail(null)}/>} width={Math.min(600,globalThis.innerWidth-16)} destroyOnHidden>{detail&&(Object.hasOwn(detail,'reference')?<><h3>当前浏览器</h3><FeatureDetails value={detail.current}/><h3>导入报告</h3><FeatureDetails value={detail.reference}/></>:<FeatureDetails value={detail.value}/>)}</Drawer></div>;
}
createRoot(document.getElementById('root')).render(<ConfigProvider locale={zhCN} theme={{token:{colorPrimary:'#315fc9',colorText:'#242d3a',colorTextSecondary:'#687588',colorBorder:'#e3e7ed',borderRadius:8,fontSize:14,controlHeight:36,fontFamily:'-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif'},components:{Card:{paddingLG:20},Table:{headerBg:'#f8f9fb'}}}}><App><FingerprintPage/></App></ConfigProvider>);
