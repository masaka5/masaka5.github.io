import {build} from 'esbuild';
import {mkdir,copyFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const out=resolve('../../toolbox-site/tools/powershell-ide');await mkdir(out,{recursive:true});
await build({entryPoints:['src/app.js'],bundle:true,minify:true,format:'esm',target:'es2022',outfile:out+'/app.js',legalComments:'external'});
await copyFile('src/index.html',out+'/index.html');await copyFile('src/app.css',out+'/app.css');
console.log('Built PowerShell IDE:',out);
