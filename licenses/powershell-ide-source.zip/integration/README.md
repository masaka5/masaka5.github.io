# PowerShell 7 IDE

Pure static browser IDE. `npm ci && npm test && npm run build && npm run package-source`.
The build output is `../../toolbox-site/tools/powershell-ide`.
Serve the existing `toolbox-site` static tree, then open `/tools/powershell-ide/`.
No local execution server or API endpoint is used by the product.

The editor uses CodeMirror 6 with the upstream PowerShell stream grammar.
The terminal uses existing xterm.js / fit / Unicode 11 bundles. A thin bridge
loads the existing v86 WASM and Alpine x86_64 / PowerShell 7.4.13 image from
`../webvm/images`; there is no extra VM image copy. Runtime RAM is 1 GiB.
Shared libraries and image provenance are recorded in the manifest and existing
`licenses/sources.json`, `licenses/third-party-notices.txt`, and
`licenses/integration-source.zip`. BIOS and Linux retain their own licenses.

The initial bash serial session starts a persistent, interactive PowerShell
session. Its prompt emits a session-specific OSC readiness marker. Script
execution writes UTF-8 bytes through v86 9p into `/mnt/共享`, then invokes the
actual `pwsh -NoLogo -File` process; selection executes a separate temporary
script while the full editor file is still saved. The visible terminal receives
all stdout/stderr and supports PSReadLine keys and interactive script input.
Ctrl+C interrupts the foreground process. Reset destroys the VM; editor content
stays in a validated, versioned localStorage draft. Corrupt saved drafts are
preserved until the user explicitly replaces them through New or Import.

PowerShell's serial-console ReadKey path can decode multibyte input byte by
byte. To preserve Chinese while retaining PSReadLine editing, Unicode terminal
input is written as UTF-8 to 9p and inserted at the caret by a PSReadLine F12
handler. A per-session OSC acknowledgment serializes subsequent keys. ASCII
keys, cursor controls, Ctrl+C and terminal DSR replies use the serial stream.
Unicode script paths cross as Base64 UTF-8 and decode inside PowerShell before
being passed to the real `pwsh -NoLogo -File`; the original script path and
`$PSScriptRoot` are preserved.

`python test/browser.py` launches actual Chromium, boots the actual guest, and
checks execution, Chinese text, parse errors, cancel/recovery, terminal editing,
selection, 9p bytes, refresh persistence and five viewports. It requires Python
Playwright and the existing static server at localhost:8765 (or TOOLBOX_TEST_BASE).
