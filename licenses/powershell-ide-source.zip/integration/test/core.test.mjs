import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fileName,parseDraft,psQuote,encodedPath} from '../src/core.js';
test('script names cannot inject terminal commands or paths',()=>{assert.equal(fileName('中文.ps1'),'中文.ps1');for(const value of ['../x.ps1','a\rWrite-Output x.ps1','a/b.ps1'])assert.throws(()=>fileName(value));assert.equal(psQuote("a'b.ps1"),"'a''b.ps1'");});
test('damaged drafts are rejected without silently substituting a blank draft',()=>{assert.equal(parseDraft(null),null);assert.throws(()=>parseDraft('{oops'));assert.throws(()=>parseDraft('{"version":1,"code":4}'));assert.deepEqual(parseDraft('{"version":1,"code":"中文","name":"中文.ps1"}'),{version:1,code:'中文',name:'中文.ps1'});});
test('Chinese script paths cross terminal as ASCII and decode losslessly',()=>{const input="/mnt/共享/中文'a.ps1",encoded=encodedPath(input);assert.match(encoded,/^[A-Za-z0-9+/=]+$/);assert.equal(Buffer.from(encoded,'base64').toString('utf8'),input);});
