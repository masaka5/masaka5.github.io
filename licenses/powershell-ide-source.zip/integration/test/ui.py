import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[3]
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch();page=await browser.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)));await page.goto(BASE+'/tools/powershell-ide/')
  async def edit(code):
   await page.locator('.cm-content').click();await page.keyboard.press('Control+a');await page.keyboard.insert_text(code)
  await edit('Write-Output "本机草稿"');await page.wait_for_timeout(600);await page.reload();assert '本机草稿' in await page.locator('.cm-content').inner_text()
  async with page.expect_download() as event:await page.locator('#exportFile').click()
  download=await event.value;assert '本机草稿' in Path(await download.path()).read_text(encoding='utf-8-sig')
  await page.locator('#fileInput').set_input_files({'name':'导入中文.ps1','mimeType':'text/plain','buffer':'Write-Output "导入成功"'.encode('utf-16')});await page.locator('#confirmDialog button[value=confirm]').click();await page.wait_for_function("document.querySelector('.cm-content').textContent.includes('导入成功')");assert await page.locator('#fileName').input_value()=='导入中文.ps1'
  for w,h in [(1920,1080),(1440,900),(1024,768),(768,1024),(390,844)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(150);assert await page.evaluate('document.documentElement.scrollHeight<=innerHeight+1 && document.documentElement.scrollWidth<=innerWidth+1'),(w,h)
  await page.screenshot(path=str(ROOT/'_scratch/powershell-ide-mobile-idle.png'));await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path=str(ROOT/'_scratch/powershell-ide-desktop-idle.png'))
  await page.close();page=await browser.new_page();await page.add_init_script("localStorage.setItem('toolbox-powershell-ide-draft-v1','{broken')");await page.goto(BASE+'/tools/powershell-ide/');await edit('Write-Output "不得覆盖"');await page.wait_for_timeout(600);assert await page.evaluate("localStorage.getItem('toolbox-powershell-ide-draft-v1')")=='{broken'
  await page.locator('#newFile').click();await page.locator('#confirmDialog button[value=confirm]').click();await edit('Write-Output "新草稿"');await page.wait_for_timeout(600);assert '新草稿' in await page.evaluate("localStorage.getItem('toolbox-powershell-ide-draft-v1')")
  assert not errors,errors;print(json.dumps({'draftRefresh':True,'UTF16ChineseImport':True,'BOMExport':True,'corruptDraftProtected':True,'explicitNewReplaces':True,'viewports':5,'pageErrors':errors}));await browser.close()
asyncio.run(main())
