"""Real V86 Linux and PowerShell 7 end-to-end; no runner mocks."""
import asyncio,json,os,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[3]
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
HOOK="""(()=>{let ctor;window.vmOutput='';Object.defineProperty(window,'V86',{configurable:true,get(){return ctor},set(value){ctor=new Proxy(value,{construct(target,args){const vm=Reflect.construct(target,args);window.actualVM=vm;const decoder=new TextDecoder();vm.add_listener('serial0-output-byte',b=>window.vmOutput+=decoder.decode(Uint8Array.of(b),{stream:true}));return vm;}})}})})();"""
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True);page=await browser.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)));await page.add_init_script(HOOK)
  response=await page.goto(BASE+'/tools/powershell-ide/');assert response.status==200,'PowerShell IDE entry is missing'
  async def edit(code):
   await page.locator('.cm-content').click();await page.keyboard.press('Control+a');await page.keyboard.insert_text(code)
  await edit('Write-Output (2 + 2)\nWrite-Output "中文执行正常"')
  async def progress():
   for _ in range(40):
    await asyncio.sleep(20)
    print('Progress',json.dumps(await page.evaluate("({state:document.querySelector('#runtimeState').dataset.state,status:document.querySelector('#status').textContent,out:vmOutput.slice(-450)})")),errors,flush=True)
  progressTask=asyncio.create_task(progress())
  await page.locator('#runAll').click()
  try:await page.wait_for_function("/4\\r?\\n中文执行正常\\r?\\n/.test(vmOutput)",timeout=300000)
  except Exception:
   print('Boot diagnostic:',await page.locator('#status').inner_text(),repr(await page.evaluate('vmOutput.slice(-12000)')),errors,flush=True);await page.screenshot(path=str(ROOT/'_scratch/powershell-ide-failure.png'));raise
  await page.wait_for_function("document.querySelector('#runtimeState').dataset.state==='ready'",timeout=120000)
  print('Real PowerShell script: 2+2 and Chinese passed',flush=True)
  await page.evaluate("vmOutput=''");await edit('Write-Output "SYNTAX_BROKEN');await page.locator('#runAll').click()
  await page.wait_for_function("vmOutput.includes('ParserError')",timeout=120000);await page.wait_for_function("document.querySelector('#runtimeState').dataset.state==='ready'",timeout=120000);print('Syntax error passed',flush=True)
  await edit("Write-Output ('CANCEL_'+'START'); while ($true) {}")
  await page.locator('#runAll').click();await page.wait_for_function("vmOutput.includes('CANCEL_START')",timeout=120000)
  await page.locator('#stopRun').click();await page.wait_for_function("document.querySelector('#runtimeState').dataset.state==='ready'",timeout=30000);print('Ctrl+C cancel passed',flush=True)
  await edit("Write-Output ('RECOVER_'+'OK')");await page.locator('#runAll').click();await page.wait_for_function("vmOutput.includes('RECOVER_OK')",timeout=120000)
  await page.wait_for_function("document.querySelector('#runtimeState').dataset.state==='ready'",timeout=120000);print('New run after cancel passed',flush=True)
  term=page.locator('#terminal .xterm-helper-textarea');await term.focus();await page.keyboard.type("Write-Output ('INPUT_'+'OX')");await page.keyboard.press('ArrowLeft');await page.keyboard.press('ArrowLeft');await page.keyboard.press('ArrowLeft');await page.keyboard.press('Delete');await page.keyboard.type('K');await page.keyboard.press('End');await page.keyboard.press('Enter');await page.wait_for_function("vmOutput.includes('INPUT_OK')",timeout=30000)
  await page.locator('#terminalInput').fill('Write-Output ("中文"+"交互正常")');await page.locator('#sendInput').click()
  try:await page.wait_for_function("vmOutput.includes('中文交互正常')",timeout=30000)
  except Exception:print('Unicode input diagnostic',await page.locator('#status').inner_text(),json.dumps(await page.evaluate('vmOutput.slice(-5000)')),flush=True);raise
  print('Terminal edit and Chinese input passed',flush=True)
  await page.locator('#terminalInput').fill("Write-Output ('DIMS='+[Console]::WindowWidth+','+[Console]::WindowHeight)");await page.locator('#sendInput').click();await page.wait_for_function('/DIMS=\\d+,\\d+/.test(vmOutput)',timeout=30000)
  before=re.search(r'DIMS=(\d+),(\d+)',await page.evaluate('vmOutput')).groups();await page.set_viewport_size({'width':1024,'height':768});await page.wait_for_timeout(1800)
  await page.locator('#terminalInput').fill("Write-Output ('RESIZE='+[Console]::WindowWidth+','+[Console]::WindowHeight)");await page.locator('#sendInput').click();await page.wait_for_function('/RESIZE=\\d+,\\d+/.test(vmOutput)',timeout=30000)
  after=re.search(r'RESIZE=(\d+),(\d+)',await page.evaluate('vmOutput')).groups();assert before!=after,(before,after);await page.set_viewport_size({'width':1440,'height':900})
  await edit('Write-Output "只执行选择"\nthrow "不应执行"');await page.locator('.cm-content').click();await page.keyboard.press('Control+Home');await page.keyboard.press('Shift+End');await page.locator('#runSelection').click();await page.wait_for_function("vmOutput.includes('只执行选择')",timeout=120000)
  await page.wait_for_function("document.querySelector('#runtimeState').dataset.state==='ready'",timeout=120000)
  raw=await page.evaluate("async()=>new TextDecoder().decode(await actualVM.read_file(document.querySelector('#fileName').value))")
  assert raw=='Write-Output "只执行选择"\nthrow "不应执行"',raw
  progressTask.cancel()
  for w,h in [(1920,1080),(1440,900),(1024,768),(768,1024),(390,844)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(400)
   assert await page.evaluate('document.documentElement.scrollHeight<=innerHeight+1 && document.documentElement.scrollWidth<=innerWidth+1'),(w,h)
  await page.screenshot(path=str(ROOT/'_scratch/powershell-ide-mobile.png'))
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path=str(ROOT/'_scratch/powershell-ide-desktop.png'))
  await page.reload();assert '只执行选择' in await page.locator('.cm-content').inner_text()
  async with page.expect_download() as download_event:await page.locator('#exportFile').click()
  download=await download_event.value;assert download.suggested_filename.endswith('.ps1');download_path=await download.path();assert '只执行选择' in Path(download_path).read_text(encoding='utf-8-sig')
  await page.locator('#fileInput').set_input_files({'name':'导入中文.ps1','mimeType':'text/plain','buffer':'Write-Output "导入成功"'.encode('utf-8')});await page.locator('#confirmDialog button[value=confirm]').click()
  await page.wait_for_function("document.querySelector('.cm-content').textContent.includes('导入成功')");assert await page.locator('#fileName').input_value()=='导入中文.ps1'
  await page.close();page=await browser.new_page();await page.add_init_script("localStorage.setItem('toolbox-powershell-ide-draft-v1','{broken')");await page.goto(BASE+'/tools/powershell-ide/');await edit('Write-Output "不要覆盖损坏草稿"');await page.wait_for_timeout(500)
  assert await page.evaluate("localStorage.getItem('toolbox-powershell-ide-draft-v1')")=='{broken'
  assert not errors,errors
  print(json.dumps({'realVM':True,'runFile':True,'Chinese':True,'syntaxError':True,'CtrlCRecovery':True,'selection':True,'draftRefresh':True,'viewports':5,'pageErrors':errors},ensure_ascii=False),flush=True)
  await browser.close()
asyncio.run(main())
