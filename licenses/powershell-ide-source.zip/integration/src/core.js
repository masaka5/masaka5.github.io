export const MAX_CODE=2*1024*1024;
export function fileName(value){const name=String(value).trim();if(!name||/[\\/\x00-\x1f\x7f]/.test(name)||new TextEncoder().encode(name).length>200||name==='.'||name==='..')throw Error('文件名不能包含路径或控制字符，且需少于 200 字节');return /\.ps1$/i.test(name)?name:name+'.ps1';}
export function psQuote(value){return "'"+String(value).replaceAll("'","''")+"'";}
export function encodedPath(value){return btoa(String.fromCharCode(...new TextEncoder().encode(value)));}
export function parseDraft(raw){if(raw===null)return null;const d=JSON.parse(raw);if(d?.version!==1||typeof d.code!=='string'||d.code.length>MAX_CODE||typeof d.name!=='string')throw Error('草稿格式无效');return {version:1,code:d.code,name:fileName(d.name)};}
