import {build} from 'esbuild';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const output=process.env.HOME_REACT_OUTPUT?path.resolve(process.env.HOME_REACT_OUTPUT):path.resolve(root,'../../toolbox-site/assets/home-react');
await mkdir(output,{recursive:true});
const result=await build({entryPoints:[path.join(root,'src/main.jsx')],bundle:true,minify:true,legalComments:'eof',outfile:path.join(output,'home.js'),target:['es2022'],define:{'process.env.NODE_ENV':'"production"'},metafile:true});
const noticeDir=path.resolve(output,'../../licenses/home-react');await mkdir(noticeDir,{recursive:true});
const upstreamLicenses={
 '@ant-design/icons-svg':{url:'https://raw.githubusercontent.com/ant-design/ant-design-icons/7f2516ac91226d2b41f93b35cb5197c8d94f7189/LICENSE'},
 'toggle-selection':{url:'https://raw.githubusercontent.com/sudodoki/toggle-selection/538dc4e9de40b8aee41f1e9066a4c5de3f4adc0a/LICENSE'}
};
const packages=new Map();
for(const input of Object.keys(result.metafile.inputs)){const normalized=input.replaceAll('\\','/'),match=normalized.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/);if(!match)continue;const name=match[1];if(packages.has(name))continue;const folder=path.join(root,'node_modules',name),pkg=JSON.parse(await readFile(path.join(folder,'package.json'),'utf8'));const files=(await readdir(folder)).filter(name=>/^(licen[sc]e|copying|notice)([.\-_]|$)/i.test(name)),notices=[];for(const file of files){try{notices.push({file,text:await readFile(path.join(folder,file),'utf8')});}catch{}}if(!notices.length&&upstreamLicenses[name]){const cached=path.join(root,'notices',name.replaceAll('/','_')+'.txt');let text;try{text=await readFile(cached,'utf8');}catch{const response=await fetch(upstreamLicenses[name].url);if(!response.ok)throw Error('Cannot fetch original license: '+name);text=await response.text();await mkdir(path.dirname(cached),{recursive:true});await writeFile(cached,text);}notices.push({file:upstreamLicenses[name].url,text});}if(!notices.length)throw Error('Missing original license: '+name);packages.set(name,{name,version:pkg.version,license:pkg.license,notices});}
const notices=[...packages.values()].sort((a,b)=>a.name.localeCompare(b.name));
await writeFile(path.join(noticeDir,'THIRD-PARTY-NOTICES.txt'),notices.map(p=>`===== ${p.name}@${p.version} (${p.license}) =====\n${p.notices.map(n=>`${n.file}\n${n.text}`).join('\n')}\n`).join('\n'));
await writeFile(path.join(noticeDir,'dependencies.json'),JSON.stringify(notices.map(({notices,...pkg})=>pkg),null,2)+'\n');
const artifacts={};for(const file of ['home.js','home.css']){const bytes=await readFile(path.join(output,file));artifacts[file]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};}
await writeFile(path.join(output,'manifest.json'),JSON.stringify({name:'pocket-toolbox-react-home',framework:'React 19 + Ant Design 5',dependencies:JSON.parse(await readFile(path.join(root,'package.json'),'utf8')).dependencies,artifacts},null,2)+'\n');
console.log(JSON.stringify({output,packages:packages.size,artifacts},null,2));
