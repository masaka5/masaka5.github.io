$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$site = [IO.Path]::GetFullPath((Join-Path $project '../../toolbox-site'))
$stage = Join-Path ([IO.Path]::GetTempPath()) ('home-react-source-' + [guid]::NewGuid().ToString('N'))
$source = Join-Path $stage '_scratch/home-react-integration'
New-Item -ItemType Directory -Path $source -Force | Out-Null
foreach ($name in @('src','notices','package.json','package-lock.json','build.mjs','package-source.ps1','README.md','LICENSE')) {
  Copy-Item -LiteralPath (Join-Path $project $name) -Destination $source -Recurse
}
$siteCopy = Join-Path $stage 'toolbox-site'
New-Item -ItemType Directory -Path (Join-Path $siteCopy 'assets') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $site 'index.html') -Destination $siteCopy
foreach ($name in @('catalog.js','tool-icon-paths.js','tool-icons.js','usage.js','usage-config.json','design-system.css','favicon.svg')) {
  Copy-Item -LiteralPath (Join-Path $site ('assets/' + $name)) -Destination (Join-Path $siteCopy 'assets')
}
$archive = Join-Path $site 'licenses/home-react-source.zip'
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $archive -Force
$hashes = Get-ChildItem -LiteralPath $stage -Recurse -File | ForEach-Object {
  @{path=$_.FullName.Substring($stage.Length + 1).Replace('\','/'); bytes=$_.Length; sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLower()}
}
$manifest = @{schema=1; sourceArchive='home-react-source.zip'; archiveBytes=(Get-Item -LiteralPath $archive).Length; archiveSha256=(Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLower(); files=@($hashes)}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $site 'licenses/home-react-source-manifest.json') -Encoding utf8
Write-Output ($manifest | ConvertTo-Json -Depth 2)
# The isolated staging directory is left in the system temporary directory for inspection.
