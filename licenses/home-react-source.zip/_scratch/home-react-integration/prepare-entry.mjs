import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export function homePlaceholder(){
 const category=Array.from({length:22},()=>'<span class="loading-category"><i></i><b></b></span>').join('');
 const cards=Array.from({length:32},()=>'<div class="loading-card"><div class="tool-link"><div class="card-top"><span class="tool-icon"></span></div><div class="card-copy"><span class="loading-line"></span></div></div></div>').join('');
 return `<div class="toolbox home-loading" aria-hidden="true"><aside class="sidebar"><span class="brand"><span class="brand-symbol"><i></i><i></i><i></i><i></i></span><span>口袋工具箱</span></span><div class="nav-region"><div class="category-nav">${category}</div></div></aside><main class="main"><header class="page-header"><div class="heading"><div class="heading-title"><h1>&nbsp;</h1></div></div><span class="search ant-input-affix-wrapper"></span></header><div class="mobile-category-nav"></div><section class="tools-region"><div class="tools-viewport"><div class="tool-grid">${cards}</div></div><div class="pagination"><span class="loading-line"></span></div></section></main></div>`;
}
export function updateEntry(html,revision){
 // The crawlable directory stays available without JS, but never paints before React.
 const fallback=html.match(/<div class="seo-fallback">[\s\S]*?<\/main><\/div>/)?.[0];
 if(!fallback)throw Error('Missing SEO fallback directory');
 html=html.replace(/<div id="root">[\s\S]*?<\/noscript>/,`<div id="root">${homePlaceholder()}</div><noscript><link rel="stylesheet" href="assets/catalog-seo.css"><style>#root{display:none}</style>${fallback}</noscript>`);
 html=html.replace(/<link rel="stylesheet" href="assets\/catalog-seo\.css">\s*(?=<!-- pocket-seo:start -->)/,'');
 html=html.replace(/<link rel="stylesheet" href="assets\/home-react\/home\.css(?:\?[^"<>]*)?"\s*\/>/,`<link rel="stylesheet" href="assets/home-react/home.css?v=${revision}" />`);
 html=html.replace(/<script defer src="assets\/home-react\/home\.js(?:\?[^"<>]*)?"><\/script>/,`<script defer src="assets/home-react/home.js?v=${revision}"></script>`);
 return html;
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../toolbox-site');
 const manifest=JSON.parse(await readFile(path.join(root,'assets/home-react/manifest.json'),'utf8'));
 const revision=manifest.artifacts['home.js'].sha256.slice(0,12)+manifest.artifacts['home.css'].sha256.slice(0,8);
 const file=path.join(root,'index.html');await writeFile(file,updateEntry(await readFile(file,'utf8'),revision));
}
