# React homepage

React 19 and Ant Design 5 with Simplified Chinese locale. The catalog, local icon set and cloud usage module remain the canonical data sources. Comments use the configured D1 API.

Rebuild with Node.js 22 or later: `npm ci` then `npm run build`. Versions are pinned in package-lock.json. Default output is ../../toolbox-site/assets/home-react; set HOME_REACT_OUTPUT for another directory. The build records runtime hashes and copies the original notices of all bundled dependencies.

No CDN or runtime package installation is required.

The homepage uses Ant Design Button, Input, Card, Pagination, Empty, Spin, ConfigProvider and Drawer components. The Drawer provides the dialog focus trap and Escape handling. User comments render as plain React text. Only the fixed, local ToolboxIcons SVG paths are used as trusted HTML.

Run `./package-source.ps1` after building to create the deployable source ZIP and SHA-256 file manifest. The ZIP contains the pinned source, complete upstream license fallbacks, and required shared catalog/icon/usage sources; node_modules, Git metadata and credentials are excluded. `npm ci` and `npm run build` inside the extracted _scratch/home-react-integration directory reproduce the JS/CSS bytes. The homepage source is MIT; full bundled third-party notices are emitted to toolbox-site/licenses/home-react/THIRD-PARTY-NOTICES.txt.
