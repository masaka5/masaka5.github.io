import json, os, subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[3]
BASE = os.getenv('TOOLBOX_TEST_BASE', 'http://127.0.0.1:8765')
def catalog(text):
    return json.loads(text.split('const ToolboxCatalog = ', 1)[1].split(';\nif(typeof module', 1)[0])
current = catalog((ROOT/'toolbox-site/assets/catalog.js').read_text(encoding='utf-8'))
old = catalog(subprocess.check_output(['git','show','8e766839b9e8b6dc52d5fc0b0d531737d6e71610:assets/catalog.js'], cwd=ROOT/'_scratch/masaka5-toolbox-upstream').decode())
moved = []
assert current['categories'] == old['categories']
assert len(current['tools']) == len(old['tools']) == 1117
for before, after in zip(old['tools'], current['tools']):
    assert {**after, 'category':before['category']} == before, after['id']
    if before['category'] != after['category']: moved.append(after)

with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page(viewport={'width':1440,'height':900})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(BASE)
    page.wait_for_function("document.querySelectorAll('.tool-card').length === 1117")
    page.wait_for_timeout(500)
    seen = set()
    for group in current['categories']:
        gid = group['id']
        expected = {t['id'] for t in current['tools'] if t['category'] == gid}
        nav = page.locator(f'#categoryNav [data-category="{gid}"]')
        nav.click()
        expect(page.locator('#resultCount')).to_have_text(str(len(expected)))
        expect(nav.locator('.category-count')).to_have_text(str(len(expected)))
        actual = []
        while True:
            cards = page.locator('.tool-card:not([hidden])')
            rows = cards.evaluate_all('(cards)=>cards.map(c=>({id:c.dataset.tool,group:c.dataset.group}))')
            assert all(r['group'] == gid for r in rows)
            actual += [r['id'] for r in rows]
            if page.locator('#nextPage').is_disabled(): break
            page.locator('#nextPage').click()
        assert set(actual) == expected and len(actual) == len(expected), gid
        assert seen.isdisjoint(actual)
        seen.update(actual)
    assert len(seen) == 1117
    for tool in moved:
        card = page.locator(f'.tool-card[data-tool="{tool["id"]}"]')
        assert card.get_attribute('data-group') == tool['category']
        assert card.locator('.tool-link').get_attribute('href') == tool['href']
    tool = next(t for t in moved if t['id'] == 'svg-path-rounder')
    page.locator('#categoryNav [data-category="all"]').click()
    page.locator('#toolSearch').fill(tool['name'])
    card = page.locator(f'.tool-card[data-tool="{tool["id"]}"]')
    expect(card).to_be_visible()
    card.locator('.favorite-toggle').click()
    page.reload()
    expect(card.locator('.favorite-toggle')).to_have_attribute('aria-pressed','true')
    page.locator('#toolSearch').fill('')
    page.locator('#categoryNav [data-category="favorites"]').click()
    expect(card).to_be_visible()
    page.locator('#categoryNav [data-category="frontend"]').click()
    page.locator('#toolSearch').fill(tool['name'])
    expect(card).to_be_visible()
    card.locator('.tool-link').click()
    page.wait_for_url('**/'+tool['href']+'*')
    assert page.locator('body').inner_text().strip()
    page.go_back()
    page.locator('#toolSearch').fill('')
    page.locator('#categoryNav [data-category="all"]').click()
    for width, height in [(1440,900),(1920,1080),(390,844),(390,400)]:
        page.set_viewport_size({'width':width,'height':height})
        page.wait_for_timeout(150)
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight')
        if width >= 1440:
            assert page.locator('#toolGrid').evaluate("g=>getComputedStyle(g).gridTemplateColumns.split(' ').length") == (4 if width >= 1700 else 3)
        page.screenshot(path=str(ROOT/f'.superpowers/taxonomy-{width}-{height}.png'))
    assert not errors, errors
    b.close()
print(json.dumps({'tools':len(seen),'categories':len(current['categories']),'reclassified':len(moved),'identity_preserved':True,'pagination_search_favorites':True,'desktop_columns':4,'layouts':4}))
