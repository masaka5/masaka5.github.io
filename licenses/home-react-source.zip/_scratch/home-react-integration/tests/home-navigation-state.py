from playwright.sync_api import sync_playwright,expect
import json
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page(viewport={'width':1440,'height':900});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/')
 page.locator('[data-category="text"]').first.click()
 page.locator('#toolSearch').fill('文本')
 expect(page.locator('#nextPage')).to_be_enabled();page.locator('#nextPage').click()
 before={'query':page.locator('#toolSearch').input_value(),'page':page.locator('#pageStatus').inner_text(),'category':page.locator('#toolsHeading').inner_text()}
 link=page.locator('.tool-card:not([hidden]) .tool-link').first;href=link.get_attribute('href');link.click()
 page.wait_for_url('**/'+href+'*')
 page.go_back();expect(page.locator('#toolSearch')).to_have_value(before['query'])
 expect(page.locator('#toolsHeading')).to_have_text(before['category'])
 expect(page.locator('#pageStatus')).to_have_text(before['page'])
 page.go_forward();page.wait_for_url('**/'+href+'*')
 page.go_back();page.reload()
 expect(page.locator('#toolSearch')).to_have_value(before['query'])
 expect(page.locator('#pageStatus')).to_have_text(before['page'])
 page.locator('#commentsOpen').click();page.locator('#commentBody').fill('导航恢复草稿')
 page.reload();expect(page.get_by_role('dialog')).to_be_visible()
 expect(page.locator('#commentBody')).to_have_value('导航恢复草稿')
 page.locator('#commentsClose').click()
 page.set_viewport_size({'width':390,'height':844});page.reload()
 expect(page.locator('#toolSearch')).to_have_value(before['query'])
 expect(page.locator('#toolsHeading')).to_have_text(before['category'])
 assert page.locator('.tool-card:not([hidden])').count()>0
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight')
 assert not errors,errors
 print(json.dumps({'restored':before,'history':True,'refresh':True,'comments_draft_and_drawer':True,'mobile':True}));b.close()
