from playwright.sync_api import sync_playwright,expect
import json
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page()
 page.goto('http://127.0.0.1:8765/tools/tool/?id=base64-text')
 page.wait_for_function("document.querySelector('#mode').options.length>1")
 page.evaluate("history.replaceState({...history.state,unrelatedMarker:'preserve'},'')")
 page.locator('#mode').select_option('1');page.wait_for_function("new URL(location.href).searchParams.get('mode')==='1'")
 selected=page.locator('#workspace').get_attribute('data-source')
 page.go_back(wait_until='domcontentloaded');expect(page.locator('#mode')).to_have_value('0')
 page.go_forward(wait_until='domcontentloaded');expect(page.locator('#mode')).to_have_value('1')
 page.reload();expect(page.locator('#mode')).to_have_value('1')
 assert page.locator('#workspace').get_attribute('data-source')==selected
 assert page.evaluate('history.state.unrelatedMarker')=='preserve'
 print(json.dumps({'mode_history':True,'refresh':True,'other_history_state':True}));b.close()
