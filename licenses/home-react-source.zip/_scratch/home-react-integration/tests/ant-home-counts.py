import asyncio,json,os
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch()
  page=await browser.new_page(viewport={'width':1440,'height':900})
  posts=[];requests=[];state={'pinyin':1234,'whiteboard':0}
  await page.route('**/assets/usage-config.json',lambda r:r.fulfill(json={'endpoint':'https://counts.test'}))
  async def counts(r):
   if r.request.method=='POST':
    posts.append(r.request.url);await r.abort();return
   requests.append(r.request.url)
   await asyncio.sleep(1)
   await r.fulfill(json={'schema':1,'updatedAt':'2026-11-12T00:00:00Z','counts':state.copy()})
  await page.route('https://counts.test/**',counts)
  await page.goto(os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')+'/')
  await page.get_by_label('使用次数加载中').first.wait_for()
  count=page.locator('[data-tool=pinyin] .tool-usage')
  await page.get_by_label('累计使用 1,234 次',exact=True).wait_for()
  assert await count.inner_text()=='1,234'
  assert await count.locator('.ant-statistic').count()==1
  assert await count.locator('[data-icon=bar-chart]').count()==1
  await count.focus()
  await page.get_by_role('tooltip',name='累计使用 1,234 次').wait_for()
  for refreshed in [1234,1235]:
   state['pinyin']=refreshed;before=len(requests)
   await page.evaluate('dispatchEvent(new Event("online"))')
   await page.wait_for_function('document.activeElement?.classList.contains("tool-usage")')
   while len(requests)<=before:await page.wait_for_timeout(50)
   await page.wait_for_timeout(1200)
   assert await count.evaluate('e=>document.activeElement===e'),'count refresh moved keyboard focus'
   await page.get_by_role('tooltip',name=f'累计使用 {refreshed:,} 次').wait_for()
  url=page.url;await count.click();await page.wait_for_timeout(150)
  assert page.url==url and not posts
  await page.locator('[data-tool=pinyin] .favorite-toggle').click()
  await page.get_by_role('button',name='常用',exact=True).first.click()
  assert await page.locator('.tool-card:not([hidden])').count()==1
  await page.get_by_role('button',name='全部工具',exact=True).first.click()
  await page.locator('#toolSearch').fill('白板')
  zero=page.locator('[data-tool=whiteboard] .tool-usage')
  assert await zero.inner_text()=='0'
  await page.locator('#toolSearch').fill('')
  for w,h in [(1440,900),(390,844)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(200)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight')
   for c in await page.locator('.tool-card:not([hidden])').all():
    assert await c.locator('.tool-usage').is_visible()
    assert await c.evaluate('e=>{const u=e.querySelector(".tool-usage").getBoundingClientRect(),t=e.querySelector("h3").getBoundingClientRect();return u.top>=t.bottom&&u.right<=e.getBoundingClientRect().right}'),await c.evaluate('e=>({id:e.dataset.tool,u:e.querySelector(".tool-usage").getBoundingClientRect().toJSON(),t:e.querySelector("h3").getBoundingClientRect().toJSON()})')
  assert not posts
  await browser.close()
  print('PASS loading/zero/1234/Statistic/icon/keyboard tooltip/no POST/favorites/search/desktop+mobile bounds')
asyncio.run(main())
