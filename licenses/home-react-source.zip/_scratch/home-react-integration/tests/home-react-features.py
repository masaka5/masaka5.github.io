"""React component and interaction regressions; all cloud requests are isolated fixtures."""
import json,os,uuid
from playwright.sync_api import sync_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765').rstrip('/')
with sync_playwright() as p:
 b=p.chromium.launch();context=b.new_context(viewport={'width':1440,'height':900});page=context.new_page();errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/assets/usage-config.json',lambda r:r.fulfill(json={'endpoint':'https://react-test.invalid'}))
 page.route('https://react-test.invalid/counts',lambda r:r.fulfill(json={'schema':1,'updatedAt':'2026-11-12T00:00:00Z','counts':{}}))
 state={'hold':None,'posted':None}
 def comments(route):
  if route.request.method=='POST':
   data=json.loads(route.request.post_data);state['posted']={**data,'created':1794492684};route.fulfill(json={'accepted':True,'comment':state['posted']})
  else:
   state['hold']=route
 page.route('https://react-test.invalid/comments*',comments)
 page.goto(BASE);page.wait_for_function("document.querySelectorAll('.tool-card.ant-card').length===ToolboxCatalog.tools.length")
 assert page.locator('script[src="assets/home.js"]').count()==0
 assert page.locator('script[src="assets/comments.js"]').count()==0
 assert page.locator('.search.ant-input-affix-wrapper').count()==1
 assert page.locator('.ant-pagination').count()==1
 # Moving an already focused card through cloud ranking retains focus.
 page.locator('.tool-card:not([hidden]) .favorite-toggle').nth(1).focus()
 focused=page.evaluate('document.activeElement.closest(".tool-card").dataset.tool')
 page.evaluate('''id=>{localStorage.setItem('pocket-usage-cache-v1',JSON.stringify({schema:1,updatedAt:'2026-11-12T01:00:00Z',counts:{[id]:99}}));dispatchEvent(new StorageEvent('storage',{key:'pocket-usage-cache-v1'}));}''',focused)
 page.wait_for_function('(id)=>document.querySelector(".tool-card:not([hidden])").dataset.tool===id',arg=focused)
 assert page.evaluate('document.activeElement.closest(".tool-card").dataset.tool')==focused
 assert page.evaluate('document.activeElement.classList.contains("favorite-toggle")')
 page.keyboard.press('/');assert page.locator('#toolSearch').evaluate('(e)=>e===document.activeElement')
 page.locator('#toolSearch').fill('unfindable-tool-xxxxxxxx');assert page.locator('#emptyState').is_visible()
 page.keyboard.press('Escape');assert page.locator('#toolSearch').input_value()==''
 # A POST that finishes while the first list GET is in flight cannot be overwritten by that stale GET.
 page.locator('#commentsOpen').click();page.wait_for_timeout(50)
 page.locator('#commentName').fill('并发访客');page.locator('#commentBody').fill('并发保存 '+str(uuid.uuid4()));page.locator('#commentSubmit').click()
 page.wait_for_function("document.querySelector('#commentsStatus').textContent==='已发表'")
 assert state['hold'] is not None
 first=state['hold'];state['hold']=None;first.fulfill(json={'schema':1,'comments':[],'next':None})
 page.wait_for_timeout(100)
 assert state['hold'] is not None,'revision guard must request a fresh list'
 state['hold'].fulfill(json={'schema':1,'comments':[state['posted']],'next':None});state['hold']=None
 page.wait_for_function("document.querySelector('#commentsStatus').textContent===''")
 assert page.locator('#commentsList .comment-card').count()==1
 assert state['posted']['body'] in page.locator('#commentsList').inner_text()
 page.locator('#commentsClose').click();page.get_by_role('dialog').wait_for(state='hidden')
 page.set_viewport_size({'width':1440,'height':900});page.screenshot(path='_scratch/home-react-desktop.png')
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='_scratch/home-react-mobile.png')
 assert not errors,errors
 print(json.dumps({'actual_react_antd_tree':True,'ranking_focus_restored':True,'search_keyboard_empty':True,'concurrent_comment_revision_guard':True,'errors':errors}));b.close()
