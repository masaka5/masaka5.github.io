import React from 'react';
import {Statistic,Tooltip} from 'antd';
import {BarChartOutlined} from '@ant-design/icons';

export default function UsageCount({count}){
 const label=count===undefined?'使用次数加载中':`累计使用 ${count.toLocaleString('zh-CN')} 次`;
 return <Tooltip title={label} trigger={['hover','focus']}><span className="tool-usage" tabIndex={0} aria-label={label} onClick={event=>{event.preventDefault();event.stopPropagation();}}><BarChartOutlined aria-hidden="true"/><Statistic value={count===undefined?'—':count} formatter={()=>count===undefined?'—':count.toLocaleString('zh-CN')}/></span></Tooltip>;
}
