const key='pocket-home-view-v1',field='pocketToolboxView';
function storage(){try{return JSON.parse(sessionStorage.getItem(key)||'{}');}catch{return {};}}
export function readView(){let data;try{data=history.state?.[field]??storage();}catch{data=storage();}return data&&data.schema===1?data:{schema:1};}
export function writeView(patch){const next={...readView(),...patch,schema:1};try{history.replaceState({...history.state,[field]:next},'');}catch{}try{sessionStorage.setItem(key,JSON.stringify(next));}catch{}}
export function validHome(value,groups){const data=value?.home||{};return {category:groups.some(g=>g.id===data.category)?data.category:'all',query:typeof data.query==='string'?data.query.slice(0,2000):'',page:Number.isSafeInteger(data.page)&&data.page>0?data.page:1,capacity:Number.isSafeInteger(data.capacity)&&data.capacity>0&&data.capacity<1000?data.capacity:1,navTop:Math.max(0,Number(data.navTop)||0)};}
