import {mkdir,readdir,copyFile,readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
const root=dirname(fileURLToPath(import.meta.url)),target=resolve(root,'../../toolbox-site/tools/archives');
await mkdir(target,{recursive:true});
const files=[];
for(const name of (await readdir(join(root,'src'))).sort()){
 const data=await readFile(join(root,'src',name));await copyFile(join(root,'src',name),join(target,name));
 files.push({file:name,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});
}
await writeFile(join(target,'manifest.json'),JSON.stringify({name:'本地压缩工具',version:'1.0.0',license:'MIT (integration only)',source:'../../licenses/archive-source.zip',sharedRuntime:'../../vendor/7z-wasm/manifest.json',engine:'7z-wasm 1.2.0 / 7-Zip 24.09',files},null,2)+'\n');
console.log('Built '+files.length+' native ES module assets; shared WASM is not duplicated.');
