# 本地压缩工具

中文、白灰蓝的浏览器压缩工作区，使用同源 7z-wasm 1.2.0 / 7-Zip 24.09。所有压缩与解压运行在独立 Worker；操作结束或取消时强制终止 Worker，回收 WASM 实例。没有账号、广告、上传、遥测或外部运行时请求。

## 构建

Node.js 22+。此集成没有 npm 依赖，锁文件仍保留以便审计。

```powershell
cd _scratch/archive-integration
npm ci
npm test
npm run build
npm audit --omit=dev
```

源码在 `src/`，构建复制到 `toolbox-site/tools/archives/`，并生成每文件 SHA-256 manifest。运行时以相对路径共享 `toolbox-site/vendor/7z-wasm/`，不重复分发 WASM。若单独部署，应同时保持 `assets/`、`vendor/7z-wasm/` 与 `licenses/` 的相对关系。请经 HTTP(S) 运行，不能从 file:// 加载模块 Worker。

## 能力矩阵

| 格式 | 目录/提取/校验 | 创建/重打包 | 密码 |
|---|---|---|---|
| 7z | 已真实测试 | 已真实测试 | AES，包含加密文件名，已测试错误/正确/改密码 |
| ZIP | 已真实测试 | 已真实测试 | AES-256 创建，密码限英文数字和半角符号；第三方工具兼容性取决于 AES 支持 |
| TAR | 已真实测试 | 已真实测试 | 不支持 |
| GZIP | 已真实测试 | 单文件，已真实测试 | 不支持 |
| BZIP2 | 已真实测试 | 单文件，已真实测试 | 不支持 |
| XZ | 已真实测试 | 单文件，已真实测试 | 不支持 |
| RAR | 已使用 libarchive 上游 RAR 样例真实验证目录、提取与校验；并非全部 RAR 变体 | 不提供原格式创建 | 视引擎支持 |
| ISO、WIM 等 | 引擎可读格式可尝试；本工具未逐一验证 | 不提供原格式创建 | 视引擎支持 |

目录导航、名称/大小/压缩大小/属性/修改时间排序、筛选、单文件下载、目录递归提取、批量 ZIP、可选 File System Access 目录保存、添加文件/目录、标记删除并重打包、修改输出密码。输入原文件始终保持不变。重打包可转换为上表支持的输出格式。

## 测试

在仓库根目录运行静态服务器 `python -m http.server 8765 --directory toolbox-site` 后，另一个终端执行：

```powershell
node --test _scratch/ops-tests/archive-core.test.mjs
python _scratch/ops-tests/archive-browser.py
python _scratch/ops-tests/archive-ui.py
python _scratch/ops-tests/archive-bounds.py
python _scratch/ops-tests/archive-rar-browser.py
```

Python 浏览器测试依赖本机 Playwright 与 Chromium。真实测试包括六种格式 Unicode 内容往返、7z 加密头/密码成功错误/改密码、目录选择 ZIP、添加/替换/删除重打包、嵌套删除不恢复、标删后代不提取、损坏包、取消后 Worker 恢复。UI 测试创建加密 7z，下载再导入，提取、校验，检查 1440×900、390×844、320×568、844×390、390×400 无文档滚动、无外部请求与 JS 错误。bounds 测试将 257 MiB 零数据压缩为约 210 字节 BZIP2，在大小未知的解压过程中验证拒绝并恢复。

## 安全与限制

输入压缩包、添加文件合计、所选展开内容各 256 MiB，目录最多 10000 项；工作区文件与输出写入另有 512 MiB 总预算。FS.write、MEMFS stream write、truncate 在增长前检查预算。浏览器/WASM/文件副本和压缩字典仍会占用额外内存，因此设备可用内存少时可能更早失败。不是超大文件流式方案，也没有桌面 Shell 集成、多卷、SFX、后台任务或完整桌面 7-Zip 功能。

拒绝绝对路径、路径穿越、反斜线、控制符、Windows 保留名、不兼容文件名、重复/歧义目录、符号/硬链接以及文件/目录冲突；条目始终以 textContent 显示，精确路径提取禁用通配符。某些包含特殊文件名的合法归档也会被拒绝，而不是危险地纠正路径。BZIP2/XZ 不保存原文件名时显示“解压文件”，BZIP2 目录原大小未知。Solid 7z 部分文件压缩大小显示“—”。同名输出目录文件可能覆盖，目录保存前原生选择器会请求授权。压缩包校验与引擎错误不会写入原包。

## 许可

集成代码 MIT，见 LICENSE。共享未修改 7z-wasm 引擎适用 LGPL-2.1-or-later 及 unRAR 限制。许可证和准确来源在 `toolbox-site/vendor/7z-wasm/`；完整上游源码包在 `toolbox-site/licenses/7z-wasm-source.zip`。修改此集成不改变上游许可。
