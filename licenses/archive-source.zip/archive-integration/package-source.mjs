import {createHash} from 'node:crypto';
import {readdir,readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,resolve,join} from 'node:path';
import factory from '../../toolbox-site/vendor/7z-wasm/7zz.mjs';
const root=dirname(fileURLToPath(import.meta.url)),z=await factory({print:()=>{},printErr:()=>{}}),files=[];
function dirs(path){let current='';for(const part of path.split('/').filter(Boolean)){current+='/'+part;try{z.FS.mkdir(current);}catch{}}}
async function add(disk,path){const data=await readFile(disk);dirs(path.split('/').slice(0,-1).join('/'));z.FS.writeFile('/'+path,data);files.push({file:path,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});}
for(const name of ['package.json','package-lock.json','build.mjs','package-source.mjs','verify.mjs','README.md','LICENSE'])await add(join(root,name),'archive-integration/'+name);
for(const name of await readdir(join(root,'src')))await add(join(root,'src',name),'archive-integration/src/'+name);
for(const name of (await readdir(resolve(root,'../ops-tests'))).filter(n=>n.startsWith('archive-')))await add(resolve(root,'../ops-tests',name),'ops-tests/'+name);
for(const name of ['LICENSE.txt','SOURCE.txt','unRarLicense.txt','manifest.json'])await add(resolve(root,'../../toolbox-site/vendor/7z-wasm',name),'shared-runtime-notices/'+name);
const code=z.callMain(['a','-tzip','-bd','-y','/source.zip','/archive-integration','/ops-tests','/shared-runtime-notices']);if(code!==0)throw Error('source zip error '+code);
const zip=z.FS.readFile('/source.zip'),target=resolve(root,'../../toolbox-site/licenses');await writeFile(join(target,'archive-source.zip'),zip);
await writeFile(join(target,'archive-manifest.json'),JSON.stringify({version:'1.0.0',source:'archive-source.zip',bytes:zip.length,sha256:createHash('sha256').update(zip).digest('hex'),upstreamSource:'7z-wasm-source.zip',runtime:'../vendor/7z-wasm/manifest.json',files},null,2)+'\n');console.log('Packaged source ZIP: '+zip.length+' bytes, '+files.length+' files');
