import {readFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {dirname,resolve,join} from 'node:path';
const root=dirname(fileURLToPath(import.meta.url)),site=resolve(root,'../../toolbox-site'),hash=data=>createHash('sha256').update(data).digest('hex');
const manifest=JSON.parse(await readFile(join(site,'tools/archives/manifest.json')));
for(const f of manifest.files){const run=await readFile(join(site,'tools/archives',f.file)),source=await readFile(join(root,'src',f.file));if(hash(run)!==f.sha256||!run.equals(source))throw Error('Source/runtime hash mismatch: '+f.file);}
const source=JSON.parse(await readFile(join(site,'licenses/archive-manifest.json'))),zip=await readFile(join(site,'licenses/archive-source.zip'));
if(hash(zip)!==source.sha256)throw Error('Source ZIP hash mismatch');
console.log(JSON.stringify({assets:manifest.files.length,sourceMatchesRuntime:true,sourceZIP:zip.length,sourceZIPHash:true,runtimeDuplicated:(await readdir(join(site,'tools/archives'))).some(n=>n.endsWith('.wasm'))}));
