"""Verify real third-party RAR fixture using the actual WASM engine."""
import asyncio,base64,binascii,json,os,urllib.request
from playwright.async_api import async_playwright

URL='https://raw.githubusercontent.com/libarchive/libarchive/master/libarchive/test/test_read_format_rar.rar.uu'
lines=urllib.request.urlopen(URL,timeout=30).read().splitlines()
start=next(i for i,line in enumerate(lines)if line.startswith(b'begin '))
payload=b''.join(binascii.a2b_uu(line)for line in lines[start+1:]if line not in (b'`',b'end',b''))
async def main():
 async with async_playwright()as p:
  b=await p.chromium.launch();page=await b.new_page()
  await page.goto(os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')+'/tools/archives/')
  result=await page.evaluate('''async encoded=>{
   const {ArchiveEngine}=await import('./archive-engine.mjs'),engine=new ArchiveEngine();
   const blob=new Blob([Uint8Array.from(atob(encoded),c=>c.charCodeAt(0))]);
   const info=await engine.run('list',{blob});
   if(info.format!=='rar'||!info.entries.length)throw Error('RAR listing failed');
   const file=info.entries.find(e=>!e.directory);
   const extracted=await engine.run('extract',{blob,paths:[file.path]});
   if(!extracted[0].blob.size)throw Error('RAR extraction empty');
   if(!(await engine.run('test',{blob})).ok)throw Error('RAR integrity failed');
   return {format:info.format,entries:info.entries.length,extracted:file.path,bytes:extracted[0].blob.size,integrity:true};
  }''',base64.b64encode(payload).decode())
  print(json.dumps(result));await b.close()
asyncio.run(main())
