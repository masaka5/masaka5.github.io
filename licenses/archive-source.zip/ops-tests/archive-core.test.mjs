import test from 'node:test';
import assert from 'node:assert/strict';
let core;
try { core = await import('../../toolbox-site/tools/archives/archive-core.mjs'); } catch {}
test('安全路径拒绝穿越、系统保留名、控制符和绝对路径', () => {
  assert.ok(core, '压缩工具安全核心尚未实现');
  for (const path of ['../a','a/../b','/a','C:/a','a\\b','a\nPath = x','CON','a/NUL.txt','@list','a//b','a.','a:b']) assert.throws(() => core.safePath(path), path);
  assert.equal(core.safePath('资料/报告 [1].txt'), '资料/报告 [1].txt');
});
test('目录解析保留压缩大小、加密属性并拒绝重复和歧义记录', () => {
  assert.ok(core);
  const input='Type = 7z\n----------\nPath = 资料/a.txt\nSize = 3\nPacked Size = 8\nAttributes = A\nEncrypted = +\n\nPath = 空目录\nSize = 0\nAttributes = D\n';
  const entries=core.parseListing(input);
  assert.equal(entries[0].packed,8);assert.equal(entries[0].encrypted,true);assert.equal(entries[1].directory,true);
  assert.throws(()=>core.parseListing(input+'\nPath = 资料/a.txt\nSize = 0\n'));
  assert.throws(()=>core.parseListing('----------\nPath = ../oops\nSize = 0\n'));
});
test('目录选择展开仅包含存在的后代、拒绝链接与超出预算', () => {
  assert.ok(core);
  const entries=[{path:'folder',directory:true,size:0},{path:'folder/a',size:4},{path:'folder/b',size:8},{path:'other',size:2}];
  assert.deepEqual(core.selectEntries(entries,['folder']).map(e=>e.path),['folder','folder/a','folder/b']);
  assert.throws(()=>core.selectEntries(entries,['missing']));
  assert.throws(()=>core.selectEntries([{path:'link',symlink:true,size:1}],['link']));
  assert.throws(()=>core.checkBudget(256*1024*1024+1));
});
