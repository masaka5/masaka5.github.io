import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True);page=await b.new_page()
  await page.goto(BASE+'/tools/archives/')
  result=await page.evaluate('''async()=>{
   const {ArchiveEngine}=await import('./archive-engine.mjs'),e=new ArchiveEngine(),r={};
   const assert=(x,m)=>{if(!x)throw Error(m)},fail=async(f,m)=>{let yes=false;try{await f()}catch{yes=true}assert(yes,m)};
   for(const format of ['zip','7z','tar','gzip','bzip2','xz']) {
    const single=['gzip','bzip2','xz'].includes(format),path=single?'hello.txt':'资料/hello.txt';
    const entries=[{path,blob:new Blob(['hello 世界'])},...single?[]:[{path:'空目录',directory:true},{path:'资料/second.txt',blob:new Blob(['two'])}]];
    const blob=await e.run('create',{format,entries});
    const info=await e.run('list',{blob});assert(info.entries.some(x=>!x.directory),'list '+format);
    const target=info.entries.find(x=>!x.directory).path;
    const out=await e.run('extract',{blob,paths:[single?target:'资料']});
    assert(await out.find(x=>x.blob).blob.text()==='hello 世界','roundtrip '+format);
    assert((await e.run('test',{blob})).ok,'integrity '+format);
    r[format]={bytes:blob.size,entries:info.entries.length,roundtrip:true};
    if(format==='zip')window.archiveFixture=blob;
   }
   const secured=await e.run('create',{format:'7z',password:'密码123',entries:[{path:'secret.txt',blob:new Blob(['secret'])}]});
   await fail(()=>e.run('list',{blob:secured,password:'wrong'}),'wrong password');
   assert((await e.run('list',{blob:secured,password:'密码123'})).entries[0].encrypted,'encrypted header');
   assert(await (await e.run('extract',{blob:secured,password:'密码123',paths:['secret.txt']}))[0].blob.text()==='secret','password bytes');
   const changed=await e.run('repack',{blob:secured,password:'密码123',newPassword:'new',format:'7z',remove:['secret.txt'],entries:[{path:'added.txt',blob:new Blob(['added'])}]});
   const after=await e.run('list',{blob:changed,password:'new'});assert(after.entries.length===1&&after.entries[0].path==='added.txt','add delete repack');
   await fail(()=>e.run('list',{blob:changed,password:'密码123'}),'old password');
   await fail(()=>e.run('create',{format:'zip',password:'中文密码',entries:[{path:'a.txt',blob:new Blob(['x'])}]}),'ZIP nonascii unsupported');
   const aesZip=await e.run('create',{format:'zip',password:'zip-secret',entries:[{path:'a.txt',blob:new Blob(['AES bytes'])}]});
   await fail(()=>e.run('extract',{blob:aesZip,password:'bad',paths:['a.txt']}),'ZIP wrong password');
   assert(await (await e.run('extract',{blob:aesZip,password:'zip-secret',paths:['a.txt']}))[0].blob.text()==='AES bytes','ZIP AES password');
   const zipped=await e.run('extract',{blob:archiveFixture,paths:['资料'],bundle:true});
   assert((await e.run('list',{blob:zipped})).entries.filter(x=>!x.directory).length===2,'folder ZIP');
   const deletedNested=await e.run('repack',{blob:archiveFixture,format:'zip',newPassword:'',remove:['资料/hello.txt'],entries:[]});
   assert(!(await e.run('list',{blob:deletedNested})).entries.some(x=>x.path==='资料/hello.txt'),'nested delete must not return via parent selection');
   const excluded=await e.run('extract',{blob:archiveFixture,paths:['资料'],exclude:['资料/hello.txt']});
   assert(!excluded.some(x=>x.path==='资料/hello.txt')&&excluded.some(x=>x.path==='资料/second.txt'),'directory extraction honors marked removal');
   await fail(()=>e.run('list',{blob:new Blob(['corrupt'])}),'corrupt');
   await fail(()=>e.run('create',{format:'zip',entries:[{path:'../escape',blob:new Blob(['x'])}]}),'path escape');
   const pending=e.run('list',{blob:archiveFixture});e.cancel();await fail(()=>pending,'cancel');
   assert((await e.run('list',{blob:archiveFixture})).entries.length>0,'worker recovery');
   return {...r,password:true,repack:true,directory_extract:true,corrupt:true,cancel_recovery:true};
  }''')
  print(json.dumps(result,ensure_ascii=False));await b.close()
asyncio.run(main())
