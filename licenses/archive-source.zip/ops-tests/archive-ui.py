import asyncio,json,os
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page();errors=[];external=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:external.append(r.url) if not r.url.startswith(BASE) and not r.url.startswith('blob:') else None)
  await page.goto(BASE+'/tools/archives/');assert await page.locator('h1').inner_text()=='压缩工具'
  await page.locator('#addFiles').set_input_files([{'name':'中文.txt','mimeType':'text/plain','buffer':'实际压缩'.encode()},{'name':'other.txt','mimeType':'text/plain','buffer':b'other'}])
  await page.locator('#format').select_option('7z');await page.locator('#newPassword').fill('密码123')
  await page.locator('#create').click();await page.locator('#download').wait_for(state='visible',timeout=90000)
  async with page.expect_download() as download:await page.locator('#download').click()
  downloaded=await download.value;path=await downloaded.path()
  await page.locator('#readPassword').fill('密码123');await page.locator('#archiveFile').set_input_files(path)
  await page.locator('#rows tr').first.wait_for(timeout=90000);assert '中文.txt' in await page.locator('#rows').inner_text()
  await page.locator('#selectAll').check();assert await page.locator('#extractZip').is_enabled()
  await page.locator('#extractZip').click();await page.wait_for_function("()=>!document.querySelector('#cancel').hidden",timeout=5000)
  await page.wait_for_function("()=>document.querySelector('#cancel').hidden",timeout=90000)
  await page.locator('#integrity').click();await page.wait_for_function("()=>document.querySelector('#status').textContent.includes('校验通过')",timeout=90000)
  for w,h in [(1440,900),(390,844),(320,568),(844,390),(390,400)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(50)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight'),(w,h)
   assert await page.locator('#open').is_visible()
  await page.set_viewport_size({'width':1440,'height':900});await page.screenshot(path='_scratch/archive-desktop.png')
  await page.set_viewport_size({'width':390,'height':844});await page.screenshot(path='_scratch/archive-mobile.png')
  assert not errors,errors;assert not external,external
  print(json.dumps({'real_ui_roundtrip':True,'encrypted_7z':True,'integrity':True,'layouts':5,'external_requests':external,'errors':errors}));await b.close()
asyncio.run(main())
