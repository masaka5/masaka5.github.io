import asyncio,json,os,bz2
from playwright.async_api import async_playwright
BASE=os.getenv('TOOLBOX_TEST_BASE','http://127.0.0.1:8765')
async def main():
 fixture=bz2.compress(bytes(257*1024*1024))
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page();await page.goto(BASE+'/tools/archives/')
  result=await page.evaluate('''async data=>{
   const {ArchiveEngine}=await import('./archive-engine.mjs'),e=new ArchiveEngine(),blob=new Blob([new Uint8Array(data)]);
   const info=await e.run('list',{blob});let error='';
   try{await e.run('extract',{blob,paths:info.entries.map(x=>x.path)})}catch(e){error=e.message}
   if(!error.includes('上限')&&!error.includes('预算'))throw Error('解压炸弹未以预算错误拒绝：'+error);
   const normal=await e.run('create',{format:'zip',entries:[{path:'ok',blob:new Blob(['ok'])}]});
   if(!(await e.run('list',{blob:normal})).entries.length)throw Error('预算错误后worker未恢复');
   return {compressed:blob.size,unpackedMiB:257,rejected:error,recovery:true};
  }''',list(fixture))
  print(json.dumps(result,ensure_ascii=False));await b.close()
asyncio.run(main())
