import asyncio,json,threading,http.server,functools,os,re
from pathlib import Path
from io import BytesIO
from PIL import Image,ImageOps
from playwright.async_api import async_playwright,expect
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
FIX=HERE/'fixtures';FIX.mkdir(exist_ok=True)
im=Image.new('RGB',(6,4));im.putdata([(x*40,y*60,80) for y in range(4) for x in range(6)])
for fmt in ['PNG','JPEG','GIF','TIFF','BMP','WEBP']:
 kw={'lossless':True} if fmt=='WEBP' else {}
 if fmt=='JPEG':
  ex=Image.Exif();ex[271]='Independent fixture';kw['exif']=ex
 im.save(FIX/('grid.'+fmt.lower()),format=fmt,**kw)
im.save(FIX/'animated.gif',save_all=True,append_images=[Image.new('RGB',im.size,'red')],duration=[100,200],loop=0)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
class Server(http.server.ThreadingHTTPServer):
 def handle_error(self,request,address):
  import sys
  if not isinstance(sys.exc_info()[1],(ConnectionResetError,ConnectionAbortedError,BrokenPipeError)):super().handle_error(request,address)
server=Server(('127.0.0.1',8876),functools.partial(Quiet,directory=str(ROOT/'toolbox-site')))
threading.Thread(target=server.serve_forever,daemon=True).start()
URL='http://127.0.0.1:8876/tools/image-viewer/'
async def delayed(route):
 await asyncio.sleep(.8)
 try:await route.continue_()
 except:pass
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch();page=await b.new_page(viewport={'width':1440,'height':900});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  await page.add_init_script('''window.resources={workers:0,urls:0}; const W=window.Worker;window.Worker=class extends W{constructor(...a){super(...a);resources.workers++;this.alive=true}terminate(){if(this.alive){resources.workers--;this.alive=false}super.terminate()}}; const c=URL.createObjectURL,r=URL.revokeObjectURL;URL.createObjectURL=function(...a){resources.urls++;return c.apply(this,a)};URL.revokeObjectURL=function(...a){resources.urls--;return r.apply(this,a)}''')
  response=await page.goto(URL);assert response.status==200,'image viewer entry must exist (RED)'
  await expect(page.get_by_role('button',name='打开图片',exact=True)).to_be_visible()
  matrix={}
  for fmt in ['png','jpeg','gif','tiff','bmp','webp']:
   await page.locator('#files').set_input_files(str(FIX/('grid.'+fmt)))
   await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000)
   matrix[fmt]='decoded 6x4'
  await page.locator('#files').set_input_files(str(FIX/'grid.png'))
  await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4')
  canvas=page.locator('canvas');box=await canvas.bounding_box();await canvas.click(position={'x':box['width']/12,'y':box['height']/8})
  await expect(page.locator('[data-testid=pixel]')).to_contain_text('0, 0, 80, 255')
  for fmt in ['PNG','JPEG','WebP','GIF','TIFF','BMP']:
   await page.locator('.ant-select[aria-label="导出格式"]').click();await page.locator('.ant-select-item-option').filter(has_text=fmt).click()
   await page.get_by_role('button',name='生成导出',exact=True).click()
   await expect(page.get_by_role('button',name=re.compile('下载$')).first).to_be_enabled(timeout=60000)
   async with page.expect_download() as ev:await page.get_by_role('button',name=re.compile('下载$')).first.click()
   data=Path(await(await ev.value).path()).read_bytes();out=Image.open(BytesIO(data));assert out.size==(6,4),(fmt,out.size)
   assert out.format==fmt.upper().replace('JPG','JPEG'),(fmt,out.format)
   await page.locator('#files').set_input_files({'name':'roundtrip.'+fmt.lower(),'mimeType':'application/octet-stream','buffer':data})
   await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000)
   matrix[fmt]='export/Pillow decode/reimport'
  await page.locator('#files').set_input_files(str(FIX/'grid.png'));await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4')
  await page.get_by_role('button',name='顺时针旋转',exact=True).click();await expect(page.locator('[data-testid=dimensions]')).to_have_text('4 × 6')
  for label,value in [('裁剪 X',1),('裁剪 Y',1),('裁剪宽',2),('裁剪高',3)]:await page.get_by_label(label,exact=True).fill(str(value))
  await page.get_by_role('button',name='应用裁剪',exact=True).click();await expect(page.locator('[data-testid=dimensions]')).to_have_text('2 × 3')
  await page.locator('.ant-select[aria-label="导出格式"]').click();await page.locator('.ant-select-item-option').filter(has_text='PNG').click();await page.get_by_role('button',name='生成导出',exact=True).click()
  async with page.expect_download() as ev:await page.get_by_role('button',name=re.compile('下载$')).first.click()
  transformed=Path(await(await ev.value).path()).read_bytes();expected=im.transpose(Image.Transpose.ROTATE_270).crop((1,1,3,4))
  assert Image.open(BytesIO(transformed)).convert('RGB').tobytes()==expected.tobytes()
  await page.wait_for_timeout(500);await page.reload();await expect(page.locator('[data-testid=dimensions]')).to_have_text('2 × 3',timeout=60000)
  await expect(page.get_by_role('button',name=re.compile('下载$')).first).to_be_enabled();assert await page.locator('.export-row').count()>0
  # Completed bytes remain downloadable after refresh; view restoration does not generate exports.
  async with page.expect_download() as ev:await page.get_by_role('button',name=re.compile('下载$')).first.click()
  assert Path(await(await ev.value).path()).read_bytes()==transformed
  await page.get_by_role('button',name='100%',exact=True).click();await page.get_by_role('button',name='放大',exact=True).click()
  await page.wait_for_timeout(200);await page.reload();await expect(page.locator('[data-testid=dimensions]')).to_have_text('2 × 3',timeout=60000)
  assert await page.locator('canvas').evaluate('e=>e.getBoundingClientRect().width')==2.5
  await page.goto(URL+'?away=1');await page.go_back();await expect(page.locator('[data-testid=dimensions]')).to_have_text('2 × 3',timeout=60000)
  await page.locator('#files').set_input_files(str(FIX/'grid.jpeg'));await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4')
  await expect(page.get_by_text('Independent fixture',exact=True)).to_be_visible()
  await page.locator('#files').set_input_files(str(FIX/'grid.png'));await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4')
  await page.get_by_role('button',name='水平翻转',exact=True).click();await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4')
  await page.get_by_role('button',name='生成导出',exact=True).click()
  async with page.expect_download() as ev:await page.get_by_role('button',name=re.compile('下载$')).first.click()
  assert Image.open(BytesIO(Path(await(await ev.value).path()).read_bytes())).convert('RGB').tobytes()==ImageOps.mirror(im).tobytes()
  await page.get_by_label('宽度',exact=True).fill('3');await page.get_by_label('高度',exact=True).fill('2');await page.get_by_role('button',name='应用尺寸',exact=True).click();await expect(page.locator('[data-testid=dimensions]')).to_have_text('3 × 2')
  await page.locator('#files').set_input_files(str(FIX/'animated.gif'));await expect(page.get_by_label('动画帧')).to_have_value('1',timeout=60000)
  await page.get_by_label('动画帧').fill('2');await page.get_by_label('动画帧').press('Enter');await page.wait_for_timeout(600)
  assert await page.locator('[data-testid=frames]').inner_text()=='2 帧'
  box=await canvas.bounding_box();await canvas.click(position={'x':box['width']/2,'y':box['height']/2});await expect(page.locator('[data-testid=pixel]')).to_contain_text('255, 0, 0, 255')
  await page.locator('#files').set_input_files([str(FIX/'grid.png'),str(FIX/'grid.tiff')]);await expect(page.locator('.thumb img')).to_have_count(2,timeout=60000)
  await page.keyboard.press('ArrowRight');await expect(page.locator('.thumb.selected')).to_have_attribute('title','grid.tiff')
  await page.get_by_label('幻灯间隔',exact=True).fill('1');await page.get_by_role('button',name=re.compile('幻灯片$')).click();await expect(page.locator('.thumb.selected')).to_have_attribute('title','grid.png',timeout=4000);await page.get_by_role('button',name=re.compile('停止幻灯$')).click()
  await page.get_by_role('button',name='全屏',exact=True).click();await page.wait_for_function('!!document.fullscreenElement');await page.get_by_role('button',name='全屏',exact=True).click();await page.wait_for_function('!document.fullscreenElement')
  for i in range(8):await page.get_by_role('button',name='下一张',exact=True).click()
  await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000)
  await page.wait_for_function('resources.workers===0');assert (await page.evaluate('resources.urls'))==2
  for w,h in [(1440,900),(1280,720),(1024,768),(768,1024),(390,844),(320,568)]:
   await page.set_viewport_size({'width':w,'height':h});await page.wait_for_timeout(150)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth && document.documentElement.scrollHeight<=innerHeight'),(w,h)
   await expect(page.get_by_role('button',name='打开图片',exact=True)).to_be_in_viewport()
   if w<600:
    await page.locator('.toolbar').evaluate('e=>e.scrollLeft=e.scrollWidth');await expect(page.get_by_role('button',name='调整',exact=True)).to_be_in_viewport();await page.get_by_role('button',name='调整',exact=True).click();await expect(page.locator('.ant-drawer').get_by_role('button',name='生成导出',exact=True)).to_be_visible();await page.get_by_role('button',name='Close',exact=True).click();await page.wait_for_timeout(400);await page.locator('.toolbar').evaluate('e=>e.scrollLeft=0')
   await page.screenshot(path=str(HERE/f'viewport-{w}.png'))
  await page.set_viewport_size({'width':1440,'height':900})
  await page.get_by_role('switch',name='刷新后恢复',exact=True).click()
  await page.locator('#files').set_input_files(str(FIX/'grid.png'));await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4')
  await page.reload();await expect(page.locator('.thumb')).to_have_count(0)
  await page.locator('#files').set_input_files({'name':'broken.png','mimeType':'image/png','buffer':b'not an image'});await expect(page.get_by_role('alert')).to_be_visible(timeout=60000)
  oversized=BytesIO();Image.new('RGB',(4097,4097)).save(oversized,'PNG');await page.locator('#files').set_input_files({'name':'oversized.png','mimeType':'image/png','buffer':oversized.getvalue()});await expect(page.get_by_role('alert')).to_contain_text('像素限制',timeout=60000)
  await page.get_by_role('button',name='清空',exact=True).click();await page.reload();await expect(page.locator('.thumb')).to_have_count(0)
  await page.get_by_role('switch',name='刷新后恢复',exact=True).click()
  # Folder input uses actual File bytes and can be selected independently in gallery.
  await page.locator('#folder').set_input_files(str(FIX));await expect(page.locator('.thumb')).to_have_count(7);await expect(page.locator('.thumb img')).to_have_count(7,timeout=60000)
  # Cancel a real image worker while its WASM request is delayed, then recover.
  await page.context.route('**/magick-DgWW1YxY.wasm',lambda route:asyncio.create_task(delayed(route)))
  await page.locator('#files').set_input_files(str(FIX/'grid.png'));await page.get_by_role('button',name='取消',exact=True).click();await page.wait_for_timeout(150)
  assert (await page.evaluate('resources.workers'))<=1
  await page.context.unroute('**/magick-DgWW1YxY.wasm')
  await page.locator('#files').set_input_files(str(FIX/'grid.png'));await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000)
  await page.get_by_role('button',name='清空',exact=True).click();await page.wait_for_timeout(300)
  assert await page.evaluate('resources.workers===0 && resources.urls===0')
  await page.reload();await expect(page.locator('.thumb')).to_have_count(0)
  # Viewing must survive a disabled database and disabled localStorage.
  isolated=await b.new_page();await isolated.add_init_script('''Object.defineProperty(window,'indexedDB',{get(){throw new DOMException('disabled','SecurityError')}});Object.defineProperty(window,'localStorage',{get(){throw new DOMException('disabled','SecurityError')}})''')
  await isolated.goto(URL);await expect(isolated.get_by_role('button',name='打开图片',exact=True)).to_be_enabled()
  await isolated.locator('#files').set_input_files(str(FIX/'grid.png'));await expect(isolated.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000)
  await isolated.close()
  # Quota failure must not discard the currently displayed image.
  quota=await b.new_page();await quota.add_init_script('''IDBObjectStore.prototype.put=function(){throw new DOMException('full','QuotaExceededError')}''');await quota.goto(URL);await quota.locator('#files').set_input_files(str(FIX/'grid.png'));await expect(quota.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000);await expect(quota.get_by_role('alert')).to_contain_text('缓存不可用');await quota.close()
  assert not errors,errors
  print(json.dumps({'matrix':matrix,'transforms':'independent exact pixels','refresh':'actual selected File and transforms/export restored','viewports':6,'errors':errors},ensure_ascii=False))
  await b.close()
asyncio.run(main())
