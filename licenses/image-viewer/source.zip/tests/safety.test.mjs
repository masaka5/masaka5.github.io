import test from 'node:test';
import assert from 'node:assert/strict';
import * as formats from '../src/formats.js';
import {dxfSvg} from '../src/vector.js';
import {gzipSync,deflateSync} from 'node:zlib';
import * as safePng from '../src/safe-png.js';
function png(width,height,frames=1,rect=[width,height,0,0]){
 const chunk=(type,data)=>{const b=Buffer.alloc(data.length+12);b.writeUInt32BE(data.length);b.write(type,4);data.copy(b,8);return b;};
 const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(width);ihdr.writeUInt32BE(height,4);
 const actl=Buffer.alloc(8);actl.writeUInt32BE(frames);
 const fctl=Buffer.alloc(26);rect.forEach((n,i)=>fctl.writeUInt32BE(n,4+i*4));
 return new Uint8Array(Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ihdr),chunk('acTL',actl),...Array.from({length:Math.min(frames,2)},()=>chunk('fcTL',fctl)),chunk('IEND',Buffer.alloc(0))]));
}
test('APNG preflight rejects excessive allocations before inflation',()=>{
 assert.equal(typeof formats.inspectPng,'function');
 assert.throws(()=>formats.inspectPng(png(4096,4096,64)),/总像素/);
 assert.throws(()=>formats.inspectPng(png(6,4,65)),/64 帧/);
 assert.throws(()=>formats.inspectPng(png(6,4,1,[7,4,0,0])),/范围/);
 assert.throws(()=>formats.inspectPng(png(6,4,3)),/帧数/);
 assert.doesNotThrow(()=>formats.inspectPng(png(6,4,2)));
});
test('text-only DXF bounds include glyph height and width',()=>{
 const {svg}=dxfSvg('0\nSECTION\n2\nENTITIES\n0\nTEXT\n8\n0\n10\n0\n20\n0\n40\n10\n1\nHello\n0\nENDSEC\n0\nEOF\n');
 const box=svg.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);
 assert.ok(box[2]>=50&&box[3]>=10,JSON.stringify(box));
});
test('SVGZ expansion is bounded independently of compressed size',()=>{
 assert.equal(typeof formats.inflateSvg,'function');
 assert.throws(()=>formats.inflateSvg(new Uint8Array(gzipSync('x'.repeat(4096))),1024),/展开/);
 assert.equal(new TextDecoder().decode(formats.inflateSvg(new Uint8Array(gzipSync('<svg/>')),1024)),'<svg/>');
});
test('APNG actual zlib output must match bounded scanlines',()=>{
 assert.equal(typeof safePng.inflatePng,'function');
 const out={ctype:6,depth:8,interlace:0};
 assert.throws(()=>safePng.inflatePng(new Uint8Array(deflateSync(new Uint8Array(1024*1024))),out,1,1),/解压/);
 assert.equal(safePng.inflatePng(new Uint8Array(deflateSync(new Uint8Array(5))),out,1,1).length,5);
});
