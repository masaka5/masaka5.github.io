"""Focused actual IndexedDB recovery/queue regressions; Chromium + real File bytes."""
import asyncio,functools,http.server,threading,json
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright,expect
ROOT=Path(__file__).resolve().parents[3]
FIX=Path(__file__).resolve().parent/'cache-fixtures';FIX.mkdir(exist_ok=True);Image.new('RGB',(6,4),(30,60,90)).save(FIX/'recovery.png')
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
class Server(http.server.ThreadingHTTPServer):
 def handle_error(self,*a):pass
server=Server(('127.0.0.1',8877),functools.partial(Quiet,directory=str(ROOT)));threading.Thread(target=server.serve_forever,daemon=True).start()
BASE='http://127.0.0.1:8877';URL=BASE+'/toolbox-site/tools/image-viewer/'
STORAGE=BASE+'/_scratch/image-viewer-integration/src/storage.js'
VALID='''()=>({version:2,savedAt:Date.now(),items:[{id:'first',name:'grid.png',file:new File([new Uint8Array([137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,2,0,0,0,144,119,83,222,0,0,0,12,73,68,65,84,8,153,99,248,207,192,0,0,3,1,1,0,24,221,141,176,0,0,0,0,73,69,78,68,174,66,96,130])],'grid.png',{type:'image/png'}),ops:[]}],selected:0,settings:{format:'PNG',quality:90,zoom:'fit',pan:{x:0,y:0},frame:0,interval:3},exports:[]})'''
async def seed(page,mutation='s=>s'):
 await page.goto(BASE)
 await page.evaluate('''async({valid,mutation})=>{localStorage.clear();let s=eval('('+valid+')')();s=eval('('+mutation+')')(s);await new Promise((ok,no)=>{const r=indexedDB.open('toolbox-image-viewer-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('state');r.onsuccess=()=>{const d=r.result,t=d.transaction('state','readwrite');t.objectStore('state').put(s,'latest');t.oncomplete=()=>{d.close();ok()};t.onerror=()=>no(t.error)};});}''',{'valid':VALID,'mutation':mutation})
async def suite(mode):
 async with async_playwright() as p:
  b=await p.chromium.launch()
  if mode=='schema':
   page=await b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   mutations=["s=>({...s,settings:null})","s=>({...s,exports:null})","s=>({...s,version:99})","s=>({...s,savedAt:Date.now()+100000})","s=>({...s,savedAt:0})","s=>({...s,items:[{...s.items[0],file:{size:1,name:'fake.png'}}]})","s=>({...s,items:Array.from({length:101},(_,i)=>({...s.items[0],id:String(i)}))})","s=>({...s,items:[{...s.items[0],file:new File([new Uint8Array(24*1024*1024+1)],'too-large.png')}]})","s=>({...s,selected:2})","s=>({...s,settings:{...s.settings,pan:null}})","s=>({...s,settings:{...s.settings,zoom:Infinity}})","s=>({...s,items:[{...s.items[0],ops:[{type:'resize',w:100000,h:10}]}]})","s=>({...s,exports:[{id:'out',name:'out.png',blob:{size:1}}]})","s=>({...s,exports:Array.from({length:6},(_,i)=>({id:String(i),name:'out.png',blob:new Blob(['x'])}))})"]
   mutations += ["s=>({...s,items:Array.from({length:3},(_,i)=>({...s.items[0],id:String(i),file:new File([new Uint8Array(23*1024*1024)],'large.png')}))})","s=>({...s,exports:[{id:'out',name:'out.png',blob:new Blob([new Uint8Array(32*1024*1024+1)])}]})","s=>({...s,items:[{...s.items[0],ops:Array.from({length:101},()=>({type:'rotate'}))}]})","s=>({...s,settings:{...s.settings,quality:'90'}})","s=>({...s,settings:{...s.settings,frame:-1}})"]
   for mutation in mutations:
    await seed(page,mutation);await page.goto(URL);await expect(page.get_by_role('button',name='打开图片',exact=True)).to_be_enabled(timeout=5000);await expect(page.locator('.thumb')).to_have_count(0);assert not errors,(mutation,errors)
   await page.close();print('schema: rejected',len(mutations),'fresh corrupt/future/types/count/bytes/settings snapshots')
  elif mode in ['open','read']:
   page=await b.new_page();await seed(page)
   script="""window.late=0;const open=indexedDB.open.bind(indexedDB);indexedDB.open=(...a)=>{const actual=open(...a),fake={};actual.onupgradeneeded=()=>{fake.result=actual.result;fake.onupgradeneeded?.()};actual.onerror=()=>{fake.error=actual.error;fake.onerror?.()};actual.onsuccess=()=>{const d=actual.result,c=d.close.bind(d);d.close=()=>{late++;c()};setTimeout(()=>{fake.result=d;fake.onsuccess?.()},3000)};return fake};""" if mode=='open' else """const get=IDBObjectStore.prototype.get;IDBObjectStore.prototype.get=function(...a){const r=get.apply(this,a),fake={};r.onsuccess=()=>{const value=r.result;setTimeout(()=>{fake.result=value;fake.onsuccess?.()},3000)};return fake};"""
   await page.add_init_script(script);await page.goto(URL);await expect(page.get_by_role('button',name='打开图片',exact=True)).to_be_enabled(timeout=2300)
   # Import a fresh real image after fallback, then release old startup completion.
   await page.locator('#files').set_input_files({'name':'fresh.png','mimeType':'image/png','buffer':(FIX/'recovery.png').read_bytes()});await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000);await page.wait_for_timeout(3300);await expect(page.locator('.thumb.selected')).to_have_attribute('title','fresh.png')
   if mode=='open':assert await page.evaluate('late')>=1,'late opened database must close'
   print(mode+': fallback controls/fresh upload/late completion ownership passed');await page.close()
  elif mode=='queue':
   page=await b.new_page();await page.goto(BASE)
   result=await page.evaluate('''async({url,valid})=>{localStorage.clear();const m=await import(url+'?queue'),make=eval('('+valid+')'),s=make();await m.save(s);const put=IDBObjectStore.prototype.put;let release,puts=0,held=false;IDBObjectStore.prototype.put=function(value,key){puts++;if(held)return put.call(this,value,key);held=true;const store=this,fake={};let released=false;release=()=>{released=true};const spin=()=>{const r=store.get('keepalive');r.onsuccess=()=>{if(released){const w=put.call(store,value,key);w.onsuccess=()=>{fake.result=w.result;fake.onsuccess?.()}}else spin()};};spin();return fake;};const active=m.save({...s,settings:{...s.settings,quality:1}});await new Promise(ok=>setTimeout(ok,50));const pending=[];for(let i=0;i<120;i++)pending.push(m.save({...make(),settings:{...s.settings,quality:2+i%98}}));let settled=0;for(const p of pending)p.then(()=>settled++);await new Promise(ok=>setTimeout(ok,50));const replaced=settled;const clear=m.save(null);release();await Promise.all([active,clear,...pending]);IDBObjectStore.prototype.put=put;const value=await m.load(),raw=await new Promise(ok=>{const r=indexedDB.open('toolbox-image-viewer-v1',1);r.onsuccess=()=>{const d=r.result,t=d.transaction('state'),g=t.objectStore('state').get('latest');g.onsuccess=()=>ok(g.result??null);t.oncomplete=()=>d.close()}});return{replaced,puts,value,raw};}''',{'url':STORAGE,'valid':VALID})
   assert result['replaced']==119,result
   assert result['puts']<=2 and result['value'] is None and result['raw'] is None,result
   print('queue: 120 edits retained one active + one latest; clear durable',result);await page.close()
  elif mode=='failure':
   for action in ['put','clear','all']:
    page=await b.new_page();await seed(page)
    result=await page.evaluate('''async({url,valid,action})=>{const m=await import(url+'?failure'+action);const methods=action==='all'?['put','clear','delete']:[action==='clear'?'clear':'put'],originals=methods.map(k=>IDBObjectStore.prototype[k]);for(const method of methods)IDBObjectStore.prototype[method]=function(){throw new DOMException('full','QuotaExceededError')};try{await m.save(action==='put'?eval('('+valid+')')():null);}catch{}methods.forEach((k,i)=>IDBObjectStore.prototype[k]=originals[i]);}''',{'url':STORAGE,'valid':VALID,'action':action})
    await page.goto(URL);await expect(page.get_by_role('button',name='打开图片',exact=True)).to_be_enabled();await expect(page.locator('.thumb')).to_have_count(0);await page.close()
   print('failure: failed put and clear cannot resurrect old durable File after refresh')
  elif mode=='valid':
   page=await b.new_page();await page.goto(URL);await expect(page.get_by_role('button',name='打开图片',exact=True)).to_be_enabled();await page.locator('#files').set_input_files(str(FIX/'recovery.png'));await expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000);await page.get_by_role('button',name='顺时针旋转',exact=True).click();await expect(page.locator('[data-testid=dimensions]')).to_have_text('4 × 6');await page.get_by_role('button',name='生成导出',exact=True).click();await expect(page.locator('.export-row')).to_have_count(1);await page.wait_for_timeout(250);await page.reload();await expect(page.locator('[data-testid=dimensions]')).to_have_text('4 × 6',timeout=60000);await expect(page.locator('.export-row')).to_have_count(1);print('valid: actual File + transform + completed export survive versioned cache reload');await page.close()
  elif mode=='ordering':
   page=await b.new_page();await page.goto(BASE)
   result=await page.evaluate('''async({url,valid})=>{localStorage.clear();const m=await import(url+'?order'),make=eval('('+valid+')');await m.save(make());const put=IDBObjectStore.prototype.put,del=IDBObjectStore.prototype.delete;let fail=true,release;IDBObjectStore.prototype.put=function(...args){if(fail){fail=false;throw new DOMException('full','QuotaExceededError')}return put.apply(this,args)};IDBObjectStore.prototype.delete=function(...args){const store=this,fake={};let released=false;release=()=>released=true;const spin=()=>{const r=store.get('keepalive');r.onsuccess=()=>{if(!released){spin();return;}const d=del.apply(store,args);d.onsuccess=()=>{fake.result=d.result;fake.onsuccess?.()}}};spin();return fake};const old=m.save(make()).catch(()=>false);while(!release)await new Promise(ok=>setTimeout(ok,5));const newer=make();newer.settings.quality=55;const good=m.save(newer);release();await Promise.all([old,good]);IDBObjectStore.prototype.put=put;IDBObjectStore.prototype.delete=del;return(await m.load())?.settings.quality;}''',{'url':STORAGE,'valid':VALID})
   assert result==55,result;print('ordering: failed old write cleanup cannot delete latest good snapshot');await page.close()
  await b.close()
if __name__=='__main__':
 import sys
 asyncio.run(suite(sys.argv[1] if len(sys.argv)>1 else 'schema'))
