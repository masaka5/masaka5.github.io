"""Independent format fixtures and actual browser decode/edit/export checks."""
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright,expect
import struct,io,json
import numpy as np,tifffile,zipfile
root=Path(__file__).resolve().parents[3];fixtures=Path(__file__).parent/'extended-fixtures';fixtures.mkdir(exist_ok=True)
im=Image.new('RGB',(6,4),(220,40,60))
for fmt in ['PCX','TGA','TIFF','WEBP','AVIF']:
 im.save(fixtures/('sample.'+fmt.lower()),format=fmt)
im.save(fixtures/'sample.apng',format='PNG',save_all=True,append_images=[Image.new('RGB',(6,4),'blue')],duration=[100,100],loop=0)
psd=b'8BPS'+struct.pack('>H6sHIIHH',1,b'\0'*6,3,4,6,8,3)+struct.pack('>IIIH',0,0,0,0)+bytes([220]*24+[40]*24+[60]*24)
(fixtures/'sample.psd').write_bytes(psd)
pcd=bytearray([128])*(96*2048+768*512*3//2);pcd[:96*2048]=bytes(96*2048);pcd[:32]=bytes([255])*32;pcd[2048:2055]=b'PCD_IPI';(fixtures/'sample.pcd').write_bytes(pcd)
assert Image.open(fixtures/'sample.pcd').size==(768,512)
exif=Image.Exif();exif[271]='EXIF Camera';im.save(fixtures/'sample.exif',format='JPEG',exif=exif)
(fixtures/'sample.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="6" height="4"><rect width="6" height="4" fill="#dc283c"/></svg>')
(fixtures/'text.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="180" height="60"><text x="5" y="42" font-size="32">中文 ABC</text></svg>',encoding='utf8')
for ext in ['eps','ai']:(fixtures/('sample.'+ext)).write_text('%!PS-Adobe-3.0 EPSF-3.0\n%%BoundingBox: 0 0 6 4\n1 0 0 setrgbcolor 0 0 6 4 rectfill\nshowpage\n%%EOF')
(fixtures/'sample.dxf').write_text('0\nSECTION\n2\nENTITIES\n0\nLINE\n8\n0\n10\n0\n20\n0\n11\n6\n21\n4\n0\nCIRCLE\n8\n0\n10\n3\n20\n2\n40\n1\n0\nENDSEC\n0\nEOF\n')
raw=np.full((64,64),2000,dtype=np.uint16)
tifffile.imwrite(fixtures/'sample.dng',raw,photometric=32803,metadata=None,extratags=[(50706,'B',4,(1,4,0,0),False),(50707,'B',4,(1,1,0,0),False),(50708,'s',0,'Test Camera',False),(33421,'H',2,(2,2),False),(33422,'B',4,(0,1,1,2),False),(50717,'I',1,4095,False),(50721,'2i',9,(1,1,0,1,0,1,0,1,1,1,0,1,0,1,0,1,1,1),False),(50728,'2I',3,(1,1,1,1,1,1),False),(50778,'H',1,21,False)])
def rec(code,*args):return struct.pack('<IH',3+len(args),code)+struct.pack('<'+'h'*len(args),*args)
records=rec(0x020b,0,0)+rec(0x020c,100,100)+rec(0x041b,90,90,10,10)+rec(0)
header=struct.pack('<HHHIHIH',1,9,0x300,(18+len(records))//2,0,7,0)
place=struct.pack('<IHhhhhHI',0x9ac6cdd7,0,0,0,100,100,1440,0);checksum=0
for value in struct.unpack('<10H',place):checksum^=value
(fixtures/'sample.wmf').write_bytes(place+struct.pack('<H',checksum)+header+records)
for ext in ['cdr','ufo','fpx']:
 with zipfile.ZipFile(fixtures/('sample.'+ext),'w')as z:
  data=io.BytesIO();im.save(data,'PNG');z.writestr('metadata/thumbnails/thumbnail.png',data.getvalue())
with sync_playwright()as p:
 b=p.chromium.launch();page=b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8765/tools/image-viewer/')
 matrix={}
 for ext in ['pcx','tga','tiff','webp','avif','apng','psd','pcd','exif','svg','eps','ai','dxf','wmf','dng','cdr','ufo','fpx']:
  page.locator('#files').set_input_files(str(fixtures/('sample.'+ext)))
  page.wait_for_function("document.querySelector('[data-testid=dimensions]').textContent || document.querySelector('[role=alert]')",timeout=60000)
  assert page.locator('[data-testid=dimensions]').inner_text(),(ext,page.locator('body').inner_text())
  before=page.locator('[data-testid=dimensions]').inner_text()
  if ext=='dng':expect(page.locator('.options')).to_contain_text('Test Camera')
  page.get_by_role('button',name='顺时针旋转',exact=True).click()
  parts=before.split(' × ')
  expect(page.locator('[data-testid=dimensions]')).to_have_text(parts[1]+' × '+parts[0],timeout=60000)
  page.get_by_role('button',name='生成导出',exact=True).click()
  expect(page.locator('.export-row button').first).to_be_enabled(timeout=60000)
  with page.expect_download()as download:page.locator('.export-row button').first.click()
  out=Image.open(io.BytesIO(download.value.path().read_bytes()));assert out.size==(int(parts[1]),int(parts[0]))
  matrix[ext]={'decoded':before,'png_export':out.size}
 page.locator('#files').set_input_files(str(fixtures/'text.svg'))
 expect(page.locator('[data-testid=dimensions]')).to_have_text('1536 × 512',timeout=60000)
 assert page.locator('canvas').evaluate('c=>{const d=c.getContext("2d").getImageData(0,0,c.width,c.height).data;return d.some((v,i)=>i%4===3&&v>0)}'),'SVG text must render actual glyph pixels'
 page.locator('#files').set_input_files(str(fixtures/'sample.pcx'));expect(page.locator('[data-testid=dimensions]')).to_have_text('6 × 4',timeout=60000)
 for fmt in ['AVIF','PCX','TGA']:
  page.locator('.ant-select[aria-label="导出格式"]').click();page.get_by_role('option',name=fmt,exact=True).click();page.get_by_role('button',name='生成导出',exact=True).click()
  expect(page.locator('.export-row').first).to_contain_text('sample.'+fmt.lower(),timeout=60000)
  expect(page.locator('.export-row button').first).to_be_enabled(timeout=60000)
  with page.expect_download()as download:page.locator('.export-row button').first.click()
  out=Image.open(io.BytesIO(download.value.path().read_bytes()));assert out.size==(6,4) and out.format==fmt,(fmt,out.size,out.format)
 assert not errors,errors
 print(json.dumps(matrix));b.close()
