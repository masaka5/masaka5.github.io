# Toolbox image viewer

Original React/Ant Design browser integration using ImageMagick WASM 0.0.37.
ImageGlass inspired the viewer workflow; no ImageGlass source is included and
this is not the desktop application or its complete OS/format integration.

## Rebuild

Node 22+, npm, Python 3. Run `npm ci --ignore-scripts`, then `npm run build`.
`IMAGE_VIEWER_OUTPUT` can select an absolute output directory. The default is
`../../toolbox-site/tools/image-viewer` relative to this source directory.
No node_modules or WASM binary is in this source archive. The pinned package
supplies the wrapper and verifies the exact existing engine hash. Build never
copies its binary: deployment must provide the shared runtime at
`../conversion/assets/magick-DgWW1YxY.wasm` (14,451,784 bytes, SHA-256
8cf682c6b1cbf2d4772b7bfd7d4e481501fb953953fa2c9411f4c881a2e74c59).
Serve the `tools` parent under HTTP/HTTPS; workers require a same-origin URL.

## Verification

In the repository layout, install Python Pillow and Playwright, install a
Chromium browser (`python -m playwright install chromium`), then `npm test`.
Tests generate independent fixture files with Pillow and start a local server
on port 8876. They cover six formats and exports, exact pixels after crop and
rotation, flips, resize, EXIF, animation frames, local IDB restore, cached
export bytes, disabled storage, quota failure, cancellation, folder input,
bounded object URLs/workers, and six viewports. Tests contact no backend.
Focused actual IndexedDB regressions: `python -X utf8 tests/recovery.py MODE`,
where MODE is `schema`, `open`, `read`, `queue`, `failure`, `ordering`, or `valid`.
They use port 8877, seed actual records and File/Blob bytes, hold actual
transactions, and check late completion and failed-write refresh behavior.

## Bounds and behavior

100 files, 24 MiB each, 64 MiB total inputs; decoded images 16 Mi pixels;
64 frames / 32 Mi total frame pixels. Policy memory 192 MiB per Worker,
no disk/map/delegates, coder allowlist only. Every job terminates its Worker
after completion or cancellation, with a 25-second watchdog. Gallery and
main decode can overlap (at most three jobs during export). Thumbnails are
96x72 bound PNGs. Transform history caps at 100 steps. Crop follows the
preceding transforms; resize uses explicit width and height.

IDB stores File/Blob bytes, selected index, transform history, view/export
settings and five most recent exports capped at 32 MiB; snapshot maximum
96 MiB. A versioned schema validates File/Blob types, ids, operation counts,
settings, byte/count budgets and seven-day age before hydration. Unknown,
future or malformed snapshots are discarded. Open/read/write transactions
each time out after 1.5 seconds; a late database connection is closed and a
late read cannot hydrate the page. The writer retains at most one active and
one latest pending snapshot, coalescing superseded edits. Clear/failure marks
old durable data invalid immediately and cleanup stays serialized before a
newer successful write; an invalidation marker prevents failed cleanup from
resurrecting old files on refresh. Quota/disabled storage leaves viewing usable.
Clearing deletes the snapshot; URLs and Worker objects are not persisted. Switching input replaces
the gallery. Animation export exports the selected frame; GIF/TIFF animation
navigation and playback re-decode in a Worker. Tiny or numerous animations
can be slower than native playback. No RAW/SVG/HEIC/PDF or network URL loading
is advertised. Lossy exports and resized pixels follow ImageMagick's codec
and filter behavior. EXIF fields present in the image are shown, not invented.

See original bundled notices and dependency manifest for upstream licensing.
