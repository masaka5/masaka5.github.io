import {init,processImage} from './engine.js';
import {decodeSource} from './decode.js';
let ready;
self.onmessage=async({data})=>{try{if(data.bytes.byteLength>24*1024*1024)throw Error('单张图片不能超过 24 MB');const source=await decodeSource(new Uint8Array(data.bytes),data.options);ready??=init(new URL('../../conversion/assets/magick-DgWW1YxY.wasm',self.location.href));const formats=await ready;const result=processImage(source.bytes,{...data.options,frame:source.frames?0:data.options.frame,source});const transfer=[result.pixels?.buffer,result.data?.buffer,result.thumbnail?.buffer].filter(Boolean);self.postMessage({id:data.id,result,formats},transfer);}catch(e){self.postMessage({id:data.id,error:String(e.message||e)});}};
