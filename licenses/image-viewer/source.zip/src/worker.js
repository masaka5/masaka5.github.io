import {init,processImage} from './engine.js';
let ready;
self.onmessage=async({data})=>{try{ready??=init(new URL('../../conversion/assets/magick-DgWW1YxY.wasm',self.location.href));const formats=await ready;const result=processImage(new Uint8Array(data.bytes),data.options);const transfer=[result.pixels?.buffer,result.data?.buffer,result.thumbnail?.buffer].filter(Boolean);self.postMessage({id:data.id,result,formats},transfer);}catch(e){self.postMessage({id:data.id,error:String(e.message||e)});}};
