import DxfParser from 'dxf-parser';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
export function dxfSvg(text){
 const drawing=new DxfParser().parseSync(text);if(!drawing?.entities?.length)throw Error('DXF 没有可显示的二维图元');
 if(drawing.entities.length>20000)throw Error('DXF 超过 2 万个图元限制');
 const bounds=[],shapes=[];let skipped=0;
 function point(p){const x=Number(p?.x),y=Number(p?.y);if(!Number.isFinite(x)||!Number.isFinite(y)||Math.abs(x)>1e12||Math.abs(y)>1e12)throw Error('DXF 坐标无效');bounds.push([x,y]);return `${x},${-y}`;}
 for(const entity of drawing.entities){
  const stroke=entity.color?('#'+entity.color.toString(16).padStart(6,'0')):'#315fc9';
  if(['LINE','LWPOLYLINE','POLYLINE'].includes(entity.type)){
   const points=(entity.vertices||[]).map(point);if(points.length>1)shapes.push(`<${entity.shape?'polygon':'polyline'} points="${points.join(' ')}" stroke="${stroke}"/>`);
  }else if(['CIRCLE','ARC'].includes(entity.type)){
   const c=entity.center,r=entity.radius;if(!Number.isFinite(r)||r<=0)continue;point({x:c.x-r,y:c.y-r});point({x:c.x+r,y:c.y+r});
   if(entity.type==='CIRCLE')shapes.push(`<circle cx="${c.x}" cy="${-c.y}" r="${r}" stroke="${stroke}"/>`);
   else{let delta=(entity.endAngle-entity.startAngle+Math.PI*2)%(Math.PI*2);const a={x:c.x+r*Math.cos(entity.startAngle),y:c.y+r*Math.sin(entity.startAngle)},b={x:c.x+r*Math.cos(entity.endAngle),y:c.y+r*Math.sin(entity.endAngle)};shapes.push(`<path d="M${point(a)} A${r},${r} 0 ${delta>Math.PI?1:0} 0 ${point(b)}" stroke="${stroke}"/>`);}
  }else if(['TEXT','MTEXT'].includes(entity.type)){
   const p=entity.startPoint||entity.position;if(!p){skipped++;continue;}point(p);const height=Math.max(.1,Number(entity.textHeight||entity.height)||10),text=String(entity.text||'').replace(/\\P/g,' ');
   point({x:p.x,y:p.y+height});point({x:p.x+Math.max(1,[...text].length)*height,y:p.y-height*.3});
   shapes.push(`<text x="${p.x}" y="${-p.y}" font-size="${height}" fill="${stroke}" stroke="none">${esc(text)}</text>`);
  }else skipped++;
 }
 if(!shapes.length||!bounds.length)throw Error('DXF 暂无可显示的二维图元');
 let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;for(const [x,y]of bounds){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
 const w=Math.max(1,maxX-minX),h=Math.max(1,maxY-minY),pad=Math.max(w,h)*.03;
 return{svg:`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="${Math.max(1,Math.round(1200*(h+2*pad)/(w+2*pad)))}" viewBox="${minX-pad} ${-maxY-pad} ${w+2*pad} ${h+2*pad}"><g fill="none" stroke-width="${Math.max(w,h)/1000}">${shapes.join('')}</g></svg>`,note:skipped?`二维预览 · ${skipped} 个图元未渲染`:'二维预览'};
}
