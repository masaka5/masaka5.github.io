const NAME='toolbox-image-viewer-v1';
let database,chain=Promise.resolve();
function db(){return database??=new Promise((resolve,reject)=>{const r=indexedDB.open(NAME,1);r.onupgradeneeded=()=>r.result.createObjectStore('state');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onblocked=()=>reject(Error('本地缓存被其他页面占用'));});}
export async function load(){const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction('state').objectStore('state').get('latest');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
export function save(state){chain=chain.catch(()=>{}).then(async()=>{const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction('state','readwrite');if(state)t.objectStore('state').put(state,'latest');else t.objectStore('state').clear();t.oncomplete=resolve;t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error);});});return chain;}
