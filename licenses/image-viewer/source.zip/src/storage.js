import {snapshot,validateSnapshot} from './snapshot.js';
const NAME='toolbox-image-viewer-v1',TOMBSTONE='toolbox-image-viewer-invalid-v2',TIMEOUT=1500;
let databasePromise,active=false,pending=null,generation=0,invalid=false;
function markInvalid(value){invalid=value;try{if(value)localStorage.setItem(TOMBSTONE,'1');else localStorage.removeItem(TOMBSTONE);}catch{}}
function isInvalid(){try{return invalid||localStorage.getItem(TOMBSTONE)==='1';}catch{return invalid;}}
function database(){
 if(databasePromise)return databasePromise;
 const promise=new Promise((resolve,reject)=>{
  let request,done=false;const finish=error=>{if(done)return;done=true;clearTimeout(timer);reject(error);};
  const timer=setTimeout(()=>finish(Error('本地缓存打开超时')),TIMEOUT);
  try{request=indexedDB.open(NAME,1);}catch(e){finish(e);return;}
  request.onupgradeneeded=()=>{if(done){try{request.transaction.abort();}catch{}return;}if(!request.result.objectStoreNames.contains('state'))request.result.createObjectStore('state');};
  request.onsuccess=()=>{if(done){request.result.close();return;}done=true;clearTimeout(timer);const db=request.result;db.onversionchange=()=>{db.close();if(databasePromise===promise)databasePromise=null;};resolve(db);};
  request.onerror=()=>finish(request.error||Error('本地缓存无法打开'));
  request.onblocked=()=>finish(Error('本地缓存被其他页面占用'));
 });
 databasePromise=promise;promise.catch(()=>{if(databasePromise===promise)databasePromise=null;});return promise;
}
async function transaction(mode,operation){
 const db=await database();return new Promise((resolve,reject)=>{
  let tx,done=false,completed=false,received=false,result;
  const finish=error=>{if(done)return;if(!error&&(!completed||!received))return;done=true;clearTimeout(timer);error?reject(error):resolve(result);};
  const timer=setTimeout(()=>{finish(Error('本地缓存事务超时'));try{tx?.abort();}catch{}},TIMEOUT);
  try{
   tx=db.transaction('state',mode);tx.oncomplete=()=>{completed=true;finish();};tx.onerror=()=>finish(tx.error||Error('本地缓存事务失败'));tx.onabort=()=>finish(tx.error||Error('本地缓存事务中断'));
   const request=operation(tx.objectStore('state'));if(request){request.onsuccess=()=>{if(done)return;received=true;result=request.result;finish();};request.onerror=()=>finish(request.error||Error('本地缓存读取失败'));}else received=true;
  }catch(e){finish(e);try{tx?.abort();}catch{}}
 });
}
export async function load(){
 if(isInvalid())return null;const started=generation;
 const raw=await transaction('readonly',s=>s.get('latest'));
 if(started!==generation||isInvalid())return null;
 const safe=validateSnapshot(raw);if(raw&&!safe){void save(null).catch(()=>{});return null;}return safe;
}
async function replace(task){
 try{
  const value=task.state===null?null:snapshot(task.state);if(task.state!==null&&!value)throw Error('本地缓存内容无效');
  await transaction('readwrite',s=>value?s.put(value,'latest'):s.clear());
  // An older completion must not validate the newer queued intent.
  if(task.generation===generation)markInvalid(false);return true;
 }catch(error){
  markInvalid(true);
  // Cleanup is inside the serial writer: it cannot erase a newer good write.
  try{await transaction('readwrite',s=>s.delete('latest'));}catch{}
  throw error;
 }
}
async function drain(){if(active)return;active=true;try{while(pending){const task=pending;pending=null;try{task.resolve(await replace(task));}catch(e){task.reject(e);}}}finally{active=false;}}
export function save(state){
 // Persist invalidation at intent time, even when a clear is behind a slow write.
 markInvalid(true);const current=++generation;
 return new Promise((resolve,reject)=>{if(pending)pending.resolve(false);pending={state,resolve,reject,generation:current};void drain();});
}
