export class EngineClient{
 constructor(){this.worker=null;this.pending=null;this.counter=0;}
 cancel(){this.worker?.terminate();this.worker=null;if(this.pending){clearTimeout(this.pending.timer);this.pending.reject(new DOMException('已取消','AbortError'));this.pending=null;}}
 run(file,options){this.cancel();return new Promise(async(resolve,reject)=>{
  const id=++this.counter;const worker=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});this.worker=worker;
  const timer=setTimeout(()=>{if(this.worker===worker){this.cancel();}},25000);this.pending={reject,timer};
  worker.onmessage=({data})=>{if(data.id!==id)return;clearTimeout(timer);this.pending=null;worker.terminate();if(this.worker===worker)this.worker=null;data.error?reject(Error(data.error)):resolve(data.result);};
  worker.onerror=e=>{clearTimeout(timer);this.pending=null;worker.terminate();this.worker=null;reject(Error(e.message));};
  try{const bytes=await file.arrayBuffer();if(this.worker===worker)worker.postMessage({id,bytes,options},[bytes]);}catch(e){this.cancel();reject(e);}
 });}
}
