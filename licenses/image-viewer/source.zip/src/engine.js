import {initializeImageMagick,ImageMagick,MagickImageInfo,MagickReadSettings,MagickGeometry,MagickFormat,ConfigurationFiles,Magick} from '@imagemagick/magick-wasm';
import {exportFormats} from './formats.js';
export const LIMITS={file:24*1024*1024,pixels:16*1024*1024,frames:64,totalPixels:32*1024*1024};
export async function init(url){
 const config=ConfigurationFiles.default;
 config.policy.data=config.policy.data.replace('</policymap>',`<policy domain="resource" name="memory" value="192MiB"/><policy domain="resource" name="map" value="0"/><policy domain="resource" name="disk" value="0"/><policy domain="resource" name="width" value="16384"/><policy domain="resource" name="height" value="16384"/><policy domain="resource" name="list-length" value="64"/><policy domain="delegate" rights="none" pattern="*"/><policy domain="coder" rights="none" pattern="*"/><policy domain="coder" rights="read|write" pattern="{PNG,JPEG,GIF,TIFF,BMP,WEBP,RGBA,PCX,TGA,PSD,PSB,PCD,PCDS,AVIF,HEIC}"/></policymap>`);
 await initializeImageMagick(url,config);
 return ['PNG','JPEG','WEBP','GIF','TIFF','BMP'].filter(f=>Magick.supportedFormats.some(x=>x.format===f&&x.supportsReading&&x.supportsWriting));
}
function budget(w,h){if(!Number.isSafeInteger(w)||!Number.isSafeInteger(h)||w<1||h<1||w*h>LIMITS.pixels)throw Error('图片超过 1600 万像素限制');}
export function processImage(bytes,{ops=[],frame=0,format,quality=90,thumb=false,source={}}={}){
 if(bytes.length>LIMITS.file)throw Error('单张图片不能超过 24 MB');
 const readSettings=new MagickReadSettings();if(source.magickFormat)readSettings.format=source.magickFormat;
 const info=MagickImageInfo.create(bytes,readSettings);budget(info.width,info.height);
 const detected=/^BMP[23]?$/.test(info.format)?'BMP':info.format;
 if(!['PNG','JPEG','GIF','TIFF','TIFF64','BMP','WEBP','PCX','TGA','PSD','PSB','PCD','PCDS','AVIF','HEIC'].includes(detected))throw Error('此图片格式或版本暂不支持');
 const render=images=>{
  if(images.length>LIMITS.frames||images.reduce((n,i)=>n+i.width*i.height,0)>LIMITS.totalPixels||info.width*info.height*images.length>LIMITS.totalPixels)throw Error('动画或多页图片超过 64 帧 / 3200 万总像素限制');
  const count=images.length;images.coalesce();const image=images[Math.min(count-1,Math.max(0,frame|0))];image.autoOrient();
  const metadata={format:source.sourceFormat||detected,originalWidth:info.width,originalHeight:info.height,frames:source.frames||count,delay:source.delay||Math.max(50,image.animationDelay*10),attributes:{...source.attributes,...(source.note?{预览:source.note}:{})}};
  for(const key of image.attributeNames.slice(0,80)){if(key.toLowerCase().startsWith('exif:'))metadata.attributes[key]=String(image.getAttribute(key)).slice(0,500);}
  // EXIF properties are lazily expanded by ImageMagick.
  for(const key of ['exif:Make','exif:Model','exif:DateTimeOriginal','exif:ExposureTime','exif:FNumber','exif:ISOSpeedRatings','exif:Orientation']){const value=image.getAttribute(key);if(value)metadata.attributes[key]=value;}
  for(const op of ops){
   if(op.type==='rotate')image.rotate(90);
   else if(op.type==='flop')image.flop();
   else if(op.type==='flip')image.flip();
   else if(op.type==='crop'){
    const {x,y,w,h}=op;if(![x,y,w,h].every(Number.isInteger)||x<0||y<0||w<1||h<1||x+w>image.width||y+h>image.height)throw Error('裁剪范围超出图片');
    image.crop(new MagickGeometry(x,y,w,h));image.resetPage();
   }else if(op.type==='resize'){budget(op.w,op.h);const g=new MagickGeometry(op.w,op.h);g.ignoreAspectRatio=true;image.resize(g);}
   budget(image.width,image.height);
  }
  if(thumb){image.resize(96,72);return image.write(MagickFormat.Png,data=>({thumbnail:new Uint8Array(data)}));}
  const result={...metadata,width:image.width,height:image.height};
  if(format){if(!Object.hasOwn(exportFormats,format))throw Error('不支持的导出格式');image.quality=Math.max(1,Math.min(100,quality));return image.write(format,data=>({...result,data:new Uint8Array(data)}));}
  result.pixels=image.getPixels(p=>p.toByteArray(0,0,image.width,image.height,'RGBA'));
  return result;
 };
 return source.magickFormat?ImageMagick.readCollection(bytes,source.magickFormat,render):ImageMagick.readCollection(bytes,render);
}
