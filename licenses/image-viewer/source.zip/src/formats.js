export const inputExtensions=['png','jpg','jpeg','jpe','jfif','exif','gif','tif','tiff','bmp','webp','avif','apng','pcx','tga','psd','psb','pcd','svg','svgz','eps','epsf','ps','ai','pdf','wmf','emf','dxf','raw','dng','cr2','cr3','nef','nrw','arw','sr2','orf','rw2','raf','pef','srw','fpx','cdr','ufo','heic','heif'];
import {Gunzip} from 'fflate';
export const accept=inputExtensions.map(x=>'.'+x).join(',');
export const exportFormats={PNG:'image/png',JPEG:'image/jpeg',WEBP:'image/webp',GIF:'image/gif',TIFF:'image/tiff',BMP:'image/bmp',AVIF:'image/avif',PCX:'image/x-pcx',TGA:'image/x-tga'};
export function supportedName(name){return inputExtensions.includes(String(name).split('.').at(-1).toLowerCase());}
export function inflateSvg(bytes,maximum=24*1024*1024){
 const chunks=[];let length=0;
 const unzip=new Gunzip(chunk=>{length+=chunk.length;if(length>maximum)throw Error('SVGZ 展开后超过 24 MB');chunks.push(chunk);});
 // Bound the expansion of each push, including malicious compression ratios.
 for(let at=0;at<bytes.length;at+=1024)unzip.push(bytes.subarray(at,at+1024),at+1024>=bytes.length);
 const output=new Uint8Array(length);let offset=0;for(const c of chunks){output.set(c,offset);offset+=c.length;}return output;
}
// Inspect animation headers before a decoder can allocate or inflate frame data.
export function inspectPng(bytes){
 const max=16*1024*1024,total=32*1024*1024,view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
 if(bytes.length<33||view.getUint32(0)!==0x89504e47||view.getUint32(4)!==0x0d0a1a0a)throw Error('PNG 文件不完整');
 let width,height,declared=0,frames=0,end=false;
 for(let offset=8;offset+12<=bytes.length;){
  const length=view.getUint32(offset),type=String.fromCharCode(...bytes.subarray(offset+4,offset+8)),at=offset+8;
  if(length>bytes.length-offset-12)throw Error('PNG 数据块不完整');
  if(type==='IHDR'){
   if(offset!==8||length!==13)throw Error('PNG 图片头无效');width=view.getUint32(at);height=view.getUint32(at+4);
   if(!width||!height||width*height>max)throw Error('图片超过 1600 万像素限制');
  }else if(!width)throw Error('PNG 缺少图片头');
  else if(type==='acTL'){
   if(length!==8||declared||frames)throw Error('APNG 帧数无效');declared=view.getUint32(at);
   if(!declared||declared>64)throw Error('动画超过 64 帧限制');if(width*height*declared>total)throw Error('动画超过 3200 万总像素限制');
  }else if(type==='fcTL'){
   if(length!==26||!declared||++frames>declared)throw Error('APNG 帧数无效');
   const w=view.getUint32(at+4),h=view.getUint32(at+8),x=view.getUint32(at+12),y=view.getUint32(at+16);
   if(!w||!h||x+w>width||y+h>height)throw Error('APNG 帧范围无效');
  }else if(type==='IEND'){end=true;break;}
  offset+=length+12;
 }
 if(!end||declared&&frames!==declared)throw Error('APNG 帧数或数据不完整');
 return{width,height,frames:declared||1,animated:declared>0};
}
