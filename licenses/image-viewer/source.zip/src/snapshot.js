export const CACHE_VERSION=2,MAX_AGE=7*24*60*60*1000;
const MiB=1024*1024;
const record=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const text=(x,max)=>typeof x==='string'&&x.length>0&&x.length<=max;
const finite=(x,min,max)=>Number.isFinite(x)&&x>=min&&x<=max;
const integer=(x,min,max)=>Number.isSafeInteger(x)&&x>=min&&x<=max;
const formats=['PNG','JPEG','WEBP','GIF','TIFF','BMP','AVIF','PCX','TGA'];
function operation(raw){
 if(!record(raw))return null;
 if(['rotate','flop','flip'].includes(raw.type))return{type:raw.type};
 if(!['crop','resize'].includes(raw.type)||!integer(raw.w,1,16384)||!integer(raw.h,1,16384)||raw.w*raw.h>16*MiB)return null;
 if(raw.type==='crop'){if(!integer(raw.x,0,16384)||!integer(raw.y,0,16384)||raw.x+raw.w>16384||raw.y+raw.h>16384)return null;return{type:'crop',x:raw.x,y:raw.y,w:raw.w,h:raw.h};}
 return{type:'resize',w:raw.w,h:raw.h};
}
export function validateSnapshot(raw,now=Date.now()){
 if(!record(raw)||raw.version!==CACHE_VERSION||!finite(raw.savedAt,now-MAX_AGE,now)||!Array.isArray(raw.items)||raw.items.length>100||!Array.isArray(raw.exports)||raw.exports.length>5||!record(raw.settings))return null;
 const items=[],ids=new Set();let inputBytes=0,outputBytes=0;
 for(const row of raw.items){
  if(!record(row)||!text(row.id,128)||ids.has(row.id)||!text(row.name,4096)||!(row.file instanceof File)||!text(row.file.name,1024)||row.file.size>24*MiB||!Array.isArray(row.ops)||row.ops.length>100)return null;
  inputBytes+=row.file.size;if(inputBytes>64*MiB)return null;
  const ops=[];for(const op of row.ops){const safe=operation(op);if(!safe)return null;ops.push(safe);}
  ids.add(row.id);items.push({id:row.id,name:row.name,file:row.file,ops});
 }
 if(!integer(raw.selected,0,Math.max(0,items.length-1)))return null;
 const exports=[],exportIds=new Set();for(const row of raw.exports){
  if(!record(row)||!text(row.id,128)||exportIds.has(row.id)||!text(row.name,1024)||!(row.blob instanceof Blob))return null;
  outputBytes+=row.blob.size;if(outputBytes>32*MiB||inputBytes+outputBytes>96*MiB)return null;
  exportIds.add(row.id);exports.push({id:row.id,name:row.name,blob:row.blob});
 }
 const s=raw.settings;
 if(!formats.includes(s.format)||!integer(s.quality,1,100)||!(s.zoom==='fit'||finite(s.zoom,.02,16))||!record(s.pan)||!finite(s.pan.x,-1e7,1e7)||!finite(s.pan.y,-1e7,1e7)||!integer(s.frame,0,63)||!finite(s.interval,1,60))return null;
 return{version:CACHE_VERSION,savedAt:raw.savedAt,items,selected:raw.selected,settings:{format:s.format,quality:s.quality,zoom:s.zoom,pan:{x:s.pan.x,y:s.pan.y},frame:s.frame,interval:s.interval},exports};
}
export function snapshot(state){return validateSnapshot({...state,version:CACHE_VERSION,savedAt:Date.now()});}
