import {Unzlib} from 'fflate';
import UPNG from 'upng-js';
export function inflatePng(bytes,out,width,height){
 const channels={0:1,2:3,3:1,4:2,6:4}[out.ctype],depth=out.depth;
 if(!channels||![1,2,4,8,16].includes(depth)||![0,1].includes(out.interlace))throw Error('PNG 像素格式无效');
 const bits=channels*depth;let expected=0;
 const rows=(w,h)=>w>0&&h>0?(Math.ceil(w*bits/8)+1)*h:0;
 if(!out.interlace)expected=rows(width,height);
 else{
  for(const [x,y,dx,dy]of [[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]])expected+=rows(Math.ceil((width-x)/dx),Math.ceil((height-y)/dy));
 }
 if(expected>144*1024*1024)throw Error('PNG 解压数据过大');
 const output=new Uint8Array(expected);let length=0;
 const decoder=new Unzlib(chunk=>{if(length+chunk.length>expected)throw Error('PNG 解压数据超出图片尺寸');output.set(chunk,length);length+=chunk.length;});
 for(let at=0;at<bytes.length;at+=1024)decoder.push(bytes.subarray(at,at+1024),at+1024>=bytes.length);
 if(length!==expected)throw Error('PNG 解压数据不完整');return output;
}
// UPNG otherwise inflates arbitrary zlib output before validating scanlines.
UPNG.decode._decompress=(out,bytes,width,height)=>{
 const data=inflatePng(bytes,out,width,height);
 return out.interlace?UPNG.decode._readInterlace(data,{...out,width,height}):UPNG.decode._filterZero(data,out,0,width,height);
};
