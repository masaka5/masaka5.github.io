import {Resvg,initWasm} from '@resvg/resvg-wasm';
import {renderToSvg} from 'wmf-emf-renderer';
import {Unzip,UnzipInflate} from 'fflate';
import UPNG from 'upng-js';
import './safe-png.js';
import {dxfSvg} from './vector.js';
import {inspectPng,inflateSvg} from './formats.js';
let svgReady,fontReady;
const root=()=>new URL('./runtime/',self.location.href);
const limit=16*1024*1024;
function budget(w,h){if(!Number.isSafeInteger(w)||!Number.isSafeInteger(h)||w<1||h<1||w*h>limit)throw Error('图片超过 1600 万像素限制');}
async function svgPng(svg){
 svgReady??=initWasm(new URL('resvg.wasm',root()));await svgReady;
 const text=typeof svg==='string'?svg:new TextDecoder().decode(svg);let font={loadSystemFonts:false};
 if(/<text[\s>]/i.test(text)){
  fontReady??=Promise.all(['NotoSans-Regular.ttf','NotoSansSC-Regular.ttf'].map(async name=>{const response=await fetch(new URL('../../documents/fonts/'+name,self.location.href));if(!response.ok)throw Error('图片字体加载失败');return new Uint8Array(await response.arrayBuffer());}));
  font={fontBuffers:await fontReady,defaultFontFamily:'Noto Sans SC',sansSerifFamily:'Noto Sans SC'};
 }
 const resvg=new Resvg(svg,{font,fitTo:{mode:'width',value:1536}});
 try{budget(1536,Math.max(1,Math.ceil(1536*resvg.height/resvg.width)));const box=resvg.getBBox();if(box){try{if(box.width/Math.max(.001,box.height)>100||box.height/Math.max(.001,box.width)>100)throw Error('矢量图片宽高比例过大');}finally{box.free();}}
  const rendered=resvg.render();try{budget(rendered.width,rendered.height);return new Uint8Array(rendered.asPng());}finally{rendered.free();}
 }finally{resvg.free();}
}
function pngFrame(bytes,frame){
 inspectPng(bytes);
 const decoded=UPNG.decode(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));budget(decoded.width,decoded.height);
 const frames=decoded.frames.length||1;if(frames>64||decoded.width*decoded.height*frames>32*1024*1024)throw Error('动画超过 64 帧 / 3200 万总像素限制');
 const index=Math.max(0,Math.min(frames-1,frame|0)),rgba=UPNG.toRGBA8(decoded)[index];
 return{bytes:new Uint8Array(UPNG.encode([rgba],decoded.width,decoded.height,0)),sourceFormat:'APNG',frames,delay:Math.max(50,decoded.frames[index]?.delay||100)};
}
async function postscript(bytes){
 const {default:load}=await import(new URL('gs.js',root()).href);const logs=[];
 const gs=await load({locateFile:file=>new URL(file,root()).href,noInitialRun:true,print:()=>{},printErr:s=>{if(logs.length<30)logs.push(s);}});
 gs.FS.writeFile('/input.bin',bytes);
 const code=gs.callMain(['-dSAFER','-dBATCH','-dNOPAUSE','-dFirstPage=1','-dLastPage=1','-dEPSCrop','-dMaxBitmap=67108864','-r96','-sDEVICE=pngalpha','-sOutputFile=/page.png','/input.bin']);
 if(code)throw Error('PostScript / PDF 解析失败');return gs.FS.readFile('/page.png');
}
async function rawPng(bytes){
 const {default:load}=await import(new URL('libraw.js',root()).href);const module=await load({locateFile:file=>new URL(file,root()).href});const raw=new module.LibRaw();
 try{raw.open(bytes,{halfSize:true,outputBps:8,useCameraWb:true});const meta=raw.metadata(false);if(!meta)throw Error('RAW 元数据读取失败');budget(Math.ceil((meta.width||meta.raw_width)/2),Math.ceil((meta.height||meta.raw_height)/2));const image=raw.imageData();if(!image)throw Error('RAW 解码失败');budget(image.width,image.height);
  const channels=image.colors||image.channels||3,data=image.data,rgba=new Uint8Array(image.width*image.height*4);
  if(image.bits!==8||![1,3,4].includes(channels)||!data?.length||data.length<image.width*image.height*channels)throw Error('RAW 像素数据不完整');for(let i=0,j=0;i<rgba.length;i+=4,j+=channels){rgba[i]=data[j];rgba[i+1]=channels===1?data[j]:data[j+1];rgba[i+2]=channels===1?data[j]:data[j+2];rgba[i+3]=255;}
  return{bytes:new Uint8Array(UPNG.encode([rgba.buffer],image.width,image.height,0)),attributes:{相机:[meta.camera_make,meta.camera_model].filter(Boolean).join(' '),传感器尺寸:meta.raw_width+' × '+meta.raw_height},note:'RAW 半尺寸解码'};
 }finally{raw.delete();}
}
function zipPreview(bytes){
 let output;
 const unzip=new Unzip(file=>{if(output||!/(?:thumbnail|preview).*(?:\.png|\.jpe?g|\.bmp)$/i.test(file.name)){file.terminate();return;}
  if(file.originalSize>24*1024*1024){file.terminate();throw Error('内嵌预览超过 24 MB');}
  const chunks=[];let length=0;file.ondata=(error,data,final)=>{if(error)throw error;length+=data.length;if(length>24*1024*1024){file.terminate();throw Error('内嵌预览超过 24 MB');}chunks.push(data);if(final&&!output){output=new Uint8Array(length);let offset=0;for(const c of chunks){output.set(c,offset);offset+=c.length;}}};file.start();});unzip.register(UnzipInflate);for(let at=0;at<bytes.length&&!output;at+=1024)unzip.push(bytes.subarray(at,at+1024),at+1024>=bytes.length);return output;
}
function embeddedPreview(bytes){
 if(bytes[0]===80&&bytes[1]===75){try{const preview=zipPreview(bytes);if(preview)return preview;}catch{}}
 let candidates=0;
 for(let start=0;start<bytes.length-16;start++){
  if((bytes[start]===255&&bytes[start+1]===216&&bytes[start+2]===255||bytes[start]===137&&bytes[start+1]===80&&bytes[start+2]===78&&bytes[start+3]===71)&&++candidates>32)break;
  if(bytes[start]===255&&bytes[start+1]===216&&bytes[start+2]===255){for(let end=start+3;end<bytes.length-1;end++)if(bytes[end]===255&&bytes[end+1]===217)return bytes.slice(start,end+2);}
  if(bytes[start]===137&&bytes[start+1]===80&&bytes[start+2]===78&&bytes[start+3]===71){for(let end=start+8;end<bytes.length-12;end++)if(bytes[end+4]===73&&bytes[end+5]===69&&bytes[end+6]===78&&bytes[end+7]===68)return bytes.slice(start,end+12);}
 }
 throw Error('此版本没有可读取的内嵌预览，请在原软件中导出 PNG、SVG 或 PDF');
}
export async function decodeSource(bytes,options={}){
 const ext=String(options.name||'').split('.').at(-1).toLowerCase();
 if(['cdr','ufo','fpx'].includes(ext))return{bytes:embeddedPreview(bytes),sourceFormat:ext.toUpperCase(),note:'内嵌预览 · 非完整文档'};
 if(ext==='apng'||bytes[0]===137&&bytes[1]===80&&inspectPng(bytes).animated)return pngFrame(bytes,options.frame);
 if(['svg','svgz'].includes(ext)){if(ext==='svgz')bytes=inflateSvg(bytes);return{bytes:await svgPng(bytes),sourceFormat:ext.toUpperCase(),note:'矢量栅格预览'};}
 if(['wmf','emf'].includes(ext))return{bytes:await svgPng(renderToSvg(bytes,{viewWidth:1536,viewHeight:1024})),sourceFormat:ext.toUpperCase(),note:'矢量栅格预览'};
 if(ext==='dxf'){const {svg,note}=dxfSvg(new TextDecoder().decode(bytes));return{bytes:await svgPng(svg),sourceFormat:'DXF',note};}
 if(['eps','epsf','ps','ai','pdf'].includes(ext))return{bytes:await postscript(bytes),sourceFormat:ext.toUpperCase(),note:'第 1 页栅格预览'};
 if(['raw','dng','cr2','cr3','nef','nrw','arw','sr2','orf','rw2','raf','pef','srw'].includes(ext))return{...await rawPng(bytes),sourceFormat:ext.toUpperCase()};
 return{bytes,...(ext==='tga'?{magickFormat:'TGA'}:{})};
}
