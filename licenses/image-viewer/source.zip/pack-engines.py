"""Bundle corresponding build sources, excluding upstream docs/tests and binaries."""
from pathlib import Path
import tarfile,io,lzma,json,hashlib
root=Path(__file__).resolve().parent
archives=['ghostpdl-source.tar.gz','ghostpdl-wasm-source.tar.gz','libraw-source.tar.gz','libraw-wrapper-source.tar.gz','lcms-source.tar.gz']
omitted=[];kept=0;licenses=[]
output=root/'notices/engine-build-sources.tar.xz'
with tarfile.open(output,'w:xz',preset=9)as dest:
 for name in archives:
  with tarfile.open(root/'notices'/name)as source:
   for m in source:
    parts=Path(m.name).parts;rel=parts[1:];lower=[p.lower()for p in rel]
    if m.isfile()and len(rel)==1 and rel[0].lower().startswith(('license','copying','copyright')):
     licenses.append('\n===== '+m.name+' =====\n'+source.extractfile(m).read().decode('utf8',errors='replace'))
    skip=any(p in {'doc','docs','examples','test','tests','testbed','.serena','node_modules','dist','libs'}for p in lower)
    skip|=m.name.lower().endswith(('.arw','.wasm','.a','.map'))
    skip|=len(rel)==1 and rel[0] in {'libraw.js','worker.js'}
    if skip:
     if m.isfile():omitted.append(m.name)
     continue
    if m.isfile():dest.addfile(m,source.extractfile(m));kept+=1
    elif m.isdir()or m.issym():dest.addfile(m)
manifest={'archive':output.name,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'kept_files':kept,'omitted_nonbuild_files':omitted,'upstreams':{
 'ghostpdl-wasm':'https://github.com/okathira-dev/ghostpdl-wasm/tree/a62b7d686b21cf88f6425b3e989d1062b9af4256',
 'ghostpdl':'https://github.com/ArtifexSoftware/ghostpdl/tree/2d6e764c1f4a73520ed6de6dd3fa78ad30cd6a63',
 'libraw-wrapper':'https://github.com/garbarok/libraw-wasm-nothread/tree/d03be9f0eb0efda42e807a87045b4ac18ad8ca98',
 'libraw':'https://github.com/LibRaw/LibRaw/tree/0.22.1',
 'little-cms':'https://github.com/mm2/Little-CMS/tree/lcms2.19.1'}}
(root/'notices/engine-sources.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
(root/'notices/engine-LICENSES.txt').write_text('\n'.join(licenses),encoding='utf8')
print(json.dumps({k:manifest[k]for k in ['bytes','sha256','kept_files']}))
