import sys,zipfile,json,hashlib
from pathlib import Path
root=Path(sys.argv[1]);out=Path(sys.argv[2])
files=[root/n for n in ['package.json','package-lock.json','build.mjs','package-source.py','index.html','LICENSE','README.md']]
files+=list((root/'src').glob('*'))+list((root/'notices').glob('*'))+list((root/'tests').glob('*.py'))
manifest={str(p.relative_to(root)).replace('\\','/'):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,str(p.relative_to(root)))
 z.write(out/'THIRD-PARTY-NOTICES.txt','THIRD-PARTY-NOTICES.txt')
 z.writestr('source-manifest.json',json.dumps(manifest,indent=2)+'\n')
data=(out/'source.zip').read_bytes();(out/'source-manifest.json').write_text(json.dumps({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'files':manifest},indent=2)+'\n',encoding='utf8',newline='\n')
